# Verification record — 2026-09-28

## 0.9.1 empty-view and link-reload correction — 2026-09-30

The dedicated worker and active-document service handle exact known English/Korean no-geometry exporter warnings during one owned export call. Revit dialog events are handled first; exporter-owned native windows require matching process, title, message, window class and one enabled OK button. Generic errors are not reclassified as empty. Partial NWC files are excluded, optional `_객체없음.txt` reports are produced, and independent views continue.

For registered-file export with links included, all top-level Revit links are explicitly reloaded with all worksets open before object preflight. Load results and actual loaded state are checked; Attachment descendants are checked and Overlay descendants are excluded. A failed required link marks that view failed after checking other links. Active-document exports keep the current user's link state.

- Core: 563 automated checks passed in this revision. Final lightweight bootstrap/application smoke passed with 50 rendered screenshots and empty stderr (`verification/empty-view-package-20260930/`).
- Worker dialog/export continuation: 78 checks passed, including real Windows MessageBox fixtures owned by the test process and Revit API doubles (`verification/empty-view-fix-20260930/worker-guard-tests.log`).
- Link preparation: 44 checks passed against production helper with API adapter doubles (`verification/link-reload-20260930/adapter-tests.log`).
- Revit workers 2019/2023/2025/2027: final production API builds passed without warnings/errors; worker version 0.9.1.0 (`verification/empty-view-fix-20260930/worker-build-receipt.json`).
- KKY active-document guard: 184 checks passed, including scoped warning handling, partial NWC preservation and subsequent export. Five-version API build evidence: `../KKY_Tool_Revit/_verification/nwc-empty-view-fix-20260930/`.

Real Autodesk Revit warning windows, native empty-view NWC export, central-file link reload, ACC authentication and the user's project were not exercised. Native fixture checks do not replace that validation. Earlier evidence below is historical and retains its original scope.


## NWC Exporter plus 0.9 — 2026-09-30

- All running KKY Revit windows automatically publish independent active-document sessions. The desktop discovers sessions in the background, labels them by year/title/PID and preserves the selected Revit/view. Temporarily unreadable live hosts remain selected with export disabled; closed hosts are removed. Discovery never changes models or bridge files.
- Core: **563 checks passed**, including simultaneous same-titled Revit 2023/2027 sessions, exact request routing, process-start identity, closed/recycled PIDs, stale/busy states, malformed XML/DTD/junction handling, read-only discovery, multi-view registration, collision-free suggested names, exact view-name output mode and three-mode Excel round trips. Evidence: `verification/multi-view-registration-20260930/core-tests.log`.
- KKY bridge: **102 checks passed**, including quiet wake-up, scalar view caching and invalidation, session/document validation and shutdown. Isolated production API builds passed for Revit 2019/2021/2023/2025/2027. Evidence: `../KKY_Tool_Revit/_verification/nwc-multi-revit-20260930/RESULT.md`.
- Styled WPF confirmations replace all desktop MessageBox calls. **28 dialog checks passed** for modal ownership, button results, Enter/Esc/close behavior, long Korean text and small-window scrolling. No added runtime dependency. Explorer file/folder pickers are preserved.
- Multi-view entry: **22 checks passed** for exact text, blank/duplicate handling, mode selection, registration-error retention/retry, cancellation and constrained layouts. Selecting an existing RVT opens this editor; a blank source row is reused with its existing ID/schedule. View-name mode preserves the user's exact filename or reports an invalid/colliding name without rewriting it.
- The actual lightweight bootstrap and packaged application passed smoke testing, producing **50 screenshots**. UI checks cover multi-version selection, selected view/settings preservation across refresh and temporary failure, host removal, multi-view row additions, view-name preview/persistence and existing Excel/schedule/progress/result behavior. Evidence: `verification/multi-view-registration-20260930/final-package`.
- Excel export prompts to open only after saving succeeds; opening uses the default .xlsx association. Open failures explicitly preserve/report successful file saving. The confirmation uses the same styled dialog.
- Shared .NET runtime preparation and scheduling still use the lightweight bootstrap. Native Revit 2023/2027 simultaneous UI/export, physical keyboard/mouse input, high DPI and installer execution were not performed for this change. API builds, protocol tests and render/behavior smoke tests are reported separately.

## Historical 0.8 verification

## NWC Exporter plus 0.8

One KKY Tools ribbon button named **NWC Exporter plus** opens one program window with **활성 문서 / 파일·예약** tabs. The active-document tab connects to the current Revit instance; the file tab supports NWC-only or combined NWD publication, XLSX input/output and independent model/view schedules. Navisworks selection follows the job's Revit year (2019, 2023, 2025 or 2027).

Structured progress covers queued work, environment checks, RVT opening/NWC export, NWD append/save and destination copying. API operations without a measurable percentage stay indeterminate with elapsed time. Manual runs show a completion window with per-view Success/Failed/Empty outcomes, the failing stage, published paths and folder buttons. Scheduled CLI runs retain result.json and logs in their run folders.

Per-view failures are isolated. A worker's explicitly identified document-level dialog or close failure permits a new owned Revit process to continue only unattempted rows; startup failures, invalid responses and result-less crashes do not create a retry loop. Completed successes and failed rows are never retried. A malformed native NWC is excluded; after a failed append, Navisworks reopens the previously accepted inputs before continuing so fragments of a rejected input are not retained. Global initialization, cancellation and timeout failures can still end the run.

Empty is an explicit conservative preflight outcome or an exact known no-geometry exporter warning/exception observed within the export scope. General API/export exceptions and missing output alone remain failures. Optional reports use the configured NWC basename plus `_객체없음.txt`. An uncertain object inspection proceeds through the real exporter. Existing published NWC files and old reports are preserved; current status and timestamps identify this run. A newly failed/empty cached view invalidates its older successful NWC for future NWD creation. NWD and empty reports share one NWD completion timestamp, including midnight crossings.

### Automated and Windows checks

- **480 checks passed**, including actual Windows Task Scheduler registration, time editing, deletion, view/task independence and cleanup. Three filesystem symbolic-link cases remain skipped because this Windows environment cannot create those links. Evidence: `verification/plus-final-core-tests.log`.
- The total includes 50 XLSX checks, 64 active-document IPC checks using explicit fake hosts, 46 latest-attempt cache checks, 27 bounded Revit continuation checks, and 5 production-runner filesystem checks proving empty-report publication continues when NWD initialization fails. These checks do not instantiate native Revit documents.
- File tests cover SHA-256-verified publication, existing NWC replacement, NWD collision protection, locked destinations, cancellation, exact filenames, empty reports and preservation of prior files. Cache tests include current failed/empty status superseding old success, individual corruption/missing entries, selected model names and changed options.
- **34 packaged GUI screenshots** cover normal/minimum layouts, Excel previews, one-window tabs, disconnected/connected active-document states, Revit-matched Navisworks versions, current document/view matching, actual file counts, indeterminate NWD work and partial-completion rows. Smoke exit code 0. Evidence: `verification/plus-final-ui`.
- The final self-contained Windows x64 package builds Desktop/Core, Revit workers 2019/2023/2025/2027 and NavisWorker with **zero warnings and errors**. Evidence: `verification/plus-final-package-build.log`. File version: **0.8.0.0**. Standalone package: `artifacts/NWCExporterPlus-v0.8`.

### KKY integration and installer scope

The final KKY host/launcher suite passed **83 checks** using real local publication files, explicit Revit API stubs and actual WPF dispatcher timing. Evidence: `KKY_Tool_Revit/_verification/bim-publisher-launcher-20260928/results-f47bf16ff7eb42839c9696068471ba2c`. The host wakes with a low-frequency DispatcherTimer that raises ExternalEvent; document API access occurs only in a Revit API callback, including when the user is interacting with the external program. Checks cover stale/busy/document-instance gates, duplicate requests, expiry, shutdown cleanup, explicit Empty classification and launcher path priority.

The installed common Program Files program is preferred over an older remembered portable path. Without a common installation, the remembered path or a file selection can be used. KKY builds target 2019/2021/2023/2025/2027. The existing KKY 2021 target supports active-document launching; batch worker support remains the four years above. Modern KKY builds retain existing warnings from other project sources/dependencies; the NWC Exporter plus standalone projects do not have those warnings.

Installer path contracts passed 64 checks and build preflight passed 2 checks. The integration build stages the common program once under `%ProgramFiles%\KKY Tools\BimPublisher`, with version-specific KKY assemblies. It updates the existing KKY Tool 3 product and includes the current shared KKY source, including other changes in that source tree. It is a verification build, not a separately installed parallel product or an official-feed publication. Building the installer does not execute it. No installed KKY binary, user add-in registration, official release feed or project model was changed by packaging. The earlier two-button installer is marked superseded.

### Actual Navisworks 2025 — final package verified

**56/56 native integration checks passed** using the exact packaged Core and NavisWorker, installed Navisworks Manage 2025, and genuine synthetic NWC cube fixtures. Evidence: `verification/publisher-plus-final-native-714a178786974bef892ead46396a742f` (`evidence.json`, `RESULT.md`, native inspection reports, `run-evidence`, `published-files.json` and cleanup records).

- Two valid cubes were combined, published and reopened in a fresh native instance. Their geometry, positions and user-selected Korean model names were verified.
- One successful, one latest failed and one latest empty cached view produced a partial NWD containing only the current successful view, plus the exact empty-view TXT. Old successes for failed/empty views were excluded.
- A malformed middle NWC reached the actual Navisworks reader, failed append, triggered reconstruction from accepted inputs and was skipped. The following valid cube was still included. Reopening the final NWD verified both valid cubes and their names.
- A malformed first input failed OpenFile; the next valid file still produced a partial NWD. With every input malformed, all rows were failures and no NWD was published.
- Structured progress retained real processed/input counts and combining/publishing/final states. Long native calls remained indeterminate. Changed scheduled settings were rejected before worker startup.
- Test-owned Navisworks, worker and inspection processes exited. Original fixtures and jobs.json were unchanged. No Revit model was opened and no scheduler job was registered by these native tests.

Tested SHA-256:

| Component | SHA-256 |
| --- | --- |
| Packaged/loaded Core DLL | `2ED6719226A69FD552FE414F857BC4E224CBA9D77DEC0234D48A7FD8DE2C603A` |
| Packaged NavisWorker EXE | `1CBDF91FED40205BC4A3E1F40C4077255F11CA5B208B7FEC5C9015799D8FCDB9` |

The earlier partial-publication checkpoint under `publisher-plus-native-ca7c2a9221c84cea9b6d6d5add74e299` records an older worker and is superseded by the final package evidence above.

### Limits and previous Revit startup report

**Not yet verified in native Revit:** clicking the installed ribbon, active-document NWC export, real scheduled RVT-to-NWC extraction, central-model link/workset recovery, conservative empty-view classification with actual documents, and process continuation after a real document dialog/close failure. The complete RVT → NWC → NWD pipeline is therefore not claimed as passed. Navisworks 2019/2023/2027 runtime behavior, a real remote network share, and executing the integration installer also remain unverified. No user project RVT, exact production view or network destination was supplied.

Native tests inject an isolated owned workspace under Temp because the native Navisworks process could not see the Codex host's default AppData run directory in earlier diagnostics, despite the controller being able to read it. No ACL or security setting was changed. The normal standalone AppData path has not been established as working inside this automation host; production defaults remain unchanged. Published test destinations are local folders, not SMB shares.

The previous Revit 2023 external-application startup failure has not been reproduced and resolved on the user's PC. A normal Revit 2023 worker load probe succeeded, while a test copy carrying an Internet-zone marker reproduced .NET Framework 0x80131515; removing only that test copy's marker restored loading. This is a possible cause, not a confirmed diagnosis. An earlier native Revit fixture attempt progressed past its trust prompt but was blocked by an unrelated installed KKY Preview startup dialog and did not establish successful RVT export.

Navisworks 2027's API major 24 follows the [Autodesk-published version sequence](https://aps.autodesk.com/marketplace/publisher-center/navisworks-publisher-guidelines) (v22 for 2025, v23 for 2026); this is an inference checked against the selected installation at runtime, not a native 2027 test. No different installed release is silently substituted.

---
## Historical 0.7 verification — 2026-09-22

## Version 0.7 automatic link/workset recovery

The shared recovery coordinator now repairs unmet preparation conditions before export. With links excluded, it attempts to unload remaining Revit links, reads the actual link/workset state again, and, if needed, closes the disposable document without saving and reopens it with every user workset ID explicitly selected. The initial opening permits at most two recovery reopenings, and each opened document permits at most two unload passes. Retry exhaustion reports the remaining workset/link names. With links included, recovery opens every host workset without unloading links. Export is performed once, only after the required state has been reached.

Recoverable native per-link unload errors are logged and other links are still attempted. Closed-workset failures can therefore reach the reopen-all step. Cancellation, timeouts, unknown dialogs, invalid document/detachment checks and document open/close failures do not become an unbounded retry. Reopening reuses the same owned physical copy and never saves or synchronizes the original RVT, central model or linked files.

Core/filesystem/recovery suite: **207 checks passed**, including **26 new recovery checks**. New checks cover actual callback ordering, repeat unload, reopen-all after closed worksets or remaining links, links reloaded on reopening, success on the last allowed attempt, retry exhaustion with names, include-links behavior, null state rejection and immediate termination after fatal/cancellation callbacks. These checks exercise the production coordinator with controlled callbacks; they are not native Revit document tests. The existing **three symbolic-link execution checks remain skipped** because the host cannot create those links.

Final self-contained Windows x64 build passed for Desktop/Core, Revit 2019/2023/2025/2027 workers and the Navisworks worker with zero warnings/errors. Packaged file version is **0.7.0.0**. Packaged `--smoke-test` and `--check` both exited 0. The smoke run produced 18 screenshots, and the updated link/workset explanation was visually checked at the minimum 1100×760 layout. No global job settings or scheduled jobs were changed.

### Native Revit test status

An opt-in Revit 2025 integration application and a production `PublishRunner` console driver have been built. The integration application creates only synthetic fixtures: a central host with four user worksets, two host cubes on different worksets (one sharing a workset with the link), a linked cube and a named 3D view. It is designed to force closed-workset reopening and native link unloading, verify both host cubes remain visible, export NWC files and compare source/link SHA-256 hashes.

A dedicated Revit 2025 process was actually launched on 2026-09-22 at 12:00 KST. Revit stopped before add-in startup at `TaskDialog_Security_Unsigned_File_Loading`. The native window was inspected and confirmed to name **BIM Publisher Integration Test**. The harness has not started and no fixture/result directory exists yet. No security setting or trust prompt was overridden. Consequently, native workset/link recovery, RVT-to-NWC export and the complete production RVT-to-NWC-to-NWD chain are **not yet passed**. An operator must complete the test add-in's Revit security prompt before those checks can run. The test's temporary manifest was removed after Revit had read it so future normal Revit starts do not inherit the registration; the current dedicated process remains at its observed prompt. Launch and pending status are recorded under `verification/v0.7-native-*.json`.

Test tooling is excluded from the distributable. The real user central RVT path, exact view name and network destination have not been supplied, so real-project geometry, network publication and performance are not yet validated. Full Navisworks 2019/2023 runtimes are absent on this PC; successful worker builds do not establish runtime compatibility for those releases.

### Native Navisworks 2025 test — passed

The installed Navisworks Manage 2025 runtime actually generated NWC caches from two synthetic OBJ cubes. The **packaged v0.7.0.0 NavisWorker** opened the first NWC in its own new application instance, appended the second, and saved a 6,386-byte NWD. The worker exited 0 and returned `Success=true`. A separate fresh Navisworks instance reopened the saved NWD and verified two geometry items with individual bounds `(0,0,0)–(2,2,2)` and `(10,0,0)–(12,2,2)`. The combined bounds were `(0,0,0)–(12,2,2)`.

Evidence: `verification/navis-native-43ded979624e41e691f7f0334a7dfbff/RESULT.md` and its companion request/response, logs and geometry report. NWD SHA-256: `0054E7D574970EBBC03E49F3DE3269B6860035AC09A58068D169A95A831144DE`. All Navisworks/probe/worker instances created by this test were stopped. This establishes native NWC-to-NWD append/save/reopen behavior for Navisworks 2025 using OBJ-derived NWC inputs; it does **not** establish RVT export behavior, Revit link/workset recovery or 2019/2023 runtime behavior.

### Real NWD local publication test — passed

The production `FilePublisher.PublishAsync` published that actual NWD into a new isolated local folder. **Eight checks passed**: the expected date subfolder and filename pattern, original/output hash equality, duplicate-name refusal at the same completion time, preservation of the source and existing destination after refusal, and absence of additional/temporary files. All checked hashes matched the NWD SHA-256 above. Evidence: `verification/publication-local-v0.7-20260922-1209/publication-verification.json` and its log. This is a local-filesystem test, not SMB/network-share validation.

The v0.7 package contains production binaries and the current verification record only; synthetic models, native test plugins, test drivers and user configuration are excluded. Actual Revit recovery/export, full end-to-end execution, 2019/2023 Navisworks runtimes and the user's network destination remain pending as stated above.

## Version 0.6 host-only opening with every host workset open

`ExportLinks=false` now creates a physically independent per-model RVT copy under the run's `source-copies` directory. Only that copy receives `TransmissionData` writes which request file-based Revit links to remain unloaded before document opening. Top-level link suppression also prevents their nested links loading. The worker opens **all host user worksets** with `OpenAllWorksets`, preserves worksharing via detached opening, and checks all user worksets are actually open before inspecting views/exporting. It never opens only a selected subset or changes view visibility to force hidden elements into the export. `ExportLinks=true` retains the original opening path and also verifies all host user worksets are open.

The worker preserves effective desired metadata for already-transmitted files and rebases relative file references using the selected central/non-workshared source location, or the stored central location for a local workshared file. Non-Revit references retain their load intent, including missing references and references in closed worksets; imported embedded geometry is not relinked. CAD export choices are unchanged. Invalid/unrecognized reference metadata stops the operation rather than reopening the original as a fallback.

TransmissionData does not cover external-resource server/cloud links. Any top-level Revit links still loaded after open are unloaded only inside the temporary document, with no shared-coordinate save callback; the worker then verifies no Revit link remains loaded. Initial loading of those unsupported external-resource references may still occur. `UnloadLocally` is intentionally not used because Autodesk restricts it to local workshared models and the worker opens detached documents. `WorksetConfiguration` cannot change already-open worksets; the implementation does not claim to perform a close/open cycle inside an open document.

All four installed Revit API versions (2019, 2023, 2025, 2027) expose the required metadata, opening, detached-document, workset-state, and link-state/unload APIs. Release builds against all four installed SDK assemblies passed with zero warnings/errors. There are no calls to save/synchronize the source, central model or linked files. Documents close with `Close(false)`; the temporary copy is then deleted. Controller cleanup also handles copies left after cancellation/timeout once the owned Revit process has stopped. Cleanup is confined to recognizable owned directories and refuses reparse points.

Core/filesystem suite: **181 checks passed** (124 existing, 40 reference-path/load-state checks, 17 temporary-copy/cleanup checks). Actual filesystem tests cover physical source/copy separation, source byte preservation, read-only source, writer-locked/empty/missing source rejection, separate copies with equal basenames, nested artifacts, unrelated sibling preservation, controller recovery cleanup, and a locked copy followed by successful cleanup retry. **Three symlink/reparse-point execution checks were skipped** because this host cannot create test symbolic links; the refusal logic is implemented but those paths are not claimed as exercised. These tests do not instantiate Revit documents or test native TransmissionData behavior.

Updated UI text states that both modes open every host workset. Packaged UI smoke passed and produced 18 images; the NWC settings screen was visually checked at the minimum 1100×760 size. The actual RVT → NWC → NWD pipeline, native link-state changes, reference loading and timing improvements still require a real model test. No performance gain or universal early suppression of cloud/provider links is claimed.

Final self-contained Windows x64 build includes Desktop/Core, four Revit workers and the Navisworks worker at version 0.6.0 (file version 0.6.0.0). Final packaged `--smoke-test` and `--check` both exited 0. Deliverable: `artifacts/BimPublisher-win-x64-v0.6.zip`; the prior v0.5 ZIP remains unchanged.

## Version 0.5 per-source NWC filenames

Each source now chooses its original Revit basename (the default) or a literal custom NWC filename. The shared `NwcOutputNames` helper constructs the worker model list and is also used by job validation. Selected names travel unchanged through `ExportModel.OutputName` into the existing Revit worker and the Navisworks input list. Numeric prefixes and the previous 80-character basename truncation are removed. Existing configurations without these additive fields use the original Revit basename.

Custom inputs accept an optional case-insensitive `.nwc` suffix; missing suffixes are appended once. Windows-invalid, reserved, empty, padded or overlong filenames are rejected instead of silently rewritten. Enabled sources must have unique final filenames using ordinal case-insensitive comparison; different folders with the same basename or different views of the same RVT require custom names. Disabled rows are excluded. Final NWD name patterns, date folders and network publication remain unchanged.

Core/integration suite: **124 checks passed**, including **39 new checks** for exact source/custom names, Unicode/dots/case, long names, extension handling, invalid input, duplicate output names, inactive rows, legacy defaults, save/reload/clone, registered order and source/view association, and export request XML. The tests use the same model-list builder as the actual publisher. Final-name validation also preserves valid dots/spaces immediately before the extension (`A..rvt` and `A .rvt`) instead of rejecting the source basename.

Desktop UI adds a per-selected-model filename editor and a visible shortcut from the model list. Smoke checks passed for both modes, immediate filename previews, input enablement, custom-value retention on mode changes, independent row settings, duplicate warning/validation, isolated save/reload and empty/multiple selection. Eighteen previews were rendered; the new normal/minimum-size editors were visually checked, including the complete custom-name area at 1100×760. Smoke mode does not modify real settings or schedules.

Final self-contained Windows x64 build passed for Desktop/Core, Revit 2019/2023/2025/2027 workers and the Navisworks worker with no warnings/errors. Packaged executable file version is 0.5.0.0; packaged `--smoke-test` and `--check` both exited 0. Deliverable: `artifacts/BimPublisher-win-x64-v0.5.zip`. No Autodesk DLLs or user models/settings are included.

Actual RVT → NWC → NWD processing remains unverified. Naming/configuration tests do not verify Autodesk export geometry or runtime behavior; the full Navisworks 2019/2023 runtimes are still unavailable on this development PC.

## Version 0.4 Navisworks 2019 / 2023 / 2025

The application now selects and persists Navisworks 2019, 2023 or 2025 independently of the Revit model version. Discovery checks same-year Manage then Simulate installations; Freedom and standalone Exporters cannot replace an automation runtime. Missing versions remain available in the configuration UI, with installation status, but preflight and execution reject missing installations.

`CombineRequest.NavisworksVersion` passes the selected year to the generic .NET Framework worker. Missing fields in older request XML default to 2025. The worker checks assembly names and exact API generation (2019=16, 2023=20, 2025=22), registered installation path, loaded assemblies and required public Automation signatures before starting its own application. It never substitutes another installed release. The chosen application performs its native SaveFile; this is an execution-version selector, not a separate NWD format downgrade option.

Core/integration suite: **85 checks passed**, including 23 new checks for supported and unsupported years, stored year and XML preservation, legacy requests, API generation mapping, exact-year discovery, same-year edition fallback, incomplete installations and exclusion of Freedom/Exporter-only folders. Navisworks worker negative-path suite: **18 checks passed**, including requesting 2019 or 2023 against the installed 2025 DLLs and rejection before Autodesk code is loaded.

Desktop Release build passed with no warnings/errors. UI smoke exercises selection, reading, isolated persistence, reload and installation-state display for all three years. Standard/minimum-size 2019 and 2023 screens were rendered and visually checked. Real settings and schedules are not changed by these checks.

Installed Navisworks 2025 Resolver/Automation binding and every required public method signature passed a check which does not construct a Navisworks application. Owned-process containment also passed. The scoped loaded-assembly guard permits satellite/resource assemblies while enforcing the selected path and generation for Resolver, Api and Automation. Local official 2019 Exporter API metadata confirms major version 16; it is not a full 2019 runtime test. Runtime evidence: `src/BimPublisher.NavisWorker/verification/runtime-313ef24233484a03af14d2b347976f9b`. Negative-test evidence: `src/BimPublisher.NavisWorker/verification/d1f5c453c4e749dc8b683255749bcadb`.

Final self-contained Windows x64 build succeeded for desktop/Core, all four Revit workers, and the generic Navisworks worker with no warnings/errors. Packaged executable file version is 0.4.0.0; `--smoke-test` and `--check` both exited 0. Fourteen preview images were produced, including 2019/2023 standard and minimum-size views. Deliverable: `artifacts/BimPublisher-win-x64-v0.4.zip`.

This development PC has Navisworks Manage 2025 only. Navisworks 2019 and 2023 full-runtime startup, licensing and actual NWD generation remain unverified. No real RVT → NWC → NWD test has been completed for any combination. Release 0.4 does not change this limitation.

## Version 0.3 NWC settings and distribution wording

Added job-level optional NWC export settings: element properties, parameter inclusion (None / Elements / All), element IDs, room geometry, room attributes, division into levels, parts, missing material search, URLs, linked CAD, lights, and faceting factor. Existing view scope, coordinates and Revit link settings remain connected. New fields default to null, preserving each installed Revit API's defaults for legacy jobs and requests. They do not inherit the last manual export dialog settings.

Core suite: **62 checks passed**, including **21 new checks** for all-option JSON/XML round trips, explicit false versus null, independent jobs and editing clones, old jobs/requests without options, all parameter modes, finite/nonnegative faceting validation, and unsupported options on Revit 2019. Revit 2019 rejects explicit linked CAD, lights or faceting overrides; the 2023/2025/2027 workers support them.

Revit 2019 / 2023 / 2025 / 2027 worker builds passed against the corresponding installed Autodesk API assemblies with 0 warnings and 0 errors. Public API option signatures/defaults were checked against installed RevitAPI.xml files. Actual model conversion remains unverified, as described below.

User-facing Korean text in the desktop application, validation, controller logs, Revit and Navisworks workers and user guide uses professional polite wording. Source/code comments and diagnostic test names are unchanged where they are not product copy.

Final self-contained Windows x64 package built successfully: desktop/Core, four Revit workers and Navisworks worker, version 0.3.0, no build warnings or errors. Packaged `--smoke-test` and `--check` both exited 0. UI smoke checks verify all 12 option controls through loading/reading, default versus explicit selection, invalid faceting text, 0, Revit 2019 disable/reset, preservation of coordinate/link choices, and schedule/NWC tab navigation. Ten PNGs were rendered; standard and minimum-size NWC screens and the lower scrolling section were visually reviewed. No real job settings or schedules were changed by smoke mode.

Deliverable: `artifacts/BimPublisher-win-x64-v0.3.zip`. As in earlier versions, a real RVT → NWC → NWD run is still required to verify Autodesk runtime/exporter behavior and resulting geometry/properties. The manual export dialog also includes some options which the public Revit API does not expose; those are not provided by this application.

## Version 0.2 output update

Per-model 3D view names are now always-visible editable text fields. Newly added RVT rows begin with a blank view name; common values are applied only by the explicit button. User-entered view text remains unchanged through persistence and export.

Added optional `yyyyMMdd_label` output subfolder, independent NWD filename pattern with `{folder}`, and a pure full-path UI preview. A single NWD completion timestamp determines both folder and filename. Existing stored jobs retain their original direct-folder behavior until the new option is enabled.

The default test suite passed **41 checks**, including **14 new checks** for completion-date naming, independent patterns, same-day folder reuse, collision protection, path traversal rejection, cancellation/empty-output protection, missing-parent preservation, direct-folder option, backward compatibility, and persistence. Existing Windows registration integration was not repeated because scheduler code was unchanged.

## Built and packaged

- Desktop and Core Release: 0 warnings, 0 errors.
- Revit workers 2019 / 2023 / 2025 / 2027: 0 warnings, 0 errors against corresponding installed Autodesk API assemblies.
- Navisworks 2025 worker net48 x64: 0 warnings, 0 errors. Exact installed Resolver and Automation assembly load verified without creating a Navisworks application.
- Self-contained Windows x64 package: `artifacts/BimPublisher/BimPublisher.exe`, all four Revit workers and Navisworks executable/config included. No Autodesk DLLs redistributed.
- Packaged executable `--smoke-test`: exit 0. `--check`: exit 0 with initial empty configuration.

## Behavior checked

Core/Windows integration suite: **32 checks passed** via `dotnet run --project tests/BimPublisher.Tests.csproj -c Release -- --scheduler-integration`.

Coverage includes weekly/daily/one-time boundaries, changing today's execution time, midnight/year rollover, disabling schedules, past one-time schedules, malformed times, duplicate models/views, output filename traversal and reserved names, saved settings/backup, malformed configuration, worker response serialization, Task Scheduler XML escaping, missed-run behavior, file copy integrity, duplicate result protection, cancelled/empty upload refusal, and owned child process cleanup.

Windows Task Scheduler was exercised with a temporary one-time task set to **2035**. Its execution time was updated, weekly multi-day XML validated without registration, then the temporary task removed. No Autodesk processing was scheduled. Final enumeration found no `BimPublisher_*` tasks left behind.

Navisworks worker: **11 negative-input tests passed**. Inputs, existing output, and existing response files remained intact. Benign process containment test verified cleanup of a hidden child process on worker exit.

UI: model, schedule, log tabs plus model/schedule at 1100×760 rendered and visually reviewed. Packaged screenshots are in `artifacts/preview*.png`. These contain illustrative models only; smoke mode never saves settings or registers schedules.

## Initial release verification limits (historical; see newer entries above)

- No user RVT path, target 3D view, or real network publication folder was supplied.
- Real Revit launch, NWC exporter availability/trust interaction, actual NWC generation, NWD aggregation, and publication to the user's network share remain untested.
- Revit 2027 exporter NWC compatibility with Navisworks 2025 needs an actual file test.
- No changes were made to the existing KKY add-in, installed Autodesk add-in manifests, production model files, or production output folders during development.
- Active timeout supports cancellation between/asynchronously during operations. Windows synchronous network filesystem calls may still wait for the operating system; no absolute hard deadline is promised for a stalled SMB server.


