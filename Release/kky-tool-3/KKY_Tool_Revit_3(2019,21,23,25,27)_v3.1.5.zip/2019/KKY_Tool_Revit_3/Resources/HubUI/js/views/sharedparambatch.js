import { createRvtRegistration } from '../core/rvtRegistration.js?v=20261008registration1';
import { clear, div, toast, showExcelSavedDialog, chooseExcelMode } from '../core/dom.js?v=20260731parameterexport1';
import { refreshUiAfterHostDialog } from '../core/hostDialog.js';
import { getLastExcelExportLocale } from '../core/dom.js?v=20260731parameterexport1';
import { attachRvtDropZone } from '../core/rvtDrop.js';
import { ProgressDialog } from '../core/progress.js';
import { post, onHost } from '../core/bridge.js';
import { getTopbarState } from '../core/topbar.js?v=20261012official315';
import { operationOutcome, resultValue, resultCount } from '../core/operationOutcome.js';
import { createRvtTable, renderRvtRows, getRvtName } from './rvtTable.js?v=20260504a';

const DEFAULT_SUMMARY = { okCount: 0, failCount: 0, skipCount: 0 };
const CATEGORY_PRESET_KEY = "kky_spb_cat_presets";
const SHAREDPARAMBATCH_SETTINGS_KEY = 'kky.settings.sharedparambatch.v1';
let activeSharedParamBatchPreferenceCleanup = null;
const EXCEL_PHASE_WEIGHT = { EXCEL_INIT: 0.05, EXCEL_WRITE: 0.85, EXCEL_SAVE: 0.08, AUTOFIT: 0.02, DONE: 1, ERROR: 1 };

function formatRevitParamGroupLabel(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (raw.toUpperCase() === 'INVALID') return 'Other';
  const source = raw.toUpperCase().startsWith('PG_') ? raw.substring(3) : raw;
  return source
    .split('_')
    .filter(Boolean)
    .map((part) => {
      const lower = String(part || '').toLowerCase();
      return lower ? lower.charAt(0).toUpperCase() + lower.slice(1) : '';
    })
    .join(' ');
}

function normalizeCategoryPresets(rows) {
  return (Array.isArray(rows) ? rows : [])
    .filter((row) => row && String(row.name || '').trim())
    .map((row) => ({
      name: String(row.name || '').trim(),
      ids: (Array.isArray(row.ids) ? row.ids : [])
        .map((id) => Number(id))
        .filter(Number.isFinite)
    }));
}

function loadLegacyCategoryPresets() {
  try {
    const parsed = JSON.parse(localStorage.getItem(CATEGORY_PRESET_KEY) || '[]');
    if (Array.isArray(parsed)) return normalizeCategoryPresets(parsed);
    if (!parsed || typeof parsed !== 'object') return [];
    return normalizeCategoryPresets(Object.keys(parsed).map((name) => {
      const old = parsed[name];
      return {
        name,
        ids: Array.isArray(old)
          ? old.map((item) => item?.idInt)
          : (Array.isArray(old?.ids) ? old.ids : [])
      };
    }));
  } catch {
    return [];
  }
}

function normalizeSavedSharedParams(rows) {
  return (Array.isArray(rows) ? rows : [])
    .filter((row) => row && String(row.guid || '').trim())
    .map((row) => ({
      groupName: String(row.groupName || ''),
      name: String(row.name || row.guid || ''),
      guid: String(row.guid || ''),
      paramTypeLabel: String(row.paramTypeLabel || ''),
      desc: String(row.desc || ''),
      settings: {
        isInstanceBinding: row.settings?.isInstanceBinding !== false,
        paramGroup: String(row.settings?.paramGroup || 'PG_DATA'),
        allowVaryBetweenGroups: !!row.settings?.allowVaryBetweenGroups,
        categories: (Array.isArray(row.settings?.categories) ? row.settings.categories : []).map((category) => ({
          idInt: Number(category?.idInt),
          name: String(category?.name || ''),
          path: String(category?.path || category?.name || '')
        })).filter((category) => Number.isFinite(category.idInt))
      }
    }));
}

function loadSharedParamBatchPreferences() {
  try {
    const value = JSON.parse(localStorage.getItem(SHAREDPARAMBATCH_SETTINGS_KEY) || 'null');
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

function applySharedParamBatchPreferences(state, value) {
  if (!value || typeof value !== 'object') return;
  state.selectedGroup = String(value.selectedGroup || '');
  state.selectedParams = normalizeSavedSharedParams(value.selectedParams);
  state.activeParamGuid = state.selectedParams[0]?.guid || '';
  state.options.closeAllWorksetsOnOpen = value.closeAllWorksetsOnOpen !== false;
  state.options.syncComment = String(value.syncComment || '').slice(0, 240);
  state.categoryPresets = normalizeCategoryPresets(value.categoryPresets);
}

function saveSharedParamBatchPreferences(state) {
  const serialized = JSON.stringify({
    selectedGroup: String(state.selectedGroup || ''),
    selectedParams: normalizeSavedSharedParams(state.selectedParams),
    closeAllWorksetsOnOpen: !!state.options.closeAllWorksetsOnOpen,
    syncComment: String(state.options.syncComment || '').slice(0, 240),
    categoryPresets: normalizeCategoryPresets(state.categoryPresets)
  });
  if (serialized === state.lastSavedPreferences) return;
  try {
    localStorage.setItem(SHAREDPARAMBATCH_SETTINGS_KEY, serialized);
    state.lastSavedPreferences = serialized;
  } catch {}
}

function attachSharedParamBatchPreferenceSync(page, state, refresh) {
  let saveTimer = 0;
  let applyTimer = 0;
  let routeTimer = 0;
  const scheduleSave = () => {
    clearTimeout(saveTimer);
    saveTimer = window.setTimeout(() => saveSharedParamBatchPreferences(state), 180);
  };
  const scheduleSaveAfterClick = scheduleSave;
  page.addEventListener('input', scheduleSave);
  page.addEventListener('change', scheduleSave);
  page.addEventListener('click', scheduleSaveAfterClick);

  const tryApply = () => {
    clearTimeout(applyTimer);
    if (!page.isConnected) return;
    const value = loadSharedParamBatchPreferences();
    if (!value || JSON.stringify(value) === state.lastSavedPreferences) return;
    const active = document.activeElement;
    const editing = !!active && page.contains(active) && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName || '');
    if (state.running || editing) {
      applyTimer = window.setTimeout(tryApply, 400);
      return;
    }
    applySharedParamBatchPreferences(state, value);
    state.lastSavedPreferences = JSON.stringify(value);
    refresh();
  };
  const onSharedChange = (event) => {
    const detail = event?.detail;
    const keys = Array.isArray(detail?.keys) ? [...detail.keys] : [];
    if (detail?.key) keys.push(detail.key);
    if (detail?.values && typeof detail.values === 'object') keys.push(...Object.keys(detail.values));
    if (!detail || !keys.length || keys.includes(SHAREDPARAMBATCH_SETTINGS_KEY)) tryApply();
  };
  const cleanup = () => {
    clearTimeout(saveTimer);
    clearTimeout(applyTimer);
    clearTimeout(routeTimer);
    page.removeEventListener('input', scheduleSave);
    page.removeEventListener('change', scheduleSave);
    page.removeEventListener('click', scheduleSaveAfterClick);
    window.removeEventListener('kky:shared-settings-changed', onSharedChange);
    window.removeEventListener('hashchange', onRouteChange);
    if (activeSharedParamBatchPreferenceCleanup === cleanup) activeSharedParamBatchPreferenceCleanup = null;
  };
  const onRouteChange = () => {
    clearTimeout(routeTimer);
    routeTimer = window.setTimeout(() => {
      if (!page.isConnected) cleanup();
    }, 0);
  };
  window.addEventListener('kky:shared-settings-changed', onSharedChange);
  window.addEventListener('hashchange', onRouteChange);
  return cleanup;
}

export function renderSharedParamBatch(root) {
  activeSharedParamBatchPreferenceCleanup?.();
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);
  const top = document.querySelector('#topbar-root .topbar') || document.querySelector('.topbar');
  if (top) top.classList.add('hub-topbar');

  const savedPreferences = loadSharedParamBatchPreferences();
  const state = {
    spFilePath: '',
    groups: [],
    defsByGroup: {},
    categoryTree: [],
    paramGroups: [],
    selectedGroup: String(savedPreferences?.selectedGroup || ''),
    selectedParams: normalizeSavedSharedParams(savedPreferences?.selectedParams),
    activeParamGuid: '',
    defSelection: new Set(),
    defSearch: '',
    rvtList: [],
    rvtChecked: new Set(),
    pendingFolderBrowse: false,
    options: {
      closeAllWorksetsOnOpen: savedPreferences?.closeAllWorksetsOnOpen !== false,
      syncComment: String(savedPreferences?.syncComment || '')
    },
    summary: { ...DEFAULT_SUMMARY },
    logs: [],
    lastResult: null,
    running: false,
    lastProgressPct: 0,
    categoryFilterText: '',
    categoryPresets: Array.isArray(savedPreferences?.categoryPresets)
      ? normalizeCategoryPresets(savedPreferences.categoryPresets)
      : loadLegacyCategoryPresets()
  };
  let progressHideTimer = null;
  let progressOwner = null;
  let progressKind = '';
  let catalogRefreshTimer = null;
  let lastCatalogSnapshot = '';

  const page = div('feature-shell sharedparambatch-page sharedparambatch-page--main');
  const header = div('feature-header');
  const heading = div('feature-heading');
  heading.innerHTML = `
    <span class="feature-kicker">프로젝트 파라미터</span>
    <h2 class="feature-title">프로젝트/공유 파라미터 일괄 추가</h2>
    <p class="feature-sub">프로젝트 또는 공유 파라미터를 여러 RVT에 일괄 추가하고 바인딩합니다.</p>`;

  const btnRun = cardBtn('실행', onRun, 'btn--primary');
  const btnExport = cardBtn('엑셀 내보내기', onExport, 'btn--secondary');
  btnExport.disabled = true;
  const btnViewResult = cardBtn('결과 보기', openResultModal, 'btn--secondary');
  btnViewResult.disabled = true;

  header.append(heading);
  page.append(header);

  const layout = div('sharedparambatch-layout');
  page.append(layout);

  const warningSection = div('section sharedparambatch-section spb-warning');
  const warningText = document.createElement('div');
  warningText.textContent = '현재 Revit에 연결된 공유 매개변수를 찾지 못했습니다. 관리 > 공유 매개변수에서 파일을 연결하면 목록을 자동으로 다시 확인합니다.';
  warningSection.append(warningText);
  warningSection.style.display = 'none';

  const paramSection = div('section sharedparambatch-section sharedparambatch-param-workflow');
  const bulkApplyBtn = cardBtn('현재 설정을 전체에 적용', applyBulkSettings, 'btn--secondary');
  const paramHeader = buildSelectHeader('공유파라미터 적용 설정', bulkApplyBtn, btnRun, btnExport);
  const paramHeaderActions = paramHeader.querySelector('.spb-headerRight');
  if (paramHeaderActions) {
    paramHeaderActions.insertBefore(btnViewResult, btnExport);
  }
  const paramIntro = div('spb-workflow-note');
  paramIntro.textContent = '공유파라미터를 추가하고 선택한 행의 바인딩, Parameter Group, 적용 카테고리를 아래에서 바로 설정합니다.';

  const inlineWorkbench = div('spb-inline-workbench');
  const catalogPanel = div('spb-workbench-panel spb-catalog-panel');
  const catalogHeader = div('spb-workbench-panel__header');
  const catalogHeading = document.createElement('h4');
  catalogHeading.textContent = '공유파라미터 목록';
  const catalogCount = document.createElement('span');
  catalogCount.className = 'chip chip--info';
  catalogCount.textContent = '0개';
  catalogHeader.append(catalogHeading, catalogCount);

  const catalogControls = div('spb-catalog-controls');
  const catalogGroupField = div('spb-catalog-field');
  catalogGroupField.append(labelSpan('그룹'));
  const groupSelect = document.createElement('select');
  groupSelect.className = 'sharedparambatch-select spb-groupSelect';
  groupSelect.addEventListener('change', () => {
    state.selectedGroup = groupSelect.value;
    renderDefinitionList();
  });
  catalogGroupField.append(groupSelect);

  const catalogSearchField = div('spb-catalog-field spb-catalog-field--search');
  catalogSearchField.append(labelSpan('검색'));
  const searchInput = document.createElement('input');
  searchInput.type = 'search';
  searchInput.className = 'sharedparambatch-input spb-search';
  searchInput.placeholder = '이름 검색';
  searchInput.addEventListener('input', () => {
    state.defSearch = (searchInput.value || '').trim();
    renderDefinitionList();
  });
  catalogSearchField.append(searchInput);
  catalogControls.append(catalogGroupField, catalogSearchField);

  const catalogMeta = div('sharedparambatch-def-meta');
  const catalogResultCount = document.createElement('span');
  catalogResultCount.className = 'chip';
  const catalogSelectionBadge = document.createElement('span');
  catalogSelectionBadge.className = 'chip chip--info';
  catalogMeta.append(catalogResultCount, catalogSelectionBadge);
  const definitionList = div('sharedparambatch-def-list spb-defList sharedparambatch-def-card-list');
  const addDefinitionsBtn = cardBtn('선택 항목 추가', onAddSelectedDefs, 'btn--primary');
  const catalogFooter = div('spb-workbench-panel__footer');
  catalogFooter.append(addDefinitionsBtn);
  catalogPanel.append(catalogHeader, catalogControls, catalogMeta, definitionList, catalogFooter);

  const selectedPanel = div('spb-workbench-panel spb-selected-panel');
  const selectedHeader = div('spb-workbench-panel__header');
  const selectedHeading = document.createElement('h4');
  selectedHeading.textContent = '선택된 파라미터';
  const selectedCount = document.createElement('span');
  selectedCount.className = 'chip chip--info';
  selectedCount.textContent = '0개';
  selectedHeader.append(selectedHeading, selectedCount);
  const paramTable = document.createElement('table');
  paramTable.className = 'sharedparambatch-table sharedparambatch-selected-table';
  paramTable.innerHTML = '<thead><tr><th>이름</th><th>바인딩</th><th>Parameter Group</th><th>카테고리</th><th>작업</th></tr></thead><tbody></tbody>';
  const paramBody = paramTable.querySelector('tbody');
  const paramWrap = div('spb-tableWrap spb-selected-tableWrap');
  paramWrap.append(paramTable);
  const selectedEmptyHint = div('spb-selected-hint');
  selectedEmptyHint.textContent = '목록에서 공유파라미터를 선택해 추가하세요.';
  selectedPanel.append(selectedHeader, paramWrap, selectedEmptyHint);
  inlineWorkbench.append(catalogPanel, selectedPanel);

  const inlineEditor = div('spb-inline-editor is-empty');
  paramSection.append(paramHeader, paramIntro, inlineWorkbench, inlineEditor);

  const rvtSection = div('section sharedparambatch-section');
  const rvtHeader = div('spb-rvtHeader');
  const rvtHeaderLeft = div('spb-rvtHeaderLeft');
  const rvtTitle = document.createElement('h3');
  rvtTitle.textContent = 'RVT 파일';
  const rvtActions = div('section-actions');
  rvtActions.append(
    cardBtn('추가', () => post('sharedparambatch:browse-rvts', {})),
    cardBtn('폴더 선택', onBrowseFolder),
    cardBtn('선택 제거', removeSelectedRvts, 'btn--secondary'),
    cardBtn('목록 비우기', clearRvts, 'btn--secondary'),
    cardBtn('리스트 크게보기', openRvtModal, 'btn--secondary')
  );
  rvtHeaderLeft.append(rvtTitle, rvtActions);

  const rvtHeaderRight = div('spb-rvtHeaderRight');
  const closeWrap = document.createElement('label');
  closeWrap.className = 'spb-inlineCheck';
  const closeChk = document.createElement('input');
  closeChk.type = 'checkbox';
  closeChk.checked = !!state.options.closeAllWorksetsOnOpen;
  closeChk.id = 'spb-close-worksets';
  closeChk.addEventListener('change', () => { state.options.closeAllWorksetsOnOpen = !!closeChk.checked; });
  const closeLbl = document.createElement('span');
  closeLbl.textContent = '워크셰어링 파일: 모든 웍셋 닫고 열기';
  closeWrap.append(closeChk, closeLbl);

  const syncInput = document.createElement('input');
  syncInput.type = 'text';
  syncInput.className = 'sharedparambatch-input spb-syncInput';
  syncInput.placeholder = '동기화 코멘트';
  syncInput.value = state.options.syncComment || '';
  syncInput.addEventListener('input', () => { state.options.syncComment = syncInput.value || ''; });
  rvtHeaderRight.append(closeWrap, labelSpan('동기화 코멘트'), syncInput);

  rvtHeader.append(rvtHeaderLeft, rvtHeaderRight);
  rvtSection.append(rvtHeader);
  const rvtHint = div('rvt-drop-hint');
  rvtHint.textContent = 'RVT 추가 버튼을 누르거나 탐색기에서 .rvt 파일을 이 목록으로 끌어다 놓으면 바로 등록됩니다.';
  rvtSection.append(rvtHint);
  const { table: rvtTable, tbody: rvtBody, master: rvtMaster } = createRvtTable({ registration: true });
  const rvtListWrap = div('spb-rvtTableWrap rvt-drop-zone');
  rvtListWrap.append(rvtTable);
  rvtSection.append(rvtListWrap);
  attachRvtDropZone(rvtListWrap, {
    onDropPaths: (paths) => {
      const added = appendDroppedRvts(paths);
      if (!added) {
        toast('이미 등록된 RVT입니다.', 'warn');
        return;
      }
      renderRvtList();
      toast(`${added}개 RVT를 추가했습니다.`, 'ok');
    },
    onInvalid: () => toast('RVT 파일만 드래그해서 추가할 수 있습니다.', 'warn')
  });

  const rvtModal = buildRvtModal();
  const resultModal = buildResultModal();

  const resultSection = div('sharedparambatch-result');
  const resultHeader = sectionHeader('최근 실행 결과', []);
  resultSection.append(resultHeader);
  const summaryRow = div('sharedparambatch-summary');
  const badgeOk = summaryBadge('정상', '0');
  const badgeFail = summaryBadge('실패', '0');
  const badgeSkip = summaryBadge('건너뜀', '0');
  summaryRow.append(badgeOk.wrap, badgeFail.wrap, badgeSkip.wrap);

  const logPathRow = div('sharedparambatch-logpath');
  const logPathText = document.createElement('span');
  logPathText.textContent = '로그 파일: -';
  const logOpenBtn = cardBtn('폴더 열기', () => {
    if (!state.logTextPath) { toast('로그 파일이 없습니다.', 'err'); return; }
    post('sharedparambatch:open-folder', { path: state.logTextPath });
  }, 'btn--secondary');
  logOpenBtn.disabled = true;
  logPathRow.append(logPathText, logOpenBtn);

  const logTable = document.createElement('table');
  logTable.className = 'sharedparambatch-table';
  logTable.innerHTML = '<thead><tr><th>단계</th><th>RVT</th><th>메시지</th></tr></thead><tbody></tbody>';
  const logBody = logTable.querySelector('tbody');
  resultSection.append(summaryRow, logPathRow, logTable);
  resultSection.style.display = 'none';
  resultModal.body.append(summaryRow, logTable);

  layout.append(warningSection, paramSection, rvtSection);
  page.append(layout);
  page.append(rvtModal, resultModal.overlay);

  target.append(page);
  activeSharedParamBatchPreferenceCleanup = attachSharedParamBatchPreferenceSync(page, state, () => {
    if (syncInput) syncInput.value = state.options.syncComment || '';
    closeChk.checked = !!state.options.closeAllWorksetsOnOpen;
    if (state.groups.length) {
      state.defSelection = reconcileDefinitionSelection(state.defSelection);
      reconcileSelectedParams();
    }
    renderGroupOptions();
    renderDefinitionList();
    renderSelectedParams();
    updateButtons();
  });

  const preferenceCleanup = activeSharedParamBatchPreferenceCleanup;

  onHost('sharedparambatch:init', handleInit);
  onHost('sharedparambatch:rvts-picked', handleRvtsPicked);
  onHost('sharedparambatch:progress', handleProgress);
  onHost('sharedparambatch:done', handleDone);
  onHost('sharedparambatch:exported', handleExported);
  onHost('revit:error', ({ message }) => {
    state.pendingFolderBrowse = false;
    finishRunning(true);
    toast(message || '프로젝트 파라미터 추가 중 Revit 오류가 발생했습니다. 대상 RVT와 선택한 파라미터 설정을 확인한 뒤 다시 실행해 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err', 3200);
  });
  onHost('host:error', ({ message }) => {
    state.pendingFolderBrowse = false;
    finishRunning(true);
    toast(message || '프로젝트 파라미터 추가 중 호스트 오류가 발생했습니다. Hub 화면을 다시 열고 Revit 연결 상태를 확인한 뒤 다시 실행해 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err', 3200);
  });

  requestInit();
  renderGroupOptions();
  renderDefinitionList();
  renderSelectedParams();
  renderRvtList();
  window.addEventListener('focus', autoRefreshSharedParameters, true);
  document.addEventListener('visibilitychange', handleVisibilityChange, true);

  let lastAutoRefreshAt = 0;

  function autoRefreshSharedParameters() {
    if (!page.isConnected) {
      cleanupAutoRefresh();
      return;
    }
    if (document.visibilityState === 'hidden') return;
    const now = Date.now();
    if (now - lastAutoRefreshAt < 800) return;
    lastAutoRefreshAt = now;
    requestInit();
  }

  function handleVisibilityChange() {
    if (document.visibilityState === 'visible') autoRefreshSharedParameters();
  }

  function cleanupAutoRefresh() {
    clearTimeout(catalogRefreshTimer);
    window.removeEventListener('focus', autoRefreshSharedParameters, true);
    document.removeEventListener('visibilitychange', handleVisibilityChange, true);
  }

  function requestInit() {
    post('sharedparambatch:init', {
      activeDocument: getSharedParamBatchActiveDocumentInfo()
    });
  }

  function handleInit(payload) {
    clearTimeout(catalogRefreshTimer);
    if (!page.isConnected) return;
    if (!payload || !payload.ok) {
      warningText.textContent = payload?.message || 'Revit에 공유 매개변수가 지정되어 있지 않습니다. Revit의 관리 > 공유 매개변수에서 파일을 연결하면 목록을 자동으로 다시 확인합니다.';
      warningSection.style.display = 'flex';
      toast(payload?.message || '프로젝트 파라미터 추가 화면을 초기화하지 못했습니다. 공유파라미터 파일 연결 상태를 확인한 뒤 Hub 화면을 다시 열어 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err');
      return;
    }
    warningSection.style.display = 'none';
    const catalogSnapshot = JSON.stringify([payload.spFilePath || '', payload.groups || [], payload.defsByGroup || {}, payload.categoryTree || [], payload.paramGroups || []]);
    if (catalogSnapshot === lastCatalogSnapshot) return;
    const active = document.activeElement;
    if (state.running || (active && page.contains(active) && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName || ''))) {
      catalogRefreshTimer = setTimeout(() => handleInit(payload), 400);
      return;
    }
    lastCatalogSnapshot = catalogSnapshot;
    state.spFilePath = payload.spFilePath || '';
    state.groups = Array.isArray(payload.groups) ? payload.groups : [];
    state.defsByGroup = payload.defsByGroup || {};
    state.categoryTree = Array.isArray(payload.categoryTree) ? payload.categoryTree : [];
    state.paramGroups = Array.isArray(payload.paramGroups) ? payload.paramGroups : [];
    if (syncInput) syncInput.value = state.options.syncComment || '';
    closeChk.checked = !!state.options.closeAllWorksetsOnOpen;
    state.defSelection = reconcileDefinitionSelection(state.defSelection);
    const removedCount = reconcileSelectedParams();
    if (removedCount > 0) {
      toast(`현재 Revit 공유 매개변수에서 찾을 수 없는 선택 ${removedCount}개를 제외했습니다.`, 'warn');
    }
    renderGroupOptions();
    renderDefinitionList();
    renderSelectedParams();
    saveSharedParamBatchPreferences(state);
  }

  function renderGroupOptions() {
    if (!groupSelect) return;
    groupSelect.innerHTML = '';
    if (!state.groups.length) {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = '그룹이 없습니다.';
      groupSelect.append(opt);
      state.selectedGroup = '';
      return;
    }
    if (!state.groups.includes(state.selectedGroup)) {
      state.selectedGroup = state.groups[0] || '';
    }
    state.groups.forEach((g) => {
      const opt = document.createElement('option');
      opt.value = g;
      opt.textContent = g;
      groupSelect.append(opt);
    });
    groupSelect.value = state.selectedGroup;
  }

  function renderDefinitionList() {
    if (!definitionList) return;
    definitionList.innerHTML = '';
    const defs = state.defsByGroup[state.selectedGroup] || [];
    const search = (state.defSearch || '').toLowerCase();
    const filtered = search
      ? defs.filter(d => (d.name || '').toLowerCase().includes(search))
      : defs;
    catalogCount.textContent = `${Object.values(state.defsByGroup || {}).reduce((sum, rows) => sum + (Array.isArray(rows) ? rows.length : 0), 0)}개`;
    catalogResultCount.textContent = filtered.length ? `${filtered.length}/${defs.length}개 표시` : '0개 표시';
    catalogSelectionBadge.textContent = `${state.defSelection.size}개 선택`;
    if (!filtered.length) {
      const empty = div('sharedparambatch-def-empty');
      empty.textContent = '조건에 맞는 공유파라미터 정의가 없습니다.';
      definitionList.append(empty);
      updateButtons();
      return;
    }
    filtered.forEach((d) => {
      const row = document.createElement('button');
      row.type = 'button';
      row.className = 'sharedparambatch-def-row';
      row.dataset.guid = d.guid;
      if (state.defSelection.has(d.guid)) row.classList.add('is-selected');
      if (state.selectedParams.some(p => p.guid === d.guid)) row.classList.add('is-added');

      const info = div('sharedparambatch-def-info');
      const name = document.createElement('strong');
      name.textContent = d.name || '';
      const meta = document.createElement('small');
      meta.textContent = `${state.selectedGroup || '-'}${d.paramTypeLabel ? ' · ' + d.paramTypeLabel : ''}${d.guid ? ' · ' + d.guid.slice(0, 8) : ''}`;
      info.append(name, meta);

      const alreadyAdded = state.selectedParams.some(p => p.guid === d.guid);
      const action = document.createElement('span');
      action.className = alreadyAdded
        ? 'chip chip--ok'
        : (state.defSelection.has(d.guid) ? 'chip chip--info' : 'chip');
      action.textContent = alreadyAdded
        ? '추가됨'
        : (state.defSelection.has(d.guid) ? '선택됨' : '추가');
      row.append(info, action);
      row.addEventListener('click', () => {
        if (alreadyAdded) {
          setActiveParam(d.guid, true);
          return;
        }
        if (state.defSelection.has(d.guid)) state.defSelection.delete(d.guid);
        else state.defSelection.add(d.guid);
        renderDefinitionList();
      });
      definitionList.append(row);
    });
    updateButtons();
  }

  function onAddSelectedDefs() {
    const selectedGuids = Array.from(state.defSelection || []);
    if (!selectedGuids.length) { toast('추가할 파라미터를 선택해 주세요.', 'err'); return; }

    const nextSelection = new Set(state.defSelection);
    const newlyAddedGuids = [];
    selectedGuids.forEach((guid) => {
      if (!guid) return;
      if (state.selectedParams.some(p => p.guid === guid)) {
        nextSelection.delete(guid);
        return;
      }
      const found = findDefinitionByGuid(guid);
      if (!found) return;
      nextSelection.delete(guid);
      state.selectedParams.push({
        groupName: found.groupName || state.selectedGroup,
        name: found.name || guid,
        guid,
        paramTypeLabel: found.paramTypeLabel || '',
        desc: found.desc || '',
        settings: {
          isInstanceBinding: true,
          paramGroup: getDefaultParamGroupValue(),
          allowVaryBetweenGroups: false,
          categories: []
        }
      });
      newlyAddedGuids.push(guid);
    });
    state.defSelection = nextSelection;
    renderDefinitionList();
    if (newlyAddedGuids.length) state.activeParamGuid = newlyAddedGuids[0];
    renderSelectedParams();
    if (newlyAddedGuids.length) {
      window.requestAnimationFrame(() => {
        inlineEditor.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }
  }

  function normalizeDefinitionKey(value) {
    return String(value || '').trim().toLowerCase();
  }

  function findDefinitionByGuid(guid) {
    const key = normalizeDefinitionKey(guid);
    if (!key) return null;
    for (const groupName of Object.keys(state.defsByGroup || {})) {
      const found = (state.defsByGroup[groupName] || []).find((item) => normalizeDefinitionKey(item.guid) === key);
      if (found) return { ...found, groupName };
    }
    return null;
  }

  function findDefinitionMatch(param) {
    if (!param) return null;
    const byGuid = findDefinitionByGuid(param.guid);
    if (byGuid) return byGuid;

    const targetName = normalizeDefinitionKey(param.name);
    const targetGroup = normalizeDefinitionKey(param.groupName);
    if (!targetName) return null;

    for (const groupName of Object.keys(state.defsByGroup || {})) {
      if (targetGroup && normalizeDefinitionKey(groupName) !== targetGroup) continue;
      const found = (state.defsByGroup[groupName] || []).find((item) => normalizeDefinitionKey(item.name) === targetName);
      if (found) return { ...found, groupName };
    }
    return null;
  }

  function reconcileDefinitionSelection(selection) {
    const next = new Set();
    Array.from(selection || []).forEach((guid) => {
      const match = findDefinitionByGuid(guid);
      if (match?.guid) next.add(match.guid);
    });
    return next;
  }

  function reconcileSelectedParams() {
    const before = state.selectedParams.length;
    state.selectedParams = state.selectedParams
      .map((param) => {
        const match = findDefinitionMatch(param);
        if (!match) return null;
        return {
          ...param,
          groupName: match.groupName || param.groupName,
          name: match.name || param.name,
          guid: match.guid || param.guid,
          paramTypeLabel: match.paramTypeLabel || param.paramTypeLabel || '',
          desc: match.desc || param.desc || ''
        };
      })
      .filter(Boolean);
    return before - state.selectedParams.length;
  }

  function renderSelectedParams() {
    paramBody.innerHTML = '';
    selectedCount.textContent = `${state.selectedParams.length}개`;
    selectedEmptyHint.style.display = state.selectedParams.length ? 'none' : '';
    if (!state.selectedParams.length) {
      state.activeParamGuid = '';
      const tr = document.createElement('tr');
      tr.className = 'empty-row';
      const td = document.createElement('td');
      td.className = 'empty-cell';
      td.colSpan = 5;
      td.textContent = '선택된 파라미터가 없습니다.';
      tr.append(td);
      paramBody.append(tr);
      renderInlineParamEditor();
      updateButtons();
      return;
    }

    if (!state.selectedParams.some((param) => param.guid === state.activeParamGuid)) {
      state.activeParamGuid = state.selectedParams[0].guid;
    }

    state.selectedParams.forEach((p, idx) => {
      const tr = document.createElement('tr');
      tr.dataset.guid = p.guid || '';
      if (p.guid === state.activeParamGuid) tr.classList.add('is-active');
      tr.append(tdText(p.name));
      tr.append(tdText(p.settings.isInstanceBinding ? '인스턴스' : '타입'));
      tr.append(tdText(formatParamGroup(p.settings.paramGroup)));
      tr.append(tdCategorySummary(p.settings.categories));

      const actionTd = document.createElement('td');
      actionTd.className = 'spb-selected-actions';
      const btnSetting = actionBtn('편집', (event) => {
        event?.stopPropagation?.();
        setActiveParam(p.guid, true);
      });
      const btnRemove = actionBtn('삭제', (event) => {
        event?.stopPropagation?.();
        state.defSelection.delete(p.guid);
        state.selectedParams.splice(idx, 1);
        if (state.activeParamGuid === p.guid) {
          state.activeParamGuid = state.selectedParams[Math.min(idx, state.selectedParams.length - 1)]?.guid || '';
        }
        renderDefinitionList();
        renderSelectedParams();
      }, 'btn--ghost');
      actionTd.append(btnSetting, btnRemove);
      tr.append(actionTd);
      tr.addEventListener('click', () => setActiveParam(p.guid));
      paramBody.append(tr);
    });
    renderInlineParamEditor();
    updateButtons();
  }

  function setActiveParam(guid, scrollToEditor = false) {
    if (!guid || !state.selectedParams.some((param) => param.guid === guid)) return;
    state.activeParamGuid = guid;
    renderSelectedParams();
    if (scrollToEditor) {
      window.requestAnimationFrame(() => inlineEditor.scrollIntoView({ behavior: 'smooth', block: 'start' }));
    }
  }

  function renderInlineParamEditor() {
    inlineEditor.innerHTML = '';
    const param = state.selectedParams.find((item) => item.guid === state.activeParamGuid);
    if (!param) {
      inlineEditor.classList.add('is-empty');
      const emptyTitle = document.createElement('h3');
      emptyTitle.textContent = '파라미터 상세 설정';
      const emptyText = document.createElement('p');
      emptyText.textContent = '공유파라미터를 추가하면 바인딩과 적용 카테고리를 여기에서 바로 설정할 수 있습니다.';
      inlineEditor.append(emptyTitle, emptyText);
      return;
    }

    inlineEditor.classList.remove('is-empty');
    const editorHeader = div('spb-inline-editor__header');
    const editorHeading = div('spb-inline-editor__heading');
    const editorTitle = document.createElement('h3');
    editorTitle.textContent = `${param.name} 설정`;
    const editorDescription = document.createElement('p');
    editorDescription.textContent = param.desc || '이 파라미터의 바인딩과 적용 카테고리를 설정합니다.';
    editorHeading.append(editorTitle, editorDescription);
    const editorSummary = div('spb-inline-editor__summary');
    const bindingBadge = document.createElement('span');
    bindingBadge.className = 'chip chip--info';
    const groupBadge = document.createElement('span');
    groupBadge.className = 'chip';
    const categoryCount = document.createElement('span');
    categoryCount.className = 'chip';
    editorSummary.append(bindingBadge, groupBadge, categoryCount);
    editorHeader.append(editorHeading, editorSummary);

    const settingsGrid = div('spb-inline-settings-grid');
    const bindingField = div('spb-inline-setting-field');
    bindingField.append(subTitle('바인딩'));
    const bindingOptions = div('sharedparambatch-binding');
    const radioName = `spb-binding-${String(param.guid || 'active').replace(/[^a-zA-Z0-9_-]/g, '')}`;
    const instanceRadio = radio(radioName, '인스턴스', param.settings.isInstanceBinding, (checked) => {
      if (!checked) return;
      param.settings.isInstanceBinding = true;
      syncVaryState();
      refreshParamSummary();
    });
    const typeRadio = radio(radioName, '타입', !param.settings.isInstanceBinding, (checked) => {
      if (!checked) return;
      param.settings.isInstanceBinding = false;
      syncVaryState();
      refreshParamSummary();
    });
    bindingOptions.append(instanceRadio.wrap, typeRadio.wrap);
    bindingField.append(bindingOptions);

    const groupField = div('spb-inline-setting-field');
    groupField.append(subTitle('Parameter Group'));
    const groupSelectEl = document.createElement('select');
    groupSelectEl.className = 'sharedparambatch-select';
    state.paramGroups.forEach((group) => {
      const option = document.createElement('option');
      option.value = getParamGroupValue(group);
      option.textContent = formatParamGroup(option.value);
      groupSelectEl.append(option);
    });
    const currentGroup = state.paramGroups.find((group) => {
      const value = getParamGroupValue(group);
      return value === param.settings.paramGroup
        || group.id === param.settings.paramGroup
        || group.Id === param.settings.paramGroup
        || group.key === param.settings.paramGroup
        || group.Key === param.settings.paramGroup;
    });
    groupSelectEl.value = getParamGroupValue(currentGroup) || param.settings.paramGroup || getDefaultParamGroupValue();
    param.settings.paramGroup = groupSelectEl.value || getDefaultParamGroupValue();
    groupSelectEl.addEventListener('change', () => {
      param.settings.paramGroup = groupSelectEl.value;
      refreshParamSummary();
    });
    groupField.append(groupSelectEl);

    const varyField = div('spb-inline-setting-field');
    varyField.append(subTitle('그룹 인스턴스'));
    const varyWrap = div('sharedparambatch-option');
    const varyChk = document.createElement('input');
    varyChk.type = 'checkbox';
    varyChk.checked = !!param.settings.allowVaryBetweenGroups;
    varyChk.id = `spb-vary-${String(param.guid || 'active').replace(/[^a-zA-Z0-9_-]/g, '')}`;
    varyChk.addEventListener('change', () => {
      param.settings.allowVaryBetweenGroups = !!varyChk.checked;
    });
    const varyLabel = document.createElement('label');
    varyLabel.setAttribute('for', varyChk.id);
    varyLabel.textContent = 'Values can vary by group instance';
    varyWrap.append(varyChk, varyLabel);
    varyField.append(varyWrap);
    settingsGrid.append(bindingField, groupField, varyField);

    const categorySection = div('spb-inline-category-editor');
    const categoryHeader = div('spb-inline-category-editor__header');
    const categoryHeading = div('spb-inline-editor__heading');
    const categoryTitle = document.createElement('h4');
    categoryTitle.textContent = '적용 카테고리';
    const categoryDescription = document.createElement('p');
    categoryDescription.textContent = '프로젝트 파라미터를 추가할 Revit 카테고리를 선택합니다.';
    categoryHeading.append(categoryTitle, categoryDescription);
    const categoryActions = div('sharedparambatch-category-actions');
    const selectAllBtn = cardBtn('전체 선택', () => {
      selectAllCategories(param);
      refreshCategoryTree();
      refreshParamSummary();
    }, 'btn--secondary');
    const clearAllBtn = cardBtn('전체 해제', () => {
      clearAllCategories(param);
      refreshCategoryTree();
      refreshParamSummary();
    }, 'btn--secondary');
    const clearChildrenBtn = cardBtn('서브카테고리 해제', () => {
      clearSubCategories(param);
      refreshCategoryTree();
      refreshParamSummary();
    }, 'btn--secondary');
    categoryActions.append(selectAllBtn, clearAllBtn, clearChildrenBtn);
    categoryHeader.append(categoryHeading, categoryActions);

    const categoryTools = div('spb-inline-category-tools');
    const categoryFilter = document.createElement('input');
    categoryFilter.type = 'search';
    categoryFilter.className = 'sharedparambatch-input';
    categoryFilter.placeholder = '카테고리 검색';
    categoryFilter.value = state.categoryFilterText || '';
    categoryFilter.addEventListener('input', () => {
      state.categoryFilterText = categoryFilter.value || '';
      refreshCategoryTree();
    });

    const presetSelect = document.createElement('select');
    presetSelect.className = 'sharedparambatch-select sharedparambatch-preset-select';
    const presetNameInput = document.createElement('input');
    presetNameInput.type = 'text';
    presetNameInput.className = 'sharedparambatch-input sharedparambatch-preset-name';
    presetNameInput.placeholder = '프리셋 이름';
    presetSelect.addEventListener('change', () => {
      presetNameInput.value = presetSelect.value || '';
    });

    const savePresetBtn = cardBtn('프리셋 저장', () => {
      const name = (presetNameInput.value || presetSelect.value || '').trim();
      if (!name) {
        toast('저장할 프리셋 이름을 입력해 주세요.', 'err');
        return;
      }
      saveCategoryPreset(name, param.settings.categories || []);
      populatePresetOptions(name);
      presetNameInput.value = name;
      toast(`프리셋 저장 완료: ${name}`, 'ok');
    }, 'btn--secondary');
    const loadPresetBtn = cardBtn('불러오기', () => {
      if (!presetSelect.value) {
        toast('불러올 프리셋을 선택해 주세요.', 'err');
        return;
      }
      applyCategoryPreset(param, presetSelect.value);
      refreshCategoryTree();
      refreshParamSummary();
      toast(`프리셋 적용 완료: ${presetSelect.value}`, 'ok');
    }, 'btn--secondary');
    const deletePresetBtn = cardBtn('삭제', () => {
      const name = (presetSelect.value || '').trim();
      if (!name) {
        toast('삭제할 프리셋을 선택해 주세요.', 'err');
        return;
      }
      deleteCategoryPreset(name);
      populatePresetOptions('');
      presetNameInput.value = '';
      toast(`프리셋 삭제 완료: ${name}`, 'ok');
    }, 'btn--secondary');
    const categorySearchRow = div('spb-inline-category-search');
    categorySearchRow.append(categoryFilter);
    const presetTools = div('spb-inline-preset-tools');
    presetTools.append(presetSelect, presetNameInput, savePresetBtn, loadPresetBtn, deletePresetBtn);
    categoryTools.append(categorySearchRow, presetTools);

    const categoryTree = div('sharedparambatch-category-tree');
    categorySection.append(categoryHeader, categoryTools, categoryTree);
    inlineEditor.append(editorHeader, settingsGrid, categorySection);

    populatePresetOptions('');
    syncVaryState();
    refreshCategoryTree();
    refreshParamSummary();

    function populatePresetOptions(selectedName) {
      presetSelect.innerHTML = '';
      const defaultOption = document.createElement('option');
      defaultOption.value = '';
      defaultOption.textContent = '카테고리 프리셋 선택';
      presetSelect.append(defaultOption);
      loadCategoryPresets().map((preset) => preset.name).sort().forEach((name) => {
        const option = document.createElement('option');
        option.value = name;
        option.textContent = name;
        presetSelect.append(option);
      });
      presetSelect.value = selectedName || '';
    }

    function syncVaryState() {
      varyChk.disabled = !param.settings.isInstanceBinding;
      if (!param.settings.isInstanceBinding) {
        param.settings.allowVaryBetweenGroups = false;
        varyChk.checked = false;
      }
    }

    function refreshCategoryTree() {
      renderCategoryTree(categoryTree, param, refreshParamSummary);
    }

    function refreshParamSummary() {
      bindingBadge.textContent = param.settings.isInstanceBinding ? '인스턴스' : '타입';
      groupBadge.textContent = formatParamGroup(param.settings.paramGroup) || 'Parameter Group 미지정';
      categoryCount.textContent = `${param.settings.categories.length}개 카테고리`;
      const row = Array.from(paramBody.querySelectorAll('tr[data-guid]')).find((item) => item.dataset.guid === param.guid);
      if (!row || row.cells.length < 4) return;
      row.cells[1].textContent = param.settings.isInstanceBinding ? '인스턴스' : '타입';
      row.cells[2].textContent = formatParamGroup(param.settings.paramGroup);
      row.replaceChild(tdCategorySummary(param.settings.categories), row.cells[3]);
    }
  }

  function renderRvtList() {
    const allChecked = state.rvtList.length > 0 && state.rvtList.every(f => state.rvtChecked.has(f));
    [rvtMaster, buildRvtModal.master].forEach((master) => {
      if (!master) return;
      master.checked = allChecked;
      master.indeterminate = !allChecked && state.rvtList.some(path => state.rvtChecked.has(path));
      master.disabled = state.rvtList.length === 0;
      master.onchange = () => {
        if (master.checked) state.rvtChecked = new Set(state.rvtList);
        else state.rvtChecked.clear();
        renderRvtList();
        updateButtons();
      };
    });
    const rows = state.rvtList.map((p, idx) => ({
      checked: state.rvtChecked.has(p),
      index: idx + 1,
      name: getRvtName(p),
      path: p,
      title: p,
      onToggle: (checked) => {
        if (checked) state.rvtChecked.add(p);
        else state.rvtChecked.delete(p);
        renderRvtList();
      }
    }));
    renderRvtRows(rvtBody, rows);
    if (buildRvtModal.tbody) {
      renderRvtRows(buildRvtModal.tbody, rows);
    }
    updateButtons();
  }

  function handleRvtsPicked(payload) {
    if (state.pendingFolderBrowse) {
      ProgressDialog.hide();
      state.pendingFolderBrowse = false;
    }
    if (!payload || !payload.ok) {
      if (payload?.message) toast(payload.message, 'err');
      return;
    }
    const droppedPaths = Array.isArray(payload?.rvtPaths)
      ? payload.rvtPaths
      : (Array.isArray(payload?.paths) ? payload.paths : []);
    const added = appendDroppedRvts(droppedPaths);
    const changed = added > 0;
    if (changed) {
      refreshUiAfterHostDialog(() => renderRvtList());
    }
    if (payload?.fromFolder) {
      toast(added ? `${added}개 추가 완료` : '추가된 RVT가 없습니다.', added ? 'ok' : 'err');
    }
  }

  function removeSelectedRvts() {
    if (!state.rvtChecked.size) { toast('삭제할 RVT를 선택해 주세요.', 'err'); return; }
    state.rvtList = state.rvtList.filter(p => !state.rvtChecked.has(p));
    state.rvtChecked.clear();
    renderRvtList();
  }

  function clearRvts() {
    state.rvtList = [];
    state.rvtChecked.clear();
    renderRvtList();
  }

  function appendDroppedRvts(paths) {
    let added = 0;
    (Array.isArray(paths) ? paths : []).forEach((path) => {
      if (!path) return;
      if (!state.rvtList.includes(path)) {
        state.rvtList.push(path);
        added += 1;
      }
      state.rvtChecked.add(path);
    });
    return added;
  }

  function onBrowseFolder() {
    if (state.running) return;
    state.pendingFolderBrowse = true;
    ProgressDialog.show('RVT 폴더 선택', '폴더 내 RVT 파일을 찾는 중입니다.');
    ProgressDialog.update(20, '폴더 내 RVT 파일을 찾는 중입니다.', '하위 폴더를 포함해 RVT 파일을 검색하는 중입니다.');
    post('sharedparambatch:browse-folder', {});
  }

  function onRun() {
    if (state.running) return;
    if (!state.selectedParams.length) { toast('파라미터를 선택해 주세요.', 'err'); return; }
    if (!state.rvtList.length) { toast('RVT 파일을 추가해 주세요.', 'err'); return; }
    const selectedRvts = getCheckedRvtPaths();
    if (!selectedRvts.length) { toast('적용할 RVT를 1개 이상 선택해 주세요.', 'err'); return; }
    const missingCats = state.selectedParams.filter(p => !p.settings.categories.length);
    if (missingCats.length) {
      toast('카테고리를 지정하지 않은 파라미터가 있습니다.', 'err');
      return;
    }

    const payload = {
      activeDocument: getSharedParamBatchActiveDocumentInfo(),
      spFilePath: state.spFilePath,
      rvtPaths: selectedRvts,
      parameters: state.selectedParams.map(p => ({
        groupName: p.groupName,
        paramName: p.name,
        guid: p.guid,
        paramTypeLabel: p.paramTypeLabel,
        description: p.desc,
        settings: {
          isInstanceBinding: p.settings.isInstanceBinding,
          paramGroup: p.settings.paramGroup,
          allowVaryBetweenGroups: p.settings.allowVaryBetweenGroups,
          categories: p.settings.categories
        }
      })),
      closeAllWorksetsOnOpen: state.options.closeAllWorksetsOnOpen,
      syncComment: state.options.syncComment
    };

    state.running = true;
    updateButtons();
    progressKind = 'run';
    progressOwner = ProgressDialog.show('프로젝트 파라미터 추가', '작업을 준비하는 중입니다.');
    ProgressDialog.update(0, '작업을 준비하는 중입니다.', '선택한 파라미터와 RVT 목록을 정리하는 중입니다.', progressOwner);
    post('sharedparambatch:run', payload);
  }

  function handleProgress(payload) {
    if (!payload || !state.running || !ProgressDialog.isOwner(progressOwner)) return;
    if (payload.phase || payload.current != null || payload.phaseProgress != null) {
      handleExcelProgress(payload);
      return;
    }
    handleRunProgress(payload);
  }

  function handleRunProgress(payload) {
    clearProgressHideTimer();
    const total = Number(payload.total || payload.Total || 0);
    const step = Number(payload.step || payload.Step || 0);
    const text = payload.text || payload.message || '';
    const pct = Math.max(0, Math.min(100, total > 0 ? (step / total) * 100 : (Number(payload.percent) || 0)));
    state.lastProgressPct = pct;
    const subtitle = buildRunProgressSubtitle(pct, text, step, total);
    const detail = buildRunProgressDetail(text, step, total);
    if (progressKind !== 'run') return;
    ProgressDialog.update(pct, subtitle, detail, progressOwner);
    if (pct >= 100) scheduleProgressHide();
  }

  function handleExcelProgress(payload) {
    clearProgressHideTimer();
    const phase = normalizeExcelPhase(payload?.phase);
    const total = Number(payload?.total) || 0;
    const current = Number(payload?.current) || 0;
    const percent = computeExcelPercent(phase, current, total, payload?.phaseProgress, payload?.percent);
    const subtitle = buildExcelSubtitle(phase, current, total);
    const detail = formatExcelDetail(phase, payload?.message, current, total);

    state.lastProgressPct = percent;
    if (progressKind !== 'excel') return;
    ProgressDialog.update(percent, subtitle, detail, progressOwner);

    if (phase === 'DONE' || phase === 'ERROR') {
      scheduleProgressHide(260);
    }
  }

  function handleDone(payload) {
    finishRunning(true);
    const summary = resultValue(payload, 'summary') || {};
    state.summary = {
      okCount: resultCount(summary, 'okCount'),
      failCount: resultCount(summary, 'failCount'),
      skipCount: resultCount(summary, 'skipCount')
    };
    state.logs = (Array.isArray(resultValue(payload, 'logs')) ? resultValue(payload, 'logs') : []).map(log => ({
      level: resultValue(log, 'level') || '', file: resultValue(log, 'file') || '',
      msg: resultValue(log, 'msg') || resultValue(log, 'message') || ''
    }));
    state.lastResult = operationOutcome(payload || { ok: false }, {
      successCount: state.summary.okCount, failureCount: state.summary.failCount,
      skippedCount: state.summary.skipCount,
      targetCount: state.summary.okCount + state.summary.failCount + state.summary.skipCount
    });
    renderSummary();
    renderLogs();
    requestAnimationFrame(() => openResultModal());
    toast(state.lastResult.message, state.lastResult.tone, 4200);
  }

  function finishRunning(resetProgress) {
    state.running = false;
    updateButtons();
    if (resetProgress) {
      clearProgressHideTimer();
      state.lastProgressPct = 0;
      if (progressOwner != null) ProgressDialog.hide(progressOwner);
      progressOwner = null;
      progressKind = '';
    }
  }

  async function onExport() {
    if (state.running) return;
    if (!state.logs.length) { toast('내보낼 로그가 없습니다.', 'err'); return; }
    const excelMode = await chooseExcelMode();
    if (!excelMode) return;
    state.running = true;
    updateButtons();
    progressKind = 'excel';
    progressOwner = ProgressDialog.show('프로젝트 파라미터 결과 내보내기', '엑셀 파일을 준비하는 중입니다.');
    ProgressDialog.update(0, '엑셀 파일을 준비하는 중입니다.', '로그 결과와 저장 옵션을 정리하는 중입니다.', progressOwner);
    post('sharedparambatch:export-excel', { excelMode, locale: getLastExcelExportLocale() });
  }

  function handleExported(payload) {
    finishRunning(true);
    if (!payload || !payload.ok) {
      toast(payload?.message || '프로젝트 파라미터 추가 결과 엑셀 내보내기에 실패했습니다. 저장 경로 권한과 파일이 열려 있는지 확인해 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err');
      return;
    }
    const path = payload.filePath || payload.path;
    requestAnimationFrame(() => {
      showExcelSavedDialog('프로젝트/공유 파라미터 일괄 추가 결과 엑셀을 저장했습니다.', path, (p) => post('excel:open', { path: p }));
    });
  }

  function clearProgressHideTimer() {
    if (progressHideTimer) {
      clearTimeout(progressHideTimer);
      progressHideTimer = null;
    }
  }

  function scheduleProgressHide(delay = 260, afterHide) {
    clearProgressHideTimer();
    const owner = progressOwner;
    progressHideTimer = setTimeout(() => {
      progressHideTimer = null;
      ProgressDialog.hide(owner);
      if (typeof afterHide === 'function') afterHide();
    }, delay);
  }

  function buildRunProgressSubtitle(percent, message, step, total) {
    const raw = String(message || '').trim();
    if (raw.includes('정의 로드')) return '공유파라미터 정의를 읽는 중입니다.';
    if (raw.includes('완료')) return '프로젝트 파라미터 추가 완료';
    if (total > 0) return `RVT를 처리하는 중입니다. (${Math.max(step, 0)}/${total})`;
    return `프로젝트 파라미터를 추가하는 중입니다. (${formatProgressPercent(percent)})`;
  }

  function buildRunProgressDetail(message, step, total) {
    const raw = String(message || '').trim();
    if (raw) return raw;
    if (total > 0) return `${Math.max(step, 0)} / ${total}`;
    return '';
  }

  function normalizeExcelPhase(phase) {
    return String(phase || '').trim().toUpperCase() || 'EXCEL_WRITE';
  }

  function computeExcelPercent(phase, current, total, phaseProgress, fallbackPercent) {
    const norm = normalizeExcelPhase(phase);
    if (norm === 'DONE') { state.lastProgressPct = 100; return 100; }
    if (norm === 'ERROR') return state.lastProgressPct;

    if (Number.isFinite(fallbackPercent)) {
      const direct = Math.max(state.lastProgressPct, Math.min(100, Number(fallbackPercent)));
      state.lastProgressPct = direct;
      return direct;
    }

    const completed = ['EXCEL_INIT', 'EXCEL_WRITE', 'EXCEL_SAVE', 'AUTOFIT'].reduce((acc, key) => {
      if (key === norm) return acc;
      return acc + (EXCEL_PHASE_WEIGHT[key] || 0);
    }, 0);
    const weight = EXCEL_PHASE_WEIGHT[norm] || 0;
    const ratio = total > 0 ? Math.max(0, Math.min(1, current / total)) : 0;
    const staged = Math.max(ratio, clamp01(phaseProgress));
    const pct = Math.min(100, Math.max(state.lastProgressPct, (completed + weight * staged) * 100));
    state.lastProgressPct = pct;
    return pct;
  }

  function buildExcelSubtitle(phase, current, total) {
    const norm = normalizeExcelPhase(phase);
    switch (norm) {
      case 'EXCEL_INIT': return '엑셀 워크북을 준비하는 중입니다.';
      case 'EXCEL_WRITE': return `엑셀 로그를 작성하는 중입니다. (${current}/${Math.max(total, current || 1)})`;
      case 'EXCEL_SAVE': return '엑셀 파일을 저장하는 중입니다.';
      case 'AUTOFIT': return '엑셀 스타일을 적용하는 중입니다.';
      case 'DONE': return '프로젝트/공유 파라미터 일괄 추가 결과 엑셀 내보내기 완료';
      case 'ERROR': return '프로젝트/공유 파라미터 일괄 추가 결과 엑셀 내보내기 오류';
      default: return '프로젝트/공유 파라미터 일괄 추가 결과 엑셀 내보내기를 진행하는 중입니다.';
    }
  }

  function formatExcelDetail(phase, message, current, total) {
    const raw = String(message || '').trim();
    if (raw) return raw;
    const norm = normalizeExcelPhase(phase);
    if (norm === 'EXCEL_WRITE' && total > 0) return `${current} / ${total} 로그를 기록하는 중입니다.`;
    if (norm === 'AUTOFIT') return '셀 스타일과 열 너비를 정리하는 중입니다.';
    if (norm === 'DONE') return '프로젝트/공유 파라미터 일괄 추가 결과 엑셀 파일이 저장되었습니다.';
    return '';
  }

  function clamp01(value) {
    const num = Number(value);
    if (!Number.isFinite(num)) return 0;
    return Math.max(0, Math.min(1, num));
  }

  function formatProgressPercent(percent) {
    const safe = Number(percent);
    if (!Number.isFinite(safe)) return '0%';
    return `${Math.max(0, Math.min(100, Math.round(safe * 10) / 10))}%`;
  }

  function renderSummary() {
    badgeOk.value.textContent = String(state.summary.okCount ?? 0);
    badgeFail.value.textContent = String(state.summary.failCount ?? 0);
    badgeSkip.value.textContent = String(state.summary.skipCount ?? 0);
    resultModal.title.textContent = state.lastResult ? `프로젝트 파라미터 추가 ${state.lastResult.label}` : '결과 보기';
    resultModal.message.textContent = state.lastResult?.message || '';
    logPathText.textContent = state.logTextPath ? `로그 파일: ${state.logTextPath}` : '로그 파일: -';
    logOpenBtn.disabled = !state.logTextPath;
    btnViewResult.disabled = !hasRunResults();
    btnExport.disabled = !state.logs.length;
    resultSection.style.display = 'none';
  }

  function renderLogs() {
    logBody.innerHTML = '';
    if (!state.logs.length) {
      const tr = document.createElement('tr');
      tr.className = 'empty-row';
      const td = document.createElement('td');
      td.className = 'empty-cell';
      td.colSpan = 3;
      td.textContent = '로그가 없습니다.';
      tr.append(td);
      logBody.append(tr);
      return;
    }
    state.logs.forEach((log) => {
      const tr = document.createElement('tr');
      tr.append(tdText(log.level || ''));
      tr.append(tdText(log.file || ''));
      tr.append(tdText(log.msg || ''));
      logBody.append(tr);
    });
  }

  function getCheckedRvtPaths() {
    return state.rvtList.filter((path) => state.rvtChecked.has(path));
  }

  function updateButtons() {
    const disabled = state.running;
    btnRun.disabled = disabled || !state.selectedParams.length || !state.rvtList.length || !getCheckedRvtPaths().length;
    btnViewResult.disabled = disabled || !hasRunResults();
    btnExport.disabled = disabled || !state.logs.length;
    addDefinitionsBtn.disabled = disabled || state.defSelection.size === 0;
    bulkApplyBtn.disabled = disabled || state.selectedParams.length < 2;
  }

  function hasRunResults() {
    if (state.lastResult) return true;
    if (state.logs.length) return true;
    const summary = state.summary || DEFAULT_SUMMARY;
    return Number(summary.okCount || 0) + Number(summary.failCount || 0) + Number(summary.skipCount || 0) > 0;
  }

  function formatParamGroup(value) {
    const match = state.paramGroups.find(g => g.key === value || g.Key === value || g.id === value || g.Id === value);
    if (match) return formatRevitParamGroupLabel(match.label || match.Label || match.key || match.Key || match.id || match.Id || value || '');
    return formatRevitParamGroupLabel(value || '');
  }

  function getParamGroupValue(group) {
    if (!group) return '';
    return group.key || group.Key || group.id || group.Id || '';
  }

  function getDefaultParamGroupValue() {
    const preferred = state.paramGroups.find((group) => {
      const key = String(group?.key || group?.Key || '').toLowerCase();
      const id = String(group?.id || group?.Id || '').toLowerCase();
      const label = String(group?.label || group?.Label || '').toLowerCase();
      return key === 'pg_data'
        || id === 'pg_data'
        || key.includes('parameter.group:data')
        || label === 'data';
    });
    return getParamGroupValue(preferred || state.paramGroups[0]) || 'PG_DATA';
  }

  function applyBulkSettings() {
    if (state.selectedParams.length < 2) return;
    const source = state.selectedParams.find((param) => param.guid === state.activeParamGuid) || state.selectedParams[0];
    const template = source?.settings;
    if (!template) return;
    const cloned = cloneSettings(template);
    state.selectedParams.forEach((p) => {
      if (!p || p.guid === source.guid) return;
      p.settings = cloneSettings(cloned);
    });
    renderSelectedParams();
    toast(`${source.name} 설정을 나머지 파라미터에 적용했습니다.`, 'ok');
  }

  function cloneSettings(src) {
    return {
      isInstanceBinding: !!src.isInstanceBinding,
      paramGroup: src.paramGroup,
      allowVaryBetweenGroups: !!src.allowVaryBetweenGroups,
      categories: Array.isArray(src.categories) ? src.categories.map(c => ({
        idInt: c.idInt,
        name: c.name,
        path: c.path
      })) : []
    };
  }

  function buildSelectHeader(titleText, pickerButton, runButton, exportButton) {
    const header = div('spb-cardHeader');
    const left = div('spb-headerLeft');
    const title = document.createElement('h3');
    title.textContent = titleText;
    left.append(title, pickerButton);
    const right = div('spb-headerRight');
    right.append(runButton, exportButton);
    header.append(left, right);
    return header;
  }

  function buildRvtModal() {
    const overlay = div('sharedparambatch-modal-overlay');
    const modal = div('sharedparambatch-modal spb-modalLarge');
    const header = div('sharedparambatch-modal__header');
    const title = div('sharedparambatch-modal__title');
    title.textContent = 'RVT 파일 목록';
    const closeBtn = actionBtn('닫기', closeRvtModal, 'btn--ghost');
    header.append(title, closeBtn);

    const body = div('sharedparambatch-modal__body');
    const actions = div('section-actions');
    actions.append(
      cardBtn('RVT 추가', () => post('sharedparambatch:browse-rvts', {})),
      cardBtn('폴더 선택', onBrowseFolder),
      cardBtn('선택 제거', removeSelectedRvts, 'btn--secondary'),
      cardBtn('목록 비우기', clearRvts, 'btn--secondary')
    );
    const { table, tbody, master } = createRvtTable({ registration: true });
    const wrap = div('spb-rvtTableWrap rvt-drop-zone');
    wrap.append(table);
    body.append(actions, wrap);
    attachRvtDropZone(wrap, {
      onDropPaths: (paths) => {
        const added = appendDroppedRvts(paths);
        if (!added) {
          toast('이미 등록된 RVT입니다.', 'warn');
          return;
        }
        renderRvtList();
        toast(`${added}개 RVT를 추가했습니다.`, 'ok');
      },
      onInvalid: () => toast('RVT 파일만 드래그해서 추가할 수 있습니다.', 'warn')
    });

    modal.append(header, body);
    overlay.append(modal);

    overlay.addEventListener('click', (ev) => { if (ev.target === overlay) closeRvtModal(); });

    buildRvtModal.registration = createRvtRegistration({
      overlay, dialog: modal, header, actions, body, tableWrap: wrap, table,
      addButton: actions.querySelector('button'), closeButton: closeBtn,
      openClass: 'is-open', subtitle: '공유파라미터를 적용할 RVT를 등록합니다.', onClose: closeRvtModal
    });
    buildRvtModal.overlay = overlay;
    buildRvtModal.tbody = tbody;
    buildRvtModal.master = master;

    return overlay;
  }

  function buildResultModal() {
    const overlay = div('sharedparambatch-modal-overlay');
    const modal = div('sharedparambatch-modal spb-modalLarge');
    const header = div('sharedparambatch-modal__header');
    const title = div('sharedparambatch-modal__title');
    title.textContent = '결과 보기';
    const closeBtn = actionBtn('닫기', closeResultModal, 'btn--ghost');
    header.append(title, closeBtn);

    const body = div('sharedparambatch-modal__body');
    const message = div('sharedparambatch-result-message');
    body.append(message);
    const footer = div('sharedparambatch-modal__footer');
    const spacer = document.createElement('span');
    const closeFooterBtn = cardBtn('닫기', closeResultModal, 'btn--secondary');
    footer.append(spacer, closeFooterBtn);

    modal.append(header, body, footer);
    overlay.append(modal);

    overlay.addEventListener('click', (ev) => { if (ev.target === overlay) closeResultModal(); });

    return { overlay, body, title, message };
  }

  function openResultModal() {
    if (!hasRunResults()) {
      toast('최근 실행 결과가 없습니다.', 'err');
      return;
    }
    if (resultModal.overlay) resultModal.overlay.classList.add('is-open');
  }

  function closeResultModal() {
    if (resultModal.overlay) resultModal.overlay.classList.remove('is-open');
  }

  function openRvtModal() {
    const modal = buildRvtModal;
    modal.registration?.open();
    renderRvtList();
  }

  function closeRvtModal() {
    const modal = buildRvtModal;
    modal.registration?.close();
  }

  function renderCategoryTree(container, param, onChange) {
    container.innerHTML = '';
    if (!state.categoryTree.length) {
      container.textContent = '카테고리 정보가 없습니다.';
      return;
    }
    const selected = new Set(param.settings.categories.map(c => c.path || c.name));
    const keyword = (state.categoryFilterText || '').trim().toLowerCase();
    const list = document.createElement('ul');
    list.className = 'sharedparambatch-tree';
    state.categoryTree.forEach((node) => {
      const built = buildCategoryNode(node, keyword);
      if (built) list.append(built);
    });
    container.append(list);

    function buildCategoryNode(node, keyword) {
      const nameText = String(node.name || '').toLowerCase();
      const childMatches = [];
      if (node.children && node.children.length) {
        node.children.forEach((child) => {
          const cnode = buildCategoryNode(child, keyword);
          if (cnode) childMatches.push(cnode);
        });
      }
      const selfMatch = !keyword || nameText.includes(keyword);
      if (!selfMatch && childMatches.length === 0) return null;

      const li = document.createElement('li');
      const row = div('sharedparambatch-tree-row');
      if (node.isBindable) {
        const chk = document.createElement('input');
        chk.type = 'checkbox';
        chk.checked = selected.has(node.path || node.name);
        chk.addEventListener('change', () => {
          if (chk.checked) {
            addCategory(param, node);
          } else {
            removeCategory(param, node);
          }
          if (typeof onChange === 'function') onChange();
        });
        row.append(chk);
      }
      const label = document.createElement('span');
      label.textContent = node.name || '';
      row.append(label);
      li.append(row);

      if (childMatches.length) {
        const childList = document.createElement('ul');
        childList.className = 'sharedparambatch-tree';
        childMatches.forEach((child) => childList.append(child));
        li.append(childList);
      }
      return li;
    }
  }

  function addCategory(param, node) {
    if (!param.settings.categories.find(c => c.path === node.path)) {
      param.settings.categories.push({
        idInt: node.idInt,
        name: node.name,
        path: node.path
      });
    }
  }

  function removeCategory(param, node) {
    param.settings.categories = param.settings.categories.filter(c => c.path !== node.path);
  }

  function selectAllCategories(param) {
    const all = [];
    collectBindable(state.categoryTree, all);
    param.settings.categories = all.map((n) => ({ idInt: n.idInt, name: n.name, path: n.path }));
  }

  function clearAllCategories(param) {
    param.settings.categories = [];
  }

  function clearSubCategories(param) {
    const targets = new Set();
    collectBindableWithDepth(state.categoryTree, targets, 0);
    param.settings.categories = param.settings.categories.filter(c => !targets.has(c.path || c.name));
  }

  function collectBindable(nodes, out) {
    nodes.forEach((n) => {
      if (n.isBindable) out.push(n);
      if (n.children && n.children.length) collectBindable(n.children, out);
    });
  }

  function collectBindableWithDepth(nodes, out, depth) {
    nodes.forEach((n) => {
      if (depth >= 1 && n.isBindable) out.add(n.path || n.name);
      if (n.children && n.children.length) collectBindableWithDepth(n.children, out, depth + 1);
    });
  }


  function loadCategoryPresets() {
    return normalizeCategoryPresets(state.categoryPresets);
  }

  function saveCategoryPresets(presets) {
    const rows = normalizeCategoryPresets(presets);
    state.categoryPresets = rows;
    try { localStorage.setItem(CATEGORY_PRESET_KEY, JSON.stringify(rows)); } catch {}
    saveSharedParamBatchPreferences(state);
  }

  function saveCategoryPreset(name, categories) {
    const key = String(name || '').trim();
    if (!key) return;
    const presets = loadCategoryPresets();
    const next = {
      name: key,
      ids: (categories || []).map((c) => c.idInt).filter((id) => Number.isFinite(Number(id)))
    };
    const idx = presets.findIndex((p) => p.name === key);
    if (idx >= 0) presets[idx] = next;
    else presets.push(next);
    saveCategoryPresets(presets);
  }

  function applyCategoryPreset(param, name) {
    const presets = loadCategoryPresets();
    const preset = presets.find((p) => p.name === name);
    const ids = Array.isArray(preset?.ids) ? preset.ids : [];
    const picked = [];
    const idSet = new Set(ids.map((id) => Number(id)));
    collectBindable(state.categoryTree, picked);
    param.settings.categories = picked
      .filter((cat) => idSet.has(Number(cat.idInt)))
      .map((cat) => ({ idInt: cat.idInt, name: cat.name, path: cat.path }));
  }

  function deleteCategoryPreset(name) {
    const key = String(name || '').trim();
    if (!key) return;
    const presets = loadCategoryPresets();
    saveCategoryPresets(presets.filter((p) => p.name !== key));
  }

  function sectionHeader(title, buttons) {
    const wrap = div('section-header');
    const h = document.createElement('h3');
    h.textContent = title;
    wrap.append(h);
    if (Array.isArray(buttons) && buttons.length) {
      const actions = div('section-actions');
      buttons.forEach(btn => actions.append(btn));
      wrap.append(actions);
    }
    return wrap;
  }

  function subTitle(text) {
    const el = document.createElement('div');
    el.className = 'sharedparambatch-subtitle';
    el.textContent = text;
    return el;
  }

  function summaryBadge(label, value) {
    const wrap = div('sharedparambatch-badge');
    const span = document.createElement('span');
    span.textContent = label;
    const val = document.createElement('strong');
    val.textContent = value;
    wrap.append(span, val);
    return { wrap, value: val };
  }

  function cardBtn(text, onClick, extraClass = '') {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `btn ${extraClass}`.trim();
    btn.textContent = text;
    if (typeof onClick === 'function') btn.addEventListener('click', onClick);
    return btn;
  }

  function actionBtn(text, onClick, extraClass = '') {
    return cardBtn(text, onClick, `btn--small ${extraClass}`.trim());
  }

  function tdText(value) {
    const td = document.createElement('td');
    td.textContent = value == null ? '' : String(value);
    return td;
  }

  function tdCategorySummary(categories) {
    const td = document.createElement('td');
    const list = Array.isArray(categories) ? categories : [];
    td.className = list.length ? 'spb-category-summary-cell' : 'spb-category-summary-cell is-missing';
    if (!list.length) {
      td.textContent = '미지정';
      return td;
    }
    const labels = list.map((item) => item?.name || item?.path || '').filter(Boolean);
    const preview = labels.slice(0, 2).join(', ');
    td.textContent = labels.length > 2 ? `${preview} 외 ${labels.length - 2}개` : (preview || `${list.length}개`);
    td.title = labels.join('\n');
    return td;
  }

  function labelSpan(text) {
    const span = document.createElement('span');
    span.className = 'sharedparambatch-label';
    span.textContent = text;
    return span;
  }

  function radio(name, label, checked, onChange) {
    const wrap = div('sharedparambatch-radio');
    const input = document.createElement('input');
    input.type = 'radio';
    input.name = name;
    input.checked = checked;
    const span = document.createElement('span');
    span.textContent = label;
    input.addEventListener('change', () => { if (input.checked && onChange) onChange(true); });
    wrap.append(input, span);
    return { wrap, input };
  }

  function getSharedParamBatchActiveDocumentInfo() {
    const topbar = getTopbarState?.() || {};
    const active = topbar.activeDocument || topbar.activeDoc || {};
    const name = active.name || active.title || topbar.activeDocumentName || topbar.documentName || '';
    const title = active.title || active.name || topbar.activeDocumentName || topbar.documentName || '';
    const path = active.path || active.filePath || topbar.activeDocumentPath || topbar.documentPath || '';
    return {
      name,
      title,
      path,
      filePath: active.filePath || active.path || path,
      isLinked: !!(active.isLinked || active.linked || active.isRevitLink || topbar.activeDocumentIsLinked)
    };
  }

  return () => {
    cleanupAutoRefresh();
    preferenceCleanup?.();
    buildRvtModal.registration?.dispose();
  };
}
