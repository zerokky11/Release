// Resources/HubUI/js/core/featureCatalog3.js
import { getFavoriteEntries, getHubEntries, getHubEntryUsage, isHubEntryFavorite } from './hubFavorites.js?v=20260917columnnumber1';

export const FEATURE_GROUPS3 = Object.freeze({
  bqc: {
    id: 'bqc',
    label: 'BQC 검토',
    subtitle: 'RVT를 검토할 기능을 선택합니다.',
    groupLabel: '납품 시 BQC 검토'
  },
  'bqc-results': {
    id: 'bqc-results',
    label: 'BQC 결과 정리',
    subtitle: '이전 회신을 결과 엑셀에 반영하거나 납품할 RVT를 정리합니다.',
    groupLabel: 'BQC 결과 정리'
  },
  utility: {
    id: 'utility',
    label: '일반 도구',
    subtitle: '반복 작업과 운영 도구를 선택합니다.',
    groupLabel: '일반 도구'
  },
  linktools: {
    id: 'linktools',
    label: '링크 도구',
    subtitle: '새 RVT 링크를 추가하거나 기존 링크의 경로, 웍셋과 공유좌표를 관리합니다.',
    groupLabel: '링크 도구'
  },
  modeling: {
    id: 'modeling',
    label: '모델링',
    subtitle: '모델링 자동화 기능을 실행합니다.',
    groupLabel: '모델링'
  },
  schedule: {
    id: 'schedule',
    label: 'Schedule 도구',
    subtitle: '스케줄 데이터와 Excel 교환 작업을 실행합니다.',
    groupLabel: 'Schedule 도구'
  },
  nwc: {
    id: 'nwc',
    label: 'NWC Export',
    subtitle: 'RVT의 3D View를 Navisworks Cache로 일괄 추출합니다.',
    groupLabel: 'NWC Export'
  }
});

const FEATURE_ORDER = Object.freeze([
  'connector',
  'unconnected',
  'reducerpoint',
  'floorinfo',
  'gridlevelconsistency',
  'familysuitability',
  'tapalign',
  'tapdepth',
  'dupclash',
  'worksetassignment',
  'parameterduplication',
  'parametermissing',
  'parameterstandard',
  'utilitymaterial',
  'ghostcleaner',
  'revieworganizer',
  'deliverycleaner',
  'conditionextract',
  'dup',
  'paramprop',
  'parammigration',
  'segmentpms',
  'parammodifier',
  'linkbatch',
  'linkpath',
  'linksharedcoord',
  'cadcircle',
  'columnnumber',
  'terraindrape',
  'lateralnozzle',
  'guid',
  'tapdepthutility',
  'familylink',
  'points',
  'linkworkset',
  'centralworkset',
  'levelchange',
  'acccloud',
  'accbackup',
  'sharedparambatch',
  'scheduleio',
  'nwcexport'
]);

const SELECTABLE_ENTRY_IDS = new Set([
  'connector',
  'unconnected',
  'reducerpoint',
  'floorinfo',
  'gridlevelconsistency',
  'familysuitability',
  'tapalign',
  'tapdepth',
  'dupclash',
  'worksetassignment',
  'parameterduplication',
  'parametermissing',
  'parameterstandard',
  'utilitymaterial',
  'ghostcleaner',
  'tapdepthutility',
  'familylink',
  'points',
  'linkworkset'
]);

const PRESET_ENTRY_IDS = new Set([
  'connector',
  'unconnected',
  'reducerpoint',
  'floorinfo',
  'gridlevelconsistency',
  'familysuitability',
  'tapalign',
  'tapdepth',
  'dupclash',
  'worksetassignment',
  'parameterduplication',
  'parametermissing',
  'parameterstandard',
  'utilitymaterial',
  'ghostcleaner',
  'sharedparambatch'
]);

const SETTING_HINTS = Object.freeze({
  connector: '공통 필터',
  unconnected: '중심축 + 묻힘',
  reducerpoint: 'ECC/CON 자동 비교',
  floorinfo: '영역 필요',
  gridlevelconsistency: '기준 등록',
  familysuitability: '엑셀 필요',
  tapalign: '허용값',
  tapdepth: '허용값',
  dupclash: '단독 설정',
  worksetassignment: '웍셋 기준',
  parameterduplication: '프리셋 가능',
  parametermissing: '프리셋 가능',
  parameterstandard: '기준 엑셀',
  utilitymaterial: '기준 + 파일명 규칙 Excel',
  ghostcleaner: '선택 삭제',
  deliverycleaner: '워크플로우',
  revieworganizer: '1차·2차 엑셀',
  conditionextract: '워크플로우',
  sharedparambatch: '카테고리 프리셋'
});

const STATUS_BY_ENTRY = Object.freeze({
  connector: { tone: 'ok', label: '준비됨' },
  unconnected: { tone: 'ok', label: '준비됨' },
  reducerpoint: { tone: 'ok', label: '자동 기준' },
  floorinfo: { tone: 'warn', label: '영역 필요' },
  gridlevelconsistency: { tone: 'warn', label: '기준 필요' },
  familysuitability: { tone: 'warn', label: '엑셀 필요' },
  tapalign: { tone: 'idle', label: '선택 가능' },
  tapdepth: { tone: 'idle', label: '선택 가능' },
  dupclash: { tone: 'idle', label: '단독 설정' },
  worksetassignment: { tone: 'idle', label: '선택 가능' },
  parameterduplication: { tone: 'idle', label: '프리셋 가능' },
  parametermissing: { tone: 'warn', label: '기준 필요' },
  parameterstandard: { tone: 'warn', label: '기준 엑셀' },
  utilitymaterial: { tone: 'warn', label: '기준 + 규칙' },
  ghostcleaner: { tone: 'idle', label: '선택 가능' },
  deliverycleaner: { tone: 'blue', label: '별도 화면' },
  revieworganizer: { tone: 'blue', label: '엑셀로 실행' },
  conditionextract: { tone: 'blue', label: '별도 화면' },
  sharedparambatch: { tone: 'blue', label: '별도 화면' }
});

export function getFeatureGroup3(mode) {
  return FEATURE_GROUPS3[mode] || FEATURE_GROUPS3.bqc;
}

export function getFeatureCounts3() {
  return {
    bqc: getFeaturesForGroup3('bqc').length,
    'bqc-results': getFeaturesForGroup3('bqc-results').length,
    utility: getFeaturesForGroup3('utility').length,
    linktools: getHubEntries({ groupLabel: '링크 도구' }).length,
    modeling: getFeaturesForGroup3('modeling').length,
    schedule: getFeaturesForGroup3('schedule').length,
    nwc: getFeaturesForGroup3('nwc').length,
    favorites: getFavoriteEntries().length
  };
}

export function getFeaturesForGroup3(mode) {
  const group = getFeatureGroup3(mode);
  return getHubEntries({ groupLabel: group.groupLabel })
    .map((entry) => enrichFeature3(entry, mode))
    .sort(compareFeature3);
}

export function searchFeatures3(mode, query) {
  const text = normalize(query);
  const compact = text.replace(/\s+/g, '');
  const list = getFeaturesForGroup3(mode);
  if (!text) return list;
  return list.filter((entry) => {
    const fields = [entry.label, entry.desc, entry.groupLabel, entry.settingHint]
      .map((value) => normalize(value));
    return fields.some((value) => value.includes(text) || value.replace(/\s+/g, '').includes(compact));
  });
}

export function getFeatureById3(entryId) {
  const all = [
    ...getFeaturesForGroup3('bqc'),
    ...getFeaturesForGroup3('bqc-results'),
    ...getFeaturesForGroup3('utility'),
    ...getFeaturesForGroup3('linktools'),
    ...getFeaturesForGroup3('modeling'),
    ...getFeaturesForGroup3('schedule'),
    ...getFeaturesForGroup3('nwc')
  ];
  if (entryId === 'linkbatch') {
    const entry = getHubEntries().find((item) => item.id === entryId);
    return entry ? enrichFeature3(entry, 'linktools') : null;
  }
  return all.find((entry) => entry.id === entryId) || null;
}

function enrichFeature3(entry, mode) {
  const usage = getHubEntryUsage(entry.id);
  const featureKey = String(entry.featureKey || entry.id || '').trim();
  const selectable = SELECTABLE_ENTRY_IDS.has(entry.id) || (entry.route === 'multi' && !!entry.multiMode);
  const direct = !selectable;
  const status = STATUS_BY_ENTRY[entry.id] || (selectable
    ? { tone: 'idle', label: '선택 가능' }
    : { tone: 'blue', label: '별도 화면' });
  return {
    ...entry,
    featureKey,
    mode,
    uiType: selectable ? 'selectable' : (direct ? 'direct' : 'hybrid'),
    workflowGroup: selectable ? 'batch' : 'standalone',
    selectable,
    direct,
    supportsPreset: PRESET_ENTRY_IDS.has(entry.id) || selectable,
    settingHint: SETTING_HINTS[entry.id] || '',
    statusTone: status.tone,
    statusLabel: status.label,
    favorite: isHubEntryFavorite(entry.id),
    usageCount: usage.count,
    lastUsedAt: usage.lastUsedAt
  };
}

function compareFeature3(left, right) {
  const a = FEATURE_ORDER.indexOf(left?.id);
  const b = FEATURE_ORDER.indexOf(right?.id);
  const rankA = a >= 0 ? a : FEATURE_ORDER.length;
  const rankB = b >= 0 ? b : FEATURE_ORDER.length;
  if (rankA !== rankB) return rankA - rankB;
  return String(left?.label || '').localeCompare(String(right?.label || ''), 'ko');
}

function normalize(value) {
  return String(value || '').toLowerCase().trim();
}
