import { toast } from './dom.js';

const STORAGE_KEY = 'kky.hub.quickAccess.v1';
const PENDING_KEY = 'kky.hub.quickAccess.pending';
const MULTI_MODE_KEY = 'kky.hub.multiMode';
const PANEL_SEARCH_KEY = 'kky.hub.panelSearch.v1';
export const HUB_QUICK_ACCESS_CHANGE_EVENT = 'hub:quickaccess-changed';

const BQC_GROUP_LABEL = '납품 시 BQC 검토';
const BQC_RESULTS_GROUP_LABEL = 'BQC 결과 정리';
const UTILITY_GROUP_LABEL = '일반 도구';
const LINK_GROUP_LABEL = '링크 도구';
const SCHEDULE_GROUP_LABEL = 'Schedule 도구';
const MODELING_GROUP_LABEL = '모델링';
const NWC_GROUP_LABEL = 'NWC Export';
const LEGACY_HUB_ENTRY_ALIASES = Object.freeze({
  worksetmanager: 'centralworkset'
});

const HUB_ENTRY_CATALOG = Object.freeze({
  connector: {
    id: 'connector',
    label: '파라미터 연속성 검토',
    desc: '연결된 MEP 객체 사이의 파라미터 연속성을 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  unconnected: {
    id: 'unconnected',
    label: '미연결 검토',
    desc: '커넥터가 있는 객체의 미연결 상태와 중심축 연결 상태를 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  reducerpoint: {
    id: 'reducerpoint',
    label: 'Reducer Point 정합성 검토',
    desc: 'Reducer 타입명과 Point 파라미터의 ECC/CON 표기가 일치하는지 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  floorinfo: {
    id: 'floorinfo',
    label: '레벨 영역별 파라미터 검토',
    desc: '선택한 레벨 영역을 기준으로 파라미터 일치 여부를 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  gridlevelconsistency: {
    id: 'gridlevelconsistency',
    label: 'Grid / Level 기준 정합성 검토',
    desc: '기준 RVT 또는 Level 기준 Excel과 비교해 Grid 위치·방향과 Level 이름·높이의 정합성을 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  familysuitability: {
    id: 'familysuitability',
    label: '패밀리 타입 적합성 검토',
    desc: '기준 엑셀의 카테고리/패밀리/타입 조합으로 실제 사용 타입의 적합성을 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  tapalign: {
    id: 'tapalign',
    label: '탭/분기 축 틀어짐 검토',
    desc: '탭/분기 피팅 축이 연결된 배관 또는 덕트 중심축에서 벗어났는지 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  tapdepth: {
    id: 'tapdepth',
    label: 'Tap, Saddle 모델링 검토 (묻힘)',
    desc: '실제 묻힘 깊이를 Takeoff Length Projection / Takeoff Length 기준과 비교합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  dupclash: {
    id: 'dupclash',
    label: '중복 / 자체 간섭 검토',
    desc: '여러 RVT를 대상으로 중복 검토 또는 자체 간섭 검토를 선택해 배치 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  worksetassignment: {
    id: 'worksetassignment',
    label: '웍셋 배정 검토',
    desc: '입력한 정상 웍셋 목록 밖에 배정된 모델 객체를 오류로 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  parameterduplication: {
    id: 'parameterduplication',
    label: '프로젝트 파라미터 중복 검토',
    desc: '추가된 프로젝트 파라미터 중 이름이 중복된 항목을 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  parametermissing: {
    id: 'parametermissing',
    label: '파라미터 누락 검토',
    desc: '공유파라미터의 누락 여부를 공통 대상 필터와 예외 규칙 기준으로 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  parameterstandard: {
    id: 'parameterstandard',
    label: '속성 기준값 검토',
    desc: '기준 엑셀의 속성 기준값과 모델 객체 값을 비교해 불일치 항목을 검토합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  utilitymaterial: {
    id: 'utilitymaterial',
    label: 'UTILITY 기반 재질 오류 검토',
    desc: '프로젝트·분야·동별 Utility/재질 기준과 지정 Category 객체의 S5_UTILITY·S5_MATERIAL 값을 비교합니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  ghostcleaner: {
    id: 'ghostcleaner',
    label: '유령객체 제거',
    desc: '다른 BQC 검토 전에 호스트나 Run 참조가 끊긴 모델 객체를 정리하고 전후 객체 수와 삭제 내역을 Excel로 남깁니다.',
    route: 'multi',
    multiMode: 'bqc',
    groupLabel: BQC_GROUP_LABEL
  },
  deliverycleaner: {
    id: 'deliverycleaner',
    label: 'RVT 정리 (납품용)',
    desc: '납품 파일 작성을 위한 뷰 정리, 불필요 항목 제거(Purge), 검토용 속성 추출을 진행합니다.',
    route: 'deliverycleaner',
    groupLabel: BQC_RESULTS_GROUP_LABEL
  },
  revieworganizer: {
    id: 'revieworganizer',
    label: '다회차 엑셀 결과 정리',
    desc: '1차 회신과 2차 결과 엑셀을 연결해 이전 코멘트와 인정된 예외를 반영하고 전달할 오류 수량을 정리합니다.',
    route: 'revieworganizer',
    groupLabel: BQC_RESULTS_GROUP_LABEL
  },
  conditionextract: {
    id: 'conditionextract',
    label: '조건별 객체 대상 속성 추출',
    desc: '조건식으로 객체를 추려 지정 속성, 좌표, 선형 정보를 함께 추출합니다.',
    route: 'conditionextract',
    groupLabel: BQC_GROUP_LABEL
  },
  dup: {
    id: 'dup',
    label: '중복 / 자체 간섭 검토',
    desc: '활성 문서에서 중복 객체 또는 자체 간섭을 검토합니다.',
    route: 'dup',
    groupLabel: UTILITY_GROUP_LABEL
  },
  paramprop: {
    id: 'paramprop',
    label: '패밀리 공유파라미터 추가/연동',
    desc: '복합 및 하위 패밀리에 지정한 파라미터를 추가하고 연동합니다.',
    route: 'paramprop',
    groupLabel: UTILITY_GROUP_LABEL
  },
  parammigration: {
    id: 'parammigration',
    label: '공유파라미터 통합 변경',
    desc: '프로젝트와 패밀리의 기존 정의·값을 신규 공유파라미터로 옮기고 체크포인트부터 이어서 진행합니다.',
    route: 'parammigration',
    groupLabel: UTILITY_GROUP_LABEL
  },
  segmentpms: {
    id: 'segmentpms',
    label: 'Segment-PMS 비교 검토',
    desc: 'PMS 양식을 입력받아 Segment와 OD, ID 값을 비교 검토합니다.',
    route: 'segmentpms',
    groupLabel: UTILITY_GROUP_LABEL
  },
  parammodifier: {
    id: 'parammodifier',
    label: '파라미터 수정기',
    desc: '입력 조건 기반 필터링 대상의 지정 파라미터에 값을 일괄 입력합니다.',
    route: 'parammodifier',
    groupLabel: UTILITY_GROUP_LABEL
  },
  linkbatch: {
    id: 'linkbatch',
    label: '링크 매니저',
    desc: '선택한 RVT를 활성 문서 또는 Excel에 지정한 여러 RVT에 링크하고 타입·인스턴스 웍셋을 지정합니다.',
    route: 'linkbatch',
    groupLabel: LINK_GROUP_LABEL
  },
  linkpath: {
    id: 'linkpath',
    label: 'Revit 링크 경로 추출/재지정',
    desc: '열린 RVT의 Revit 링크 경로를 추출하고 엑셀 기준으로 대상 경로를 반영합니다.',
    route: 'linkpath',
    groupLabel: LINK_GROUP_LABEL
  },
  linksharedcoord: {
    id: 'linksharedcoord',
    label: 'Link 파일 Shared Coordination 검토/설정',
    desc: '활성 호스트의 링크를 A × 1 교차점과 기준 Level로 분석하고 Shared Site 배치와 Publish를 검토·설정합니다.',
    route: 'linksharedcoord',
    groupLabel: LINK_GROUP_LABEL
  },
  cadcircle: {
    id: 'cadcircle',
    label: 'CAD link 기반 Foreline 모델링',
    desc: '링크 CAD의 원형 중심과 지름을 검출해 선택한 레벨에 패밀리를 배치하고 파라미터를 입력합니다.',
    route: 'cadcircle',
    groupLabel: MODELING_GROUP_LABEL
  },
  columnnumber: {
    id: 'columnnumber',
    label: '기둥 넘버',
    desc: '링크 기둥 중심에 넘버 패밀리를 배치하고 기존 배치의 누락·중복·번호를 검토합니다.',
    route: 'columnnumber',
    groupLabel: MODELING_GROUP_LABEL
  },
  terraindrape: {
    id: 'terraindrape',
    label: '지형 연동 (TEST)',
    desc: '본체 대지 → 보완 지형 → 도로 바닥을 연결하고, 지형 편집 완료 후 연쇄 갱신합니다.',
    route: 'terraindrape',
    groupLabel: MODELING_GROUP_LABEL
  },
  lateralnozzle: {
    id: 'lateralnozzle',
    label: 'Nozzle Code, KTA, 모델링 검토',
    desc: 'KTA 엑셀을 단일화하거나 여러 RVT에서 Nozzle 객체의 Utility, Lateral, Nozzle Code와 좌표를 추출합니다.',
    route: 'lateralnozzle',
    groupLabel: UTILITY_GROUP_LABEL
  },
  guid: {
    id: 'guid',
    label: '파라미터 GUID 검토 및 정리',
    desc: '프로젝트와 패밀리 파라미터 GUID를 검토하고 정리 기준으로 정리합니다.',
    route: 'guid',
    groupLabel: UTILITY_GROUP_LABEL
  },
  tapdepthutility: {
    id: 'tapdepthutility',
    featureKey: 'tapdepth',
    label: 'Tap, Saddle 모델링 검토 (묻힘)',
    desc: '활성/선택 RVT에서 Tap/Saddle 묻힘 깊이를 두 Takeoff Length 기준으로 검토합니다.',
    route: 'multi',
    multiMode: 'utility',
    groupLabel: UTILITY_GROUP_LABEL
  },
  familylink: {
    id: 'familylink',
    label: '패밀리 공유파라미터 연동 검토',
    desc: '복합 패밀리를 대상으로 하위 패밀리와의 파라미터 연동 여부를 검토합니다.',
    route: 'multi',
    multiMode: 'utility',
    groupLabel: UTILITY_GROUP_LABEL
  },
  points: {
    id: 'points',
    label: '기준점/북각 추출',
    desc: 'RVT의 프로젝트 기준점, 측량 기준점, 내부 원점, 북각 값을 추출합니다.',
    route: 'multi',
    multiMode: 'utility',
    groupLabel: UTILITY_GROUP_LABEL
  },
  linkworkset: {
    id: 'linkworkset',
    label: '링크 기본 웍셋 점검/적용',
    desc: '링크별 로드 상태와 열려 있는 웍셋 현황을 확인하고 기본 웍셋(Workset1)만 열리도록 재적용합니다.',
    route: 'linkworkset',
    multiMode: 'utility',
    groupLabel: LINK_GROUP_LABEL
  },
  centralworkset: {
    id: 'centralworkset',
    label: '센트럴 파일생성, 웍셋 추가 Grid/Level, 3D 뷰 권한 적용',
    desc: '활성 문서 또는 여러 RVT를 새 센트럴로 만들거나 기존 센트럴에 웍셋을 추가하고 Grid/Level 및 지정 3D 뷰 권한을 적용합니다.',
    route: 'centralworkset',
    groupLabel: UTILITY_GROUP_LABEL
  },
  levelchange: {
    id: 'levelchange',
    label: '프로젝트 파일 내 Level 변경',
    desc: 'Excel 지시대로 여러 RVT의 Level을 이동하고 영향 객체·Revit 오류·동기화 결과를 파일별로 추출합니다.',
    route: 'levelchange',
    groupLabel: UTILITY_GROUP_LABEL
  },
  acccloud: {
    id: 'acccloud',
    label: 'ACC 클라우드 모델 생성 (TEST)',
    desc: '파일 RVT를 새 ACC/Autodesk Docs Cloud Workshared 모델로 생성하는 테스트 기능입니다. Revit 2023/2025/2027을 지원합니다.',
    route: 'acccloud',
    groupLabel: UTILITY_GROUP_LABEL
  },
  accbackup: {
    id: 'accbackup',
    label: 'ACC 백업 (TEST)',
    desc: 'LAN file-based central의 성공 SWC 후 닫힌 local snapshot을 ACC 일반 RVT Item의 새 Version으로 테스트 백업합니다. RCW 모델 병합은 하지 않습니다.',
    route: 'accbackup',
    groupLabel: UTILITY_GROUP_LABEL
  },
  sharedparambatch: {
    id: 'sharedparambatch',
    label: '프로젝트 파라미터 일괄 추가',
    desc: '프로젝트 파일에 지정한 파라미터를 일괄 추가합니다.',
    route: 'sharedparambatch',
    groupLabel: UTILITY_GROUP_LABEL
  },
  scheduleio: {
    id: 'scheduleio',
    label: 'Schedule Excel Import / Export',
    desc: '스케줄 기준 객체 데이터를 활성 문서 또는 여러 RVT에서 Excel로 교환합니다.',
    route: 'scheduleio',
    groupLabel: SCHEDULE_GROUP_LABEL
  },
  nwcexport: {
    id: 'nwcexport',
    label: '3D View NWC Export',
    desc: '활성 문서 또는 여러 RVT의 3D View를 선택해 링크를 새로 고친 뒤 NWC로 일괄 추출합니다.',
    route: 'nwcexport',
    groupLabel: NWC_GROUP_LABEL
  }
});

const boundEntries = new Set();
export const HUB_FAVORITE_SET_COUNT = 10;
const DEFAULT_FAVORITE_SET_ID = 'set-1';
let memoryState = createState();
let memoryPending = null;
let memoryPanelSearch = createPanelSearchState();
let contextMenuEl = null;
let contextMenuCleanup = null;

function createState() {
  return {
    favorites: [],
    favoriteSets: createDefaultFavoriteSets(),
    activeFavoriteSetId: DEFAULT_FAVORITE_SET_ID,
    usage: {}
  };
}

function createDefaultFavoriteSets() {
  return Array.from({ length: HUB_FAVORITE_SET_COUNT }, (_, index) => ({
    id: `set-${index + 1}`,
    name: `세트 ${index + 1}`,
    entryIds: []
  }));
}

function normalizeFavoriteSetName(value, index) {
  const fallback = `세트 ${index + 1}`;
  const name = String(value || '').replace(/\s+/g, ' ').trim();
  return (name || fallback).slice(0, 30);
}

function findFavoriteSet(state, setId) {
  const id = String(setId || '').trim();
  return state?.favoriteSets?.find((item) => item.id === id) || null;
}

function getAllFavoriteEntryIds(state) {
  return normalizeFavoriteEntryIds(
    (state?.favoriteSets || []).flatMap((item) => item.entryIds || [])
  );
}

function createPanelSearchState() {
  return {
    bqc: { query: '', entryId: '' },
    'bqc-results': { query: '', entryId: '' },
    utility: { query: '', entryId: '' },
    linktools: { query: '', entryId: '' },
    modeling: { query: '', entryId: '' }
  };
}

function normalizeFavoriteEntryIds(entryIds) {
  const list = Array.isArray(entryIds) ? entryIds : [];
  return Array.from(new Set(
    list
      .map(normalizeHubEntryId)
      .filter((id) => HUB_ENTRY_CATALOG[id])
  ));
}

function normalizeHubEntryId(value) {
  const id = String(value || '').trim();
  return LEGACY_HUB_ENTRY_ALIASES[id] || id;
}

function isSameFavoriteList(left, right) {
  const a = normalizeFavoriteEntryIds(left);
  const b = normalizeFavoriteEntryIds(right);
  if (a.length !== b.length) return false;
  return a.every((id, index) => id === b[index]);
}

function normalizeState(raw) {
  const next = createState();
  const legacyFavorites = normalizeFavoriteEntryIds(raw?.favorites);
  const sourceSets = Array.isArray(raw?.favoriteSets) ? raw.favoriteSets : [];
  const hasStoredSets = sourceSets.length > 0;

  next.favoriteSets = next.favoriteSets.map((fallback, index) => {
    const source = sourceSets.find((item) => String(item?.id || '') === fallback.id) || sourceSets[index];
    const entryIds = source
      ? normalizeFavoriteEntryIds(source.entryIds || source.favorites)
      : (!hasStoredSets && index === 0 ? legacyFavorites : []);
    return {
      id: fallback.id,
      name: normalizeFavoriteSetName(source?.name, index),
      entryIds
    };
  });

  const requestedActiveId = String(raw?.activeFavoriteSetId || '').trim();
  next.activeFavoriteSetId = findFavoriteSet(next, requestedActiveId)?.id || DEFAULT_FAVORITE_SET_ID;
  next.favorites = (findFavoriteSet(next, next.activeFavoriteSetId)?.entryIds || []).slice();

  const usage = raw && typeof raw.usage === 'object' ? raw.usage : {};
  Object.keys(usage).forEach((id) => {
    const normalizedId = normalizeHubEntryId(id);
    if (!HUB_ENTRY_CATALOG[normalizedId]) return;
    const item = usage[id] || {};
    const count = Math.max(0, Number(item.count) || 0);
    const lastUsedAt = Math.max(0, Number(item.lastUsedAt) || 0);
    if (count > 0 || lastUsedAt > 0) {
      const previous = next.usage[normalizedId] || {};
      next.usage[normalizedId] = {
        count: Math.max(0, Number(previous.count) || 0) + count,
        lastUsedAt: Math.max(Math.max(0, Number(previous.lastUsedAt) || 0), lastUsedAt)
      };
    }
  });

  return next;
}

function readState() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    memoryState = normalizeState(raw);
    if (raw) {
      const normalizedJson = JSON.stringify(memoryState);
      if (JSON.stringify(raw) !== normalizedJson) {
        localStorage.setItem(STORAGE_KEY, normalizedJson);
      }
    }
  } catch {
    // Use in-memory fallback when localStorage is unavailable.
  }
  return memoryState;
}

function writeState(next) {
  memoryState = normalizeState(next);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(memoryState));
  } catch {
    // Keep in-memory state only.
  }
  return memoryState;
}

function normalizePending(raw) {
  if (!raw || !HUB_ENTRY_CATALOG[raw.entryId]) return null;
  const createdAt = Math.max(0, Number(raw.createdAt) || Date.now());
  if (Date.now() - createdAt > 5 * 60 * 1000) return null;
  return {
    entryId: raw.entryId,
    route: String(raw.route || ''),
    createdAt
  };
}

function readPending() {
  try {
    const raw = JSON.parse(localStorage.getItem(PENDING_KEY) || 'null');
    memoryPending = normalizePending(raw);
    if (!memoryPending) localStorage.removeItem(PENDING_KEY);
  } catch {
    memoryPending = normalizePending(memoryPending);
  }
  return memoryPending;
}

function writePending(next) {
  memoryPending = normalizePending(next);
  try {
    if (memoryPending) localStorage.setItem(PENDING_KEY, JSON.stringify(memoryPending));
    else localStorage.removeItem(PENDING_KEY);
  } catch {
    // Keep in-memory fallback only.
  }
}

function normalizePanelSearchMode(mode) {
  if (mode === 'bqc-results') return 'bqc-results';
  if (mode === 'modeling') return 'modeling';
  if (mode === 'linktools') return 'linktools';
  return mode === 'utility' ? 'utility' : 'bqc';
}

function normalizePanelSearchState(raw) {
  const next = createPanelSearchState();
  ['bqc', 'bqc-results', 'utility', 'linktools', 'modeling'].forEach((mode) => {
    const item = raw && typeof raw === 'object' ? raw[mode] : null;
    const query = String(item?.query || '').trim();
    const entryId = HUB_ENTRY_CATALOG[item?.entryId] ? String(item.entryId) : '';
    next[mode] = {
      query,
      entryId
    };
  });
  return next;
}

function readPanelSearchState() {
  try {
    const raw = JSON.parse(localStorage.getItem(PANEL_SEARCH_KEY) || 'null');
    memoryPanelSearch = normalizePanelSearchState(raw);
  } catch {
    memoryPanelSearch = normalizePanelSearchState(memoryPanelSearch);
  }
  return memoryPanelSearch;
}

function writePanelSearchState(next) {
  memoryPanelSearch = normalizePanelSearchState(next);
  try {
    localStorage.setItem(PANEL_SEARCH_KEY, JSON.stringify(memoryPanelSearch));
  } catch {
    // Keep in-memory fallback only.
  }
  return memoryPanelSearch;
}

function emitChange() {
  syncHubEntryBindings();
  try {
    window.dispatchEvent(new CustomEvent(HUB_QUICK_ACCESS_CHANGE_EVENT));
  } catch {
    // Ignore custom event failures in embedded hosts.
  }
}

window.addEventListener('kky:shared-settings-changed', (event) => {
  const keys = Array.isArray(event?.detail?.keys) ? event.detail.keys : [];
  if (!keys.includes(STORAGE_KEY) && !keys.includes(PANEL_SEARCH_KEY)) return;
  readState();
  readPanelSearchState();
  emitChange();
});

function compareQuickAccess(a, b) {
  if (a.favorite !== b.favorite) return a.favorite ? -1 : 1;
  if (a.count !== b.count) return b.count - a.count;
  if (a.lastUsedAt !== b.lastUsedAt) return b.lastUsedAt - a.lastUsedAt;
  return a.label.localeCompare(b.label, 'ko');
}

function setMultiMode(mode) {
  try {
    localStorage.setItem(MULTI_MODE_KEY, mode);
  } catch {
    // Ignore localStorage failures in embedded hosts.
  }
}

function navigateToRoute(route) {
  const target = String(route || '').replace(/^#/, '');
  if (!target) return;

  const current = (location.hash || '').replace('#', '');
  if (current === target) {
    window.dispatchEvent(new Event('hashchange'));
    return;
  }

  location.hash = `#${target}`;
  window.setTimeout(() => {
    if ((location.hash || '').replace('#', '') === target) {
      window.dispatchEvent(new Event('hashchange'));
    }
  }, 0);
}

function cleanupDisconnectedBindings() {
  for (const binding of Array.from(boundEntries)) {
    if (!binding.element || !binding.element.isConnected) {
      boundEntries.delete(binding);
    }
  }
}

function syncBinding(binding) {
  if (!binding?.element || !binding.entryId) return;
  binding.element.classList.add('hub-entry');
  binding.element.dataset.entryId = binding.entryId;
  if (isHubEntryFavorite(binding.entryId, { anySet: true })) binding.element.dataset.favorite = 'true';
  else delete binding.element.dataset.favorite;
}

function hideContextMenu() {
  if (typeof contextMenuCleanup === 'function') {
    contextMenuCleanup();
  }
  contextMenuCleanup = null;

  if (contextMenuEl) {
    contextMenuEl.remove();
    contextMenuEl = null;
  }
}

function placeContextMenu(menu, x, y) {
  const pad = 12;
  const rect = menu.getBoundingClientRect();
  const left = Math.max(pad, Math.min(x, window.innerWidth - rect.width - pad));
  const top = Math.max(pad, Math.min(y, window.innerHeight - rect.height - pad));
  menu.style.left = `${left}px`;
  menu.style.top = `${top}px`;
}

function showContextMenu(x, y, entryId) {
  const entry = getHubEntry(entryId);
  if (!entry) return;

  hideContextMenu();

  const activeSet = getActiveFavoriteSet();
  const favorite = isHubEntryFavorite(entryId, { setId: activeSet.id });
  const menu = document.createElement('div');
  menu.className = 'hub-context-menu';

  const meta = document.createElement('div');
  meta.className = 'hub-context-menu__meta';
  meta.textContent = entry.label;

  const action = document.createElement('button');
  action.type = 'button';
  action.className = 'hub-context-menu__action';
  action.textContent = favorite ? `'${activeSet.name}'에서 제거` : `'${activeSet.name}'에 추가`;
  action.addEventListener('click', () => {
    setHubEntryFavorite(entryId, !favorite, { setId: activeSet.id });
    hideContextMenu();
  });

  menu.append(meta, action);
  document.body.append(menu);
  placeContextMenu(menu, x, y);
  contextMenuEl = menu;

  const closeOnPointer = (ev) => {
    if (contextMenuEl && contextMenuEl.contains(ev.target)) return;
    hideContextMenu();
  };
  const closeOnKey = (ev) => {
    if (ev.key === 'Escape') hideContextMenu();
  };

  document.addEventListener('mousedown', closeOnPointer, true);
  document.addEventListener('contextmenu', closeOnPointer, true);
  document.addEventListener('keydown', closeOnKey, true);
  window.addEventListener('resize', hideContextMenu);
  window.addEventListener('blur', hideContextMenu);
  window.addEventListener('scroll', hideContextMenu, true);
  window.addEventListener('hashchange', hideContextMenu);

  contextMenuCleanup = () => {
    document.removeEventListener('mousedown', closeOnPointer, true);
    document.removeEventListener('contextmenu', closeOnPointer, true);
    document.removeEventListener('keydown', closeOnKey, true);
    window.removeEventListener('resize', hideContextMenu);
    window.removeEventListener('blur', hideContextMenu);
    window.removeEventListener('scroll', hideContextMenu, true);
    window.removeEventListener('hashchange', hideContextMenu);
  };
}

export function getHubEntry(entryId) {
  return HUB_ENTRY_CATALOG[entryId] || null;
}

export function getHubEntries(options = {}) {
  const groupLabel = String(options?.groupLabel || '').trim();
  const multiMode = String(options?.multiMode || '').trim();
  return Object.values(HUB_ENTRY_CATALOG)
    .filter((entry) => !groupLabel || entry.groupLabel === groupLabel)
    .filter((entry) => !multiMode || entry.multiMode === multiMode)
    .map((entry) => ({ ...entry }));
}

export function getFavoriteSets() {
  const state = readState();
  return state.favoriteSets.map((item) => ({
    id: item.id,
    name: item.name,
    entryIds: item.entryIds.slice(),
    count: item.entryIds.length,
    isActive: item.id === state.activeFavoriteSetId
  }));
}

export function getActiveFavoriteSet() {
  const state = readState();
  const item = findFavoriteSet(state, state.activeFavoriteSetId) || state.favoriteSets[0];
  return {
    id: item.id,
    name: item.name,
    entryIds: item.entryIds.slice(),
    count: item.entryIds.length,
    isActive: true
  };
}

export function setActiveFavoriteSet(setId, options = {}) {
  const current = readState();
  const target = findFavoriteSet(current, setId);
  if (!target) return getActiveFavoriteSet();
  if (target.id === current.activeFavoriteSetId) return getActiveFavoriteSet();

  writeState({
    ...current,
    activeFavoriteSetId: target.id
  });
  emitChange();
  if (options?.toast !== false) toast(`즐겨찾기 '${target.name}'을 열었습니다.`, 'info');
  return getActiveFavoriteSet();
}

export function renameFavoriteSet(setId, nextName, options = {}) {
  const current = readState();
  const index = current.favoriteSets.findIndex((item) => item.id === String(setId || ''));
  if (index < 0) return null;
  const name = normalizeFavoriteSetName(nextName, index);
  if (current.favoriteSets[index].name === name) return { ...current.favoriteSets[index] };

  const favoriteSets = current.favoriteSets.map((item, itemIndex) => (
    itemIndex === index ? { ...item, name } : item
  ));
  writeState({ ...current, favoriteSets });
  emitChange();
  if (options?.toast !== false) toast(`즐겨찾기 세트 이름을 '${name}'으로 변경했습니다.`, 'ok');
  return { ...favoriteSets[index], entryIds: favoriteSets[index].entryIds.slice() };
}

export function getFavoriteSetIdsForEntry(entryId) {
  if (!getHubEntry(entryId)) return [];
  return readState().favoriteSets
    .filter((item) => item.entryIds.includes(entryId))
    .map((item) => item.id);
}

export function isHubEntryFavorite(entryId, options = {}) {
  const state = readState();
  const requestedSet = String(options?.setId || '').trim();
  if (requestedSet) return !!findFavoriteSet(state, requestedSet)?.entryIds.includes(entryId);
  if (options?.anySet === false) return state.favorites.includes(entryId);
  return getAllFavoriteEntryIds(state).includes(entryId);
}

export function getHubEntryUsage(entryId) {
  const usage = readState().usage[entryId] || {};
  return {
    count: Math.max(0, Number(usage.count) || 0),
    lastUsedAt: Math.max(0, Number(usage.lastUsedAt) || 0)
  };
}

export function setHubEntryFavorite(entryId, nextFavorite, options = {}) {
  const entry = getHubEntry(entryId);
  if (!entry) return false;

  const current = readState();
  const target = findFavoriteSet(current, options?.setId || current.activeFavoriteSetId);
  if (!target) return false;
  const favorites = new Set(target.entryIds);
  const shouldFavorite = typeof nextFavorite === 'boolean' ? nextFavorite : !favorites.has(entryId);

  if (shouldFavorite) favorites.add(entryId);
  else favorites.delete(entryId);

  writeState({
    ...current,
    favoriteSets: current.favoriteSets.map((item) => (
      item.id === target.id ? { ...item, entryIds: Array.from(favorites) } : item
    ))
  });
  emitChange();

  if (options?.toast !== false) {
    toast(
      shouldFavorite
        ? `'${entry.label}' 기능을 '${target.name}'에 추가했습니다.`
        : `'${entry.label}' 기능을 '${target.name}'에서 제거했습니다.`,
      shouldFavorite ? 'ok' : 'info'
    );
  }

  return shouldFavorite;
}

export function setHubEntryFavoriteSets(entryId, setIds, options = {}) {
  const entry = getHubEntry(entryId);
  if (!entry) return [];
  const current = readState();
  const validIds = new Set(current.favoriteSets.map((item) => item.id));
  const nextIds = new Set(
    (Array.isArray(setIds) ? setIds : [])
      .map((id) => String(id || '').trim())
      .filter((id) => validIds.has(id))
  );
  const previousIds = new Set(getFavoriteSetIdsForEntry(entryId));
  const unchanged = previousIds.size === nextIds.size
    && Array.from(previousIds).every((id) => nextIds.has(id));
  if (unchanged) return Array.from(nextIds);

  const favoriteSets = current.favoriteSets.map((item) => {
    const entries = new Set(item.entryIds);
    if (nextIds.has(item.id)) entries.add(entryId);
    else entries.delete(entryId);
    return { ...item, entryIds: Array.from(entries) };
  });
  writeState({ ...current, favoriteSets });
  emitChange();
  if (options?.toast !== false) {
    toast(
      nextIds.size
        ? `'${entry.label}' 기능을 즐겨찾기 세트 ${nextIds.size}곳에 저장했습니다.`
        : `'${entry.label}' 기능을 모든 즐겨찾기 세트에서 제거했습니다.`,
      nextIds.size ? 'ok' : 'info'
    );
  }
  return Array.from(nextIds);
}

export function replaceHubFavorites(entryIds, options = {}) {
  const current = readState();
  const target = findFavoriteSet(current, options?.setId || current.activeFavoriteSetId);
  if (!target) return [];
  const favorites = normalizeFavoriteEntryIds(entryIds);
  if (isSameFavoriteList(target.entryIds, favorites)) {
    return favorites.slice();
  }

  writeState({
    ...current,
    favoriteSets: current.favoriteSets.map((item) => (
      item.id === target.id ? { ...item, entryIds: favorites } : item
    ))
  });
  emitChange();

  if (options?.toast !== false) {
    const sourceLabel = String(options?.sourceLabel || '').trim();
    const prefix = sourceLabel ? `${sourceLabel}에서 ` : '';
    toast(
      favorites.length
        ? `${prefix}'${target.name}'에 기능 ${favorites.length}개를 복원했습니다.`
        : `${prefix}'${target.name}'이 비어 있습니다.`,
      favorites.length ? 'ok' : 'info'
    );
  }

  return favorites.slice();
}

export function recordHubEntryUse(entryId) {
  const entry = getHubEntry(entryId);
  if (!entry) return;

  const current = readState();
  const usage = { ...(current.usage || {}) };
  const prev = usage[entryId] || { count: 0, lastUsedAt: 0 };
  usage[entryId] = {
    count: Math.max(0, Number(prev.count) || 0) + 1,
    lastUsedAt: Date.now()
  };

  writeState({
    ...current,
    usage
  });
  emitChange();
}

export function getHubQuickAccessEntries(limit = 6) {
  const state = readState();
  const allFavorites = new Set(getAllFavoriteEntryIds(state));
  const items = Object.values(HUB_ENTRY_CATALOG)
    .map((entry) => {
      const usage = state.usage[entry.id] || {};
      return {
        ...entry,
        favorite: allFavorites.has(entry.id),
        count: Math.max(0, Number(usage.count) || 0),
        lastUsedAt: Math.max(0, Number(usage.lastUsedAt) || 0)
      };
    })
    .filter((entry) => entry.favorite || entry.count > 0)
    .sort(compareQuickAccess);

  return typeof limit === 'number' && limit > 0 ? items.slice(0, limit) : items;
}

export function getFavoriteEntries(limit = 0) {
  const state = readState();
  const activeSet = findFavoriteSet(state, state.activeFavoriteSetId) || state.favoriteSets[0];
  const items = activeSet.entryIds
    .map((id) => {
      const entry = HUB_ENTRY_CATALOG[id];
      if (!entry) return null;
      const usage = state.usage[id] || {};
      return {
        ...entry,
        favorite: true,
        count: Math.max(0, Number(usage.count) || 0),
        lastUsedAt: Math.max(0, Number(usage.lastUsedAt) || 0)
      };
    })
    .filter(Boolean)
    .sort(compareQuickAccess);

  return typeof limit === 'number' && limit > 0 ? items.slice(0, limit) : items;
}

function normalizeSearchValue(value) {
  return String(value || '').toLowerCase().trim();
}

function compactSearchValue(value) {
  return normalizeSearchValue(value).replace(/\s+/g, '');
}

function buildSearchRank(entry, queryNorm, queryCompact) {
  if (!entry || !queryNorm) return 0;

  const labelNorm = normalizeSearchValue(entry.label);
  const labelCompact = compactSearchValue(entry.label);
  const descNorm = normalizeSearchValue(entry.desc);
  const descCompact = compactSearchValue(entry.desc);
  const groupNorm = normalizeSearchValue(entry.groupLabel);
  const groupCompact = compactSearchValue(entry.groupLabel);

  let score = 0;

  if (labelNorm === queryNorm || labelCompact === queryCompact) score += 120;
  else if (labelNorm.startsWith(queryNorm) || labelCompact.startsWith(queryCompact)) score += 90;
  else if (labelNorm.includes(queryNorm) || labelCompact.includes(queryCompact)) score += 70;

  if (groupNorm.includes(queryNorm) || groupCompact.includes(queryCompact)) score += 24;
  if (descNorm.includes(queryNorm) || descCompact.includes(queryCompact)) score += 12;

  return score;
}

export function searchHubEntries(query, limit = 0) {
  const queryNorm = normalizeSearchValue(query);
  const queryCompact = queryNorm.replace(/\s+/g, '');
  if (!queryNorm) return [];

  const state = readState();
  const allFavorites = new Set(getAllFavoriteEntryIds(state));
  const items = Object.values(HUB_ENTRY_CATALOG)
    .map((entry) => {
      const usage = state.usage[entry.id] || {};
      return {
        ...entry,
        favorite: allFavorites.has(entry.id),
        count: Math.max(0, Number(usage.count) || 0),
        lastUsedAt: Math.max(0, Number(usage.lastUsedAt) || 0),
        searchRank: buildSearchRank(entry, queryNorm, queryCompact)
      };
    })
    .filter((entry) => entry.searchRank > 0)
    .sort((a, b) => b.searchRank - a.searchRank || compareQuickAccess(a, b))
    .map(({ searchRank, ...entry }) => entry);

  return typeof limit === 'number' && limit > 0 ? items.slice(0, limit) : items;
}

export function getHubPanelSearch(mode = 'bqc') {
  const key = normalizePanelSearchMode(mode);
  const state = readPanelSearchState();
  const item = state[key] || {};
  return {
    query: String(item.query || ''),
    entryId: String(item.entryId || '')
  };
}

export function setHubPanelSearch(mode = 'bqc', nextValue = {}) {
  const key = normalizePanelSearchMode(mode);
  const current = readPanelSearchState();
  current[key] = {
    query: String(nextValue?.query || '').trim(),
    entryId: String(nextValue?.entryId || '').trim()
  };
  const next = writePanelSearchState(current);
  return {
    query: String(next[key]?.query || ''),
    entryId: String(next[key]?.entryId || '')
  };
}

export function bindHubEntryContextMenu(element, entryId) {
  if (!element || !getHubEntry(entryId)) return element;

  const binding = { element, entryId };
  boundEntries.add(binding);
  syncBinding(binding);

  if (!element.dataset.hubFavoriteBound) {
    element.dataset.hubFavoriteBound = 'true';
    element.addEventListener('contextmenu', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      showContextMenu(ev.clientX, ev.clientY, entryId);
    });
  }

  return element;
}

export function syncHubEntryBindings() {
  cleanupDisconnectedBindings();
  boundEntries.forEach(syncBinding);
}

export function openHubEntry(entryId, options = {}) {
  const entry = getHubEntry(entryId);
  if (!entry) return;

  if (options.recordUsage !== false) {
    recordHubEntryUse(entryId);
  }

  const panelRoute = String(options.panelRoute || '').replace(/^#/, '');
  let route = String(panelRoute || entry.route || '').replace(/^#/, '');
  if (!route) return;

  if (route === 'multi') {
    const mode = entry.multiMode === 'utility' ? 'utility' : 'bqc';
    setMultiMode(mode);
    setHubPanelSearch(mode, { query: '', entryId });
    writePending(null);
    navigateToRoute(mode);
    return;
  }

  if (panelRoute) {
    writePending({
      entryId,
      route,
      createdAt: Date.now()
    });
  } else {
    writePending(null);
  }

  navigateToRoute(route);
}

export function consumePendingHubEntry(route = '') {
  const pending = readPending();
  if (!pending) return null;
  if (route && pending.route !== route) return null;
  writePending(null);
  return pending;
}
