import { clear, div, showExcelSavedDialog } from '../core/dom.js';
import { onHost, post } from '../core/bridge.js';
import { ProgressDialog } from '../core/progress.js';
import { openProjectCategoryPicker } from '../core/projectCategoryPicker.js?v=20260922categories1';
import { isAccRvt, accRvtName, accRvtLabel, accRvtIdentity, rememberAccRvtLocations } from '../core/accRvt.js';

const text = value => String(value ?? '');
const list = value => Array.isArray(value) ? value : [];
const read = (object, key, fallback = '') => object?.[key] ?? object?.[key[0].toLowerCase() + key.slice(1)] ?? fallback;
const leaf = value => text(value).split(/[\\/]/).pop();
const targetName = value => isAccRvt(value) ? accRvtName(value) : leaf(value);
const targetLabel = value => isAccRvt(value) ? accRvtLabel(value) : text(value);
const uniqueTargets = paths => [...new Map(paths.map(path => text(path).trim()).filter(path => isAccRvt(path) || /\.rvt$/i.test(path)).map(path => [accRvtIdentity(path), path])).values()];
const parentDirectory = value => text(value).replace(/[\\/][^\\/]*$/, '');
const stageNames = { all: '전체 진행', inspect: '최초 분석·백업', project: '프로젝트 준비', families: '패밀리 준비', compare: '준비 후 값 비교', verify: '값 복원·이관·검증', cleanup: '기존 파라미터 정리', save: '최종 검증·저장' };
const stageDescriptions = { all: '최초 백업 → 프로젝트 신규 파라미터 준비 → 스케줄 필드 선행 전환 → 패밀리 파라미터 묶음 추가·연동·기존 정의 삭제·로드 → 준비 후 값 비교 → 최초 값 복원·이관 및 스케줄 표시 값 검증 → 기존 파라미터 정리 → 최종 검증·저장 순서로 진행합니다.', inspect: '기존 바인딩 설정, 변경 대상 값과 보존할 업무 값을 최초 백업으로 저장합니다. 이후 비교·복원의 기준으로 유지합니다.', project: '최초 백업 후 교체는 기존 바인딩 설정을 승계하고, 신규 추가는 선택한 카테고리·값 구분·파라미터 그룹으로 프로젝트 파라미터를 준비합니다.', families: '프로젝트 신규 파라미터 준비 후 선택한 스케줄 필드를 먼저 전환합니다. 대상 복합·하위 패밀리를 편집할 때 선택한 매핑의 신규 추가·하위 연동·기존 정의 삭제를 함께 완료하고 로드합니다. 프로젝트 값은 준비 후 비교를 마친 다음 최초 백업으로 복원·이관합니다.', compare: '프로젝트·패밀리 준비가 끝난 값을 다시 추출해 최초 백업과 비교합니다. 이 단계에서는 프로젝트 값을 복원하거나 이관하지 않으며, 값 변화와 신규 파라미터의 존재를 기록합니다.', verify: '준비 후 비교 기록을 확인한 뒤 최초 백업으로 프로젝트 값을 복원·이관합니다. 모든 패밀리 로드 후의 값·연동과 스케줄 표시 값을 검증한 뒤 기존 정리를 진행합니다.', cleanup: '값 이관 검증이 완료된 기존 프로젝트 파라미터를 정리하고, 영향을 받은 프로젝트 값을 최초 백업 기준으로 복원·검증합니다. 패밀리의 기존 정의는 패밀리 준비 단계에서 삭제합니다.', save: '기존 정리 결과와 신규 값·연결·보존 값을 최종 검증한 뒤 저장합니다. 정리 보류나 실패가 있으면 결과에 표시합니다.' };
const statusNames = { ready: '준비됨', pending: '대기', running: '진행 중', completed: '완료', succeeded: '완료', success: '완료', passed: '통과', failed: '실패', error: '오류', partial: '일부 완료', paused: '체크포인트에서 정지', skipped: '제외', excluded: '제외', blocked: '확인 필요', unchanged: '변경 없음', applied: '적용 완료', verified: '검증 완료', 'no-work': '처리 대상 없음', 'no-changes': '실제 변경 없음', 'not-selected': '선택 안 함' };
const persistenceNames = { saved: '저장 완료', synced: '중앙파일 동기화 완료', synchronized: '중앙파일 동기화 완료', 'in-memory': '문서에 적용됨 · 직접 저장 필요', 'cloud-in-memory': 'ACC 적용 대기 · 같은 Revit에서 이어서 실행', 'cloud-inspected': 'ACC 분석 기록 저장', 'checkpoint-only': '체크포인트만 저장됨 · 원본 RVT 미저장', 'not-saved': '저장하지 않음', 'not-needed': '저장 불필요', failed: '저장 실패' };
// Original document persistence and recovery checkpoints are separate host facts.
// This helper changes text only; it never updates settings, timers or progress units.
export function migrationPersistenceNote(result, { mode = 'active', saveActive = false, running = false, stage = '', requestedStage = 'all', familyDefinitionsOnly = false } = {}) {
  const labels = familyDefinitionsOnly ? familyStageNames : stageNames;
  const statuses = list(read(result, 'Files', [])).map(file => text(read(file, 'PersistenceStatus')).toLowerCase());
  if (statuses.length > 1) {
    const counts = new Map();
    statuses.forEach(status => counts.set(status, (counts.get(status) || 0) + 1));
    const summary = [...counts].map(([status, count]) => `${persistenceNames[status] || '저장 상태 확인 필요'} ${count.toLocaleString()}개`).join(' · ');
    return `대상 문서 저장 상태: ${summary}${running ? ` · 현재 ${labels[stage] || '작업'} 진행 중` : ''}`;
  }
  const status = statuses[0] || '';
  if (running && ['', 'not-saved', 'in-memory'].includes(status)) {
    if (mode === 'active' && !saveActive) return '체크포인트에는 작업 기록만 저장합니다. 활성 문서의 변경은 같은 Revit 실행에서 이어가며, Revit 재시작 후 이어가려면 저장·동기화 옵션을 선택하세요.';
    if (!['all', 'save'].includes(requestedStage)) return mode === 'active' && saveActive ? '체크포인트 저장 시 활성 문서를 저장·동기화합니다. 저장이 완료된 체크포인트는 Revit을 다시 시작한 뒤 이어갈 수 있습니다.' : '현재 실행 범위에는 원본 문서 저장 단계가 없습니다. 변경 내용의 저장 여부는 파일별 결과에서 확인하세요.';
    if (stage === 'save') return '최종 검증·저장 단계가 진행 중입니다. 저장·동기화 완료 결과를 기다리고 있습니다.';
    if (mode === 'active') return '활성 문서의 체크포인트 및 최종 저장·동기화가 선택되어 있습니다. 저장이 완료된 체크포인트는 Revit을 다시 시작한 뒤 이어갈 수 있습니다. 저장 결과는 파일별 결과에서 확인하세요.';
    return '원본 문서 저장·동기화는 아직 완료되지 않았습니다. 파일별 저장 결과는 저장 단계가 끝난 뒤 확인됩니다.';
  }
  const notes = {
    saved: '원본 문서 저장이 완료되었습니다.',
    synced: '원본 문서의 중앙파일 동기화가 완료되었습니다.',
    synchronized: '원본 문서의 중앙파일 동기화가 완료되었습니다.',
    'in-memory': '원본 문서가 아직 저장되지 않았습니다. 활성 문서의 변경은 직접 저장하거나 같은 Revit에서 이어서 실행하세요.',
    'cloud-in-memory': 'ACC 변경은 같은 Revit 세션에 남아 있습니다. 같은 Revit에서 이어서 실행하거나 저장·동기화를 완료하세요.',
    'cloud-inspected': 'ACC 분석 기록이 저장되었습니다. 원본 문서 저장 상태는 별도로 확인하세요.',
    'checkpoint-only': '작업 기록만 저장된 체크포인트입니다. 원본 RVT 저장·동기화는 확인되지 않았으며, 진행 중 변경은 같은 Revit 실행에서 이어가세요.',
    'not-saved': '원본 문서가 저장되지 않았습니다. 파일별 저장 단계와 결과를 확인하세요.',
    'not-needed': '저장할 변경이 없어 원본 문서 저장이 필요하지 않습니다.',
    failed: '원본 문서 저장·동기화에 실패했습니다. 결과의 저장 오류를 확인하세요.'
  };
  const note = notes[status] || '원본 문서 저장·동기화 상태가 확인되지 않았습니다.';
  return running ? `${note} · 현재 ${labels[stage] || '작업'} 진행 중` : note;
}


const scopeNames = { project: '프로젝트', family: '패밀리', families: '패밀리', instance: '인스턴스', type: '타입' };
const uuid = () => globalThis.crypto?.randomUUID?.() || `mapping-${Date.now()}-${Math.random().toString(16).slice(2)}`;
const familyTargetNames = { compound: '복합패밀리만', standalone: '단일 패밀리만', all: '복합 + 단일 패밀리' };
const familyStageNames = { all: '전체 진행', inspect: '정의 분석·백업', project: '프로젝트 파라미터 준비', families: '패밀리 추가·연동', verify: '패밀리 검증', cleanup: '기존 파라미터 정리', save: '최종 검증·저장' };
const familyStageDescriptions = { all: '프로젝트 파라미터 준비 → 스케줄 필드 선행 전환 → 패밀리 파라미터 묶음 추가·연동·기존 정의 삭제·로드 → 패밀리 검증 → 기존 파라미터 정리 → 최종 저장 순서로 진행합니다.', inspect: '프로젝트 바인딩과 패밀리 정의·기본값·연결을 분석하고 백업합니다.', project: '기존 바인딩 설정을 계승하거나 신규 추가 설정에 따라 프로젝트 파라미터를 준비합니다.', families: '프로젝트 준비 후 선택한 스케줄 필드를 먼저 전환하고, 대상 패밀리를 편집할 때 선택한 매핑의 신규 추가·하위 연동·기존 정의 삭제를 함께 완료하고 로드합니다.', verify: '패밀리 정의·기본값·상하위 연결을 검증합니다.', cleanup: '검증된 기존 프로젝트 파라미터를 정리합니다. 패밀리의 기존 정의는 패밀리 준비 단계에서 삭제합니다.', save: '정의와 연결의 최종 검증 후 문서를 저장합니다.' };
const newMapping = () => ({ Key: uuid(), Mode: 'replace', OldName: '', OldGuid: '', OldParameterId: 0, NewName: '', NewGuid: '', IsInstance: null, GroupKey: '', FamilyGroupKey: '', VariesAcrossGroups: false, CategoryIds: [], CategoryBindingMode: 'inherit', ApplyProject: true, ApplyFamilies: true, FamilyTargetKind: 'compound', AddIfMissing: false, AddToDummyFamilies: false, AddToDummyRootFamilies: true });
const normalizeMapping = item => Object.fromEntries(Object.entries(newMapping()).map(([key, fallback]) => [key, read(item, key, fallback)]));
const guidIdentity = value => text(value).trim().replace(/^\{(.*)\}$/, '$1').toLowerCase();
const sameParameterGuid = row => row.Mode === 'replace' && !!guidIdentity(row.OldGuid) && guidIdentity(row.OldGuid) === guidIdentity(row.NewGuid);
const categoryModes = ['extend', 'remove', 'replace'];
const categoryModeNames = { extend: '기존 범위에 추가', remove: '기존 범위에서 제외', replace: '선택한 범위로 재설정' };
const categorySummaryNames = { extend: '기존 범위 유지 + 선택 카테고리 추가', remove: '기존 범위 유지 + 선택 카테고리 제외', replace: '선택한 카테고리로 적용 범위 재설정' };
const isCategoryScopeUpdate = row => sameParameterGuid(row) && categoryModes.includes(row.CategoryBindingMode);
const preferenceKey = 'kky.settings.parammigration.v1';
const portableMappingFields = ['Mode', 'OldName', 'OldGuid', 'NewName', 'NewGuid', 'IsInstance', 'GroupKey', 'FamilyGroupKey', 'VariesAcrossGroups', 'CategoryIds', 'CategoryBindingMode', 'ApplyProject', 'ApplyFamilies', 'FamilyTargetKind', 'AddIfMissing', 'AddToDummyFamilies', 'AddToDummyRootFamilies'];
// Settings describe reusable intent. Native IDs, paths, run records and checkpoints
// are owned by the current document/session and never enter this portable format.
export function migrationPortableSettings(value) {
  const defaults = read(value, 'CategoryDefaults', {});
  return { Schema: 'KKY.ParameterMigration.Settings.1', SchemaVersion: 1,
    CategoryDefaults: { CategoryBindingMode: categoryModes.includes(read(defaults, 'CategoryBindingMode')) ? read(defaults, 'CategoryBindingMode') : 'extend', CategoryIds: [...new Set(list(read(defaults, 'CategoryIds', [])).map(Number).filter(Number.isSafeInteger))] }, FamilyDefinitionsOnly: read(value, 'FamilyDefinitionsOnly', false) === true,
    SyncComment: text(read(value, 'SyncComment', 'KKY Tool 공유파라미터 통합 변경')).slice(0, 240),
    Mappings: list(read(value, 'Mappings', [])).map(item => {
      const row = normalizeMapping(item), portable = Object.fromEntries(portableMappingFields.map(key => [key, row[key]]));
      portable.CategoryIds = [...new Set(list(row.CategoryIds).map(Number).filter(Number.isSafeInteger))];
      ['OldName', 'OldGuid', 'NewName', 'NewGuid', 'GroupKey', 'FamilyGroupKey'].forEach(key => { portable[key] = text(portable[key]).trim(); });
      if (isCategoryScopeUpdate(portable)) { portable.ApplyProject = true; portable.ApplyFamilies = false; }
      return portable;
    }) };
}
const totalIssues = file => Math.max(list(read(file, 'Issues', [])).length, Number(read(file, 'TotalIssueCount', 0)) || 0);
const unresolvedErrors = file => Math.max(0, Number(read(file, 'UnresolvedErrorCount', list(read(file, 'Issues', [])).filter(issue => !read(issue, 'Resolved', false) && text(read(issue, 'Severity')).toLowerCase() === 'error').length)) || 0);
const hasFileError = file => ['failed', 'error', 'blocked', 'partial'].includes(text(read(file, 'Status')).toLowerCase()) || unresolvedErrors(file) > 0;
const hasRunError = result => ['failed', 'error', 'blocked', 'partial'].includes(text(read(result, 'Status')).toLowerCase()) || list(read(result, 'Files', [])).some(hasFileError);
const isError = issue => text(read(issue, 'Severity')).toLowerCase() === 'error' && !read(issue, 'Resolved', false);
const isInfo = issue => text(read(issue, 'Severity')).toLowerCase() === 'info' && !read(issue, 'Resolved', false);
const isWarning = issue => text(read(issue, 'Severity')).toLowerCase() === 'warning' && !read(issue, 'Resolved', false);
const number = value => Math.max(0, Number(value) || 0);
const duration = value => { const seconds = Math.floor(number(value)); return `${Math.floor(seconds / 3600)}시간 ${Math.floor(seconds / 60) % 60}분 ${seconds % 60}초`; };
// Native Revit calls can hold the host event loop while WebView JavaScript still
// runs. Interpolate elapsed time only; work counts remain the host's committed units.
export function createMigrationElapsedClock(now = () => globalThis.performance.now()) {
  let seconds = 0, sampledAt = 0, running = false;
  const valueAt = time => seconds + (running ? Math.max(0, time - sampledAt) / 1000 : 0);
  return {
    sync(hostSeconds, active) {
      const time = now(), reported = number(hostSeconds);
      seconds = running && active ? Math.max(reported, valueAt(time)) : reported;
      sampledAt = time; running = active;
      return seconds;
    },
    read: () => valueAt(now()),
    reset() { seconds = 0; sampledAt = 0; running = false; }
  };
}
// Activity means a real host callback, not a ticking browser clock. A checkpoint
// can retain its RunId across resumes, so bind both IDs before accepting packets.
export function createMigrationActivityState(now = () => globalThis.performance.now()) {
  let runId = '', sessionId = '', sequence = 0, current = null, receivedAt = 0;
  const retiredSessions = new Set();
  return {
    bind(nextRunId, nextSessionId) {
      const run = text(nextRunId), session = text(nextSessionId);
      if (!run || !session || retiredSessions.has(session)) return false;
      if (runId === run && sessionId === session) return true;
      if (sessionId) retiredSessions.add(sessionId);
      runId = run; sessionId = session; sequence = 0; current = null; receivedAt = 0;
      return true;
    },
    accept(payload) {
      const next = Number(read(payload, 'Sequence', 0));
      if (!sessionId || text(read(payload, 'RunId')) !== runId || text(read(payload, 'ActivitySessionId')) !== sessionId || !Number.isSafeInteger(next) || next <= sequence) return false;
      sequence = next; receivedAt = now();
      current = { stage: text(read(payload, 'Stage')), operation: text(read(payload, 'Operation')), detail: text(read(payload, 'Detail')), elapsedSeconds: number(read(payload, 'ElapsedSeconds', 0)) };
      return true;
    },
    read: () => current ? { ...current, ageSeconds: Math.floor(Math.max(0, now() - receivedAt) / 1000) } : null,
    reset() {
      if (sessionId) retiredSessions.add(sessionId);
      runId = ''; sessionId = ''; sequence = 0; current = null; receivedAt = 0;
    }
  };
}
export function migrationActivityLabel(activity) {
  // Keep the actual family path and mapping names. Only remove the diagnostic
  // document-count suffix, never an arbitrary slash that may belong to a name.
  const detail = text(activity?.detail).replace(/^\[[a-z]+\]\s*/i, '').replace(/\s*\/\s*Application\.Documents\b.*$/i, '').trim();
  return detail ? `최근 작업 알림: ${detail}` : `현재 작업: ${text(activity?.operation)}`;
}
const issueRank = issue => isError(issue) ? 0 : read(issue, 'Resolved', false) ? 2 : 1;
// Bounded display selection keeps older unresolved errors visible before recent notices.
const displayIssues = files => {
  const entries = files.flatMap((file, fileIndex) => list(read(file, 'Issues', [])).map((issue, index) => ({ issue, fileIndex, index })));
  const errors = entries.filter(entry => isError(entry.issue)).slice(0, 200), selected = new Set(errors);
  const remaining = 200 - errors.length;
  if (remaining) entries.filter(entry => !selected.has(entry)).slice(-remaining).forEach(entry => selected.add(entry));
  return files.map((_, fileIndex) => [...selected].filter(entry => entry.fileIndex === fileIndex).sort((a, b) => issueRank(a.issue) - issueRank(b.issue) || a.index - b.index).map(entry => entry.issue));
};

// Keep editors mounted through context and progress events. Only explicit row actions
// or checkpoint loading replace editors; typing and IME never rebuild their ancestors.
export function renderParameterMigration(root) {
  clear(root);
  const state = { mode: 'active', familyDefinitionsOnly: false, hosts: [], mappings: [], definitions: [], currentParameters: [], categories: [], parameterGroups: [], definitionPath: '', active: null, token: '', checkpointDirectory: '', checkpointPath: '', checkpointLoaded: false, stage: 'all', conflict: 'stop', saveActive: false, confirmSchedulesWithoutConditionalFormatting: false, syncComment: 'KKY Tool 공유파라미터 통합 변경', running: false, pending: '', pauseRequested: false, progressOwner: null, progressKind: '', result: null, issueSearch: '', issueFilter: 'all', editor: null, disposed: false };
  const page = div('parammigration-page');
  page.innerHTML = `
    <div class="parammigration-workspace">
      <div class="rvt3-mode-grid parammigration-modes" role="tablist" aria-label="객체 입력값 유지 여부"><button type="button" class="rvt3-mode-card is-active" data-workflow="project" role="tab" aria-selected="true" tabindex="0"><strong>객체 입력값 유지</strong></button><button type="button" class="rvt3-mode-card" data-workflow="families" role="tab" aria-selected="false" tabindex="-1"><strong>객체 입력값 유지 제외</strong></button></div>
      <p class="parammigration-note" data-workflow-note hidden>프로젝트 바인딩·패밀리 정의·하위 연동·스케줄 필드 교체를 처리합니다. 프로젝트 객체의 입력값은 백업·복원·유지 검사하지 않습니다. 패밀리 내부 전체 값은 두 작업 방식 모두 비교하지 않으며, 교체 대상의 기본값 복사와 모든 타입의 Label·파라미터 연동을 처리합니다.</p>
      <section class="parammigration-card">
        <header><h2><small>01</small> 작업 대상</h2><button type="button" class="secondary" data-refresh>새로고침</button></header>
        <div class="rvt3-mode-grid parammigration-modes" role="group" aria-label="작업 대상">
          <button type="button" class="rvt3-mode-card is-active" data-mode="active" aria-pressed="true"><strong>활성 문서</strong></button>
          <button type="button" class="rvt3-mode-card" data-mode="batch" aria-pressed="false"><strong>여러 RVT</strong></button>
        </div>
        <div class="parammigration-document" data-active-document>활성 문서를 확인하고 있습니다.</div>
        <div data-batch-target hidden><div class="parammigration-actions"><button type="button" class="secondary" data-pick-targets>로컬 RVT 추가</button><button type="button" class="secondary" data-pick-acc-targets>ACC 모델 추가</button><button type="button" class="secondary" data-clear-targets>목록 비우기</button><span data-target-count>0개</span></div><div class="parammigration-files" data-hosts data-parammigration-scroll-key="hosts" role="region" aria-label="등록한 RVT 및 ACC 모델" tabindex="0"></div><p class="parammigration-note parammigration-target-note" data-acc-target-note hidden>ACC 모델은 현재 Revit 계정으로 접근합니다. 실행 전 등록한 모델을 닫으세요.</p></div>
      </section>
      <section class="parammigration-card">
        <header><h2><small>02</small> 파라미터 변경 목록 <span class="parammigration-count" data-mapping-count>0개</span></h2><button type="button" class="secondary" data-add-mapping>파라미터 추가</button></header>
        <div class="parammigration-definition-bar"><p class="parammigration-note parammigration-path" data-definition-path>신규 공유파라미터 TXT를 선택하세요.</p><div class="parammigration-actions"><button type="button" class="secondary" data-pick-definitions>공유 TXT 선택</button><button type="button" class="secondary" data-use-revit-definitions>Revit 설정 TXT 사용</button></div></div>
        <div class="parammigration-actions parammigration-bulk-tools"><button type="button" class="secondary" data-register-categories>카테고리 변경 파라미터 일괄 등록</button><button type="button" class="secondary" data-import-parameters>Excel 목록 불러오기</button><button type="button" class="secondary" data-export-parameters>Excel 목록 저장</button><button type="button" class="secondary" data-export-parameter-template>Excel 양식 저장</button></div>
        <div class="parammigration-actions"><label class="parammigration-toggle"><input type="checkbox" data-select-mappings><span>전체 선택</span></label><span class="parammigration-note" data-selected-mappings>0개 선택</span><button type="button" class="secondary" data-bulk-categories>선택한 파라미터의 카테고리 일괄 설정</button></div>
        <details class="parammigration-settings" data-settings-panel><summary>설정 저장·불러오기</summary><div class="parammigration-settings-grid"><label class="parammigration-field"><span>저장할 설정 이름</span><input type="text" data-preset-name maxlength="64" placeholder="예: 설비 공통 카테고리"></label><div class="parammigration-actions"><button type="button" class="secondary" data-save-preset>이름으로 저장</button><button type="button" class="secondary" data-load-recent>최근 설정 불러오기</button></div><label class="parammigration-field"><span>저장한 설정</span><select data-preset-picker></select></label><div class="parammigration-actions"><button type="button" class="secondary" data-load-preset>불러오기</button><button type="button" class="secondary" data-delete-preset>삭제</button><button type="button" class="secondary" data-export-settings>설정 파일 저장</button><button type="button" class="secondary" data-import-settings>설정 파일 불러오기</button></div></div><p class="parammigration-note" data-settings-note>등록한 목록과 카테고리 설정을 자동으로 기억합니다. 대상 RVT·실행 기록은 저장하지 않습니다.</p></details>
        <div class="parammigration-empty" data-mapping-empty>공유 TXT를 선택한 뒤 변경할 파라미터를 등록하세요.</div>
        <div class="parammigration-mappings" data-mappings data-parammigration-scroll-key="mappings" role="region" aria-label="등록한 파라미터" tabindex="0"></div>
      </section>
      <section class="parammigration-card parammigration-checkpoint">
        <header><h2><small>03</small> 저장 및 이어서 진행</h2></header>
        <div class="parammigration-output-directory"><div class="parammigration-field"><span>작업 기록 저장 폴더</span><p class="parammigration-note parammigration-path" data-output-directory>저장할 폴더를 선택하세요.</p></div><button type="button" class="secondary" data-pick-output-directory>폴더 선택</button></div>
        <div class="parammigration-actions"><button type="button" class="secondary" data-pick-checkpoint>체크포인트 불러오기</button><button type="button" class="secondary" data-clear-checkpoint hidden>새 설정으로 전환</button><button type="button" class="secondary" data-export-result>결과 Excel 저장</button><span class="parammigration-note parammigration-path" data-checkpoint-path></span></div>
        <details class="parammigration-storage-help"><summary>저장·복구 안내</summary><p class="parammigration-note" data-checkpoint-note></p><p class="parammigration-note">결과 Excel은 마지막 체크포인트의 전체 기록을 저장합니다. 객체 입력값 유지 모드에서는 준비 후 차이 시트에서 객체·파라미터별 최초 값, 준비 후 값과 신규 파라미터 존재 여부를 확인할 수 있습니다. 저장할 때 파일 위치를 선택하세요.</p></details>
        <p class="parammigration-note parammigration-path" data-export-path hidden></p>
      </section>
      <section class="parammigration-card" data-results hidden><header><div><small>결과</small><h2>문서별 진행 결과</h2></div><span data-result-count></span></header>
        <div class="parammigration-result-filters"><label class="parammigration-field"><span>확인 사항 검색</span><input type="text" data-issue-search data-result-control placeholder="파라미터, 요소 ID, 메시지 검색"></label><label class="parammigration-field"><span>표시 항목</span><select data-issue-filter data-result-control><option value="all">전체</option><option value="error">미해결 오류</option><option value="warning">경고</option><option value="info">안내·제외</option><option value="resolved">해결됨</option></select></label></div>
        <p class="parammigration-note" data-result-summary></p><div data-result-files data-parammigration-scroll-key="results"></div></section>
      <dialog class="parammigration-editor parammigration-card" data-mapping-dialog aria-labelledby="parammigration-editor-title">
        <header><div><h2 id="parammigration-editor-title" data-editor-title>파라미터 등록</h2><p class="parammigration-note" data-editor-description>등록할 내용을 입력한 뒤 적용하세요.</p></div><button type="button" class="secondary" data-editor-close aria-label="파라미터 설정 닫기">닫기</button></header>
        <div class="parammigration-editor-body" data-editor-body data-parammigration-scroll-key="editor" tabindex="0"></div>
        <footer><p class="parammigration-note" data-editor-message role="status"></p><div class="parammigration-actions"><button type="button" class="secondary" data-editor-cancel>취소</button><button type="button" class="primary" data-editor-apply>등록</button></div></footer>
      </dialog>
    </div>
    <aside class="parammigration-run-panel">
      <section class="parammigration-card">
        <header><h2>설정 및 실행</h2><span role="status" data-state>준비됨</span></header>
        <label class="parammigration-field"><span>실행 단계</span><select data-stage><option value="all">전체 진행</option><option value="inspect">최초 분석·백업</option><option value="project">프로젝트 준비</option><option value="families">패밀리 준비</option><option value="compare">준비 후 값 비교</option><option value="verify">값 복원·이관·검증</option><option value="cleanup">기존 파라미터 정리</option><option value="save">최종 검증·저장</option></select></label>
        <p class="parammigration-note" data-stage-note>${stageDescriptions.all}</p>
        <label class="parammigration-toggle" data-schedule-transition-wrap><input type="checkbox" data-confirm-schedule-transition data-parammigration-focus-key="confirm-schedule-transition" aria-describedby="parammigration-schedule-transition-note"><span>스케줄 필드 자동 전환</span></label>
        <p class="parammigration-note" id="parammigration-schedule-transition-note">대상 스케줄에 조건부서식이 없음을 확인한 경우 선택하세요. 프로젝트 신규 파라미터 준비 후 패밀리 로드 전에 열 설정·필터·정렬을 신규 파라미터로 전환합니다. 객체 입력값 유지 방식의 표시 값은 패밀리 로드와 최초 프로젝트 값 복원 후 검증합니다. 계산식이 있는 스케줄은 기존 참조를 유지합니다. 선택하지 않으면 사용 중인 스케줄 참조를 유지하고 해당 기존 파라미터 정리를 보류합니다.</p>
        <label class="parammigration-toggle" data-save-active-wrap><input type="checkbox" data-save-active><span>체크포인트 및 최종 저장 / 동기화</span></label>
        <details class="parammigration-extra"><summary>동기화 코멘트</summary><label class="parammigration-field"><span class="sr-only">동기화 코멘트</span><input type="text" data-sync-comment maxlength="240" value="KKY Tool 공유파라미터 통합 변경"></label></details>
        <div class="parammigration-readiness" data-readiness></div>
        <div class="parammigration-run-actions"><button type="button" class="primary" data-direct-kind="primary" data-run>전체 진행</button><button type="button" class="secondary" data-retry disabled>실패한 대상만 재시도</button><button type="button" class="secondary" data-pause hidden>체크포인트까지 진행 후 정지</button></div>
        <p class="parammigration-note" data-save-note></p>
        <div class="parammigration-progress" data-progress hidden><strong data-progress-activity hidden></strong><span data-progress-text>작업을 준비하고 있습니다.</span><span data-progress-activity-age hidden></span><span data-progress-work></span><span data-progress-values></span><span data-progress-elapsed></span><span data-progress-checkpoint></span><span data-progress-pause hidden></span></div>
        <p class="parammigration-feedback" role="status" aria-live="polite" data-feedback></p>
      </section>
    </aside>`;
  root.append(page);
  const workspace = page.querySelector('.parammigration-workspace'), aside = page.querySelector('.parammigration-run-panel');
  const $ = selector => workspace.querySelector(selector) || aside.querySelector(selector);
  const $$ = selector => [...workspace.querySelectorAll(selector), ...aside.querySelectorAll(selector)];
  const subscriptions = [], rowElements = new Map(), hostElements = new Map(), selectedMappings = new Set();
  let preferences = { SchemaVersion: 1, Recent: null, Presets: [] }, lastPreferences = '', preferencesPending = false, saveTimer = 0;
  state.categoryDefaults = { CategoryBindingMode: 'extend', CategoryIds: [] };
  const currentSettings = () => migrationPortableSettings({ CategoryDefaults: state.categoryDefaults, FamilyDefinitionsOnly: state.familyDefinitionsOnly, SyncComment: state.syncComment, Mappings: state.mappings.map(row => ({ ...row, ...(normalScopes.get(row.Key) || {}) })) });
  // Source TXT is an editor catalog, independent of the target TXT and request schema.
  const sourceCatalog = { definitions: [], path: '', mode: 'active' }, sourceModes = new Map();
  // Project scopes stay in a local draft; only effective definition flags enter the request.
  const normalScopes = new Map();
  const mappingScope = row => ({ ApplyProject: row.ApplyProject, ApplyFamilies: row.ApplyFamilies });
  const forceDefinitionScope = row => { row.ApplyProject = true; row.ApplyFamilies = !isCategoryScopeUpdate(row); };
  let normalStage = null;
  const currentStageNames = () => state.familyDefinitionsOnly ? familyStageNames : stageNames;
  let sourceRequest = null;
  let interactionVersion = 0;
  const onInteraction = () => { interactionVersion++; };
  const interactionEvents = ['wheel', 'pointerdown', 'keydown', 'focusin'];
  interactionEvents.forEach(event => window.addEventListener(event, onInteraction, { capture: true, passive: true }));
  const listen = (event, fn) => subscriptions.push(onHost(`parammigration:${event}`, payload => { if (!state.disposed && page.isConnected) fn(payload || {}); }));
  const feedback = (message, tone = '') => { $('[data-feedback]').textContent = text(message); $('[data-feedback]').dataset.tone = tone; };
  const busy = () => state.running || !!state.pending;
  function request(event, payload = {}, pending = '') {
    if (busy() && event !== 'pause') return false;
    state.pending = pending; sync();
    if (post(`parammigration:${event}`, payload) === false) { state.pending = ''; feedback('Revit 연결을 확인하세요.', 'error'); sync(); return false; }
    return true;
  }
  function payload(retry = false) {
    return { contextToken: state.token, request: { TargetKind: state.mode, TargetPaths: [...state.hosts], FamilyDefinitionsOnly: state.familyDefinitionsOnly, DefinitionFilePath: state.definitionPath, Mappings: state.mappings.map(row => ({ ...row, ...(isCategoryScopeUpdate(row) ? { ApplyProject: true, ApplyFamilies: false } : state.familyDefinitionsOnly ? { ApplyProject: true, ApplyFamilies: true } : {}), OldName: state.checkpointLoaded ? text(row.OldName) : text(row.OldName).trim(), OldGuid: state.checkpointLoaded ? text(row.OldGuid) : text(row.OldGuid).trim(), OldParameterId: state.mode === 'active' || state.checkpointLoaded ? row.OldParameterId : 0, CategoryIds: [...list(row.CategoryIds)] })), ConflictPolicy: state.conflict, Stage: state.stage, CheckpointDirectory: state.checkpointDirectory, CheckpointPath: state.checkpointPath, RetryFailedOnly: retry, SaveActiveDocument: state.saveActive, ConfirmSchedulesWithoutConditionalFormatting: state.confirmSchedulesWithoutConditionalFormatting, SyncComment: state.syncComment } };
  }
  function problems() {
    const errors = [];
    if (state.mode === 'active' && (!state.active || !state.token || !read(state.active, 'CanUse', true))) errors.push('편집 가능한 활성 프로젝트 문서가 필요합니다.');
    if (state.mode === 'batch' && !state.hosts.length) errors.push('대상 RVT를 등록하세요.');
    if (state.checkpointLoaded) return errors;
    if (!state.checkpointDirectory) errors.push('작업 기록을 저장할 폴더를 선택하세요.');
    if (!['all', 'inspect'].includes(state.stage)) errors.push('먼저 최초 분석·백업을 실행하거나 체크포인트를 불러오세요.');
    if (state.mappings.some(row => !isCategoryScopeUpdate(row)) && (!state.definitionPath || !state.definitions.length)) errors.push('신규 공유파라미터 TXT를 선택하세요.');
    if (!state.mappings.length) errors.push('매핑을 하나 이상 추가하세요.');
    state.mappings.forEach((row, i) => mappingProblems(row).forEach(message => errors.push(`${i + 1}번 매핑: ${message}`)));
    return errors;
  }
  function mappingProblems(row) {
    const errors = [];
    if (row.ApplyFamilies && !familyTargetNames[row.FamilyTargetKind]) errors.push('패밀리 적용 범위를 선택하세요.');
    if (row.Mode === 'replace' && !text(row.OldName).trim() && !text(row.OldGuid).trim() && !row.OldParameterId) errors.push('기존 이름 또는 GUID를 입력하세요.');
    if (row.OldGuid && !/^[{]?[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}[}]?$/i.test(row.OldGuid.trim())) errors.push('기존 GUID 형식을 확인하세요.');
    if (!row.NewGuid) errors.push('신규 정의를 선택하세요.');
    if (row.NewGuid && !isCategoryScopeUpdate(row) && state.definitions.length && !state.definitions.some(def => guidIdentity(read(def, 'Guid')) === guidIdentity(row.NewGuid) && text(read(def, 'Name')) === row.NewName)) errors.push('선택한 신규 이름·GUID가 현재 공유 TXT에 없습니다. 정의를 확인하세요.');
    if ((isCategoryScopeUpdate(row) || (row.Mode === 'add' || row.AddIfMissing) && row.ApplyProject || row.Mode === 'add' && row.ApplyFamilies) && !list(row.CategoryIds).length) errors.push(isCategoryScopeUpdate(row) && row.CategoryBindingMode === 'replace' ? '최종 적용 카테고리를 하나 이상 선택하세요.' : row.CategoryBindingMode === 'remove' ? '제외할 카테고리를 선택하세요.' : '추가할 카테고리를 선택하세요.');
    return errors;
  }
  function sync() {
    const locked = busy(), frozen = state.checkpointLoaded, batch = state.mode === 'batch', errors = problems();
    state.categoryPicker?.setLocked(locked || frozen);
    $$('button, input, select').forEach(el => { el.disabled = !el.hasAttribute('data-result-control') && (locked || (frozen && !!el.closest('[data-editor-body]'))); });
    $$('[data-mode]').forEach(button => { const selected = button.dataset.mode === state.mode; button.classList.toggle('is-active', selected); button.setAttribute('aria-pressed', text(selected)); button.disabled = locked || frozen; });
    $$('[data-workflow]').forEach(button => { const selected = (button.dataset.workflow === 'families') === state.familyDefinitionsOnly; button.classList.toggle('is-active', selected); button.setAttribute('aria-selected', text(selected)); button.tabIndex = selected ? 0 : -1; button.disabled = locked || frozen || !!state.editor || !!state.localDialog; });
    $('[data-workflow-note]').hidden = !state.familyDefinitionsOnly;
    $('[data-schedule-transition-wrap]').hidden = false;
    $('#parammigration-schedule-transition-note').hidden = false;
    [...$('[data-stage]').options].forEach(option => { option.hidden = state.familyDefinitionsOnly && !familyStageNames[option.value]; option.disabled = option.hidden; option.textContent = currentStageNames()[option.value] || stageNames[option.value]; });
    $('[data-active-document]').hidden = batch; $('[data-batch-target]').hidden = !batch;
    $('[data-active-document]').textContent = state.active ? `${read(state.active, 'Name', read(state.active, 'Title', '활성 문서'))}${read(state.active, 'Path') ? '' : ' · 저장되지 않은 문서'}` : '활성 프로젝트 문서가 없습니다.';
    $('[data-active-document]').title = text(read(state.active, 'Path'));
    const cloudCount = state.hosts.filter(isAccRvt).length;
    $('[data-target-count]').textContent = cloudCount ? `로컬 ${state.hosts.length - cloudCount}개 · ACC ${cloudCount}개` : `${state.hosts.length}개`;
    $('[data-acc-target-note]').hidden = !cloudCount;
    ['pick-targets', 'pick-acc-targets', 'clear-targets', 'pick-definitions', 'use-revit-definitions', 'add-mapping'].forEach(key => { $(`[data-${key}]`).disabled = locked || frozen; });
    $('[data-add-mapping]').disabled = locked || frozen || !state.definitions.length;
    $('[data-add-mapping]').title = state.definitions.length ? '별도 창에서 변경할 파라미터를 등록합니다.' : '공유 TXT를 먼저 선택하세요.';
    $$('[data-remove-mapping]').forEach(button => { button.disabled = locked || frozen; });
    $$('[data-edit-mapping]').forEach(button => { button.textContent = frozen ? '상세 보기' : '수정'; });
    ['register-categories', 'import-parameters', 'bulk-categories', 'select-mappings', 'save-preset', 'load-recent', 'preset-picker', 'preset-name', 'load-preset', 'delete-preset', 'import-settings'].forEach(key => { $(`[data-${key}]`).disabled = locked || frozen; });
    $$('[data-select-mapping]').forEach(control => { control.disabled = locked || frozen; });
    syncSelection();
    $('[data-load-recent]').disabled ||= !preferences.Recent;
    $('[data-load-preset]').disabled ||= !preferences.Presets.length;
    $('[data-delete-preset]').disabled ||= !preferences.Presets.length;
    if (state.localDialog) {
      const modal = state.localDialog;
      modal.node.querySelectorAll('input,select,button').forEach(control => { control.disabled = locked || frozen; });
      modal.node.querySelectorAll('[data-local-close],[data-local-cancel]').forEach(control => { control.disabled = false; });
      modal.update?.();
    }
    $('[data-mapping-count]').textContent = `${state.mappings.length}개`;
    $('[data-mapping-empty]').hidden = !!state.mappings.length;
    $('[data-mappings]').hidden = !state.mappings.length;
    $('[data-mapping-empty]').textContent = '카테고리 변경은 일괄 등록으로 시작하세요. 정의 교체·신규 추가는 공유 TXT를 선택한 뒤 파라미터 추가로 등록하세요.';
    $$('[data-hosts] button').forEach(button => { button.disabled = locked || frozen; });
    $('[data-definition-path]').textContent = state.definitionPath ? `${leaf(state.definitionPath)} · 정의 ${state.definitions.length}개` : '정의 교체·신규 추가에는 공유 TXT를 선택하세요. 카테고리 변경만 할 때는 생략할 수 있습니다.';
    $('[data-definition-path]').title = state.definitionPath;
    $('[data-clear-checkpoint]').hidden = !frozen;
    $('[data-checkpoint-path]').textContent = state.checkpointPath ? leaf(state.checkpointPath) : '';
    $('[data-checkpoint-path]').title = state.checkpointPath;
    const outputDirectory = frozen ? parentDirectory(state.checkpointPath) : state.checkpointDirectory;
    $('[data-output-directory]').textContent = outputDirectory || '저장할 폴더를 선택하세요.';
    $('[data-output-directory]').title = outputDirectory;
    $('[data-checkpoint-note]').title = '체크포인트·복구 사본·로그는 선택한 폴더에 저장합니다. 일반 RVT의 작업 사본은 상대 링크 경로 유지를 위해 원본 파일 옆에 만듭니다. Windows/Revit 자체 임시 파일의 위치는 변경하지 않습니다.';
    $('[data-pick-output-directory]').disabled = locked || frozen;
    $('[data-export-result]').disabled = locked;
    $('[data-checkpoint-note]').textContent = frozen ? '기존 체크포인트 폴더에서 이어서 진행합니다. 대상·매핑·저장 폴더를 바꾸려면 새 설정으로 전환하세요.' : '선택한 폴더에 작업별 체크포인트·복구 사본·로그를 저장합니다. 일반 RVT의 작업 사본은 상대 링크 유지를 위해 원본 옆에 만들며, Revit 임시 파일은 Windows 임시 폴더를 사용합니다.';
    if (batch && cloudCount) $('[data-checkpoint-note]').textContent += ' ACC 모델은 로컬 RVT 복구 사본을 만들지 않습니다. 전체 진행을 권장하며, 변경 중 멈춘 작업은 같은 Revit 실행에서 이어서 진행하세요.';
    $('[data-save-active-wrap]').hidden = batch;
    $('[data-save-note]').textContent = batch ? '저장 단계에서 대상 RVT를 저장하거나 중앙파일과 동기화합니다.' : state.saveActive ? '체크포인트 및 최종 단계에서 활성 RVT를 저장하고, 작업 공유 문서는 중앙파일과 동기화합니다. 저장이 완료된 체크포인트는 Revit을 다시 시작한 뒤 이어갈 수 있습니다.' : '체크포인트에는 작업 기록만 저장합니다. 활성 문서의 변경은 같은 Revit 실행에서 이어가며, Revit 재시작 후 이어가려면 이 저장·동기화 옵션을 선택하세요.';
    if (batch && cloudCount) $('[data-save-note]').textContent += ' ACC 모델은 최종 저장 단계에서 반영됩니다.';
    $('[data-stage-note]').textContent = (state.familyDefinitionsOnly ? familyStageDescriptions : stageDescriptions)[state.stage] || '선택한 단계의 선행 조건과 체크포인트를 확인한 뒤 진행합니다.';
    const ready = $('[data-readiness]'); ready.replaceChildren();
    [batch ? `대상 RVT ${state.hosts.length}개` : '활성 문서', `매핑 ${state.mappings.length}개`, frozen ? '체크포인트 사용' : '새 작업'].forEach(value => { const line = document.createElement('span'); line.textContent = value; ready.append(line); });
    if (errors.length) { const line = document.createElement('p'); line.textContent = errors[0]; ready.append(line); }
    $('[data-run]').textContent = frozen ? `${currentStageNames()[state.stage]} 이어서 진행` : currentStageNames()[state.stage];
    $('[data-run]').disabled = locked || !!errors.length;
    $('[data-retry]').disabled = locked || !state.checkpointPath || !list(read(state.result, 'Files', [])).some(hasFileError);
    $('[data-pause]').hidden = !state.running; $('[data-pause]').disabled = state.pauseRequested;
    $('[data-state]').textContent = state.pauseRequested ? '정지 요청됨' : locked ? '처리 중' : statusNames[read(state.result, 'Status')] || '준비됨';
    $('[data-progress]').hidden = !state.running && !state.result;
    $('[data-progress-pause]').hidden = !state.pauseRequested;
    $('[data-progress-pause]').textContent = state.pauseRequested ? '정지 요청을 받았습니다. 현재 처리 단위를 마친 뒤 저장 완료를 확인하고 정지합니다.' : '';
    if (state.progressKind === 'run' && ProgressDialog.isOwner(state.progressOwner)) ProgressDialog.setActionState({ cancelDisabled: state.pauseRequested || !state.running, statusText: state.pauseRequested ? '현재 처리 단위를 마친 뒤 체크포인트 저장을 완료하고 정지합니다.' : '정지하면 현재 처리 단위의 저장을 마친 뒤 이어서 진행할 수 있습니다.' }, state.progressOwner);
    if (state.editor) {
      const editorErrors = mappingProblems(state.editor.draft);
      $('[data-editor-apply]').disabled = locked || frozen || !!editorErrors.length;
      $('[data-editor-apply]').hidden = frozen;
      $('[data-editor-cancel]').textContent = frozen ? '닫기' : '취소';
      $('[data-editor-message]').textContent = frozen ? '체크포인트의 설정은 변경할 수 없습니다.' : state.editor.notice || editorErrors[0] || '적용하면 변경 목록에 반영됩니다.';
      // Closing a local draft remains available even if an unrelated Host request is pending.
      $('[data-editor-close]').disabled = false; $('[data-editor-cancel]').disabled = false;
      const categoryUpdate = isCategoryScopeUpdate(state.editor.draft);
      state.editor.element.querySelector('[data-scope]').disabled = locked || frozen || state.familyDefinitionsOnly || categoryUpdate;
      state.editor.element.querySelector('[data-field="IsInstance"]').disabled = locked || frozen || categoryUpdate;
    }
  }
  function fillOptions(select, options, selected, placeholder) {
    select.replaceChildren();
    const first = document.createElement('option'); first.value = ''; first.textContent = placeholder; select.append(first);
    options.forEach(({ value, label }) => { const option = document.createElement('option'); option.value = text(value); option.textContent = label; select.append(option); });
    select.value = text(selected);
  }
  function updateRowCatalog(row, element) {
    filterDefinitions(row, element); filterSources(element);
    syncRow(row, element);
  }
  function searchWords(value) { return text(value).trim().toLocaleLowerCase().split(/\s+/).filter(Boolean); }
  function includesWords(value, words) { const haystack = text(value).toLocaleLowerCase(); return words.every(word => haystack.includes(word)); }
  function editorCatalog() { return state.editor?.catalog || state; }
  function filterDefinitions(row, element) {
    const definitions = editorCatalog().definitions;
    const words = searchWords(element.querySelector('[data-new-search]').value);
    const matches = definitions.filter(def => includesWords([read(def, 'Name'), read(def, 'Group', read(def, 'GroupName')), read(def, 'Guid')].join(' '), words));
    const options = matches.map(def => ({ value: read(def, 'Guid'), label: `${read(def, 'Name')} · ${read(def, 'Group', read(def, 'GroupName'))} · ${read(def, 'Guid')}` }));
    if (row.NewGuid && !options.some(def => guidIdentity(def.value) === guidIdentity(row.NewGuid))) options.push({ value: row.NewGuid, label: `${row.NewName} · ${row.NewGuid}${isCategoryScopeUpdate(row) || state.checkpointLoaded ? '' : ' · 현재 TXT에서 확인 필요'}` });
    fillOptions(element.querySelector('[data-field="NewGuid"]'), options, row.NewGuid, matches.length ? '검색 결과에서 신규 정의를 선택하세요.' : '검색 결과가 없습니다.');
    element.querySelector('[data-new-search-count]').textContent = `${matches.length} / ${definitions.length}개`;
  }
  function filterSources(element) {
    const editor = state.editor, fromTxt = editor.sourceMode === 'txt', parameters = sourceParameters();
    const search = element.querySelector('[data-source-search]'), picker = element.querySelector('[data-source-picker]');
    const words = searchWords(search.value), row = editor.draft;
    const selected = parameters.findIndex(item => row.OldGuid ? text(read(item, 'Guid')).toLowerCase() === row.OldGuid.toLowerCase() : row.OldParameterId ? Number(read(item, 'Id', read(item, 'ParameterId', 0))) === row.OldParameterId : row.OldName && read(item, 'Name') === row.OldName);
    const matches = parameters.map((item, index) => ({ item, index })).filter(({ item }) => includesWords([read(item, 'Name'), read(item, 'Group', read(item, 'GroupName')), read(item, 'Guid')].join(' '), words));
    const label = item => [read(item, 'Name'), fromTxt ? read(item, 'Group', read(item, 'GroupName')) : '', read(item, 'Guid') || 'ID ' + read(item, 'Id')].filter(Boolean).join(' · ');
    fillOptions(picker, matches.map(({ item, index }) => ({ value: index, label: label(item) })), selected < 0 ? '' : selected, matches.length ? '검색 결과에서 기존 정의를 선택하세요.' : fromTxt && !editor.sourcePath ? '기존 공유 TXT를 선택하세요.' : '검색 결과가 없습니다. 아래에 직접 입력할 수 있습니다.');
    picker.setAttribute('aria-label', fromTxt ? '기존 공유 TXT의 파라미터' : '활성 문서의 기존 파라미터');
    search.placeholder = fromTxt ? '이름 · 그룹 · GUID 검색' : '활성 문서의 이름 또는 GUID 검색';
    element.querySelector('[data-source-txt]').hidden = !fromTxt;
    const path = element.querySelector('[data-source-path]');
    path.textContent = editor.sourcePath ? `${leaf(editor.sourcePath)} · 정의 ${editor.sourceDefinitions.length}개` : '기존 정의가 있는 공유 TXT를 선택하세요.'; path.title = editor.sourcePath;
    element.querySelector('[data-source-search-count]').textContent = `${matches.length} / ${parameters.length}개`;
  }
  function sourceParameters() { return state.editor.sourceMode === 'txt' ? state.editor.sourceDefinitions : editorCatalog().currentParameters; }
  function pickSourceDefinitions(button, useRevitConfiguration = false) {
    if (busy() || state.checkpointLoaded || !state.editor) return;
    const body = $('[data-editor-body]');
    sourceRequest = { editor: state.editor, button, top: body.scrollTop, left: body.scrollLeft, interaction: interactionVersion };
    state.editor.notice = '';
    if (!request('pick-definitions', { role: 'source', path: state.editor.sourcePath, useRevitConfiguration }, 'pick-source-definitions')) {
      finishSourceRequest('Revit 연결을 확인하세요.');
    }
  }
  function finishSourceRequest(message = '') {
    const pending = sourceRequest; sourceRequest = null;
    if (state.pending === 'pick-source-definitions') state.pending = '';
    if (pending?.editor === state.editor) state.editor.notice = message;
    sync();
    // Only restore the picker that initiated this request; a closed editor or a
    // later user interaction owns its own focus and scroll position.
    if (pending?.editor === state.editor && pending.interaction === interactionVersion) {
      const body = $('[data-editor-body]'); body.scrollTop = pending.top; body.scrollLeft = pending.left;
      if (!pending.button.disabled) pending.button.focus({ preventScroll: true });
    }
  }
  function syncRow(row, element) {
    // Same-GUID edits update the existing project binding. Keep this local draft
    // transition out of checkpoint loading so legacy requests remain immutable.
    if (!state.checkpointLoaded && state.editor?.draft === row) {
      if (sameParameterGuid(row)) {
        state.editor.categoryScope ||= { ...mappingScope(row), AddIfMissing: row.AddIfMissing };
        if (!categoryModes.includes(row.CategoryBindingMode)) row.CategoryBindingMode = 'extend';
        row.ApplyProject = true; row.ApplyFamilies = false; row.AddIfMissing = false;
      } else {
        if (state.editor.categoryScope) { Object.assign(row, state.editor.categoryScope); state.editor.categoryScope = null; if (state.familyDefinitionsOnly) forceDefinitionScope(row); }
        row.CategoryBindingMode = 'inherit';
      }
    }
    const categoryUpdate = isCategoryScopeUpdate(row);
    const add = row.Mode === 'add'; element.querySelector('[data-old-fields]').hidden = add;
    element.querySelector('[data-scope]').value = row.ApplyProject && row.ApplyFamilies ? 'both' : row.ApplyFamilies ? 'families' : 'project';
    element.querySelector('[data-field="IsInstance"]').value = categoryUpdate || row.IsInstance == null ? '' : text(row.IsInstance);
    element.querySelector('[data-category-binding-wrap]').hidden = !categoryUpdate;
    element.querySelector('[data-field="CategoryBindingMode"]').value = row.CategoryBindingMode;
    element.querySelector('[data-category-binding-note]').hidden = !categoryUpdate;
    element.querySelector('[data-category-binding-note]').textContent = categoryDescription(row.CategoryBindingMode);
    element.querySelector('[data-category-removal-note]').hidden = !categoryUpdate || row.CategoryBindingMode === 'extend';
    element.querySelector('[data-category-removal-note]').textContent = row.CategoryBindingMode === 'remove' ? '선택한 카테고리에서는 이 프로젝트 파라미터가 사라집니다. 최종 범위가 비면 적용할 수 없습니다.' : '체크를 해제한 카테고리에서는 이 프로젝트 파라미터가 사라집니다.';
    element.querySelector('[data-family-target-wrap]').hidden = !row.ApplyFamilies;
    element.querySelector('[data-project-scope-wrap]').hidden = false;
    element.querySelector('[data-field="IsInstance"] option[value=""]').disabled = add;
    element.querySelector('[data-category-wrap]').hidden = !(categoryUpdate || add && (row.ApplyProject || row.ApplyFamilies) || row.AddIfMissing && row.ApplyProject);
    element.querySelector('[data-category-heading]').textContent = categoryUpdate ? row.CategoryBindingMode === 'replace' ? '최종 프로젝트 카테고리 적용 범위' : row.CategoryBindingMode === 'remove' ? '기존 범위에서 제외할 카테고리' : '프로젝트 카테고리 적용 범위 갱신' : row.ApplyProject ? '추가할 프로젝트 카테고리' : '대상 패밀리 카테고리';
    element.querySelector('[data-add-missing-wrap]').hidden = add || categoryUpdate;
    element.querySelector('[data-field="AddIfMissing"]').checked = !!row.AddIfMissing;
    element.querySelector('[data-add-dummy-wrap]').hidden = !row.ApplyFamilies || (!add && !row.AddIfMissing);
    element.querySelector('[data-add-dummy-root-wrap]').hidden = !row.ApplyFamilies || (!add && !row.AddIfMissing);
    element.querySelector('[data-family-group-wrap]').hidden = !add || !(row.ApplyProject || row.ApplyFamilies);
    element.querySelector('[data-family-group-inherit-note]').hidden = add || !(row.ApplyProject || row.ApplyFamilies);
    element.querySelector('[data-group-values-wrap]').hidden = !add || !row.ApplyProject || row.IsInstance !== true;
    element.querySelectorAll('[data-field="VariesAcrossGroups"]').forEach(control => { control.checked = (control.value === 'true') === !!row.VariesAcrossGroups; });
    element.querySelector('[data-dummy-replace-note]').hidden = !row.ApplyFamilies || add;
    element.querySelector('[data-new-guid]').textContent = row.NewGuid ? `GUID ${row.NewGuid}` : '신규 정의의 GUID를 기준으로 처리합니다.';
    element.querySelector('[data-selected-definition]').textContent = row.NewGuid ? `선택: ${row.NewName || row.NewGuid}` : '선택한 신규 정의가 없습니다.';
    element.querySelector('[data-category-count]').textContent = `${list(row.CategoryIds).length}개 선택`;
    const catalog = new Map(editorCatalog().categories.map(item => [Number(read(item, 'Id')), item]));
    const categoryNames = list(row.CategoryIds).map(id => {
      const category = catalog.get(Number(id));
      return category ? [read(category, 'ParentName'), read(category, 'Name')].filter(Boolean).join(' › ') : `ID ${id}`;
    });
    const summary = element.querySelector('[data-category-summary]');
    summary.textContent = categoryNames.length ? categoryNames.slice(0, 3).join(', ') + (categoryNames.length > 3 ? ` 외 ${categoryNames.length - 3}개` : '') : editorCatalog().categories.length ? '카테고리 선택을 눌러 적용할 항목을 지정하세요.' : '활성 프로젝트를 연 뒤 새로고침하세요.';
    summary.title = categoryNames.join('\n');
  }
  function mountEditor(row) {
    const element = div('parammigration-mapping');
    element.innerHTML = `<div class="parammigration-row-options"><label class="parammigration-field"><span>작업</span><select data-field="Mode"><option value="replace">기존 정의 교체</option><option value="add">신규 추가</option></select></label><label class="parammigration-field" data-project-scope-wrap><span>적용 범위</span><select data-scope><option value="both">프로젝트 + 패밀리</option><option value="project">프로젝트만</option><option value="families">패밀리만</option></select></label><label class="parammigration-field"><span>값 구분</span><select data-field="IsInstance"><option value="">기존 방식 유지</option><option value="true">인스턴스</option><option value="false">타입</option></select></label></div>
      <label class="parammigration-field" data-family-target-wrap><span>패밀리 적용 범위</span><select data-field="FamilyTargetKind"><option value="compound">복합패밀리만</option><option value="standalone">단일 패밀리만</option><option value="all">복합 + 단일 패밀리</option></select></label>
      <div data-old-fields><div class="parammigration-source-toolbar"><label class="parammigration-field"><span>기존 파라미터 찾기</span><select data-source-mode aria-label="기존 파라미터 선택 위치"><option value="active">활성 문서</option><option value="txt">기존 공유 TXT</option></select></label><div class="parammigration-source-txt" data-source-txt hidden><p class="parammigration-note parammigration-path" data-source-path></p><div class="parammigration-actions"><button type="button" class="secondary" data-pick-source-definitions>기존 TXT 선택</button><button type="button" class="secondary" data-use-revit-source-definitions>Revit 설정 TXT 사용</button></div></div></div><label class="parammigration-field"><span class="parammigration-source-search-label">검색 결과 <small data-source-search-count></small></span><input type="text" data-source-search placeholder="활성 문서의 이름 또는 GUID 검색" autocomplete="off" aria-label="기존 파라미터 검색"><select data-source-picker size="3" aria-label="활성 문서의 기존 파라미터"></select></label><div class="parammigration-source-fields"><label class="parammigration-field"><span>기존 이름</span><input type="text" data-field="OldName" placeholder="이름 또는 GUID를 입력하세요."></label><label class="parammigration-field"><span>기존 GUID</span><input type="text" data-field="OldGuid" placeholder="선택 사항"></label></div></div>
      <label class="parammigration-field"><span>신규 공유파라미터 찾기 <small data-new-search-count></small></span><input type="text" data-new-search placeholder="이름 · 그룹 · GUID 검색" autocomplete="off" aria-label="신규 공유파라미터 검색"><select data-field="NewGuid" size="4" aria-label="신규 공유파라미터 검색 결과"></select><strong class="parammigration-selection" data-selected-definition></strong><small data-new-guid></small></label>
      <label class="parammigration-field" data-category-binding-wrap hidden><span>카테고리 적용 방식</span><select data-field="CategoryBindingMode"><option value="extend">기존 범위에 추가</option><option value="remove">기존 범위에서 제외</option><option value="replace">선택한 범위로 재설정</option></select></label>
      <p class="parammigration-note" data-category-binding-note hidden></p>
      <p class="parammigration-note" data-category-removal-note hidden>체크를 해제한 카테고리에서는 이 프로젝트 파라미터가 사라집니다.</p>
      <label class="parammigration-toggle" data-add-missing-wrap><input type="checkbox" data-field="AddIfMissing"><span>기존 정의가 없는 대상에도 신규 추가</span></label>
      <label class="parammigration-field" data-family-group-wrap hidden><span>신규 파라미터 그룹</span><select data-field="FamilyGroupKey" aria-describedby="parammigration-family-group-note"></select><small id="parammigration-family-group-note">신규 추가 시 선택한 적용 범위의 프로젝트·패밀리 파라미터에 같은 그룹을 적용합니다.</small></label>
      <p class="parammigration-note" data-family-group-inherit-note>기존 정의 교체는 프로젝트·패밀리의 원래 파라미터 그룹을 각각 유지합니다.</p>
      <fieldset data-group-values-wrap hidden><legend>신규 프로젝트 파라미터의 그룹 값</legend><label class="parammigration-toggle"><input type="radio" name="parammigration-group-values" data-field="VariesAcrossGroups" value="false"><span>그룹 유형별로 값 정렬</span></label><label class="parammigration-toggle"><input type="radio" name="parammigration-group-values" data-field="VariesAcrossGroups" value="true"><span>그룹 인스턴스마다 값이 달라질 수 있음</span></label></fieldset>
      <label class="parammigration-toggle" data-add-dummy-root-wrap hidden><input type="checkbox" data-field="AddToDummyRootFamilies"><span>이름에 Dummy가 포함된 상위 복합패밀리에 이 파라미터 신규 추가</span></label>
      <label class="parammigration-toggle" data-add-dummy-wrap hidden><input type="checkbox" data-field="AddToDummyFamilies"><span>Dummy 하위 패밀리에 이 파라미터 신규 추가</span></label>
      <p class="parammigration-note" data-dummy-replace-note>Dummy에 이미 정의된 변경 대상 파라미터는 신규 추가 옵션과 관계없이 변경합니다.</p>
      <section class="parammigration-category-summary" data-category-wrap hidden><div><strong><span data-category-heading>추가할 프로젝트 카테고리</span> <span class="parammigration-count" data-category-count>0개 선택</span></strong><p class="parammigration-note" data-category-summary></p></div><button type="button" class="secondary" data-pick-categories>카테고리 선택…</button></section>`;
    // Populate once from this editor's catalog. Host refreshes never replace a
    // focused select or its ancestors while the settings dialog is open.
    const groupPicker = element.querySelector('[data-field="FamilyGroupKey"]');
    groupPicker.add(new Option('기본 그룹 사용', ''));
    const groups = list(editorCatalog().parameterGroups);
    groups.forEach(group => { const key = text(read(group, 'Key', read(group, 'Id'))); if (key) groupPicker.add(new Option(text(read(group, 'Label', key)), key)); });
    if (row.FamilyGroupKey && ![...groupPicker.options].some(option => option.value === row.FamilyGroupKey)) groupPicker.add(new Option(`등록한 그룹: ${row.FamilyGroupKey}`, row.FamilyGroupKey));
    element.querySelectorAll('[data-field]').forEach(control => {
      const key = control.dataset.field;
      if (control.type === 'checkbox') control.checked = !!row[key]; else if (control.type === 'radio') control.checked = (control.value === 'true') === !!row[key]; else control.value = row[key] == null ? '' : text(row[key]);
      control.addEventListener(control.tagName === 'INPUT' && !['checkbox', 'radio'].includes(control.type) ? 'input' : 'change', () => {
        if (control.type === 'radio' && !control.checked) return;
        const previousCategoryMode = row.CategoryBindingMode;
        state.editor.notice = '';
        row[key] = control.type === 'checkbox' ? control.checked : control.type === 'radio' ? control.value === 'true' : key === 'IsInstance' ? control.value === '' ? null : control.value === 'true' : control.value;
        if (key === 'OldName' || key === 'OldGuid') row.OldParameterId = 0;
        if (key === 'Mode' && row.Mode === 'add' && row.IsInstance == null) { row.IsInstance = true; element.querySelector('[data-field="IsInstance"]').value = 'true'; }
        if (key === 'NewGuid') row.NewName = text(read(editorCatalog().definitions.find(def => text(read(def, 'Guid')) === row.NewGuid), 'Name'));
        if (key === 'CategoryBindingMode') {
          const selections = state.editor.categorySelections ||= new Map(), identity = guidIdentity(row.OldGuid);
          selections.set(`${identity}/${previousCategoryMode}`, [...list(row.CategoryIds)]);
          const previous = selections.get(`${identity}/${row.CategoryBindingMode}`);
          if (previous) row.CategoryIds = [...previous];
          else if (row.CategoryBindingMode === 'replace') {
            const binding = editorCatalog().currentParameters.find(item => guidIdentity(read(item, 'Guid')) === identity);
            row.CategoryIds = [...list(read(binding, 'CategoryIds', []))];
          } else row.CategoryIds = [];
        }
        syncRow(row, element); sync();
      });
    });
    const scope = element.querySelector('[data-scope]'); scope.value = row.ApplyProject && row.ApplyFamilies ? 'both' : row.ApplyFamilies ? 'families' : 'project';
    scope.addEventListener('change', () => { if (busy() || state.checkpointLoaded || state.familyDefinitionsOnly || isCategoryScopeUpdate(row)) return; row.ApplyProject = scope.value !== 'families'; row.ApplyFamilies = scope.value !== 'project'; syncRow(row, element); sync(); });
    const sourceMode = element.querySelector('[data-source-mode]'); sourceMode.value = state.editor.sourceMode;
    sourceMode.addEventListener('change', () => {
      const editor = state.editor, search = element.querySelector('[data-source-search]');
      editor.sourceSearches[editor.sourceMode] = search.value; editor.sourceMode = sourceMode.value;
      sourceCatalog.mode = editor.sourceMode;
      search.value = editor.sourceSearches[editor.sourceMode] || ''; editor.notice = '';
      filterSources(element); sync();
    });
    element.querySelector('[data-pick-source-definitions]').addEventListener('click', event => pickSourceDefinitions(event.currentTarget));
    element.querySelector('[data-use-revit-source-definitions]').addEventListener('click', event => pickSourceDefinitions(event.currentTarget, true));
    element.querySelector('[data-source-picker]').addEventListener('change', event => {
      if (event.target.value === '') return;
      const source = sourceParameters()[Number(event.target.value)]; if (!source) return;
      row.OldName = text(read(source, 'Name')); row.OldGuid = text(read(source, 'Guid')); row.OldParameterId = state.editor.sourceMode === 'txt' ? 0 : Number(read(source, 'Id', read(source, 'ParameterId', 0)));
      state.editor.notice = '';
      element.querySelector('[data-field="OldName"]').value = row.OldName; element.querySelector('[data-field="OldGuid"]').value = row.OldGuid; syncRow(row, element); sync();
    });
    element.querySelector('[data-pick-categories]').addEventListener('click', event => {
      if (busy() || state.checkpointLoaded || state.categoryPicker) return;
      state.categoryPicker = openProjectCategoryPicker({ categories: editorCatalog().categories, selectedIds: list(row.CategoryIds), trigger: event.currentTarget,
        onApply: ids => { if (busy() || state.checkpointLoaded || !state.editor || state.editor.draft !== row) return false; row.CategoryIds = ids; state.editor.notice = ''; syncRow(row, element); sync(); },
        onClose: () => { state.categoryPicker = null; }
      });
    });
    [['[data-new-search]', () => filterDefinitions(row, element)], ['[data-source-search]', () => filterSources(element)]].forEach(([selector, filter]) => {
      const control = element.querySelector(selector);
      control.addEventListener('input', event => { if (!event.isComposing) filter(); });
      control.addEventListener('compositionend', filter);
    });
    $('[data-editor-body]').replaceChildren(element); updateRowCatalog(row, element);
    // Stable keys are also useful for diagnostics; live edits never replace these nodes.
    element.querySelectorAll('input,select,summary').forEach((control, index) => { control.dataset.parammigrationFocusKey = control.dataset.field || `editor-${index}`; });
    return element;
  }
  function mountRow(row) {
    const element = div('parammigration-summary-row'); element.dataset.mappingKey = row.Key;
    element.innerHTML = `<label class="parammigration-row-selection"><input type="checkbox" data-select-mapping><span class="parammigration-row-number" data-row-title></span></label><div class="parammigration-summary-text"><strong data-row-name></strong><span data-row-meta></span></div><span class="parammigration-status" data-row-status></span><div class="parammigration-actions"><button type="button" class="secondary" data-edit-mapping>수정</button><button type="button" class="secondary" data-remove-mapping>제거</button></div>`;
    element.querySelector('[data-select-mapping]').addEventListener('change', event => { if (event.target.checked) selectedMappings.add(row.Key); else selectedMappings.delete(row.Key); syncSelection(); });
    element.querySelector('[data-edit-mapping]').addEventListener('click', event => openEditor(row, event.currentTarget));
    element.querySelector('[data-remove-mapping]').addEventListener('click', () => {
      const index = state.mappings.indexOf(row);
      state.mappings.splice(index, 1); rowElements.delete(row.Key); selectedMappings.delete(row.Key); sourceModes.delete(row.Key); normalScopes.delete(row.Key); element.remove(); renumber(); saveRecent(); sync();
      const next = rowElements.get(state.mappings[Math.min(index, state.mappings.length - 1)]?.Key)?.querySelector('[data-edit-mapping]');
      (next || $('[data-add-mapping]')).focus({ preventScroll: true });
    });
    rowElements.set(row.Key, element); $('[data-mappings]').append(element); updateSummary(row); renumber();
  }
  function updateSummary(row) {
    const element = rowElements.get(row.Key); if (!element) return;
    const categoryUpdate = isCategoryScopeUpdate(row);
    const from = row.Mode === 'add' ? '신규 추가' : row.OldName || row.OldGuid || '기존 정의 미지정';
    const name = categoryUpdate ? `${from} · 프로젝트 카테고리 적용 범위 갱신` : `${from} → ${row.NewName || '신규 정의 미지정'}`;
    element.querySelector('[data-row-name]').textContent = name;
    element.querySelector('[data-row-name]').title = name;
    const familyGroup = state.parameterGroups.find(group => text(read(group, 'Key', read(group, 'Id'))) === row.FamilyGroupKey);
    element.querySelector('[data-row-meta]').textContent = [row.ApplyProject && row.ApplyFamilies ? '프로젝트 + 패밀리' : row.ApplyFamilies ? '패밀리' : '프로젝트', row.ApplyFamilies ? familyTargetNames[row.FamilyTargetKind] : '', categoryUpdate ? categorySummaryNames[row.CategoryBindingMode] : '', categoryUpdate || row.IsInstance == null ? '기존 방식 유지' : row.IsInstance ? '인스턴스' : '타입', row.AddIfMissing ? '없는 대상에도 추가' : '', row.Mode === 'add' && (row.ApplyProject || row.ApplyFamilies) && row.FamilyGroupKey ? `파라미터 그룹: ${text(read(familyGroup, 'Label', row.FamilyGroupKey))}` : '', row.Mode === 'add' && row.ApplyProject && row.IsInstance === true ? (row.VariesAcrossGroups ? '그룹 인스턴스별 값 허용' : '그룹 유형별 값 정렬') : '', row.ApplyFamilies && (row.Mode === 'add' || row.AddIfMissing) ? (row.AddToDummyRootFamilies ? 'Dummy 상위 추가 포함' : 'Dummy 상위 추가 제외') : '', row.ApplyFamilies && (row.Mode === 'add' || row.AddIfMissing) ? (row.AddToDummyFamilies ? 'Dummy 하위 추가 포함' : 'Dummy 하위 추가 제외') : '', list(row.CategoryIds).length ? `카테고리 ${row.CategoryIds.length}개` : ''].filter(Boolean).join(' · ');
    element.querySelector('[data-select-mapping]').checked = selectedMappings.has(row.Key);
    element.querySelector('[data-select-mapping]').setAttribute('aria-label', `${name} 선택`);
    const errors = mappingProblems(row), badge = element.querySelector('[data-row-status]');
    badge.textContent = errors.length ? '설정 필요' : '등록됨'; badge.dataset.tone = errors.length ? 'warning' : 'ready'; badge.title = errors.join('\n');
    element.querySelector('[data-edit-mapping]').setAttribute('aria-label', `${name} ${state.checkpointLoaded ? '상세 보기' : '수정'}`);
    element.querySelector('[data-remove-mapping]').setAttribute('aria-label', `${name} 제거`);
  }
  function renumber() { state.mappings.forEach((row, i) => { const title = rowElements.get(row.Key)?.querySelector('[data-row-title]'); if (title) title.textContent = `${i + 1}`; }); }
  function openEditor(row, trigger) {
    if (busy() || state.editor || state.localDialog) return;
    const draft = row ? { ...row, CategoryIds: [...list(row.CategoryIds)] } : newMapping();
    const normalScope = normalScopes.get(draft.Key) || mappingScope(draft);
    if (state.familyDefinitionsOnly) forceDefinitionScope(draft);
    // Match selections against the same catalog the user sees. A Host refresh may
    // reorder its arrays while the editor is open; its indices must never drift.
    state.editor = { draft, normalScope, original: row, trigger, element: null, sourceMode: sourceModes.get(draft.Key) || sourceCatalog.mode, sourceDefinitions: [...sourceCatalog.definitions], sourcePath: sourceCatalog.path, sourceSearches: {}, notice: '', catalog: { definitions: [...state.definitions], currentParameters: [...state.currentParameters], categories: [...state.categories], parameterGroups: [...state.parameterGroups] } };
    $('[data-editor-title]').textContent = state.checkpointLoaded ? '등록한 파라미터 상세' : row ? '파라미터 수정' : '파라미터 등록';
    $('[data-editor-description]').textContent = state.checkpointLoaded ? '작업에 사용한 정의와 적용 범위를 확인하세요.' : '기존 정의와 신규 정의를 연결하고 적용 범위를 선택하세요.';
    $('[data-editor-apply]').textContent = row ? '적용' : '등록';
    state.editor.element = mountEditor(draft); sync();
    $('[data-mapping-dialog]').showModal();
    (state.checkpointLoaded ? $('[data-editor-close]') : $('[data-editor-body] [data-field="Mode"]')).focus({ preventScroll: true });
  }
  function closeEditor(restoreFocus = true) {
    if (!state.editor) return;
    state.categoryPicker?.close(false);
    const trigger = state.editor.trigger; state.editor = null; state.composing = false;
    $('[data-mapping-dialog]').close(); $('[data-editor-body]').replaceChildren();
    if (restoreFocus && !state.disposed && trigger?.isConnected && !trigger.disabled) trigger.focus({ preventScroll: true });
    refreshCatalogRows();
    if (!state.disposed) sync();
  }
  function applyEditor() {
    if (!state.editor || busy() || state.checkpointLoaded || mappingProblems(state.editor.draft).length) return;
    const { draft, original } = state.editor;
    if (state.familyDefinitionsOnly) { normalScopes.set(draft.Key, isCategoryScopeUpdate(draft) ? mappingScope(draft) : { ...state.editor.normalScope }); forceDefinitionScope(draft); }
    sourceModes.set(draft.Key, state.editor.sourceMode);
    if (original) { Object.assign(original, draft, { CategoryIds: [...draft.CategoryIds] }); updateSummary(original); }
    else { state.mappings.push(draft); mountRow(draft); }
    closeEditor(); saveRecent(); sync();
  }
  function categoryDescription(mode) {
    const action = mode === 'replace' ? '선택한 카테고리를 최종 적용 범위로 설정합니다.' : mode === 'remove' ? '각 문서의 기존 범위에서 선택한 카테고리를 제외합니다.' : '기존 카테고리를 유지하고 선택한 카테고리를 추가합니다.';
    return `${action} 이름·GUID·타입/인스턴스·그룹 설정은 유지합니다.`;
  }
  function syncSelection() {
    const keys = new Set(state.mappings.map(row => row.Key));
    [...selectedMappings].forEach(key => { if (!keys.has(key)) selectedMappings.delete(key); });
    const checkbox = $('[data-select-mappings]');
    checkbox.checked = !!keys.size && selectedMappings.size === keys.size;
    checkbox.indeterminate = !!selectedMappings.size && selectedMappings.size < keys.size;
    checkbox.disabled = busy() || state.checkpointLoaded || !keys.size;
    $('[data-selected-mappings]').textContent = `${selectedMappings.size}개 선택`;
    $('[data-bulk-categories]').disabled = busy() || state.checkpointLoaded || !selectedMappings.size;
  }
  function loadPreferences() {
    try {
      const value = JSON.parse(localStorage.getItem(preferenceKey) || 'null');
      if (!value || typeof value !== 'object') return { SchemaVersion: 1, Recent: null, Presets: [] };
      return { SchemaVersion: 1, Recent: value.Recent ? migrationPortableSettings(value.Recent) : null,
        Presets: list(value.Presets).filter(item => text(read(item, 'Name')).trim() && read(item, 'Settings', null)).map(item => ({ Name: text(read(item, 'Name')).trim().slice(0, 64), Settings: migrationPortableSettings(read(item, 'Settings')) })) };
    } catch { return { SchemaVersion: 1, Recent: null, Presets: [] }; }
  }
  function syncPresets() {
    if (state.disposed || state.composing || document.activeElement === $('[data-preset-picker]')) { preferencesPending = true; return; }
    preferencesPending = false;
    const picker = $('[data-preset-picker]'), selected = picker.value;
    fillOptions(picker, preferences.Presets.map(item => ({ value: item.Name, label: item.Name })), selected, preferences.Presets.length ? '불러올 설정을 선택하세요.' : '저장한 설정이 없습니다.');
  }
  function storePreferences(next, message = '') {
    const serialized = JSON.stringify(next);
    if (serialized.length > 240000) { $('[data-settings-note]').textContent = '설정 저장 용량을 초과했습니다. 저장한 설정을 줄이거나 설정 파일로 저장하세요. 현재 편집 내용은 유지됩니다.'; return false; }
    try { localStorage.setItem(preferenceKey, serialized); preferences = next; lastPreferences = serialized; syncPresets(); if (message) $('[data-settings-note]').textContent = message; return true; }
    catch { $('[data-settings-note]').textContent = '설정을 기억하지 못했습니다. 현재 편집 내용은 유지됩니다. 설정 파일로 저장하세요.'; return false; }
  }
  function saveRecent() {
    if (state.disposed || state.checkpointLoaded || state.running) return;
    clearTimeout(saveTimer); saveTimer = 0;
    storePreferences({ ...preferences, Recent: currentSettings() });
  }
  function onSharedPreferences(event) {
    const detail = event?.detail, keys = [...list(detail?.keys), ...(detail?.key ? [detail.key] : []), ...Object.keys(detail?.values || {})];
    if (keys.length && !keys.includes(preferenceKey)) return;
    const next = loadPreferences(), serialized = JSON.stringify(next);
    if (serialized === lastPreferences) return;
    preferences = next; lastPreferences = serialized; syncPresets();
    $('[data-settings-note]').textContent = '다른 Revit 창의 저장한 설정이 갱신되었습니다. 현재 편집 내용은 유지됩니다. 불러오기를 누르면 적용 범위를 선택할 수 있습니다.';
    sync();
  }
  function openLocalDialog(title, description, trigger, kind) {
    if (busy() || state.checkpointLoaded || state.editor || state.localDialog) return null;
    const node = document.createElement('dialog'); node.className = 'parammigration-editor parammigration-card parammigration-bulk-dialog'; node.dataset.localDialog = kind;
    node.innerHTML = '<header><div><h2 data-local-title></h2><p class="parammigration-note" data-local-description></p></div><button type="button" class="secondary" data-local-close aria-label="창 닫기">닫기</button></header><div class="parammigration-editor-body" data-local-body tabindex="0" role="region" aria-label="일괄 설정 내용"></div><footer><p class="parammigration-note" data-local-message aria-live="polite"></p><div class="parammigration-actions"><button type="button" class="secondary" data-local-cancel>취소</button><button type="button" data-local-apply>적용</button></div></footer>';
    node.querySelector('[data-local-title]').textContent = title; node.querySelector('[data-local-description]').textContent = description;
    const modal = { node, trigger, kind, body: node.querySelector('[data-local-body]'), message: node.querySelector('[data-local-message]'), apply: node.querySelector('[data-local-apply]'), update: null };
    state.localDialog = modal; workspace.append(node);
    node.querySelectorAll('[data-local-close],[data-local-cancel]').forEach(button => button.addEventListener('click', () => closeLocalDialog()));
    node.addEventListener('cancel', event => { event.preventDefault(); closeLocalDialog(); });
    return modal;
  }
  function showLocalDialog(modal) {
    if (!modal) return;
    sync(); modal.node.showModal(); (modal.body.querySelector('input,select,button') || modal.node.querySelector('[data-local-close]')).focus({ preventScroll: true });
  }
  function closeLocalDialog(restoreFocus = true) {
    const modal = state.localDialog; if (!modal) return;
    state.categoryPicker?.close(false); state.localDialog = null; state.composing = false;
    modal.node.close(); modal.node.remove();
    if (restoreFocus && !state.disposed && modal.trigger?.isConnected && !modal.trigger.disabled) modal.trigger.focus({ preventScroll: true });
    refreshCatalogRows(); if (!state.disposed) sync();
  }
  function sharedParameters(parameters) {
    return [...new Map(parameters.filter(item => guidIdentity(read(item, 'Guid'))).map(item => [guidIdentity(read(item, 'Guid')), { Name: text(read(item, 'Name')), Guid: text(read(item, 'Guid')), CategoryIds: [...list(read(item, 'CategoryIds', []))] }])).values()];
  }
  function openRegistration(trigger) {
    const modal = openLocalDialog('카테고리 변경 파라미터 일괄 등록', '같은 GUID의 프로젝트 카테고리만 변경할 파라미터를 선택하세요. 등록한 뒤 카테고리를 일괄 설정합니다.', trigger, 'register');
    if (!modal) return;
    const catalogs = { active: sharedParameters(state.currentParameters), txt: sharedParameters(state.definitions) }, checked = new Map(), existing = new Set(state.mappings.flatMap(row => [guidIdentity(row.OldGuid), guidIdentity(row.NewGuid)]).filter(Boolean));
    modal.body.innerHTML = '<div class="parammigration-bulk-search"><label class="parammigration-field"><span>파라미터 목록</span><select data-register-source><option value="active">현재 프로젝트의 공유파라미터</option><option value="txt">선택한 공유 TXT</option></select></label><label class="parammigration-field"><span>이름·GUID 검색</span><input type="text" data-register-search placeholder="여러 단어로 검색"></label></div><div class="parammigration-actions"><label class="parammigration-toggle"><input type="checkbox" data-register-visible><span>검색 결과 전체 선택</span></label><span class="parammigration-note" data-register-count></span></div><div class="parammigration-parameter-choices" data-register-list tabindex="0" role="region" aria-label="등록할 공유파라미터 목록"></div><p class="parammigration-note" data-register-empty></p>';
    const source = modal.body.querySelector('[data-register-source]'), search = modal.body.querySelector('[data-register-search]'), visiblePicker = modal.body.querySelector('[data-register-visible]'), container = modal.body.querySelector('[data-register-list]');
    let sourceRows = [], matches = [];
    function filter() {
      const words = searchWords(search.value); matches = sourceRows.filter(entry => includesWords(`${entry.item.Name} ${entry.item.Guid}`, words));
      const matchKeys = new Set(matches.map(entry => entry.key)); sourceRows.forEach(entry => { entry.node.hidden = !matchKeys.has(entry.key); }); update();
    }
    function update() {
      const eligible = matches.filter(entry => !existing.has(entry.key));
      visiblePicker.checked = !!eligible.length && eligible.every(entry => checked.has(entry.key)); visiblePicker.indeterminate = eligible.some(entry => checked.has(entry.key)) && !visiblePicker.checked;
      visiblePicker.disabled = busy() || !eligible.length;
      modal.body.querySelector('[data-register-count]').textContent = `검색 ${matches.length}개 · 선택 ${checked.size}개`;
      modal.body.querySelector('[data-register-empty]').textContent = sourceRows.length ? matches.length ? '' : '검색 결과가 없습니다.' : source.value === 'txt' ? '공유 TXT를 선택하면 이 목록에 표시됩니다.' : '현재 프로젝트의 공유파라미터가 없습니다.';
      modal.message.textContent = checked.size ? `선택한 ${checked.size}개를 등록하고 카테고리를 지정하세요. 대상 RVT마다 기존 바인딩을 다시 확인합니다.` : '등록할 파라미터를 하나 이상 선택하세요.';
      modal.apply.disabled = busy() || !checked.size;
      sourceRows.forEach(entry => { entry.control.checked = checked.has(entry.key); entry.control.disabled = busy() || existing.has(entry.key); });
    }
    function mountSource() {
      sourceRows = catalogs[source.value].map(item => {
        const key = guidIdentity(item.Guid), node = document.createElement('label'); node.className = 'parammigration-parameter-choice';
        node.innerHTML = '<input type="checkbox"><span><strong></strong><small></small></span>'; const control = node.querySelector('input');
        control.setAttribute('aria-label', `${item.Name} 선택`); node.querySelector('strong').textContent = item.Name || '(이름 없음)';
        node.querySelector('small').textContent = `${item.Guid}${existing.has(key) ? ' · 이미 등록됨' : ''}`;
        control.addEventListener('change', () => { if (control.checked) checked.set(key, item); else checked.delete(key); update(); });
        return { key, item, node, control };
      });
      container.replaceChildren(...sourceRows.map(entry => entry.node)); filter();
    }
    source.addEventListener('change', mountSource);
    search.addEventListener('input', event => { if (!event.isComposing) filter(); }); search.addEventListener('compositionend', filter);
    visiblePicker.addEventListener('change', () => { matches.filter(entry => !existing.has(entry.key)).forEach(entry => { if (visiblePicker.checked) checked.set(entry.key, entry.item); else checked.delete(entry.key); }); update(); });
    modal.update = update; modal.apply.textContent = '선택한 파라미터 등록';
    modal.apply.addEventListener('click', () => {
      if (busy() || !checked.size) return;
      checked.forEach(item => {
        const row = { ...newMapping(), OldName: item.Name, OldGuid: item.Guid, NewName: item.Name, NewGuid: item.Guid, ApplyProject: true, ApplyFamilies: false, CategoryBindingMode: 'extend' };
        state.mappings.push(row); selectedMappings.add(row.Key); mountRow(row);
      });
      closeLocalDialog(); saveRecent(); feedback(`${checked.size}개를 등록했습니다. 선택한 파라미터의 카테고리 일괄 설정을 누르세요.`); sync();
    });
    mountSource(); showLocalDialog(modal);
  }
  function openBulkCategories(trigger) {
    const selected = state.mappings.filter(row => selectedMappings.has(row.Key)), incompatible = selected.filter(row => !isCategoryScopeUpdate(row));
    const modal = openLocalDialog('선택한 파라미터의 카테고리 일괄 설정', '카테고리 변경 목록에만 적용합니다. 이름·GUID와 각 문서의 기존 파라미터 설정을 유지합니다.', trigger, 'categories');
    if (!modal) return;
    if (incompatible.length) {
      modal.body.innerHTML = '<p class="parammigration-note" data-bulk-incompatible></p>';
      modal.body.querySelector('p').textContent = `일반 교체·신규 추가 ${incompatible.length}개가 선택되어 있습니다. 이 항목의 선택을 해제한 뒤 다시 여세요. 작업 종류를 자동으로 바꾸지 않습니다.`;
      modal.update = () => { modal.apply.disabled = true; modal.message.textContent = '카테고리 변경 항목만 선택하세요.'; }; showLocalDialog(modal); return;
    }
    const initial = selected[0]?.CategoryIds?.length ? selected[0] : state.categoryDefaults;
    const categories = [...state.categories], bindings = [...state.currentParameters], draft = { mode: initial.CategoryBindingMode || 'extend', ids: [...list(initial.CategoryIds)] }, selections = new Map();
    modal.body.innerHTML = '<label class="parammigration-field"><span>기준 파라미터의 설정 가져오기</span><select data-bulk-reference></select></label><label class="parammigration-field"><span>카테고리 적용 방식</span><select data-bulk-mode><option value="extend">기존 범위에 추가</option><option value="remove">기존 범위에서 제외</option><option value="replace">선택한 범위로 재설정</option></select></label><p class="parammigration-note" data-bulk-description></p><section class="parammigration-category-summary"><div><strong data-bulk-category-count></strong><p class="parammigration-note" data-bulk-category-summary></p></div><button type="button" class="secondary" data-bulk-pick-categories>카테고리 선택…</button></section><p class="parammigration-note" data-bulk-removal></p>';
    const reference = modal.body.querySelector('[data-bulk-reference]'), mode = modal.body.querySelector('[data-bulk-mode]');
    selected.forEach(row => reference.add(new Option(row.OldName || row.OldGuid, row.Key))); mode.value = draft.mode;
    function update() {
      modal.body.querySelector('[data-bulk-description]').textContent = categoryDescription(draft.mode);
      modal.body.querySelector('[data-bulk-category-count]').textContent = `${draft.mode === 'replace' ? '최종 적용' : draft.mode === 'remove' ? '제외할' : '추가할'} 카테고리 ${draft.ids.length}개`;
      const names = draft.ids.map(id => { const item = categories.find(item => Number(read(item, 'Id')) === Number(id)); return item ? text(read(item, 'Name')) : `ID ${id} · 현재 문서에서 확인 필요`; });
      const summary = modal.body.querySelector('[data-bulk-category-summary]'); summary.textContent = names.join(', ') || '카테고리를 선택하세요.'; summary.title = names.join('\n');
      modal.body.querySelector('[data-bulk-removal]').textContent = draft.mode === 'replace' ? '모든 선택 항목의 최종 범위가 같아집니다. 기존 범위에서 빠진 카테고리의 파라미터가 사라집니다.' : draft.mode === 'remove' ? '각 RVT의 기존 범위에서 선택 항목만 제외합니다. 해당 카테고리의 파라미터가 사라지며 최종 범위가 비면 적용하지 않습니다.' : '각 RVT의 기존 범위에 선택 항목을 추가하므로 파라미터별 기존 범위의 차이를 유지합니다.';
      modal.message.textContent = draft.ids.length ? `${selected.length}개의 카테고리 변경 설정에 적용합니다.` : '카테고리를 하나 이상 선택하세요.';
      modal.apply.disabled = busy() || !draft.ids.length || !selected.length;
    }
    reference.addEventListener('change', () => { const row = selected.find(row => row.Key === reference.value); if (!row) return; draft.mode = row.CategoryBindingMode; draft.ids = [...list(row.CategoryIds)]; selections.clear(); mode.value = draft.mode; update(); });
    mode.addEventListener('change', () => {
      selections.set(draft.mode, [...draft.ids]); draft.mode = mode.value;
      draft.ids = selections.has(draft.mode) ? [...selections.get(draft.mode)] : draft.mode === 'replace' ? [...list(read(bindings.find(item => guidIdentity(read(item, 'Guid')) === guidIdentity(selected.find(row => row.Key === reference.value)?.OldGuid)), 'CategoryIds', []))] : [];
      update();
    });
    modal.body.querySelector('[data-bulk-pick-categories]').addEventListener('click', event => {
      if (busy() || state.categoryPicker) return;
      state.categoryPicker = openProjectCategoryPicker({ categories, selectedIds: draft.ids, trigger: event.currentTarget,
        onApply: ids => { if (busy() || state.localDialog !== modal) return false; draft.ids = [...ids]; update(); }, onClose: () => { state.categoryPicker = null; } });
    });
    modal.update = update; modal.apply.addEventListener('click', () => {
      if (busy() || !draft.ids.length) return;
      state.categoryDefaults = { CategoryBindingMode: draft.mode, CategoryIds: [...draft.ids] };
      selected.forEach(row => { row.CategoryBindingMode = draft.mode; row.CategoryIds = [...draft.ids]; row.ApplyProject = true; row.ApplyFamilies = false; row.AddIfMissing = false; if (normalScopes.has(row.Key)) normalScopes.set(row.Key, mappingScope(row)); updateSummary(row); });
      closeLocalDialog(); saveRecent(); feedback(`${selected.length}개에 ${categoryModeNames[draft.mode]} 설정을 적용했습니다.`); sync();
    }); showLocalDialog(modal);
  }
  function applyPortableSettings(value, append = false, parametersOnly = false) {
    const settings = migrationPortableSettings(value), incoming = settings.Mappings.map(item => ({ ...normalizeMapping(item), Key: uuid(), OldParameterId: 0 }));
    if (!append) {
      state.mappings = []; rowElements.clear(); selectedMappings.clear(); sourceModes.clear(); normalScopes.clear(); normalStage = null; $('[data-mappings]').replaceChildren();
      // Excel contains a parameter list only. Its DTO defaults are not options
      // selected by the user; preserve the current common settings on replacement.
      if (!parametersOnly) { state.familyDefinitionsOnly = settings.FamilyDefinitionsOnly; state.categoryDefaults = { ...settings.CategoryDefaults, CategoryIds: [...settings.CategoryDefaults.CategoryIds] }; state.syncComment = settings.SyncComment; $('[data-sync-comment]').value = state.syncComment; }
    }
    incoming.forEach(row => { if (state.familyDefinitionsOnly) { normalScopes.set(row.Key, mappingScope(row)); forceDefinitionScope(row); } state.mappings.push(row); if (isCategoryScopeUpdate(row)) selectedMappings.add(row.Key); mountRow(row); });
    state.saveActive = false; state.stage = 'all'; state.confirmSchedulesWithoutConditionalFormatting = false;
    $('[data-save-active]').checked = false; $('[data-stage]').value = 'all'; $('[data-confirm-schedule-transition]').checked = false;
    clearResult(); sync();
  }
  function previewSettings(value, label, trigger, warnings = [], parametersOnly = false) {
    const settings = migrationPortableSettings(value), modal = openLocalDialog('설정 불러오기 확인', `${label} · ${settings.Mappings.length}개 파라미터`, trigger, 'import');
    if (!modal) return;
    modal.body.innerHTML = '<label class="parammigration-field"><span>불러올 목록 적용 방법</span><select data-settings-apply-kind><option value="replace">현재 변경 목록 교체</option><option value="append">현재 변경 목록에 추가</option></select></label><p class="parammigration-note">목록과 카테고리 설정만 가져옵니다. 대상 RVT·TXT 경로·체크포인트·자동 저장·실행 단계는 가져오지 않습니다. 불러온 뒤 직접 검토하고 실행하세요.</p><div class="parammigration-import-preview" data-import-preview tabindex="0" role="region" aria-label="불러올 파라미터 목록"></div><p class="parammigration-note" data-import-warnings></p>';
    const catalog = [...state.currentParameters, ...state.definitions], review = [];
    settings.Mappings.forEach(row => {
      const entry = document.createElement('p'); entry.textContent = `${isCategoryScopeUpdate(row) ? categoryModeNames[row.CategoryBindingMode] : row.Mode === 'add' ? '신규 추가' : '기존 정의 교체'} · ${row.OldName || row.NewName || '(이름 없음)'} · ${row.NewGuid || '(GUID 없음)'} · 카테고리 ${row.CategoryIds.length}개`;
      if (isCategoryScopeUpdate(row) && !catalog.some(item => guidIdentity(read(item, 'Guid')) === guidIdentity(row.OldGuid) && text(read(item, 'Name')) === row.OldName)) { entry.className = 'parammigration-import-review'; review.push(row.OldName || row.OldGuid); }
      modal.body.querySelector('[data-import-preview]').append(entry);
    });
    modal.body.querySelector('[data-import-warnings]').textContent = [...list(warnings).map(item => typeof item === 'string' ? item : text(read(item, 'Message', ''))), review.length ? `현재 프로젝트·TXT에서 같은 이름과 GUID를 확인하지 못한 ${review.length}개 항목을 검토하세요. GUID를 다른 정의로 바꾸지 않으며 대상 RVT별 실제 바인딩은 실행 전 다시 확인합니다.` : '', settings.Mappings.some(row => isCategoryScopeUpdate(row) && !row.CategoryIds.length) ? '카테고리가 비어 있는 항목은 불러온 뒤 일괄 설정해야 실행할 수 있습니다.' : ''].filter(Boolean).join(' ');
    modal.update = () => { modal.message.textContent = settings.Mappings.length ? '적용을 누르면 선택한 방법으로 변경 목록에 반영됩니다.' : '불러올 파라미터가 없습니다.'; modal.apply.disabled = busy() || !settings.Mappings.length; };
    modal.apply.addEventListener('click', () => { if (busy() || !settings.Mappings.length) return; const append = modal.body.querySelector('[data-settings-apply-kind]').value === 'append'; closeLocalDialog(false); applyPortableSettings(settings, append, parametersOnly); saveRecent(); feedback(`${settings.Mappings.length}개 설정을 ${append ? '추가' : '불러오기'}했습니다. 실행 전에 카테고리와 작업 대상을 확인하세요.`); trigger?.focus({ preventScroll: true }); });
    showLocalDialog(modal);
  }
  function exportSettings(format, template = false) {
    if (busy()) return;
    const categoryRows = state.mappings.filter(isCategoryScopeUpdate), parameters = template ? sharedParameters([...state.definitions, ...state.currentParameters]) : categoryRows.map(row => ({ Name: row.OldName || row.NewName, Guid: row.OldGuid }));
    if (format === 'excel' && !template && state.mappings.length !== categoryRows.length) feedback(`Excel에는 카테고리 변경 ${categoryRows.length}개만 저장합니다. 일반 교체·신규 추가 ${state.mappings.length - categoryRows.length}개는 설정 파일(JSON)로 저장할 수 있습니다.`);
    request('export-settings', { settings: currentSettings(), format, template, parameters }, 'export-settings');
  }
  function renderHosts() {
    const host = $('[data-hosts]'), desired = new Set(state.hosts.map(accRvtIdentity));
    // Keep existing rows mounted so new picker responses do not reset list scroll or focus.
    for (const [key, row] of hostElements) if (!desired.has(key)) { row.remove(); hostElements.delete(key); }
    state.hosts.forEach((path, index) => {
      const key = accRvtIdentity(path); let row = hostElements.get(key);
      if (!row) {
        row = div('parammigration-file');
        const name = document.createElement('span'), badge = document.createElement('small'), remove = document.createElement('button');
        name.className = 'parammigration-file-name'; badge.className = 'parammigration-file-kind'; remove.type = 'button'; remove.className = 'secondary'; remove.textContent = '제거';
        remove.addEventListener('click', () => {
          if (busy() || state.checkpointLoaded) return;
          const next = row.nextElementSibling?.querySelector('button') || row.previousElementSibling?.querySelector('button') || $('[data-pick-targets]');
          state.hosts = state.hosts.filter(item => accRvtIdentity(item) !== key); renderHosts(); sync(); next?.focus({ preventScroll: true });
        });
        row.append(name, badge, remove); hostElements.set(key, row); host.append(row);
      }
      row.title = targetLabel(path); row.dataset.targetIdentity = key;
      row.querySelector('span').textContent = targetName(path); row.querySelector('small').textContent = isAccRvt(path) ? 'ACC' : 'RVT';
      row.querySelector('button').setAttribute('aria-label', `${targetName(path)} 제거`);
      if (host.children[index] !== row) host.insertBefore(row, host.children[index] || null);
    });
  }
  let resultGeneration = 0;
  const elapsedClock = createMigrationElapsedClock();
  const activityState = createMigrationActivityState();
  let elapsedTimer = null, progressPresentation = null;
  function resetProgressClock() {
    if (elapsedTimer != null) clearInterval(elapsedTimer);
    elapsedTimer = null; progressPresentation = null; elapsedClock.reset(); activityState.reset();
    renderLiveActivity();
  }
  function closeProgress() {
    resetProgressClock();
    if (state.progressOwner != null) ProgressDialog.hide(state.progressOwner);
    state.progressOwner = null; state.progressKind = '';
  }
  function openProgress(kind) {
    closeProgress(); state.progressKind = kind;
    const exporting = kind === 'export-result';
    const exportMessage = state.checkpointPath ? '결과 Excel의 저장 위치를 선택하세요.' : '내보낼 체크포인트와 Excel 저장 위치를 선택하세요.';
    state.progressOwner = ProgressDialog.show(exporting ? '공유파라미터 변경 결과 Excel' : '공유파라미터 통합 변경', exporting ? exportMessage : '선택한 실행 단계를 준비하고 있습니다.');
    ProgressDialog.setActions(exporting ? {} : { onCancel: pause, cancelLabel: '체크포인트 저장 후 정지' }, state.progressOwner);
    ProgressDialog.setActionState({ cancelDisabled: !state.running, statusText: exporting ? '' : '실행 준비가 끝나면 정지를 요청할 수 있습니다.' }, state.progressOwner);
    ProgressDialog.updateIndeterminate(exporting ? exportMessage : '선택한 실행 단계를 준비하고 있습니다.', exporting ? '마지막으로 저장된 체크포인트의 전체 결과를 저장합니다.' : `실행 범위: ${currentStageNames()[state.stage]}`, state.progressOwner);
  }
  function updateProgressDialog() {
    if (!progressPresentation || !state.running || state.progressKind !== 'run' || !ProgressDialog.isOwner(state.progressOwner)) return;
    const { total, completed, subtitle, beforeElapsed, afterElapsed } = progressPresentation;
    const currentActivity = $('[data-progress-activity]').hidden ? '' : $('[data-progress-activity]').textContent;
    const activityAge = $('[data-progress-activity-age]').hidden ? '' : $('[data-progress-activity-age]').textContent;
    const detail = [currentActivity ? `처리 묶음: ${subtitle}` : '', activityAge, ...beforeElapsed, $('[data-progress-elapsed]').textContent, ...afterElapsed].filter(Boolean).join('\n');
    if (total > 0 && completed < total) ProgressDialog.update(Math.min(99, completed / total * 100), currentActivity || subtitle, detail, state.progressOwner);
    else ProgressDialog.updateIndeterminate(currentActivity || subtitle, detail, state.progressOwner);
  }
  function renderLiveActivity() {
    const activity = state.running && state.progressKind === 'run' ? activityState.read() : null;
    const current = $('[data-progress-activity]'), age = $('[data-progress-activity-age]');
    current.hidden = age.hidden = !activity;
    current.textContent = activity ? migrationActivityLabel(activity) : '';
    age.textContent = activity ? `마지막 작업 알림 ${activity.ageSeconds.toLocaleString()}초 전 · 실행 시간과 별도로 표시됩니다.` : '';
  }
  function bindActivity(payload, result) {
    activityState.bind(read(result, 'RunId'), read(payload, 'ActivitySessionId'));
    renderLiveActivity();
  }
  function renderProgress(result) {
    const progress = read(result, 'Progress', null);
    const total = number(read(progress, 'TotalUnits', 0)), completed = number(read(progress, 'CompletedUnits', 0));
    const stage = text(read(progress, 'Stage')), item = text(read(progress, 'CurrentItem'));
    $('[data-progress-text]').textContent = [currentStageNames()[stage] || stage, item].filter(Boolean).join(' · ') || text(read(result, 'Message', '작업을 진행하고 있습니다.'));
    $('[data-progress-work]').textContent = total ? `현재 단계 완료 확정: ${completed.toLocaleString()} / ${total.toLocaleString()}개${state.running && completed >= total ? ' · 마무리 중' : ''}` : state.running ? '처리할 작업량을 확인하고 있습니다.' : '이 기록에는 작업량 정보가 없습니다.';
    const totalValues = number(read(progress, 'TotalValues', 0)), processedValues = number(read(progress, 'ProcessedValues', 0));
    $('[data-progress-values]').hidden = !totalValues && !processedValues;
    $('[data-progress-values]').textContent = !processedValues && totalValues && !['compare', 'verify'].includes(stage) ? `분석한 값: ${totalValues.toLocaleString()}개` : `${stage === 'compare' ? '준비 후 값 비교' : stage === 'verify' ? '값 검증' : '현재 값 처리'}: ${processedValues.toLocaleString()}${totalValues ? ` / ${totalValues.toLocaleString()}` : ''}개`;
    elapsedClock.sync(read(progress, 'ElapsedSeconds', 0), !!progress && state.running && state.progressKind === 'run');
    $('[data-progress-elapsed]').textContent = progress ? `누적 실행 시간: ${duration(elapsedClock.read())}` : '이 기록에는 실행 시간 정보가 없습니다.';
    const savedAt = text(read(progress, 'LastCheckpointAt')), savedUnits = number(read(progress, 'CheckpointCompletedUnits', 0)), checkpointStage = text(read(progress, 'CheckpointStage'));
    const date = savedAt ? new Date(savedAt) : null, savedTime = date && !Number.isNaN(date.getTime()) ? date.toLocaleString('ko-KR') : savedAt;
    const persistenceNote = migrationPersistenceNote(result, { mode: state.mode, saveActive: state.saveActive, running: state.running, stage, requestedStage: state.stage, familyDefinitionsOnly: state.familyDefinitionsOnly });
    const checkpointNote = savedAt ? `마지막 복구 저장: ${savedTime} · ${currentStageNames()[checkpointStage] || checkpointStage || '작업'} ${savedUnits.toLocaleString()}개 처리 시점${state.running ? ' · 이후 처리 내용은 다음 복구 저장 시 반영됩니다.' : ''}` : '';
    $('[data-progress-checkpoint]').textContent = [checkpointNote, persistenceNote].filter(Boolean).join(' · ');
    progressPresentation = null;
    if (progress && state.running && state.progressKind === 'run') {
      const files = list(read(result, 'Files', []));
      const subtitle = `${currentStageNames()[stage] || stage || '작업 준비'} · ${item || text(read(result, 'Message', '작업을 진행하고 있습니다.'))}`;
      progressPresentation = { total, completed, subtitle,
        beforeElapsed: [files.length > 1 ? `대상 문서 ${files.length.toLocaleString()}개 · 표시 비율은 현재 단계 기준입니다.` : '표시 비율은 현재 단계 기준입니다.', $('[data-progress-work]').textContent, $('[data-progress-values]').hidden ? '' : $('[data-progress-values]').textContent],
        afterElapsed: [savedAt ? `마지막 복구 저장: ${savedTime}` : '', persistenceNote, '처리 수는 현재 처리 단위가 끝난 뒤 갱신됩니다.'] };
      renderLiveActivity(); updateProgressDialog();
      if (elapsedTimer == null) elapsedTimer = setInterval(() => {
        if (state.disposed || !page.isConnected || !state.running || state.progressKind !== 'run') { resetProgressClock(); return; }
        // Never rerender results/settings from the timer: preserve editors,
        // focus and every scroll position during a long native operation.
        $('[data-progress-elapsed]').textContent = `누적 실행 시간: ${duration(elapsedClock.read())}`;
        renderLiveActivity();
        updateProgressDialog();
      }, 1000);
    } else if (elapsedTimer != null) {
      clearInterval(elapsedTimer); elapsedTimer = null;
    }
  }
  function appendIssue(parent, issue) {
    const note = div('parammigration-issue'); note.dataset.severity = isError(issue) ? 'error' : read(issue, 'Resolved', false) ? 'resolved' : isInfo(issue) ? 'info' : 'warning';
    const heading = document.createElement('strong'); heading.textContent = [read(issue, 'Resolved', false) ? '해결됨' : isError(issue) ? '오류' : isInfo(issue) ? '안내' : isWarning(issue) ? '경고' : '확인', currentStageNames()[read(issue, 'Stage')] || read(issue, 'Stage'), scopeNames[read(issue, 'Scope')] || read(issue, 'Scope'), read(issue, 'Parameter')].filter(Boolean).join(' · ');
    const message = document.createElement('p'); message.textContent = text(read(issue, 'Message'));
    const remedy = document.createElement('p'); remedy.textContent = text(read(issue, 'Remedy'));
    note.append(heading, message, remedy);
    [['ObjectId', '요소 ID'], ['UniqueId', '고유 ID'], ['Expected', '기대 값'], ['Actual', '실제 값']].forEach(([key, label]) => { if (read(issue, key)) { const line = document.createElement('p'); line.textContent = `${label}: ${read(issue, key)}`; note.append(line); } }); parent.append(note);
  }
  function appendMappingSummaries(parent, file) {
    const mappings = list(read(file, 'MappingSummaries', [])); if (!mappings.length) return;
    const section = div('parammigration-mapping-results');
    const heading = document.createElement('strong'); heading.textContent = '매핑별 처리 결과'; section.append(heading);
    mappings.forEach(mapping => {
      const row = div('parammigration-mapping-result'); row.dataset.mappingResult = text(read(mapping, 'MappingKey'));
      const categoryMode = read(mapping, 'CategoryBindingMode'), categoryUpdate = categoryModes.includes(categoryMode);
      const title = document.createElement('strong'); title.textContent = categoryUpdate ? `${read(mapping, 'OldName') || read(mapping, 'NewName') || '공유파라미터'} · 프로젝트 카테고리 적용 범위 갱신` : `${read(mapping, 'OldName') || '신규 추가'} → ${read(mapping, 'NewName') || '신규 정의'}`;
      const scope = document.createElement('p'); scope.textContent = [read(mapping, 'ApplyProject', false) ? `프로젝트: ${statusNames[read(mapping, 'ProjectStatus')] || read(mapping, 'ProjectStatus') || '대기'}` : '', read(mapping, 'ApplyFamilies', false) ? `패밀리: 적용 ${number(read(mapping, 'AppliedFamilyUnits')).toLocaleString()} · 변경 없음 ${number(read(mapping, 'UnchangedFamilyUnits')).toLocaleString()} · 실패 ${number(read(mapping, 'FailedFamilyUnits')).toLocaleString()} / 대상 ${number(read(mapping, 'PlannedFamilyUnits')).toLocaleString()}개` : ''].filter(Boolean).join(' · ');
      const values = document.createElement('p'); values.textContent = categoryUpdate ? `카테고리 ${categoryMode === 'replace' ? '범위 재설정' : categoryMode === 'remove' ? '제외' : '추가'}: 추가 ${number(read(mapping, 'AddedBindingCategories')).toLocaleString()}개 · 제외 ${number(read(mapping, 'RemovedBindingCategories')).toLocaleString()}개 · 유지 카테고리 값 보존 ${number(read(mapping, 'PreservedBindingValues')).toLocaleString()}개` : state.familyDefinitionsOnly ? '객체 입력값 유지 제외 · 수집·백업·복원·이관·유지 검사 생략' : `객체 입력값: 이관 ${number(read(mapping, 'MigratedValues')).toLocaleString()} · 기존 유지 ${number(read(mapping, 'RetainedValues')).toLocaleString()} · 검증 ${number(read(mapping, 'VerifiedValues')).toLocaleString()}개`;
      const issues = document.createElement('p'); issues.textContent = `오류 ${number(read(mapping, 'ErrorCount')).toLocaleString()} · 경고 ${number(read(mapping, 'WarningCount')).toLocaleString()}개`;
      row.append(title, scope, values, issues); section.append(row);
    }); parent.append(section);
  }
  function renderResult(result) {
    state.result = result; const files = list(read(result, 'Files', [])); $('[data-results]').hidden = !files.length; $('[data-result-count]').textContent = `${files.length}개 문서`;
    const host = $('[data-result-files]'), generation = ++resultGeneration;
    // Result controls remain mounted. Preserve expansion and every scroll ancestor
    // when only the changing result region is replaced, including compact layouts.
    const open = new Map([...host.querySelectorAll('details[data-detail-key]')].map(el => [el.dataset.detailKey, el.open]));
    const scrollers = new Set([host, workspace, aside, document.scrollingElement]); for (let node = root; node; node = node.parentElement) scrollers.add(node);
    const scrolls = [...scrollers].filter(Boolean).map(node => ({ node, top: node.scrollTop, left: node.scrollLeft }));
    const active = document.activeElement, focusKey = active?.dataset?.detailKey;
    host.replaceChildren();
    const issuesByFile = displayIssues(files), displayed = issuesByFile.flat().length, issueTotal = files.reduce((sum, file) => sum + totalIssues(file), 0), errorTotal = files.reduce((sum, file) => sum + unresolvedErrors(file), 0);
    $('[data-result-summary]').textContent = `전체 확인 사항 ${issueTotal.toLocaleString()}개 · 미해결 오류 ${errorTotal.toLocaleString()}개. 검색과 필터는 화면에 받은 ${displayed.toLocaleString()}개 항목에 적용됩니다.`;
    if (issueTotal > displayed) { const notice = div('parammigration-note'); notice.dataset.issueLimit = '200'; notice.textContent = `확인 사항 총 ${issueTotal.toLocaleString()}개 중 ${displayed}개를 표시합니다. 미해결 오류를 우선 표시하고 나머지는 최근 항목입니다. 전체 기록은 CSV 로그와 체크포인트 파일에서 확인하세요.`; host.append(notice); }
    const runLogPath = text(read(result, 'LogPath'));
    if (runLogPath) { const log = div('parammigration-note'); log.dataset.logPath = ''; log.textContent = `전체 로그: ${runLogPath}`; host.append(log); }
    files.map((file, index) => ({ file, index })).sort((a, b) => Number(hasFileError(b.file)) - Number(hasFileError(a.file)) || a.index - b.index).forEach(({ file, index: fileIndex }) => {
      const card = div('parammigration-result-file'); card.dataset.status = read(file, 'Status');
      const fileKey = text(read(file, 'Path')) || text(fileIndex);
      const title = document.createElement('strong'); title.textContent = `${read(file, 'Name', targetName(read(file, 'Path')))} · ${statusNames[read(file, 'Status')] || read(file, 'Status')}`;
      const message = document.createElement('p'); message.textContent = text(read(file, 'Message'));
      const persistence = document.createElement('p'); persistence.className = 'parammigration-note'; persistence.textContent = `원본 문서 저장 상태: ${persistenceNames[read(file, 'PersistenceStatus')] || read(file, 'PersistenceStatus', '확인 필요')}`;
      const stages = div('parammigration-stages'); list(read(file, 'Stages', [])).filter(stage => !state.familyDefinitionsOnly || read(stage, 'Stage') !== 'compare').forEach(stage => { const item = document.createElement('span'); item.textContent = `${currentStageNames()[read(stage, 'Stage')] || read(stage, 'Stage')} · ${statusNames[read(stage, 'Status')] || read(stage, 'Status')}`; item.title = text(read(stage, 'Message')); stages.append(item); });
      card.append(title, message, persistence, stages); appendMappingSummaries(card, file);
      const fileLogPath = text(read(file, 'LogPath'));
      if (fileLogPath && fileLogPath !== runLogPath) { const log = div('parammigration-note'); log.dataset.logPath = ''; log.textContent = `전체 로그: ${fileLogPath}`; card.append(log); }
      const issues = issuesByFile[fileIndex], fileTotal = totalIssues(file), errorCount = unresolvedErrors(file), visibleErrors = issues.filter(isError).length;
      if (fileTotal) { const counts = div('parammigration-note'); counts.dataset.issueSummary = ''; const infoCount = read(file, 'InfoCount', null), visibleInfos = issues.filter(isInfo).length; counts.textContent = `확인 사항 ${fileTotal.toLocaleString()}개 · 미해결 오류 ${errorCount.toLocaleString()}개${read(file, 'WarningCount', null) !== null ? ` · 경고 ${number(read(file, 'WarningCount')).toLocaleString()}개` : ''}${infoCount !== null ? ` · 안내 ${number(infoCount).toLocaleString()}개` : visibleInfos ? ` · 표시된 안내 ${visibleInfos.toLocaleString()}개` : ''}`; card.append(counts); }
      if (fileTotal > issues.length) { const note = div('parammigration-note'); note.dataset.issuesOmitted = ''; note.textContent = `전체 ${fileTotal.toLocaleString()}개 중 ${issues.length}개를 받았습니다.${errorCount > visibleErrors ? ` 화면에 없는 미해결 오류 ${errorCount - visibleErrors}개가 있습니다.` : ''} 전체 로그 또는 체크포인트에서 확인하세요.`; card.append(note); }
      const search = state.issueSearch.trim().toLocaleLowerCase();
      const filtered = issues.filter(issue => (state.issueFilter === 'all' || (state.issueFilter === 'error' ? isError(issue) : state.issueFilter === 'warning' ? isWarning(issue) : state.issueFilter === 'info' ? isInfo(issue) : state.issueFilter === 'resolved' && read(issue, 'Resolved', false))) && (!search || ['Parameter', 'ObjectId', 'UniqueId', 'Message', 'Remedy', 'Expected', 'Actual', 'Scope', 'Stage'].some(key => text(read(issue, key)).toLocaleLowerCase().includes(search))));
      if (filtered.length) {
        const details = document.createElement('details'), summary = document.createElement('summary'); details.dataset.detailKey = `${fileKey}:issues`; summary.dataset.detailKey = details.dataset.detailKey;
        summary.textContent = `항목별 확인 사항 · ${filtered.length}개 표시`; details.open = open.has(details.dataset.detailKey) ? open.get(details.dataset.detailKey) : filtered.some(isError); details.append(summary);
        filtered.filter(isError).forEach(issue => appendIssue(details, issue));
        const groups = new Map(); filtered.filter(issue => !isError(issue)).forEach(issue => { const key = JSON.stringify(['Severity', 'Resolved', 'Stage', 'Scope', 'Parameter', 'Message', 'Remedy'].map(field => read(issue, field))); if (!groups.has(key)) groups.set(key, []); groups.get(key).push(issue); });
        groups.forEach((items, key) => {
          if (items.length === 1) { appendIssue(details, items[0]); return; }
          const group = document.createElement('details'), label = document.createElement('summary'); group.className = 'parammigration-issue-group'; group.dataset.detailKey = `${fileKey}:${key}`; label.dataset.detailKey = group.dataset.detailKey; group.open = open.get(group.dataset.detailKey) || false;
          label.textContent = [`${read(items[0], 'Resolved', false) ? '해결됨' : isInfo(items[0]) ? '안내' : isWarning(items[0]) ? '경고' : '확인'} ${items.length}개`, scopeNames[read(items[0], 'Scope')] || read(items[0], 'Scope'), read(items[0], 'Parameter'), read(items[0], 'Message')].filter(Boolean).join(' · '); group.append(label); items.forEach(issue => appendIssue(group, issue)); details.append(group);
        }); card.append(details);
      } else if (issues.length && (search || state.issueFilter !== 'all')) { const empty = div('parammigration-note'); empty.textContent = '현재 검색·필터에 맞는 항목이 없습니다.'; card.append(empty); }
      host.append(card);
    });
    if (focusKey) [...host.querySelectorAll('summary[data-detail-key]')].find(el => el.dataset.detailKey === focusKey)?.focus({ preventScroll: true });
    const interactionAtRender = interactionVersion;
    const restore = () => { if (generation !== resultGeneration || state.disposed || interactionAtRender !== interactionVersion) return; scrolls.forEach(({ node, top, left }) => { node.scrollTop = top; node.scrollLeft = left; }); };
    restore(); requestAnimationFrame(restore);
    const checkpoint = text(read(result, 'CheckpointPath')); if (checkpoint) { state.checkpointPath = checkpoint; state.checkpointLoaded = true; }
    state.pauseRequested = state.running && (state.pauseRequested || !!read(read(result, 'Progress', null), 'PauseRequested', false));
    renderProgress(result);
  }
  function applyRequest(value) {
    closeEditor(false);
    closeLocalDialog(false); selectedMappings.clear();
    state.familyDefinitionsOnly = read(value, 'FamilyDefinitionsOnly', false) === true;
    normalScopes.clear(); normalStage = null;
    if (state.familyDefinitionsOnly && !familyStageNames[state.stage]) { state.stage = 'all'; $('[data-stage]').value = state.stage; }
    state.mode = read(value, 'TargetKind', 'active'); state.hosts = uniqueTargets(list(read(value, 'TargetPaths', []))); state.definitionPath = text(read(value, 'DefinitionFilePath')); state.checkpointDirectory = text(read(value, 'CheckpointDirectory')); state.conflict = read(value, 'ConflictPolicy', 'stop'); state.saveActive = !!read(value, 'SaveActiveDocument', false); state.confirmSchedulesWithoutConditionalFormatting = read(value, 'ConfirmSchedulesWithoutConditionalFormatting', false) === true; state.syncComment = text(read(value, 'SyncComment', state.syncComment));
    state.mappings = list(read(value, 'Mappings', [])).map(normalizeMapping); if (state.familyDefinitionsOnly) state.mappings.forEach(forceDefinitionScope); rowElements.clear(); $('[data-mappings]').replaceChildren(); state.mappings.forEach(mountRow); renderHosts();
    $('[data-save-active]').checked = state.saveActive; $('[data-confirm-schedule-transition]').checked = state.confirmSchedulesWithoutConditionalFormatting; $('[data-sync-comment]').value = state.syncComment;
  }
  function clearResult() {
    resetProgressClock();
    state.result = null; resultGeneration++;
    $('[data-results]').hidden = true; $('[data-result-files]').replaceChildren(); $('[data-result-count]').textContent = ''; $('[data-result-summary]').textContent = '';
    $('[data-progress]').hidden = true;
    $('[data-export-path]').textContent = ''; $('[data-export-path]').hidden = true;
  }
  $$('[data-mode]').forEach(button => button.addEventListener('click', () => { state.mode = button.dataset.mode; sync(); }));
  function changeWorkflow(families) {
    if (busy() || state.checkpointLoaded || state.editor || state.localDialog || families === state.familyDefinitionsOnly) return;
    state.familyDefinitionsOnly = families;
    state.mappings.forEach(row => {
      if (families) { normalScopes.set(row.Key, mappingScope(row)); forceDefinitionScope(row); }
      else { if (normalScopes.has(row.Key)) Object.assign(row, normalScopes.get(row.Key)); normalScopes.delete(row.Key); }
      updateSummary(row);
    });
    if (families && !familyStageNames[state.stage]) { normalStage = state.stage; state.stage = 'all'; }
    else if (!families && normalStage) { state.stage = normalStage; normalStage = null; }
    $('[data-stage]').value = state.stage; saveRecent(); sync();
  }
  $$('[data-workflow]').forEach(button => {
    button.addEventListener('click', () => changeWorkflow(button.dataset.workflow === 'families'));
    button.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key) || button.disabled) return;
      event.preventDefault();
      const families = event.key === 'End' || (event.key !== 'Home' && !state.familyDefinitionsOnly);
      changeWorkflow(families); $(`[data-workflow="${families ? 'families' : 'project'}"]`).focus({ preventScroll: true });
    });
  });
  $('[data-refresh]').addEventListener('click', () => request('init', { definitionFilePath: state.definitionPath }, 'init'));
  $('[data-pick-targets]').addEventListener('click', () => request('pick-targets', {}, 'pick-targets'));
  $('[data-pick-acc-targets]').addEventListener('click', () => request('pick-targets', { source: 'acc' }, 'pick-targets'));
  $('[data-clear-targets]').addEventListener('click', () => { state.hosts = []; renderHosts(); sync(); });
  $('[data-pick-definitions]').addEventListener('click', () => request('pick-definitions', {}, 'pick-definitions'));
  $('[data-use-revit-definitions]').addEventListener('click', () => request('pick-definitions', { useRevitConfiguration: true }, 'pick-definitions'));
  $('[data-add-mapping]').addEventListener('click', event => openEditor(null, event.currentTarget));
  $('[data-select-mappings]').addEventListener('change', event => { state.mappings.forEach(row => { if (event.target.checked) selectedMappings.add(row.Key); else selectedMappings.delete(row.Key); updateSummary(row); }); syncSelection(); });
  $('[data-register-categories]').addEventListener('click', event => openRegistration(event.currentTarget));
  $('[data-bulk-categories]').addEventListener('click', event => openBulkCategories(event.currentTarget));
  $('[data-save-preset]').addEventListener('click', () => {
    if (busy() || state.checkpointLoaded) return;
    const name = $('[data-preset-name]').value.trim();
    if (!name) { $('[data-settings-note]').textContent = '저장할 설정 이름을 입력하세요.'; $('[data-preset-name]').focus({ preventScroll: true }); return; }
    if (preferences.Presets.some(item => item.Name === name) && !window.confirm(`“${name}” 설정을 현재 목록과 카테고리 설정으로 덮어쓰시겠습니까?`)) return;
    const settings = currentSettings(), next = { ...preferences, Recent: settings, Presets: [...preferences.Presets.filter(item => item.Name !== name), { Name: name, Settings: settings }] };
    if (storePreferences(next, `“${name}” 설정을 저장했습니다.`)) { $('[data-preset-picker]').value = name; sync(); }
  });
  $('[data-load-preset]').addEventListener('click', event => { const preset = preferences.Presets.find(item => item.Name === $('[data-preset-picker]').value); if (preset) previewSettings(preset.Settings, preset.Name, event.currentTarget); else $('[data-settings-note]').textContent = '불러올 설정을 선택하세요.'; });
  $('[data-load-recent]').addEventListener('click', event => { if (preferences.Recent) previewSettings(preferences.Recent, '최근 편집한 설정', event.currentTarget); });
  $('[data-delete-preset]').addEventListener('click', () => { const name = $('[data-preset-picker]').value; if (!name) return; if (storePreferences({ ...preferences, Presets: preferences.Presets.filter(item => item.Name !== name) }, `“${name}” 설정을 삭제했습니다.`)) sync(); });
  $('[data-export-settings]').addEventListener('click', () => exportSettings('json'));
  $('[data-import-settings]').addEventListener('click', () => request('import-settings', { format: 'json' }, 'import-settings'));
  $('[data-import-parameters]').addEventListener('click', () => request('import-settings', { format: 'excel' }, 'import-settings'));
  $('[data-export-parameters]').addEventListener('click', () => exportSettings('excel'));
  $('[data-export-parameter-template]').addEventListener('click', () => exportSettings('excel', true));
  $('[data-editor-apply]').addEventListener('click', applyEditor);
  $('[data-editor-cancel]').addEventListener('click', () => closeEditor());
  $('[data-editor-close]').addEventListener('click', () => closeEditor());
  $('[data-mapping-dialog]').addEventListener('cancel', event => { event.preventDefault(); closeEditor(); });
  $('[data-pick-checkpoint]').addEventListener('click', () => request('pick-checkpoint', {}, 'pick-checkpoint'));
  $('[data-pick-output-directory]').addEventListener('click', () => request('pick-output-directory', { path: state.checkpointDirectory }, 'pick-output-directory'));
  $('[data-export-result]').addEventListener('click', () => { if (busy()) return; openProgress('export-result'); if (!request('export-result', { checkpointPath: state.checkpointPath }, 'export-result')) closeProgress(); });
  function clearCheckpoint() { state.checkpointPath = ''; state.checkpointLoaded = false; state.conflict = 'stop'; clearResult(); feedback('기존 체크포인트는 유지됩니다. 현재 설정으로 새 작업을 시작합니다.'); sync(); }
  $('[data-clear-checkpoint]').addEventListener('click', () => {
    if (busy()) return;
    if (state.checkpointLoaded && state.hosts.some(isAccRvt)) {
      if (!window.confirm('저장하지 않은 ACC 변경 사항을 취소하고 새 설정으로 전환하시겠습니까?')) return;
      request('discard-cloud', { path: state.checkpointPath }, 'discard-cloud'); return;
    }
    clearCheckpoint();
  });
  $('[data-stage]').addEventListener('change', event => { state.stage = event.target.value; sync(); });
  $('[data-save-active]').addEventListener('change', event => { state.saveActive = event.target.checked; sync(); });
  $('[data-confirm-schedule-transition]').addEventListener('change', event => { state.confirmSchedulesWithoutConditionalFormatting = event.target.checked; sync(); });
  $('[data-sync-comment]').addEventListener('input', event => { state.syncComment = event.target.value; if (!event.isComposing) { clearTimeout(saveTimer); saveTimer = window.setTimeout(saveRecent, 350); } });
  $('[data-sync-comment]').addEventListener('compositionend', event => { state.syncComment = event.target.value; saveRecent(); });
  $('[data-issue-search]').addEventListener('input', event => { state.issueSearch = event.target.value; if (!event.isComposing && state.result) renderResult(state.result); });
  $('[data-issue-search]').addEventListener('compositionend', event => { state.issueSearch = event.target.value; if (state.result) renderResult(state.result); });
  $('[data-issue-filter]').addEventListener('change', event => { state.issueFilter = event.target.value; if (state.result) renderResult(state.result); });
  function run(retry) { if (busy() || problems().length) return; state.pauseRequested = false; feedback('작업을 시작하고 있습니다.'); openProgress('run'); if (!request('run', payload(retry), 'run')) closeProgress(); }
  $('[data-run]').addEventListener('click', () => run(false)); $('[data-retry]').addEventListener('click', () => run(true));
  function pause() { if (!state.running || state.pauseRequested) return; state.pauseRequested = true; if (post('parammigration:pause', {}) === false) { state.pauseRequested = false; feedback('정지 요청을 전달하지 못했습니다. Revit 연결을 확인하세요.', 'error'); } else feedback('정지를 요청했습니다. 현재 처리 단위를 마친 뒤 복구에 필요한 저장을 완료하고 정지합니다.'); sync(); }
  $('[data-pause]').addEventListener('click', pause);
  function refreshCatalogRows() {
    if (state.disposed || !state.catalogPending || state.editor || state.localDialog || state.composing) return;
    state.catalogPending = false;
    state.mappings.forEach(row => {
      updateSummary(row);
    }); sync();
  }
  workspace.addEventListener('compositionstart', () => { state.composing = true; });
  workspace.addEventListener('compositionend', () => { state.composing = false; refreshCatalogRows(); if (preferencesPending) syncPresets(); });
  workspace.addEventListener('focusout', () => queueMicrotask(() => { refreshCatalogRows(); if (preferencesPending) syncPresets(); }));
  function catalog(payload) {
    const data = read(payload, 'Catalog', payload); if (['init', 'pick-definitions'].includes(state.pending)) state.pending = ''; state.active = read(data, 'ActiveDocument', null); state.token = text(read(payload, 'ContextToken', state.token)); state.definitions = list(read(data, 'Definitions', [])); state.currentParameters = list(read(data, 'CurrentParameters', [])); state.categories = list(read(data, 'Categories', [])); state.definitionPath = text(read(data, 'DefinitionFilePath', read(payload, 'DefinitionFilePath', state.definitionPath)));
    state.parameterGroups = list(read(data, 'ParameterGroups', []));
    const signature = JSON.stringify([state.definitions, state.currentParameters, state.categories, state.parameterGroups]);
    if (signature !== state.catalogSignature) {
      state.catalogSignature = signature;
      state.catalogPending = true; refreshCatalogRows();
    }
    if (read(payload, 'Running', false)) { const restored = read(payload, 'Request', null); if (restored && !state.running) applyRequest(restored); state.running = true; state.pauseRequested = state.pauseRequested || !!read(payload, 'PauseRequested', false); if (!state.progressKind) openProgress('run'); const result = read(payload, 'Result', null); if (result) { bindActivity(payload, result); renderResult(result); } }
    if (read(data, 'DefinitionMessage')) feedback(read(data, 'DefinitionMessage'));
    sync();
  }
  listen('context', catalog); listen('definitions-loaded', catalog);
  listen('source-definitions-loaded', payload => {
    if (state.pending !== 'pick-source-definitions' || !sourceRequest) return;
    if (sourceRequest.editor === state.editor && !state.checkpointLoaded) {
      const editor = state.editor;
      editor.sourceDefinitions = list(read(payload, 'Definitions', [])); editor.sourcePath = text(read(payload, 'DefinitionFilePath'));
      sourceCatalog.definitions = [...editor.sourceDefinitions]; sourceCatalog.path = editor.sourcePath;
      filterSources(editor.element);
    }
    finishSourceRequest();
  });
  listen('targets-picked', payload => {
    if (state.running || state.checkpointLoaded || (state.pending && state.pending !== 'pick-targets')) return;
    state.pending = ''; rememberAccRvtLocations(read(payload, 'Locations', {}));
    state.hosts = uniqueTargets([...state.hosts, ...list(read(payload, 'Paths', []))]); renderHosts(); sync();
  });
  listen('output-directory-picked', payload => { if (state.pending !== 'pick-output-directory') return; state.pending = ''; state.checkpointDirectory = text(read(payload, 'Path')).trim(); feedback(state.checkpointDirectory ? '작업 기록을 저장할 폴더를 선택했습니다.' : '작업 기록을 저장할 폴더를 선택하세요.'); sync(); });
  listen('cloud-discarded', payload => { if (state.pending !== 'discard-cloud' || text(read(payload, 'Path')) !== state.checkpointPath) return; state.pending = ''; clearCheckpoint(); });
  listen('result-exported', payload => {
    if (state.pending !== 'export-result') return;
    state.pending = ''; closeProgress();
    const path = text(read(payload, 'Path')).trim();
    if (read(payload, 'Cancelled', false) || read(payload, 'Ok', true) === false || !path) {
      feedback(read(payload, 'Cancelled', false) ? '결과 Excel 저장을 취소했습니다.' : read(payload, 'Message', '저장된 결과 Excel 경로를 확인하지 못했습니다.'), read(payload, 'Cancelled', false) ? '' : 'error');
      sync(); return;
    }
    $('[data-export-path]').textContent = `저장한 결과 Excel: ${path}`; $('[data-export-path]').hidden = false;
    feedback('결과 Excel을 저장했습니다.'); sync();
    requestAnimationFrame(() => {
      if (!state.disposed && workspace.isConnected) showExcelSavedDialog('공유파라미터 통합 변경 결과 Excel을 저장했습니다.', path, savedPath => post('excel:open', { path: savedPath }));
    });
  });
  listen('checkpoint-loaded', payload => { state.pending = ''; clearResult(); applyRequest(read(payload, 'Request', {})); state.checkpointPath = text(read(payload, 'Path')); state.checkpointLoaded = true; const previousResult = read(payload, 'Result', null); if (previousResult) renderResult(previousResult); const data = read(payload, 'Catalog', null); if (data) catalog({ Catalog: data, ContextToken: read(payload, 'ContextToken', state.token) }); feedback('체크포인트를 불러왔습니다. 실행 단계를 선택하세요.'); sync(); });
  listen('settings-loaded', data => {
    if (state.pending !== 'import-settings') return;
    state.pending = ''; sync();
    if (read(data, 'Cancelled', false)) return;
    const source = text(read(data, 'Source')), settings = read(data, 'Settings', null);
    if (!settings) { feedback('불러온 설정을 확인하지 못했습니다.', 'error'); return; }
    const trigger = source.toLowerCase().includes('excel') ? $('[data-import-parameters]') : $('[data-import-settings]');
    previewSettings(settings, leaf(read(data, 'Path')) || '불러온 설정', trigger, list(read(data, 'Warnings', [])), source.toLowerCase().includes('excel'));
  });
  listen('settings-exported', data => {
    if (state.pending !== 'export-settings') return;
    state.pending = ''; const path = text(read(data, 'Path')).trim();
    const warnings = list(read(data, 'Warnings', [])).map(item => typeof item === 'string' ? item : text(read(item, 'Message'))).filter(Boolean).join(' ');
    feedback(path ? `${read(data, 'Format') === 'excel' ? 'Excel 파라미터 목록' : '설정 파일'}을 저장했습니다: ${path}${warnings ? ` · ${warnings}` : ''}` : '설정 저장을 취소했습니다.'); sync();
  });
  listen('progress', payload => { if (!state.running && state.pending !== 'run') return; state.pending = ''; state.running = true; const result = read(payload, 'Result', payload); bindActivity(payload, result); renderResult(result); sync(); });
  listen('activity', payload => {
    if (!state.running || state.progressKind !== 'run' || !activityState.accept(payload)) return;
    elapsedClock.sync(read(payload, 'ElapsedSeconds', 0), true);
    $('[data-progress-elapsed]').textContent = `누적 실행 시간: ${duration(elapsedClock.read())}`;
    renderLiveActivity(); updateProgressDialog();
  });
  listen('completed', payload => { if (state.pending === 'export-result') return; state.pending = ''; state.running = false; state.pauseRequested = false; closeProgress(); const result = read(payload, 'Result', payload); renderResult(result); feedback(read(payload, 'Message', read(result, 'Message', '처리 결과를 확인하세요.')), hasRunError(result) ? 'error' : ''); sync(); });
  listen('cancelled', payload => { const operation = text(read(payload, 'Operation')); if (operation === 'pick-source-definitions' || (!operation && state.pending === 'pick-source-definitions')) { finishSourceRequest(); return; } if (operation === 'pause') state.pauseRequested = false; if (operation === 'run') { state.running = false; state.pauseRequested = false; } if (operation === state.pending || !operation) state.pending = ''; if (operation === state.progressKind || (!operation && !state.running)) closeProgress(); sync(); });
  listen('error', payload => { const operation = text(read(payload, 'Operation')); if (operation === 'pick-source-definitions' || (!operation && state.pending === 'pick-source-definitions')) { finishSourceRequest(text(read(payload, 'Message', '기존 공유 TXT를 읽지 못했습니다.'))); return; } if (operation === state.pending || !operation) state.pending = ''; if (operation !== 'pause' && operation !== 'export-result' && !read(payload, 'Busy', false)) state.running = false; if (operation === 'pause' || !state.running) state.pauseRequested = false; if (operation === 'export-result' || (!state.running && state.progressKind === 'run')) closeProgress(); feedback(read(payload, 'Message', '작업 중 오류가 발생했습니다.'), 'error'); sync(); });
  const onRoute = () => { if (location.hash.replace(/^#/, '').split('?')[0] !== 'parammigration') { if (saveTimer) saveRecent(); clearTimeout(saveTimer); state.disposed = true; closeEditor(false); closeLocalDialog(false); resultGeneration++; closeProgress(); subscriptions.forEach(unsubscribe => unsubscribe?.()); interactionEvents.forEach(event => window.removeEventListener(event, onInteraction, true)); window.removeEventListener('kky:shared-settings-changed', onSharedPreferences); window.removeEventListener('hashchange', onRoute); } };
  window.addEventListener('hashchange', onRoute);
  window.addEventListener('kky:shared-settings-changed', onSharedPreferences);
  preferences = loadPreferences(); lastPreferences = JSON.stringify(preferences); syncPresets();
  if (preferences.Recent) { applyPortableSettings(preferences.Recent); feedback('최근 편집한 목록과 카테고리 설정을 불러왔습니다. 작업 대상과 저장 폴더를 확인하세요.'); }
  sync(); request('init', {}, 'init');
}
