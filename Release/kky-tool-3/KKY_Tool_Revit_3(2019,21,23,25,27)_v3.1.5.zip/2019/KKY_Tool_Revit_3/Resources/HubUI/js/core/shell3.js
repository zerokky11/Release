// Resources/HubUI/js/core/shell3.js
import { clear, div } from './dom.js';
import { post } from './bridge.js';
import { getTopbarState, TOPBAR_STATE_CHANGE_EVENT, toggleDocumentNavigatorSettingsPanel } from './topbar.js?v=20261012official315';
import { getCurrentTheme, THEME_CHANGE_EVENT, toggleTheme } from './theme.js?v=20260731sharedsettings3';
import { FEATURE_GROUPS3, getFeatureCounts3 } from './featureCatalog3.js?v=20260917columnnumber1';
import { WORKFLOW3_CHANGE_EVENT } from './workflowState3.js?v=20260731sharedsettings3';
import { getFavoriteEntries, HUB_QUICK_ACCESS_CHANGE_EVENT } from './hubFavorites.js?v=20260917columnnumber1';

const PRODUCT_VERSION_DISPLAY = '3.1.5';

const NAV_SECTIONS = Object.freeze([
  { id: 'start', label: '바로가기', items: ['home', 'favorites'] },
  { id: 'review', label: '검토', items: ['bqc'] },
  { id: 'tools', label: '작업 도구', items: ['utility', 'linktools', 'modeling'] },
  { id: 'data', label: '데이터 · 출력', items: ['schedule', 'nwc'] }
]);
// A submenu is a floating panel: opening it never changes the sidebar's layout.
let activeShellCleanup = null;
const NAV_ICON_PATHS = Object.freeze({
  home: '<path d="m3 10 9-7 9 7M5 9v11h5v-6h4v6h5V9"/>',
  favorites: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9Z"/>',
  bqc: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 3h6v3H9zM8 12l2 2 5-5M8 18h8"/>',
  utility: '<path d="M14 6a5 5 0 0 0-6 6L3 17a2.8 2.8 0 0 0 4 4l5-5a5 5 0 0 0 6-6l-3 3-4-4Z"/>',
  linktools: '<path d="m10 13 4-4m-6 7-1 1a4.2 4.2 0 0 1-6-6l5-5a4.2 4.2 0 0 1 6 0m0 2 1-1a4.2 4.2 0 0 1 6 6l-5 5a4.2 4.2 0 0 1-6 0" transform="translate(2 1) scale(.88)"/>',
  modeling: '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9ZM4 7.5l8 4.5 8-4.5M12 12v9M8 5.3l8 4.5"/>',
  schedule: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M9 10v10M15 10v10M3 15h18"/>',
  nwc: '<path d="M12 3v12m-4-4 4 4 4-4M4 15v5h16v-5"/>'
});

const NAV_ITEMS = Object.freeze([
  { id: 'home', label: '홈', hint: 'Home', icon: 'H', route: '' },
  { id: 'favorites', label: '즐겨찾기', hint: 'Favorite', icon: 'F', route: 'favorites' },
  {
    id: 'bqc', label: 'BQC', hint: 'BQC', icon: 'B', route: 'bqc',
    children: [
      { label: '검토', route: 'bqc' },
      { label: '결과 정리', route: 'bqc-results' }
    ]
  },
  { id: 'utility', label: '일반 도구', hint: 'General', icon: 'G', route: 'utility' },
  { id: 'linktools', label: '링크 도구', hint: 'Links', icon: 'L', route: 'linktools' },
  { id: 'modeling', label: '모델링', hint: 'Modeling', icon: 'M', route: 'modeling' },
  { id: 'schedule', label: 'Schedule 도구', hint: 'Schedule', icon: 'S', route: 'scheduleio' },
  {
    id: 'nwc',
    label: 'NWC Export',
    hint: 'NWC',
    icon: 'N',
    route: 'nwcexport',
    children: [
      { label: '3D View 일괄 추출', route: 'nwcexport' },
      { label: 'NWC 용량 비교 검토', route: 'nwccompare' }
    ]
  }
]);

export function renderShell3(root, options = {}) {
  activeShellCleanup?.();
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);

  const shell = div(`shell3 shell3--${options.layout || 'home'}`);
  const sidebar = buildSidebar(options);
  const workspace = div('shell3-workspace');
  const top = buildTopStrip(options);
  const content = div(`shell3-content shell3-content--${options.layout || 'home'}`);
  const main = div('shell3-main');
  const aside = div('shell3-aside');

  if (options.main) main.append(options.main);
  if (options.aside) {
    aside.append(options.aside);
  } else {
    aside.classList.add('is-empty');
  }

  content.append(main, aside);
  workspace.append(top, content);
  shell.append(sidebar, workspace);
  target.append(shell);

  const refresh = () => {
    if (!shell.isConnected) {
      cleanup();
      return;
    }
    refreshSidebar(sidebar, options);
    refreshTopStrip(top);
  };

  const cleanup = () => {
    sidebar._navigation?.dispose();
    window.removeEventListener(TOPBAR_STATE_CHANGE_EVENT, refresh);
    window.removeEventListener(THEME_CHANGE_EVENT, refresh);
    window.removeEventListener(WORKFLOW3_CHANGE_EVENT, refresh);
    window.removeEventListener(HUB_QUICK_ACCESS_CHANGE_EVENT, refresh);
  };

  window.addEventListener(TOPBAR_STATE_CHANGE_EVENT, refresh);
  window.addEventListener(THEME_CHANGE_EVENT, refresh);
  window.addEventListener(WORKFLOW3_CHANGE_EVENT, refresh);
  window.addEventListener(HUB_QUICK_ACCESS_CHANGE_EVENT, refresh);
  activeShellCleanup = cleanup;
  refresh();

  return { shell, main, aside, refresh, cleanup };
}

function buildSidebar(options) {
  const sidebar = div('shell3-sidebar');
  sidebar.dataset.mobileOpen = 'false';
  sidebar.innerHTML = `
    <div class="shell3-brand">
      <span class="shell3-brand__mark">K</span>
      <div>
        <strong>KKY Tool</strong>
        <span>Revit Hub 3.1.5</span>
      </div>
    </div>
    <button class="shell3-nav-mobile-toggle" type="button" aria-expanded="false" aria-controls="shell3-tools-nav"><span>도구 메뉴</span><strong data-current-menu></strong><svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true"><path d="m4 6 4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
    <nav class="shell3-nav" id="shell3-tools-nav" aria-label="도구 메뉴"></nav>`;

  const nav = sidebar.querySelector('.shell3-nav');
  const mobileToggle = sidebar.querySelector('.shell3-nav-mobile-toggle');
  sidebar._navigation = createNavigationController(sidebar);
  mobileToggle.addEventListener('click', () => {
    sidebar._navigation.close(false);
    const expanded = mobileToggle.getAttribute('aria-expanded') !== 'true';
    sidebar.dataset.mobileOpen = String(expanded);
    mobileToggle.setAttribute('aria-expanded', String(expanded));
  });
  nav.addEventListener('keydown', (event) => {
    if (event.defaultPrevented || event.key !== 'Escape' || sidebar.dataset.mobileOpen !== 'true') return;
    sidebar.dataset.mobileOpen = 'false';
    mobileToggle.setAttribute('aria-expanded', 'false');
    mobileToggle.focus({ preventScroll: true });
    event.preventDefault();
  });
  NAV_SECTIONS.forEach((section) => {
    const region = div('shell3-nav-section');
    region.dataset.navSection = section.id;
    region.setAttribute('role', 'group');
    region.setAttribute('aria-label', section.label);
    const title = div('shell3-nav-title');
    title.textContent = section.label;
    const items = div('shell3-nav-section-items');
    section.items.forEach((id) => {
      const item = NAV_ITEMS.find((entry) => entry.id === id);
      items.append(item.children?.length ? buildNavGroup(item, options) : buildNavItem(item, options));
    });
    region.append(title, items);
    nav.append(region);
  });

  refreshSidebar(sidebar, options);
  return sidebar;
}

function buildNavItem(item, options) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'shell3-nav-item';
  button.dataset.navId = item.id;
  button.dataset.navTone = item.id;
  button.title = item.label;
  button.innerHTML = `
    <span class="shell3-nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round">${NAV_ICON_PATHS[item.id]}</svg></span>
    <span>${escapeHtml(item.label)}</span>
    <em data-nav-count></em>`;
  button.addEventListener('click', () => {
    closeMobileNav(button);
    const route = item.route || '';
    location.hash = route ? `#${route}` : '';
  });
  if (item.id === options.active) button.classList.add('is-active');
  return button;
}

function buildNavGroup(item, options) {
  const group = div('shell3-nav-group');
  group.dataset.navGroup = item.id;
  group.dataset.navTone = item.id;
  const heading = div('shell3-nav-group-heading');
  const toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.className = 'shell3-nav-toggle';
  toggle.setAttribute('aria-haspopup', 'dialog');
  toggle.setAttribute('aria-controls', `shell3-submenu-${item.id}`);
  toggle.innerHTML = '<svg viewBox="0 0 16 16" width="18" height="18" aria-hidden="true"><path d="m6 4 4 4-4 4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  toggle.addEventListener('click', (event) => setNavExpanded(group, item, toggle.getAttribute('aria-expanded') !== 'true', event.detail === 0));
  heading.append(buildNavItem(item, options), toggle);
  group.append(heading);

  const submenu = div('shell3-nav-submenu');
  submenu.id = `shell3-submenu-${item.id}`;
  submenu.setAttribute('popover', 'manual');
  submenu.setAttribute('role', 'dialog');
  submenu.setAttribute('aria-modal', 'false');
  submenu.setAttribute('aria-label', `${item.label} 하위 메뉴`);
  const menuHead = div('shell3-nav-submenu-head');
  const menuTitle = document.createElement('strong');
  menuTitle.textContent = item.label;
  const menuClose = document.createElement('button');
  menuClose.type = 'button';
  menuClose.className = 'shell3-nav-submenu-close';
  menuClose.setAttribute('aria-label', `${item.label} 하위 메뉴 닫기`);
  menuClose.textContent = '×';
  menuClose.addEventListener('click', () => sidebarNavigation(group)?.close(true));
  menuHead.append(menuTitle, menuClose);
  submenu.append(menuHead);
  item.children.forEach((child) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'shell3-nav-subitem';
    button.dataset.navRoute = child.route;
    const label = document.createElement('strong');
    label.textContent = child.label;
    const arrow = document.createElement('span');
    arrow.setAttribute('aria-hidden', 'true');
    arrow.textContent = '→';
    button.append(label, arrow);
    button.addEventListener('click', () => {
      closeMobileNav(button);
      location.hash = child.route ? `#${child.route}` : '';
    });
    submenu.append(button);
  });
  group.append(submenu);
  setNavGroupState(group, item, false);
  group.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowRight' && !submenu.contains(event.target)) {
      setNavExpanded(group, item, true, true);
      event.preventDefault();
    } else if ((event.key === 'Escape' || event.key === 'ArrowLeft') && group.classList.contains('is-expanded')) {
      sidebarNavigation(group)?.close(true);
      event.preventDefault();
    } else if (submenu.contains(event.target) && ['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
      const buttons = [...submenu.querySelectorAll('.shell3-nav-subitem')];
      const current = buttons.indexOf(document.activeElement);
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1
        : (current + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length;
      buttons[next]?.focus({ preventScroll: true });
      event.preventDefault();
    }
  });
  return group;
}

function sidebarNavigation(group) { return group.closest('.shell3-sidebar')?._navigation; }

function setNavExpanded(group, item, expanded, focusFirst = false) {
  const navigation = group && sidebarNavigation(group);
  if (expanded) navigation?.open(group, item, focusFirst);
  else navigation?.close(focusFirst);
}

function setNavGroupState(group, item, expanded) {
  if (!group) return;
  group.classList.toggle('is-expanded', expanded);
  const toggle = group.querySelector('.shell3-nav-toggle');
  toggle.setAttribute('aria-expanded', String(expanded));
  toggle.setAttribute('aria-label', `${item.label} 하위 메뉴 ${expanded ? '접기' : '펼치기'}`);
  toggle.title = `${item.label} 하위 메뉴 ${expanded ? '접기' : '펼치기'}`;
  group.querySelector('.shell3-nav-submenu').hidden = !expanded;
}

function createNavigationController(sidebar) {
  let opened = null;
  let disposed = false;
  const close = (restoreFocus = false) => {
    if (!opened) return;
    const { group, item, panel, toggle } = opened;
    opened = null;
    try { if (panel.matches(':popover-open')) panel.hidePopover(); } catch {}
    setNavGroupState(group, item, false);
    if (restoreFocus && toggle.isConnected) toggle.focus({ preventScroll: true });
  };
  const position = () => {
    if (!opened) return;
    const { panel, toggle } = opened;
    const margin = 12;
    const narrow = window.matchMedia('(max-width: 860px)').matches;
    const anchor = toggle.getBoundingClientRect();
    const sidebarRect = sidebar.getBoundingClientRect();
    panel.style.width = `${Math.min(narrow ? 320 : 280, window.innerWidth - margin * 2)}px`;
    panel.style.maxHeight = `${Math.max(80, window.innerHeight - margin * 2)}px`;
    const rect = panel.getBoundingClientRect();
    const preferredLeft = narrow ? anchor.right - rect.width : sidebarRect.right + 8;
    const left = Math.max(margin, Math.min(preferredLeft, window.innerWidth - rect.width - margin));
    const preferredTop = narrow ? anchor.bottom + 6 : anchor.top - 8;
    const top = Math.max(margin, Math.min(preferredTop, window.innerHeight - rect.height - margin));
    panel.style.left = `${Math.round(left)}px`;
    panel.style.top = `${Math.round(top)}px`;
  };
  const open = (group, item, focusFirst) => {
    if (disposed) return;
    if (opened?.group !== group) close(false);
    const panel = group.querySelector('.shell3-nav-submenu');
    const toggle = group.querySelector('.shell3-nav-toggle');
    opened = { group, item, panel, toggle };
    setNavGroupState(group, item, true);
    try { if (typeof panel.showPopover === 'function' && !panel.matches(':popover-open')) panel.showPopover(); } catch {}
    position();
    if (focusFirst) panel.querySelector('.shell3-nav-subitem')?.focus({ preventScroll: true });
  };
  const pointerDown = (event) => {
    if (opened && !opened.group.contains(event.target)) close(false);
    if (sidebar.dataset.mobileOpen === 'true' && !sidebar.contains(event.target)) {
      sidebar.dataset.mobileOpen = 'false';
      sidebar.querySelector('.shell3-nav-mobile-toggle').setAttribute('aria-expanded', 'false');
    }
  };
  const focusIn = (event) => { if (opened && !opened.group.contains(event.target)) close(false); };
  const onScroll = (event) => {
    if (!opened || opened.panel.contains(event.target)) return;
    if (sidebar.contains(event.target)) position();
    else close(false);
  };
  const resize = () => close(true);
  const route = () => close(false);
  document.addEventListener('pointerdown', pointerDown, true);
  document.addEventListener('focusin', focusIn, true);
  window.addEventListener('scroll', onScroll, true);
  window.addEventListener('resize', resize);
  window.addEventListener('hashchange', route);
  return {
    open, close,
    dispose() {
      if (disposed) return;
      close(false);
      disposed = true;
      document.removeEventListener('pointerdown', pointerDown, true);
      document.removeEventListener('focusin', focusIn, true);
      window.removeEventListener('scroll', onScroll, true);
      window.removeEventListener('resize', resize);
      window.removeEventListener('hashchange', route);
    }
  };
}

function closeMobileNav(button) {
  const sidebar = button.closest('.shell3-sidebar');
  if (!sidebar) return;
  sidebar._navigation?.close(false);
  sidebar.dataset.mobileOpen = 'false';
  const toggle = sidebar.querySelector('.shell3-nav-mobile-toggle');
  toggle.setAttribute('aria-expanded', 'false');
  if (window.matchMedia('(max-width: 860px)').matches) toggle.focus({ preventScroll: true });
}

function refreshSidebar(sidebar, options) {
  const counts = getFeatureCounts3();

  sidebar.querySelectorAll('.shell3-nav-item').forEach((button) => {
    const id = button.dataset.navId;
    const active = id === options.active || (id === 'bqc' && options.active === 'bqc-results');
    button.classList.toggle('is-active', active);
    button.closest('.shell3-nav-group')?.classList.toggle('has-active-route', active);
    if (active) button.setAttribute('aria-current', button.closest('.shell3-nav-group') ? 'true' : 'page');
    else button.removeAttribute('aria-current');
    const count = button.querySelector('[data-nav-count]');
    if (!count) return;
    if (id === 'bqc') count.textContent = String(counts.bqc + counts['bqc-results']);
    else if (id === 'utility') count.textContent = String(counts.utility);
    else if (id === 'linktools') count.textContent = String(counts.linktools);
    else if (id === 'modeling') count.textContent = String(counts.modeling);
    else if (id === 'schedule') count.textContent = String(counts.schedule);
    else if (id === 'nwc') count.textContent = String(NAV_ITEMS.find((item) => item.id === 'nwc').children.length);
    else if (id === 'favorites') count.textContent = String(getFavoriteEntries().length);
  });

  const currentRoute = String(location.hash || '')
    .replace(/^#/, '')
    .split('?')[0]
    .toLowerCase();
  const activeItem = NAV_ITEMS.find((item) => item.id === options.active || (item.id === 'bqc' && options.active === 'bqc-results'));
  const currentLabel = activeItem?.children?.find((child) => child.route === currentRoute)?.label || activeItem?.label || '홈';
  const mobileLabel = sidebar.querySelector('[data-current-menu]');
  if (mobileLabel) mobileLabel.textContent = currentLabel;
  sidebar.querySelectorAll('.shell3-nav-subitem').forEach((button) => {
    const route = button.dataset.navRoute;
    const isBqc = button.closest('[data-nav-group="bqc"]');
    const active = isBqc
      ? route === (options.active === 'bqc-results' ? 'bqc-results' : options.active === 'bqc' ? 'bqc' : currentRoute)
      : button.closest('[data-nav-group="linktools"]') && options.active === 'linktools'
        ? route === (currentRoute === 'linkbatch' ? 'linkbatch' : 'linktools')
      : route === currentRoute;
    button.classList.toggle('is-active', active);
    if (active) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });

}

function buildTopStrip(options) {
  const top = div('shell3-topbar');
  top.innerHTML = `
    <div class="shell3-title">
      <h1>${escapeHtml(options.title || 'Home')}</h1>
      <p>${escapeHtml(options.subtitle || '')}</p>
    </div>
    <div class="shell3-top-actions">
      <button class="shell3-chip shell3-chip--ok shell3-chip--connection" type="button" data-shell3-conn>연결 <strong>Revit</strong></button>
      <span class="shell3-chip" data-shell3-docs>문서 <strong>0</strong></span>
      <button class="shell3-chip shell3-chip--warn" type="button" data-shell3-update>업데이트 <strong>확인</strong></button>
      <button class="shell3-chip shell3-chip--theme" type="button" data-shell3-theme aria-pressed="true">다크</button>
      <button class="shell3-chip shell3-chip--settings" type="button" data-shell3-settings>설정</button>
      <span class="shell3-chip" data-shell3-version>v3.1.5</span>
    </div>`;

  const update = top.querySelector('[data-shell3-update]');
  update?.addEventListener('click', () => post('update:check'));
  const theme = top.querySelector('[data-shell3-theme]');
  theme?.addEventListener('click', () => {
    toggleTheme();
    refreshTopStrip(top);
  });
  const settings = top.querySelector('[data-shell3-settings]');
  settings?.addEventListener('click', () => toggleDocumentNavigatorSettingsPanel(settings));
  refreshTopStrip(top);
  return top;
}

function refreshTopStrip(top) {
  const state = getTopbarState();
  const documents = Array.isArray(state.documents) ? state.documents : [];
  const activeDoc = getDocumentName(state.activeDocument);
  const version = getDisplayedVersion(state);
  const hasUpdate = !!state.update?.hasUpdate;
  const themeName = getCurrentTheme();

  const conn = top.querySelector('[data-shell3-conn]');
  if (conn) {
    conn.classList.toggle('shell3-chip--ok', !!activeDoc);
    conn.innerHTML = activeDoc
      ? `연결 <strong>${escapeHtml(activeDoc)}</strong>`
      : '연결 <strong>대기</strong>';
    conn.title = activeDoc ? `활성 문서: ${activeDoc}` : '활성 Revit 문서 연결 대기';
    conn.setAttribute('aria-label', conn.title);
  }

  const docs = top.querySelector('[data-shell3-docs]');
  if (docs) docs.innerHTML = `문서 <strong>${documents.length}</strong>`;

  const update = top.querySelector('[data-shell3-update]');
  if (update) {
    update.classList.toggle('shell3-chip--warn', hasUpdate);
    update.innerHTML = hasUpdate ? '업데이트 <strong>필요</strong>' : '업데이트 <strong>확인</strong>';
  }

  const settings = top.querySelector('[data-shell3-settings]');
  if (settings) {
    settings.classList.remove('shell3-chip--ok', 'is-off');
    settings.textContent = '설정';
    settings.title = 'KKY Tools 설정';
    settings.setAttribute('aria-label', settings.title);
    settings.setAttribute('aria-haspopup', 'dialog');
  }

  const theme = top.querySelector('[data-shell3-theme]');
  if (theme) {
    const isDark = themeName !== 'light';
    theme.classList.toggle('shell3-chip--ok', isDark);
    theme.classList.toggle('is-light', !isDark);
    theme.textContent = isDark ? '다크' : '라이트';
    theme.title = isDark ? '현재 다크 테마입니다. 클릭하면 라이트 테마로 전환합니다.' : '현재 라이트 테마입니다. 클릭하면 다크 테마로 전환합니다.';
    theme.setAttribute('aria-label', theme.title);
    theme.setAttribute('aria-pressed', isDark ? 'true' : 'false');
  }

  const versionEl = top.querySelector('[data-shell3-version]');
  if (versionEl) versionEl.textContent = version;
}

function getDocumentName(doc = {}) {
  return String(doc.name || doc.Name || doc.title || doc.Title || '').trim();
}

function getDisplayedVersion(state = getTopbarState()) {
  return formatVersion(
    state?.update?.currentVersionDisplay
    || state?.update?.currentVersion
    || PRODUCT_VERSION_DISPLAY
  );
}

function formatVersion(value) {
  const text = String(value || '').trim();
  if (!text) return 'v3.1.5';
  return /^v/i.test(text) ? text : `v${text}`;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function getShellGroupTitle3(mode) {
  const group = FEATURE_GROUPS3[mode] || FEATURE_GROUPS3.bqc;
  return {
    title: group.label,
    subtitle: group.subtitle
  };
}
