import { onHost, post } from './core/bridge.js';
import { renderLinkBatch } from './views/linkbatch.js?v=20261012standalone1';

const root = document.getElementById('view-root');
const themeButton = document.querySelector('[data-theme-toggle]');
const themeLabel = document.querySelector('[data-theme-label]');
const documentLabel = document.querySelector('[data-header-document]');
const statusLabel = document.querySelector('[data-header-status]');
const versionLabel = document.querySelector('[data-header-version]');
const themeKey = 'kky.settings.linkmanager.theme.v1';
let disposeEditor = null;

function setTheme(theme) {
  const value = theme === 'dark' ? 'dark' : 'light';
  document.documentElement.dataset.theme = value;
  try { localStorage.setItem(themeKey, value); } catch {}
  const label = value === 'light' ? '어두운 화면' : '밝은 화면';
  themeLabel.textContent = label;
  themeButton.setAttribute('aria-label', `${label}으로 전환`);
  themeButton.setAttribute('aria-pressed', String(value === 'dark'));
  post('ui:theme-changed', { theme: value });
}

try {
  window.kkyHubStartup?.phase('script-load', '링크 매니저 스크립트를 불러왔습니다.');
  let theme = 'light';
  try { theme = localStorage.getItem(themeKey) || 'light'; } catch {}
  setTheme(theme);
  window.kkyHubStartup?.phase('theme', '화면 표시 설정을 적용했습니다.');
  themeButton.addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));
  onHost('linkbatch:context', payload => {
    const active = payload?.activeDocument || {};
    documentLabel.textContent = active.title || '활성 문서 없음';
    documentLabel.title = active.displayPath || active.path || 'Revit에서 프로젝트 문서를 열면 활성 문서에 링크할 수 있습니다.';
    if (payload?.running === true) statusLabel.textContent = '진행 중인 링크 작업에 연결했습니다.';
  });
  onHost('linkbatch:progress', payload => { if (payload?.message) statusLabel.textContent = String(payload.message); });
  for (const event of ['linkbatch:completed', 'linkbatch:preflighted', 'linkbatch:error']) {
    onHost(event, payload => { statusLabel.textContent = String(payload?.message || '작업 결과를 확인하세요.'); });
  }
  onHost('host:connected', payload => {
    const version = payload?.version || payload?.buildVersion;
    if (version) versionLabel.textContent = `KKY Tools ${version} · Link Manager`;
  });
  disposeEditor = renderLinkBatch(root, { standalone: true });
  post('ui:route-changed', { route: 'linkbatch' });
  post('ui:sync-context', {});
  requestAnimationFrame(() => {
    if (!root.querySelector('.linkbatch-workspace') || !root.querySelector('[data-run]')) {
      window.kkyHubStartup?.fail('파일 등록 또는 실행 화면을 구성하지 못했습니다.');
      return;
    }
    window.kkyHubStartup?.ready('링크 매니저의 파일 등록, 설정 및 실행 화면이 준비되었습니다.');
  });
  window.addEventListener('pagehide', () => { if (typeof disposeEditor === 'function') disposeEditor(); }, { once: true });
} catch (error) {
  window.kkyHubStartup?.fail(error);
}
