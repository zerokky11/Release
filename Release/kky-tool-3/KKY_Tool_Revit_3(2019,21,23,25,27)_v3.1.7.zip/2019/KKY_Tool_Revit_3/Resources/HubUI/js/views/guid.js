import { clear, div, toast, showExcelSavedDialog, chooseExcelMode, showCompletionSummaryDialog } from '../core/dom.js?v=20260731parameterexport1';
import { refreshUiAfterHostDialog } from '../core/hostDialog.js';
import { getLastExcelExportLocale } from '../core/dom.js?v=20260731parameterexport1';
import { attachRvtDropZone } from '../core/rvtDrop.js';
import { createRvtTable, renderRvtRows, getRvtName } from './rvtTable.js?v=20260504a';
import { ProgressDialog } from '../core/progress.js';
import { post, onHost } from '../core/bridge.js';
import { getTopbarState, TOPBAR_STATE_CHANGE_EVENT } from '../core/topbar.js?v=20261012official317';

const LS_RVTS = 'kky_guid_rvts';
const LS_SETTINGS = 'kky_guid_settings';
let activeGuidSettingsCleanup = null;
let guidSessionState = null;

const HIDDEN_DETAIL_COLS = new Set(['RvtPath']);
const EXCEL_PHASE_WEIGHT = { EXCEL_INIT: 0.05, EXCEL_WRITE: 0.85, EXCEL_SAVE: 0.08, AUTOFIT: 0.02, DONE: 1, ERROR: 1 };

export function renderGuid(root) {
    activeGuidSettingsCleanup?.();
    const target = root || document.getElementById('view-root') || document.getElementById('app');
    clear(target);
    const top = document.querySelector('#topbar-root .topbar') || document.querySelector('.topbar'); if (top) top.classList.add('hub-topbar');

    const initialRvtList = loadRvtList();
    const initialSettings = loadGuidSettings();
    const previous = guidSessionState;
    const state = {
        rvtList: initialRvtList,
        rvtChecked: new Set(initialRvtList.filter(path => !previous || previous.rvtChecked.has(path))),
        project: previous?.project || { columns: [], rows: [] },
        familyNav: previous?.familyNav || { columns: [], rows: [] },
        familyDetail: previous?.familyDetail || { columns: [], rows: [] },
        activeProjectDoc: previous?.activeProjectDoc || '',
        activeFamilyDoc: previous?.activeFamilyDoc || '',
        activeFamily: previous?.activeFamily || '',
        activeTab: previous?.activeTab || 'project',
        busy: false,
        acceptRunProgress: false,
        acceptCleanupProgress: false,
        acceptExcelProgress: false,
        runId: previous?.runId || '',
        hasRun: !!previous?.hasRun,
        resultIncludeFamily: !!previous?.resultIncludeFamily,
        cleanupResult: previous?.cleanupResult || null,
        cleanupSourceExcelPath: previous?.cleanupSourceExcelPath || '',
        resultSearch: previous?.resultSearch || '',
        resultFilter: previous?.resultFilter || 'all',
        cleanupFilter: previous?.cleanupFilter || 'all',
        excelExportKind: 'review',
        includeFamily: !!initialSettings.includeFamily,
        includeAnnotation: !!initialSettings.includeAnnotation,
        closeAllWorksetsOnOpen: initialSettings.closeAllWorksetsOnOpen !== false,
        useSyncComment: !!initialSettings.useSyncComment,
        syncComment: initialSettings.syncComment || 'KKY Tools - 파라미터 GUID 정리',
        familyFilter: previous?.familyFilter || 'all',
        sharedParamStatus: null,
        rvtModalSnapshot: null
    };
    guidSessionState = state;
    const auditUi = {};
    const processButtons = {};
    const processSync = {};
    const processUi = {};
    let lastExcelPct = 0;

    const page = div('feature-shell familylink-page guid-page guid-page--main');
    page.addEventListener('kky:direct-rvt-modal', (event) => {
        if (event.detail?.key !== 'guid') return;
        if (event.detail.phase === 'open') {
            state.rvtModalSnapshot = {
                rvtList: [...state.rvtList],
                rvtChecked: new Set(state.rvtChecked)
            };
            return;
        }
        if (event.detail.phase === 'confirm') {
            state.rvtModalSnapshot = null;
            return;
        }
        if (event.detail.phase === 'cancel' && state.rvtModalSnapshot) {
            state.rvtList = [...state.rvtModalSnapshot.rvtList];
            state.rvtChecked = new Set(state.rvtModalSnapshot.rvtChecked);
            state.rvtModalSnapshot = null;
            persistRvts();
            renderRvtList();
            syncRvtActionState();
        }
    });

    // Header
    const header = div('feature-header guid-header');
    const headerLeft = div('feature-heading');
    headerLeft.innerHTML = `
      <span class="feature-kicker">등록 파라미터 관리</span>
      <h2 class="feature-title">파라미터 GUID 검토 및 정리</h2>
      <p class="feature-sub">GUID 검토 결과를 확인한 뒤, 엑셀에서 선택한 등록 파라미터를 삭제합니다.</p>`;

    header.append(headerLeft);
    page.append(header);

    const body = div('familylink-body guid-body');
    const topPanels = div('familylink-top-panels guid-top-panels');
    const leftColumn = div('guid-left-column');
    const rightColumn = div('guid-right-column');

    // GUID 검토
    const reviewSection = div('feature-results-panel guid-panel familylink-card segmentpms-extract');
    const reviewHeader = document.createElement('div');
    reviewHeader.className = 'feature-results-head familylink-results-head guid-rvt-head';
    const reviewTitle = document.createElement('div');
    reviewTitle.className = 'guid-title';
    reviewTitle.innerHTML = '<span class="guid-step-label">1 · 검토</span><h3>파라미터 GUID 검토</h3><p class="feature-note">활성 문서를 바로 검토하거나, 등록한 RVT 중 선택한 파일을 검토합니다.</p>';
    const rvtMeta = div('familylink-results-meta');
    rvtMeta.textContent = '파일 0개';
    reviewHeader.append(reviewTitle, rvtMeta);

    const reviewActions = div('familylink-rvt-actions');
    const reviewManageActions = div('feature-actions guid-action-grid guid-action-grid--primary');
    let btnRemove = null;
    let btnClear = null;
    const btnAdd = cardBtn('RVT 파일 추가', () => { if (!state.busy) post('guid:add-files', { pick: 'files' }); });
    btnAdd.classList.add('guid-btn-subtle');
    btnRemove = cardBtn('선택 제거', onRemoveSelected);
    btnRemove.disabled = true;
    btnClear = cardBtn('등록 목록 비우기', () => { if (state.busy) return; state.rvtList = []; state.rvtChecked.clear(); persistRvts(); renderRvtList(); syncRvtActionState(); });
    const runBtn = cardBtn('선택 RVT 검토', () => onRun(false));
    const activeRunBtn = cardBtn('활성 문서 검토', () => onRun(true));
    const reviewLaunch = div('guid-review-launch');
    const reviewLaunchCopy = div('guid-review-launch__copy');
    const reviewLaunchButtons = div('guid-review-launch__buttons');
    reviewLaunchButtons.append(activeRunBtn, runBtn);
    reviewLaunch.append(reviewLaunchCopy, reviewLaunchButtons);
    const exportBtn = cardBtn('삭제용 엑셀 내보내기', onExport);
    const pickCleanupExcelBtn = cardBtn('삭제용 엑셀 불러오기', onPickCleanupExcel);
    const cleanupBtn = cardBtn('선택한 파라미터 삭제', onCleanupStart);
    runBtn.classList.add('btn-primary');
    activeRunBtn.classList.add('btn-primary');
    exportBtn.classList.add('guid-btn-subtle');
    pickCleanupExcelBtn.classList.add('guid-btn-subtle');
    cleanupBtn.classList.add('guid-btn-warning');
    exportBtn.disabled = true;
    cleanupBtn.disabled = true;
    reviewManageActions.append(btnAdd, btnRemove, btnClear);
    reviewActions.append(reviewManageActions);

    const reviewHint = div('rvt-drop-hint');
    reviewHint.textContent = 'RVT 파일 추가 버튼을 누르거나 탐색기에서 .rvt 파일을 드래그하면 아래 목록에 바로 등록됩니다.';
    const inlineSettings = buildInlineSettings();
    const reviewSummary = div('feature-note guid-config-summary');
    auditUi.summary = reviewSummary;

    const rvtTableWrap = div('segmentpms-rvtlist guid-rvt-wrap rvt-drop-zone');
    const { table: rvtTable, tbody: rvtBody, master: rvtMaster } = createRvtTable();
    rvtTableWrap.append(rvtTable);
    const rvtSummary = div('segmentpms-summary');
    rvtSummary.textContent = '파일 0개';
    reviewSection.append(reviewHeader, reviewLaunch, inlineSettings, reviewSummary, reviewActions, reviewHint, rvtTableWrap, rvtSummary);
    attachRvtDropZone(rvtTableWrap, {
        onDropPaths: (paths) => {
            const added = appendDroppedRvts(paths);
            if (!added) {
                toast('이미 등록된 RVT입니다.', 'warn');
                return;
            }
            persistRvts();
            renderRvtList();
            syncRvtActionState();
            toast(`${added}개 RVT를 추가했습니다.`, 'ok');
        },
        onInvalid: () => toast('RVT 파일만 드래그해서 추가할 수 있습니다.', 'warn')
    });

    // 2단계 정리용 엑셀 반영
    const processSection = buildProcessSection(exportBtn, pickCleanupExcelBtn, cleanupBtn);
    leftColumn.append(reviewSection);
    rightColumn.append(processSection);
    topPanels.append(leftColumn, rightColumn);
    body.append(topPanels);

    const resultOverview = div('guid-result-overview');
    const reviewResultCard = div('guid-result-card');
    const reviewResultText = div('guid-result-card__copy');
    const reviewResultBtn = cardBtn('검토 결과 보기', () => openResultDialog('review'));
    reviewResultCard.append(reviewResultText, reviewResultBtn);
    const cleanupResultCard = div('guid-result-card');
    const cleanupResultText = div('guid-result-card__copy');
    const cleanupResultActions = div('guid-result-card__actions');
    const cleanupResultBtn = cardBtn('삭제 결과 보기', () => openResultDialog('cleanup'));
    const cleanupReportBtn = cardBtn('삭제 결과 엑셀 내보내기', onCleanupReportExport);
    cleanupResultActions.append(cleanupResultBtn, cleanupReportBtn);
    cleanupResultCard.append(cleanupResultText, cleanupResultActions);
    resultOverview.append(reviewResultCard, cleanupResultCard);
    body.append(resultOverview);
    [[activeRunBtn, 'active-review'], [runBtn, 'selected-review'], [btnAdd, 'add-rvts'], [reviewResultBtn, 'review-results'], [cleanupResultBtn, 'cleanup-results'], [cleanupReportBtn, 'cleanup-export'], [cleanupBtn, 'cleanup-run']].forEach(([element, name]) => element.dataset.guidRef = name);

    // Result tabs
    const tabs = div('feature-results-panel familylink-results-panel guid-results feature-tabs');
    const tabHead = div('feature-results-head familylink-results-head guid-results-head');
    const tabHeadLeft = div('guid-results-tabs');
    const tabHeadRight = div('guid-results-filters');
    const tabBtns = div('pill-tabs');
    const btnTabProject = document.createElement('button'); btnTabProject.type = 'button'; btnTabProject.className = 'pill-tab is-active'; btnTabProject.innerHTML = `<span class="pill-label">RVT 검토결과</span><span class="pill-count">0</span>`;
    const btnTabFamily = document.createElement('button'); btnTabFamily.type = 'button'; btnTabFamily.className = 'pill-tab'; btnTabFamily.innerHTML = `<span class="pill-label">패밀리 검토 결과</span><span class="pill-count">0</span>`;
    tabBtns.append(btnTabProject, btnTabFamily);
    tabHeadLeft.append(tabBtns);
    const filterBar = buildFamilyFilter();
    filterBar.classList.add('is-hidden');
    const resultFilter = document.createElement('select');
    resultFilter.className = 'guid-result-select';
    resultFilter.setAttribute('aria-label', '검토 결과 상태 필터');
    [['all', '전체 결과'], ['attention', '일치 외 결과'], ['match', 'GUID 일치'], ['failure', '처리 실패']].forEach(([value, label]) => {
        const option = document.createElement('option'); option.value = value; option.textContent = label; resultFilter.append(option);
    });
    resultFilter.value = state.resultFilter;
    resultFilter.onchange = () => { state.resultFilter = resultFilter.value; paintProject(); paintFamily(); };
    const resultSearch = document.createElement('input');
    resultSearch.type = 'search'; resultSearch.className = 'guid-result-search'; resultSearch.placeholder = '파라미터 이름·GUID·사유 검색';
    resultSearch.setAttribute('aria-label', '검토 결과 검색'); resultSearch.value = state.resultSearch;
    resultSearch.addEventListener('input', () => { state.resultSearch = resultSearch.value; paintProject(); paintFamily(); });
    resultFilter.dataset.guidRef = 'review-filter'; resultSearch.dataset.guidRef = 'review-search';
    btnTabProject.dataset.guidRef = 'project-tab'; btnTabFamily.dataset.guidRef = 'family-tab';
    tabHeadRight.append(resultFilter, resultSearch, filterBar);
    tabHead.append(tabHeadLeft, tabHeadRight);
    tabs.append(tabHead);

    const emptyState = div('guid-empty-state');
    emptyState.textContent = 'RVT를 등록한 뒤 검토를 시작해 주세요.';
    tabs.append(emptyState);

    const tabPanels = div('guid-tab-panels');
    const tabPanelProject = div('guid-tab-panel');
    const projWrap = div('guid-detail-wrap');
    const projNavPane = div('guid-detail-nav feature-results-panel guid-scroll-box');
    const projNavList = document.createElement('ul'); projNavList.className = 'guid-nav-list';
    projNavPane.append(projNavList);
    const projDetailPane = div('guid-detail-pane');
    const projContext = div('guid-result-context');
    const projTableWrap = div('guid-table-wrap guid-scroll-box');
    projTableWrap.tabIndex = 0; projTableWrap.setAttribute('aria-label', '프로젝트 검토 결과 표');
    const projTable = document.createElement('table'); projTable.className = 'guid-table';
    projTable.dataset.guidRef = 'project-table';
    const projHead = document.createElement('thead');
    const projBody = document.createElement('tbody');
    projTable.append(projHead, projBody);
    projTableWrap.append(projTable);
    projDetailPane.append(projContext, projTableWrap);
    projWrap.append(projNavPane, projDetailPane);
    tabPanelProject.append(projWrap);

    const tabPanelFamily = div('guid-tab-panel is-hidden');
    const detailWrap = div('guid-detail-wrap');
    const navPane = div('guid-detail-nav feature-results-panel guid-scroll-box');
    const navList = document.createElement('ul'); navList.className = 'guid-nav-list';
    navPane.append(navList);
    const detailPane = div('guid-detail-pane');
    const familyContext = div('guid-result-context');
    const familyUserSection = div('guid-section');
    const familyUserHeader = div('guid-section-header');
    const familyUserTitle = document.createElement('div'); familyUserTitle.className = 'guid-section-title'; familyUserTitle.textContent = '사용자 파라미터';
    const familyUserCount = document.createElement('span'); familyUserCount.className = 'guid-section-count'; familyUserCount.textContent = '0';
    familyUserHeader.append(familyUserTitle, familyUserCount);
    const familyEmpty = div('guid-empty'); familyEmpty.textContent = '파라미터가 없습니다.';
    const detailTableWrap = div('guid-table-wrap guid-scroll-box');
    detailTableWrap.tabIndex = 0; detailTableWrap.setAttribute('aria-label', '패밀리 사용자 파라미터 결과 표');
    const detailTable = document.createElement('table'); detailTable.className = 'guid-table';
    detailTable.dataset.guidRef = 'family-table';
    const detailHead = document.createElement('thead');
    const detailBody = document.createElement('tbody');
    detailTable.append(detailHead, detailBody);
    detailTableWrap.append(detailTable);
    familyUserSection.append(familyUserHeader, familyEmpty, detailTableWrap);

    const builtSection = div('guid-section');
    const builtHeader = div('guid-section-header');
    const builtTitle = document.createElement('div'); builtTitle.className = 'guid-section-title'; builtTitle.textContent = '기본 제공 파라미터';
    const builtCount = document.createElement('span'); builtCount.className = 'guid-section-count'; builtCount.textContent = '0';
    const builtToggle = document.createElement('button'); builtToggle.type = 'button'; builtToggle.className = 'pill-tab'; builtToggle.textContent = '펼치기';
    builtHeader.append(builtTitle, builtCount, builtToggle);
    const builtTableWrap = div('guid-table-wrap guid-scroll-box');
    builtTableWrap.tabIndex = 0; builtTableWrap.setAttribute('aria-label', '패밀리 기본 제공 파라미터 결과 표');
    const builtTable = document.createElement('table'); builtTable.className = 'guid-table';
    const builtHead = document.createElement('thead');
    const builtBody = document.createElement('tbody');
    builtTable.append(builtHead, builtBody);
    builtTableWrap.append(builtTable);
    builtSection.append(builtHeader, builtTableWrap);
    detailPane.append(familyContext, familyUserSection, builtSection);

    builtToggle.onclick = () => {
        builtSection.classList.toggle('is-open');
        builtToggle.textContent = builtSection.classList.contains('is-open') ? '접기' : '펼치기';
        paintFamily();
    };
    detailWrap.append(navPane, detailPane);
    tabPanelFamily.append(detailWrap);

    tabPanels.append(tabPanelProject, tabPanelFamily);
    tabs.append(tabPanels);

    const resultBackdrop = div('guid-result-backdrop is-hidden');
    const resultDialog = div('guid-result-dialog');
    resultDialog.dataset.guidRef = 'result-dialog';
    resultDialog.setAttribute('role', 'dialog'); resultDialog.setAttribute('aria-modal', 'true');
    resultDialog.setAttribute('aria-labelledby', 'guid-result-title');
    const resultDialogHeader = div('guid-result-dialog__header');
    const resultDialogHeading = div('guid-result-dialog__heading');
    const resultDialogTitle = document.createElement('h3'); resultDialogTitle.id = 'guid-result-title';
    const resultDialogSub = document.createElement('p');
    resultDialogHeading.append(resultDialogTitle, resultDialogSub);
    const resultDialogActions = div('guid-result-dialog__actions');
    const resultExportBtn = cardBtn('삭제용 엑셀 내보내기', () => resultMode === 'cleanup' ? onCleanupReportExport() : onExport());
    const resultExpandBtn = cardBtn('화면 채우기', () => {
        const expanded = resultDialog.classList.toggle('is-expanded');
        resultExpandBtn.textContent = expanded ? '창 크기 복원' : '화면 채우기';
        resultExpandBtn.setAttribute('aria-pressed', String(expanded));
    });
    resultExpandBtn.setAttribute('aria-pressed', 'false');
    const resultCloseBtn = cardBtn('닫기', () => closeResultDialog());
    resultExportBtn.dataset.guidRef = 'result-export'; resultExpandBtn.dataset.guidRef = 'result-expand'; resultCloseBtn.dataset.guidRef = 'result-close';
    resultDialogActions.append(resultExportBtn, resultExpandBtn, resultCloseBtn);
    resultDialogHeader.append(resultDialogHeading, resultDialogActions);
    const resultDialogContent = div('guid-result-dialog__content');
    resultDialogContent.tabIndex = 0; resultDialogContent.setAttribute('aria-label', '검토 및 삭제 상세 결과');
    const cleanupDetail = div('guid-cleanup-detail is-hidden');
    const cleanupSummary = div('guid-cleanup-summary');
    const cleanupToolbar = div('guid-cleanup-toolbar');
    const cleanupDetailFilter = document.createElement('select'); cleanupDetailFilter.className = 'guid-result-select';
    cleanupDetailFilter.setAttribute('aria-label', '삭제 결과 상태 필터');
    [['all', '전체 파일'], ['failure', '실패·일부 실패'], ['success', '완료·변경 없음']].forEach(([value, label]) => {
        const option = document.createElement('option'); option.value = value; option.textContent = label; cleanupDetailFilter.append(option);
    });
    cleanupDetailFilter.value = state.cleanupFilter;
    cleanupDetailFilter.dataset.guidRef = 'cleanup-filter';
    cleanupDetailFilter.onchange = () => { state.cleanupFilter = cleanupDetailFilter.value; paintCleanupResult(); };
    const cleanupSource = div('guid-result-context');
    cleanupToolbar.append(cleanupDetailFilter, cleanupSource);
    const cleanupFileResults = div('guid-cleanup-files');
    const cleanupItemHeading = document.createElement('h4'); cleanupItemHeading.textContent = '파라미터별 처리 결과';
    const cleanupItemWrap = div('guid-table-wrap guid-cleanup-items');
    cleanupItemWrap.tabIndex = 0; cleanupItemWrap.setAttribute('aria-label', '파라미터별 삭제 처리 결과 표');
    const cleanupItemTable = document.createElement('table'); cleanupItemTable.className = 'guid-table';
    cleanupItemTable.dataset.guidRef = 'cleanup-table';
    const cleanupItemHead = document.createElement('thead'); const cleanupItemBody = document.createElement('tbody');
    cleanupItemTable.append(cleanupItemHead, cleanupItemBody); cleanupItemWrap.append(cleanupItemTable);
    cleanupDetail.append(cleanupSummary, cleanupToolbar, cleanupFileResults, cleanupItemHeading, cleanupItemWrap);
    resultDialogContent.append(tabs, cleanupDetail);
    resultDialog.append(resultDialogHeader, resultDialogContent); resultBackdrop.append(resultDialog); page.append(resultBackdrop);
    let resultMode = 'review';
    let resultFocusBefore = null;
    const rowRenderVersions = new WeakMap();
    const onResultDialogKey = (event) => {
        if (resultBackdrop.classList.contains('is-hidden')) return;
        if (event.key === 'Escape') { event.preventDefault(); closeResultDialog(); return; }
        if (event.key !== 'Tab') return;
        const focusable = [...resultDialog.querySelectorAll('button:not(:disabled), input:not(:disabled), select:not(:disabled), [tabindex]:not([tabindex="-1"])')].filter(element => element.getClientRects().length > 0);
        const first = focusable[0]; const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    };
    resultBackdrop.addEventListener('click', event => { if (event.target === resultBackdrop) closeResultDialog(); });
    window.addEventListener('keydown', onResultDialogKey);
    const onActiveDocumentChanged = (event) => {
        syncRvtActionState();
        if (event?.detail?.kind === 'active-document') { state.sharedParamStatus = null; requestSharedParamStatus(); }
    };
    window.addEventListener(TOPBAR_STATE_CHANGE_EVENT, onActiveDocumentChanged);

    page.append(body);
    target.append(page);

    renderRvtList();
    syncTabState();
    syncRvtActionState();
    syncAnnotationToggle();
    syncInlineGuidSettings();
    syncAuditConfigSummary();
    syncResultState();
    paintProject();
    paintFamily();
    syncCleanupPanel();
    requestSharedParamStatus();

    let sharedSettingsTimer = 0;
    const applySharedGuidSettings = () => {
        window.clearTimeout(sharedSettingsTimer);
        if (!page.isConnected) return;
        const active = document.activeElement;
        const editing = !!active && page.contains(active) && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName || '');
        if (state.busy || editing) {
            sharedSettingsTimer = window.setTimeout(applySharedGuidSettings, 400);
            return;
        }
        const incoming = loadGuidSettings();
        state.includeFamily = !!incoming.includeFamily;
        state.includeAnnotation = !!incoming.includeAnnotation;
        state.closeAllWorksetsOnOpen = incoming.closeAllWorksetsOnOpen !== false;
        state.useSyncComment = !!incoming.useSyncComment;
        state.syncComment = incoming.syncComment || 'KKY Tools - 파라미터 GUID 정리';
        syncAnnotationToggle();
        syncInlineGuidSettings();
        syncAuditConfigSummary();
        if (processSync.checkbox) processSync.checkbox.checked = !!state.useSyncComment;
        if (processSync.input) {
            processSync.input.value = state.syncComment || '';
            processSync.input.disabled = !state.useSyncComment;
        }
        processSync.checkbox?.closest('label')?.classList.toggle('is-disabled', !state.useSyncComment);
        syncTabState();
        paintFamily();
    };
    const onSharedGuidSettingsChanged = (event) => {
        const keys = Array.isArray(event?.detail?.keys) ? event.detail.keys : [];
        if (keys.includes(LS_SETTINGS)) applySharedGuidSettings();
    };
    const cleanupSharedGuidSettings = () => {
        window.clearTimeout(sharedSettingsTimer);
        window.removeEventListener('kky:shared-settings-changed', onSharedGuidSettingsChanged);
        window.removeEventListener('hashchange', cleanupSharedGuidSettingsOnRoute);
        window.removeEventListener('keydown', onResultDialogKey);
        window.removeEventListener(TOPBAR_STATE_CHANGE_EVENT, onActiveDocumentChanged);
        closeResultDialog(false);
        if (activeGuidSettingsCleanup === cleanupSharedGuidSettings) activeGuidSettingsCleanup = null;
    };
    const cleanupSharedGuidSettingsOnRoute = () => {
        const route = String(location.hash || '').replace(/^#/, '').split('?')[0].toLowerCase();
        if (route !== 'guid') cleanupSharedGuidSettings();
    };
    activeGuidSettingsCleanup = cleanupSharedGuidSettings;
    window.addEventListener('kky:shared-settings-changed', onSharedGuidSettingsChanged);
    window.addEventListener('hashchange', cleanupSharedGuidSettingsOnRoute);

    // Host events
    onHost('guid:files', ({ paths }) => {
        const added = appendDroppedRvts(paths);
        if (added) persistRvts();
        refreshUiAfterHostDialog(() => {
            renderRvtList();
            syncRvtActionState();
        });
    });

    onHost('guid:progress', (payload) => {
        if (payload && payload.phase) {
            handleExcelProgress(payload);
        } else {
            handleRunProgress(payload);
        }
    });
    onHost('guid:cleanup-progress', handleCleanupProgress);

    onHost('guid:done', (payload) => {
        state.acceptRunProgress = false;
        ProgressDialog.hide();
        setBusy(false);
        lastExcelPct = 0;
        const proj = payload?.project || {};
        const famNav = payload?.family || payload?.familyIndex || {};
        state.runId = payload?.runId || '';
        state.hasRun = true;
        state.resultIncludeFamily = !!payload?.includeFamily;
        if (Object.prototype.hasOwnProperty.call(payload || {}, 'includeFamily')) state.includeFamily = !!payload?.includeFamily;
        if (Object.prototype.hasOwnProperty.call(payload || {}, 'includeAnnotation')) state.includeAnnotation = !!payload?.includeAnnotation;
        state.project = {
            columns: Array.isArray(proj.columns) ? proj.columns : [],
            rows: Array.isArray(proj.rows) ? proj.rows : []
        };
        state.familyNav = {
            columns: Array.isArray(famNav.columns) ? famNav.columns : [],
            rows: Array.isArray(famNav.rows) ? famNav.rows : []
        };
        state.familyDetail = { columns: [], rows: [] };
        state.activeProjectDoc = '';
        state.activeFamilyDoc = '';
        state.activeFamily = '';
        state.familyFilter = 'all';
        state.activeTab = 'project';
        syncAnnotationToggle();
        syncInlineGuidSettings();
        syncAuditConfigSummary();
        exportBtn.disabled = !hasRowsForExport();
        updateTabCounts();
        paintProject();
        paintFamily();
        syncTabState();
        syncResultState();
        requestAnimationFrame(() => showGuidCompletionDialog(payload));
        toast('검토 완료', 'ok');
    });

    onHost('guid:cleanup-done', (payload) => {
        state.acceptCleanupProgress = false;
        ProgressDialog.hide();
        setBusy(false);
        lastExcelPct = 0;
        state.cleanupSourceExcelPath = String(payload?.sourceExcelPath || state.cleanupSourceExcelPath || '').trim();
        state.cleanupResult = payload || null;
        syncCleanupPanel();
        syncResultState();
        paintCleanupResult();
        if (payload?.message) toast(payload.message, payload?.ok ? 'ok' : 'warn');
        requestAnimationFrame(() => showGuidCleanupDialog(payload));
    });
    onHost('guid:cleanup-cancelled', () => {
        refreshUiAfterHostDialog(() => {
            state.acceptCleanupProgress = false;
            ProgressDialog.hide();
            setBusy(false);
        });
    });
    onHost('guid:cleanup-excel-picked', ({ path }) => {
        refreshUiAfterHostDialog(() => {
            state.cleanupSourceExcelPath = String(path || '').trim();
            syncCleanupPanel();
        });
    });

    onHost('guid:family-detail', (payload) => {
        if (payload?.runId && state.runId && payload.runId !== state.runId) return;
        if (payload?.rvtPath && state.activeFamilyDoc && payload.rvtPath !== state.activeFamilyDoc) return;
        if (payload?.familyName && state.activeFamily && payload.familyName !== state.activeFamily) return;
        state.familyDetail = {
            columns: Array.isArray(payload?.columns) ? payload.columns : [],
            rows: Array.isArray(payload?.rows) ? payload.rows : []
        };
        state.activeFamilyDoc = payload?.rvtPath || state.activeFamilyDoc || '';
        state.activeFamily = payload?.familyName || state.activeFamily || '';
        updateTabCounts();
        paintFamily();
        syncTabState();
        syncResultState();
    });

    onHost('guid:warn', ({ message }) => {
        if (message) toast(message, 'warn');
    });

    onHost('guid:exported', ({ path }) => {
        state.acceptExcelProgress = false;
        ProgressDialog.hide();
        setBusy(false);
        lastExcelPct = 0;
        state.cleanupSourceExcelPath = String(path || state.cleanupSourceExcelPath || '').trim();
        syncCleanupPanel();
        if (path) {
            showExcelSavedDialog('파라미터 GUID 삭제용 엑셀을 저장했습니다.', path, (p) => post('excel:open', { path: p }));
        } else {
            toast('파라미터 GUID 삭제용 엑셀 내보내기를 완료했습니다.', 'ok');
        }
    });
    onHost('guid:cleanup-report-exported', ({ path, cancelled }) => {
        state.acceptExcelProgress = false;
        ProgressDialog.hide(); setBusy(false); lastExcelPct = 0;
        if (path) showExcelSavedDialog('파라미터 삭제 결과 엑셀을 저장했습니다.', path, (p) => post('excel:open', { path: p }));
        else if (!cancelled) toast('삭제 결과 엑셀을 저장하지 못했습니다.', 'warn');
    });

    const handleError = ({ message }) => {
        state.acceptRunProgress = false;
        state.acceptCleanupProgress = false;
        state.acceptExcelProgress = false;
        ProgressDialog.hide();
        setBusy(false);
        lastExcelPct = 0;
        if (message) toast(message, 'err');
    };
    onHost('guid:error', handleError);
    onHost('revit:error', handleError);
    onHost('host:error', handleError);
    onHost('sharedparam:status', (payload) => {
        state.sharedParamStatus = payload || {};
    });

    // UI handlers
    btnTabProject.onclick = () => { state.activeTab = 'project'; syncTabState(); };
    btnTabFamily.onclick = () => {
        if (!state.resultIncludeFamily) return;
        state.activeTab = 'family';
        syncTabState();
    };

    function onRun(activeOnly = false) {
        if (state.busy) return;
        if (!canRunWithSharedParam()) return;
        const activeDocument = getGuidActiveDocumentInfo();
        if (activeOnly && ((!activeDocument.name && !activeDocument.path) || activeDocument.isLinked)) {
            toast('검토할 활성 문서를 열어 주세요.', 'warn'); return;
        }
        syncAnnotationToggle();
        state.rvtList = dedupPaths(state.rvtList);
        const targets = dedupPaths(state.rvtList.filter(p => state.rvtChecked.has(p)));
        if (!activeOnly && targets.length === 0) {
            toast('선택된 RVT가 없습니다.', 'warn');
            return;
        }

        const includeFamily = !!state.includeFamily;
        const payload = {
            mode: includeFamily ? 2 : 1,
            rvtPaths: activeOnly ? [] : targets,
            includeFamily,
            includeAnnotation: includeFamily ? !!state.includeAnnotation : false,
            activeDocument
        };
        persistRvts();
        persistGuidSettings();

        setBusy(true);
        state.acceptRunProgress = true;
        state.acceptCleanupProgress = false;
        state.acceptExcelProgress = false;
        ProgressDialog.show('파라미터 GUID 검토', '검토를 준비하는 중입니다.');
        post('guid:run', payload);
    }

    function requestSharedParamStatus() {
        post('sharedparam:status', getGuidContextPayload());
    }

    function canRunWithSharedParam() {
        const status = state.sharedParamStatus || {};
        if (!status.status || status.status === 'ok') return true;
        const msg = status.warning || '공유파라미터 파일 상태가 올바르지 않습니다.';
        toast(msg, 'err');
        return false;
    }

    function onExport() {
        if (state.busy) return;
        if (!hasRowsForExport()) { toast('저장할 결과가 없습니다.', 'warn'); return; }
        closeResultDialog();
        let which = 'project';
        if (state.resultIncludeFamily) which = 'all';
        chooseExcelMode((mode) => {
            if (state.busy) return;
            const excelMode = mode || 'fast';
            state.excelExportKind = 'review';
            lastExcelPct = 0;
            setBusy(true);
            state.acceptExcelProgress = true;
            state.acceptRunProgress = false;
            state.acceptCleanupProgress = false;
            ProgressDialog.show('삭제용 엑셀 내보내기', '엑셀 파일을 만드는 중입니다.');
            post('guid:export', { which, excelMode, locale: getLastExcelExportLocale() });
        });
    }

    function onPickCleanupExcel() {
        if (state.busy) return;
        post('guid:pick-cleanup-excel', {});
    }

    function onCleanupReportExport() {
        if (state.busy) return;
        if (!state.cleanupResult?.cleanupRunId) { toast('먼저 파라미터 삭제를 실행하세요.', 'warn'); return; }
        closeResultDialog();
        chooseExcelMode((mode) => {
            if (state.busy) return;
            setBusy(true); state.acceptExcelProgress = true; state.acceptRunProgress = false; state.acceptCleanupProgress = false;
            state.excelExportKind = 'cleanup-report';
            lastExcelPct = 0;
            ProgressDialog.show('삭제 결과 엑셀 내보내기', '파일별·파라미터별 처리 결과를 작성하는 중입니다.');
            post('guid:cleanup-report-export', { cleanupRunId: state.cleanupResult.cleanupRunId, excelMode: mode || 'fast', locale: getLastExcelExportLocale() });
        });
    }

    function onCleanupStart() {
        if (state.busy) return;
        if (!state.cleanupSourceExcelPath) {
            toast('먼저 삭제용 엑셀을 불러와 주세요.', 'warn');
            return;
        }
        state.closeAllWorksetsOnOpen = true;
        persistGuidSettings();
        lastExcelPct = 0;
        setBusy(true);
        state.acceptRunProgress = false;
        state.acceptExcelProgress = false;
        state.acceptCleanupProgress = true;
        ProgressDialog.show('파라미터 GUID 정리', '삭제용 엑셀 기준으로 정리를 준비하는 중입니다.');
        post('guid:cleanup', {
            excelPath: state.cleanupSourceExcelPath,
            closeAllWorksetsOnOpen: true,
            useSyncComment: !!state.useSyncComment,
            syncComment: state.syncComment || ''
        });
    }

    function buildInlineSettings() {
        const wrap = div('guid-inline-settings');
        wrap.setAttribute('aria-label', 'GUID 검토 설정');

        const copy = div('guid-inline-settings__copy');
        copy.textContent = '검토 범위를 여기서 바로 선택합니다. 패밀리 포함을 끄면 주석 패밀리도 함께 제외됩니다.';

        const options = div('guid-inline-settings__options');
        const familyLabel = document.createElement('label');
        familyLabel.className = 'guid-checkbox-row';
        const familyText = document.createElement('span');
        familyText.textContent = '패밀리 포함';
        const familyCk = document.createElement('input');
        familyCk.type = 'checkbox';
        familyCk.checked = !!state.includeFamily;
        familyLabel.append(familyText, familyCk);

        const annotationLabel = document.createElement('label');
        annotationLabel.className = 'guid-checkbox-row';
        const annotationText = document.createElement('span');
        annotationText.textContent = '주석 패밀리 포함';
        const annotationCk = document.createElement('input');
        annotationCk.type = 'checkbox';
        annotationCk.checked = !!state.includeAnnotation;
        annotationLabel.append(annotationText, annotationCk);

        const commit = () => {
            state.includeFamily = !!familyCk.checked;
            state.includeAnnotation = state.includeFamily ? !!annotationCk.checked : false;
            persistGuidSettings();
            syncAnnotationToggle();
            syncInlineGuidSettings();
            syncAuditConfigSummary();
            syncTabState();
            paintFamily();
        };
        familyCk.addEventListener('change', commit);
        annotationCk.addEventListener('change', commit);

        auditUi.inlineSettings = wrap;
        auditUi.familyCheck = familyCk;
        auditUi.annotationCheck = annotationCk;
        auditUi.annotationLabel = annotationLabel;
        options.append(familyLabel, annotationLabel);
        wrap.append(copy, options);
        return wrap;
    }

    function buildProcessSection(exportBtn, pickCleanupExcelBtn, cleanupBtn) {
        const panel = div('feature-results-panel guid-panel familylink-card guid-process-panel');
        const head = div('feature-results-head familylink-results-head guid-process-head');
        const title = document.createElement('div');
        title.className = 'guid-title';
        title.innerHTML = '<span class="guid-step-label">2 · 삭제</span><h3>등록 파라미터 삭제</h3><p class="feature-note">검토 결과를 엑셀로 저장하고, 삭제할 행을 표시한 뒤 다시 불러와 실행합니다.</p>';
        const meta = div('familylink-results-meta');
        meta.textContent = '삭제용 엑셀 선택 필요';
        processUi.meta = meta;
        head.append(title, meta);

        const actions = div('familylink-rvt-actions guid-process-actions');
        const actionGrid = div('feature-actions guid-action-grid guid-action-grid--process');
        actionGrid.append(exportBtn, pickCleanupExcelBtn, cleanupBtn);
        actions.append(actionGrid);

        processButtons.export = exportBtn;
        processButtons.pickCleanupExcel = pickCleanupExcelBtn;
        processButtons.cleanup = cleanupBtn;

        const excelDrop = div('feature-row__summary guid-apply-drop');
        const excelLead = document.createElement('strong');
        excelLead.textContent = "선택한 삭제용 엑셀의 '삭제여부' 열에 '삭제'가 입력된 행만 정리 대상으로 적용합니다.";
        const excelPath = div('feature-note');
        excelPath.textContent = '아직 선택한 삭제용 엑셀이 없습니다.';
        processUi.path = excelPath;
        excelDrop.append(excelLead, excelPath);

        const ruleWrap = div('guid-rule-box');
        const rule = div('guid-setting-code');
        rule.innerHTML = '<span>입력 예시</span><strong>삭제여부 = 삭제</strong>';
        const ruleNote = div('feature-note');
        ruleNote.textContent = '삭제하지 않을 행은 비워 두세요. 양식의 숨겨진 식별 정보는 수정하지 마세요.';
        const openDocumentNote = div('feature-note');
        openDocumentNote.textContent = '엑셀의 대상 경로와 일치하는 저장된 RVT가 이미 열려 있으면 현재 문서에 적용합니다. 열린 문서는 자동 저장·동기화하지 않으며, 닫힌 RVT는 적용 후 저장하거나 동기화합니다.';
        ruleWrap.append(rule, ruleNote, openDocumentNote);

        const syncBlock = div('guid-process-sync');
        const syncLabel = document.createElement('label');
        syncLabel.className = 'guid-checkbox-row';
        const syncCk = document.createElement('input');
        syncCk.type = 'checkbox';
        syncCk.checked = !!state.useSyncComment;
        const syncText = document.createElement('span');
        syncText.textContent = '닫힌 RVT 동기화 시 코멘트 작성';
        syncLabel.append(syncCk, syncText);

        const syncInput = document.createElement('input');
        syncInput.type = 'text';
        syncInput.className = 'guid-text-input';
        syncInput.placeholder = '예) KKY Tools - 파라미터 GUID 정리';
        syncInput.value = state.syncComment || '';

        const syncState = () => {
            state.useSyncComment = !!syncCk.checked;
            syncInput.disabled = !state.useSyncComment;
            syncLabel.classList.toggle('is-disabled', !state.useSyncComment);
            persistGuidSettings();
        };

        syncCk.onchange = syncState;
        syncInput.addEventListener('input', () => {
            state.syncComment = syncInput.value || '';
            persistGuidSettings();
        });
        syncState();

        processSync.checkbox = syncCk;
        processSync.input = syncInput;
        processSync.sync = () => {
            syncCk.checked = !!state.useSyncComment;
            syncInput.value = state.syncComment || '';
            syncState();
        };

        const syncTitle = document.createElement('div');
        syncTitle.className = 'guid-setting-card__title';
        syncTitle.textContent = '닫힌 RVT 동기화 코멘트';
        syncBlock.append(syncLabel, syncInput);

        panel.append(head, actions, excelDrop, ruleWrap, syncTitle, syncBlock);
        return panel;
    }

    function buildFamilyFilter() {
        const bar = div('guid-filter-bar');
        const btnAll = document.createElement('button'); btnAll.type = 'button'; btnAll.className = 'pill-tab is-active'; btnAll.textContent = '전체';
        const btnShared = document.createElement('button'); btnShared.type = 'button'; btnShared.className = 'pill-tab'; btnShared.textContent = '공유';
        const btnFamily = document.createElement('button'); btnFamily.type = 'button'; btnFamily.className = 'pill-tab'; btnFamily.textContent = '패밀리';
        const sync = () => {
            btnAll.classList.toggle('is-active', state.familyFilter === 'all');
            btnShared.classList.toggle('is-active', state.familyFilter === 'shared');
            btnFamily.classList.toggle('is-active', state.familyFilter === 'family');
        };
        btnAll.onclick = () => { state.familyFilter = 'all'; sync(); paintFamily(); };
        btnShared.onclick = () => { state.familyFilter = 'shared'; sync(); paintFamily(); };
        btnFamily.onclick = () => { state.familyFilter = 'family'; sync(); paintFamily(); };
        bar.append(btnAll, btnShared, btnFamily);
        bar.sync = sync;
        return bar;
    }

    function renderRvtList() {
        state.rvtList = dedupPaths(state.rvtList);
        state.rvtChecked = new Set(state.rvtList.filter(p => state.rvtChecked.has(p)));
        const allChecked = state.rvtList.length > 0 && state.rvtList.every(p => state.rvtChecked.has(p));
        rvtMaster.checked = allChecked;
        rvtMaster.indeterminate = state.rvtList.length > 0 && !allChecked && state.rvtChecked.size > 0;
        rvtMaster.disabled = state.rvtList.length === 0;
        rvtMaster.onchange = () => {
            if (state.busy) return;
            if (rvtMaster.checked) state.rvtChecked = new Set(state.rvtList);
            else state.rvtChecked.clear();
            persistRvts();
            renderRvtList();
        };
        const rows = state.rvtList.map((p, i) => ({
            checked: state.rvtChecked.has(p),
            index: i + 1,
            name: getRvtName(p),
            path: p,
            title: p,
            onToggle: (checked) => {
                if (state.busy) return;
                if (checked) state.rvtChecked.add(p); else state.rvtChecked.delete(p);
                persistRvts();
                renderRvtList();
            }
        }));
        renderRvtRows(rvtBody, rows);
        rvtSummary.textContent = state.rvtList.length ? `파일 ${state.rvtList.length}개` : '파일 0개';
        syncRvtActionState();
    }

    function paintProject() {
        projNavList.innerHTML = '';
        if (!state.project.rows.length) {
            const empty = document.createElement('li');
            empty.className = 'guid-nav-empty';
            empty.textContent = '결과가 없습니다.';
            projNavList.append(empty);
            projHead.innerHTML = '';
            projBody.innerHTML = '';
            return;
        }
        const idxPath = projectCol('RvtPath');
        const idxName = projectCol('RvtName');
        const docMap = new Map();
        state.project.rows.forEach(row => {
            const path = idxPath >= 0 ? safe(row[idxPath]) : '';
            const name = idxName >= 0 ? safe(row[idxName]) : (path || '(Doc)');
            const key = path || name;
            if (!docMap.has(key)) docMap.set(key, name);
        });
        const docs = Array.from(docMap.entries()).sort((a, b) => a[1].localeCompare(b[1]));
        if (!docMap.has(state.activeProjectDoc) && docs.length) state.activeProjectDoc = docs[0][0];
        projContext.textContent = state.activeProjectDoc;
        docs.forEach(([key, name]) => {
            const li = document.createElement('li');
            const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'nav-fam-item'; btn.textContent = name;
            btn.title = key;
            btn.onclick = () => { state.activeProjectDoc = key; paintProject(); };
            if (state.activeProjectDoc === key) btn.classList.add('is-active');
            li.append(btn);
            projNavList.append(li);
        });
        buildHead(projHead, state.project.columns, new Set(['RvtPath']));
        paintVirtualRows(projBody, state.project.columns, filteredProjectRows(), new Set(['RvtPath']));
    }

    function paintFamily() {
        navList.innerHTML = '';
        if (!state.resultIncludeFamily) {
            navList.innerHTML = '<li class="guid-nav-empty">패밀리 검토 결과 추가 검토를 선택한 뒤 실행해 주세요.</li>';
            detailHead.innerHTML = '';
            detailBody.innerHTML = '';
            builtHead.innerHTML = '';
            builtBody.innerHTML = '';
            familyEmpty.style.display = 'none';
            detailTableWrap.style.display = 'none';
            builtTableWrap.style.display = 'none';
            if (filterBar && typeof filterBar.sync === 'function') filterBar.sync();
            return;
        }
        if (!state.familyNav.rows.length) {
            const empty = document.createElement('li');
            empty.className = 'guid-nav-empty';
            empty.textContent = '패밀리 결과가 없습니다.';
            navList.append(empty);
            detailHead.innerHTML = '';
            detailBody.innerHTML = '';
            builtHead.innerHTML = '';
            builtBody.innerHTML = '';
            familyEmpty.style.display = 'none';
            detailTableWrap.style.display = 'none';
            builtTableWrap.style.display = 'none';
            if (filterBar && typeof filterBar.sync === 'function') filterBar.sync();
            return;
        }
        if (filterBar && typeof filterBar.sync === 'function') filterBar.sync();
        const idxPath = indexCol(state.familyNav, 'RvtPath');
        const idxName = indexCol(state.familyNav, 'RvtName');
        const idxFam = indexCol(state.familyNav, 'FamilyName');
        const map = new Map();
        state.familyNav.rows.forEach(row => {
            const path = idxPath >= 0 ? safe(row[idxPath]) : '';
            const rname = idxName >= 0 ? safe(row[idxName]) : (path || '(Doc)');
            const fam = idxFam >= 0 ? safe(row[idxFam]) : '';
            const key = path || rname;
            if (!map.has(key)) map.set(key, { name: rname, families: new Set() });
            if (fam) map.get(key).families.add(fam);
        });
        const entries = Array.from(map.entries()).sort((a, b) => a[1].name.localeCompare(b[1].name));
        if (!state.activeFamilyDoc && entries.length) state.activeFamilyDoc = entries[0][0];
        entries.forEach(([key, info]) => {
            const docItem = document.createElement('li');
            docItem.className = 'guid-nav-doc';
            const docTitle = document.createElement('div');
            docTitle.className = 'nav-doc-title';
            docTitle.textContent = info.name;
            docTitle.title = key;
            docItem.append(docTitle);

            const famList = document.createElement('ul');
            famList.className = 'guid-nav-fams';

            Array.from(info.families).sort((a, b) => a.localeCompare(b)).forEach(f => {
                const li = document.createElement('li');
                const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'nav-fam-item'; btn.textContent = f;
                btn.setAttribute('aria-label', f);
                btn.onclick = () => { onRequestFamilyDetail(key, f); };
                if (state.activeFamilyDoc === key && state.activeFamily === f) btn.classList.add('is-active');
                li.append(btn);
                famList.append(li);
            });

            docItem.append(famList);
            navList.append(docItem);
        });
        const { userRows, builtRows } = splitFamilyRows();
        familyContext.textContent = state.activeFamily ? `${state.activeFamilyDoc} · ${state.activeFamily}` : '왼쪽 목록에서 패밀리를 선택하세요.';
        familyUserCount.textContent = String(userRows.length || 0);
        builtCount.textContent = String(builtRows.length || 0);
        familyEmpty.style.display = userRows.length ? 'none' : 'block';
        detailTableWrap.style.display = userRows.length ? 'block' : 'none';
        buildHead(detailHead, state.familyDetail.columns, HIDDEN_DETAIL_COLS);
        paintVirtualRows(detailBody, state.familyDetail.columns, userRows, HIDDEN_DETAIL_COLS);

        const builtOpen = builtSection.classList.contains('is-open');
        builtTableWrap.style.display = builtOpen ? 'block' : 'none';
        if (builtOpen) {
            buildHead(builtHead, state.familyDetail.columns, HIDDEN_DETAIL_COLS);
            paintVirtualRows(builtBody, state.familyDetail.columns, builtRows, HIDDEN_DETAIL_COLS);
        } else {
            builtHead.innerHTML = '';
            builtBody.innerHTML = '';
        }
    }

    function onRequestFamilyDetail(rvtPath, familyName) {
        if (state.busy) return;
        if (!state.runId) {
            toast('먼저 검토를 실행해 주세요.', 'warn');
            return;
        }
        state.activeFamilyDoc = rvtPath || familyName || '';
        state.activeFamily = familyName || '';
        state.familyDetail = { columns: [], rows: [] };
        paintFamily();
        post('guid:request-family-detail', { runId: state.runId, rvtPath, familyName });
    }

    function filteredProjectRows() {
        if (!state.project.rows.length) return [];
        const idxPath = projectCol('RvtPath');
        const idxName = projectCol('RvtName');
        if (!state.activeProjectDoc) return state.project.rows;
        return state.project.rows.filter(row => {
            const path = idxPath >= 0 ? safe(row[idxPath]) : '';
            const name = idxName >= 0 ? safe(row[idxName]) : '';
            return (path || name) === state.activeProjectDoc && matchesResultRow(row, state.project.columns);
        });
    }

    function filteredFamilyRows() {
        if (!state.familyDetail.rows.length) return [];
        const idxPath = colIndex('RvtPath');
        const idxFam = colIndex('FamilyName');
        const idxKind = colIndex('ParamKind');
        const idxShared = colIndex('IsShared');
        return state.familyDetail.rows.filter(row => {
            const path = idxPath >= 0 ? safe(row[idxPath]) : '';
            const famName = idxFam >= 0 ? safe(row[idxFam]) : '';
            const kind = idxKind >= 0 ? safe(row[idxKind]) : '';
            const shared = idxShared >= 0 ? safe(row[idxShared]) : '';
            const docMatch = idxPath < 0 || !state.activeFamilyDoc || ((path || '') === state.activeFamilyDoc);
            const famMatch = !state.activeFamily || (famName === state.activeFamily);
            const filterMatch = state.familyFilter === 'all' ||
                (state.familyFilter === 'shared' && (kind === 'Shared' || shared === 'Y')) ||
                (state.familyFilter === 'family' && (kind === 'Family' || shared === 'N'));
            return docMatch && famMatch && filterMatch && matchesResultRow(row, state.familyDetail.columns);
        });
    }

    function matchesResultRow(row, columns) {
        const search = state.resultSearch.trim().toLocaleLowerCase();
        if (search && !row.some(value => safe(value).toLocaleLowerCase().includes(search))) return false;
        const resultIndex = columns.indexOf('Result');
        const result = resultIndex >= 0 ? safe(row[resultIndex]).toUpperCase() : '';
        const matched = result === 'MATCH' || result === 'OK' || result === 'OK(MULTI_IN_FILE)' || result.startsWith('일치');
        const failed = /ERROR|FAIL|실패|오류/.test(result);
        return state.resultFilter === 'all' || (state.resultFilter === 'match' && matched) ||
            (state.resultFilter === 'attention' && !matched) || (state.resultFilter === 'failure' && failed);
    }

    function splitFamilyRows() {
        const rows = filteredFamilyRows();
        const idxKind = colIndex('ParamKind');
        const userRows = [];
        const builtRows = [];
        rows.forEach(row => {
            const kind = idxKind >= 0 ? safe(row[idxKind]) : '';
            if (kind === 'BuiltIn') {
                builtRows.push(row);
            } else if (kind === 'Shared' || kind === 'Family') {
                userRows.push(row);
            } else {
                userRows.push(row);
            }
        });
        return { userRows, builtRows };
    }

    function colIndex(name) {
        return state.familyDetail.columns.findIndex(c => c === name);
    }

    function projectCol(name) {
        return state.project.columns.findIndex(c => c === name);
    }

    function indexCol(table, name) {
        return (table.columns || []).findIndex(c => c === name);
    }

    function buildHead(thead, columns, hidden) {
        thead.innerHTML = '';
        const tr = document.createElement('tr');
        columns.forEach(c => {
            if (hidden.has(c)) return;
            const th = document.createElement('th');
            th.textContent = guidHeaderLabel(c);
            th.dataset.guidColumn = c;
            th.style.setProperty('width', `${guidColumnWidth(c)}px`, 'important');
            tr.append(th);
        });
        thead.append(tr);
    }

    function paintVirtualRows(tbody, columns, rows, hidden) {
        const version = (rowRenderVersions.get(tbody) || 0) + 1;
        rowRenderVersions.set(tbody, version);
        tbody.innerHTML = '';
        const table = tbody.closest('table');
        if (table) {
            const width = Math.max(960, columns.filter(column => !hidden.has(column)).reduce((total, column) => total + guidColumnWidth(column), 0));
            table.style.setProperty('min-width', `${width}px`, 'important');
            table.style.setProperty('width', `${width}px`, 'important');
        }
        let idx = 0;
        const chunk = () => {
            if (rowRenderVersions.get(tbody) !== version) return;
            const frag = document.createDocumentFragment();
            for (let i = 0; i < 200 && idx < rows.length; i++, idx++) {
                const row = rows[idx];
                const tr = document.createElement('tr');
                columns.forEach((c, ci) => {
                    if (hidden.has(c)) return;
                    const td = document.createElement('td');
                    const text = guidCellLabel(c, safe(row[ci]));
                    const cellText = document.createElement('div'); cellText.className = 'guid-cell-text';
                    cellText.textContent = text;
                    cellText.style.setProperty('width', `${guidColumnWidth(c) - 24}px`, 'important');
                    cellText.style.setProperty('min-width', `${guidColumnWidth(c) - 24}px`, 'important');
                    cellText.style.whiteSpace = c === 'Notes' || c === 'Message' ? 'pre-line' : /Guids$|Path$|Categories$/.test(c) ? 'normal' : 'nowrap';
                    cellText.style.overflowWrap = 'anywhere';
                    td.append(cellText);
                    td.style.setProperty('width', `${guidColumnWidth(c)}px`, 'important');
                    td.style.setProperty('min-width', `${guidColumnWidth(c)}px`, 'important');
                    td.dataset.guidColumn = c;
                    td.title = text;
                    td.setAttribute('aria-label', text || '-');
                    tr.append(td);
                });
                frag.append(tr);
            }
            tbody.append(frag);
            if (idx < rows.length) setTimeout(chunk, 0);
        };
        chunk();
    }

    function hasRowsForExport() {
        const hasProject = (state.project.columns || []).length > 0;
        const hasFamily = state.resultIncludeFamily && ((state.familyDetail.columns || []).length > 0 || (state.familyNav.columns || []).length > 0);
        return hasProject || hasFamily;
    }

    function syncTabState() {
        btnTabProject.classList.toggle('is-active', state.activeTab === 'project');
        btnTabFamily.classList.toggle('is-active', state.activeTab === 'family');
        btnTabFamily.disabled = !state.resultIncludeFamily;
        tabPanelProject.classList.toggle('is-hidden', state.activeTab !== 'project');
        tabPanelFamily.classList.toggle('is-hidden', state.activeTab !== 'family');
        filterBar.classList.toggle('is-hidden', state.activeTab !== 'family');
        if (state.activeTab === 'family' && !state.resultIncludeFamily) {
            state.activeTab = 'project';
            tabPanelProject.classList.remove('is-hidden');
            tabPanelFamily.classList.add('is-hidden');
            filterBar.classList.add('is-hidden');
        }
        exportBtn.disabled = state.busy || !hasRowsForExport();
        if (processButtons.export) processButtons.export.disabled = !!exportBtn.disabled;
        updateTabCounts();
    }

    function syncResultState() {
        const showResults = state.hasRun;
        tabPanels.style.display = showResults ? '' : 'none';
        emptyState.style.display = showResults ? 'none' : 'flex';
        reviewResultBtn.disabled = !showResults;
        reviewResultText.textContent = showResults ? `최근 검토 · 프로젝트 ${state.project.rows.length}건${state.resultIncludeFamily ? ` · 패밀리 ${state.familyNav.rows.length}건` : ''}` : '검토 결과가 없습니다. 활성 문서 또는 선택한 RVT를 검토하세요.';
        cleanupResultBtn.disabled = !state.cleanupResult;
        cleanupReportBtn.disabled = state.busy || !state.cleanupResult?.cleanupRunId;
        const persistenceCounts = guidPersistenceCounts(state.cleanupResult);
        cleanupResultText.textContent = state.cleanupResult ? `최근 삭제 · 실제 삭제 ${Number(state.cleanupResult.deletedCount) || 0}건 · 실패 요청 ${Number(state.cleanupResult.failedDeleteCount) || 0}건${persistenceCounts ? ` · ${persistenceCounts}` : ''}` : '삭제 결과가 없습니다. 삭제용 엑셀을 불러온 뒤 실행하세요.';
        resultExportBtn.disabled = state.busy || (resultMode === 'cleanup' ? !state.cleanupResult?.cleanupRunId : !hasRowsForExport());
    }

    function openResultDialog(mode) {
        if (mode === 'cleanup' ? !state.cleanupResult : !state.hasRun) return;
        resultMode = mode;
        resultFocusBefore = document.activeElement;
        resultDialog.dataset.guidMode = mode;
        resultDialogTitle.textContent = mode === 'cleanup' ? '등록 파라미터 삭제 결과' : '파라미터 GUID 검토 결과';
        resultDialogSub.textContent = mode === 'cleanup' ? '파일별 사유와 파라미터별 실제 처리 결과를 확인할 수 있습니다.' : '파일을 선택한 뒤 상세 결과를 확인하세요. 표는 가로·세로로 스크롤할 수 있습니다.';
        resultExportBtn.textContent = mode === 'cleanup' ? '삭제 결과 엑셀 내보내기' : '삭제용 엑셀 내보내기';
        tabs.classList.toggle('is-hidden', mode !== 'review');
        cleanupDetail.classList.toggle('is-hidden', mode !== 'cleanup');
        if (mode === 'cleanup') paintCleanupResult();
        else { paintProject(); paintFamily(); syncTabState(); }
        resultBackdrop.classList.remove('is-hidden');
        syncResultState();
        resultCloseBtn.focus({ preventScroll: true });
    }

    function closeResultDialog(restoreFocus = true) {
        const wasOpen = !resultBackdrop.classList.contains('is-hidden');
        resultBackdrop.classList.add('is-hidden');
        if (wasOpen && restoreFocus) {
            const focusTarget = resultFocusBefore?.isConnected ? resultFocusBefore : (resultMode === 'cleanup' ? cleanupResultBtn : reviewResultBtn);
            focusTarget.focus({ preventScroll: true });
        }
    }

    function paintCleanupResult() {
        const payload = state.cleanupResult;
        if (!payload) return;
        clear(cleanupSummary); clear(cleanupFileResults);
        [['삭제 요청', payload.instructionCount], ['실제 삭제', payload.deletedCount], ['실패 요청', payload.failedDeleteCount], ['일부 실패 파일', payload.partialCount]].forEach(([label, value]) => {
            const card = div('guid-cleanup-stat'); const caption = document.createElement('span'); caption.textContent = label;
            const count = document.createElement('strong'); count.textContent = String(Number(value) || 0); card.append(caption, count); cleanupSummary.append(card);
        });
        const persistenceCounts = guidPersistenceCounts(payload);
        cleanupSource.textContent = `삭제 기준 엑셀: ${payload.sourceExcelPath || '(경로 없음)'}${persistenceCounts ? ` · ${persistenceCounts}` : ''}`;
        const matches = value => {
            const status = safe(cleanupField(value, 'Status'));
            return state.cleanupFilter === 'all' || (state.cleanupFilter === 'failure' ? status === 'Fail' || status === 'Partial' : status === 'Success' || status === 'NoChange');
        };
        const filesSource = cleanupField(payload, 'Files');
        const files = (Array.isArray(filesSource) ? filesSource : []).filter(matches);
        files.forEach(file => {
            const card = div('guid-cleanup-file');
            const heading = div('guid-cleanup-file__heading'); const name = document.createElement('strong');
            const path = safe(cleanupField(file, 'FilePath')); const status = safe(cleanupField(file, 'Status'));
            name.textContent = safe(cleanupField(file, 'FileName')) || getRvtName(path) || '(파일명 없음)';
            const badge = div(`guid-result-status guid-result-status--${status.toLowerCase()}`); badge.textContent = guidStatusLabel(status);
            heading.append(name, badge);
            const persistence = guidPersistenceLabel(safe(cleanupField(file, 'PersistenceStatus')));
            const persistenceText = div('guid-cleanup-file__counts');
            if (persistence) { const label = document.createElement('strong'); label.textContent = `저장 상태: ${persistence}`; persistenceText.append(label); }
            const pathText = div('guid-result-context'); pathText.textContent = path || '(경로 없음)';
            const counts = div('guid-cleanup-file__counts');
            counts.textContent = `삭제 요청 ${Number(cleanupField(file, 'RequestedDeleteCount')) || 0}건 · 실제 삭제 ${Number(cleanupField(file, 'DeletedCount')) || 0}건 · 실패 요청 ${Number(cleanupField(file, 'FailedDeleteCount')) || 0}건`;
            const reason = div('guid-cleanup-file__reason'); reason.dataset.guidRef = 'cleanup-reason';
            reason.textContent = cleanupReason(file);
            card.append(heading);
            if (persistence) card.append(persistenceText);
            card.append(pathText, counts, reason); cleanupFileResults.append(card);
        });
        if (!files.length) { const empty = div('guid-empty'); empty.textContent = '선택한 조건의 파일 결과가 없습니다.'; cleanupFileResults.append(empty); }
        const columns = ['ParamName', 'Status', 'Message', 'PersistenceStatus', 'WasAlreadyOpen', 'FileName', 'DeleteScope', 'FamilyName', 'ParamKind', 'RequestedGuid', 'FilePath', 'SheetName', 'RowNumber'];
        const itemsSource = cleanupField(payload, 'Items');
        const items = (Array.isArray(itemsSource) ? itemsSource : []).filter(matches);
        const rows = items.map(item => columns.map(column => column === 'Message' ? cleanupReason(item) : safe(cleanupField(item, column))));
        buildHead(cleanupItemHead, columns, new Set()); paintVirtualRows(cleanupItemBody, columns, rows, new Set());
        cleanupItemHeading.textContent = `파라미터별 처리 결과 · ${items.length}건`;
        cleanupItemWrap.classList.toggle('is-hidden', !items.length);
        if (!items.length) cleanupItemHeading.textContent = '파라미터별 처리 결과가 없습니다. 파일별 사유를 확인하세요.';
    }

    function syncAnnotationToggle() {
        if (!state.includeFamily) state.includeAnnotation = false;
    }

    function syncInlineGuidSettings() {
        if (auditUi.familyCheck) { auditUi.familyCheck.checked = !!state.includeFamily; auditUi.familyCheck.disabled = state.busy; }
        if (auditUi.annotationCheck) {
            auditUi.annotationCheck.checked = !!state.includeAnnotation;
            auditUi.annotationCheck.disabled = state.busy || !state.includeFamily;
        }
        if (auditUi.annotationLabel) {
            auditUi.annotationLabel.classList.toggle('is-disabled', !state.includeFamily);
        }
    }

    function syncAuditConfigSummary() {
        if (!auditUi.summary) return;
        const familyText = state.includeFamily ? '포함' : '미포함';
        const annotationText = state.includeFamily && state.includeAnnotation ? '포함' : '미포함';
        auditUi.summary.textContent = `현재 설정: 패밀리 ${familyText} / 주석 패밀리 ${annotationText}`;
    }

    function setBusy(on) {
        state.busy = on;
        exportBtn.disabled = on || !hasRowsForExport();
        pickCleanupExcelBtn.disabled = on;
        cleanupBtn.disabled = on || !state.cleanupSourceExcelPath;
        if (processButtons.run) processButtons.run.disabled = !!runBtn.disabled;
        if (processButtons.export) processButtons.export.disabled = !!exportBtn.disabled;
        if (processButtons.pickCleanupExcel) processButtons.pickCleanupExcel.disabled = !!pickCleanupExcelBtn.disabled;
        if (processButtons.cleanup) processButtons.cleanup.disabled = !!cleanupBtn.disabled;
        syncRvtActionState(); syncInlineGuidSettings(); syncResultState();
        if (processSync.checkbox) processSync.checkbox.disabled = on;
        if (processSync.input) processSync.input.disabled = on || !state.useSyncComment;
    }

    function persistRvts() {
        state.rvtList = dedupPaths(state.rvtList);
        try { localStorage.setItem(LS_RVTS, JSON.stringify(state.rvtList || [])); } catch { }
    }

    function loadRvtList() {
        try {
            const raw = localStorage.getItem(LS_RVTS);
            const arr = JSON.parse(raw || '[]');
            if (Array.isArray(arr)) return dedupPaths(arr);
        } catch { }
        return [];
    }

    function persistGuidSettings() {
        const payload = {
            includeFamily: !!state.includeFamily,
            includeAnnotation: !!state.includeAnnotation,
            closeAllWorksetsOnOpen: !!state.closeAllWorksetsOnOpen,
            useSyncComment: !!state.useSyncComment,
            syncComment: state.syncComment || ''
        };
        try { localStorage.setItem(LS_SETTINGS, JSON.stringify(payload)); } catch { }
    }

    function loadGuidSettings() {
        try {
            const raw = localStorage.getItem(LS_SETTINGS);
            const parsed = JSON.parse(raw || '{}');
            if (parsed && typeof parsed === 'object') return parsed;
        } catch { }
        return {};
    }

    function handleRunProgress(payload) {
        if (!state.acceptRunProgress) return;
        const percent = typeof payload?.pct === 'number' ? payload.pct : 0;
        const message = payload?.detail || payload?.text || '';
        if (!state.busy && percent <= 0) return;
        if (!state.busy) setBusy(true);
        const subtitle = payload?.stage || buildRunProgressSubtitle(percent, message);
        ProgressDialog.show('파라미터 GUID 검토', subtitle);
        ProgressDialog.update(percent, subtitle, buildRunProgressDetail(percent, message));
    }

    function handleCleanupProgress(payload) {
        if (!state.acceptCleanupProgress) return;
        const percent = typeof payload?.pct === 'number' ? payload.pct : 0;
        const message = payload?.detail || payload?.text || '';
        if (!state.busy && percent <= 0) return;
        if (!state.busy) setBusy(true);
        const subtitle = payload?.stage || buildCleanupProgressSubtitle(percent, message);
        ProgressDialog.show('파라미터 GUID 정리', subtitle);
        ProgressDialog.update(percent, subtitle, message || `전체 진행률 ${formatRunPercent(percent)}`);
    }

    function handleExcelProgress(payload) {
        if (!state.acceptExcelProgress) return;
        const phase = normalizeExcelPhase(payload?.phase);
        const total = Number(payload?.total) || 0;
        const current = Number(payload?.current) || 0;
        const percent = computeExcelPercent(phase, current, total, payload?.phaseProgress);
        const subtitle = buildExcelSubtitle(phase, current, total);
        const detail = formatExcelDetail(phase, payload?.message);

        const exporting = phase !== 'DONE' && phase !== 'ERROR';
        if (!state.busy && exporting) setBusy(true);

        ProgressDialog.show(state.excelExportKind === 'cleanup-report' ? '삭제 결과 엑셀 내보내기' : '삭제용 엑셀 내보내기', subtitle || '엑셀을 내보내는 중입니다.');
        ProgressDialog.update(percent, subtitle, detail);

        if (!exporting) {
            setTimeout(() => { ProgressDialog.hide(); lastExcelPct = 0; setBusy(false); }, 260);
        }
    }

    function normalizeExcelPhase(phase) {
        return String(phase || '').trim().toUpperCase() || 'EXCEL_WRITE';
    }

    function computeExcelPercent(phase, current, total, phaseProgress) {
        const norm = normalizeExcelPhase(phase);
        if (norm === 'DONE') { lastExcelPct = 100; return 100; }
        if (norm === 'ERROR') return lastExcelPct;

        const completed = ['EXCEL_INIT', 'EXCEL_WRITE', 'EXCEL_SAVE', 'AUTOFIT'].reduce((acc, key) => {
            if (key === norm) return acc;
            return acc + (EXCEL_PHASE_WEIGHT[key] || 0);
        }, 0);
        const weight = EXCEL_PHASE_WEIGHT[norm] || 0;
        const ratio = total > 0 ? Math.max(0, Math.min(1, current / total)) : 0;
        const staged = Math.max(ratio, clamp01(phaseProgress));
        const pct = (completed + weight * staged) * 100;
        lastExcelPct = Math.max(lastExcelPct, Math.min(100, pct));
        return lastExcelPct;
    }

    function clamp01(v) { const n = Number(v); if (Number.isFinite(n)) return Math.max(0, Math.min(1, n)); return 0; }

    function buildExcelSubtitle(phase, current, total) {
        const norm = normalizeExcelPhase(phase);
        const label = state.excelExportKind === 'cleanup-report' ? '파라미터 삭제 결과' : '파라미터 GUID 삭제용';
        switch (norm) {
            case 'EXCEL_INIT': return `${label} 엑셀 워크북을 준비하는 중입니다.`;
            case 'EXCEL_WRITE': return `${label} 엑셀 데이터를 작성하는 중입니다. (${current}/${Math.max(total, current || 1)})`;
            case 'EXCEL_SAVE': return `${label} 엑셀을 내보내는 중입니다.`;
            case 'AUTOFIT': return `${label} 엑셀 열 너비를 자동 조정하는 중입니다.`;
            case 'DONE': return `${label} 엑셀 내보내기 완료`;
            case 'ERROR': return `${label} 엑셀 내보내기 오류`;
            default: return `${label} 엑셀을 내보내는 중입니다.`;
        }
    }

    function formatExcelDetail(phase, message) {
        const norm = normalizeExcelPhase(phase);
        if (norm === 'AUTOFIT') return state.excelExportKind === 'cleanup-report' ? '파라미터 삭제 결과 엑셀 열 너비를 자동 조정하는 중입니다.' : '파라미터 GUID 삭제용 엑셀 열 너비를 자동 조정하는 중입니다.';
        return message || '';
    }

    function buildRunProgressSubtitle(percent, message) {
        const raw = String(message || '').trim();
        if (!raw) return '파라미터 GUID 검토를 진행하는 중입니다.';
        if (raw.includes('문서 여는 중')) return '파라미터 GUID 검토 대상 문서를 여는 중입니다.';
        if (raw.includes('프로젝트 파라미터')) return `프로젝트 파라미터 GUID를 검토하는 중입니다. (${formatRunPercent(percent)})`;
        if (raw.includes('패밀리 처리 중')) return `패밀리 파라미터 GUID를 검토하는 중입니다. (${formatRunPercent(percent)})`;
        if (raw.includes('실패')) return '문서 처리 실패';
        if (raw.includes('완료')) return '파라미터 GUID 검토 완료';
        return `파라미터 GUID 검토를 진행하는 중입니다. (${formatRunPercent(percent)})`;
    }

    function buildCleanupProgressSubtitle(percent, message) {
        const raw = String(message || '').trim();
        if (!raw) return '파라미터 GUID 정리를 진행하는 중입니다.';
        if (raw.includes('문서 여는 중')) return '삭제 대상 문서를 여는 중입니다.';
        if (raw.includes('프로젝트 파라미터 정리 중')) return `프로젝트 파라미터를 정리하는 중입니다. (${formatRunPercent(percent)})`;
        if (raw.includes('로드 패밀리 파라미터 정리 중')) return `로드 패밀리를 정리하는 중입니다. (${formatRunPercent(percent)})`;
        if (raw.includes('완료')) return '파라미터 GUID 정리 완료';
        return `파라미터 GUID 정리를 진행하는 중입니다. (${formatRunPercent(percent)})`;
    }

    function buildRunProgressDetail(percent, message) {
        const raw = String(message || '').trim();
        if (raw) return raw;
        return `전체 진행률 ${formatRunPercent(percent)}`;
    }

    function formatRunPercent(percent) {
        const safe = Number(percent);
        if (!Number.isFinite(safe)) return '0%';
        return `${Math.max(0, Math.min(100, Math.round(safe * 10) / 10))}%`;
    }

    function onRemoveSelected() {
        if (state.busy) return;
        if (!state.rvtChecked.size) { toast('제거할 RVT를 선택해 주세요.', 'warn'); return; }
        state.rvtList = state.rvtList.filter(p => !state.rvtChecked.has(p));
        state.rvtChecked.clear();
        persistRvts();
        renderRvtList();
    }

    function appendDroppedRvts(paths) {
        let added = 0;
        (Array.isArray(paths) ? paths : []).forEach((entry) => {
            const path = normalizeRvtPath(entry);
            if (!path) return;
            const exists = state.rvtList.some((item) => samePath(item, path));
            if (!exists) {
                state.rvtList.push(path);
                added += 1;
            }
            state.rvtChecked.add(path);
        });
        state.rvtList = dedupPaths(state.rvtList);
        return added;
    }

    function syncRvtActionState() {
        if (btnRemove) btnRemove.disabled = state.busy || state.rvtChecked.size === 0;
        if (btnClear) btnClear.disabled = state.busy || state.rvtList.length === 0;
        btnAdd.disabled = state.busy;
        const activeDocument = getGuidActiveDocumentInfo();
        activeRunBtn.disabled = state.busy || ((!activeDocument.name && !activeDocument.path) || activeDocument.isLinked);
        runBtn.disabled = state.busy || state.rvtChecked.size === 0;
        reviewLaunchCopy.textContent = `활성 문서: ${activeDocument.name || getRvtName(activeDocument.path) || '열린 문서 없음'} · 선택 RVT ${state.rvtChecked.size}개`;
        reviewLaunchCopy.title = activeDocument.path || '';
        rvtMaster.disabled = state.busy || state.rvtList.length === 0;
        rvtBody.querySelectorAll('input[type="checkbox"]').forEach(input => { input.disabled = state.busy; });
        rvtMeta.textContent = `파일 ${state.rvtList.length}개`;
        rvtSummary.textContent = `파일 ${state.rvtList.length}개`;
        if (processButtons.run) processButtons.run.disabled = !!runBtn.disabled;
        if (processButtons.export) processButtons.export.disabled = !!exportBtn.disabled;
        if (processButtons.cleanup) processButtons.cleanup.disabled = !!cleanupBtn.disabled;
    }

    function syncCleanupPanel() {
        if (processUi.meta) {
            processUi.meta.textContent = state.cleanupSourceExcelPath ? '삭제용 엑셀 선택 완료' : '삭제용 엑셀 선택 필요';
        }
        if (processUi.path) {
            processUi.path.textContent = state.cleanupSourceExcelPath || '아직 선택한 삭제용 엑셀이 없습니다.';
        }
        cleanupBtn.disabled = !!state.busy || !state.cleanupSourceExcelPath;
        if (processButtons.cleanup) processButtons.cleanup.disabled = !!cleanupBtn.disabled;
        if (processSync.sync) processSync.sync();
    }

    function showGuidCompletionDialog(payload) {
        const projectCount = state.project.rows.length || 0;
        const familyCount = state.resultIncludeFamily ? (state.familyNav.rows.length || 0) : 0;
        const projectDocCount = countUniqueDocEntries(state.project.columns, state.project.rows);
        const familyDocCount = state.resultIncludeFamily ? countUniqueDocEntries(state.familyNav.columns, state.familyNav.rows) : 0;
        const notes = [];

        if (state.resultIncludeFamily) notes.push('상세 결과창의 패밀리 탭에서 RVT별 패밀리 결과를 확인할 수 있습니다.');
        if (payload?.includeAnnotation) notes.push('주석 패밀리까지 포함해 GUID를 비교했습니다.');
        notes.push("삭제할 행은 엑셀의 '삭제여부' 열에 '삭제'를 입력한 뒤, 삭제용 엑셀 불러오기로 다시 실행하면 됩니다.");

        showCompletionSummaryDialog({
            title: '파라미터 GUID 검토 완료',
            message: 'GUID 검토가 끝났습니다. 상세 결과창을 열거나 삭제용 엑셀로 내보내세요.',
            summaryItems: [
                { label: '프로젝트 결과 건수', value: String(projectCount) },
                { label: '프로젝트 대상 RVT', value: `${projectDocCount}개` },
                { label: '패밀리 결과 건수', value: String(familyCount) },
                { label: '패밀리 대상 RVT', value: `${familyDocCount}개` },
                { label: '패밀리 검토 포함', value: state.resultIncludeFamily ? '예' : '아니오' }
            ],
            notes,
            actions: [{ label: '상세 결과 보기', variant: 'primary', onClick: () => openResultDialog('review') }],
            exportDisabled: !!exportBtn.disabled,
            onExport: () => exportBtn.click()
        });
    }

    function showGuidCleanupDialog(payload) {
        const successCount = Number(payload?.successCount) || 0;
        const failCount = Number(payload?.failCount) || 0;
        const partialCount = Number(payload?.partialCount) || 0;
        const noChangeCount = Number(payload?.noChangeCount) || 0;
        const deletedCount = Number(payload?.deletedCount) || 0;
        const failedDeleteCount = Number(payload?.failedDeleteCount) || 0;
        const instructionCount = Number(payload?.instructionCount) || 0;
        const hasFailures = failCount > 0 || partialCount > 0 || failedDeleteCount > 0;
        const allFailed = hasFailures && successCount === 0 && partialCount === 0 && deletedCount === 0;
        const filesSource = cleanupField(payload, 'Files');
        const files = Array.isArray(filesSource) ? filesSource : [];
        const hasUnsavedChanges = Number(cleanupField(payload, 'OpenDocumentDeletedCount')) > 0 || files.some(file => cleanupField(file, 'PersistenceStatus') === 'InMemory');
        const newlyProcessedFiles = files.filter(file => String(cleanupField(file, 'WasAlreadyOpen')).toLowerCase() === 'false'
            && ['Saved', 'Synchronized', 'NoChange'].includes(cleanupField(file, 'PersistenceStatus')));
        const savedCount = cleanupField(payload, 'SavedDeletedCount');
        const openCount = cleanupField(payload, 'OpenDocumentDeletedCount');
        const notes = [];

        if (payload?.sourceExcelPath) notes.push(`삭제 기준 엑셀: ${payload.sourceExcelPath}`);
        if (payload?.settings?.closeAllWorksetsOnOpen && newlyProcessedFiles.length) notes.push('새로 연 워크셰어링 문서는 모든 웍셋을 닫은 상태로 처리했습니다. 기존 열린 문서의 웍셋 상태는 유지합니다.');
        if (payload?.settings?.useSyncComment && newlyProcessedFiles.some(file => cleanupField(file, 'PersistenceStatus') === 'Synchronized')) notes.push(`닫힌 RVT 동기화 코멘트 설정: ${payload?.settings?.syncComment || '(빈 코멘트)'}`);
        const statusLabels = { Success: '완료', Partial: '일부 실패', Fail: '실패', NoChange: '변경 없음' };
        files.forEach((file) => {
            const path = String(file?.FilePath ?? file?.filePath ?? '').trim();
            const name = String(file?.FileName ?? file?.fileName ?? '').trim() || getRvtName(path) || '(파일명 없음)';
            const status = String(file?.Status ?? file?.status ?? '').trim();
            const requested = Number(file?.RequestedDeleteCount ?? file?.requestedDeleteCount) || 0;
            const deleted = Number(file?.DeletedCount ?? file?.deletedCount) || 0;
            const failed = Number(file?.FailedDeleteCount ?? file?.failedDeleteCount) || 0;
            const message = cleanupReason(file);
            notes.push(`${name} · ${statusLabels[status] || status || '상태 확인 필요'}`);
            const persistence = guidPersistenceLabel(safe(cleanupField(file, 'PersistenceStatus')));
            if (persistence) notes.push(`저장 상태: ${persistence}`);
            notes.push(`경로: ${path || '(경로 없음)'}`);
            notes.push(`삭제 요청 ${requested}건 · 실제 삭제 ${deleted}건 · 실패 요청 ${failed}건`);
            if (message) notes.push(`처리 결과: ${message}`);
        });

        const message = payload?.message || (hasFailures ? '삭제하지 못한 요청이 있습니다. 아래 파일별 처리 결과를 확인하세요.' : '삭제용 엑셀 기준 정리가 완료되었습니다.');
        showCompletionSummaryDialog({
            title: allFailed ? '파라미터 GUID 정리 실패' : hasFailures ? '파라미터 GUID 정리 일부 실패' : hasUnsavedChanges ? '파라미터 GUID 정리 완료 · 저장 필요' : '파라미터 GUID 정리 완료',
            message: `${message}${hasUnsavedChanges && !message.includes('저장하거나 동기화') ? ' 열린 문서에 적용한 변경은 Revit에서 저장하거나 동기화하세요.' : ''}`,
            summaryItems: [
                { label: '삭제 요청 건수', value: String(instructionCount) },
                { label: '실제 삭제 건수', value: String(deletedCount) },
                ...(savedCount !== '' || openCount !== '' ? [
                    { label: '저장·동기화된 삭제 건수', value: String(Number(savedCount) || 0) },
                    { label: '열린 문서 미저장 적용 건수', value: String(Number(openCount) || 0) }
                ] : []),
                { label: '실패 요청 건수', value: String(failedDeleteCount) },
                { label: '성공 파일', value: `${successCount}개` },
                { label: '일부 실패 파일', value: `${partialCount}개` },
                { label: '변경 없는 파일', value: `${noChangeCount}개` },
                { label: '실패 파일', value: `${failCount}개` }
            ],
            notes,
            actions: [{ label: '삭제 상세 결과 보기', variant: 'primary', onClick: () => openResultDialog('cleanup') }],
            exportLabel: '삭제 결과 엑셀 내보내기',
            showExport: !!payload?.cleanupRunId,
            onExport: onCleanupReportExport
        });
    }

    function countUniqueDocEntries(columns, rows) {
        const list = Array.isArray(rows) ? rows : [];
        if (!list.length) return 0;
        const idxPath = Array.isArray(columns) ? columns.findIndex((col) => col === 'RvtPath') : -1;
        const idxName = Array.isArray(columns) ? columns.findIndex((col) => col === 'RvtName') : -1;
        const docs = new Set();
        list.forEach((row) => {
            const path = idxPath >= 0 ? safe(row?.[idxPath]) : '';
            const name = idxName >= 0 ? safe(row?.[idxName]) : '';
            const key = path || name;
            if (key) docs.add(key);
        });
        return docs.size;
    }

    function updateTabCounts() {
        setTabCount(btnTabProject, state.project.rows.length || 0);
        const detCount = state.resultIncludeFamily ? (state.familyNav.rows.length || 0) : 0;
        setTabCount(btnTabFamily, detCount);
    }
}

function guidColumnWidth(column) {
    if (column === 'Notes' || column === 'Message') return 400;
    if (/Guids$/.test(column)) return 360;
    if (/Guid$|Path$/.test(column)) return 320;
    return ({ ParamName: 200, FamilyName: 200, RvtName: 180, FileName: 180, Status: 100, Result: 140,
        ParamKind: 110, DeleteScope: 120, RegisteredParameterCount: 130, BoundCategories: 240, RowNumber: 100, PersistenceStatus: 260, WasAlreadyOpen: 180 })[column] || 160;
}

function cleanupField(value, name) {
    return value?.[name] ?? value?.[name.charAt(0).toLowerCase() + name.slice(1)] ?? '';
}

function guidStatusLabel(status) {
    return ({ Success: '완료', Partial: '일부 실패', Fail: '실패', NoChange: '변경 없음' })[status] || status || '상태 확인 필요';
}

function guidPersistenceLabel(status) {
    return ({ InMemory: '문서에 적용 · 저장 필요', Saved: '저장 완료', Synchronized: '동기화 완료', NoChange: '변경 없음', NotApplied: '변경 미적용', Unconfirmed: '적용·취소 확인 필요' })[status] || status || '';
}

function guidPersistenceCounts(payload) {
    const saved = cleanupField(payload, 'SavedDeletedCount');
    const opened = cleanupField(payload, 'OpenDocumentDeletedCount');
    if (saved === '' && opened === '') return '';
    return `저장·동기화된 삭제 ${Number(saved) || 0}건 · 열린 문서 저장 필요 ${Number(opened) || 0}건`;
}

function cleanupReason(value) {
    const message = String(cleanupField(value, 'Message') || '').trim();
    const status = String(cleanupField(value, 'Status') || '');
    if (message) return message;
    if (status === 'Fail' || status === 'Partial') return '실패 사유가 전달되지 않았습니다. 삭제 결과 엑셀을 저장해 확인하거나 다시 실행한 결과를 확인하세요.';
    if (cleanupField(value, 'PersistenceStatus') === 'InMemory') return '열린 문서에 적용했습니다. 저장·동기화는 수행하지 않았습니다. Revit에서 저장하거나 동기화해 주세요.';
    return status === 'NoChange' ? '변경된 파라미터가 없습니다.' : '별도 처리 사유가 없습니다.';
}

function guidHeaderLabel(name) {
    return ({ RvtName: 'RVT 파일', RvtPath: 'RVT 경로', FileName: '파일명', FilePath: '파일 경로', FamilyName: '패밀리', FamilyCategory: '패밀리 카테고리',
        ParamName: '파라미터 이름', ParamKind: '종류', BoundCategories: '등록 카테고리', RvtGuid: '프로젝트 GUID', FamilyGuid: '패밀리 GUID',
        FileGuid: '공유 파일 GUID', RegisteredParameterCount: '프로젝트 등록 수', RegisteredSharedGuids: '등록 공유 GUID', UnboundSharedGuids: '프로젝트 미등록 공유 GUID',
        Result: '검토 결과', Notes: '검토 사유', DeleteScope: '삭제 범위', RequestedGuid: '삭제 요청 GUID', Status: '처리 상태', Message: '처리 사유',
        IsShared: '공유 여부', IsInstance: '인스턴스 여부', ParamGroup: '파라미터 그룹', StorageType: '값 형식', SheetName: '엑셀 시트', RowNumber: '엑셀 행', PersistenceStatus: '저장 상태', WasAlreadyOpen: '실행 전 열린 문서' })[name] || name;
}

function guidCellLabel(column, value) {
    if (column === 'Status') return guidStatusLabel(value);
    if (column === 'PersistenceStatus') return guidPersistenceLabel(value) || '정보 없음';
    if (column === 'WasAlreadyOpen') return value.toLowerCase() === 'true' ? '예' : value.toLowerCase() === 'false' ? '아니오' : '정보 없음';
    if (column === 'ParamKind' || column === 'DeleteScope') return ({ Shared: '공유', Project: '프로젝트', Family: '패밀리', BuiltIn: '기본 제공' })[value] || value;
    if (column === 'Result') return ({ OK: '일치', 'OK(MULTI_IN_FILE)': '일치(기준 파일 중복)', MATCH: '일치', MISMATCH: '불일치', NOT_FOUND_IN_FILE: '기준 파일에 없음', NOT_IN_FILE: '공유 파일에 없음', PROJECT_PARAM: '프로젝트 파라미터', FAMILY_PARAM: '패밀리 파라미터', BUILTIN: '기본 제공 파라미터', GUID_FAIL: 'GUID 추출 실패', OPEN_FAIL: '열기 실패', ERROR: '처리 오류', FAIL: '처리 실패', MISSING_IN_RVT: '프로젝트에 없음', GUID_MISMATCH: 'GUID 불일치' })[value] || value;
    return value;
}

function normalizeRvtPath(entry) {
    if (!entry) return '';
    if (typeof entry === 'string') return entry.trim();
    if (typeof entry === 'object') {
        if (typeof entry.path === 'string') return entry.path.trim();
        if (typeof entry.fullPath === 'string') return entry.fullPath.trim();
    }
    return '';
}

function dedupPaths(list) {
    const seen = new Set();
    const clean = [];
    (list || []).forEach(item => {
        const path = normalizeRvtPath(item);
        if (!path) return;
        const key = path.toLowerCase();
        if (seen.has(key)) return;
        seen.add(key);
        clean.push(path);
    });
    return clean;
}

function setTabCount(btn, count) {
    if (!btn) return;
    const badge = btn.querySelector('.pill-count');
    if (!badge) return;
    badge.textContent = Number.isFinite(count) ? count : 0;
}

function safe(v) {
    if (v === null || v === undefined) return '';
    return String(v);
}

function samePath(a, b) {
    if (!a || !b) return false;
    return a.toLowerCase() === b.toLowerCase();
}

function cardBtn(text, onClick) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn card-btn';
    btn.textContent = text;
    btn.onclick = onClick;
    return btn;
}

function getGuidContextPayload(extra = {}) {
    return {
        source: 'guid',
        activeDocument: getGuidActiveDocumentInfo(),
        ...extra
    };
}

function getGuidActiveDocumentInfo() {
    const topbar = (typeof getTopbarState === 'function' ? getTopbarState() : {}) || {};
    const doc = topbar.activeDocument || topbar.activeDoc || {};
    const name = doc.name || doc.title || topbar.activeDocumentName || topbar.documentName || '';
    const title = doc.title || doc.name || topbar.activeDocumentName || topbar.documentName || '';
    const path = doc.path || doc.filePath || topbar.activeDocumentPath || topbar.documentPath || '';
    return {
        name,
        title,
        path,
        filePath: doc.filePath || doc.path || path,
        isLinked: !!(doc.isLinked || doc.linked || doc.isRevitLink || topbar.activeDocumentIsLinked)
    };
}
