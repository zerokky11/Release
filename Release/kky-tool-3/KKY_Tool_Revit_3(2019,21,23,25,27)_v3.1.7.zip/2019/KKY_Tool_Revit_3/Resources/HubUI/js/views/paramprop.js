// Resources/HubUI/js/views/paramprop.js
import { clear, div, toast, setBusy, showExcelSavedDialog, showCompletionSummaryDialog, debounce, chooseExcelMode, getLastExcelExportLocale } from '../core/dom.js?v=20260731parameterexport1';
import { ProgressDialog } from '../core/progress.js';
import { post, onHost } from '../core/bridge.js';
import { getTopbarState } from '../core/topbar.js?v=20261012official317';

const DEFAULT_GUIDE = '복합패밀리 공유파라미터 추가/연동을 실행하면 결과가 여기에 표시됩니다.';
const PHASE_WEIGHT = {
    collect: 0.15,
    analyze: 0.25,
    apply: 0.3,
    save: 0.05,
    close: 0.05,
    excel_init: 0.05,
    excel_write: 0.12,
    excel_save: 0.02,
    autofit: 0.01,
    done: 0
};
const PHASE_ORDER = ['collect', 'analyze', 'apply', 'save', 'close', 'excel_init', 'excel_write', 'excel_save', 'autofit', 'done'];
const PHASE_LABEL = {
    collect: '대상 패밀리를 수집하는 중입니다.',
    analyze: '공유파라미터 구성을 분석하는 중입니다.',
    apply: '공유파라미터를 적용하는 중입니다.',
    save: '패밀리 파일을 저장하는 중입니다.',
    close: '작업을 마무리하는 중입니다.',
    excel_init: '엑셀 내보내기를 준비하는 중입니다.',
    excel_write: '엑셀 시트를 작성하는 중입니다.',
    excel_save: '엑셀 파일을 저장하는 중입니다.',
    autofit: '열 너비를 자동으로 맞추는 중입니다.',
    done: '작업이 완료되었습니다.'
};
const PARAMPROP_SETTINGS_KEY = 'kky.settings.paramprop.v1';
let activeParamPropPreferenceCleanup = null;

function formatRevitParamGroupLabel(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    if (raw.toUpperCase() === 'INVALID') return 'Other';
    const source = raw.toUpperCase().startsWith('PG_') ? raw.substring(3) : raw;
    return source
        .split('_')
        .filter(Boolean)
        .map((part) => {
            const lower = String(part || '').toLowerCase();
            return lower ? lower.charAt(0).toUpperCase() + lower.slice(1) : '';
        })
        .join(' ');
}

function loadParamPropPreferences() {
    try {
        const value = JSON.parse(localStorage.getItem(PARAMPROP_SETTINGS_KEY) || 'null');
        return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
    } catch {
        return null;
    }
}

function applyParamPropPreferences(state, value) {
    if (!value || typeof value !== 'object') return;
    state.excludeDummy = value.excludeDummy !== false;
    state.includeStandaloneFamilies = !!value.includeStandaloneFamilies;
    state.saveModifiedFamilies = !!value.saveModifiedFamilies;
    state.selectedParams = new Set(
        (Array.isArray(value.selectedParamKeys) ? value.selectedParamKeys : [])
            .map((key) => String(key || '').trim())
            .filter(Boolean)
    );
    const rows = value.paramSettings && typeof value.paramSettings === 'object' && !Array.isArray(value.paramSettings)
        ? value.paramSettings
        : {};
    state.paramSettings = new Map(Object.entries(rows).map(([key, setting]) => [
        key,
        {
            isInstance: setting?.isInstance !== false,
            targetGroupId: setting?.targetGroupId ?? null,
            targetGroupKey: String(setting?.targetGroupKey || '').trim()
        }
    ]));
}

function getParamPropPreferences(state) {
    const paramSettings = {};
    state.paramSettings.forEach((setting, key) => {
        if (!state.selectedParams.has(key)) return;
        paramSettings[key] = {
            isInstance: setting?.isInstance !== false,
            targetGroupId: setting?.targetGroupId ?? null,
            targetGroupKey: String(setting?.targetGroupKey || '').trim()
        };
    });
    return {
        excludeDummy: !!state.excludeDummy,
        includeStandaloneFamilies: !!state.includeStandaloneFamilies,
        saveModifiedFamilies: !!state.saveModifiedFamilies,
        selectedParamKeys: Array.from(state.selectedParams),
        paramSettings
    };
}

function normalizedParamPropPreferences(value) {
    const selectedParamKeys = [...new Set((Array.isArray(value?.selectedParamKeys) ? value.selectedParamKeys : [])
        .map((key) => String(key || '').trim()).filter(Boolean))].sort();
    const paramSettings = {};
    selectedParamKeys.forEach((key) => {
        const setting = value?.paramSettings?.[key];
        paramSettings[key] = {
            isInstance: setting?.isInstance !== false,
            targetGroupId: setting?.targetGroupId == null ? null : String(setting.targetGroupId),
            targetGroupKey: String(setting?.targetGroupKey || '').trim().toUpperCase()
        };
    });
    return JSON.stringify({
        excludeDummy: value?.excludeDummy !== false,
        includeStandaloneFamilies: !!value?.includeStandaloneFamilies,
        saveModifiedFamilies: !!value?.saveModifiedFamilies,
        selectedParamKeys,
        paramSettings
    });
}

function saveParamPropPreferences(state) {
    const serialized = JSON.stringify(getParamPropPreferences(state));
    if (serialized === state.lastSavedPreferences) return;
    try {
        localStorage.setItem(PARAMPROP_SETTINGS_KEY, serialized);
        state.lastSavedPreferences = serialized;
    } catch {}
}

function mergeParamPropPreferences(value, baselineValue, currentValue) {
    const incoming = JSON.parse(normalizedParamPropPreferences(value));
    const baseline = JSON.parse(normalizedParamPropPreferences(baselineValue));
    const current = JSON.parse(normalizedParamPropPreferences(currentValue));
    const merged = { ...incoming, paramSettings: {} };
    ['excludeDummy', 'includeStandaloneFamilies', 'saveModifiedFamilies'].forEach((key) => {
        if (current[key] !== baseline[key]) merged[key] = current[key];
    });
    const keys = new Set([...incoming.selectedParamKeys, ...baseline.selectedParamKeys, ...current.selectedParamKeys]);
    merged.selectedParamKeys = [...keys].filter((key) => {
        const selectedNow = current.selectedParamKeys.includes(key);
        const selectedBefore = baseline.selectedParamKeys.includes(key);
        const settingChanged = JSON.stringify(current.paramSettings[key]) !== JSON.stringify(baseline.paramSettings[key]);
        return selectedNow !== selectedBefore || (selectedNow && settingChanged)
            ? selectedNow : incoming.selectedParamKeys.includes(key);
    });
    merged.selectedParamKeys.forEach((key) => {
        const before = baseline.paramSettings[key] || {};
        const now = current.paramSettings[key] || {};
        const remote = incoming.paramSettings[key] || now;
        const setting = {};
        ['isInstance', 'targetGroupId', 'targetGroupKey'].forEach((field) => {
            setting[field] = now[field] !== before[field] ? now[field] : remote[field];
        });
        merged.paramSettings[key] = setting;
    });
    return merged;
}

function attachParamPropPreferenceSync(page, state, refresh) {
    let saveTimer = 0;
    let applyTimer = 0;
    let routeTimer = 0;
    let composing = false;
    let pointerDown = false;
    let pendingPreferences = null;
    let pendingBaseline = null;
    const scheduleSave = () => {
        clearTimeout(saveTimer);
        saveTimer = window.setTimeout(() => saveParamPropPreferences(state), 180);
    };
    const scheduleSaveAfterClick = scheduleSave;
    page.addEventListener('input', scheduleSave);
    page.addEventListener('change', scheduleSave);
    page.addEventListener('click', scheduleSaveAfterClick);

    const tryApply = () => {
        clearTimeout(applyTimer);
        if (!page.isConnected) return;
        const value = pendingPreferences;
        if (!value) return;
        // Host/shared-settings acknowledgements must not replace the current controls.
        if (normalizedParamPropPreferences(value) === normalizedParamPropPreferences(getParamPropPreferences(state))) {
            state.lastSavedPreferences = JSON.stringify(getParamPropPreferences(state));
            pendingPreferences = null;
            pendingBaseline = null;
            return;
        }
        const active = document.activeElement;
        const editing = !!active && page.contains(active) && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName || '');
        if (state.acceptProgress || editing || composing || pointerDown) {
            applyTimer = window.setTimeout(tryApply, 400);
            return;
        }
        const merged = mergeParamPropPreferences(value, pendingBaseline, getParamPropPreferences(state));
        pendingPreferences = null;
        pendingBaseline = null;
        applyParamPropPreferences(state, merged);
        refresh();
        saveParamPropPreferences(state);
    };
    const onCompositionStart = () => { composing = true; };
    const onCompositionEnd = () => { composing = false; };
    const onPointerDown = () => { pointerDown = true; };
    const onPointerUp = () => { pointerDown = false; };
    const onSharedChange = (event) => {
        const detail = event?.detail;
        const keys = Array.isArray(detail?.keys) ? [...detail.keys] : [];
        if (detail?.key) keys.push(detail.key);
        if (detail?.values && typeof detail.values === 'object') keys.push(...Object.keys(detail.values));
        if (detail && keys.length && !keys.includes(PARAMPROP_SETTINGS_KEY)) return;
        const value = loadParamPropPreferences();
        if (!value) return;
        const current = getParamPropPreferences(state);
        if (normalizedParamPropPreferences(value) === normalizedParamPropPreferences(current)) return;
        pendingPreferences = value;
        pendingBaseline = current;
        tryApply();
    };
    const cleanup = () => {
        clearTimeout(saveTimer);
        clearTimeout(applyTimer);
        clearTimeout(routeTimer);
        page.removeEventListener('input', scheduleSave);
        page.removeEventListener('change', scheduleSave);
        page.removeEventListener('click', scheduleSaveAfterClick);
        page.removeEventListener('compositionstart', onCompositionStart, true);
        page.removeEventListener('compositionend', onCompositionEnd, true);
        page.removeEventListener('pointerdown', onPointerDown, true);
        window.removeEventListener('pointerup', onPointerUp, true);
        window.removeEventListener('pointercancel', onPointerUp, true);
        window.removeEventListener('blur', onPointerUp);
        window.removeEventListener('kky:shared-settings-changed', onSharedChange);
        window.removeEventListener('hashchange', onRouteChange);
        if (activeParamPropPreferenceCleanup === cleanup) activeParamPropPreferenceCleanup = null;
    };
    const onRouteChange = () => {
        clearTimeout(routeTimer);
        routeTimer = window.setTimeout(() => {
            if (!page.isConnected) cleanup();
        }, 0);
    };
    window.addEventListener('kky:shared-settings-changed', onSharedChange);
    window.addEventListener('hashchange', onRouteChange);
    page.addEventListener('compositionstart', onCompositionStart, true);
    page.addEventListener('compositionend', onCompositionEnd, true);
    page.addEventListener('pointerdown', onPointerDown, true);
    window.addEventListener('pointerup', onPointerUp, true);
    window.addEventListener('pointercancel', onPointerUp, true);
    window.addEventListener('blur', onPointerUp);
    return cleanup;
}

export function renderParamProp(root) {
    activeParamPropPreferenceCleanup?.();
    const target = root || document.getElementById('view-root') || document.getElementById('app');
    clear(target);
    const top = document.querySelector('#topbar-root .topbar') || document.querySelector('.topbar');
    if (top) top.classList.add('hub-topbar');

    const savedPreferences = loadParamPropPreferences();
    const state = {
        defs: [],
        targetGroups: [],
        selectedParams: new Set(Array.isArray(savedPreferences?.selectedParamKeys) ? savedPreferences.selectedParamKeys : []),
        paramSettings: new Map(Object.entries(savedPreferences?.paramSettings || {})),
        search: '',
        excludeDummy: savedPreferences?.excludeDummy !== false,
        includeStandaloneFamilies: !!savedPreferences?.includeStandaloneFamilies,
        saveModifiedFamilies: !!savedPreferences?.saveModifiedFamilies,
        modifiedFamilyOutputFolder: '',
        acceptProgress: false,
        lastReport: '',
        lastDetails: []
    };
    let lastProgressPct = 0;

    const page = div('paramprop-page feature-shell paramprop-page--main');
    page.dataset.parampropScrollKey = 'page';
    let interactionGeneration = 0;
    ['pointerdown', 'keydown', 'input', 'wheel'].forEach((eventName) => {
        page.addEventListener(eventName, () => { interactionGeneration += 1; }, { capture: true, passive: true });
    });

    const header = div('feature-header');
    const heading = div('feature-heading');
    heading.innerHTML = `
      <span class="feature-kicker">공유파라미터 연동</span>
      <h2 class="feature-title">복합패밀리 공유파라미터 추가/연동</h2>
      <p class="feature-sub">복합 패밀리의 하위 패밀리에 공유파라미터를 추가하고 연동 및 검증을 수행합니다.</p>`;

    const runBtn = cardBtn('연동 실행', onRun);
    runBtn.id = 'btnParamPropRun';
    const exportBtn = cardBtn('엑셀 내보내기', onExport);
    exportBtn.id = 'btnParamPropExport';
    exportBtn.disabled = true;

    const actions = div('feature-actions');
    actions.append(runBtn, exportBtn);
    header.append(heading, actions);
    page.append(header);

    const layout = div('paramprop-layout');
    layout.dataset.parampropScrollKey = 'layout';
    page.append(layout);

    const pickerCard = div('paramprop-card section paramprop-picker-card');
    pickerCard.dataset.parampropScrollKey = 'picker';
    pickerCard.innerHTML = '<div class="paramprop-title">공유파라미터 선택</div>';

    const sharedStatusRow = div('paramprop-row paramprop-shared-status-row');
    const sharedStatusText = div('paramprop-shared-status-text');
    sharedStatusText.textContent = 'Revit 연결 공유파라미터를 확인하는 중입니다.';
    sharedStatusRow.append(sharedStatusText);
    pickerCard.append(sharedStatusRow);

    const searchRow = div('paramprop-row paramprop-search-row');
    const searchBox = document.createElement('input');
    searchBox.type = 'search';
    searchBox.placeholder = '공유파라미터 이름 또는 그룹 검색';
    searchBox.className = 'paramprop-search';
    searchBox.dataset.parampropFocusKey = 'search';
    searchBox.addEventListener('input', debounce((e) => {
        state.search = (e.target.value || '').trim();
        renderTable(false);
    }, 120));
    searchRow.append(labelSpan('검색'), searchBox);
    pickerCard.append(searchRow);

    const selectGrid = div('paramprop-grid');
    selectGrid.dataset.parampropScrollKey = 'grid';
    pickerCard.append(selectGrid);

    const tableBox = div('paramprop-table-box paramprop-param-box');
    tableBox.dataset.parampropScrollKey = 'parameters';
    const tableHead = div('paramprop-subtitle');
    tableHead.textContent = '파라미터';
    const table = document.createElement('table');
    table.className = 'paramprop-table';
    const thead = document.createElement('thead');
    thead.innerHTML = '<tr><th>선택</th><th>이름</th></tr>';
    const tbody = document.createElement('tbody');
    table.append(thead, tbody);
    const tableWrap = div('paramprop-table-wrap');
    tableWrap.dataset.parampropScrollKey = 'parameter-list';
    tableWrap.append(table);
    tableBox.append(tableHead, tableWrap);
    selectGrid.append(tableBox);

    const selectedBox = div('paramprop-table-box paramprop-selected-box');
    selectedBox.dataset.parampropScrollKey = 'selected';
    const selectedHead = div('paramprop-subtitle paramprop-selected-head');
    const selectedTitle = document.createElement('span');
    selectedTitle.textContent = '선택된 공유파라미터';
    const selectedBadge = document.createElement('span');
    selectedBadge.className = 'chip chip--info';
    selectedHead.append(selectedTitle, selectedBadge);
    const selectedSettings = div('paramprop-selected-settings');
    selectedSettings.dataset.parampropScrollKey = 'selected-settings';
    const selectedHint = div('paramprop-selected-note');
    selectedHint.textContent = '각 파라미터의 Binding과 Parameter Group을 실행 전까지 개별로 수정할 수 있습니다.';
    selectedBox.append(selectedHead, selectedSettings, selectedHint);
    selectGrid.append(selectedBox);

    const optionPanel = div('paramprop-settings-panel');
    optionPanel.dataset.parampropScrollKey = 'options';
    const scopeGroup = settingGroup('적용 범위', '하위 패밀리 제외 규칙과 단일 패밀리 처리 여부를 정합니다.');
    const saveGroup = settingGroup('저장 옵션', '필요한 경우 수정된 패밀리 파일을 별도 폴더에 저장합니다.');
    scopeGroup.classList.add('paramprop-setting-group--scope');
    saveGroup.classList.add('paramprop-setting-group--save');

    const optionRow = div('paramprop-row paramprop-options paramprop-scope-options');
    const dummyWrap = div('paramprop-opt');
    const dummyChk = document.createElement('input');
    dummyChk.type = 'checkbox';
    dummyChk.checked = !!state.excludeDummy;
    dummyChk.id = 'optDummy';
    dummyChk.dataset.parampropFocusKey = 'exclude-dummy';
    dummyChk.addEventListener('change', () => { state.excludeDummy = !!dummyChk.checked; });
    const dummyLbl = document.createElement('label');
    dummyLbl.setAttribute('for', 'optDummy');
    dummyLbl.textContent = "하위 패밀리 'Dummy' 포함 요소 제외";
    dummyWrap.append(dummyChk, dummyLbl);

    const standaloneWrap = div('paramprop-opt');
    const standaloneChk = document.createElement('input');
    standaloneChk.type = 'checkbox';
    standaloneChk.checked = !!state.includeStandaloneFamilies;
    standaloneChk.id = 'optStandaloneFamilies';
    standaloneChk.dataset.parampropFocusKey = 'standalone-families';
    standaloneChk.addEventListener('change', () => { state.includeStandaloneFamilies = !!standaloneChk.checked; });
    const standaloneLbl = document.createElement('label');
    standaloneLbl.setAttribute('for', 'optStandaloneFamilies');
    standaloneLbl.textContent = '단일 패밀리까지 파라미터 추가 (연동 제외)';
    standaloneWrap.append(standaloneChk, standaloneLbl);

    optionRow.append(dummyWrap, standaloneWrap);
    scopeGroup.append(optionRow);

    const saveRow = div('paramprop-row paramprop-save-row');
    const saveWrap = div('paramprop-opt paramprop-opt-save');
    const saveChk = document.createElement('input');
    saveChk.type = 'checkbox';
    saveChk.checked = !!state.saveModifiedFamilies;
    saveChk.id = 'optSaveModifiedFamilies';
    saveChk.dataset.parampropFocusKey = 'save-families';
    const saveLbl = document.createElement('label');
    saveLbl.setAttribute('for', 'optSaveModifiedFamilies');
    saveLbl.textContent = '수정된 패밀리(.rfa) 파일 저장';
    saveWrap.append(saveChk, saveLbl);

    const savePathWrap = div('paramprop-opt paramprop-opt-save-path is-disabled');
    const savePathLbl = labelSpan('저장 폴더');
    const savePathInput = document.createElement('input');
    savePathInput.type = 'text';
    savePathInput.className = 'paramprop-search paramprop-folder-input';
    savePathInput.dataset.parampropFocusKey = 'output-folder';
    savePathInput.placeholder = '수정된 패밀리(.rfa)를 저장할 폴더를 선택해 주세요';
    savePathInput.disabled = true;
    const saveBrowseBtn = document.createElement('button');
    saveBrowseBtn.type = 'button';
    saveBrowseBtn.className = 'btn btn-secondary';
    saveBrowseBtn.dataset.parampropFocusKey = 'browse-folder';
    saveBrowseBtn.textContent = '찾아보기';
    saveBrowseBtn.disabled = true;
    savePathWrap.append(savePathLbl, savePathInput, saveBrowseBtn);
    saveRow.append(saveWrap, savePathWrap);
    saveGroup.append(saveRow);
    optionPanel.append(scopeGroup, saveGroup);
    pickerCard.append(optionPanel);

    const resultCard = div('paramprop-card section paramprop-report-card');
    const resultTitle = div('paramprop-title');
    resultTitle.textContent = '결과';
    const reportBox = document.createElement('pre');
    reportBox.className = 'paramprop-report';
    reportBox.dataset.parampropScrollKey = 'report';
    reportBox.textContent = DEFAULT_GUIDE;

    const filterRow = div('paramprop-row paramprop-filters');
    filterRow.innerHTML = '<span class="opt-label">결과 필터</span>';
    const filterAll = chip('전체', 'all');
    const filterScan = chip('스캔 실패', 'ScanFail');
    const filterSkip = chip('건너뜀', 'Skip');
    const filterErr = chip('오류', 'Error');
    const filterChild = chip('하위 오류', 'ChildError');
    const filters = [filterAll, filterScan, filterSkip, filterErr, filterChild];
    filterAll.classList.add('is-active');
    filterRow.append(filterAll, filterScan, filterSkip, filterErr, filterChild);

    const detailTable = document.createElement('table');
    detailTable.className = 'paramprop-detail';
    detailTable.innerHTML = '<thead><tr><th>상태</th><th>패밀리</th><th>상세</th></tr></thead><tbody></tbody>';
    const detailWrap = div('paramprop-detail-wrap');
    detailWrap.dataset.parampropScrollKey = 'details';
    detailWrap.append(detailTable);

    resultCard.append(resultTitle, reportBox, filterRow, detailWrap);

    layout.append(pickerCard, resultCard);
    target.append(page);

    onHost('sharedparam:list', handleList);
    onHost('sharedparam:status', handleSharedParamStatus);
    onHost('sharedparam:done', handleDone);
    onHost('sharedparam:exported', handleExported);
    onHost('paramprop:progress', handleProgress);
    onHost('paramprop:output-folder-picked', ({ path }) => {
        if (!path) return;
        state.modifiedFamilyOutputFolder = String(path || '').trim();
        savePathInput.value = state.modifiedFamilyOutputFolder;
    });
    onHost('revit:error', ({ message }) => {
        state.acceptProgress = false;
        lastProgressPct = 0;
        ProgressDialog.hide();
        setBusy(false);
        toast(message || '패밀리 공유파라미터 연동 중 Revit 오류가 발생했습니다. Revit 공유 매개변수 연결, 대상 패밀리, 저장 옵션을 확인한 뒤 다시 실행해 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err', 3200);
    });
    onHost('host:error', ({ message }) => {
        state.acceptProgress = false;
        lastProgressPct = 0;
        ProgressDialog.hide();
        setBusy(false);
        toast(message || '패밀리 공유파라미터 연동 중 호스트 오류가 발생했습니다. Hub 화면을 다시 열고 Revit 연결 상태를 확인한 뒤 다시 실행해 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err', 3200);
    });

    fetchDefinitions();
    saveChk.addEventListener('change', () => {
        state.saveModifiedFamilies = !!saveChk.checked;
        if (!state.saveModifiedFamilies) {
            state.modifiedFamilyOutputFolder = '';
            savePathInput.value = '';
        }
        syncSaveOptions();
    });
    savePathInput.addEventListener('input', () => {
        state.modifiedFamilyOutputFolder = String(savePathInput.value || '').trim();
    });
    saveBrowseBtn.addEventListener('click', () => {
        if (!state.saveModifiedFamilies) return;
        post('paramprop:browse-output-folder', { currentPath: state.modifiedFamilyOutputFolder || '' });
    });
    syncSaveOptions();
    activeParamPropPreferenceCleanup = attachParamPropPreferenceSync(page, state, () => {
        dummyChk.checked = !!state.excludeDummy;
        standaloneChk.checked = !!state.includeStandaloneFamilies;
        saveChk.checked = !!state.saveModifiedFamilies;
        if (!state.saveModifiedFamilies) {
            state.modifiedFamilyOutputFolder = '';
            savePathInput.value = '';
        }
        reconcileSelectionState();
        renderTable();
        syncSaveOptions();
        syncRunState();
    });

    function fetchDefinitions() {
        setBusy(true, '공유파라미터를 불러오는 중입니다.');
        post('sharedparam:status', getParamPropContextPayload());
        post('sharedparam:list', getParamPropContextPayload());
    }

    function handleSharedParamStatus(payload) {
        const status = String(payload?.status || '').toLowerCase();
        const warning = String(payload?.warning || payload?.errorMessage || '').trim();
        const ok = status === 'ok' || (payload?.isSet && payload?.existsOnDisk && payload?.canOpen);
        sharedStatusRow.classList.toggle('is-ok', !!ok);
        sharedStatusRow.classList.toggle('is-warn', !ok);
        sharedStatusText.textContent = ok
            ? 'Revit 연결 공유파라미터를 읽었습니다.'
            : (warning || 'Revit에 연결된 공유 매개변수가 없거나 열 수 없습니다. 관리 > 공유 매개변수에서 연결한 뒤 이 화면을 다시 열어 주세요.');
    }

    function handleList(payload) {
        setBusy(false);
        const ok = payload?.ok !== false;
        if (!ok) {
            toast(payload?.message || '공유파라미터 목록을 불러오지 못했습니다.', 'warn');
            state.defs = [];
            renderTable();
            return;
        }

        if (Array.isArray(payload?.items)) {
            state.defs = payload.items.map((item) => ({
                groupName: item.groupName || '',
                name: item.name || '',
                guid: item.guid || '',
                paramType: item.dataTypeToken || '',
                visible: true
            }));
        } else {
            state.defs = Array.isArray(payload?.definitions) ? payload.definitions : [];
        }
        state.targetGroups = Array.isArray(payload?.targetGroups) ? payload.targetGroups : [];
        reconcileSelectionState();
        renderTable();
        updateSharedStatusCount();
        syncRunState();
        saveParamPropPreferences(state);
    }

    function handleDone({ ok, status, message, report, details, rows }) {
        state.acceptProgress = false;
        setBusy(false);
        const statusKey = String(status || '').trim().toLowerCase();
        const cancelled = statusKey === 'cancelled' || statusKey === 'canceled';
        const good = ok !== false && (statusKey === 'succeeded' || statusKey === 'success' || (!statusKey && ok === true));
        const resultLabel = good ? '완료' : (cancelled ? '취소' : (statusKey === 'blocked' ? '실행 불가' : '실패'));
        const msg = message || (good ? '공유파라미터 연동이 완료되었습니다.' : (cancelled ? '공유파라미터 연동이 취소되었습니다.' : '공유파라미터 연동에 실패했습니다.'));
        state.lastReport = typeof report === 'string' ? report : '';
        state.lastDetails = Array.isArray(rows) ? rows : (Array.isArray(details) ? details : []);
        paintReport(state.lastReport || msg);
        paintDetails(getActiveFilterKey());
        exportBtn.disabled = !hasExportableResult();

        toast(msg, good ? 'ok' : (cancelled ? 'info' : 'err'), 2800);
        ProgressDialog.update(100, `실행 결과: ${resultLabel}`, msg);
        const detailSummary = summarizeDetailRows(state.lastDetails);
        const summaryItems = [
            { label: '선택 파라미터 수', value: String(state.selectedParams.size) },
            { label: '오류 행 수', value: String(detailSummary.errorCount) },
            { label: '건너뜀 행 수', value: String(detailSummary.skipCount) },
            { label: '검토 필요 행 수', value: String(detailSummary.reviewCount) },
            { label: '실행 결과', value: resultLabel }
        ];
        const notes = [];
        if (detailSummary.totalCount === 0 && good) notes.push('상세 결과에 표시할 오류 또는 건너뜀 항목이 없습니다.');
        if (detailSummary.scanFailCount > 0) notes.push(`스캔 실패: ${detailSummary.scanFailCount}건`);
        if (detailSummary.childErrorCount > 0) notes.push(`하위 오류: ${detailSummary.childErrorCount}건`);
        setTimeout(() => {
            lastProgressPct = 0;
            ProgressDialog.hide();
            requestAnimationFrame(() => {
                showCompletionSummaryDialog({
                    title: `공유파라미터 연동 ${resultLabel}`,
                    message: msg,
                    summaryItems,
                    notes,
                    exportDisabled: exportBtn.disabled,
                    onExport: () => exportBtn.click()
                });
            });
        }, 400);
    }

    function summarizeDetailRows(rows) {
        const summary = {
            totalCount: 0,
            skipCount: 0,
            scanFailCount: 0,
            errorCount: 0,
            childErrorCount: 0,
            reviewCount: 0
        };
        (Array.isArray(rows) ? rows : []).forEach((row) => {
            summary.totalCount += 1;
            const kind = String(row?.type || row?.kind || '').trim().toLowerCase();
            if (kind === 'skip') {
                summary.skipCount += 1;
                return;
            }
            if (kind === 'scanfail') {
                summary.scanFailCount += 1;
                return;
            }
            if (kind === 'error') {
                summary.errorCount += 1;
                return;
            }
            if (kind === 'childerror') {
                summary.childErrorCount += 1;
                return;
            }
            summary.reviewCount += 1;
        });
        summary.errorCount += summary.scanFailCount + summary.childErrorCount;
        summary.reviewCount += summary.errorCount;
        return summary;
    }

    function handleExported({ ok, path, message }) {
        state.acceptProgress = false;
        ProgressDialog.hide();
        setBusy(false);
        exportBtn.disabled = !hasExportableResult();
        if (ok && path) {
            showExcelSavedDialog('패밀리 공유파라미터 연동 결과 엑셀을 저장했습니다.', path, (p) => post('excel:open', { path: p }));
        } else {
            toast(message || '패밀리 공유파라미터 연동 결과 엑셀 내보내기에 실패했습니다. 저장 경로 권한과 파일 열림 상태를 확인한 뒤, 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err');
        }
    }

    function onRun() {
        const selectedDefs = getSelectedDefinitions();
        if (!selectedDefs.length) {
            toast('하나 이상의 파라미터를 선택해 주세요.', 'warn');
            return;
        }
        if (state.saveModifiedFamilies && !String(state.modifiedFamilyOutputFolder || '').trim()) {
            toast('수정된 패밀리(.rfa)를 저장할 폴더를 선택해 주세요.', 'warn');
            return;
        }
        const invalidSetting = selectedDefs.find((def) => {
            const setting = ensureParamSetting(def);
            return !setting?.targetGroupKey && setting?.targetGroupId == null;
        });
        if (invalidSetting) {
            toast(`${invalidSetting.name || '선택 파라미터'}의 Parameter Group을 선택해 주세요.`, 'warn');
            return;
        }
        lastProgressPct = 0;
        state.acceptProgress = true;
        const standaloneMode = !!state.includeStandaloneFamilies;
        setBusy(true, standaloneMode ? '공유파라미터를 추가하는 중입니다.' : '공유파라미터를 연동하는 중입니다.');
        ProgressDialog.show(
            standaloneMode ? '공유파라미터 추가' : '공유파라미터 추가 및 연동',
            standaloneMode ? '파라미터 추가 구성을 확인하는 중입니다.' : '연동 구성을 확인하는 중입니다.'
        );
        ProgressDialog.update(
            0,
            standaloneMode ? '파라미터 추가 구성을 확인하는 중입니다.' : '연동 구성을 확인하는 중입니다.',
            '선택한 파라미터와 저장 옵션을 정리하는 중입니다.'
        );
        exportBtn.disabled = true;
        const paramSelections = selectedDefs.map((def) => {
            const setting = ensureParamSetting(def);
            return {
                name: String(def?.name || '').trim(),
                guid: String(def?.guid || '').trim(),
                groupName: String(def?.groupName || '').trim(),
                targetGroup: setting?.targetGroupId ?? null,
                targetGroupKey: String(setting?.targetGroupKey || '').trim(),
                isInstance: setting?.isInstance !== false
            };
        });
        const legacySetting = paramSelections[0] || {};
        const payload = {
            paramSelections,
            paramNames: paramSelections.map((item) => item.name).filter(Boolean),
            paramGuids: paramSelections.map((item) => item.guid).filter(Boolean),
            paramGroups: paramSelections.map((item) => item.groupName),
            activeDocument: getParamPropActiveDocumentInfo(),
            group: legacySetting.targetGroup ?? null,
            groupKey: legacySetting.targetGroupKey || '',
            isInstance: legacySetting.isInstance !== false,
            excludeDummy: !!state.excludeDummy,
            includeStandaloneFamilies: standaloneMode,
            saveModifiedFamilies: !!state.saveModifiedFamilies,
            modifiedFamilyOutputFolder: String(state.modifiedFamilyOutputFolder || '').trim()
        };
        post('sharedparam:run', payload);
    }

    function getParamPropActiveDocumentInfo() {
        const doc = getTopbarState()?.activeDocument || {};
        const name = String(doc.name || doc.title || '').trim();
        const path = String(doc.path || doc.filePath || '').trim();
        return {
            name,
            title: name,
            path,
            filePath: path,
            isLinked: !!doc.isLinked
        };
    }

    function getParamPropContextPayload(extra = {}) {
        return {
            source: 'paramprop',
            activeDocument: getParamPropActiveDocumentInfo(),
            ...extra
        };
    }

    function hasExportableResult() {
        return String(state.lastReport || '').trim().length > 0 || state.lastDetails.length > 0;
    }

    async function onExport() {
        if (!hasExportableResult()) {
            toast('최근 연동 결과가 없습니다.', 'info');
            return;
        }
        const excelMode = await chooseExcelMode();
        if (!excelMode) return;
        state.acceptProgress = true;
        setBusy(true, '엑셀을 내보내는 중입니다.');
        ProgressDialog.show('공유파라미터 결과 내보내기', '엑셀 내보내기를 준비하는 중입니다.');
        ProgressDialog.update(0, '엑셀 내보내기를 준비하는 중입니다.', '검토 결과와 저장 옵션을 정리하는 중입니다.');
        post('sharedparam:export-excel', { excelMode, locale: getLastExcelExportLocale() });
    }

    function updateSharedStatusCount() {
        const count = Array.isArray(state.defs) ? state.defs.length : 0;
        if (!sharedStatusRow.classList.contains('is-ok')) return;
        sharedStatusText.textContent = `Revit 연결 공유파라미터 ${count}개`;
    }

    function renderSelectedParamSettings() {
        selectedBadge.textContent = `${state.selectedParams.size}개`;
        selectedSettings.innerHTML = '';
        if (!state.selectedParams.size) {
            const empty = div('paramprop-empty-chip');
            empty.textContent = '공유파라미터를 선택하면 여기에 표시됩니다.';
            selectedSettings.append(empty);
            return;
        }

        getSelectedDefinitions().forEach((def, index) => {
            const key = getParamKey(def);
            const setting = ensureParamSetting(def);
            const row = div('paramprop-selection-row');

            const meta = div('paramprop-selection-meta');
            const name = document.createElement('strong');
            name.textContent = String(def?.name || '').trim() || '이름 없음';
            const source = document.createElement('span');
            source.textContent = String(def?.groupName || '').trim() || '공유파라미터 그룹 없음';
            meta.append(name, source);

            const binding = div('paramprop-selection-binding');
            const bindingLabel = document.createElement('span');
            bindingLabel.className = 'paramprop-selection-label';
            bindingLabel.textContent = 'Binding';
            const bindingOptions = div('paramprop-selection-segment');
            const radioName = `paramprop-binding-${index}-${key.replace(/[^a-z0-9_-]+/gi, '-')}`;
            bindingOptions.append(
                selectionRadio(radioName, '인스턴스', setting.isInstance !== false, () => {
                    setting.isInstance = true;
                    state.paramSettings.set(key, setting);
                }, `binding-instance:${key}`),
                selectionRadio(radioName, '타입', setting.isInstance === false, () => {
                    setting.isInstance = false;
                    state.paramSettings.set(key, setting);
                }, `binding-type:${key}`)
            );
            binding.append(bindingLabel, bindingOptions);

            const groupWrap = div('paramprop-selection-group');
            const groupLabel = document.createElement('label');
            groupLabel.className = 'paramprop-selection-label';
            groupLabel.textContent = 'Parameter Group';
            const groupSelect = document.createElement('select');
            groupSelect.className = 'paramprop-select paramprop-selection-group-select';
            groupSelect.dataset.parampropFocusKey = `group:${key}`;
            if (!state.targetGroups.length) {
                const unavailable = document.createElement('option');
                unavailable.value = '';
                unavailable.textContent = '선택 가능한 그룹 없음';
                groupSelect.append(unavailable);
                groupSelect.disabled = true;
            } else {
                state.targetGroups.forEach((option) => {
                    const opt = document.createElement('option');
                    opt.value = String(option?.id ?? '');
                    opt.textContent = formatRevitParamGroupLabel(option?.name || option?.label || option?.key || option?.id);
                    groupSelect.append(opt);
                });
                const currentGroup = findTargetGroup(setting.targetGroupId, setting.targetGroupKey) || getDefaultTargetGroup();
                if (currentGroup) {
                    groupSelect.value = String(currentGroup.id ?? '');
                    setting.targetGroupId = currentGroup.id ?? null;
                    setting.targetGroupKey = String(currentGroup.key || '').trim();
                    state.paramSettings.set(key, setting);
                }
            }
            groupSelect.addEventListener('change', () => {
                const selectedGroup = findTargetGroup(groupSelect.value, '');
                setting.targetGroupId = selectedGroup?.id ?? null;
                setting.targetGroupKey = String(selectedGroup?.key || '').trim();
                state.paramSettings.set(key, setting);
            });
            groupWrap.append(groupLabel, groupSelect);

            const removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'btn btn-ghost paramprop-selection-remove';
            removeBtn.textContent = '제거';
            removeBtn.title = `${name.textContent} 선택 제거`;
            removeBtn.dataset.parampropFocusKey = `remove:${key}`;
            removeBtn.dataset.parampropFocusFallback = `parameter:${key}`;
            removeBtn.addEventListener('click', () => {
                deselectParam(key);
                renderTable();
                syncRunState();
            });

            row.append(meta, binding, groupWrap, removeBtn);
            selectedSettings.append(row);
        });
    }

    function preserveSettingsInteraction(render) {
        const generation = ++interactionGeneration;
        const active = page.contains(document.activeElement) ? document.activeElement : null;
        const focusKey = active?.dataset.parampropFocusKey;
        const fallbackKey = active?.dataset.parampropFocusFallback;
        const value = active?.value;
        const checked = active?.checked;
        const selection = typeof active?.selectionStart === 'number'
            ? [active.selectionStart, active.selectionEnd, active.selectionDirection] : null;
        const nodes = new Set([page, ...page.querySelectorAll('[data-paramprop-scroll-key]')]);
        for (let parent = page.parentElement; parent; parent = parent.parentElement) nodes.add(parent);
        if (document.scrollingElement) nodes.add(document.scrollingElement);
        const scroll = [...nodes].map((node) => ({ node, key: node.dataset.parampropScrollKey, top: node.scrollTop, left: node.scrollLeft }));
        render();
        const findKey = (attribute, key) => key
            ? [...page.querySelectorAll(`[${attribute}]`)].find((node) => node.getAttribute(attribute) === key) : null;
        const focused = active?.isConnected ? active
            : findKey('data-paramprop-focus-key', focusKey) || findKey('data-paramprop-focus-key', fallbackKey);
        if (focused && focused !== active && !focused.disabled) {
            // Restore a replaced control only when it still represents the same setting.
            if (focused.dataset.parampropFocusKey === focusKey) {
                if (value !== undefined) focused.value = value;
                if (checked !== undefined) focused.checked = checked;
            }
            focused.focus({ preventScroll: true });
            if (selection && typeof focused.setSelectionRange === 'function') {
                try { focused.setSelectionRange(...selection); } catch {}
            }
        }
        const restoreScroll = () => {
            if (!page.isConnected || generation !== interactionGeneration) return;
            scroll.forEach(({ node, key, top, left }) => {
                const current = node.isConnected ? node : findKey('data-paramprop-scroll-key', key);
                if (!current) return;
                current.scrollTop = top;
                current.scrollLeft = left;
            });
        };
        restoreScroll();
        requestAnimationFrame(() => {
            restoreScroll();
            requestAnimationFrame(restoreScroll);
        });
    }

    function renderTable(renderSelection = true) {
        preserveSettingsInteraction(() => {
            renderParameterTable();
            if (renderSelection) renderSelectedParamSettings();
        });
    }

    function renderParameterTable() {
        tbody.innerHTML = '';
        const filtered = filterDefs();
        if (!filtered.length) {
            const tr = document.createElement('tr');
            const tdEmpty = document.createElement('td');
            tdEmpty.colSpan = 2;
            tdEmpty.textContent = state.defs.length
                ? '조건에 맞는 항목이 없습니다.'
                : '공유파라미터 등록이 필요합니다. Revit의 관리 > 공유 매개변수에서 파일을 연결한 뒤 다시 시도해 주세요.';
            tdEmpty.className = 'paramprop-empty';
            tr.append(tdEmpty);
            tbody.append(tr);
            return;
        }

        filtered.forEach((def) => {
            const key = getParamKey(def);
            const tr = document.createElement('tr');
            tr.dataset.key = key;
            tr.dataset.type = def.paramType || '';
            tr.dataset.visible = def.visible ? 'true' : 'false';
            tr.dataset.group = def.groupName || '';
            tr.className = state.selectedParams.has(key) ? 'is-selected' : '';
            const tdChk = document.createElement('td');
            const chk = document.createElement('input');
            chk.type = 'checkbox';
            chk.checked = state.selectedParams.has(key);
            chk.dataset.parampropFocusKey = `parameter:${key}`;
            chk.addEventListener('click', (e) => e.stopPropagation());
            chk.addEventListener('change', () => {
                if (chk.checked) selectParam(def); else deselectParam(key);
                renderTable();
                syncRunState();
            });
            tdChk.append(chk);
            const nameCell = td(def.name);
            const visibilityText = def.visible ? '표시' : '숨김';
            nameCell.setAttribute('aria-label', `${def.groupName || ''} · ${def.paramType || ''} · ${visibilityText}`.trim());
            tr.append(tdChk, nameCell);
            tr.addEventListener('click', () => {
                if (state.selectedParams.has(key)) deselectParam(key); else selectParam(def);
                renderTable();
                syncRunState();
            });
            tbody.append(tr);
        });
    }

    function getParamKey(def) {
        const guid = String(def?.guid || '').trim().toLowerCase();
        if (guid) return `guid:${guid}`;
        const group = String(def?.groupName || '').trim().toLowerCase();
        const name = String(def?.name || '').trim().toLowerCase();
        return `name:${group}::${name}`;
    }

    function getSelectedDefinitions() {
        const selected = state.selectedParams || new Set();
        return (Array.isArray(state.defs) ? state.defs : []).filter((def) => selected.has(getParamKey(def)));
    }

    function selectParam(def) {
        const key = getParamKey(def);
        state.selectedParams.add(key);
        ensureParamSetting(def);
    }

    function deselectParam(keyOrDef) {
        const key = typeof keyOrDef === 'string' ? keyOrDef : getParamKey(keyOrDef);
        state.selectedParams.delete(key);
        state.paramSettings.delete(key);
    }

    function ensureParamSetting(def) {
        const key = getParamKey(def);
        let setting = state.paramSettings.get(key);
        const matchedGroup = setting
            ? findTargetGroup(setting.targetGroupId, setting.targetGroupKey)
            : null;
        const targetGroup = matchedGroup || getDefaultTargetGroup();
        if (!setting) {
            setting = {
                isInstance: true,
                targetGroupId: targetGroup?.id ?? null,
                targetGroupKey: String(targetGroup?.key || '').trim()
            };
        } else if (targetGroup) {
            setting.targetGroupId = targetGroup.id ?? null;
            setting.targetGroupKey = String(targetGroup.key || '').trim();
        }
        state.paramSettings.set(key, setting);
        return setting;
    }

    function getDefaultTargetGroup() {
        const groups = Array.isArray(state.targetGroups) ? state.targetGroups : [];
        return groups.find((item) => String(item?.key || '').trim().toUpperCase() === 'PG_TEXT')
            || groups.find((item) => formatRevitParamGroupLabel(item?.name || item?.label || item?.key).toLowerCase() === 'text')
            || groups[0]
            || null;
    }

    function findTargetGroup(id, key) {
        const groups = Array.isArray(state.targetGroups) ? state.targetGroups : [];
        const keyText = String(key || '').trim();
        if (keyText) {
            const byKey = groups.find((item) => String(item?.key || '').trim().toLowerCase() === keyText.toLowerCase());
            if (byKey) return byKey;
        }
        if (id == null || String(id) === '') return null;
        return groups.find((item) => String(item?.id ?? '') === String(id)) || null;
    }

    function reconcileSelectionState() {
        const available = new Set((state.defs || []).map(getParamKey));
        Array.from(state.selectedParams).forEach((key) => {
            if (!available.has(key)) deselectParam(key);
        });
        Array.from(state.paramSettings.keys()).forEach((key) => {
            if (!state.selectedParams.has(key)) state.paramSettings.delete(key);
        });
        getSelectedDefinitions().forEach(ensureParamSetting);
    }

    function selectionRadio(name, label, checked, onChange, focusKey) {
        const wrap = document.createElement('label');
        wrap.className = 'paramprop-selection-radio';
        const input = document.createElement('input');
        input.type = 'radio';
        input.name = name;
        input.checked = checked;
        input.dataset.parampropFocusKey = focusKey;
        input.addEventListener('change', () => {
            if (input.checked && typeof onChange === 'function') onChange();
        });
        const text = document.createElement('span');
        text.textContent = label;
        wrap.append(input, text);
        return wrap;
    }

    function syncRunState() {
        runBtn.disabled = state.selectedParams.size === 0 || state.targetGroups.length === 0;
    }

    function filterDefs() {
        const search = String(state.search || '').toLowerCase();
        return state.defs.filter((d) => {
            if (!search) return true;
            return (d.name || '').toLowerCase().includes(search) || (d.groupName || '').toLowerCase().includes(search);
        });
    }

    function paintReport(text) {
        reportBox.textContent = text || DEFAULT_GUIDE;
    }

    function paintDetails(kind) {
        const body = detailTable.querySelector('tbody');
        body.innerHTML = '';
        const rows = (state.lastDetails || []).filter((r) => {
            const t = r.type || r.kind || '';
            return kind === 'all' || t === kind;
        });
        if (!rows.length) {
            const tr = document.createElement('tr');
            const td = document.createElement('td');
            td.colSpan = 3;
            td.textContent = state.lastDetails.length ? '필터 결과가 없습니다.' : (state.lastReport ? '상세 오류 또는 건너뜀 항목이 없습니다.' : '결과가 없습니다.');
            tr.append(td);
            body.append(tr);
            return;
        }
        rows.forEach((r) => {
            const tr = document.createElement('tr');
            tr.append(td(r.type || r.kind), td(r.family), td(r.detail));
            body.append(tr);
        });
    }

    filters.forEach((btn) => {
        btn.addEventListener('click', () => {
            filters.forEach((b) => b.classList.remove('is-active'));
            btn.classList.add('is-active');
            const key = btn.dataset.key || 'all';
            paintDetails(key);
        });
    });

    function getActiveFilterKey() {
        return filters.find((f) => f.classList.contains('is-active'))?.dataset.key || 'all';
    }

    function labelSpan(text) {
        const s = document.createElement('span');
        s.className = 'opt-label';
        s.textContent = text;
        return s;
    }

    function settingGroup(title, desc) {
        const box = div('paramprop-setting-group');
        const head = div('paramprop-setting-head');
        const titleEl = document.createElement('span');
        titleEl.textContent = title;
        head.append(titleEl);
        const descEl = div('paramprop-setting-desc');
        descEl.textContent = desc;
        box.append(head, descEl);
        return box;
    }

    function radio(name, label, checked, onChange) {
        const wrap = document.createElement('label');
        wrap.className = 'paramprop-radio';
        const rb = document.createElement('input');
        rb.type = 'radio';
        rb.name = name;
        rb.checked = checked;
        rb.addEventListener('change', () => { if (rb.checked && typeof onChange === 'function') onChange(); });
        const span = document.createElement('span');
        span.textContent = label;
        wrap.append(rb, span);
        return wrap;
    }

    function chip(label, key) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'paramprop-chip-btn';
        btn.textContent = label;
        btn.dataset.key = key;
        return btn;
    }

    function td(text) {
        const cell = document.createElement('td');
        cell.textContent = text == null ? '' : text;
        return cell;
    }

    function cardBtn(label, onClick) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-primary';
        btn.textContent = label;
        btn.onclick = onClick;
        return btn;
    }

    function syncSaveOptions() {
        const enabled = !!state.saveModifiedFamilies;
        savePathInput.disabled = !enabled;
        saveBrowseBtn.disabled = !enabled;
        savePathWrap.classList.toggle('is-disabled', !enabled);
    }

    function handleProgress(payload) {
        if (!state.acceptProgress) return;
        if (!payload) {
            ProgressDialog.hide();
            return;
        }
        const phase = String(payload.phase || payload.Stage || '').toLowerCase();
        const phaseProgress = clamp01(payload.phaseProgress);
        const current = Number(payload.current || payload.Index || 0) || 0;
        const total = Number(payload.total || payload.Total || 0) || 0;
        const message = payload.message || payload.Message || '';
        const targetLabel = payload.target || payload.Target || '';

        const basePct = computeBasePercent(phase);
        const weight = PHASE_WEIGHT[phase] || 0;
        const rawPct = phase === 'done' ? 100 : Math.min(100, Math.max(0, (basePct + weight * phaseProgress) * 100));
        const percent = Math.max(lastProgressPct, rawPct);
        lastProgressPct = percent;

        const subtitle = buildSubtitle(phase, current, total);
        const detail = buildDetail(message, targetLabel);

        ProgressDialog.show('공유파라미터 추가 및 연동', subtitle);
        ProgressDialog.update(percent, subtitle, detail);

        if (phase === 'done') {
            setTimeout(() => { lastProgressPct = 0; ProgressDialog.hide(); }, 450);
        }
    }

    function clamp01(v) {
        const n = Number(v);
        if (!Number.isFinite(n)) return 0;
        return Math.max(0, Math.min(1, n));
    }

    function computeBasePercent(phase) {
        const p = String(phase || '').toLowerCase();
        let acc = 0;
        for (const key of PHASE_ORDER) {
            if (key === p) break;
            acc += PHASE_WEIGHT[key] || 0;
        }
        return acc;
    }

    function buildSubtitle(phase, current, total) {
        const label = PHASE_LABEL[phase] || '패밀리 공유파라미터 연동을 진행하는 중입니다.';
        const count = total > 0 ? ` (${Math.max(current, 0)}/${total})` : '';
        return `${label}${count}`;
    }

    function buildDetail(message, targetLabel) {
        const parts = [];
        if (message) parts.push(message);
        if (targetLabel) parts.push(targetLabel);
        return parts.join(' · ');
    }
}
