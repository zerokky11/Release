// Resources/HubUI/js/views/groupView3.js
import { clear, div, toast } from '../core/dom.js?v=20260731parameterexport1';
import { DEV, onHost, post } from '../core/bridge.js';
import { renderShell3 } from '../core/shell3.js?v=20261012official317';
import { getTopbarState } from '../core/topbar.js?v=20261012official317';
import { getFeatureById3, getFeatureGroup3, getFeaturesForGroup3, searchFeatures3 } from '../core/featureCatalog3.js?v=20260917columnnumber1';
import {
  getPresetInfo3,
  getFeatureOrder3,
  getSelectedFeatureIds3,
  setFeatureOrder3,
  setPresetInfo3,
  setSelectedFeatureIds3,
  toggleSelectedFeature3,
  WORKFLOW3_CHANGE_EVENT
} from '../core/workflowState3.js?v=20260731sharedsettings3';
import {
  getActiveFavoriteSet,
  getFavoriteEntries,
  getFavoriteSetIdsForEntry,
  getFavoriteSets,
  getHubEntry,
  getHubPanelSearch,
  HUB_QUICK_ACCESS_CHANGE_EVENT,
  isHubEntryFavorite,
  openHubEntry,
  renameFavoriteSet,
  replaceHubFavorites,
  setActiveFavoriteSet,
  setHubPanelSearch,
  setHubEntryFavoriteSets
} from '../core/hubFavorites.js?v=20260917columnnumber1';

const FAVORITE_PRESET_KIND = 'kky.hub.favoritesPreset';
const FAVORITE_PRESET_VERSION = 4;
const FAVORITE_PRESET_EXTENSION = '.kkyfav.json';
const MULTI_MODE_KEY = 'kky.hub.multiMode';
const WORKFLOW3_PENDING_SELECTION_KEY = 'kky.hub.workflow3.pendingSelection';
const WORKFLOW3_PENDING_SETTINGS_KEY = 'kky.hub.workflow3.pendingSettings';
const WORKFLOW3_PENDING_ACTIVE_DOCUMENT_KEY = 'kky.hub.workflow3.pendingActiveDocument';
const WORKFLOW3_SETTINGS_NAV_STARTED_KEY = 'kky.hub.workflow3.settingsNavigationStartedAt';

export function renderGroupView3(root, options = {}) {
  const favoriteOnly = options.favoriteOnly === true;
  const requestedMode = String(options.mode || '').trim();
  const mode = favoriteOnly
    ? 'favorites'
    : (['bqc', 'bqc-results', 'utility', 'linktools', 'modeling'].includes(requestedMode) ? requestedMode : 'bqc');
  const directOnly = mode === 'modeling' || mode === 'linktools' || mode === 'bqc-results';
  const group = getFeatureGroup3(mode === 'favorites' ? 'bqc' : mode);
  const panelSearch = favoriteOnly ? { query: '', entryId: '' } : getHubPanelSearch(mode);
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);

  const state = {
    mode,
    favoriteOnly,
    filter: favoriteOnly ? 'favorites' : 'all',
    query: panelSearch.query || '',
    focusEntryId: panelSearch.entryId || '',
    didApplyFocus: false
  };

  const main = div(`group3-main${mode === 'bqc-results' ? ' group3-main--results' : ''}`);
  const controls = div('group3-controls');
  const favoriteSetBar = favoriteOnly ? div('group3-favorite-setbar') : null;
  const toolbar = buildToolbar(state);
  const list = div('group3-feature-list');
  if (favoriteSetBar) controls.append(favoriteSetBar);
  controls.append(toolbar);
  main.append(controls, list);

  const aside = div(`group3-aside${mode === 'bqc-results' ? ' group3-aside--results' : ''}${directOnly ? ' group3-aside--direct' : ''}`);
  const runSet = div('group3-runset');
  const selected = div('shell3-panel group3-selected');
  const note = div('shell3-notice');
  if (directOnly) {
    const directPanel = div('shell3-panel group3-direct-only');
    const directBody = div('shell3-panel-body shell3-context-list');
    const isResults = mode === 'bqc-results';
    directBody.append(buildContextRow('기능 선택', isResults
      ? '왼쪽에서 결과 엑셀 정리 또는 납품용 RVT 정리를 선택합니다.'
      : mode === 'linktools' ? '왼쪽 링크 기능을 눌러 설정과 실행 화면을 엽니다.' : '왼쪽 모델링 기능을 눌러 설정과 실행 화면을 엽니다.'));
    directPanel.append(buildPanelHead(isResults ? 'BQC' : mode === 'linktools' ? 'Links' : 'Modeling', '바로 실행', `${getFeaturesForGroup3(mode).length}개`), directBody);
    note.innerHTML = isResults
      ? '<strong>이전 회신 반영</strong><span>1차 회신에서 인정한 예외를 2차 결과에 반영합니다. 다회차 엑셀 정리는 RVT를 열거나 검토를 다시 실행할 필요가 없습니다.</span>'
      : mode === 'linktools' ? '<strong>링크 도구</strong><span>기존 링크의 경로, 웍셋, 공유좌표를 관리합니다. 새 링크는 Revit 애드인 탭의 Link Manager에서 추가하세요.</span>' : '<strong>Modeling</strong><span>모델링 그룹은 실행 세트 선택 없이 각 기능의 전용 화면에서 직접 실행합니다.</span>';
    aside.append(directPanel, note);
  } else if (!directOnly) {
    note.innerHTML = '<strong>Group 방향</strong><span>BQC와 일반 도구 선택은 서로 분리됩니다. 두 그룹을 함께 실행하려면 즐겨찾기에서 실행 세트를 만듭니다.</span>';
    aside.append(runSet, selected, note);
  }

  const shell = renderShell3(target, {
    active: favoriteOnly ? 'favorites' : mode,
    layout: 'group',
    title: favoriteOnly ? '즐겨찾기' : group.label,
    subtitle: favoriteOnly ? '즐겨찾기한 기능을 모아 실행 세트를 구성합니다.' : group.subtitle,
    main,
    aside
  });
  if (mode === 'linktools') {
    shell.shell.classList.add('shell3--linktools');
  }

  const render = (options = {}) => {
    const shouldPreserveScroll = options.preserveScroll === true;
    const previousScrollTop = shouldPreserveScroll ? list.scrollTop : 0;
    if (favoriteSetBar) renderFavoriteSetBar(favoriteSetBar, state, list);
    renderFeatureList(list, state);
    applyPendingFeatureFocus(list, state);
    if (shouldPreserveScroll) restoreFeatureListScroll(list, previousScrollTop);
    if (!directOnly) {
      renderRunSet(runsetHost(runSet), state);
      renderSelectedPanel(selected, state);
    }
  };

  if (!directOnly) registerPresetHostEvents(state, render);

  const onChange = (event) => {
    if (!main.isConnected) {
      window.removeEventListener(WORKFLOW3_CHANGE_EVENT, onChange);
      window.removeEventListener(HUB_QUICK_ACCESS_CHANGE_EVENT, onChange);
      return;
    }
    const detail = event?.detail || {};
    const shouldPreserveScroll = event?.type === HUB_QUICK_ACCESS_CHANGE_EVENT
      || (detail.kind === 'feature-order' && normalizePresetMode(detail.mode) === state.mode)
      || (detail.kind === 'selection' && normalizePresetMode(detail.mode) === state.mode);
    render({ preserveScroll: shouldPreserveScroll });
  };

  window.addEventListener(WORKFLOW3_CHANGE_EVENT, onChange);
  window.addEventListener(HUB_QUICK_ACCESS_CHANGE_EVENT, onChange);
  render();
}

function renderFavoriteSetBar(host, state, list) {
  clear(host);
  const sets = getFavoriteSets();
  const active = getActiveFavoriteSet();

  const copy = div('group3-favorite-setbar__copy');
  copy.innerHTML = `
    <span class="shell3-kicker">Favorite Set</span>
    <strong>${escapeHtml(active.name)}</strong>
    <small>이 세트의 기능을 표시하고 실행 세트로 사용합니다.</small>`;

  const controls = div('group3-favorite-setbar__controls');
  const select = document.createElement('select');
  select.className = 'group3-favorite-set-select';
  select.setAttribute('aria-label', '즐겨찾기 세트 선택');
  sets.forEach((item, index) => {
    const option = document.createElement('option');
    option.value = item.id;
    option.textContent = `${index + 1}. ${item.name} · ${item.count}개`;
    option.selected = item.id === active.id;
    select.append(option);
  });
  select.addEventListener('change', () => {
    const next = setActiveFavoriteSet(select.value, { toast: false });
    const selectableIds = getFavoriteFeatureEntries('')
      .filter((entry) => entry.selectable)
      .map((entry) => entry.id);
    setSelectedFeatureIds3('favorites', selectableIds);
    list.scrollTop = 0;
    toast(`'${next.name}' 기능 ${next.count}개를 불러왔습니다.`, 'ok');
  });

  const rename = document.createElement('button');
  rename.type = 'button';
  rename.className = 'shell3-btn shell3-btn--ghost group3-favorite-set-action group3-favorite-set-rename';
  rename.textContent = '이름 변경';
  rename.addEventListener('click', () => openFavoriteSetRenameDialog(active));

  const saveFile = document.createElement('button');
  saveFile.type = 'button';
  saveFile.className = 'shell3-btn shell3-btn--ghost group3-favorite-set-action';
  saveFile.textContent = '파일 저장';
  saveFile.title = '현재 즐겨찾기 세트를 KKY 프리셋 파일로 저장합니다.';
  saveFile.disabled = active.count === 0;
  saveFile.addEventListener('click', () => {
    requestPresetSave('favorites', {
      ids: active.entryIds,
      sourceLabel: active.name
    });
  });

  const loadFile = document.createElement('button');
  loadFile.type = 'button';
  loadFile.className = 'shell3-btn shell3-btn--ghost group3-favorite-set-action';
  loadFile.textContent = '파일 불러오기';
  loadFile.title = 'KKY 프리셋 파일의 기능을 현재 즐겨찾기 세트로 불러옵니다.';
  loadFile.addEventListener('click', () => requestPresetLoad('favorites'));

  const count = document.createElement('span');
  count.className = 'shell3-tag';
  count.textContent = `${active.count}개`;

  controls.append(select, rename, saveFile, loadFile, count);
  host.append(copy, controls);
}

function restoreFeatureListScroll(list, scrollTop) {
  const nextTop = Math.max(0, Number(scrollTop) || 0);
  list.scrollTop = nextTop;
  window.requestAnimationFrame?.(() => {
    if (list.isConnected) list.scrollTop = nextTop;
  });
}

function buildToolbar(state) {
  const toolbar = div('group3-toolbar');
  const placeholder = getToolbarPlaceholder(state);
  toolbar.innerHTML = `
    <input class="group3-search" type="search" autocomplete="off" spellcheck="false" placeholder="${escapeHtml(placeholder)}">
    <div class="group3-segments" role="tablist" aria-label="Feature filters">
      <button class="is-active" type="button" data-filter="all">전체</button>
      <button type="button" data-filter="favorites">즐겨찾기</button>
      <button type="button" data-filter="selectable">선택형</button>
      <button type="button" data-filter="direct">별도 화면</button>
    </div>`;

  toolbar.querySelectorAll('[data-filter]').forEach((button) => {
    button.classList.toggle('is-active', (button.dataset.filter || 'all') === state.filter);
    if ((state.mode === 'bqc-results' || state.mode === 'modeling' || state.mode === 'linktools') && ['selectable', 'direct'].includes(button.dataset.filter)) button.hidden = true;
  });

  const input = toolbar.querySelector('.group3-search');
  input.value = state.query;
  input.addEventListener('input', () => {
    state.query = input.value || '';
    state.focusEntryId = '';
    if (!state.favoriteOnly) setHubPanelSearch(state.mode, { query: state.query, entryId: '' });
    window.dispatchEvent(new CustomEvent(WORKFLOW3_CHANGE_EVENT, { detail: { kind: 'filter', mode: state.mode } }));
  });

  toolbar.querySelectorAll('[data-filter]').forEach((button) => {
    button.addEventListener('click', () => {
      state.filter = button.dataset.filter || 'all';
      toolbar.querySelectorAll('[data-filter]').forEach((node) => node.classList.toggle('is-active', node === button));
      window.dispatchEvent(new CustomEvent(WORKFLOW3_CHANGE_EVENT, { detail: { kind: 'filter', mode: state.mode } }));
    });
  });

  return toolbar;
}

function getToolbarPlaceholder(state) {
  if (state?.favoriteOnly || state?.mode === 'favorites') return '즐겨찾기 기능 검색';
  if (state?.mode === 'modeling') return 'CAD, 패밀리, 자동 배치';
  if (state?.mode === 'bqc-results') return '엑셀, 회신, RVT 정리';
  if (state?.mode === 'linktools') return '웍셋, 경로, 공유좌표';
  if (state?.mode === 'utility') return 'GUID, 링크, 파라미터, PMS';
  return '미연결, 파라미터, 레벨';
}

function replaceHubLocationWithoutReload(url) {
  try {
    window.history.replaceState(null, '', url.toString());
    window.setTimeout(() => window.dispatchEvent(new Event('hashchange')), 0);
  } catch {
    location.replace(url.toString());
  }
}

function navigateToWorkflow3Settings(mode, selectedIds) {
  const url = new URL(location.href);
  url.hash = 'settings';
  url.searchParams.set('workflow3', String(Date.now()));
  url.searchParams.set('workflow3Settings', '1');
  url.searchParams.set('workflow3Mode', normalizePresetMode(mode));
  url.searchParams.set('workflow3Selection', normalizeIds(selectedIds).join(','));
  url.searchParams.delete('workflow3Dialog');
  try {
    sessionStorage.setItem(WORKFLOW3_SETTINGS_NAV_STARTED_KEY, String(Date.now()));
  } catch {
  }
  replaceHubLocationWithoutReload(url);
}

function renderFeatureList(host, state) {
  clear(host);
  const selected = state.mode === 'modeling' || state.mode === 'linktools' || state.mode === 'bqc-results'
    ? new Set()
    : new Set(getSelectedFeatureIds3(state.mode));
  const features = getFeaturesForView(state)
    .map((entry) => state.mode === 'linktools' ? { ...entry, selectable: false, statusLabel: '열기', statusTone: 'blue' } : entry)
    .filter((entry) => {
      if (state.filter === 'favorites') return isHubEntryFavorite(entry.id);
      if (state.filter === 'selectable') return entry.selectable;
      if (state.filter === 'direct') return !entry.selectable;
      return true;
    });

  if (!features.length) {
    const empty = div('shell3-empty');
    empty.textContent = '표시할 기능이 없습니다.';
    host.append(empty);
    return;
  }

  if (state.mode === 'linktools') {
    const order = ['linkworkset', 'linkpath', 'linksharedcoord'];
    const entries = features.sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id))
      .map((entry) => entry.id === 'linksharedcoord' ? { ...entry, label: '링크 파일 공유좌표 검토/설정' } : entry);
    appendFeatureSection(host, '링크 기능', '기존 링크를 점검하고 필요한 관리 기능의 설정 화면을 엽니다.', entries, state.mode, selected);
    return;
  }

  const batch = features.filter((entry) => entry.selectable);
  const standalone = features.filter((entry) => !entry.selectable);

  appendFeatureSection(host, '선택 실행 기능', '여러 기능을 선택해 같은 설정 흐름에서 검토합니다.', batch, state.mode, selected);
  appendFeatureSection(host,
    state.mode === 'bqc-results' ? '결과 정리 기능' : '별도 화면 기능',
    state.mode === 'bqc-results' ? '정리할 파일에 맞는 기능을 엽니다.' : '전용 화면을 열어 별도 워크플로우로 실행합니다.',
    standalone, state.mode, selected);
}

function appendFeatureSection(host, title, desc, entries, mode, selected) {
  if (!entries.length) return;

  const section = div('group3-feature-section');
  const head = div('group3-section-head');
  head.innerHTML = `
    <div><strong>${escapeHtml(title)}</strong><span>${escapeHtml(desc)}</span></div>
    <div class="group3-section-actions">
      <em>${entries.length}개</em>
    </div>`;

  if (title === '선택 실행 기능') {
    const actions = head.querySelector('.group3-section-actions');
    const selectedCount = selected?.size || 0;
    const selectableIds = Array.from(getSelectableEntryIdSet(mode));
    const allSelected = selectableIds.length > 0 && selectableIds.every((id) => selected?.has(id));
    const selectAllButton = document.createElement('button');
    selectAllButton.className = 'shell3-btn shell3-btn--ghost group3-section-action';
    selectAllButton.type = 'button';
    selectAllButton.textContent = '전체 선택';
    selectAllButton.disabled = selectableIds.length === 0 || allSelected;
    selectAllButton.addEventListener('click', () => {
      setSelectedFeatureIds3(mode, selectableIds);
      toast(`선택 실행 기능 ${selectableIds.length}개를 모두 선택했습니다.`, 'ok');
    });

    const clearButton = document.createElement('button');
    clearButton.className = 'shell3-btn shell3-btn--ghost group3-section-action';
    clearButton.type = 'button';
    clearButton.textContent = '전체 선택 해제';
    clearButton.disabled = selectedCount === 0;
    clearButton.addEventListener('click', () => {
      if (!getSelectedFeatureIds3(mode).length) return;
      setSelectedFeatureIds3(mode, []);
      toast('선택한 실행 기능을 모두 해제했습니다.', 'info');
    });

    const loadButton = document.createElement('button');
    loadButton.className = 'shell3-btn shell3-btn--ghost group3-section-action group3-section-action--preset group3-help-tooltip';
    loadButton.type = 'button';
    loadButton.textContent = '프리셋 불러오기';
    loadButton.dataset.tooltip = '이전에 저장해두었던 선택 기능을 설정과 함께 바로 불러올 수 있습니다. 프리셋 저장은 기능 선택 후 기능 설정창에서 설정이 끝난 후 저장할 수 있습니다.';
    loadButton.setAttribute('aria-label', loadButton.dataset.tooltip);
    attachFloatingTooltip(loadButton);
    loadButton.addEventListener('click', () => requestPresetLoad(mode));

    actions?.append(selectAllButton, clearButton, loadButton);
  }

  section.append(head);

  const list = div('group3-section-list');
  entries.forEach((entry) => {
    list.append(buildFeatureRow(entry, mode, selected.has(entry.id)));
  });
  if (mode !== 'bqc-results' && mode !== 'linktools') enableFeatureCardSorting(list, mode);
  section.append(list);
  host.append(section);
}

let group3FloatingTooltip = null;

function attachFloatingTooltip(button) {
  if (!button) return;
  const show = () => showFloatingTooltip(button);
  const hide = () => hideFloatingTooltip();

  button.addEventListener('mouseenter', show);
  button.addEventListener('focus', show);
  button.addEventListener('mouseleave', hide);
  button.addEventListener('blur', hide);
  button.addEventListener('click', hide);
}

function showFloatingTooltip(source) {
  const text = String(source?.dataset?.tooltip || '').trim();
  if (!text) return;

  if (!group3FloatingTooltip) {
    group3FloatingTooltip = document.createElement('div');
    group3FloatingTooltip.className = 'group3-floating-tooltip';
    group3FloatingTooltip.setAttribute('role', 'tooltip');
    document.body.append(group3FloatingTooltip);
  }

  group3FloatingTooltip.textContent = text;
  group3FloatingTooltip.hidden = false;
  group3FloatingTooltip.style.left = '0px';
  group3FloatingTooltip.style.top = '0px';

  const margin = 12;
  const rect = source.getBoundingClientRect();
  const tipRect = group3FloatingTooltip.getBoundingClientRect();
  const width = Math.min(Math.max(tipRect.width, 320), Math.max(320, window.innerWidth - margin * 2));
  group3FloatingTooltip.style.width = `${width}px`;

  const measured = group3FloatingTooltip.getBoundingClientRect();
  let left = rect.right - measured.width;
  left = Math.max(margin, Math.min(left, window.innerWidth - measured.width - margin));

  let top = rect.top - measured.height - 10;
  if (top < margin) top = rect.bottom + 10;
  top = Math.max(margin, Math.min(top, window.innerHeight - measured.height - margin));

  group3FloatingTooltip.style.left = `${Math.round(left)}px`;
  group3FloatingTooltip.style.top = `${Math.round(top)}px`;
  group3FloatingTooltip.classList.add('is-visible');

  window.addEventListener('scroll', hideFloatingTooltip, { once: true, capture: true });
  window.addEventListener('resize', hideFloatingTooltip, { once: true });
}

function hideFloatingTooltip() {
  if (!group3FloatingTooltip) return;
  group3FloatingTooltip.classList.remove('is-visible');
  group3FloatingTooltip.hidden = true;
}

function buildFeatureRow(entry, mode, selected) {
  const row = document.createElement('article');
  row.className = 'group3-feature-row';
  row.dataset.entryId = entry.id;
  row.dataset.selected = selected ? 'true' : 'false';
  row.tabIndex = 0;

  const check = document.createElement('button');
  check.type = 'button';
  check.className = 'group3-check';
  check.textContent = selected ? '✓' : '';
  check.setAttribute('aria-label', `${entry.label} 선택`);
  check.disabled = !entry.selectable;
  if (!entry.selectable) {
    check.textContent = '↗';
    check.classList.add('is-direct');
    check.setAttribute('aria-hidden', 'true');
  }
  check.addEventListener('click', (ev) => {
    ev.stopPropagation();
    if (!entry.selectable) return;
    toggleSelectedFeature3(mode, entry.id);
  });

  const copy = div('group3-feature-copy');
  copy.innerHTML = `<strong>${escapeHtml(entry.label)}</strong><span>${escapeHtml(entry.desc || '')}</span>`;

  const status = document.createElement('span');
  status.className = `shell3-tag ${entry.statusTone ? `shell3-tag--${entry.statusTone}` : ''}`.trim();
  status.textContent = entry.statusLabel || (entry.selectable ? '선택 가능' : '열기');

  const actions = div('group3-row-actions');
  const assignedSetIds = getFavoriteSetIdsForEntry(entry.id);
  const assignedSetCount = assignedSetIds.length;
  const favorite = document.createElement('button');
  favorite.type = 'button';
  favorite.className = `shell3-btn shell3-btn--ghost group3-icon-action${assignedSetCount ? ' is-active' : ''}`;
  favorite.innerHTML = `<span>${assignedSetCount ? '★' : '☆'}</span>${assignedSetCount > 1 ? `<em>${assignedSetCount}</em>` : ''}`;
  favorite.title = assignedSetCount
    ? `즐겨찾기 세트 ${assignedSetCount}곳에 저장됨. 배정 변경`
    : '즐겨찾기 세트에 추가';
  favorite.setAttribute('aria-label', `${entry.label} ${favorite.title}`);
  favorite.addEventListener('click', (ev) => {
    ev.stopPropagation();
    openFavoriteAssignmentDialog(entry, mode);
  });

  actions.append(favorite);
  row.append(check, copy, status, actions);

  row.addEventListener('click', () => {
    if (row.dataset.dragSuppress === 'true') {
      row.dataset.dragSuppress = '';
      return;
    }
    if (entry.selectable) {
      toggleSelectedFeature3(mode, entry.id);
    } else {
      openHubEntry(entry.id);
    }
  });
  row.addEventListener('keydown', (ev) => {
    if (ev.target !== row) return;
    if (ev.key !== 'Enter' && ev.key !== ' ') return;
    ev.preventDefault();
    if (entry.selectable) {
      toggleSelectedFeature3(mode, entry.id);
    } else {
      openHubEntry(entry.id);
    }
  });

  return row;
}

function openFavoriteAssignmentDialog(entry, mode) {
  const sets = getFavoriteSets();
  const assignedIds = new Set(getFavoriteSetIdsForEntry(entry.id));
  const overlay = document.createElement('div');
  overlay.className = 'group3-modal-overlay group3-favorite-overlay';
  overlay.innerHTML = `
    <section class="group3-modal-window group3-favorite-window" role="dialog" aria-modal="true" aria-labelledby="group3-favorite-title">
      <header class="group3-modal-titlebar">
        <div>
          <strong id="group3-favorite-title">즐겨찾기 세트 지정</strong>
          <span>${escapeHtml(entry.label)}</span>
        </div>
        <button class="shell3-btn shell3-btn--ghost" type="button" data-close aria-label="닫기">×</button>
      </header>
      <div class="group3-favorite-body">
        <p>기능을 저장할 세트를 모두 선택합니다. 여러 세트에 동시에 둘 수 있습니다.</p>
        <div class="group3-favorite-assignment-list"></div>
      </div>
      <footer class="group3-favorite-footer">
        <span data-summary>${assignedIds.size ? `${assignedIds.size}개 세트 선택` : '선택 없음'}</span>
        <div>
          <button class="shell3-btn shell3-btn--ghost" type="button" data-cancel>취소</button>
          <button class="shell3-btn shell3-btn--primary" type="button" data-apply>적용</button>
        </div>
      </footer>
    </section>`;

  const list = overlay.querySelector('.group3-favorite-assignment-list');
  sets.forEach((item, index) => {
    const label = document.createElement('label');
    label.className = `group3-favorite-assignment-row${item.isActive ? ' is-current' : ''}`;
    label.innerHTML = `
      <input type="checkbox" value="${escapeHtml(item.id)}" ${assignedIds.has(item.id) ? 'checked' : ''}>
      <span><strong>${index + 1}. ${escapeHtml(item.name)}</strong><small>${item.isActive ? '현재 세트' : `${item.count}개 기능`}</small></span>
      ${item.isActive ? '<em>사용 중</em>' : ''}`;
    list.append(label);
  });

  const updateSummary = () => {
    const count = overlay.querySelectorAll('.group3-favorite-assignment-list input:checked').length;
    overlay.querySelector('[data-summary]').textContent = count ? `${count}개 세트 선택` : '선택 없음';
  };
  list.addEventListener('change', updateSummary);

  const close = () => {
    document.removeEventListener('keydown', onKeyDown, true);
    overlay.remove();
  };
  const apply = () => {
    const ids = Array.from(overlay.querySelectorAll('.group3-favorite-assignment-list input:checked'))
      .map((input) => input.value);
    close();
    setHubEntryFavoriteSets(entry.id, ids);
    if (normalizePresetMode(mode) === 'favorites') {
      const selectableIds = getFavoriteFeatureEntries('')
        .filter((item) => item.selectable)
        .map((item) => item.id);
      setSelectedFeatureIds3('favorites', selectableIds);
    }
  };
  const onKeyDown = (event) => {
    if (event.key === 'Escape') close();
    if (event.key === 'Enter' && event.ctrlKey) apply();
  };

  overlay.querySelector('[data-close]').addEventListener('click', close);
  overlay.querySelector('[data-cancel]').addEventListener('click', close);
  overlay.querySelector('[data-apply]').addEventListener('click', apply);
  overlay.addEventListener('mousedown', (event) => {
    if (event.target === overlay) close();
  });
  document.addEventListener('keydown', onKeyDown, true);
  document.body.append(overlay);
  overlay.querySelector('input')?.focus();
}

function openFavoriteSetRenameDialog(favoriteSet) {
  const overlay = document.createElement('div');
  overlay.className = 'group3-modal-overlay group3-favorite-overlay';
  overlay.innerHTML = `
    <section class="group3-modal-window group3-favorite-window group3-favorite-window--rename" role="dialog" aria-modal="true" aria-labelledby="group3-favorite-rename-title">
      <header class="group3-modal-titlebar">
        <div>
          <strong id="group3-favorite-rename-title">즐겨찾기 세트 이름 변경</strong>
          <span>세트 번호는 유지되고 표시 이름만 바뀝니다.</span>
        </div>
        <button class="shell3-btn shell3-btn--ghost" type="button" data-close aria-label="닫기">×</button>
      </header>
      <div class="group3-favorite-rename-body">
        <label for="group3-favorite-name">세트 이름</label>
        <input id="group3-favorite-name" maxlength="30" value="${escapeHtml(favoriteSet.name)}">
      </div>
      <footer class="group3-favorite-footer">
        <span>최대 30자</span>
        <div>
          <button class="shell3-btn shell3-btn--ghost" type="button" data-cancel>취소</button>
          <button class="shell3-btn shell3-btn--primary" type="button" data-apply>저장</button>
        </div>
      </footer>
    </section>`;

  const input = overlay.querySelector('input');
  const close = () => {
    document.removeEventListener('keydown', onKeyDown, true);
    overlay.remove();
  };
  const apply = () => {
    const name = String(input.value || '').replace(/\s+/g, ' ').trim();
    if (!name) {
      input.focus();
      toast('세트 이름을 입력해 주세요.', 'warn');
      return;
    }
    close();
    renameFavoriteSet(favoriteSet.id, name);
  };
  const onKeyDown = (event) => {
    if (event.key === 'Escape') close();
    if (event.key === 'Enter') apply();
  };

  overlay.querySelector('[data-close]').addEventListener('click', close);
  overlay.querySelector('[data-cancel]').addEventListener('click', close);
  overlay.querySelector('[data-apply]').addEventListener('click', apply);
  overlay.addEventListener('mousedown', (event) => {
    if (event.target === overlay) close();
  });
  document.addEventListener('keydown', onKeyDown, true);
  document.body.append(overlay);
  input.focus();
  input.select();
}

function enableFeatureCardSorting(list, mode) {
  const rows = Array.from(list.querySelectorAll('.group3-feature-row'));
  if (rows.length < 2) return;

  rows.forEach((row) => {
    row.draggable = true;
    row.dataset.dragEnabled = 'true';
    row.setAttribute('aria-grabbed', 'false');
    row.title = row.title || '드래그해서 기능 순서 변경';
  });

  list.addEventListener('click', (event) => {
    if (list.dataset.dragSuppress === 'true') {
      event.preventDefault();
      event.stopPropagation();
    }
  }, true);

  list.addEventListener('dragstart', (event) => {
    const row = event.target?.closest?.('.group3-feature-row');
    if (!row || event.target?.closest?.('button')) {
      event.preventDefault();
      return;
    }
    list.dataset.dragEntryId = row.dataset.entryId || '';
    list.dataset.dragSuppress = 'true';
    row.dataset.dragSuppress = 'true';
    row.classList.add('is-dragging');
    row.setAttribute('aria-grabbed', 'true');
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('text/plain', row.dataset.entryId || '');
    }
  });

  list.addEventListener('dragover', (event) => {
    const draggingId = list.dataset.dragEntryId || '';
    if (!draggingId) return;
    const overRow = event.target?.closest?.('.group3-feature-row');
    if (!overRow || overRow.dataset.entryId === draggingId || !list.contains(overRow)) return;
    event.preventDefault();
    const dragging = list.querySelector(`.group3-feature-row[data-entry-id="${escapeCssAttribute(draggingId)}"]`);
    if (!dragging) return;
    const rect = overRow.getBoundingClientRect();
    const after = event.clientY > rect.top + rect.height / 2;
    const target = after ? overRow.nextSibling : overRow;
    if (target === dragging || target === dragging.nextSibling) return;
    animateFeatureCardReorder(list, () => {
      list.insertBefore(dragging, target);
    });
  });

  list.addEventListener('drop', (event) => {
    if (!list.dataset.dragEntryId) return;
    event.preventDefault();
    persistFeatureCardOrder(mode, getEntryIdsFromRows(list));
  });

  list.addEventListener('dragend', () => {
    const draggedId = list.dataset.dragEntryId || '';
    if (draggedId) {
      const row = list.querySelector(`.group3-feature-row[data-entry-id="${escapeCssAttribute(draggedId)}"]`);
      row?.classList.remove('is-dragging');
      row?.setAttribute('aria-grabbed', 'false');
      persistFeatureCardOrder(mode, getEntryIdsFromRows(list));
    }
    delete list.dataset.dragEntryId;
    window.setTimeout(() => {
      delete list.dataset.dragSuppress;
      rows.forEach((row) => { delete row.dataset.dragSuppress; });
    }, 0);
  });
}

function animateFeatureCardReorder(list, mutate) {
  const prefersReducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
  if (prefersReducedMotion) {
    mutate();
    return;
  }

  const firstRects = new Map(
    Array.from(list.querySelectorAll('.group3-feature-row'))
      .map((row) => [row, row.getBoundingClientRect()])
  );

  mutate();

  Array.from(list.querySelectorAll('.group3-feature-row')).forEach((row) => {
    if (row.classList.contains('is-dragging')) return;

    const first = firstRects.get(row);
    if (!first) return;

    const last = row.getBoundingClientRect();
    const dx = first.left - last.left;
    const dy = first.top - last.top;
    if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5) return;

    row.classList.add('is-reordering');
    row.style.transition = 'none';
    row.style.transform = `translate(${dx}px, ${dy}px)`;
    row.getBoundingClientRect();

    const cleanup = () => {
      row.classList.remove('is-reordering');
      row.style.transition = '';
      row.style.transform = '';
      row.removeEventListener('transitionend', onTransitionEnd);
      window.clearTimeout(timer);
    };
    const onTransitionEnd = (event) => {
      if (event.propertyName === 'transform') cleanup();
    };
    const timer = window.setTimeout(cleanup, 260);

    row.addEventListener('transitionend', onTransitionEnd);
    window.requestAnimationFrame(() => {
      row.style.transition = '';
      row.style.transform = '';
    });
  });
}

function getEntryIdsFromRows(list) {
  return Array.from(list.querySelectorAll('.group3-feature-row'))
    .map((row) => String(row.dataset.entryId || '').trim())
    .filter(Boolean);
}

function persistFeatureCardOrder(mode, visibleOrderedIds) {
  const ids = normalizeIds(visibleOrderedIds);
  if (ids.length < 2) return;
  const current = getAllFeatureEntriesForMode(mode).map((entry) => entry.id);
  if (!current.length) return;
  const currentSet = new Set(current);
  const visible = ids.filter((id) => currentSet.has(id));
  if (visible.length < 2) return;
  const visibleSet = new Set(visible);
  const base = current.filter((id) => !visibleSet.has(id));
  const firstIndex = current.reduce((found, id, index) => {
    if (found >= 0) return found;
    return visibleSet.has(id) ? index : -1;
  }, -1);
  const insertAt = firstIndex >= 0
    ? base.filter((id) => current.indexOf(id) < firstIndex).length
    : base.length;
  const next = [
    ...base.slice(0, insertAt),
    ...visible,
    ...base.slice(insertAt)
  ];
  setFeatureOrder3(mode, next);
}

function applyPendingFeatureFocus(host, state) {
  if (state.didApplyFocus || !state.focusEntryId || !host) return;
  const entryId = state.focusEntryId;
  state.didApplyFocus = true;
  state.focusEntryId = '';
  if (!state.favoriteOnly) setHubPanelSearch(state.mode, { query: state.query, entryId: '' });

  window.setTimeout(() => {
    const row = host.querySelector(`[data-entry-id="${escapeCssAttribute(entryId)}"]`);
    if (!row) return;
    row.classList.add('group3-feature-row--spotlight');
    if (typeof row.scrollIntoView === 'function') {
      row.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    if (typeof row.focus === 'function') {
      try {
        row.focus({ preventScroll: true });
      } catch {
        row.focus();
      }
    }
    window.setTimeout(() => {
      row.classList.remove('group3-feature-row--spotlight');
    }, 1800);
  }, 90);
}

function runsetHost(host) {
  clear(host);
  const panel = div('group3-run-summary');
  host.append(panel);
  return panel;
}

function renderRunSet(host, state) {
  clear(host);
  const selectedIds = getSelectedFeatureIds3(state.mode);
  const preset = getPresetInfo3(state.mode);
  const modeLabel = getModeLabel(state.mode);
  host.innerHTML = `
    <div class="group3-run-summary__head">
      <span class="shell3-kicker">Selected Run Set</span>
      <span class="shell3-tag ${selectedIds.length ? 'shell3-tag--warn' : ''}">${selectedIds.length ? '설정 확인 필요' : '선택 없음'}</span>
    </div>
    <strong>선택된 ${modeLabel} 기능 ${selectedIds.length}개</strong>
    <button class="shell3-btn shell3-btn--primary group3-settings-cta" type="button" data-settings ${selectedIds.length ? '' : 'disabled'}>선택 기능 설정하기</button>
    <small>${escapeHtml(preset.name ? `${preset.source === 'loaded' ? '불러온 프리셋' : '마지막 저장'}: ${preset.name}` : '프리셋 저장은 설정하기 화면에서 기능 설정과 함께 저장합니다.')}</small>`;

  host.querySelector('[data-settings]')?.addEventListener('click', () => openSettingsForRunSet(state.mode));
}

function renderSelectedPanel(host, state) {
  clear(host);
  const selectedIds = new Set(getSelectedFeatureIds3(state.mode));
  const selected = getFeaturesForView({ ...state, query: '', filter: 'all' })
    .filter((entry) => selectedIds.has(entry.id));
  host.append(buildPanelHead('Selected', '실행 세트', selected.length ? `${selected.length}개` : '없음'));

  const body = div('shell3-panel-body shell3-context-list group3-selected-list');
  if (!selected.length) {
    body.append(buildContextRow('선택된 기능 없음', '왼쪽 리스트에서 실행할 기능을 선택해 주세요.'));
  } else {
    selected.forEach((entry) => {
      body.append(buildContextRow(entry.label, entry.settingHint || entry.statusLabel || '설정 확인'));
    });
  }
  host.append(body);
}

function buildPanelHead(kicker, title, count) {
  const head = div('shell3-panel-head');
  head.innerHTML = `
    <div><span class="shell3-kicker">${escapeHtml(kicker)}</span><h2>${escapeHtml(title)}</h2></div>
    <span class="shell3-tag">${escapeHtml(count)}</span>`;
  return head;
}

function buildContextRow(title, desc) {
  const row = div('shell3-context-row');
  row.innerHTML = `<strong>${escapeHtml(title)}</strong><span>${escapeHtml(desc)}</span>`;
  return row;
}

function requestPresetSave(mode, options = {}) {
  const ids = Array.isArray(options.ids) && options.ids.length
    ? options.ids
    : getSelectedFeatureIds3(mode);
  const favoriteIds = getFavoriteEntries().map((entry) => entry.id);
  const entryIds = normalizeIds([...ids, ...favoriteIds]);
  if (!entryIds.length) {
    toast('저장할 선택 기능이나 즐겨찾기가 없습니다.', 'warn');
    return;
  }
  const snapshot = buildPresetSnapshot(mode, entryIds, ids);
  const defaultName = buildPresetDefaultName(snapshot, options.sourceLabel);
  const json = JSON.stringify(snapshot, null, 2);
  if (DEV) {
    downloadPresetInBrowser(json, defaultName);
    handlePresetSaved(mode, { fileName: defaultName, path: defaultName });
    return;
  }
  post('favorites:preset-save', { json, defaultName });
}

function requestPresetLoad(mode) {
  if (DEV) {
    openPresetFileInBrowser(mode);
    return;
  }
  post('favorites:preset-load', {});
}

function buildPresetSnapshot(mode, favoriteEntryIds, selectedEntryIds) {
  const features = {};
  const favoriteSet = getActiveFavoriteSet();
  normalizeIds(selectedEntryIds).forEach((id) => {
    features[id] = {
      enabled: true,
      config: {}
    };
  });
  return {
    kind: FAVORITE_PRESET_KIND,
    version: FAVORITE_PRESET_VERSION,
    mode,
    createdAt: new Date().toISOString(),
    favoriteSet: {
      id: favoriteSet.id,
      name: favoriteSet.name
    },
    favoriteEntryIds: normalizeIds(favoriteEntryIds),
    selectedEntryIds: normalizeIds(selectedEntryIds),
    favoriteKeys: normalizeIds(favoriteEntryIds),
    features
  };
}

function buildPresetDefaultName(snapshot, label = '') {
  const dateToken = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const ids = Array.isArray(snapshot.selectedEntryIds) && snapshot.selectedEntryIds.length
    ? snapshot.selectedEntryIds
    : snapshot.favoriteEntryIds;
  const base = label || (ids.length === 1 ? ids[0] : `${getModeLabel(snapshot.mode)} ${ids.length}개 기능`);
  return `${dateToken}_${sanitizeFileLabel(base)}${FAVORITE_PRESET_EXTENSION}`;
}

function parsePresetSnapshot(json) {
  const snapshot = JSON.parse(String(json || '').replace(/^\uFEFF/, '').trim());
  if (!snapshot || typeof snapshot !== 'object' || Array.isArray(snapshot)) {
    throw new Error('프리셋 형식이 올바르지 않습니다.');
  }
  const kind = String(snapshot.kind || '').trim();
  if (kind && kind !== FAVORITE_PRESET_KIND) {
    throw new Error('KKY 즐겨찾기 프리셋 파일이 아닙니다.');
  }
  return snapshot;
}

function applyPresetSnapshot(mode, snapshot, meta = {}) {
  const targetMode = normalizePresetMode(snapshot.mode || mode);
  const favoriteEntryIds = normalizeIds(snapshot.favoriteEntryIds || snapshot.favoriteKeys || []);
  const featureMap = snapshot.features && typeof snapshot.features === 'object' ? snapshot.features : {};
  const selectedEntryIds = normalizeIds(
    snapshot.selectedEntryIds || Object.keys(featureMap).filter((key) => featureMap[key]?.enabled)
  );
  if (favoriteEntryIds.length || targetMode === 'favorites') {
    replaceHubFavorites(favoriteEntryIds, { toast: false });
  }
  const selectableIds = getSelectableEntryIdSet(targetMode);
  const idsToSelect = (selectedEntryIds.length ? selectedEntryIds : favoriteEntryIds)
    .filter((id) => selectableIds.has(id));

  setSelectedFeatureIds3(targetMode, idsToSelect);
  persistPresetSettingsForWorkflow3(targetMode, snapshot, idsToSelect);
  setPresetInfo3(targetMode, {
    name: String(meta.fileName || '').trim() || getPathLeafLabel(meta.path, '프리셋'),
    path: String(meta.path || '').trim(),
    source: 'loaded'
  });
  if (targetMode !== normalizePresetMode(mode)) {
    try {
      localStorage.setItem('kky.hub.multiMode', targetMode);
      setHubPanelSearch(targetMode, { query: '', entryId: idsToSelect[0] || favoriteEntryIds[0] || '' });
    } catch {
    }
    window.setTimeout(() => {
      location.hash = targetMode === 'favorites'
        ? '#favorites'
        : (targetMode === 'utility' ? '#utility' : (targetMode === 'modeling' ? '#modeling' : '#bqc'));
    }, 0);
  }
  toast(`프리셋을 불러왔습니다. ${getModeLabel(targetMode)} 선택 기능 ${idsToSelect.length}개`, 'ok');
}

function persistPresetSettingsForWorkflow3(mode, snapshot, selectedEntryIds) {
  const featureMap = snapshot?.features && typeof snapshot.features === 'object' && !Array.isArray(snapshot.features)
    ? snapshot.features
    : {};
  const selectedKeys = normalizeIds(selectedEntryIds)
    .map((id) => resolveFeatureKeyFromEntry(id))
    .filter(Boolean);
  const selectedKeySet = new Set(selectedKeys);
  const features = {};

  Object.keys(featureMap).forEach((rawKey) => {
    const key = resolveFeatureKeyFromEntry(rawKey);
    if (!key || (selectedKeySet.size && !selectedKeySet.has(key))) return;
    const source = featureMap[rawKey];
    const item = source && typeof source === 'object' && !Array.isArray(source) ? source : {};
    if (!hasPresetFeatureConfig(item)) return;
    const committed = getPresetFeatureConfig(item);
    features[key] = {
      enabled: item.enabled !== false,
      applied: item.applied !== false,
      dirty: !!item.dirty,
      configCommitted: committed,
      configDraft: getPresetFeatureDraft(item, committed)
    };
  });

  const common = getPresetCommonOptions(snapshot);
  if (!common && !Object.keys(features).length) return;

  try {
    localStorage.setItem(WORKFLOW3_PENDING_SETTINGS_KEY, JSON.stringify({
      common: common || {},
      features,
      selectedKeys,
      source: 'preset-load',
      createdAt: Date.now()
    }));
    localStorage.setItem(MULTI_MODE_KEY, normalizePresetMode(mode));
    localStorage.setItem(WORKFLOW3_PENDING_SELECTION_KEY, JSON.stringify({
      mode: normalizePresetMode(mode),
      selected: normalizeIds(selectedEntryIds),
      createdAt: Date.now()
    }));
  } catch {
  }
}

function resolveFeatureKeyFromEntry(entryId) {
  const id = String(entryId || '').trim();
  if (!id) return '';
  const entry = getHubEntry(id);
  return String(entry?.featureKey || entry?.id || id).trim();
}

function getPresetCommonOptions(snapshot) {
  const common = snapshot?.commonOptions || snapshot?.common;
  return common && typeof common === 'object' && !Array.isArray(common) ? common : null;
}

function hasPresetFeatureConfig(item) {
  if (!item || typeof item !== 'object' || Array.isArray(item)) return false;
  if (Object.prototype.hasOwnProperty.call(item, 'configCommitted')) return true;
  if (Object.prototype.hasOwnProperty.call(item, 'configDraft')) return true;
  const config = item.config;
  return !!(config && typeof config === 'object' && !Array.isArray(config) && Object.keys(config).length);
}

function getPresetFeatureConfig(item) {
  if (item.configCommitted && typeof item.configCommitted === 'object' && !Array.isArray(item.configCommitted)) return item.configCommitted;
  if (item.config && typeof item.config === 'object' && !Array.isArray(item.config)) return item.config;
  return {};
}

function getPresetFeatureDraft(item, committed) {
  if (item.configDraft && typeof item.configDraft === 'object' && !Array.isArray(item.configDraft)) return item.configDraft;
  return committed || {};
}

function registerPresetHostEvents(state, render) {
  onHost('favorites:preset-saved', (payload) => {
    if (!document.querySelector('.shell3')) return;
    handlePresetSaved(state.mode, payload);
    render();
  });
  onHost('favorites:preset-loaded', (payload) => {
    if (!document.querySelector('.shell3')) return;
    handlePresetLoaded(state.mode, payload);
    render();
  });
  onHost('favorites:preset-error', (payload) => {
    if (!document.querySelector('.shell3')) return;
    toast(payload?.message || '프리셋을 처리하지 못했습니다.', 'err');
  });
}

function handlePresetSaved(mode, payload = {}) {
  const path = String(payload.path || '').trim();
  const name = String(payload.fileName || '').trim() || getPathLeafLabel(path, '프리셋');
  setPresetInfo3(mode, { name, path, source: 'saved' });
  toast(`프리셋을 저장했습니다. (${name})`, 'ok');
}

function handlePresetLoaded(mode, payload = {}) {
  try {
    const snapshot = parsePresetSnapshot(payload.json || '');
    applyPresetSnapshot(mode, snapshot, payload);
  } catch (error) {
    toast(error?.message || '프리셋 형식을 읽지 못했습니다.', 'err');
  }
}

function downloadPresetInBrowser(json, fileName) {
  const blob = new Blob([json], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

function openPresetFileInBrowser(mode) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json,.kkyfav.json,application/json';
  input.addEventListener('change', () => {
    const file = input.files && input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      handlePresetLoaded(mode, {
        fileName: file.name,
        path: file.name,
        json: typeof reader.result === 'string' ? reader.result : ''
      });
    };
    reader.onerror = () => toast('프리셋 파일을 읽지 못했습니다.', 'err');
    reader.readAsText(file, 'utf-8');
  }, { once: true });
  input.click();
}

function normalizeIds(ids) {
  const seen = new Set();
  return (Array.isArray(ids) ? ids : [])
    .map((id) => String(id || '').trim())
    .filter(Boolean)
    .filter((id) => {
      if (seen.has(id)) return false;
      seen.add(id);
      return true;
    });
}

function normalizePresetMode(mode) {
  if (mode === 'utility') return 'utility';
  if (mode === 'modeling') return 'modeling';
  if (mode === 'favorites') return 'favorites';
  return 'bqc';
}

function getSelectableEntryIdSet(mode) {
  if (normalizePresetMode(mode) === 'favorites') {
    return new Set(getFavoriteFeatureEntries('')
      .filter((entry) => entry.selectable)
      .map((entry) => entry.id));
  }
  return new Set(
    searchFeatures3(normalizePresetMode(mode), '')
      .filter((entry) => entry.selectable)
      .map((entry) => entry.id)
  );
}

function openSettingsForRunSet(mode) {
  const selected = getSelectedFeatureIds3(mode);
  if (!selected.length) {
    toast('실행할 기능을 먼저 선택해 주세요.', 'warn');
    return;
  }
  try {
    localStorage.setItem(MULTI_MODE_KEY, normalizePresetMode(mode));
    localStorage.setItem(WORKFLOW3_PENDING_SELECTION_KEY, JSON.stringify({ mode: normalizePresetMode(mode), selected, createdAt: Date.now() }));
  } catch {
  }
  closeWorkflow3Dialog();
  navigateToWorkflow3Settings(mode, selected);
}

function openWorkflow3RvtDialog(href) {
  const url = safeUrl(href);
  url.hash = 'rvt';
  url.searchParams.delete('workflow3Dialog');
  url.searchParams.delete('workflow3Settings');
  closeWorkflow3Dialog();
  location.replace(url.toString());
}

function closeWorkflow3Dialog() {
  document.querySelectorAll('[data-workflow-dialog="true"]').forEach((node) => node.remove());
}

function openActiveDocumentTargetDialog(href) {
  const runUrl = safeUrl(href);
  runUrl.searchParams.delete('workflow3Dialog');
  const state = getTopbarState();
  const docs = normalizeTopbarDocuments(state.documents).filter((doc) => !isLinkedDocument(doc));
  const active = normalizeDocumentItem(state.activeDocument || {});
  const activeFallback = !isLinkedDocument(active) ? active : {};
  if (docs.length <= 1) {
    runWorkflow3ActiveDocument(runUrl, docs[0] || activeFallback);
    return;
  }

  closeWorkflow3Dialog();
  const overlay = document.createElement('div');
  overlay.className = 'group3-modal-overlay group3-modal-overlay--docs';
  overlay.dataset.workflowDialog = 'true';
  overlay.innerHTML = `
    <section class="group3-modal-window group3-doc-window" role="dialog" aria-modal="true" aria-label="활성 문서 선택">
      <header class="group3-modal-titlebar">
        <div>
          <strong>활성 문서 검토</strong>
          <span>열려 있는 문서 중 검토할 대상을 선택합니다.</span>
        </div>
        <button class="shell3-btn shell3-btn--ghost" type="button" data-dialog-close>닫기</button>
      </header>
      <div class="group3-doc-list"></div>
    </section>`;
  const list = overlay.querySelector('.group3-doc-list');
  docs.forEach((doc) => {
    const row = document.createElement('button');
    row.type = 'button';
    row.className = `group3-doc-row${isSameDocument(doc, active) ? ' is-active' : ''}`;
    row.innerHTML = `
      <strong>${escapeHtml(doc.name || '문서')}</strong>
      <span>${escapeHtml(doc.path || '저장되지 않은 문서')}</span>`;
    row.addEventListener('click', () => runWorkflow3ActiveDocument(runUrl, doc));
    list.append(row);
  });
  document.body.append(overlay);
  overlay.querySelector('[data-dialog-close]')?.addEventListener('click', closeWorkflow3Dialog);
  overlay.addEventListener('click', (ev) => {
    if (ev.target === overlay) closeWorkflow3Dialog();
  });
}

function runWorkflow3ActiveDocument(runUrl, doc) {
  const target = normalizeDocumentItem(doc || {});
  const active = normalizeDocumentItem(getTopbarState().activeDocument || {});
  runUrl.searchParams.set('workflow3Target', 'active');
  runUrl.searchParams.set('workflow3Rvts', '0');
  const proceed = () => {
    persistWorkflow3ActiveDocument(target.path || target.name ? target : active);
    closeWorkflow3Dialog();
    location.replace(runUrl.toString());
  };
  if (!target.path || isSameDocument(target, active)) {
    proceed();
    return;
  }
  let done = false;
  const unsubscribeOk = onHost('host:doc-activated', () => {
    if (done) return;
    done = true;
    unsubscribeOk();
    unsubscribeErr();
    window.setTimeout(proceed, 120);
  });
  const unsubscribeErr = onHost('host:doc-activate-error', (payload) => {
    if (done) return;
    done = true;
    unsubscribeOk();
    unsubscribeErr();
    toast(payload?.message || '선택한 문서를 활성화하지 못했습니다.', 'err');
  });
  post('hub:activate-document', target);
  window.setTimeout(() => {
    if (done) return;
    done = true;
    unsubscribeOk();
    unsubscribeErr();
    proceed();
  }, 900);
}

function persistWorkflow3ActiveDocument(doc) {
  const target = normalizeDocumentItem(doc || {});
  try {
    if (!target.name && !target.path) {
      localStorage.removeItem(WORKFLOW3_PENDING_ACTIVE_DOCUMENT_KEY);
      return;
    }
    localStorage.setItem(WORKFLOW3_PENDING_ACTIVE_DOCUMENT_KEY, JSON.stringify({
      ...target,
      createdAt: Date.now()
    }));
  } catch {
  }
}

function safeUrl(href) {
  try {
    return new URL(String(href || ''), location.href);
  } catch {
    return new URL(location.href);
  }
}

function normalizeTopbarDocuments(docs) {
  const seen = new Set();
  return (Array.isArray(docs) ? docs : [])
    .map(normalizeDocumentItem)
    .filter((doc) => doc.name || doc.path)
    .filter((doc) => {
      const key = (doc.path || doc.name).toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function normalizeDocumentItem(doc) {
  return {
    name: String(doc?.name || doc?.Name || doc?.title || doc?.Title || '').trim(),
    path: String(doc?.path || doc?.Path || doc?.filePath || doc?.FilePath || '').trim(),
    isLinked: doc?.isLinked === true || doc?.IsLinked === true || doc?.linked === true || doc?.Linked === true || doc?.isLink === true || doc?.IsLink === true
  };
}

function isLinkedDocument(doc) {
  return normalizeDocumentItem(doc).isLinked === true;
}

function isSameDocument(left, right) {
  const a = normalizeDocumentItem(left);
  const b = normalizeDocumentItem(right);
  const ak = (a.path || a.name).toLowerCase();
  const bk = (b.path || b.name).toLowerCase();
  return !!ak && ak === bk;
}

function getFeaturesForView(state) {
  let entries = state.mode === 'favorites'
    ? getFavoriteFeatureEntries(state.query)
    : searchFeatures3(state.mode, state.query);
  if (state.mode === 'linktools' && state.query) {
    const query = String(state.query).toLowerCase().replace(/\s+/g, '');
    if ('링크파일공유좌표검토/설정'.includes(query) && !entries.some((entry) => entry.id === 'linksharedcoord')) {
      entries = [...entries, ...searchFeatures3('linktools', '').filter((entry) => entry.id === 'linksharedcoord')];
    }
  }
  return orderFeatureEntriesForMode(state.mode, entries);
}

function getAllFeatureEntriesForMode(mode) {
  const normalized = normalizePresetMode(mode);
  if (normalized === 'favorites') return orderFeatureEntriesForMode(normalized, getFavoriteFeatureEntries(''));
  return orderFeatureEntriesForMode(normalized, searchFeatures3(normalized, ''));
}

function orderFeatureEntriesForMode(mode, entries) {
  const list = Array.isArray(entries) ? entries.slice() : [];
  const rank = new Map((mode === 'modeling' || mode === 'linktools' || mode === 'bqc-results' ? [] : getFeatureOrder3(mode)).map((id, index) => [id, index]));
  return list
    .map((entry, index) => ({
      entry,
      index,
      rank: rank.has(entry?.id) ? rank.get(entry.id) : Number.MAX_SAFE_INTEGER
    }))
    .sort((left, right) => left.rank - right.rank || left.index - right.index)
    .map((item) => item.entry);
}

function getFavoriteFeatureEntries(query) {
  const favoriteIds = new Set(getFavoriteEntries().map((entry) => entry.id));
  const seen = new Set();
  const text = String(query || '').toLowerCase().trim();
  const compact = text.replace(/\s+/g, '');
  return [...getFeaturesForGroup3('bqc'), ...getFeaturesForGroup3('bqc-results'), ...getFeaturesForGroup3('utility'), ...getFeaturesForGroup3('linktools'), ...getFeaturesForGroup3('modeling')].filter(Boolean)
    .filter((entry) => favoriteIds.has(entry.id))
    .filter((entry) => {
      if (seen.has(entry.id)) return false;
      seen.add(entry.id);
      return true;
    })
    .filter((entry) => {
      if (!text) return true;
      const fields = [entry.label, entry.desc, entry.groupLabel, entry.settingHint]
        .map((value) => String(value || '').toLowerCase().trim());
      return fields.some((value) => value.includes(text) || value.replace(/\s+/g, '').includes(compact));
    });
}

function getModeLabel(mode) {
  if (mode === 'bqc-results') return 'BQC 결과 정리';
  if (mode === 'utility') return '일반 도구';
  if (mode === 'linktools') return '링크 도구';
  if (mode === 'modeling') return '모델링';
  if (mode === 'favorites') return '즐겨찾기';
  return 'BQC';
}

function getPathLeafLabel(path, fallback) {
  const text = String(path || '').trim();
  if (!text) return fallback;
  return text.split(/[\\/]/).filter(Boolean).pop() || fallback;
}

function sanitizeFileLabel(value) {
  return String(value || '프리셋')
    .replace(/[<>:"/\\|?*\u0000-\u001F]/g, '_')
    .replace(/\s+/g, ' ')
    .trim() || '프리셋';
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function escapeCssAttribute(value) {
  if (window.CSS && typeof window.CSS.escape === 'function') {
    return window.CSS.escape(String(value || ''));
  }
  return String(value || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}
