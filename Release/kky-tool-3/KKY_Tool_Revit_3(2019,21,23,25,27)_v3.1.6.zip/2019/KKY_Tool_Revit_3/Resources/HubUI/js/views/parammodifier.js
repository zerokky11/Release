import { createRvtRegistration } from '../core/rvtRegistration.js?v=20261008registration1';
import { clear, div, toast, setBusy, showCompletionSummaryDialog } from '../core/dom.js?v=20260731parameterexport1';
import { ProgressDialog } from '../core/progress.js';
import { chooseExcelMode, getLastExcelExportLocale, showExcelSavedDialog } from '../core/dom.js?v=20260731parameterexport1';
import { refreshUiAfterHostDialog } from '../core/hostDialog.js';
import { attachRvtDropZone } from '../core/rvtDrop.js';
import { post, onHost } from '../core/bridge.js';
import { getTopbarState } from '../core/topbar.js?v=20261012official316';
import { bindActiveDocumentContext, acceptActiveDocumentSnapshot, getActiveDocumentSnapshot, beginActiveDocumentRun, finishActiveDocumentRun } from '../core/activeDocumentContext.js';
import { operationOutcome, resultValue, resultCount } from '../core/operationOutcome.js';
import { createRvtTable, renderRvtRows, getRvtName } from './rvtTable.js?v=20260504a';

const FILTER_OPERATORS = [
  'Equals', 'NotEquals', 'Contains', 'NotContains', 'BeginsWith', 'NotBeginsWith',
  'EndsWith', 'NotEndsWith', 'Greater', 'GreaterOrEqual', 'Less', 'LessOrEqual',
  'HasValue', 'HasNoValue'
];
const PARAMMODIFIER_SETTINGS_KEY = 'kky.settings.parammodifier.v1';
let activeParamModifierPreferenceCleanup = null;

export function renderParamModifier(root) {
  activeParamModifierPreferenceCleanup?.();
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);
  const savedPreferences = loadParamModifierPreferences();

  const state = {
    rvtPaths: [],
    checked: new Set(),
    synchronizeAfterProcessing: !!savedPreferences?.synchronizeAfterProcessing,
    syncComment: String(savedPreferences?.syncComment || ''),
    elementParameterUpdate: normalizeElementUpdate(savedPreferences?.elementParameterUpdate || {}),
    lastResult: null,
    activeDocument: null,
    busy: false,
    acceptProgress: false,
    ui: {},
    hasSavedPreferences: !!savedPreferences
  };

  const page = div('feature-shell deliverycleaner-page parammodifier-page--main');
  state.ui.page = page;
  const preferenceCleanup = attachParamModifierPreferenceSync(page, state);
  const documentCleanup = bindActiveDocumentContext(state, () => {
    if (!page.isConnected) return;
    renderRunSummary(state);
    updateActionState(state);
  });
  activeParamModifierPreferenceCleanup = () => { preferenceCleanup(); documentCleanup(); state.ui.rvtRegistration?.dispose(); };
  page.innerHTML = `
    <div class="feature-header deliverycleaner-header">
      <div class="feature-heading">
        <span class="feature-kicker">일반 도구 · 별도 워크플로</span>
        <h2 class="feature-title">파라미터 수정기</h2>
        <p class="feature-sub">입력 조건을 기준으로 활성 문서 또는 여러 RVT에 파라미터 값을 일괄 적용합니다.</p>
      </div>
    </div>
  `;

  const layout = div('deliverycleaner-top-grid');
  const leftColumn = div('deliverycleaner-field-stack');
  leftColumn.append(buildRunCard(state));
  layout.append(leftColumn, buildSettingsCard(state));
  page.append(layout, buildRvtModal(state));
  target.append(page);

  onHost('parammodifier:init', (payload) => applyHostState(state, payload));
  onHost('parammodifier:rvts-picked', (payload) => {
    const paths = Array.isArray(payload?.paths) ? payload.paths : [];
    if (!paths.length) return;

    const added = appendDroppedRvts(state, paths);
    refreshUiAfterHostDialog(() => {
      renderRvtModal(state);
      renderRunSummary(state);
      updateActionState(state);
      if (added) toast(`${added}개 RVT를 추가했습니다.`, 'ok');
      openRvtModal(state);
    });
  });
  onHost('parammodifier:progress', (payload) => {
    if (!state.acceptProgress || !state.busy) return;
    if (!ProgressDialog.isOwner(state.progressOwner)) return;
    ProgressDialog.update(Number(payload?.percent) || 0, payload?.message || '', payload?.detail || '', state.progressOwner);
  });
  onHost('parammodifier:done', (payload) => {
    const runDocument = state.runDocument;
    state.acceptProgress = false;
    if (state.progressOwner != null) ProgressDialog.hide(state.progressOwner);
    setPageBusy(state, false);
    state.lastResult = {
      ...payload,
      ok: resultValue(payload, 'ok'),
      status: resultValue(payload, 'status'),
      message: resultValue(payload, 'message') || '',
      outputFolder: payload?.outputFolder || '',
      resultWorkbookPath: payload?.resultWorkbookPath || '',
      logTextPath: payload?.logTextPath || '',
      summary: resultValue(payload, 'summary') || null,
      fileCount: resultCount(payload, 'fileCount'),
      runDocument
    };
    if (payload?.activeDocument) acceptActiveDocumentSnapshot(state, payload.activeDocument);
    renderRunSummary(state);
    renderRvtModal(state);
    updateActionState(state);
    requestAnimationFrame(() => {
      if (state.progressOwner != null) ProgressDialog.hide(state.progressOwner);
      openCompletionResultDialog(state, state.lastResult);
    });
    const outcome = getParamModifierOutcome(state.lastResult);
    toast(outcome.message, outcome.tone, 4200);
  });
  onHost('parammodifier:artifacts-exported', (payload) => {
    state.acceptProgress = false;
    if (state.progressOwner != null) ProgressDialog.hide(state.progressOwner);
    setPageBusy(state, false);
    if (!state.lastResult) state.lastResult = {};
    if (payload?.outputFolder) state.lastResult.outputFolder = payload.outputFolder;
    if (payload?.resultWorkbookPath) state.lastResult.resultWorkbookPath = payload.resultWorkbookPath;
    if (Object.prototype.hasOwnProperty.call(payload || {}, 'logTextPath')) state.lastResult.logTextPath = payload.logTextPath || '';
    renderRunSummary(state);
    renderRvtModal(state);
    updateActionState(state);
    const savedPath = payload?.path || payload?.resultWorkbookPath || '';
    if (payload?.ok && savedPath) {
      requestAnimationFrame(() => {
        showExcelSavedDialog(payload?.message || '파라미터 수정기 결과 엑셀을 저장했습니다.', savedPath, (path) => post('excel:open', { path }));
      });
    } else {
      requestAnimationFrame(() => {
        if (state.progressOwner != null) ProgressDialog.hide(state.progressOwner);
        openCompletionResultDialog(state, payload || {});
      });
      toast(
        payload?.message || (payload?.ok === false
          ? '파라미터 수정기 결과 파일 저장에 실패했습니다.'
          : '파라미터 수정기 결과 파일을 저장했습니다.'),
        payload?.ok === false ? 'err' : 'ok',
        3200
      );
    }
  });
  onHost('parammodifier:filter-saved', (payload) => {
    if (payload?.ok === false) toast(payload?.message || '필터 저장에 실패했습니다.', 'err', 3000);
  });
  onHost('parammodifier:filter-loaded', (payload) => {
    if (payload?.ok === false) toast(payload?.message || '필터를 불러오지 못했습니다.', 'err', 3000);
  });
  onHost('parammodifier:filter-doc-list', (payload) => {
    if (payload?.ok === false) toast(payload?.message || '문서 필터 목록을 가져오지 못했습니다.', 'err', 3000);
  });
  onHost('parammodifier:folder-opened', (payload) => {
    if (payload?.ok === false) toast(payload?.message || '결과 폴더를 열지 못했습니다.', 'err', 3000);
  });
  onHost('parammodifier:error', (payload) => {
    state.acceptProgress = false;
    if (state.progressOwner != null) ProgressDialog.hide(state.progressOwner);
    setPageBusy(state, false);
    renderRunSummary(state);
    toast(payload?.message || '파라미터 수정기 작업 중 오류가 발생했습니다. 대상 RVT, 선택 조건, 입력 파라미터 값을 확인한 뒤 다시 실행해 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err', 3600);
  });

  renderElementUpdateRows(state);
  renderRunSummary(state);
  renderRvtModal(state);
  updateActionState(state);
  post('parammodifier:init', { activeDocument: getParamModifierActiveDocumentInfo(state) });
  return () => { preferenceCleanup(); documentCleanup(); state.ui.rvtRegistration?.dispose(); };
}

function openCompletionResultDialog(state, payload) {
  const isRunResult = resultValue(payload, 'summary') != null || resultValue(payload, 'fileCount') != null || resultValue(payload, 'status') != null;
  const result = isRunResult ? payload : (state.lastResult || payload || {});
  const summary = resultValue(result, 'summary') || {};
  const outcome = getParamModifierOutcome(result);
  const workbookPath = payload?.resultWorkbookPath || state.lastResult?.resultWorkbookPath || '';
  const logPath = payload?.logTextPath || state.lastResult?.logTextPath || '';
  const outputFolder = payload?.outputFolder || state.lastResult?.outputFolder || '';

  const successCount = summary?.SuccessCount ?? summary?.successCount ?? 0;
  const failCount = summary?.FailCount ?? summary?.failCount ?? 0;
  const noChangeCount = summary?.NoChangeCount ?? summary?.noChangeCount ?? 0;
  const updatedElementCount = summary?.TotalUpdatedElementCount ?? summary?.totalUpdatedElementCount ?? 0;
  const updatedParameterCount = summary?.TotalUpdatedParameterCount ?? summary?.totalUpdatedParameterCount ?? 0;
  const idCounts = [
    ['ID 변경', summary?.TotalIdChangedCount ?? summary?.totalIdChangedCount],
    ['기존 객체 미확인', summary?.TotalMissingIdentityCount ?? summary?.totalMissingIdentityCount],
    ['새 객체', summary?.TotalAddedIdentityCount ?? summary?.totalAddedIdentityCount],
    ['비교 미완료 파일', summary?.IdentityAuditIncompleteFileCount ?? summary?.identityAuditIncompleteFileCount]
  ];
  const partialCount = resultCount(summary, 'partialCount');
  const rejectedCount = resultCount(summary, 'totalRejectedParameterCount');
  const unchangedCount = resultCount(summary, 'totalUnchangedParameterCount');
  const targetCount = resultCount(result, 'fileCount', successCount + failCount + noChangeCount + partialCount);
  const canExport = resultValue(result, 'canExport') !== false && (targetCount > 0 || (resultValue(result, 'details') || []).length > 0 || (resultValue(result, 'logs') || []).length > 0);

  const notes = [];
  if (result.runDocument) notes.push(`실행 문서: ${result.runDocument.title || result.runDocument.name}`);
  if (!isRunResult && payload?.message) notes.push(payload.message);
  const failureNotes = (resultValue(result, 'files') || []).filter(file => ['fail', 'failed', 'partial'].includes(String(resultValue(file, 'status') || '').toLowerCase()));
  failureNotes.slice(0, 8).forEach(file => notes.push(`${resultValue(file, 'fileName') || resultValue(file, 'filePath') || '대상 파일'}: ${resultValue(file, 'message') || '실패 이유를 결과 엑셀에서 확인하세요.'}`));
  if (failureNotes.length > 8) notes.push(`그 밖의 실패 ${failureNotes.length - 8}개는 결과 엑셀에서 확인하세요.`);
  if (outputFolder) notes.push(`결과 폴더: ${outputFolder}`);
  if (workbookPath) notes.push(`결과 엑셀: ${workbookPath}`);
  if (logPath) notes.push(`로그 파일: ${logPath}`);
  if (!workbookPath && canExport) notes.push('자동 저장은 하지 않습니다. 필요할 때 이 창에서 엑셀을 추출합니다.');
  if (idCounts.some(([, value]) => Number(value) > 0)) {
    notes.push('객체 ID 수량은 적용 전후와 저장·동기화 전후의 비교 건수를 합산합니다. 기존 객체 미확인과 새 객체가 함께 있어도 재생성 여부는 확인이 필요합니다.');
  }

  const actions = [];
  if (workbookPath) {
    actions.push({
      label: '결과 엑셀 열기',
      onClick: () => post('excel:open', { path: workbookPath })
    });
  } else if (canExport) {
      actions.push({
        label: '결과 엑셀 추출',
        variant: 'primary',
        onClick: async () => {
          const excelMode = await chooseExcelMode();
          if (!excelMode) return;
          state.acceptProgress = true;
          setPageBusy(state, true);
          beginParamModifierProgress(state, '파라미터 수정기', '결과 엑셀 생성을 준비하는 중입니다.');
          post('parammodifier:export-results', { excelMode: excelMode || 'fast', locale: getLastExcelExportLocale() });
        }
      });
  }
  if (logPath) {
    actions.push({
      label: '로그 열기',
      onClick: () => post('excel:open', { path: logPath })
    });
  }
  if (outputFolder) {
    actions.push({
      label: '결과 폴더 열기',
      onClick: () => post('parammodifier:open-folder', { path: outputFolder })
    });
  }

  showCompletionSummaryDialog({
    title: `파라미터 수정 ${outcome.label}`,
    message: outcome.message,
    summaryItems: [
      { label: '실행 결과', value: outcome.label },
      { label: '대상 파일', value: `${targetCount}개` },
      { label: '성공', value: `${successCount}개` },
      { label: '실패', value: `${failCount}개` },
      { label: '일부 실패 파일', value: `${partialCount}개` },
      { label: '변경 없는 파일', value: `${noChangeCount}개` },
      { label: '업데이트 요소', value: `${updatedElementCount}개` },
      { label: '업데이트 파라미터', value: `${updatedParameterCount}개` },
      { label: '입력 실패', value: `${rejectedCount}개` },
      { label: '기존 값과 동일', value: `${unchangedCount}개` },
      ...idCounts.filter(([, value]) => value !== undefined && value !== null)
        .map(([label, value]) => ({ label, value: `${Number(value) || 0}개` }))
    ],
    notes,
    actions,
    confirmLabel: '닫기',
    showExport: false
  });
}

function getParamModifierOutcome(result) {
  const summary = resultValue(result, 'summary') || {};
  return operationOutcome(result, {
    successCount: resultCount(summary, 'successCount'), failureCount: resultCount(summary, 'failCount'),
    partialCount: resultCount(summary, 'partialCount'), rejectedCount: resultCount(summary, 'totalRejectedParameterCount'),
    changedCount: resultCount(summary, 'totalUpdatedParameterCount'), noChangeCount: resultCount(summary, 'noChangeCount'),
    targetCount: resultCount(result, 'fileCount', null)
  });
}
function buildRunCard(state) {
  const card = div('deliverycleaner-card deliverycleaner-card--files parammodifier-run-card');
  card.innerHTML = `
    <div class="deliverycleaner-card__head">
      <div>
        <h3>실행</h3>
        <p>활성 문서에는 바로 적용하고, 여러 RVT는 목록 창에 등록한 뒤 일괄 적용합니다.</p>
      </div>
    </div>
  `;

  const actionRow = div('deliverycleaner-inline-actions multi-action-card__actions');
  const applyActiveBtn = actionButton('활성 문서 적용', () => runActiveDocument(state), 'primary');
  const openBatchBtn = actionButton('여러 RVT 적용', () => openRvtModal(state), 'secondary');
  openBatchBtn.classList.add('btn--multi');
  actionRow.append(applyActiveBtn, openBatchBtn);

  const summary = div('deliverycleaner-note');

  const syncSection = createSubsection('동기화', '활성 문서 적용 후 동기화 여부를 선택합니다.');
  const syncCheckLine = document.createElement('label');
  syncCheckLine.className = 'deliverycleaner-checkline';
  const syncCheck = document.createElement('input');
  syncCheck.type = 'checkbox';
  syncCheck.addEventListener('change', () => {
    state.synchronizeAfterProcessing = !!syncCheck.checked;
    renderRunSummary(state);
  });
  const syncText = document.createElement('span');
  syncText.textContent = '활성 문서 작업 후 동기화';
  syncCheckLine.append(syncCheck, syncText);

  const syncHint = div('deliverycleaner-note');
  const activeSyncCommentField = fieldBlock('동기화 코멘트');
  const activeSyncCommentInput = document.createElement('input');
  activeSyncCommentInput.type = 'text';
  activeSyncCommentInput.placeholder = '활성 문서 동기화 코멘트';
  activeSyncCommentInput.addEventListener('input', () => {
    updateSyncComment(state, activeSyncCommentInput.value);
  });
  activeSyncCommentField.append(activeSyncCommentInput);
  syncSection.append(syncCheckLine, activeSyncCommentField, syncHint);

  const guide = div('deliverycleaner-note');
  card.append(actionRow, summary, syncSection, guide);

  state.ui.applyActiveBtn = applyActiveBtn;
  state.ui.openBatchBtn = openBatchBtn;
  state.ui.runSummary = summary;
  state.ui.syncCheck = syncCheck;
  state.ui.activeSyncCommentInput = activeSyncCommentInput;
  state.ui.syncHint = syncHint;
  state.ui.runGuide = guide;
  return card;
}

function buildSettingsCard(state) {
  const card = div('deliverycleaner-card deliverycleaner-card--workspace parammodifier-settings-card');
  card.append(buildElementPanel(state));
  return card;
}

function buildElementPanel(state) {
  const panel = createSubsection('입력 설정', '조건과 입력 파라미터를 필요한 만큼 추가하세요. 실행 전후의 객체 ID 변경도 함께 확인합니다.');

  const comboRow = div('deliverycleaner-inline-select');
  const comboLabel = document.createElement('span');
  comboLabel.textContent = '조건 결합';
  const comboSelect = document.createElement('select');
  comboSelect.setAttribute('aria-label', '조건 결합');
  ['And', 'Or'].forEach((value) => {
    const opt = document.createElement('option');
    opt.value = value;
    opt.textContent = value;
    comboSelect.append(opt);
  });
  comboSelect.addEventListener('change', () => {
    state.elementParameterUpdate.combinationMode = comboSelect.value;
    renderElementUpdateSummary(state);
  });
  comboRow.append(comboLabel, comboSelect);

  const conditionSection = createCompactSection('조건', '대상 객체를 추려내는 조건입니다.');
  const conditionWrap = div('deliverycleaner-table-scroll');
  conditionWrap.dataset.parammodifierScrollKey = 'conditions';
  const conditionTable = document.createElement('table');
  conditionTable.className = 'deliverycleaner-grid-table';
  conditionTable.innerHTML = `
    <thead>
      <tr>
        <th>조건 파라미터</th>
        <th>연산자</th>
        <th>값</th>
        <th>삭제</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  conditionWrap.append(conditionTable);
  const addCondition = actionButton('조건 추가', () => addElementUpdateRow(state, 'conditions'), 'secondary');
  conditionSection.append(conditionWrap, addCondition);

  const assignmentSection = createCompactSection('입력 파라미터', '선택된 객체에 입력할 파라미터와 값을 지정합니다.');
  const assignmentWrap = div('deliverycleaner-table-scroll');
  assignmentWrap.dataset.parammodifierScrollKey = 'assignments';
  const assignmentTable = document.createElement('table');
  assignmentTable.className = 'deliverycleaner-grid-table';
  assignmentTable.innerHTML = `
    <thead>
      <tr>
        <th>입력 파라미터</th>
        <th>값</th>
        <th>삭제</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  assignmentWrap.append(assignmentTable);
  const addAssignment = actionButton('입력 파라미터 추가', () => addElementUpdateRow(state, 'assignments'), 'secondary');
  assignmentSection.append(assignmentWrap, addAssignment);

  const splitGrid = div('deliverycleaner-split-grid');
  splitGrid.append(conditionSection, assignmentSection);

  const summary = div('deliverycleaner-summary-box');
  panel.append(comboRow, splitGrid, summary);

  state.ui.combinationMode = comboSelect;
  state.ui.conditionBody = conditionTable.querySelector('tbody');
  state.ui.assignmentBody = assignmentTable.querySelector('tbody');
  state.ui.elementSummary = summary;
  state.ui.addCondition = addCondition;
  state.ui.addAssignment = addAssignment;
  state.ui.rowNodes = new WeakMap();
  state.ui.nextRowKey = 0;
  return panel;
}

function buildRvtModal(state) {
  const overlay = div('rvt-expand-overlay parammodifier-rvt-overlay');
  overlay.classList.add('is-hidden');

  const modal = div('rvt-expand-modal parammodifier-rvt-modal');
  const toolbar = div('rvt-expand-toolbar');
  const titleWrap = div('rvt-expand-title');
  const title = document.createElement('h3');
  title.textContent = '여러 RVT 적용';
  const badge = document.createElement('span');
  badge.className = 'chip chip--info';
  titleWrap.append(title, badge);

  const toolbarActions = div('rvt-expand-actions');
  const btnAdd = actionButton('RVT 추가', () => post('parammodifier:pick-rvts', {}), 'primary');
  const btnRemove = actionButton('선택 제거', () => {
    state.rvtPaths = state.rvtPaths.filter((path) => !state.checked.has(path));
    state.checked.clear();
    renderRvtModal(state);
    renderRunSummary(state);
    updateActionState(state);
  });
  const btnClear = actionButton('목록 비우기', () => {
    state.rvtPaths = [];
    state.checked.clear();
    renderRvtModal(state);
    renderRunSummary(state);
    updateActionState(state);
  });
  const btnClose = actionButton('닫기', () => closeRvtModal(state), 'secondary');
  toolbarActions.append(btnAdd, btnRemove, btnClear, btnClose);
  toolbar.append(titleWrap, toolbarActions);

  const body = div('rvt-expand-body');
  const panel = div('rvt-expand-panel');

  const listSection = div('rvt-expand-section rvt-expand-section--list');
  const listHead = div('rvt-expand-section__head');
  const listTitle = document.createElement('h4');
  listTitle.textContent = '선택된 RVT 목록';
  const listSub = document.createElement('span');
  listSub.textContent = '센트럴 파일은 로컬로 열고, 웍셋은 모두 닫힌 상태로 처리합니다. 탐색기에서 .rvt 파일을 바로 끌어와 추가할 수도 있습니다.';
  listHead.append(listTitle, listSub);

  const tableWrap = div('rvt-expand-table rvt-drop-zone');
  const { table, tbody, master } = createRvtTable({ registration: true });
  table.classList.add('rvt-expand-table__grid');
  const listEmpty = div('rvt-expand-list-empty');
  const emptyTitle = document.createElement('strong');
  emptyTitle.textContent = '등록된 RVT가 없습니다.';
  const emptyText = document.createElement('span');
  emptyText.textContent = 'RVT 추가 버튼을 누르거나 탐색기에서 .rvt 파일을 이 영역으로 끌어오면 바로 목록에 추가됩니다.';
  const emptyBtn = actionButton('RVT 추가', () => post('parammodifier:pick-rvts', {}), 'primary');
  listEmpty.append(emptyTitle, emptyText, emptyBtn);
  tableWrap.append(table, listEmpty);
  listSection.append(listHead, tableWrap);

  const sideSection = div('rvt-expand-section rvt-expand-section--side');

  const syncSection = div('rvt-expand-subsection');
  const syncHead = div('rvt-expand-subsection__head');
  const syncTitle = document.createElement('h4');
  syncTitle.textContent = '동기화';
  const syncDescription = document.createElement('span');
  syncDescription.textContent = '여러 RVT 작업 후 자동 동기화할 때 아래 코멘트를 사용합니다.';
  syncHead.append(syncTitle, syncDescription);
  const syncCommentField = fieldBlock('동기화 코멘트');
  const syncCommentInput = document.createElement('input');
  syncCommentInput.type = 'text';
  syncCommentInput.placeholder = '파라미터 수정기 일괄 입력';
  syncCommentInput.addEventListener('input', () => {
    updateSyncComment(state, syncCommentInput.value);
  });
  syncCommentField.append(syncCommentInput);
  syncSection.append(syncHead, syncCommentField);

  const readySection = div('rvt-expand-subsection rvt-expand-subsection--recent');
  const readyHead = div('rvt-expand-subsection__head');
  const readyTitle = document.createElement('h4');
  readyTitle.textContent = '적용 준비';
  const readyCaption = document.createElement('div');
  readyCaption.className = 'multi-recent-caption';
  const readyHint = document.createElement('div');
  readyHint.className = 'multi-recent-hint';
  readyHead.append(readyTitle, readyCaption, readyHint);

  const readyCard = div('review-feature-card');
  const readyCardHead = div('review-feature-card__head');
  const readyCardLabel = document.createElement('strong');
  readyCardLabel.textContent = '파라미터 수정 적용';
  const readyCardBadge = document.createElement('span');
  readyCardBadge.className = 'review-feature-card__badge';
  readyCardHead.append(readyCardLabel, readyCardBadge);
  const readyList = document.createElement('ul');
  readyList.className = 'review-feature-card__list';
  const readyRunBtn = actionButton('선택된 RVT 적용 시작', () => runBatchDocuments(state), 'primary');
  readyRunBtn.classList.add('review-feature-card__action');
  readyCard.append(readyCardHead, readyList, readyRunBtn);
  readySection.append(readyHead, readyCard);

  sideSection.append(syncSection, readySection);
  panel.append(listSection, sideSection);
  body.append(panel);
  modal.append(toolbar, body);
  overlay.append(modal);

  attachRvtDropZone(tableWrap, {
    onDropPaths: (paths) => {
      const added = appendDroppedRvts(state, paths);
      if (!added) {
        toast('이미 등록된 RVT입니다.', 'warn');
        return;
      }
      renderRvtModal(state);
      renderRunSummary(state);
      updateActionState(state);
      toast(`${added}개 RVT를 추가했습니다.`, 'ok');
    },
    onInvalid: () => toast('RVT 파일만 등록할 수 있습니다.', 'warn')
  });

  overlay.addEventListener('click', (ev) => {
    if (ev.target === overlay) closeRvtModal(state);
  });
  modal.addEventListener('click', (ev) => ev.stopPropagation());

  state.ui.rvtRegistration = createRvtRegistration({
    overlay, dialog: modal, header: toolbar, actions: toolbarActions, body,
    tableWrap, table, empty: listEmpty, addButton: btnAdd, closeButton: btnClose,
    onClose: () => closeRvtModal(state)
  });
  state.ui.rvtOverlay = overlay;
  state.ui.rvtBody = tbody;
  state.ui.rvtMaster = master;
  state.ui.rvtTable = table;
  state.ui.rvtEmpty = listEmpty;
  state.ui.rvtModalCount = badge;
  state.ui.rvtModalRemoveBtn = btnRemove;
  state.ui.rvtModalClearBtn = btnClear;
  state.ui.batchSyncCommentInput = syncCommentInput;
  state.ui.batchReadyCaption = readyCaption;
  state.ui.batchReadyHint = readyHint;
  state.ui.batchReadyList = readyList;
  state.ui.batchReadyBadge = readyCardBadge;
  state.ui.batchReadyRunBtn = readyRunBtn;
  return overlay;
}

function runActiveDocument(state) {
  if (getActiveBlockingReason(state)) {
    updateActionState(state);
    return;
  }

  state.acceptProgress = true;
  setPageBusy(state, true);
  beginParamModifierProgress(state, '파라미터 수정기', '활성 문서 적용을 준비하는 중입니다.');
  post('parammodifier:run', buildPayload(state, true));
}

function runBatchDocuments(state) {
  if (getBatchBlockingReason(state)) {
    updateActionState(state);
    return;
  }

  state.acceptProgress = true;
  setPageBusy(state, true);
  closeRvtModal(state);
  const targetCount = getCheckedRvtPaths(state).length;
  beginParamModifierProgress(state, 
    '파라미터 수정기',
    `${targetCount}개 RVT 적용을 시작합니다.`,
    '첫 번째 파일을 확인하는 중입니다.'
  );
  post('parammodifier:run', buildPayload(state, false));
}

function openRvtModal(state) {
  if (getBatchOpenBlockingReason(state)) {
    updateActionState(state);
    return;
  }
  state.ui.rvtRegistration?.open();
  renderRvtModal(state);
  updateActionState(state);
}

function closeRvtModal(state) {
  state.ui.rvtRegistration?.close();
}

function beginParamModifierProgress(state, title, message, detail = '', percent = 0) {
  ProgressDialog.setActions({});
  state.progressOwner = ProgressDialog.show(title || '파라미터 수정기', message || '파라미터 수정 작업을 준비하는 중입니다.');
  ProgressDialog.update(percent, message || '파라미터 수정 작업을 준비하는 중입니다.', detail || '', state.progressOwner);
}

function updateSyncComment(state, value) {
  state.syncComment = String(value || '');
  syncInputs(state);
  renderRunSummary(state);
  renderBatchReadyCard(state);
}

function renderRunSummary(state) {
  if (!state.ui.runSummary || !state.ui.syncHint) return;

  const doc = getActiveDocumentSnapshot(state);
  const title = doc?.title || '활성 문서를 찾을 수 없습니다.';
  const docType = doc?.isWorkshared === true ? '웍셋 문서' : doc?.isWorkshared === false ? '일반 문서' : '프로젝트 문서';
  const rvtCount = state.rvtPaths.length;
  const syncCommentState = state.syncComment ? `입력됨 (${state.syncComment})` : '코멘트가 없습니다.';
  state.ui.runSummary.textContent = `${state.busy && state.runDocument ? '실행 문서' : '현재 문서'}: ${title}\n문서 유형: ${docType}\n등록된 RVT: ${rvtCount}개`;
  state.ui.syncHint.textContent = state.synchronizeAfterProcessing
    ? `활성 문서 적용 후 동기화를 수행합니다. 현재 코멘트: ${syncCommentState}`
    : '활성 문서는 동기화 없이 적용합니다. 여러 RVT는 작업 후 자동 동기화됩니다.';
}

function renderRvtModal(state) {
  if (!state.ui.rvtBody || !state.ui.rvtMaster) return;

  const rows = state.rvtPaths.map((path, index) => ({
    checked: state.checked.has(path),
    index: index + 1,
    name: getRvtName(path),
    path,
    title: path,
    onToggle: (checked) => {
      if (checked) state.checked.add(path);
      else state.checked.delete(path);
      renderRvtModal(state);
      updateActionState(state);
    }
  }));

  renderRvtRows(state.ui.rvtBody, rows, '등록된 RVT가 없습니다.');

  const count = state.rvtPaths.length;
  state.ui.rvtModalCount.textContent = `${count}개`;
  state.ui.rvtEmpty.style.display = count ? 'none' : 'flex';
  state.ui.rvtTable.style.display = count ? 'table' : 'none';
  state.ui.rvtMaster.checked = count > 0 && state.rvtPaths.every((path) => state.checked.has(path));
  state.ui.rvtMaster.disabled = count === 0;
  state.ui.rvtMaster.onchange = () => {
    if (state.ui.rvtMaster.checked) state.checked = new Set(state.rvtPaths);
    else state.checked.clear();
    renderRvtModal(state);
    updateActionState(state);
  };

  if (state.ui.rvtModalRemoveBtn) state.ui.rvtModalRemoveBtn.disabled = state.checked.size === 0 || state.busy;
  if (state.ui.rvtModalClearBtn) state.ui.rvtModalClearBtn.disabled = count === 0 || state.busy;

  renderBatchReadyCard(state);
}

function renderBatchReadyCard(state) {
  if (!state.ui.batchReadyCaption || !state.ui.batchReadyHint || !state.ui.batchReadyList || !state.ui.batchReadyBadge) return;

  const assignments = getAssignmentRows(state);
  const conditions = getConditionRows(state);
  const ready = assignments.length > 0;

  state.ui.batchReadyCaption.textContent = ready ? '입력 설정과 적용 준비가 완료되었습니다.' : '입력 설정이 필요합니다.';
  state.ui.batchReadyHint.textContent = state.rvtPaths.length
    ? `${state.rvtPaths.length}개 RVT가 등록되어 있습니다.`
    : 'RVT를 추가하면 바로 배치 적용을 시작할 수 있습니다.';
  state.ui.batchReadyBadge.textContent = ready ? '적용 준비 완료' : '입력 설정 필요';

  state.ui.batchReadyList.innerHTML = '';
  [
    `조건 ${conditions.length}개`,
    `입력 파라미터 ${assignments.length}개`,
    state.syncComment ? `동기화 코멘트 입력됨 (${state.syncComment})` : '동기화 코멘트가 없습니다.',
    '센트럴 파일은 로컬로 열고 웍셋은 모두 닫은 채 처리'
  ].forEach((line) => {
    const item = document.createElement('li');
    item.textContent = line;
    state.ui.batchReadyList.append(item);
  });
}

function renderElementUpdateRows(state) {
  ['conditions', 'assignments'].forEach((kind) => {
    const body = kind === 'conditions' ? state.ui.conditionBody : state.ui.assignmentBody;
    if (!body) return;
    const rows = state.elementParameterUpdate[kind];
    const nodes = new Set(rows.map((row) => state.ui.rowNodes.get(row)).filter(Boolean));
    Array.from(body.children).forEach((node) => { if (!nodes.has(node)) node.remove(); });
    rows.forEach((row, index) => {
      let tr = state.ui.rowNodes.get(row);
      if (!tr) {
        tr = document.createElement('tr');
        tr.dataset.parammodifierRowKey = String(++state.ui.nextRowKey);
        const fields = kind === 'conditions' ? ['parameterName', 'operatorName', 'value'] : ['parameterName', 'value'];
        fields.forEach((field) => {
          const update = (value) => {
            row[field] = value;
            renderElementUpdateSummary(state);
          };
          const cell = field === 'operatorName'
            ? tdWithSelect(row[field], FILTER_OPERATORS, update)
            : tdWithInput(row[field], field === 'parameterName' ? '파라미터 이름' : '값', update);
          const control = cell.firstElementChild;
          control.dataset.parammodifierField = field;
          control.dataset.parammodifierFocusKey = `${tr.dataset.parammodifierRowKey}-${field}`;
          tr.append(cell);
        });
        const removeCell = document.createElement('td');
        removeCell.append(actionButton('삭제', () => removeElementUpdateRow(state, kind, row), 'secondary'));
        tr.append(removeCell);
        state.ui.rowNodes.set(row, tr);
      }
      // Keep existing inputs attached: moving every row resets focus in WebView2.
      if (body.children[index] !== tr) body.insertBefore(tr, body.children[index] || null);
      const label = kind === 'conditions' ? '조건' : '입력 파라미터';
      tr.querySelectorAll('[data-parammodifier-field]').forEach((control) => {
        const field = control.dataset.parammodifierField;
        const value = String(row[field] ?? '');
        if (document.activeElement !== control && control.value !== value) control.value = value;
        control.setAttribute('aria-label', `${label} ${index + 1} ${field === 'parameterName' ? '이름' : field === 'operatorName' ? '연산자' : '값'}`);
      });
      tr.querySelector('button').setAttribute('aria-label', `${label} ${index + 1} 삭제`);
    });
  });
  renderElementUpdateSummary(state);
}

function addElementUpdateRow(state, kind) {
  if (state.busy) return;
  state.elementParameterUpdate[kind].push(createElementUpdateRow(kind));
  renderElementUpdateRows(state);
  saveParamModifierPreferences(state);
}

function removeElementUpdateRow(state, kind, row) {
  if (state.busy) return;
  const rows = state.elementParameterUpdate[kind];
  const index = rows.indexOf(row);
  if (index < 0) return;
  const node = state.ui.rowNodes.get(row);
  const hadFocus = node?.contains(document.activeElement);
  rows.splice(index, 1);
  renderElementUpdateRows(state);
  if (hadFocus) {
    const next = state.ui.rowNodes.get(rows[Math.min(index, rows.length - 1)]);
    (next?.querySelector('button') || (kind === 'conditions' ? state.ui.addCondition : state.ui.addAssignment))?.focus({ preventScroll: true });
  }
  saveParamModifierPreferences(state);
}

function renderElementUpdateSummary(state) {
  if (!state.ui.elementSummary) return;

  const conditions = getConditionRows(state);
  const assignments = getAssignmentRows(state);
  const joiner = state.elementParameterUpdate.combinationMode === 'Or' ? ' OR ' : ' AND ';

  const conditionText = conditions.length
    ? conditions.map((row) => (row.operatorName === 'HasValue' || row.operatorName === 'HasNoValue')
      ? `${row.parameterName} ${row.operatorName}`
      : `${row.parameterName} ${row.operatorName} ${row.value || ''}`).join(joiner)
    : '추가 조건이 없습니다.';

  const assignmentText = assignments.length
    ? assignments.map((row) => `${row.parameterName} = ${row.value || ''}`).join(' / ')
    : '입력 파라미터가 없습니다.';

  state.ui.elementSummary.textContent = `조건: ${conditionText}\n입력: ${assignmentText}`;
  renderRvtModal(state);
  updateActionState(state);
}

function applyHostState(state, payload) {
  const settings = payload?.settings || {};
  const initializeSettings = !state.hasSavedPreferences;
  const result = payload?.result || null;
  const activeDocument = payload?.activeDocument || null;

  if (Array.isArray(settings.rvtPaths)) {
    state.rvtPaths = [...settings.rvtPaths];
    state.checked = new Set(state.rvtPaths);
  }
  if (!state.hasSavedPreferences) {
    applyParamModifierPreferences(state, {
      synchronizeAfterProcessing: typeof settings.synchronizeAfterProcessing === 'boolean'
        ? settings.synchronizeAfterProcessing
        : false,
      syncComment: typeof settings.syncComment === 'string' ? settings.syncComment : '',
      elementParameterUpdate: settings.elementParameterUpdate
    });
    saveParamModifierPreferences(state);
    state.hasSavedPreferences = true;
  }

  state.lastResult = result;
  acceptActiveDocumentSnapshot(state, activeDocument);

  if (initializeSettings) {
    syncInputs(state);
    renderElementUpdateRows(state);
  }
  renderRunSummary(state);
  renderRvtModal(state);
  updateActionState(state);
}

function syncInputs(state) {
  if (state.ui.syncCheck) state.ui.syncCheck.checked = !!state.synchronizeAfterProcessing;
  [state.ui.activeSyncCommentInput, state.ui.batchSyncCommentInput].forEach(input => {
    if (input && input.value !== (state.syncComment || '')) input.value = state.syncComment || '';
  });
  if (state.ui.combinationMode) state.ui.combinationMode.value = state.elementParameterUpdate.combinationMode || 'And';
}

function updateActionState(state) {
  const activeReason = getActiveBlockingReason(state);
  const batchOpenReason = getBatchOpenBlockingReason(state);
  const batchRunReason = getBatchBlockingReason(state);

  if (state.ui.applyActiveBtn) state.ui.applyActiveBtn.disabled = !!activeReason || state.busy;
  if (state.ui.openBatchBtn) state.ui.openBatchBtn.disabled = !!batchOpenReason || state.busy;
  if (state.ui.batchReadyRunBtn) state.ui.batchReadyRunBtn.disabled = !!batchRunReason || state.busy;
  if (state.ui.addCondition) state.ui.addCondition.disabled = state.busy;
  if (state.ui.addAssignment) state.ui.addAssignment.disabled = state.busy;
  [state.ui.conditionBody, state.ui.assignmentBody].forEach((body) => {
    body?.querySelectorAll('input, select, button').forEach((control) => { control.disabled = state.busy; });
  });

  if (state.ui.runGuide) {
    if (state.busy) {
      state.ui.runGuide.textContent = '파라미터 수정 작업을 진행하는 중입니다. 완료되면 결과 알림을 표시합니다.';
    } else if (batchOpenReason) {
      state.ui.runGuide.textContent = '입력 파라미터를 1개 이상 설정하면 활성 문서 적용과 여러 RVT 적용 버튼이 활성화됩니다.';
    } else if (!state.activeDocument) {
      state.ui.runGuide.textContent = '현재 활성 문서를 찾을 수 없습니다.';
    } else {
      state.ui.runGuide.textContent = '입력 설정이 준비되었습니다. 활성 문서 적용은 바로 실행하고, 여러 RVT 적용은 목록 창에서 시작합니다.';
    }
  }
}

function getActiveBlockingReason(state) {
  if (!getAssignmentRows(state).length) return '입력 파라미터를 1개 이상 설정해 주세요.';
  if (!state.activeDocument) return '활성 문서를 찾을 수 없습니다.';
  return '';
}

function getBatchOpenBlockingReason(state) {
  if (!getAssignmentRows(state).length) return '입력 파라미터를 1개 이상 설정해 주세요.';
  return '';
}

function getBatchBlockingReason(state) {
  if (!getAssignmentRows(state).length) return '입력 파라미터를 1개 이상 설정해 주세요.';
  if (!state.rvtPaths.length) return '적용할 RVT를 1개 이상 등록해 주세요.';
  if (!getCheckedRvtPaths(state).length) return '적용할 RVT를 1개 이상 선택해 주세요.';
  return '';
}

function getCheckedRvtPaths(state) {
  return state.rvtPaths.filter((path) => state.checked.has(path));
}

function buildPayload(state, useActiveDocument) {
  return {
    useActiveDocument: !!useActiveDocument,
    activeDocument: getParamModifierActiveDocumentInfo(state),
    rvtPaths: useActiveDocument ? [] : getCheckedRvtPaths(state),
    outputFolder: '',
    closeAllWorksetsOnOpen: true,
    synchronizeAfterProcessing: useActiveDocument ? !!state.synchronizeAfterProcessing : true,
    syncComment: state.syncComment,
    filterProfile: null,
    elementParameterUpdate: {
      enabled: true,
      combinationMode: state.elementParameterUpdate.combinationMode,
      conditions: state.elementParameterUpdate.conditions.map((row) => ({
        ...row,
        enabled: !!String(row.parameterName || '').trim()
      })),
      assignments: state.elementParameterUpdate.assignments.map((row) => ({
        ...row,
        enabled: !!String(row.parameterName || '').trim()
      }))
    }
  };
}

function loadParamModifierPreferences() {
  try {
    const value = JSON.parse(localStorage.getItem(PARAMMODIFIER_SETTINGS_KEY) || 'null');
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

function applyParamModifierPreferences(state, value) {
  if (!value || typeof value !== 'object') return;
  state.synchronizeAfterProcessing = !!value.synchronizeAfterProcessing;
  state.syncComment = String(value.syncComment || '').trim();
  const normalized = normalizeElementUpdate(value.elementParameterUpdate || {});
  // Reuse row objects so remote updates do not replace unchanged controls.
  ['conditions', 'assignments'].forEach((kind) => {
    normalized[kind] = normalized[kind].map((row, index) => Object.assign(state.elementParameterUpdate[kind][index] || {}, row));
  });
  state.elementParameterUpdate = normalized;
}

function normalizeParamModifierPreferences(value) {
  return {
    synchronizeAfterProcessing: !!value.synchronizeAfterProcessing,
    syncComment: String(value.syncComment || '').trim(),
    elementParameterUpdate: normalizeElementUpdate(value.elementParameterUpdate || {})
  };
}

function saveParamModifierPreferences(state) {
  const serialized = JSON.stringify(normalizeParamModifierPreferences(state));
  if (serialized === state.lastSavedPreferences) return;
  try {
    localStorage.setItem(PARAMMODIFIER_SETTINGS_KEY, serialized);
    state.lastSavedPreferences = serialized;
    state.hasSavedPreferences = true;
  } catch {}
}

function attachParamModifierPreferenceSync(page, state) {
  let saveTimer = 0;
  let applyTimer = 0;
  let routeTimer = 0;
  let composing = false;
  let pointerActive = false;
  const scheduleSave = () => {
    state.hasSavedPreferences = true;
    clearTimeout(saveTimer);
    if (composing) return;
    saveTimer = window.setTimeout(() => saveParamModifierPreferences(state), 180);
  };
  const onCompositionStart = () => { composing = true; clearTimeout(saveTimer); };
  const onCompositionEnd = () => { composing = false; scheduleSave(); };
  const onPointerDown = () => { pointerActive = true; };
  const onPointerEnd = () => { pointerActive = false; };
  const scheduleSaveAfterClick = scheduleSave;
  page.addEventListener('input', scheduleSave);
  page.addEventListener('change', scheduleSave);
  page.addEventListener('click', scheduleSaveAfterClick);
  page.addEventListener('compositionstart', onCompositionStart);
  page.addEventListener('compositionend', onCompositionEnd);
  page.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('pointerup', onPointerEnd);
  window.addEventListener('pointercancel', onPointerEnd);

  const tryApply = () => {
    clearTimeout(applyTimer);
    if (!page.isConnected) return;
    const value = loadParamModifierPreferences();
    if (!value) return;
    const serialized = JSON.stringify(normalizeParamModifierPreferences(value));
    if (serialized === JSON.stringify(normalizeParamModifierPreferences(state))) {
      state.lastSavedPreferences = serialized;
      return;
    }
    const active = document.activeElement;
    const editing = !!active && page.contains(active) && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName || '');
    if (state.busy || editing || composing || pointerActive) {
      applyTimer = window.setTimeout(tryApply, 400);
      return;
    }
    applyParamModifierPreferences(state, value);
    state.lastSavedPreferences = serialized;
    syncInputs(state);
    renderElementUpdateRows(state);
    renderRunSummary(state);
    renderRvtModal(state);
    updateActionState(state);
  };
  const onSharedChange = (event) => {
    if (isParamModifierSharedEvent(event, PARAMMODIFIER_SETTINGS_KEY)) tryApply();
  };
  const cleanup = () => {
    clearTimeout(saveTimer);
    clearTimeout(applyTimer);
    clearTimeout(routeTimer);
    page.removeEventListener('input', scheduleSave);
    page.removeEventListener('change', scheduleSave);
    page.removeEventListener('click', scheduleSaveAfterClick);
    page.removeEventListener('compositionstart', onCompositionStart);
    page.removeEventListener('compositionend', onCompositionEnd);
    page.removeEventListener('pointerdown', onPointerDown);
    window.removeEventListener('pointerup', onPointerEnd);
    window.removeEventListener('pointercancel', onPointerEnd);
    window.removeEventListener('kky:shared-settings-changed', onSharedChange);
    window.removeEventListener('hashchange', onRouteChange);
    if (activeParamModifierPreferenceCleanup === cleanup) activeParamModifierPreferenceCleanup = null;
  };
  const onRouteChange = () => {
    clearTimeout(routeTimer);
    routeTimer = window.setTimeout(() => {
      if (!page.isConnected) cleanup();
    }, 0);
  };
  window.addEventListener('kky:shared-settings-changed', onSharedChange);
  window.addEventListener('hashchange', onRouteChange);
  return cleanup;
}

function isParamModifierSharedEvent(event, key) {
  const detail = event?.detail;
  if (!detail) return true;
  const keys = Array.isArray(detail.keys) ? [...detail.keys] : [];
  if (detail.key) keys.push(detail.key);
  if (detail.values && typeof detail.values === 'object') keys.push(...Object.keys(detail.values));
  return !keys.length || keys.includes(key);
}

function getParamModifierActiveDocumentInfo(state) {
  const doc = getActiveDocumentSnapshot(state, getTopbarState()?.activeDocument) || {};
  return {
    name: doc.name || doc.title || '',
    title: doc.title || doc.name || '',
    path: doc.path || doc.filePath || ''
  };
}

function createElementUpdateState() {
  return {
    enabled: true,
    combinationMode: 'And',
    conditions: Array.from({ length: 4 }, () => createElementUpdateRow('conditions')),
    assignments: Array.from({ length: 4 }, () => createElementUpdateRow('assignments'))
  };
}

function createElementUpdateRow(kind) {
  return kind === 'conditions'
    ? { enabled: false, parameterName: '', operatorName: 'Equals', value: '' }
    : { enabled: false, parameterName: '', value: '' };
}

function normalizeElementUpdate(source) {
  const base = createElementUpdateState();
  base.combinationMode = source.combinationMode || 'And';
  ['conditions', 'assignments'].forEach((kind) => {
    base[kind] = (Array.isArray(source[kind]) ? source[kind] : base[kind]).map((row) => ({
      ...createElementUpdateRow(kind),
      ...row,
      enabled: !!String(row?.parameterName || '').trim()
    }));
  });
  return base;
}

function getConditionRows(state) {
  return state.elementParameterUpdate.conditions.filter((row) => String(row.parameterName || '').trim());
}

function getAssignmentRows(state) {
  return state.elementParameterUpdate.assignments.filter((row) => String(row.parameterName || '').trim());
}

function appendDroppedRvts(state, paths) {
  let added = 0;
  (Array.isArray(paths) ? paths : []).forEach((path) => {
    if (!path) return;
    if (!state.rvtPaths.some((item) => samePath(item, path))) {
      state.rvtPaths.push(path);
      added += 1;
    }
    state.checked.add(path);
  });
  return added;
}

function samePath(left, right) {
  return String(left || '').toLowerCase() === String(right || '').toLowerCase();
}

function actionButton(label, onClick, variant = 'secondary') {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = `btn ${variant === 'primary' ? 'btn--primary' : 'btn--secondary'}`;
  btn.textContent = label;
  btn.addEventListener('click', onClick);
  return btn;
}

function fieldBlock(labelText) {
  const wrap = div('deliverycleaner-field');
  const label = document.createElement('label');
  label.textContent = labelText;
  wrap.append(label);
  return wrap;
}

function createSubsection(title, description) {
  const section = div('deliverycleaner-subsection');
  const head = div('deliverycleaner-subsection__head');
  const h4 = document.createElement('h4');
  h4.textContent = title;
  const p = document.createElement('p');
  p.textContent = description;
  head.append(h4, p);
  section.append(head);
  return section;
}

function createCompactSection(title, description) {
  const section = div('deliverycleaner-subsection deliverycleaner-subsection--compact');
  const head = div('deliverycleaner-subsection__head');
  const h4 = document.createElement('h4');
  h4.textContent = title;
  const p = document.createElement('p');
  p.textContent = description;
  head.append(h4, p);
  section.append(head);
  return section;
}

function tdWithInput(value, placeholder, onChange) {
  const td = document.createElement('td');
  const input = document.createElement('input');
  input.type = 'text';
  input.value = value || '';
  input.placeholder = placeholder || '';
  input.addEventListener('input', () => onChange(input.value.trim()));
  td.append(input);
  return td;
}

function tdWithSelect(value, options, onChange) {
  const td = document.createElement('td');
  const select = document.createElement('select');
  options.forEach((optionValue) => {
    const opt = document.createElement('option');
    opt.value = optionValue;
    opt.textContent = optionValue;
    select.append(opt);
  });
  select.value = value || options[0];
  select.addEventListener('change', () => onChange(select.value));
  td.append(select);
  return td;
}

function setPageBusy(state, on) {
  if (on && !state.busy) beginActiveDocumentRun(state, getTopbarState()?.activeDocument);
  if (!on) finishActiveDocumentRun(state);
  state.busy = !!on;
  if (!state.busy) state.acceptProgress = false;
  setBusy(on, on ? '파라미터 수정 작업을 처리하는 중입니다.' : '');
  updateActionState(state);
  renderRunSummary(state);
}

