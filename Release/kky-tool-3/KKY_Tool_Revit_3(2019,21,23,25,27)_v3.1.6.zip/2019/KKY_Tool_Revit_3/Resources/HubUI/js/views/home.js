// Resources/HubUI/js/views/home.js
import { clear, div } from '../core/dom.js?v=20260731parameterexport1';
import { onHost, post } from '../core/bridge.js';
import {
  getTopbarState,
  TOPBAR_STATE_CHANGE_EVENT
} from '../core/topbar.js?v=20261012official316';
import { renderShell3 } from '../core/shell3.js?v=20261012official316';
import { getFeatureCounts3 } from '../core/featureCatalog3.js?v=20260917columnnumber1';
import { getWebsiteUrl } from '../core/featureGuide.js?v=20260916linkbatch1';
import {
  getFavoriteEntries,
  getHubQuickAccessEntries,
  HUB_QUICK_ACCESS_CHANGE_EVENT,
  openHubEntry
} from '../core/hubFavorites.js?v=20260917columnnumber1';

const HOME_SCHEDULE_KEY = 'kky.hub.home.deliverySchedule.v1';
const PRODUCT_VERSION_DISPLAY = '3.1.6';

export function renderHome(root) {
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);

  const main = div('home3-main home3-dashboard-main');
  const aside = div('home3-aside home3-dashboard-aside');
  const session = div('shell3-panel home3-session');
  const launch = div('shell3-panel home3-launch');
  const recent = div('shell3-panel home3-recent');
  const update = div('shell3-panel home3-update');
  const help = div('shell3-panel home3-help');
  const agenda = div('shell3-panel home3-agenda');
  const scheduleState = { entries: loadScheduleEntries() };

  main.append(session, launch, recent);
  aside.append(update, help, agenda);

  renderShell3(target, {
    active: 'home',
    layout: 'home',
    title: 'Home',
    subtitle: '현재 Revit 작업과 자주 쓰는 도구를 한곳에서 확인합니다.',
    main,
    aside
  });

  const render = () => {
    renderSession(session);
    renderLaunch(launch);
    renderRecent(recent);
    renderUpdate(update);
    renderHelp(help);
    renderAgenda(agenda, scheduleState);
  };

  let pointerActive = false;
  let renderPending = false;
  let renderTimer = 0;
  let pointerReleaseTimer = 0;
  let disposed = false;
  let stopSchedule = () => {};

  const cleanup = () => {
    if (disposed) return;
    disposed = true;
    window.clearTimeout(renderTimer);
    window.clearTimeout(pointerReleaseTimer);
    window.removeEventListener(TOPBAR_STATE_CHANGE_EVENT, onChange);
    window.removeEventListener(HUB_QUICK_ACCESS_CHANGE_EVENT, onChange);
    window.removeEventListener('pointerup', onPointerEnd, true);
    window.removeEventListener('pointercancel', onPointerEnd, true);
    main.removeEventListener('pointerdown', onPointerDown, true);
    aside.removeEventListener('pointerdown', onPointerDown, true);
    stopSchedule();
  };

  const flushRender = () => {
    renderTimer = 0;
    if (!main.isConnected) {
      cleanup();
      return;
    }
    if (pointerActive) return;
    renderPending = false;
    render();
  };

  const requestRender = () => {
    if (!main.isConnected) {
      cleanup();
      return;
    }
    renderPending = true;
    window.clearTimeout(renderTimer);
    // Revit can answer a focus sync between pointerdown and click. Keep the
    // pressed button alive until the click has been delivered.
    renderTimer = window.setTimeout(flushRender, 160);
  };

  const onPointerDown = () => {
    pointerActive = true;
    window.clearTimeout(pointerReleaseTimer);
  };

  const onPointerEnd = () => {
    window.clearTimeout(pointerReleaseTimer);
    pointerReleaseTimer = window.setTimeout(() => {
      pointerActive = false;
      if (renderPending) flushRender();
    }, 0);
  };

  stopSchedule = onHost('host:schedule-board-settings', (payload = {}) => {
    scheduleState.entries = normalizeScheduleEntries(payload.entries || payload.Entries || []);
    requestRender();
  });

  const onChange = () => {
    if (!main.isConnected) {
      cleanup();
      return;
    }
    requestRender();
  };

  window.addEventListener(TOPBAR_STATE_CHANGE_EVENT, onChange);
  window.addEventListener(HUB_QUICK_ACCESS_CHANGE_EVENT, onChange);
  window.addEventListener('pointerup', onPointerEnd, true);
  window.addEventListener('pointercancel', onPointerEnd, true);
  main.addEventListener('pointerdown', onPointerDown, true);
  aside.addEventListener('pointerdown', onPointerDown, true);
  try { post('scheduleboard:query'); } catch { }
  try { post('ui:sync-context'); } catch { }
  render();
}

function renderSession(host) {
  clear(host);
  const state = getTopbarState();
  const docs = Array.isArray(state.documents) ? state.documents : [];
  const activeName = getDocumentName(state.activeDocument);
  const activePath = getDocumentPath(state.activeDocument);
  host.append(buildPanelHead(
    'Current Revit',
    '현재 작업',
    activeName ? '연결됨' : '연결 대기',
    [],
    activeName ? 'ok' : ''
  ));

  const body = div('shell3-panel-body home3-session-body');
  const primary = div('home3-session-primary');
  primary.innerHTML = `
    <span class="home3-session-mark" aria-hidden="true">R</span>
    <div class="home3-session-copy">
      <span>활성 문서</span>
      <strong title="${escapeHtml(activeName || 'Revit 연결 대기')}">${escapeHtml(activeName || 'Revit 연결 대기')}</strong>
      <em title="${escapeHtml(activePath || '')}">${escapeHtml(activePath || '열린 호스트 문서가 연결되면 여기에 표시됩니다.')}</em>
    </div>
    <div class="home3-session-status" aria-label="현재 Revit 상태">
      <span>${docs.length}개 문서</span>
    </div>`;
  body.append(primary);

  const docList = div('home3-document-list');
  if (!docs.length) {
    const empty = div('home3-inline-empty');
    empty.textContent = '열린 호스트 문서 없음';
    docList.append(empty);
  } else {
    const activeKey = normalizePath(activePath);
    docs.slice(0, 5).forEach((doc) => {
      const path = getDocumentPath(doc);
      const item = div('home3-document-item');
      if (activeKey && normalizePath(path) === activeKey) item.classList.add('is-active');
      item.innerHTML = `
        <span>${activeKey && normalizePath(path) === activeKey ? '활성' : '열림'}</span>
        <strong title="${escapeHtml(getDocumentName(doc) || '이름 없음')}">${escapeHtml(getDocumentName(doc) || '이름 없음')}</strong>`;
      docList.append(item);
    });
    if (docs.length > 5) {
      const more = div('home3-document-more');
      more.textContent = `+${docs.length - 5}`;
      docList.append(more);
    }
  }
  body.append(docList);
  host.append(body);
}

function renderLaunch(host) {
  clear(host);
  const counts = getFeatureCounts3();
  const favoriteCount = getFavoriteEntries().length;
  host.append(buildPanelHead('Workspace', '바로 실행', '7개 메뉴'));

  const body = div('shell3-panel-body home3-action-grid');
  [
    {
      icon: 'B',
      title: 'BQC 검토',
      meta: `검토 기능 ${counts.bqc}개`,
      route: 'bqc'
    },
    {
      icon: 'E',
      title: 'BQC 결과 정리',
      meta: `엑셀 · RVT 정리 ${counts['bqc-results']}개`,
      route: 'bqc-results'
    },
    {
      icon: 'G',
      title: '일반 도구',
      meta: `반복 작업 ${counts.utility}개`,
      route: 'utility'
    },
    {
      icon: 'L',
      title: '링크 도구',
      meta: `링크 관리 ${counts.linktools}개`,
      route: 'linktools'
    },
    {
      icon: 'M',
      title: '모델링',
      meta: `자동 모델링 ${counts.modeling}개`,
      route: 'modeling'
    },
    {
      icon: 'S',
      title: 'Schedule 도구',
      meta: 'Excel Import / Export',
      route: 'scheduleio'
    },
    {
      icon: 'F',
      title: '즐겨찾기',
      meta: `${favoriteCount}개 등록`,
      route: 'favorites'
    }
  ].forEach((item) => body.append(buildActionCard(item)));
  host.append(body);
}

function buildActionCard(item) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'home3-action-card';
  button.dataset.homeRoute = item.route;
  button.innerHTML = `
    <span class="home3-action-icon" aria-hidden="true">${escapeHtml(item.icon)}</span>
    <span class="home3-action-copy">
      <strong>${escapeHtml(item.title)}</strong>
      <em>${escapeHtml(item.meta)}</em>
    </span>
    <span class="home3-action-arrow" aria-hidden="true">›</span>`;
  button.addEventListener('click', () => {
    location.hash = `#${item.route}`;
  });
  return button;
}

function renderRecent(host) {
  clear(host);
  const quick = getHubQuickAccessEntries(5);
  const favorites = getFavoriteEntries(5);
  const entries = quick.length ? quick : favorites;
  const favoritesButton = createButton('즐겨찾기 관리', 'ghost');
  favoritesButton.dataset.homeRoute = 'favorites';
  favoritesButton.addEventListener('click', () => { location.hash = '#favorites'; });
  host.append(buildPanelHead('Recent', '최근 작업', entries.length ? `${entries.length}개` : '없음', [favoritesButton]));

  const body = div('shell3-panel-body home3-recent-list');
  if (!entries.length) {
    const empty = div('home3-compact-empty');
    empty.innerHTML = '<strong>최근 작업 없음</strong><span>실행한 기능과 즐겨찾기가 여기에 정리됩니다.</span>';
    body.append(empty);
  } else {
    entries.slice(0, 5).forEach((entry) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'home3-recent-item';
      button.dataset.homeEntry = entry.id;
      const usage = entry.lastUsedAt
        ? formatRelativeTime(entry.lastUsedAt)
        : (entry.favorite ? '즐겨찾기' : `${Math.max(0, Number(entry.count) || 0)}회 실행`);
      button.innerHTML = `
        <span class="home3-recent-group">${escapeHtml(entry.groupLabel || '기능')}</span>
        <strong>${escapeHtml(entry.label || '이름 없음')}</strong>
        <em>${escapeHtml(usage)}</em>`;
      button.addEventListener('click', () => openHubEntry(entry.id));
      body.append(button);
    });
  }
  host.append(body);
}

function renderUpdate(host) {
  clear(host);
  const update = getTopbarState().update || {};
  const current = formatVersion(update.currentVersionDisplay || update.currentVersion || PRODUCT_VERSION_DISPLAY);
  const latest = update.latestVersion ? formatVersion(update.latestVersion) : current;
  const hasUpdate = !!update.hasUpdate;
  const busy = !!update.busy;
  const failed = !busy && String(update.kind || '').toLowerCase() === 'err';
  const badge = busy ? '확인 중' : (failed ? '확인 필요' : (hasUpdate ? '업데이트 필요' : '최신 상태'));

  host.append(buildPanelHead('Update', '버전 업데이트', badge, [], (hasUpdate || failed) ? 'warn' : 'ok'));
  const body = div('shell3-panel-body home3-update-body');
  const versions = div('home3-version-grid');
  versions.innerHTML = `
    <div><span>현재</span><strong>${escapeHtml(current)}</strong></div>
    <div><span>최신</span><strong>${escapeHtml(latest || (hasUpdate ? '확인 필요' : current))}</strong></div>`;

  const summary = div('home3-update-summary');
  const updateCopy = getUpdateCopy({ busy, failed, hasUpdate, latest });
  summary.innerHTML = `
    <strong>${escapeHtml(updateCopy.title)}</strong>
    <span>${escapeHtml(updateCopy.detail)}</span>`;

  const actions = div('shell3-button-row home3-panel-actions');
  const checkButton = createButton(busy ? '확인 중' : '업데이트 확인', 'primary');
  checkButton.disabled = busy;
  checkButton.dataset.homeAction = 'update-check';
  checkButton.addEventListener('click', () => {
    try { post('update:check', { source: 'home' }); } catch { }
  });
  const releaseButton = createButton('배포 페이지', 'ghost');
  releaseButton.dataset.homeExternal = 'release';
  releaseButton.addEventListener('click', () => openExternal('/index.html#download', 'home-release'));
  actions.append(checkButton, releaseButton);
  body.append(versions, summary, actions);
  host.append(body);
}

function renderHelp(host) {
  clear(host);
  host.append(buildPanelHead('Help', '도움말', '온라인'));
  const body = div('shell3-panel-body home3-link-list');
  [
    { icon: '?', label: '전체 매뉴얼', meta: '업무 흐름과 기본 사용법', path: '/Manual/index.html', source: 'home-manual' },
    { icon: 'F', label: '기능별 가이드', meta: '기능 설정과 결과 확인', path: '/Manual/features.html', source: 'home-features' },
    { icon: '+', label: '개선 요청', meta: '불편 사항과 기능 제안', path: '/requests.html', source: 'home-request' }
  ].forEach((item) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'home3-link-item';
    button.dataset.homeExternal = item.source;
    button.innerHTML = `
      <span class="home3-link-icon" aria-hidden="true">${escapeHtml(item.icon)}</span>
      <span><strong>${escapeHtml(item.label)}</strong><em>${escapeHtml(item.meta)}</em></span>
      <span class="home3-action-arrow" aria-hidden="true">›</span>`;
    button.addEventListener('click', () => openExternal(item.path, item.source));
    body.append(button);
  });
  host.append(body);
}

function renderAgenda(host, state) {
  clear(host);
  const todayKey = toDateKey(new Date());
  const entries = normalizeScheduleEntries(state.entries || loadScheduleEntries())
    .filter((entry) => !isPastScheduleEntry(entry, todayKey))
    .sort((a, b) => String(a.startDate).localeCompare(String(b.startDate)) || Number(a.createdAt || 0) - Number(b.createdAt || 0));

  host.append(buildPanelHead('Schedule', '가까운 일정', entries.length ? `${entries.length}건` : '없음'));
  const body = div('shell3-panel-body home3-agenda-body');
  const list = div('home3-agenda-list');
  if (!entries.length) {
    const empty = div('home3-compact-empty');
    empty.innerHTML = '<strong>예정된 일정 없음</strong><span>일정 보드에서 납품 일정을 등록할 수 있습니다.</span>';
    list.append(empty);
  } else {
    entries.slice(0, 3).forEach((entry) => {
      const row = div('home3-agenda-item');
      const checklist = Number(entry.checklistTotal || 0) > 0
        ? `체크 ${Number(entry.checklistDone || 0)}/${Number(entry.checklistTotal || 0)}`
        : '';
      row.classList.toggle('is-current', todayKey >= entry.startDate && todayKey <= entry.endDate);
      row.innerHTML = `
        <span>${escapeHtml(formatScheduleRange(entry))}</span>
        <strong>${escapeHtml(entry.title || '납품 일정')}</strong>
        <em>${escapeHtml(checklist)}</em>`;
      list.append(row);
    });
  }

  const actions = div('shell3-button-row home3-panel-actions');
  const boardButton = createButton('일정 보드', 'primary');
  boardButton.dataset.homeAction = 'schedule-board';
  boardButton.addEventListener('click', () => {
    try { post('scheduleboard:open'); } catch { }
  });
  const widgetButton = createButton('위젯 열기', 'ghost');
  widgetButton.dataset.homeAction = 'schedule-widget';
  widgetButton.addEventListener('click', () => {
    try { post('scheduleboard:open-widget'); } catch { }
  });
  actions.append(boardButton, widgetButton);
  body.append(list, actions);
  host.append(body);
}

function buildPanelHead(kicker, title, badgeText = '', actions = [], tone = '') {
  const head = div('shell3-panel-head home3-panel-head');
  head.innerHTML = `
    <div>
      <span class="shell3-kicker">${escapeHtml(kicker)}</span>
      <h2>${escapeHtml(title)}</h2>
    </div>`;
  const controls = div('home3-panel-head-actions');
  if (badgeText) {
    const badge = document.createElement('span');
    badge.className = `shell3-tag${tone ? ` shell3-tag--${tone}` : ''}`;
    badge.textContent = badgeText;
    controls.append(badge);
  }
  actions.filter(Boolean).forEach((action) => controls.append(action));
  if (controls.childElementCount) head.append(controls);
  return head;
}

function createButton(label, variant = 'ghost') {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = `shell3-btn shell3-btn--${variant}`;
  button.textContent = label;
  return button;
}

function openExternal(path, source) {
  const url = getWebsiteUrl(path);
  try { post('ui:open-external', { url, source }); } catch { }
}

function getUpdateCopy({ busy, failed, hasUpdate, latest }) {
  if (busy) {
    return { title: '업데이트 확인 중', detail: '잠시만 기다려 주세요.' };
  }
  if (failed) {
    return { title: '업데이트를 확인하지 못했습니다', detail: '업데이트 확인을 다시 눌러 주세요.' };
  }
  if (hasUpdate) {
    return { title: '새 업데이트가 있습니다', detail: `${latest} 버전을 사용할 수 있습니다.` };
  }
  return { title: '최신 버전입니다', detail: '현재 버전을 그대로 사용하면 됩니다.' };
}

function formatRelativeTime(timestamp) {
  const value = Number(timestamp || 0);
  if (!value) return '최근 사용';
  const diffMinutes = Math.max(0, Math.floor((Date.now() - value) / 60000));
  if (diffMinutes < 1) return '방금 전';
  if (diffMinutes < 60) return `${diffMinutes}분 전`;
  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}시간 전`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 30) return `${diffDays}일 전`;
  return '최근 사용';
}

function getDocumentName(doc = {}) {
  return String(doc.name || doc.Name || doc.title || doc.Title || '').trim();
}

function getDocumentPath(doc = {}) {
  return String(doc.path || doc.Path || doc.filePath || doc.FilePath || '').trim();
}

function normalizePath(value) {
  return String(value || '').replace(/\//g, '\\').trim().toLowerCase();
}

function formatVersion(value) {
  const text = String(value || '').trim();
  if (!text) return 'v3.1.6';
  return /^v/i.test(text) ? text : `v${text}`;
}

function loadScheduleEntries() {
  try {
    const parsed = JSON.parse(localStorage.getItem(HOME_SCHEDULE_KEY) || '[]');
    if (!Array.isArray(parsed)) return [];
    return normalizeScheduleEntries(parsed);
  } catch {
    return [];
  }
}

function normalizeScheduleEntries(entries) {
  if (!Array.isArray(entries)) return [];
  return entries
    .map((entry) => {
      const date = String(entry.date || entry.Date || entry.startDate || entry.StartDate || '').slice(0, 10);
      const endDate = String(entry.endDate || entry.EndDate || date || '').slice(0, 10);
      return {
        id: String(entry.id || entry.Id || `schedule-${date}-${entry.title || entry.Title || ''}`),
        startDate: date,
        endDate: endDate || date,
        title: String(entry.title || entry.Title || '').trim(),
        memo: String(entry.memo || entry.Memo || '').trim(),
        checklistTotal: Number(entry.checklistTotal || entry.ChecklistTotal || 0),
        checklistDone: Number(entry.checklistDone || entry.ChecklistDone || 0),
        createdAt: Number(entry.createdAt || entry.CreatedAt || 0)
      };
    })
    .filter((entry) => /^\d{4}-\d{2}-\d{2}$/.test(entry.startDate) && entry.title)
    .map((entry) => ({
      ...entry,
      endDate: /^\d{4}-\d{2}-\d{2}$/.test(entry.endDate) && entry.endDate >= entry.startDate
        ? entry.endDate
        : entry.startDate
    }));
}

function isPastScheduleEntry(entry, todayKey = toDateKey(new Date())) {
  const endDate = String(entry?.endDate || entry?.startDate || '');
  return /^\d{4}-\d{2}-\d{2}$/.test(endDate) && endDate < todayKey;
}

function toDateKey(date) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

function parseDateKey(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ''));
  if (!match) return null;
  return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
}

function formatScheduleDate(value) {
  const date = parseDateKey(value);
  if (!date) return value || '-';
  return `${pad2(date.getMonth() + 1)}/${pad2(date.getDate())}`;
}

function formatScheduleRange(entry) {
  const start = formatScheduleDate(entry.startDate);
  const end = formatScheduleDate(entry.endDate || entry.startDate);
  return start === end ? start : `${start}~${end}`;
}

function pad2(value) {
  return String(value).padStart(2, '0');
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
