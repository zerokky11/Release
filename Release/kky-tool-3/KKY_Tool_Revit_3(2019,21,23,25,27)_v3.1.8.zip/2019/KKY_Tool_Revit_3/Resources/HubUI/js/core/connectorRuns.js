// Registration controls keep existing input nodes alive while their values change.
export function createConnectorRunEditor({ getDraft, getParameters, onChange }) {
  const root = document.createElement('section');
  root.className = 'connector-runs feature-row__summary';
  root.style.cssText = 'display:grid;gap:10px;padding:14px;min-width:0';
  const title = document.createElement('strong');
  title.textContent = '연속성 검토 여러 개 등록';
  const help = document.createElement('p');
  help.textContent = '선택한 파라미터를 각각 등록하면 한 번에 순서대로 검토합니다. 엑셀 파일명에는 파라미터와 등록 번호가 표시됩니다. 등록 시 옵션이 저장되며, 아래에서 항목별로 변경할 수 있습니다.';
  help.style.cssText = 'margin:0;color:var(--muted);line-height:1.6';
  const add = document.createElement('button');
  add.type = 'button'; add.className = 'btn'; add.textContent = '선택한 파라미터를 각각 등록';
  const list = document.createElement('div');
  list.style.cssText = 'display:grid;gap:10px';
  const empty = document.createElement('span');
  empty.textContent = '등록한 항목이 없으면 위 설정으로 한 번 검토합니다.';
  const rows = () => { const d = getDraft(); if (!Array.isArray(d.runs)) d.runs = []; return d.runs; };
  const changed = () => { empty.hidden = rows().length > 0; onChange(); };
  function renderRow(run) {
    // Shared settings may replace the draft object after an auto-apply while the
    // focused DOM node stays alive. Resolve by stable ID on every edit.
    const update = (key, value) => {
      const current = rows().find(item => item.id === run.id);
      if (!current) return;
      current[key] = value;
      if (key === 'param') current.paramItems = [value];
      changed();
    };
    const row = document.createElement('div'); row.dataset.runId = run.id;
    row.style.cssText = 'display:flex;flex-wrap:wrap;align-items:end;gap:10px;padding:12px;border:1px solid var(--border-soft,#b8c1cf);border-radius:10px';
    const field = (label, key, type = 'text') => {
      const wrap = document.createElement('label'); wrap.style.cssText = 'display:grid;gap:5px;min-width:0';
      const caption = document.createElement('span'); caption.textContent = label;
      const input = document.createElement('input'); input.type = type; input.value = run[key] ?? '';
      input.setAttribute('aria-label', label); input.dataset.focusKey = `connector-run-${run.id}-${key}`;
      input.style.cssText = `width:${type === 'number' ? '95px' : '220px'};max-width:100%;box-sizing:border-box;padding:7px;background:var(--panel,#fff);color:var(--text,#17243b);border:1px solid var(--border-soft,#b8c1cf);border-radius:5px`;
      if (type === 'number') { input.min = '0'; input.step = '0.01'; }
      input.addEventListener('input', () => update(key, type === 'number' ? (input.value === '' ? null : Number(input.value)) : input.value));
      wrap.append(caption, input); row.append(wrap);
    };
    field('검토 파라미터', 'param'); field('허용 범위', 'tol', 'number');
    const unit = document.createElement('select'); unit.setAttribute('aria-label','단위');
    for (const value of ['inch','mm']) { const opt = new Option(value,value); unit.add(opt); }
    unit.value = run.unit || 'inch'; unit.addEventListener('change', () => update('unit', unit.value)); row.append(unit);
    const check = (label, key) => {
      const wrap = document.createElement('label'); wrap.style.cssText = 'display:flex;gap:6px;align-items:center';
      const input = document.createElement('input'); input.type = 'checkbox'; input.checked = !!run[key];
      input.dataset.focusKey = `connector-run-${run.id}-${key}`;
      input.addEventListener('change', () => update(key, input.checked));
      wrap.append(input, document.createTextNode(label)); row.append(wrap);
    };
    check('한쪽이라도 값이 비어 있으면 결과에서 제외', 'excludeBlankValues');
    check('파라미터 값이 일치하면 결과에서 제외', 'excludeMatchValues');
    const extra = document.createElement('details'); const summary = document.createElement('summary'); summary.textContent = '추가 추출·제외 옵션'; extra.append(summary);
    row.append(extra);
    for (const [label,key] of [['End + Dummy 패밀리 제외','excludeEndDummy'],['좌표 X/Y 추출','includePointXY'],['선형 길이 / 방향 벡터 추출','includeLinearMetrics']]) {
      check(label,key); extra.append(row.lastChild);
    }
    const mapping = document.createElement('small'); mapping.textContent = `등록 시 값 매핑 ${(run.valueMappings || []).length}개 적용`; extra.append(mapping);
    const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'btn'; remove.textContent = '삭제';
    remove.addEventListener('click', () => { getDraft().runs = rows().filter(r => r.id !== run.id); row.remove(); changed(); add.focus({preventScroll:true}); }); row.append(remove);
    list.append(row);
  }
  add.addEventListener('click', () => {
    for (const param of getParameters()) {
      const { runs, ...options } = getDraft();
      const run = JSON.parse(JSON.stringify(options));
      run.id = globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      run.param = param; run.paramItems = [param];
      rows().push(run); renderRow(run);
    }
    changed();
  });
  // Called only when the settings draft is replaced, never from input or host echoes.
  function sync() { list.replaceChildren(); rows().forEach(renderRow); empty.hidden = rows().length > 0; }
  root.append(title, help, add, empty, list); sync();
  return { root, sync };
}

export function connectorRunsError(config) {
  for (const [index, run] of (config?.runs || []).entries()) {
    if (!String(run.param || '').trim()) return `연속성 검토 ${index + 1}번의 파라미터를 입력하세요.`;
    if (run.tol === null || !Number.isFinite(Number(run.tol)) || Number(run.tol) < 0) return `연속성 검토 ${index + 1}번의 허용 범위를 확인하세요.`;
  }
  return '';
}
