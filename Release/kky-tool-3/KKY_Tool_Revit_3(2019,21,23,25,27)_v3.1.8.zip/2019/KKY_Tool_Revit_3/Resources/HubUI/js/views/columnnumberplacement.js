import { onHost, post } from '../core/bridge.js';

export const COLUMN_NUMBER_EVENTS = Object.freeze({ init: 'columnnumber:init', context: 'columnnumber:context', scan: 'columnnumber:scan', preview: 'columnnumber:preview', apply: 'columnnumber:apply', result: 'columnnumber:result', review: 'columnnumber:review', reviewResult: 'columnnumber:review-result', structureInit: 'columnnumber:structure-init', structureContext: 'columnnumber:structure-context', structureScan: 'columnnumber:structure-scan', structurePreview: 'columnnumber:structure-preview', structureApply: 'columnnumber:structure-apply', structureResult: 'columnnumber:structure-result', error: 'columnnumber:error' });
let serial = 0;
let activeCleanup = null;
const str = value => String(value == null ? '' : value);
const numeric = value => str(value).trim() === '' ? NaN : Number(value);
const format = value => Number.isFinite(Number(value)) && value != null ? Number(value).toLocaleString('ko-KR', { maximumFractionDigits: 2 }) : '—';
const isAccepted = row => str(row.status).toLowerCase() === 'accepted';
const statusLabel = status => ({ accepted: '배치 가능', rejected: '확인 필요', existing: '기존 배치', created: '배치 완료', skipped: '건너뜀', failed: '실패', match: '일치', missing: '넘버 누락', mismatch: '번호 불일치', 'type-mismatch': '타입 불일치', 'dimension-mismatch': '치수 불일치', 'source-mismatch': '원본 값 불일치', 'source-error': '원본 값 오류', duplicate: '중복 배치', unmatched: '연결 기둥 없음', error: '검토 오류', 'position-mismatch': '위치 불일치', ambiguous: '연결 불명확', unavailable: '대조 불가' })[str(status).toLowerCase()] || str(status);
const sourceStatusLabel = status => ({ match: '원본 값 일치', mismatch: '원본 값 불일치', error: '원본 값 오류', unavailable: '대조 불가' })[str(status).toLowerCase()] || str(status || '대조 불가');
const TYPE_BUCKETS = Object.freeze({ mainSmallSymbolId: 'main-small', mainMediumSymbolId: 'main-medium', mainLargeSymbolId: 'main-large', studSmallSymbolId: 'stud-small' });
const isFourWay = symbol => /^4(?:\s*way)?$/i.test(str(symbol.way).trim());
const kindLabel = kind => ({ main: '주기둥', stud: '샛기둥', 'stud-horizontal': '샛기둥 · 가로', 'stud-vertical': '샛기둥 · 세로', 'stud-interior': '샛기둥 · 내부' })[str(kind).toLowerCase()] || str(kind);
const WRITE_NUMBERS_KEY = 'kky.columnnumber.writeNumbers.v1';
const readWriteNumbers = () => { try { return localStorage.getItem(WRITE_NUMBERS_KEY) !== 'false'; } catch { return true; } };
const FILL_MISSING_NUMBERS_KEY = 'kky.columnnumber.fillMissingNumbersByRule.v1';
const readFillMissingNumbers = () => { try { return localStorage.getItem(FILL_MISSING_NUMBERS_KEY) === 'true'; } catch { return false; } };
const numberingSourceLabel = row => row.useFamilyDefaultColumn === true ? '원본 없음 · 패밀리 기본값' : ({ 'source-parameter': '원본 번호 복사', 'grid-rule-missing': '원본 없음 · 규칙 번호 부여' })[str(row.numberingMode)] || '';
const cleanDocumentText = value => str(value).trim().replace(/^(["'])([\s\S]*)\1$/, '$2').trim();
function normalizeDocument(raw) {
  if (!raw || raw.isLinked === true || raw.IsLinked === true) return null;
  const name = cleanDocumentText(raw.name || raw.Name || raw.title || raw.Title);
  const title = cleanDocumentText(raw.title || raw.Title || name);
  const path = cleanDocumentText(raw.path || raw.Path || raw.filePath).replace(/\//g, '\\');
  return name || path ? { ...raw, name, title, path } : null;
}
function sameDocument(left, right) {
  const a = normalizeDocument(left), b = normalizeDocument(right);
  if (!a || !b) return a === b;
  // Unsaved Revit documents use their title as the host's path fallback.
  // Saved documents are identified by their path even when titles differ.
  const pathKey = doc => { const path = doc.path.toLowerCase(); return path === doc.name.toLowerCase() || path === doc.title.toLowerCase() ? '' : path; };
  const aPath = pathKey(a), bPath = pathKey(b);
  return aPath || bPath ? !!aPath && aPath === bPath : a.name.toLowerCase() === b.name.toLowerCase();
}

// Editors are mounted once. Input/IME and host responses update only summaries,
// option lists that actually changed, or results; never the settings subtree.
export function renderColumnNumberPlacement(root, options = {}) {
  activeCleanup?.();
  const page = document.createElement('div');
  page.className = 'columnnumber-page feature-shell';
  page.innerHTML = `
    <header class="feature-header"><div class="feature-heading"><span class="feature-kicker">모델링 · 링크 기둥</span><h2 class="feature-title">기둥 넘버</h2><p class="feature-sub">링크 기둥의 넘버를 배치하거나 기존 배치의 누락과 번호를 검토합니다.</p></div></header>
    <main class="columnnumber-workspace" data-columnnumber-scroll-key="workspace">
      <div class="columnnumber-tabs" role="tablist" aria-label="기둥 넘버 작업"><button type="button" role="tab" id="columnnumber-tab-placement" data-ref="placementTab" aria-selected="true" aria-controls="columnnumber-placement-panel">기둥 넘버 배치하기</button><button type="button" role="tab" id="columnnumber-tab-review" data-ref="reviewTab" aria-selected="false" aria-controls="columnnumber-review-panel" tabindex="-1">기둥 넘버 검토</button><button type="button" role="tab" id="columnnumber-tab-structure" data-ref="structureTab" aria-selected="false" aria-controls="columnnumber-structure-panel" tabindex="-1">구조 모델 검토</button></div>
      <section class="columnnumber-card columnnumber-settings" data-ref="linkSettings">
        <div class="columnnumber-head"><h3>01 · 작업 대상</h3><button class="btn" type="button" data-ref="refresh" data-direct-kind="secondary">프로젝트 새로고침</button></div>
        <p class="columnnumber-document" data-ref="document">활성 문서를 확인하고 있습니다.</p>
        <div class="columnnumber-fields">
          <label class="columnnumber-wide">구조 링크<select data-setting="linkElementId" data-columnnumber-focus-key="link"><option value="">프로젝트 정보를 불러오세요.</option></select></label>
          <label class="columnnumber-wide">기둥넘버 패밀리<select data-setting="familyElementId" data-columnnumber-focus-key="family"><option value="">프로젝트 정보를 불러오세요.</option></select></label>
          <label>기준 레벨 · 복수 선택<select multiple size="4" data-setting="baseLevelElementId" data-columnnumber-focus-key="level" aria-describedby="columnnumber-level-note"><option value="">프로젝트 정보를 불러오세요.</option></select></label>
          <label>레벨에서 높이 (mm)<input type="text" inputmode="decimal" autocomplete="off" value="1500" data-setting="offsetMillimeters" data-columnnumber-focus-key="offset"></label>
        </div>
        <p class="columnnumber-note" id="columnnumber-level-note">선택한 각 레벨에 입력한 높이를 더한 위치에 배치합니다. 아래층에서 시작한 기둥도 해당 높이를 관통하면 포함합니다. 해당 높이에 없는 기둥은 결과 목록에 표시하지 않습니다.</p>
        <p class="columnnumber-note">구조 기둥(Structural Columns)과 일반 기둥(Columns)의 최상위 수직 기둥을 찾습니다. 중첩된 하위 기둥과 패밀리 이름에 ", shared"가 포함된 기둥은 제외합니다. 기둥넘버는 호스트가 없는 레벨 기반 패밀리를 지원합니다.</p>
        <div class="columnnumber-dimensions" data-ref="dimensionsNote"><strong>기둥 크기 자동 반영</strong><span>원본 타입명의 쉼표로 구분된 두 번째 항목에서 가로×세로(mm)를 읽어 Column_Width 1·2에 각각 입력합니다. 예: 기둥명, 설명 400 x 800, 스펙 → 400 / 800 mm. 중간 크기 타입을 선택하며, 3D 형상의 돌출부 크기는 적용하지 않습니다.</span></div>
      </section>
      <section class="columnnumber-card" data-ref="numberSettings">
        <h3>02 · 번호 기준</h3>
        <label class="columnnumber-checkbox"><input type="checkbox" checked data-setting="writeNumbers" data-columnnumber-focus-key="write-numbers"><span>기둥·샛기둥 Number 입력</span></label>
        <p class="columnnumber-note" data-ref="writeNumbersNote">체크를 해제하면 패밀리의 기본 번호를 유지합니다. 문자 형상 오류를 방지하기 위해 빈 기본값만 -로 보정합니다. 기둥 가로·세로 치수는 항상 입력합니다.</p>
        <div data-ref="fillMissingNumbersOption"><label class="columnnumber-checkbox"><input type="checkbox" data-setting="fillMissingNumbersByRule" data-columnnumber-focus-key="fill-missing-numbers"><span>원본 번호가 없으면 위치·그리드 규칙으로 채우기</span></label><p class="columnnumber-note" data-ref="fillMissingNumbersNote">원본 번호가 있으면 그대로 복사하고, 값이 없는 기둥만 위치·그리드 규칙으로 번호를 부여합니다. 잘못된 형식의 원본 값은 덮어쓰지 않습니다.</p></div>
        <div class="columnnumber-fields">
          <label>원본 기둥 전체 번호 파라미터<input type="text" autocomplete="off" placeholder="예: 부재번호" required data-setting="sourceParameterName" data-columnnumber-focus-key="source"></label>
          <label>원본 파라미터 위치<select data-setting="sourceParameterScope" data-columnnumber-focus-key="scope"><option value="instance">인스턴스</option><option value="type">타입</option></select></label>
          <label class="columnnumber-wide">원본 번호 구분자<select data-setting="sourceNumberSeparator" data-columnnumber-focus-key="source-separator"><option value="_">밑줄 (_) · 예: G26_D-2</option><option value="-">하이픈 (-) · 예: G26-D-2</option></select></label>
          <label>넘버 패밀리의 기둥번호<input type="text" readonly value="Column Number" aria-label="고정 기둥번호 파라미터 Column Number"></label>
          <label>넘버 패밀리의 샛기둥번호<input type="text" readonly value="Stud Number" aria-label="고정 샛기둥번호 파라미터 Stud Number"></label>
          <label>그리드 판정 허용 오차 (mm)<input type="text" inputmode="decimal" autocomplete="off" value="10" data-setting="gridToleranceMillimeters" data-columnnumber-focus-key="grid-tolerance"></label>
          <label>번호 기준 방향 (°)<input type="text" inputmode="decimal" autocomplete="off" value="0" data-setting="gridAxisAngleDegrees" data-columnnumber-focus-key="grid-angle"></label>
          <label class="columnnumber-wide">그리드 내부 샛기둥 번호 · 검토·빈 번호 기준<select data-setting="interiorMode" data-columnnumber-focus-key="interior-mode"><option value="auto">자동 · 경계 우선, 맞지 않으면 내부 순번</option><option value="boundary">경계 샛기둥의 행·열 연결</option><option value="rank">내부 행·열 순번</option></select></label>
        </div>
        <p class="columnnumber-note" data-ref="parameterNote">각 기둥의 원본 번호를 분리합니다. 원본 값이 없으면 Column Number는 패밀리 기본값을 유지하고, Stud Number는 -를 입력합니다. 주기둥의 Stud Number도 -를 사용합니다.</p>
        <p class="columnnumber-note">번호 기준 방향은 도면의 오른쪽 방향입니다. 현재 평면 뷰의 방향을 기본값으로 사용하며, 평면 뷰가 아니면 0°부터 설정합니다.</p>
        <details class="columnnumber-rules"><summary>그리드 번호 규칙 · 검토 및 빈 번호 채우기</summary><ul><li>배치는 각 원본 기둥의 지정한 파라미터 값을 우선 사용합니다. 빈 번호 채우기 옵션을 켜면 값이 없는 기둥에만 위치·그리드 규칙을 적용합니다.</li><li>가로 샛기둥은 왼쪽부터 1, 2…, 세로 샛기둥은 아래부터 A, B…로 계산합니다.</li><li>내부 샛기둥은 왼쪽 아래 Main 번호와 행·열을 조합합니다. 예: G26 / D-2.</li></ul><p data-ref="interiorNote"></p></details>
      </section>
      <section class="columnnumber-card" data-ref="typeSettings">
        <h3>03 · 기둥 크기별 표지판 타입</h3>
        <p class="columnnumber-note">가로·세로 중 큰 변을 기준으로 구분합니다. 배치는 4Way 타입을 사용하며, 한 구간에 후보가 여러 개이면 직접 선택하세요.</p>
        <div class="columnnumber-fields">
          <label>Main · 500 mm 미만 · 250 × 150<select data-setting="mainSmallSymbolId" data-columnnumber-focus-key="main-small"></select></label>
          <label>Main · 500 이상~1,200 mm 미만 · 450 × 250<select data-setting="mainMediumSymbolId" data-columnnumber-focus-key="main-medium"></select></label>
          <label>Main · 1,200 mm 이상 · 600 × 400<select data-setting="mainLargeSymbolId" data-columnnumber-focus-key="main-large"></select></label>
          <label>Stud · 250 × 150 + 150 × 100<select data-setting="studSmallSymbolId" data-columnnumber-focus-key="stud-small"></select></label>
        </div>
        <p class="columnnumber-note" data-ref="typeNote">패밀리를 선택하면 적용 가능한 타입을 표시합니다. 사용하지 않는 크기 구간은 비워 둘 수 있습니다.</p>
      </section>
      <section class="columnnumber-card columnnumber-preview" data-ref="placementPanel" id="columnnumber-placement-panel" role="tabpanel" aria-labelledby="columnnumber-tab-placement">
        <div class="columnnumber-head"><h3>04 · 배치할 기둥 검토</h3><span data-ref="counts" class="columnnumber-note">검출 전</span></div>
        <p class="columnnumber-note" data-ref="previewNote">기둥 검출 후 배치할 항목을 선택하세요. 가로·세로는 원본 타입명의 두 번째 항목에서 읽은 치수입니다. 치수를 읽을 수 없는 항목은 사유를 확인하세요.</p>
        <p class="columnnumber-note">같은 레벨과 위치(1mm 이내)의 원본 기둥은 한 위치로 묶어 넘버를 하나만 배치합니다. 치수·방향·입력할 번호가 다르면 사유를 확인하세요. 해당 위치에 넘버가 이미 있으면 다시 생성하지 않습니다.</p>
        <div class="columnnumber-table-wrap" data-ref="previewScroll" data-columnnumber-scroll-key="preview"><table class="columnnumber-table"><thead><tr><th class="columnnumber-check"><input type="checkbox" data-ref="selectAll" aria-label="배치 가능한 기둥 전체 선택" data-columnnumber-focus-key="select-all"></th><th>원본 기둥 / 구분</th><th>Column Number</th><th>Stud Number</th><th>적용 타입</th><th>가로 × 세로 (mm)</th><th>회전 (°)</th><th>상태 / 사유</th></tr></thead><tbody data-ref="rows"><tr><td colspan="8" class="columnnumber-empty">검출한 기둥이 없습니다.</td></tr></tbody></table></div>
        <div class="columnnumber-paging"><button class="btn" type="button" data-ref="previous">이전</button><span data-ref="pageLabel">1 / 1</span><button class="btn" type="button" data-ref="next">다음</button></div>
      </section>
      <section class="columnnumber-card columnnumber-review" data-ref="reviewPanel" id="columnnumber-review-panel" role="tabpanel" aria-labelledby="columnnumber-tab-review" hidden>
        <div class="columnnumber-head"><h3>04 · 기둥 넘버 검토</h3><span class="columnnumber-note" data-ref="reviewCounts">검토 전</span></div>
        <div class="columnnumber-fields">
          <label>중심 위치 허용 오차 (mm)<input type="text" inputmode="decimal" autocomplete="off" value="10" data-setting="positionToleranceMillimeters" data-columnnumber-focus-key="tolerance"></label>
          <label>각 기둥의 원본 전체 번호 파라미터<input type="text" autocomplete="off" placeholder="비우면 위의 원본 파라미터 사용" data-setting="sourceCombinedParameterName" data-columnnumber-focus-key="combined-source"></label>
          <label>원본 전체 번호 파라미터 위치<select data-setting="sourceCombinedParameterScope" data-columnnumber-focus-key="combined-scope"><option value="">위의 원본 설정과 같음</option><option value="instance">인스턴스</option><option value="type">타입</option></select></label>
        </div>
        <div class="columnnumber-review-criteria"><div><strong>규칙 검토</strong><span>그리드에서 계산한 번호, 크기별 타입, 배치 위치와 Column_Width 1·2 치수를 확인합니다. 치수 허용 오차는 0.1 mm입니다.</span></div><div><strong>원본 값 대조</strong><span>각 링크 기둥의 전체 번호를 분리해 배치한 넘버와 직접 비교합니다. 예: G26_D-2 → Column G26 / Stud D-2. 규칙 검토와 결과를 별도로 표시합니다.</span></div></div>
        <p class="columnnumber-note">기존 연결 정보를 우선 사용하고, 수동 배치한 넘버는 기둥 중심과 배치 높이로 연결합니다. 여러 객체가 겹치면 중복 또는 연결 불명확으로 표시합니다.</p>
        <p class="columnnumber-note" data-ref="reviewNote">검토를 실행하면 넘버 누락과 번호 일치 여부를 확인할 수 있습니다. 모델은 변경하지 않습니다.</p>
        <p class="columnnumber-note">검토는 선택한 패밀리의 모든 방향 타입을 포함합니다. 4Way를 다른 방향 타입으로 바꾼 것만으로는 오류로 판단하지 않습니다.</p>
        <div class="columnnumber-table-wrap" data-columnnumber-scroll-key="review"><table class="columnnumber-table"><thead><tr><th>원본 / 넘버 ID</th><th>규칙 번호 / 실제 번호</th><th>예상 / 실제 타입</th><th>규칙 검토</th><th>원본 값 대조</th></tr></thead><tbody data-ref="reviewRows"><tr><td colspan="5" class="columnnumber-empty">검토 결과가 없습니다.</td></tr></tbody></table></div>
      </section>
      <section class="columnnumber-card" data-ref="results" hidden><div class="columnnumber-head"><h3>처리 결과</h3><span data-ref="resultSummary" class="columnnumber-note"></span></div><div class="columnnumber-result-list" data-ref="resultRows" data-columnnumber-scroll-key="results"></div></section>
    </main>
    <aside class="columnnumber-run-panel" data-columnnumber-scroll-key="run">
      <section class="columnnumber-card columnnumber-run" data-ref="linkRun"><h3 data-ref="runTitle">검출 및 배치</h3><p class="columnnumber-note" data-ref="selectionSummary">배치 설정을 확인하세요.</p><div class="columnnumber-actions"><button class="btn" type="button" data-ref="scan" data-direct-kind="secondary">기둥 검출</button><button class="btn" type="button" data-ref="apply" data-direct-kind="primary">선택한 기둥에 배치</button><button class="btn" type="button" data-ref="review" data-direct-kind="primary" hidden>기둥 넘버 검토</button></div><p class="columnnumber-note" data-ref="runNote">같은 링크 기둥·레벨에 이미 배치한 기둥넘버는 건너뜁니다.</p><p class="columnnumber-validation" role="status" data-ref="validation"></p><p class="columnnumber-feedback" aria-live="polite" role="status" data-ref="feedback">프로젝트 정보를 불러오는 중입니다.</p></section>
      <p class="columnnumber-note columnnumber-save" data-ref="saveNote">기둥의 위치·방향·전체 가로·세로 치수와 번호를 반영합니다. 배치 후 현재 문서의 변경 사항을 저장하세요.</p>
    </aside>`;
  root.replaceChildren(page);
  // Keep references: Shell3 may move the workspace and run panel after mounting.
  const ui = Object.fromEntries([...page.querySelectorAll('[data-ref]')].map(node => [node.dataset.ref, node]));
  const controls = Object.fromEntries([...page.querySelectorAll('[data-setting]')].map(node => [node.dataset.setting, node]));
  controls.writeNumbers.checked = readWriteNumbers();
  controls.fillMissingNumbersByRule.checked = readFillMissingNumbers();
  const state = { document: null, observedDocument: null, documentObserved: false, contextMismatchRetries: 0, ready: false, pending: null, candidates: [], selected: new Set(), previewSignature: '', scanRequestId: '', page: 1, summary: {}, mode: 'placement', hasResults: false, reviewSignature: '', symbols: [], typeFamilyId: '', gridAngleInitialized: false, gridAngleDirty: false, angleEditRevision: 0, destroyed: false, composing: false, deferredContext: null, resetDocumentSelection: false, needsInit: false };
  const disposers = [];
  const sender = options.post || options.postMessage || post;
  const listen = (node, event, handler) => { node.addEventListener(event, handler); disposers.push(() => node.removeEventListener(event, handler)); };
  const active = () => !state.destroyed && page.isConnected;
  let structure;
  const exporter = createColumnNumberExporter({ sender, listen, active, externalBusy: () => !!state.pending || !!structure?.busy(), changed: () => sync() });
  structure = createStructureReview(page.querySelector('.columnnumber-workspace'), page.querySelector('.columnnumber-run-panel'), { sender, listen, active, exporter, document: () => state.document, externalBusy: () => !!state.pending || exporter.busy(), visible: () => state.mode === 'structure', changed: () => sync() });
  exporter.register(ui.placementPanel, 'placement-preview'); exporter.register(ui.results, 'placement-result'); exporter.register(ui.reviewPanel, 'review');
  const pickers = ['linkElementId', 'familyElementId', 'baseLevelElementId', ...Object.keys(TYPE_BUCKETS)].map(key => createColumnNumberPicker(controls[key], key, { listen, composition: on => { state.composing = on; sync(); if (!on) { flushContext(); if (state.needsInit) request('init', true); } }, blur: () => queueMicrotask(flushContext) }));
  const editingContextControl = () => state.composing || pickers.some(picker => picker.hasFocus()) || Object.values(controls).some(control => control === document.activeElement && (control.tagName === 'SELECT' || control === controls.gridAxisAngleDegrees));
  const selectedLevelIds = () => [...controls.baseLevelElementId.selectedOptions].map(option => option.value).filter(Boolean);
  const settings = () => ({ selectedDocument: state.document, selectedDocumentExplicit: true, linkElementId: controls.linkElementId.value, familyElementId: controls.familyElementId.value, ...Object.fromEntries(Object.keys(TYPE_BUCKETS).map(key => [key, controls[key].value])), baseLevelElementId: selectedLevelIds()[0] || '', baseLevelElementIds: selectedLevelIds(), offsetMillimeters: numeric(controls.offsetMillimeters.value), sourceParameterName: controls.sourceParameterName.value.trim(), sourceParameterScope: controls.sourceParameterScope.value, sourceNumberSeparator: controls.sourceNumberSeparator.value, gridToleranceMillimeters: numeric(controls.gridToleranceMillimeters.value), gridAxisAngleDegrees: numeric(controls.gridAxisAngleDegrees.value), interiorMode: controls.interiorMode.value, writeNumbers: controls.writeNumbers.checked, fillMissingNumbersByRule: controls.writeNumbers.checked && controls.fillMissingNumbersByRule.checked, skipExisting: true });
  const reviewSettings = () => ({ ...settings(), writeNumbers: true, fillMissingNumbersByRule: false, positionToleranceMillimeters: numeric(controls.positionToleranceMillimeters.value), sourceCombinedParameterName: controls.sourceCombinedParameterName.value.trim(), sourceCombinedParameterScope: controls.sourceCombinedParameterScope.value, sourceNumberSeparator: controls.sourceNumberSeparator.value });
  const signature = () => JSON.stringify(settings());
  const reviewSignature = () => JSON.stringify(reviewSettings());
  const validPreview = () => state.ready && !!state.previewSignature && signature() === state.previewSignature;
  const selectedIds = () => state.candidates.filter(row => isAccepted(row) && state.selected.has(str(row.id))).map(row => str(row.id));
  function validation(stage = state.mode) {
    if (!state.ready) return '프로젝트 정보를 불러오세요.';
    const value = settings();
    if (!value.linkElementId) return '구조 링크를 선택하세요.';
    if (!value.familyElementId) return '기둥넘버 패밀리를 선택하세요.';
    if (!value.baseLevelElementId) return '기준 레벨을 선택하세요.';
    if (!Number.isFinite(value.offsetMillimeters)) return '레벨에서 높이를 유효한 숫자로 입력하세요.';
    if ((stage === 'review' || value.writeNumbers) && !value.sourceParameterName) return '원본 기둥의 전체 번호 파라미터 이름을 입력하세요.';
    if (!Number.isFinite(value.gridToleranceMillimeters) || value.gridToleranceMillimeters <= 0) return '그리드 판정 허용 오차를 0보다 큰 숫자로 입력하세요.';
    if (!Number.isFinite(value.gridAxisAngleDegrees)) return '번호 기준 방향을 유효한 각도로 입력하세요.';
    if (stage === 'review' && (!Number.isFinite(numeric(controls.positionToleranceMillimeters.value)) || numeric(controls.positionToleranceMillimeters.value) <= 0)) return '중심 위치 허용 오차를 0보다 큰 숫자로 입력하세요.';
    return '';
  }
  function feedback(message, tone = '') { ui.feedback.textContent = str(message); ui.feedback.dataset.tone = tone; }
  function sync() {
    pickers.forEach(picker => picker.sync());
    const busy = !!state.pending || structure.busy() || exporter.busy();
    const invalid = validation();
    ui.validation.textContent = invalid;
    ui.refresh.disabled = busy;
    ui.scan.disabled = busy || !!invalid || state.composing;
    ui.apply.disabled = busy || !!invalid || state.composing || !validPreview() || !selectedIds().length;
    ui.review.disabled = busy || !!validation('review') || state.composing;
    ui.scan.textContent = state.pending?.stage === 'scan' ? '기둥 검출 중…' : '기둥 검출';
    ui.apply.textContent = state.pending?.stage === 'apply' ? '배치 중…' : '선택한 기둥에 배치';
    ui.review.textContent = state.pending?.stage === 'review' ? '검토 중…' : '기둥 넘버 검토';
    const review = state.mode === 'review';
    const isStructure = state.mode === 'structure';
    controls.sourceParameterName.required = review || controls.writeNumbers.checked;
    controls.fillMissingNumbersByRule.disabled = !controls.writeNumbers.checked || review;
    ui.fillMissingNumbersOption.hidden = review;
    [ui.linkSettings, ui.numberSettings, ui.typeSettings, ui.linkRun].forEach(node => { node.hidden = isStructure; });
    ui.placementPanel.hidden = review || isStructure; ui.reviewPanel.hidden = !review;
    ui.scan.hidden = review; ui.apply.hidden = review; ui.review.hidden = !review;
    ui.results.hidden = review || isStructure || !state.hasResults;
    ui.runTitle.textContent = review ? '기둥 넘버 검토' : '검출 및 배치';
    ui.runNote.textContent = review ? '규칙 검토와 각 링크 기둥의 원본 값 대조를 독립적으로 수행합니다. 모델은 변경하지 않습니다.' : '같은 링크 기둥·레벨에 이미 배치한 기둥넘버는 건너뜁니다.';
    ui.parameterNote.textContent = review ? '그리드 규칙과 각 원본 기둥의 값을 별도로 검토합니다. 주기둥의 Stud Number는 -로 비교하며, 원본 번호가 없는 경우에는 대조 오류를 표시합니다.' : controls.writeNumbers.checked ? controls.fillMissingNumbersByRule.checked ? '원본 번호가 있는 기둥은 그대로 분리하여 복사합니다. 원본 값이 없는 기둥만 위치·그리드 규칙으로 번호를 채웁니다. 주기둥의 Stud Number는 -를 사용하며, 계산할 수 없거나 원본 형식이 잘못된 항목은 사유를 확인하세요.' : '예: G26_D-2 → G26 / D-2. 원본 값이 없으면 Column Number는 패밀리 기본값을 유지하고 Stud Number는 -를 입력합니다. 주기둥의 Stud Number도 -를 사용합니다. 비어 있지 않은 잘못된 번호 형식은 사유를 확인하세요.' : 'Column Number와 Stud Number의 패밀리 기본값을 유지합니다. 빈 기본값만 -로 보정합니다. 원본 번호 파라미터 이름은 비워 둘 수 있습니다.';
    ui.fillMissingNumbersNote.textContent = controls.writeNumbers.checked ? '원본 번호가 있으면 그대로 복사하고, 값이 없는 기둥만 위치·그리드 규칙으로 번호를 부여합니다. 잘못된 형식의 원본 값은 덮어쓰지 않습니다.' : '번호 입력이 꺼져 있어 빈 번호 채우기도 실행하지 않습니다. 선택한 옵션 값은 유지됩니다.';
    ui.writeNumbersNote.textContent = review ? '이 옵션은 배치에만 적용합니다. 검토는 번호를 항상 비교하므로 원본 번호 파라미터 이름이 필요합니다.' : '체크를 해제하면 원본 번호를 복사하지 않고 패밀리 기본값을 사용합니다. 빈 문자만 -로 보정하며 Column_Width 1·2 치수는 항상 입력합니다.';
    ui.saveNote.textContent = controls.writeNumbers.checked ? '기둥의 위치·방향·전체 가로·세로 치수와 번호를 반영합니다. 배치 후 현재 문서의 변경 사항을 저장하세요.' : '기둥의 위치·방향·전체 가로·세로 치수를 반영하고 패밀리 기본 번호를 유지합니다. 빈 기본값만 -로 보정합니다. 배치 후 현재 문서의 변경 사항을 저장하세요.';
    ui.interiorNote.textContent = { auto: '경계의 행·열 번호를 우선 사용하고, 맞지 않는 구획은 내부 위치 순서로 부여합니다.', boundary: '같은 구획 경계의 샛기둥과 행·열이 맞는 경우에만 내부 번호를 부여합니다.', rank: '각 구획 내부의 행은 아래부터 A, B…, 열은 왼쪽부터 1, 2… 순번을 부여합니다.' }[controls.interiorMode.value];
    ui.saveNote.hidden = review || isStructure;
    ui.dimensionsNote.hidden = review;
    [ui.placementTab, ui.reviewTab, ui.structureTab].forEach(tab => { const selected = tab === (isStructure ? ui.structureTab : review ? ui.reviewTab : ui.placementTab); tab.setAttribute('aria-selected', String(selected)); tab.tabIndex = selected ? 0 : -1; });
    const accepted = state.candidates.filter(isAccepted).length;
    ui.selectAll.disabled = busy || !validPreview() || !accepted;
    ui.selectAll.checked = accepted > 0 && state.selected.size === accepted;
    ui.selectAll.indeterminate = state.selected.size > 0 && state.selected.size < accepted;
    ui.selectionSummary.textContent = validPreview() ? `배치 가능한 ${accepted}개 중 ${selectedIds().length}개 선택` : state.candidates.length ? '설정이 변경되었습니다. 기둥을 다시 검출하세요.' : '기둥을 검출한 뒤 배치할 항목을 선택하세요.';
    if (review) ui.selectionSummary.textContent = state.reviewSignature && state.reviewSignature === reviewSignature() ? '현재 설정의 검토 결과를 확인하세요.' : '대상과 기준 높이를 확인한 뒤 검토하세요.';
    ui.rows.querySelectorAll('input').forEach(node => { node.disabled = busy || !validPreview() || !isAccepted(state.candidates.find(row => str(row.id) === node.dataset.candidate) || {}); node.checked = state.selected.has(node.dataset.candidate); });
    ui.rows.querySelectorAll('[data-number-value]').forEach(cell => { cell.textContent = controls.writeNumbers.checked ? cell.dataset.numberValue : '패밀리 기본값 유지'; });
    const maxPage = Math.max(1, Math.ceil(state.candidates.length / 100));
    ui.previous.disabled = state.page <= 1;
    ui.next.disabled = state.page >= maxPage;
    ui.pageLabel.textContent = `${state.page} / ${maxPage}`;
    structure.sync();
    exporter.sync();
  }
  function invalidate(message = '설정이 변경되었습니다. 기둥을 다시 검출하세요.') {
    const hadPreview = !!state.previewSignature;
    state.previewSignature = '';
    state.scanRequestId = '';
    if (state.reviewSignature) { state.reviewSignature = ''; ui.reviewNote.textContent = '설정이 변경되었습니다. 다시 검토하세요.'; }
    if (hadPreview) { ui.previewNote.textContent = message; feedback(message); }
    sync();
  }
  function renderRows() {
    const fragment = document.createDocumentFragment();
    const rows = state.candidates.slice((state.page - 1) * 100, state.page * 100);
    if (!rows.length) {
      const tr = document.createElement('tr'); const td = document.createElement('td'); td.colSpan = 8; td.className = 'columnnumber-empty'; td.textContent = '검출한 기둥이 없습니다.'; tr.append(td); fragment.append(tr);
    }
    rows.forEach(row => {
      const tr = document.createElement('tr'); tr.dataset.status = str(row.status).toLowerCase();
      const checkCell = document.createElement('td'); const check = document.createElement('input'); check.type = 'checkbox'; check.dataset.candidate = str(row.id); check.dataset.columnnumberFocusKey = `candidate-${row.id}`; check.setAttribute('aria-label', `${str(row.baseLevelName)} ${str(row.sourceName)} (${str(row.sourceElementId)}) 배치 선택`); checkCell.append(check); tr.append(checkCell);
      const ruleNote = str(row.ruleNote);
      const reason = [statusLabel(row.status), numberingSourceLabel(row), str(row.reason), ruleNote && !str(row.reason).includes(ruleNote) ? ruleNote : ''].filter(Boolean).join('\n');
      [ [str(row.baseLevelName), str(row.sourceName), `${kindLabel(row.kind)} · ID ${str(row.sourceElementId)}`].filter(Boolean).join('\n'), str(row.columnNumber) || '—', str(row.studNumber) || '—', str(row.typeName) || '—', Number(row.widthMillimeters) > 0 && Number(row.depthMillimeters) > 0 ? `${format(row.widthMillimeters)} × ${format(row.depthMillimeters)}` : '확인 불가', format(row.rotationDegrees), reason ].forEach((value, index) => { const cell = document.createElement('td'); cell.textContent = value; if (index === 1 || index === 2) cell.dataset.numberValue = value; tr.append(cell); });
      fragment.append(tr);
    });
    ui.rows.replaceChildren(fragment);
    ui.counts.textContent = `전체 ${state.candidates.length} · 가능 ${state.summary.acceptedCount ?? state.candidates.filter(isAccepted).length} · 기존 ${state.summary.existingCount ?? 0} · 확인 필요 ${state.summary.rejectedCount ?? 0}`;
    sync();
  }
  function request(stage, preserveMismatchRetries = false) {
    if (!active() || state.pending || structure.busy() || exporter.busy() || state.composing) return false;
    if (stage !== 'init' && validation(stage)) { feedback(validation(stage), 'error'); return false; }
    if (stage === 'apply' && (!validPreview() || !selectedIds().length)) { feedback('현재 설정으로 기둥을 검출하고 배치할 항목을 선택하세요.', 'error'); return false; }
    const requestId = `columnnumber-${Date.now()}-${++serial}-${stage}`;
    if (stage === 'init') { state.deferredContext = null; state.needsInit = false; if (!preserveMismatchRetries) state.contextMismatchRetries = 0; }
    const payload = stage === 'init' ? { selectedDocument: state.document, requestId } : { ...(stage === 'review' ? reviewSettings() : settings()), requestId };
    if (stage === 'apply') { payload.candidateIds = selectedIds(); payload.scanRequestId = state.scanRequestId; }
    if (stage === 'review') payload.positionToleranceMillimeters = numeric(controls.positionToleranceMillimeters.value);
    if (stage === 'init' || stage === 'scan') invalidate();
    state.pending = { stage, requestId, signature: stage === 'review' ? reviewSignature() : signature(), writeNumbers: payload.writeNumbers, fillMissingNumbersByRule: payload.fillMissingNumbersByRule, angleEditRevision: state.angleEditRevision, hasExpectedDocument: stage === 'init' && state.resetDocumentSelection && state.documentObserved, expectedDocument: state.observedDocument, exportDocument: cloneColumnNumberValue(payload.selectedDocument), exportSettings: describeColumnNumberSettings(payload, controls) };
    feedback(stage === 'init' ? '프로젝트 정보를 불러오는 중입니다.' : stage === 'scan' ? '링크 기둥을 검출하고 있습니다.' : stage === 'review' ? '기둥 넘버를 검토하고 있습니다.' : '선택한 기둥에 기둥넘버를 배치하고 있습니다.');
    sync();
    try { if (sender(COLUMN_NUMBER_EVENTS[stage], payload) !== false) return true; } catch { /* Keep the form usable if the host connection fails. */ }
    state.pending = null; feedback('Revit에 요청을 전달하지 못했습니다. 연결 상태를 확인하세요.', 'error'); sync(); return false;
  }
  function setOptions(control, values, label, emptyMessage) {
    const choices = values.map(value => ({ value: str(value.elementId), label: label(value) }));
    const items = control.multiple && choices.length ? choices : [{ value: '', label: emptyMessage }, ...choices];
    const key = JSON.stringify(items);
    if (control.dataset.optionsSignature === key) return;
    const selected = control.value;
    const selectedValues = new Set([...control.selectedOptions].map(option => option.value));
    const scrollTop = control.scrollTop, scrollLeft = control.scrollLeft;
    control.replaceChildren(...items.map(item => { const option = document.createElement('option'); option.value = item.value; option.textContent = item.label; return option; }));
    if (control.multiple) [...control.options].forEach(option => { option.selected = selectedValues.has(option.value) && !!option.value; });
    else control.value = items.some(item => item.value === selected) ? selected : '';
    control.scrollTop = scrollTop; control.scrollLeft = scrollLeft;
    control.dataset.optionsSignature = key;
  }
  function syncTypeOptions() {
    const familyId = controls.familyElementId.value;
    const familyChanged = familyId !== state.typeFamilyId;
    Object.entries(TYPE_BUCKETS).forEach(([key, bucket]) => {
      const control = controls[key];
      if (familyChanged) control.value = '';
      const symbols = state.symbols.filter(symbol => str(symbol.familyElementId) === familyId && str(symbol.typeBucket).toLowerCase() === bucket && isFourWay(symbol));
      const previous = control.dataset.optionsSignature;
      setOptions(control, symbols, symbol => symbol.typeName, symbols.length > 1 ? '후보가 여러 개입니다. 선택하세요.' : symbols.length ? '타입을 선택하세요.' : familyId ? '해당 4Way 타입 없음' : '패밀리를 먼저 선택하세요.');
      // Never choose the first of multiple matching Dummy/type variants.
      if (symbols.length === 1 && !control.value && (familyChanged || previous !== control.dataset.optionsSignature)) control.value = str(symbols[0].elementId);
    });
    state.typeFamilyId = familyId;
    ui.typeNote.textContent = familyId ? '후보가 하나인 4Way 타입은 자동 선택합니다. 비어 있는 구간이 실제 기둥에 필요하면 검출 결과에서 제외 사유를 확인하세요. 샛기둥은 모두 선택한 Stud 타입으로 배치합니다.' : '패밀리를 선택하면 적용 가능한 타입을 표시합니다. 사용하지 않는 크기 구간은 비워 둘 수 있습니다.';
  }
  function applyContext(payload, requestAngleRevision) {
    const previousDocument = state.document;
    const nextDocument = normalizeDocument(payload.document);
    if (previousDocument && !sameDocument(previousDocument, nextDocument)) { structure.resetDocument(); exporter.clear(); }
    if (state.resetDocumentSelection || (previousDocument && !sameDocument(previousDocument, nextDocument))) {
      ['linkElementId', 'familyElementId', 'baseLevelElementId', ...Object.keys(TYPE_BUCKETS)].forEach(key => { controls[key].value = ''; });
      state.gridAngleInitialized = false;
      // Edits made while this new-document request was in flight belong to the
      // user's current settings and must survive even after the editor blurs.
      state.gridAngleDirty = state.angleEditRevision !== requestAngleRevision;
      state.typeFamilyId = '';
    }
    state.resetDocumentSelection = false;
    state.contextMismatchRetries = 0;
    state.document = nextDocument;
    state.observedDocument = nextDocument; state.documentObserved = true;
    state.ready = !!state.document;
    ui.document.textContent = str(state.document?.title || state.document?.name || '열린 프로젝트가 없습니다.');
    ui.document.title = str(state.document?.path);
    setOptions(controls.linkElementId, payload.links || [], item => item.name, (payload.links || []).length ? '구조 링크를 선택하세요.' : '사용 가능한 링크가 없습니다.');
    state.symbols = Array.isArray(payload.familySymbols) ? payload.familySymbols : [];
    const families = [...new Map(state.symbols.filter(symbol => symbol.familyElementId != null).map(symbol => [str(symbol.familyElementId), { elementId: symbol.familyElementId, familyName: symbol.familyName }])).values()];
    setOptions(controls.familyElementId, families, item => item.familyName, families.length ? '패밀리를 선택하세요.' : '지원하는 패밀리가 없습니다.');
    syncTypeOptions();
    if (!state.gridAngleInitialized && !state.gridAngleDirty) { const angle = numeric(payload.gridAxisAngleDegrees ?? payload.defaultGridAxisAngleDegrees ?? 0); controls.gridAxisAngleDegrees.value = str(Number.isFinite(angle) ? angle : 0); }
    state.gridAngleInitialized = true;
    setOptions(controls.baseLevelElementId, payload.levels || [], item => `${item.name} (${format(item.elevationMillimeters)} mm)`, (payload.levels || []).length ? '기준 레벨을 선택하세요.' : '레벨이 없습니다.');
    feedback(payload.message || '프로젝트 정보를 불러왔습니다.'); sync();
  }
  function receive(event, payload = {}) {
    if (!active()) return false;
    if (event === 'columnnumber:export-result' || (event === COLUMN_NUMBER_EVENTS.error && payload.stage === 'export')) return exporter.receive(event, payload);
    if (event.startsWith('columnnumber:structure-') || (event === COLUMN_NUMBER_EVENTS.error && str(payload.stage).startsWith('structure-'))) return structure.receive(event, payload);
    if (event === 'host:doc-changed') {
      const nextDocument = normalizeDocument(payload);
      const currentDocument = state.documentObserved ? state.observedDocument : state.document || state.deferredContext?.payload.document;
      // Host context sync and view activation also publish this event without
      // changing documents. A same-document echo must not touch requests or UI.
      if ((state.documentObserved || currentDocument) && sameDocument(currentDocument, nextDocument)) return true;
      const initialRequest = !state.documentObserved && !state.document && !state.deferredContext && state.pending?.stage === 'init' && !state.resetDocumentSelection;
      state.observedDocument = nextDocument; state.documentObserved = true;
      if (initialRequest) {
        state.pending.hasExpectedDocument = true; state.pending.expectedDocument = nextDocument;
        return true;
      }
      state.contextMismatchRetries = 0;
      exporter.clear();
      structure.resetDocument();
      state.pending = null; state.ready = false; state.document = null; state.deferredContext = null;
      state.resetDocumentSelection = true;
      state.candidates = []; state.selected.clear(); state.previewSignature = ''; state.scanRequestId = ''; state.page = 1;
      state.hasResults = false; state.reviewSignature = ''; ui.reviewRows.replaceChildren(); ui.reviewCounts.textContent = '검토 전'; ui.reviewNote.textContent = '문서가 변경되었습니다. 다시 검토하세요.'; renderRows();
      ui.document.textContent = '활성 문서가 변경되었습니다.';
      state.needsInit = !request('init'); return true;
    }
    const pending = state.pending;
    if (!pending || !payload.requestId || payload.requestId !== pending.requestId) return false;
    const expected = { init: COLUMN_NUMBER_EVENTS.context, scan: COLUMN_NUMBER_EVENTS.preview, apply: COLUMN_NUMBER_EVENTS.result, review: COLUMN_NUMBER_EVENTS.reviewResult }[pending.stage];
    if (event !== expected && event !== COLUMN_NUMBER_EVENTS.error) return false;
    state.pending = null;
    if (event === COLUMN_NUMBER_EVENTS.error || (payload.ok === false && pending.stage !== 'apply')) {
      if (pending.stage === 'init') state.ready = false;
      invalidate(); feedback(payload.message || '요청을 처리하지 못했습니다.', 'error'); sync(); return true;
    }
    if (pending.stage === 'init') {
      if (pending.hasExpectedDocument && !sameDocument(pending.expectedDocument, payload.document)) {
        state.resetDocumentSelection = true; state.ready = false;
        if (state.contextMismatchRetries < 1) { state.contextMismatchRetries++; state.needsInit = !request('init', true); }
        else { feedback('현재 활성 문서와 프로젝트 정보가 일치하지 않습니다. Revit의 대상 문서를 활성화한 뒤 프로젝트 새로고침을 실행하세요.', 'error'); sync(); }
        return true;
      }
      // Context can reset the drawing angle as well as select options. Keep the
      // active editor intact, then preserve edits newer than this request.
      if (editingContextControl()) {
        state.deferredContext = { payload, angleEditRevision: pending.angleEditRevision }; feedback('프로젝트 정보를 불러왔습니다. 현재 입력을 마치면 목록이 반영됩니다.'); sync();
      } else applyContext(payload, pending.angleEditRevision);
    } else if (pending.stage === 'scan') {
      if (pending.signature !== signature()) { invalidate(); feedback('검출 중 설정이 변경되었습니다. 기둥을 다시 검출하세요.'); sync(); return true; }
      state.candidates = Array.isArray(payload.candidates) ? payload.candidates : [];
      state.summary = payload.summary || {}; state.page = 1;
      state.selected = new Set(state.candidates.filter(isAccepted).map(row => str(row.id)));
      state.previewSignature = pending.signature; state.scanRequestId = pending.requestId;
      state.hasResults = false;
      ui.previewNote.textContent = pending.writeNumbers ? pending.fillMissingNumbersByRule ? '원본 번호가 있는 행은 복사하고, 값이 없는 행은 위치·그리드 규칙으로 채웁니다. 상태 / 사유의 번호 출처와 Column Number·Stud Number를 확인하세요.' : '타입명 치수로 타입을 선택했습니다. 원본 번호가 없는 행은 패밀리 기본값 / -로 배치합니다. Column Number와 Stud Number를 확인하세요.' : '패밀리 기본 번호를 유지하고 빈 문자만 -로 보정합니다. 원본 타입명 치수의 큰 변으로 타입을 선택하고 가로·세로는 Column_Width 1·2에 각각 입력합니다.';
      renderRows(); feedback(payload.message || '기둥 검출이 완료되었습니다.');
      exporter.capture('placement-preview', pending, payload.candidates || [], [ui.counts.textContent, payload.message].filter(Boolean).join('\n'));
    } else if (pending.stage === 'review') {
      if (pending.signature !== reviewSignature()) { state.reviewSignature = ''; ui.reviewNote.textContent = '검토 중 설정이 변경되었습니다. 다시 검토하세요.'; feedback(ui.reviewNote.textContent); sync(); return true; }
      state.reviewSignature = pending.signature;
      const summary = payload.summary || {};
      ui.reviewCounts.textContent = `기둥 ${summary.columnCount || 0} · 규칙 일치 ${summary.matchedCount || 0} · 누락 ${summary.missingCount || 0} · 번호 불일치 ${summary.mismatchCount || 0} · 타입 불일치 ${summary.typeMismatchCount || 0} · 치수 불일치 ${summary.dimensionMismatchCount || 0} · 위치 불일치 ${summary.positionMismatchCount || 0} · 중복 ${summary.duplicateCount || 0} · 연결 불명확 ${summary.ambiguousCount || 0} · 미연결 ${summary.unmatchedCount || 0} · 오류 ${summary.errorCount || 0}\n원본 값 대조: 일치 ${summary.sourceMatchedCount || 0} · 불일치 ${summary.sourceMismatchCount || 0} · 원본 확인 필요 ${summary.sourceErrorCount || 0}`;
      const fragment = document.createDocumentFragment();
      (payload.rows || []).forEach(row => {
        const tr = document.createElement('tr'); tr.dataset.status = str(row.status);
        const ruleStatus = row.ruleStatus || row.status;
        const dimensionDetail = row.dimensionMismatch || ruleStatus === 'dimension-mismatch' ? `치수 예상: ${format(row.expectedWidthMillimeters)} × ${format(row.expectedDepthMillimeters)} mm\n치수 실제: ${format(row.actualWidthMillimeters)} × ${format(row.actualDepthMillimeters)} mm` : '';
        const values = [
          [str(row.baseLevelName), str(row.sourceName), `기둥 ${str(row.sourceElementId) || '—'}\n넘버 ${str(row.targetElementId) || '—'}`].filter(Boolean).join('\n'),
          `규칙 Column: ${str(row.sourceValue) || '—'}\n규칙 Stud: ${str(row.expectedStudNumber) || '—'}\n실제 Column: ${str(row.targetValue) || '—'}\n실제 Stud: ${str(row.actualStudNumber) || '—'}`,
          `예상: ${str(row.expectedTypeName) || '—'}\n실제: ${str(row.actualTypeName) || '—'}`,
          [statusLabel(ruleStatus), str(row.ruleMessage ?? row.message), dimensionDetail].filter(Boolean).join('\n'),
          [sourceStatusLabel(row.sourceComparisonStatus), `원본: ${str(row.sourceFullNumber) || '—'}`, `Column: ${str(row.sourceExpectedColumnNumber) || '—'}\nStud: ${str(row.sourceExpectedStudNumber) || '—'}`, str(row.sourceComparisonMessage)].filter(Boolean).join('\n')
        ];
        values.forEach((value, index) => { const cell = document.createElement('td'); cell.textContent = value; if (index === 3) cell.dataset.ruleStatus = str(ruleStatus); if (index === 4) cell.dataset.sourceStatus = str(row.sourceComparisonStatus || 'unavailable'); tr.append(cell); });
        fragment.append(tr);
      });
      if (!fragment.childNodes.length) { const tr = document.createElement('tr'); const td = document.createElement('td'); td.colSpan = 5; td.className = 'columnnumber-empty'; td.textContent = '현재 조건의 검토 대상이 없습니다.'; tr.append(td); fragment.append(tr); }
      ui.reviewRows.replaceChildren(fragment);
      ui.reviewNote.textContent = '그리드 번호·타입·위치·치수 규칙과 각 기둥의 원본 값 대조를 별도로 확인하세요. 방향 수만 다른 타입은 규칙 오류에서 제외합니다.';
      exporter.capture('review', pending, payload.rows || [], [ui.reviewCounts.textContent, payload.message].filter(Boolean).join('\n'));
      feedback(payload.message || '기둥 넘버 검토가 완료되었습니다.'); sync();
    } else {
      invalidate();
      state.hasResults = true;
      ui.resultSummary.textContent = `배치 ${payload.createdCount || 0} · 건너뜀 ${payload.skippedCount || 0} · 실패 ${payload.failedCount || 0}`;
      const fragment = document.createDocumentFragment();
      (payload.rows || []).forEach(row => { const item = document.createElement('div'); item.className = 'columnnumber-result-row'; item.textContent = [str(row.baseLevelName), `ID ${str(row.sourceElementId)}`, statusLabel(row.status), str(row.message)].filter(Boolean).join(' · '); fragment.append(item); });
      ui.resultRows.replaceChildren(fragment);
      exporter.capture('placement-result', pending, payload.rows || [], [ui.resultSummary.textContent, payload.message].filter(Boolean).join('\n'), payload);
      feedback(payload.message || (pending.writeNumbers ? '기둥넘버의 배치, 가로·세로 치수와 번호 입력이 완료되었습니다.' : '기둥넘버의 배치와 가로·세로 치수 입력이 완료되었습니다. 패밀리 기본 번호를 유지하고 빈 기본값은 -로 보정했습니다.'), payload.failedCount || payload.ok === false ? 'error' : 'ok');
      sync();
    }
    return true;
  }
  function flushContext() {
    if (!active() || !state.deferredContext || editingContextControl()) return;
    const context = state.deferredContext; state.deferredContext = null; applyContext(context.payload, context.angleEditRevision);
  }
  Object.values(controls).forEach(control => {
    const changed = () => { if (control === controls.familyElementId) syncTypeOptions(); if (control === controls.gridAxisAngleDegrees) { state.gridAngleDirty = true; state.angleEditRevision++; } if (control === controls.writeNumbers || control === controls.fillMissingNumbersByRule) { try { localStorage.setItem(control === controls.writeNumbers ? WRITE_NUMBERS_KEY : FILL_MISSING_NUMBERS_KEY, String(control.checked)); } catch { /* Storage restrictions must not block placement settings. */ } } invalidate(); };
    listen(control, 'input', changed); listen(control, 'change', changed);
    listen(control, 'compositionstart', () => { state.composing = true; sync(); });
    listen(control, 'compositionend', () => { state.composing = false; invalidate(); flushContext(); if (state.needsInit) request('init', true); });
    listen(control, 'blur', () => queueMicrotask(flushContext));
  });
  listen(ui.refresh, 'click', () => request('init'));
  listen(ui.scan, 'click', () => request('scan'));
  listen(ui.apply, 'click', () => request('apply'));
  listen(ui.review, 'click', () => request('review'));
  function setMode(mode) { state.mode = mode; sync(); if (mode === 'structure') structure.ensureContext(); }
  listen(ui.placementTab, 'click', () => setMode('placement')); listen(ui.reviewTab, 'click', () => setMode('review')); listen(ui.structureTab, 'click', () => setMode('structure'));
  const tabs = [ui.placementTab, ui.reviewTab, ui.structureTab], modes = ['placement', 'review', 'structure'];
  tabs.forEach((tab, index) => listen(tab, 'keydown', event => { if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return; event.preventDefault(); const next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length; setMode(modes[next]); tabs[next].focus({ preventScroll: true }); }));
  listen(ui.selectAll, 'change', () => { if (state.pending || !validPreview()) return; state.selected = new Set(ui.selectAll.checked ? state.candidates.filter(isAccepted).map(row => str(row.id)) : []); sync(); });
  listen(ui.rows, 'change', event => { const node = event.target; if (!node.matches('input[data-candidate]') || state.pending || !validPreview()) return; const row = state.candidates.find(item => str(item.id) === node.dataset.candidate); if (!row || !isAccepted(row)) return; node.checked ? state.selected.add(node.dataset.candidate) : state.selected.delete(node.dataset.candidate); sync(); });
  listen(ui.previous, 'click', () => { if (state.page > 1) { state.page--; renderRows(); } });
  listen(ui.next, 'click', () => { if (state.page < Math.ceil(state.candidates.length / 100)) { state.page++; renderRows(); } });
  [COLUMN_NUMBER_EVENTS.context, COLUMN_NUMBER_EVENTS.preview, COLUMN_NUMBER_EVENTS.result, COLUMN_NUMBER_EVENTS.reviewResult, COLUMN_NUMBER_EVENTS.structureContext, COLUMN_NUMBER_EVENTS.structurePreview, COLUMN_NUMBER_EVENTS.structureResult, 'columnnumber:export-result', COLUMN_NUMBER_EVENTS.error, 'host:doc-changed'].forEach(event => disposers.push(onHost(event, payload => receive(event, payload))));
  function destroy() { if (state.destroyed) return; state.destroyed = true; disposers.splice(0).forEach(dispose => dispose()); if (activeCleanup === destroy) activeCleanup = null; }
  listen(window, 'hashchange', () => queueMicrotask(() => { if (!page.isConnected) destroy(); }));
  activeCleanup = destroy;
  const controller = { receive, requestInit: () => request('init'), requestScan: () => request('scan'), requestApply: () => request('apply'), requestReview: () => request('review'), requestStructureInit: () => structure.request('init'), requestStructureScan: () => structure.request('scan'), requestStructureApply: () => structure.request('apply'), getState: () => ({ ready: state.ready, busy: state.pending?.stage || '', mode: state.mode, settings: settings(), previewValid: validPreview(), reviewValid: !!state.reviewSignature && state.reviewSignature === reviewSignature(), selectedCandidateIds: selectedIds(), candidates: state.candidates, scanRequestId: state.scanRequestId, structure: structure.getState() }), destroy };
  sync();
  if (options.autoInit !== false) request('init');
  return controller;
}

// Structural review has separate mounted editors, request correlation and
// preview selection. Changing these settings cannot invalidate link results.
function createStructureReview(workspace, aside, options) {
  const panel = document.createElement('section');
  panel.className = 'columnnumber-structure'; panel.id = 'columnnumber-structure-panel'; panel.hidden = true;
  panel.setAttribute('role', 'tabpanel'); panel.setAttribute('aria-labelledby', 'columnnumber-tab-structure');
  panel.innerHTML = `
    <section class="columnnumber-card">
      <div class="columnnumber-head"><h3>01 · 구조 모델 검토 대상</h3><button class="btn" type="button" data-structure-ref="refresh">프로젝트 새로고침</button></div>
      <p class="columnnumber-note">현재 구조 모델의 선택한 기둥 타입 번호를 그리드 규칙과 비교합니다. 구조 기둥(Structural Columns)과 일반 기둥(Columns)을 포함하며, 검토는 모델을 변경하지 않습니다.</p>
      <p class="columnnumber-document" data-structure-ref="document">구조 프로젝트 정보를 불러오세요.</p>
      <div class="columnnumber-fields">
        <label>주기둥 타입 · 복수 선택<select multiple size="5" data-structure-setting="mainTypeElementIds" data-columnnumber-focus-key="structure-main-types"></select></label>
        <label>샛기둥 타입 · 복수 선택<select multiple size="5" data-structure-setting="studTypeElementIds" data-columnnumber-focus-key="structure-stud-types"></select></label>
        <label>검토 레벨 · 복수 선택<select multiple size="4" data-structure-setting="baseLevelElementIds" data-columnnumber-focus-key="structure-levels"></select></label>
        <label>레벨에서 기준 높이 (mm)<input type="text" inputmode="decimal" autocomplete="off" value="1500" data-structure-setting="offsetMillimeters" data-columnnumber-focus-key="structure-offset"></label>
      </div>
      <p class="columnnumber-note">주기둥 타입은 하나 이상 체크하세요. 샛기둥 타입은 비워 둘 수 있습니다. 검색어를 바꿔도 선택은 유지하며, 같은 타입을 두 구분에 동시에 지정할 수 없습니다.</p>
      <p class="columnnumber-note">선택한 각 레벨에 공통 높이를 더한 기준면으로 해당 층의 기둥을 추립니다. 기둥 하단은 포함하고 상단은 제외합니다.</p>
    </section>
    <section class="columnnumber-card">
      <h3>02 · 전체 번호와 그리드 기준</h3>
      <div class="columnnumber-fields">
        <label>검토·입력 대상 파라미터<input type="text" autocomplete="off" required placeholder="예: 부재번호" data-structure-setting="targetParameterName" data-columnnumber-focus-key="structure-target"></label>
        <label>번호 구분자<select data-structure-setting="numberSeparator" data-columnnumber-focus-key="structure-separator"><option value="_">밑줄 (_) · G26_D-2</option><option value="-">하이픈 (-) · G26-D-2</option></select></label>
        <label class="columnnumber-wide">주기둥 그리드명 조합 순서<select data-structure-setting="gridNameOrder" data-columnnumber-focus-key="structure-grid-order"><option value="horizontal-first">가로 그리드명 + 세로 그리드명 · G + 26 → G26</option><option value="vertical-first">세로 그리드명 + 가로 그리드명 · 26 + G → 26G</option></select></label>
        <label>그리드 판정 허용 오차 (mm)<input type="text" inputmode="decimal" autocomplete="off" value="10" data-structure-setting="gridToleranceMillimeters" data-columnnumber-focus-key="structure-grid-tolerance"></label>
        <label>번호 기준 방향 (°)<input type="text" inputmode="decimal" autocomplete="off" value="0" data-structure-setting="gridAxisAngleDegrees" data-columnnumber-focus-key="structure-grid-angle"></label>
        <label class="columnnumber-wide">그리드 내부 샛기둥 번호<select data-structure-setting="interiorMode" data-columnnumber-focus-key="structure-interior"><option value="auto">자동 · 경계 우선, 맞지 않으면 내부 순번</option><option value="boundary">경계 샛기둥의 행·열 연결</option><option value="rank">내부 행·열 순번</option></select></label>
      </div>
      <p class="columnnumber-note">구조 기둥에 있는 인스턴스 문자 파라미터 이름을 지정하세요. 현재 값 검토와 선택한 기둥의 번호 입력에 같은 파라미터를 사용합니다. 넘버 패밀리의 Column Number·Stud Number는 필요하지 않습니다.</p>
      <p class="columnnumber-note">그리드명과 기둥 중심 위치로 기대값을 계산합니다. 주기둥은 G26, 샛기둥은 G26_D-2처럼 전체 번호를 지정한 파라미터 하나에 입력합니다.</p>
      <p class="columnnumber-note">번호 기준 방향은 현재 평면 뷰의 오른쪽 방향이 기본값입니다. 자동 모드는 경계 번호를 우선 사용하고, 맞지 않는 구획은 내부 위치 순서로 부여합니다.</p>
    </section>
    <section class="columnnumber-card columnnumber-structure-preview">
      <div class="columnnumber-head"><h3>03 · 구조 기둥 검토 결과</h3><span class="columnnumber-note" data-structure-ref="counts">검토 전</span></div>
      <p class="columnnumber-document" data-structure-ref="targetSummary">검토·입력 대상 파라미터를 지정하세요.</p>
      <label class="columnnumber-checkbox"><input type="checkbox" data-structure-setting="writeEnabled" data-columnnumber-focus-key="structure-write"><span>규칙에 맞게 번호 입력</span></label>
      <p class="columnnumber-note" data-structure-ref="previewNote">검토 후 예상 번호와 현재 번호를 확인하세요.</p>
      <p class="columnnumber-note">번호가 불일치하거나 비어 있고 수정 가능한 행만 선택할 수 있습니다. 일치·검토 오류·읽기 전용인 행은 상태와 사유를 확인하세요. 비활성 체크박스에 마우스를 올리면 선택할 수 없는 이유를 표시합니다.</p>
      <div class="columnnumber-table-wrap" data-columnnumber-scroll-key="structure-preview"><table class="columnnumber-table"><thead><tr><th class="columnnumber-check"><input type="checkbox" data-structure-ref="selectAll" aria-label="입력 가능한 구조 기둥 전체 선택" data-columnnumber-focus-key="structure-select-all"></th><th>레벨 / 구조 기둥</th><th>타입 / 구분</th><th>입력할 값 · 규칙</th><th>현재 파라미터 값</th><th>상태 / 사유</th></tr></thead><tbody data-structure-ref="rows"><tr><td colspan="6" class="columnnumber-empty">검토 결과가 없습니다.</td></tr></tbody></table></div>
      <div class="columnnumber-paging"><button class="btn" type="button" data-structure-ref="previous">이전</button><span data-structure-ref="pageLabel">1 / 1</span><button class="btn" type="button" data-structure-ref="next">다음</button></div>
    </section>
    <section class="columnnumber-card" data-structure-ref="results" hidden><div class="columnnumber-head"><h3>번호 입력 결과</h3><span class="columnnumber-note" data-structure-ref="resultSummary"></span></div><div class="columnnumber-result-list" data-structure-ref="resultRows" data-columnnumber-scroll-key="structure-results"></div></section>`;
  const run = document.createElement('section'); run.className = 'columnnumber-card columnnumber-run'; run.hidden = true;
  run.innerHTML = `<h3>구조 모델 검토</h3><p class="columnnumber-note" data-structure-ref="selectionSummary">구조 모델의 검토 대상을 선택하세요.</p><div class="columnnumber-actions"><button class="btn" type="button" data-structure-ref="scan" data-direct-kind="secondary">구조 모델 검토</button><button class="btn" type="button" data-structure-ref="apply" data-direct-kind="primary" hidden>선택한 기둥에 번호 입력</button></div><p class="columnnumber-note">검토는 읽기 전용입니다. 번호 입력은 쓰기 옵션을 켜고 선택한 행에만 별도로 실행합니다.</p><p class="columnnumber-validation" role="status" data-structure-ref="validation"></p><p class="columnnumber-feedback" role="status" aria-live="polite" data-structure-ref="feedback">검토할 기둥 타입과 기준 높이를 선택하세요.</p>`;
  workspace.append(panel); aside.append(run);
  const ui = Object.fromEntries([...panel.querySelectorAll('[data-structure-ref]'), ...run.querySelectorAll('[data-structure-ref]')].map(node => [node.dataset.structureRef, node]));
  const controls = Object.fromEntries([...panel.querySelectorAll('[data-structure-setting]')].map(node => [node.dataset.structureSetting, node]));
  options.exporter.register(panel.querySelector('.columnnumber-structure-preview'), 'structure-preview'); options.exporter.register(ui.results, 'structure-result');
  const state = { document: null, ready: false, pending: null, contextAttempted: false, candidates: [], selected: new Set(), previewSignature: '', scanRequestId: '', reviewedParameterName: '', page: 1, composing: false, deferredContext: null, angleRevision: 0, angleInitialized: false, angleDirty: false, resetSelection: false, hasResults: false };
  const listen = options.listen;
  const pickers = ['mainTypeElementIds', 'studTypeElementIds', 'baseLevelElementIds'].map(key => createColumnNumberPicker(controls[key], `structure-${key}`, { listen, composition: on => { state.composing = on; sync(); if (!on) { flushContext(); ensureContext(); } }, blur: () => queueMicrotask(flushContext) }));
  const chosen = key => [...controls[key].selectedOptions].map(option => option.value).filter(Boolean);
  const settings = () => ({ selectedDocument: state.document, selectedDocumentExplicit: true, mainTypeElementIds: chosen('mainTypeElementIds'), studTypeElementIds: chosen('studTypeElementIds'), baseLevelElementIds: chosen('baseLevelElementIds'), offsetMillimeters: numeric(controls.offsetMillimeters.value), targetParameterName: controls.targetParameterName.value.trim(), numberSeparator: controls.numberSeparator.value, gridToleranceMillimeters: numeric(controls.gridToleranceMillimeters.value), gridAxisAngleDegrees: numeric(controls.gridAxisAngleDegrees.value), interiorMode: controls.interiorMode.value, gridNameOrder: controls.gridNameOrder.value, writeEnabled: controls.writeEnabled.checked });
  // Write permission does not change the computed numbers or reviewed scope.
  const signature = () => { const value = settings(); delete value.writeEnabled; return JSON.stringify(value); };
  const validPreview = () => state.ready && !!state.previewSignature && state.previewSignature === signature();
  const writable = row => row.canWrite === true && ['mismatch', 'empty'].includes(str(row.status).toLowerCase());
  const selectedIds = () => state.candidates.filter(row => writable(row) && state.selected.has(str(row.id))).map(row => str(row.id));
  const editingContext = () => state.composing || pickers.some(picker => picker.hasFocus()) || Object.values(controls).some(control => control === document.activeElement && (control.tagName === 'SELECT' || control === controls.gridAxisAngleDegrees));
  const structureStatus = status => ({ match: '일치', mismatch: '번호 불일치', empty: '번호 없음', error: '검토 오류', updated: '번호 입력 완료', skipped: '건너뜀', failed: '실패' })[str(status).toLowerCase()] || str(status);
  function feedback(message, tone = '') { ui.feedback.textContent = str(message); ui.feedback.dataset.tone = tone; }
  function validation() {
    if (!state.ready) return '구조 프로젝트 정보를 불러오세요.';
    const value = settings();
    if (!value.mainTypeElementIds.length) return '주기둥 타입을 하나 이상 선택하세요.';
    if (value.mainTypeElementIds.some(id => value.studTypeElementIds.includes(id))) return '동일한 타입을 주기둥과 샛기둥으로 동시에 지정할 수 없습니다.';
    if (!value.baseLevelElementIds.length) return '검토 레벨을 선택하세요.';
    if (!Number.isFinite(value.offsetMillimeters)) return '레벨에서 기준 높이를 유효한 숫자로 입력하세요.';
    if (!value.targetParameterName) return '구조 기둥에서 검토하고 값을 입력할 파라미터 이름을 지정하세요.';
    if (!Number.isFinite(value.gridToleranceMillimeters) || value.gridToleranceMillimeters <= 0) return '그리드 판정 허용 오차를 0보다 큰 숫자로 입력하세요.';
    if (!Number.isFinite(value.gridAxisAngleDegrees)) return '번호 기준 방향을 유효한 각도로 입력하세요.';
    return '';
  }
  function sync() {
    pickers.forEach(picker => picker.sync());
    const visible = options.visible(), busy = !!state.pending || options.externalBusy(), valid = validPreview();
    panel.hidden = !visible; run.hidden = !visible;
    ui.refresh.disabled = busy;
    ui.validation.textContent = validation();
    ui.scan.disabled = busy || state.composing || !!validation();
    ui.scan.textContent = state.pending?.stage === 'scan' ? '구조 모델 검토 중…' : '구조 모델 검토';
    const parameterName = controls.targetParameterName.value.trim();
    ui.targetSummary.textContent = state.candidates.length && !valid ? `검토 당시 파라미터: ${state.reviewedParameterName} · 현재 설정으로 다시 검토하세요.` : parameterName ? `검토·입력 대상: ${parameterName} · 구조 기둥 인스턴스` : '검토·입력 대상 파라미터를 지정하세요.';
    ui.apply.title = parameterName ? `선택한 구조 기둥의 ${parameterName} 파라미터에 규칙으로 계산한 전체 번호를 입력합니다.` : '검토·입력 대상 파라미터를 지정하세요.';
    ui.apply.hidden = !controls.writeEnabled.checked;
    ui.apply.disabled = busy || state.composing || !!validation() || !controls.writeEnabled.checked || !valid || !selectedIds().length;
    ui.apply.textContent = state.pending?.stage === 'apply' ? '번호 입력 중…' : '선택한 기둥에 번호 입력';
    const count = state.candidates.filter(writable).length;
    ui.selectAll.disabled = busy || !valid || !controls.writeEnabled.checked || !count;
    ui.selectAll.checked = count > 0 && selectedIds().length === count;
    ui.selectAll.indeterminate = selectedIds().length > 0 && selectedIds().length < count;
    ui.rows.querySelectorAll('input[data-structure-candidate]').forEach(node => {
      const row = state.candidates.find(item => str(item.id) === node.dataset.structureCandidate) || {};
      node.disabled = busy || !valid || !controls.writeEnabled.checked || !writable(row); node.checked = state.selected.has(node.dataset.structureCandidate);
      const reason = str(row.status).toLowerCase() === 'match' ? '이미 규칙과 일치하여 번호를 입력할 필요가 없습니다.' : !writable(row) ? str(row.reason) || '수정할 수 없는 행입니다. 상태와 사유를 확인하세요.' : busy ? '요청을 처리하고 있습니다. 완료 후 선택하세요.' : !valid ? '검토 조건이 변경되었거나 입력을 완료했습니다. 다시 검토하세요.' : !controls.writeEnabled.checked ? '규칙에 맞게 번호 입력 옵션을 켜면 이 행을 선택할 수 있습니다.' : '이 기둥의 번호를 입력 대상으로 선택합니다.';
      node.title = reason; node.parentElement.title = reason;
    });
    if (valid) ui.previewNote.textContent = controls.writeEnabled.checked ? `빈 값·불일치 행을 선택하면 ${state.reviewedParameterName}에 입력할 수 있습니다. 일치하는 값은 변경하지 않습니다.` : '검토를 완료했습니다. 번호를 수정하려면 규칙에 맞게 번호 입력 옵션을 켜세요. 모델은 변경하지 않았습니다.';
    ui.selectionSummary.textContent = valid ? controls.writeEnabled.checked ? `입력 가능한 ${count}개 중 ${selectedIds().length}개 선택` : '현재 설정의 검토 결과입니다. 모델은 변경하지 않았습니다.' : state.candidates.length ? '설정이 변경되었습니다. 구조 모델을 다시 검토하세요.' : '타입과 기준 높이를 선택한 뒤 검토하세요.';
    ui.results.hidden = !state.hasResults;
    const max = Math.max(1, Math.ceil(state.candidates.length / 100));
    ui.pageLabel.textContent = `${state.page} / ${max}`; ui.previous.disabled = state.page <= 1; ui.next.disabled = state.page >= max;
    // An in-flight link request may finish after the third tab was opened.
    if (visible && !state.contextAttempted && !busy) queueMicrotask(ensureContext);
  }
  function invalidate() { const hadPreview = !!state.previewSignature; state.previewSignature = ''; state.scanRequestId = ''; if (hadPreview) ui.previewNote.textContent = '설정이 변경되었습니다. 구조 모델을 다시 검토하세요.'; sync(); }
  function renderRows() {
    const fragment = document.createDocumentFragment();
    state.candidates.slice((state.page - 1) * 100, state.page * 100).forEach(row => {
      const tr = document.createElement('tr'); tr.dataset.status = str(row.status);
      const cell = document.createElement('td'), check = document.createElement('input'); check.type = 'checkbox'; check.dataset.structureCandidate = str(row.id); check.dataset.columnnumberFocusKey = `structure-candidate-${row.id}`; check.setAttribute('aria-label', `${str(row.baseLevelName)} ${str(row.sourceName)} 번호 입력 선택`); cell.append(check); tr.append(cell);
      const note = str(row.ruleNote), reason = str(row.reason);
      [ [str(row.baseLevelName), str(row.sourceName), `ID ${str(row.sourceElementId)}`].filter(Boolean).join('\n'), [str(row.typeName), `지정: ${kindLabel(row.declaredKind)}`, `판정: ${kindLabel(row.kind)}`].join('\n'), str(row.expectedFullNumber) || '—', str(row.actualFullNumber) || '—', [structureStatus(row.status), reason, note && !reason.includes(note) ? note : '', writable(row) ? '인스턴스 번호 입력 가능' : ''].filter(Boolean).join('\n') ].forEach(value => { const td = document.createElement('td'); td.textContent = value; tr.append(td); });
      fragment.append(tr);
    });
    if (!fragment.childNodes.length) { const tr = document.createElement('tr'), td = document.createElement('td'); td.colSpan = 6; td.className = 'columnnumber-empty'; td.textContent = '현재 조건의 검토 대상이 없습니다.'; tr.append(td); fragment.append(tr); }
    ui.rows.replaceChildren(fragment); sync();
  }
  function fillOptions(control, values, label, empty) {
    const items = values.length ? values.map(item => ({ id: str(item.elementId), label: label(item) })) : [{ id: '', label: empty }];
    const key = JSON.stringify(items); if (control.dataset.optionsSignature === key) return;
    const selected = new Set([...control.selectedOptions].map(item => item.value)), top = control.scrollTop, left = control.scrollLeft;
    control.replaceChildren(...items.map(item => { const option = document.createElement('option'); option.value = item.id; option.textContent = item.label; option.selected = !!item.id && selected.has(item.id); return option; }));
    control.dataset.optionsSignature = key; control.scrollTop = top; control.scrollLeft = left;
  }
  function applyContext(payload, angleRevision) {
    if (state.resetSelection || (state.document && !sameDocument(state.document, payload.document))) {
      ['mainTypeElementIds', 'studTypeElementIds', 'baseLevelElementIds'].forEach(key => { [...controls[key].options].forEach(option => { option.selected = false; }); });
      controls.writeEnabled.checked = false; state.angleInitialized = false; state.angleDirty = state.angleRevision !== angleRevision;
    }
    state.resetSelection = false; state.document = normalizeDocument(payload.document); state.ready = !!state.document;
    ui.document.textContent = str(state.document?.title || state.document?.name || '열린 프로젝트가 없습니다.'); ui.document.title = str(state.document?.path);
    ['mainTypeElementIds', 'studTypeElementIds'].forEach(key => fillOptions(controls[key], payload.columnTypes || [], item => `${str(item.familyName)} · ${str(item.typeName)} (${item.instanceCount || 0}개)`, '구조 기둥 타입이 없습니다.'));
    fillOptions(controls.baseLevelElementIds, payload.levels || [], item => `${str(item.name)} (${format(item.elevationMillimeters)} mm)`, '레벨이 없습니다.');
    if (!state.angleInitialized && !state.angleDirty) { const angle = numeric(payload.gridAxisAngleDegrees ?? 0); controls.gridAxisAngleDegrees.value = str(Number.isFinite(angle) ? angle : 0); }
    state.angleInitialized = true; feedback(payload.message || '구조 프로젝트 정보를 불러왔습니다.'); sync(); options.changed();
  }
  function request(stage) {
    if (!options.active() || state.pending || options.externalBusy() || state.composing) return false;
    if (stage !== 'init' && validation()) { feedback(validation(), 'error'); sync(); return false; }
    if (stage === 'apply' && (!controls.writeEnabled.checked || !validPreview() || !selectedIds().length)) { feedback('현재 조건으로 검토한 뒤 번호 입력 옵션을 켜고 수정할 행의 체크박스를 선택하세요.', 'error'); sync(); return false; }
    const requestId = `columnnumber-${Date.now()}-${++serial}-structure-${stage}`;
    const payload = stage === 'init' ? { selectedDocument: options.document(), requestId } : { ...settings(), requestId };
    if (stage === 'apply') { payload.candidateIds = selectedIds(); payload.scanRequestId = state.scanRequestId; }
    if (stage === 'init') { state.contextAttempted = true; state.deferredContext = null; }
    if (stage === 'init' || stage === 'scan') invalidate();
    state.pending = { stage, requestId, signature: signature(), targetParameterName: payload.targetParameterName, angleRevision: state.angleRevision, exportDocument: cloneColumnNumberValue(payload.selectedDocument), exportSettings: describeColumnNumberSettings(payload, controls) };
    feedback(stage === 'init' ? '구조 프로젝트 정보를 불러오는 중입니다.' : stage === 'scan' ? '구조 기둥의 번호를 검토하고 있습니다.' : '선택한 기둥의 인스턴스 번호를 입력하고 있습니다.'); sync(); options.changed();
    try { if (options.sender(`columnnumber:structure-${stage}`, payload) !== false) return true; } catch { /* Keep mounted editors usable after a disconnected host. */ }
    state.pending = null; feedback('Revit에 요청을 전달하지 못했습니다. 연결 상태를 확인하세요.', 'error'); sync(); options.changed(); return false;
  }
  function receive(event, payload) {
    const pending = state.pending;
    if (!pending || payload.requestId !== pending.requestId) return false;
    const expected = `columnnumber:structure-${{ init: 'context', scan: 'preview', apply: 'result' }[pending.stage]}`;
    if (event !== expected && event !== COLUMN_NUMBER_EVENTS.error) return false;
    state.pending = null;
    if (event === COLUMN_NUMBER_EVENTS.error || (payload.ok === false && pending.stage !== 'apply')) { if (pending.stage === 'init') state.ready = false; invalidate(); feedback(payload.message || '구조 모델 요청을 처리하지 못했습니다.', 'error'); sync(); options.changed(); return true; }
    if (pending.stage === 'init') {
      if (editingContext()) { state.deferredContext = { payload, angleRevision: pending.angleRevision }; feedback('프로젝트 정보를 불러왔습니다. 현재 입력을 마치면 목록이 반영됩니다.'); }
      else applyContext(payload, pending.angleRevision);
    } else if (pending.stage === 'scan') {
      if (pending.signature !== signature()) { invalidate(); feedback('검토 중 설정이 변경되었습니다. 구조 모델을 다시 검토하세요.'); sync(); options.changed(); return true; }
      state.candidates = Array.isArray(payload.candidates) ? payload.candidates : []; state.selected.clear(); state.page = 1; state.hasResults = false;
      state.reviewedParameterName = pending.targetParameterName;
      state.previewSignature = pending.signature; state.scanRequestId = pending.requestId;
      const summary = payload.summary || {};
      ui.counts.textContent = `전체 ${summary.columnCount ?? state.candidates.length} · 일치 ${summary.matchCount || 0} · 불일치 ${summary.mismatchCount || 0} · 번호 없음 ${summary.emptyCount || 0} · 오류 ${summary.errorCount || 0} · 입력 가능 ${summary.writableCount || 0}`;
      ui.previewNote.textContent = controls.writeEnabled.checked ? '예상 번호를 확인하고 입력할 불일치·빈 번호 행을 선택하세요. 검토만으로는 모델이 변경되지 않습니다.' : '검토를 완료했습니다. 번호 입력 옵션은 꺼져 있으며 모델을 변경하지 않았습니다.';
      renderRows(); feedback(payload.message || '구조 모델 검토가 완료되었습니다.');
      options.exporter.capture('structure-preview', pending, payload.candidates || [], [ui.counts.textContent, payload.message].filter(Boolean).join('\n'));
    } else {
      invalidate(); state.hasResults = true;
      ui.resultSummary.textContent = `입력 ${payload.updatedCount || 0} · 건너뜀 ${payload.skippedCount || 0} · 실패 ${payload.failedCount || 0}`;
      ui.resultRows.replaceChildren(...(payload.rows || []).map(row => { const item = document.createElement('div'); item.className = 'columnnumber-result-row'; item.textContent = [str(row.baseLevelName), `ID ${str(row.sourceElementId)}`, structureStatus(row.status), str(row.message)].filter(Boolean).join(' · '); return item; }));
      options.exporter.capture('structure-result', pending, payload.rows || [], [ui.resultSummary.textContent, payload.message].filter(Boolean).join('\n'));
      feedback(payload.message || '선택한 기둥의 번호 입력 처리가 완료되었습니다. 결과를 확인하세요.', payload.ok === false || payload.failedCount ? 'error' : 'ok');
    }
    sync(); options.changed(); return true;
  }
  function flushContext() { if (!options.active() || !state.deferredContext || editingContext()) return; const deferred = state.deferredContext; state.deferredContext = null; applyContext(deferred.payload, deferred.angleRevision); }
  function ensureContext() { if (options.active() && options.visible() && !state.contextAttempted && !state.pending && !options.externalBusy()) request('init'); }
  function resetDocument() {
    state.pending = null; state.ready = false; state.document = null; state.contextAttempted = false; state.resetSelection = true; state.deferredContext = null; state.candidates = []; state.selected.clear(); state.previewSignature = ''; state.scanRequestId = ''; state.reviewedParameterName = ''; state.page = 1; state.hasResults = false; controls.writeEnabled.checked = false;
    ['mainTypeElementIds', 'studTypeElementIds', 'baseLevelElementIds'].forEach(key => { [...controls[key].options].forEach(option => { option.selected = false; }); });
    ui.document.textContent = '활성 문서가 변경되었습니다.'; ui.counts.textContent = '검토 전'; ui.previewNote.textContent = '문서가 변경되었습니다. 다시 검토하세요.'; renderRows();
  }
  Object.values(controls).forEach(control => {
    const changed = () => {
      if (control === controls.writeEnabled) { if (!control.checked) state.selected.clear(); sync(); options.changed(); return; }
      if (control === controls.gridAxisAngleDegrees) { state.angleDirty = true; state.angleRevision++; }
      invalidate(); options.changed();
    };
    listen(control, 'input', changed); listen(control, 'change', changed);
    listen(control, 'compositionstart', () => { state.composing = true; sync(); });
    listen(control, 'compositionend', () => { state.composing = false; invalidate(); flushContext(); ensureContext(); });
    listen(control, 'blur', () => queueMicrotask(flushContext));
  });
  listen(ui.refresh, 'click', () => request('init')); listen(ui.scan, 'click', () => request('scan')); listen(ui.apply, 'click', () => request('apply'));
  listen(ui.selectAll, 'change', () => { if (!validPreview() || state.pending || !controls.writeEnabled.checked) return; state.selected = new Set(ui.selectAll.checked ? state.candidates.filter(writable).map(row => str(row.id)) : []); sync(); });
  listen(ui.rows, 'change', event => { const node = event.target; if (!node.matches('input[data-structure-candidate]') || !validPreview() || state.pending || !controls.writeEnabled.checked) return; const row = state.candidates.find(item => str(item.id) === node.dataset.structureCandidate); if (!row || !writable(row)) return; node.checked ? state.selected.add(node.dataset.structureCandidate) : state.selected.delete(node.dataset.structureCandidate); sync(); });
  listen(ui.previous, 'click', () => { if (state.page > 1) { state.page--; renderRows(); } }); listen(ui.next, 'click', () => { if (state.page < Math.ceil(state.candidates.length / 100)) { state.page++; renderRows(); } });
  return { sync, receive, request, ensureContext, resetDocument, busy: () => !!state.pending, getState: () => ({ ready: state.ready, busy: state.pending?.stage || '', settings: settings(), previewValid: validPreview(), selectedCandidateIds: selectedIds(), candidates: state.candidates, scanRequestId: state.scanRequestId }) };
}

function createColumnNumberPicker(select, key, options) {
  const oldLabel = select.parentElement;
  const labelText = [...oldLabel.childNodes].filter(node => node.nodeType === Node.TEXT_NODE).map(node => node.textContent).join('').trim();
  const field = document.createElement('div'); field.className = `columnnumber-field ${oldLabel.className}`.trim(); field.dataset.picker = key;
  const heading = document.createElement('span'); heading.className = 'columnnumber-picker-label'; heading.textContent = labelText;
  const search = document.createElement('input'); search.type = 'search'; search.autocomplete = 'off'; search.placeholder = '이름 검색'; search.dataset.pickerSearch = key; search.dataset.columnnumberFocusKey = `picker-search-${key}`; search.setAttribute('aria-label', `${labelText} 검색`);
  const count = document.createElement('span'); count.className = 'columnnumber-note'; count.dataset.pickerCount = key;
  field.append(heading, search); oldLabel.replaceWith(field); field.append(select); select.setAttribute('aria-label', labelText);
  let list = null, all = null, clear = null, optionSignature = '', composing = false;
  if (select.multiple) {
    select.classList.add('columnnumber-select-model'); select.tabIndex = -1; select.setAttribute('aria-hidden', 'true');
    const toolbar = document.createElement('div'); toolbar.className = 'columnnumber-picker-toolbar';
    all = document.createElement('button'); all.type = 'button'; all.className = 'btn'; all.textContent = '검색 결과 전체 선택'; all.dataset.pickerAll = key;
    clear = document.createElement('button'); clear.type = 'button'; clear.className = 'btn'; clear.textContent = '검색 결과 선택 해제'; clear.dataset.pickerClear = key;
    toolbar.append(all, clear); list = document.createElement('div'); list.className = 'columnnumber-picker-list'; list.dataset.pickerList = key; list.dataset.columnnumberScrollKey = `picker-${key}`; list.setAttribute('role', 'group'); list.setAttribute('aria-label', labelText);
    field.append(toolbar, count, list);
  } else field.append(count);
  const matches = option => !!option.value && option.textContent.toLocaleLowerCase().includes(search.value.trim().toLocaleLowerCase());
  function sync() {
    const values = [...select.options].filter(option => !!option.value);
    const byValue = new Map(values.map(option => [option.value, option]));
    const matched = values.filter(matches), selected = values.filter(option => option.selected);
    count.textContent = select.multiple ? `선택 ${selected.length}개 · 검색 ${matched.length} / 전체 ${values.length}개` : `검색 ${matched.length} / 전체 ${values.length}개${selected.length ? ' · 현재 선택 유지' : ''}`;
    if (!list) { [...select.options].forEach(option => { option.hidden = !!option.value && !matches(option); }); return; }
    const signature = JSON.stringify(values.map(option => [option.value, option.textContent, option.disabled]));
    if (signature !== optionSignature) {
      const top = list.scrollTop, left = list.scrollLeft;
      list.replaceChildren(...values.map(option => { const label = document.createElement('label'); label.className = 'columnnumber-picker-option'; const check = document.createElement('input'); check.type = 'checkbox'; check.value = option.value; check.dataset.pickerValue = key; check.dataset.columnnumberFocusKey = `picker-${key}-${option.value}`; const text = document.createElement('span'); text.textContent = option.textContent; label.append(check, text); return label; }));
      const empty = document.createElement('p'); empty.className = 'columnnumber-note'; empty.dataset.pickerEmpty = key; empty.textContent = '검색 결과가 없습니다.'; list.append(empty);
      list.scrollTop = top; list.scrollLeft = left; optionSignature = signature;
    }
    list.querySelectorAll('input[data-picker-value]').forEach(check => { const option = byValue.get(check.value); check.checked = !!option?.selected; check.disabled = select.disabled || !!option?.disabled; check.parentElement.hidden = !option || !matches(option); });
    const empty = list.querySelector('[data-picker-empty]'); if (empty) empty.hidden = matched.length > 0;
    all.disabled = select.disabled || !matched.some(option => !option.disabled && !option.selected);
    clear.disabled = select.disabled || !matched.some(option => !option.disabled && option.selected);
  }
  function commit(change) {
    let changed = false;
    [...select.options].forEach(option => { const value = change(option); if (typeof value === 'boolean' && !option.disabled && !!option.value && option.selected !== value) { option.selected = value; changed = true; } });
    if (changed) select.dispatchEvent(new Event('change', { bubbles: true }));
    sync();
  }
  options.listen(search, 'input', () => { if (!composing) sync(); });
  options.listen(search, 'compositionstart', () => { composing = true; options.composition(true); });
  options.listen(search, 'compositionend', () => { composing = false; sync(); options.composition(false); });
  options.listen(field, 'focusout', options.blur);
  if (list) {
    options.listen(list, 'change', event => { if (!event.target.matches('input[data-picker-value]')) return; commit(option => option.value === event.target.value ? event.target.checked : undefined); });
    options.listen(all, 'click', () => commit(option => matches(option) ? true : undefined));
    options.listen(clear, 'click', () => commit(option => matches(option) ? false : undefined));
  }
  sync();
  return { sync, hasFocus: () => field.contains(document.activeElement) };
}

const cloneColumnNumberValue = value => value == null ? null : JSON.parse(JSON.stringify(value));
function describeColumnNumberSettings(settings, controls) {
  const labels = { linkElementId: '구조 링크', familyElementId: '기둥넘버 패밀리', mainSmallSymbolId: '주기둥 소형 타입', mainMediumSymbolId: '주기둥 중형 타입', mainLargeSymbolId: '주기둥 대형 타입', studSmallSymbolId: '샛기둥 타입', mainTypeElementIds: '구조 주기둥 타입', studTypeElementIds: '구조 샛기둥 타입', baseLevelElementIds: '기준 레벨', offsetMillimeters: '레벨에서 높이 (mm)', sourceParameterName: '원본 기둥 전체 번호 파라미터', sourceParameterScope: '원본 파라미터 위치', targetParameterName: '전체 번호 인스턴스 파라미터', sourceCombinedParameterName: '원본 전체 번호 파라미터', sourceCombinedParameterScope: '원본 전체 번호 위치', sourceNumberSeparator: '원본 번호 구분자', numberSeparator: '전체 번호 구분자', positionToleranceMillimeters: '중심 위치 허용 오차 (mm)', gridToleranceMillimeters: '그리드 판정 허용 오차 (mm)', gridAxisAngleDegrees: '번호 기준 방향 (°)', interiorMode: '내부 샛기둥 번호 규칙', gridNameOrder: '그리드명 조합 순서', writeNumbers: '기둥·샛기둥 Number 입력', fillMissingNumbersByRule: '원본 번호가 없으면 위치·그리드 규칙으로 채우기', writeEnabled: '구조 기둥 번호 입력 허용', skipExisting: '기존 배치 건너뛰기' };
  const result = Object.entries(labels).filter(([key]) => Object.prototype.hasOwnProperty.call(settings, key)).map(([key, label]) => {
    const raw = settings[key], control = controls[key] || (key === 'baseLevelElementIds' ? controls.baseLevelElementId : null);
    const describe = value => { const option = control?.tagName === 'SELECT' ? [...control.options].find(item => item.value === str(value)) : null; return option && value !== '' ? `${option.textContent} [${str(value)}]` : str(value) || '미지정'; };
    const value = Array.isArray(raw) ? raw.map(describe).join('\n') || '선택 없음' : typeof raw === 'boolean' ? raw ? '사용' : '사용 안 함' : describe(raw);
    return { label, value };
  });
  if (settings.familyElementId) result.push({ label: '번호 입력 파라미터', value: 'Column Number / Stud Number' }, { label: '치수 입력 파라미터', value: 'Column_Width 1 / Column_Width 2' });
  return result;
}
function createColumnNumberExporter(options) {
  const widgets = new Map(), snapshots = new Map();
  let pending = null;
  function sync() {
    const busy = !!pending || options.externalBusy();
    widgets.forEach((widget, kind) => {
      const snapshot = snapshots.get(kind);
      widget.button.disabled = busy || !snapshot;
      widget.button.textContent = pending?.kind === kind ? '엑셀로 내보내는 중…' : '엑셀로 내보내기';
      widget.note.textContent = snapshot ? `검토 당시 결과 · 전체 ${snapshot.rows.length}행${Array.isArray(snapshot.mappingRows) ? ` · 원본·넘버 연결 ${snapshot.mappingRows.length}행` : ''} · 검색·선택·페이지와 무관하게 내보냅니다.` : '결과가 생성되면 전체 행을 내보낼 수 있습니다.';
    });
  }
  function request(kind) {
    if (!options.active() || pending || options.externalBusy() || !snapshots.has(kind)) return false;
    const requestId = `columnnumber-${Date.now()}-${++serial}-export`;
    pending = { requestId, kind };
    const widget = widgets.get(kind); widget.feedback.textContent = '엑셀 파일을 저장할 위치를 선택하세요.'; widget.feedback.dataset.tone = '';
    sync(); options.changed();
    try { if (options.sender('columnnumber:export', { ...cloneColumnNumberValue(snapshots.get(kind)), requestId }) !== false) return true; } catch { /* Export failures must preserve the editable form and result snapshot. */ }
    pending = null; widget.feedback.textContent = '내보내기 요청을 전달하지 못했습니다. 연결 상태를 확인하세요.'; widget.feedback.dataset.tone = 'error'; sync(); options.changed(); return false;
  }
  function register(panel, kind) {
    const bar = document.createElement('div'); bar.className = 'columnnumber-export';
    const button = document.createElement('button'); button.type = 'button'; button.className = 'btn'; button.dataset.exportKind = kind; button.textContent = '엑셀로 내보내기'; button.disabled = true;
    const note = document.createElement('span'); note.className = 'columnnumber-note'; note.dataset.exportNote = kind;
    const feedback = document.createElement('p'); feedback.className = 'columnnumber-feedback'; feedback.dataset.exportFeedback = kind; feedback.setAttribute('role', 'status'); feedback.setAttribute('aria-live', 'polite');
    bar.append(button, note, feedback); panel.querySelector('.columnnumber-head')?.after(bar);
    widgets.set(kind, { button, note, feedback }); options.listen(button, 'click', () => request(kind));
  }
  function capture(kind, submitted, rows, summary, response = {}) {
    const snapshot = { kind, document: submitted.exportDocument, generatedAt: new Date().toISOString(), summary, settings: submitted.exportSettings, rows };
    if (kind === 'placement-result' && Array.isArray(response.mappingRows)) Object.assign(snapshot, { mappingRows: response.mappingRows, mappingMessage: str(response.mappingMessage), capturedAtUtc: str(response.capturedAtUtc) });
    snapshots.set(kind, cloneColumnNumberValue(snapshot));
    const widget = widgets.get(kind); if (widget) { widget.feedback.textContent = ''; widget.feedback.dataset.tone = ''; } sync();
  }
  function clear() { pending = null; snapshots.clear(); widgets.forEach(widget => { widget.feedback.textContent = ''; }); sync(); }
  function receive(event, payload) {
    if (!pending || payload.requestId !== pending.requestId) return false;
    if (event !== 'columnnumber:export-result' && event !== COLUMN_NUMBER_EVENTS.error) return false;
    const widget = widgets.get(pending.kind); pending = null;
    widget.feedback.textContent = payload.message || (payload.cancelled ? '엑셀 내보내기를 취소했습니다.' : payload.ok === true ? `엑셀 ${payload.rowCount ?? 0}행을 저장했습니다.` : '엑셀 내보내기를 완료하지 못했습니다.');
    widget.feedback.dataset.tone = payload.cancelled ? '' : payload.ok === true ? 'ok' : 'error'; sync(); options.changed(); return true;
  }
  return { register, capture, clear, sync, receive, busy: () => !!pending };
}
