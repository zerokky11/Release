import { accRvtIdentity, accRvtBelongsTo } from './accRvt.js';
// Resources/HubUI/js/core/workflowState3.js
export const WORKFLOW3_CHANGE_EVENT = 'kkyt:workflow3-changed';

const STORAGE_KEY = 'kky.hub.workflow3.v2';
const DEFAULT_SELECTED = Object.freeze({
  bqc: [],
  utility: [],
  favorites: []
});
const DEFAULT_FEATURE_ORDER = Object.freeze({
  bqc: [],
  utility: [],
  favorites: []
});

let memoryState = readInitialState();

window.addEventListener('kky:shared-settings-changed', hydrateSharedWorkflowState);

export function getWorkflowState3() {
  return cloneState(memoryState);
}

export function getSelectedFeatureIds3(mode = 'bqc') {
  const key = normalizeMode(mode);
  return normalizeIdList(memoryState.selected?.[key] || []);
}

export function setSelectedFeatureIds3(mode, ids) {
  const key = normalizeMode(mode);
  updateState((state) => {
    state.selected[key] = orderIdsByFeatureOrder(normalizeIdList(ids), state.featureOrder?.[key]);
  }, { kind: 'selection', mode: key });
  return getSelectedFeatureIds3(key);
}

export function toggleSelectedFeature3(mode, id, force) {
  const key = normalizeMode(mode);
  const entryId = String(id || '').trim();
  if (!entryId) return getSelectedFeatureIds3(key);
  const current = new Set(getSelectedFeatureIds3(key));
  const shouldSelect = typeof force === 'boolean' ? force : !current.has(entryId);
  if (shouldSelect) current.add(entryId);
  else current.delete(entryId);
  return setSelectedFeatureIds3(key, Array.from(current));
}

export function setPresetInfo3(mode, info = {}) {
  const key = normalizeMode(mode);
  updateState((state) => {
    state.presets[key] = {
      name: String(info.name || '').trim(),
      path: String(info.path || '').trim(),
      source: String(info.source || '').trim()
    };
  }, { kind: 'preset', mode: key });
}

export function getPresetInfo3(mode = 'bqc') {
  const key = normalizeMode(mode);
  const item = memoryState.presets?.[key] || {};
  return {
    name: String(item.name || '').trim(),
    path: String(item.path || '').trim(),
    source: String(item.source || '').trim()
  };
}

export function getFeatureOrder3(mode = 'bqc') {
  const key = normalizeMode(mode);
  return normalizeIdList(memoryState.featureOrder?.[key] || []);
}

export function setFeatureOrder3(mode, ids) {
  const key = normalizeMode(mode);
  const order = normalizeIdList(ids);
  updateState((state) => {
    state.featureOrder[key] = order;
    state.selected[key] = orderIdsByFeatureOrder(state.selected?.[key], order);
  }, { kind: 'feature-order', mode: key });
  return getFeatureOrder3(key);
}

export function getRvtTargets3() {
  const targets = Array.isArray(memoryState.rvtTargets) ? memoryState.rvtTargets : [];
  return targets.map((target) => ({
    path: String(target.path || '').trim(),
    checked: !!target.checked
  })).filter((target) => target.path);
}

export function getCheckedRvtPaths3() {
  return getRvtTargets3()
    .filter((target) => target.checked)
    .map((target) => target.path);
}

export function setRvtTargets3(paths, checkedPaths) {
  const pathList = normalizePathList(paths);
  const checked = new Set(normalizePathList(Array.isArray(checkedPaths) ? checkedPaths : pathList).map((path) => path.toLowerCase()));
  updateState((state) => {
    state.rvtTargets = pathList.map((path) => ({ path, checked: checked.has(path.toLowerCase()) }));
  }, { kind: 'rvt', action: 'set' });
  return getRvtTargets3();
}

export function removeOtherAccUsers3(ownerKey) {
  const current = getRvtTargets3();
  const kept = current.filter((target) => accRvtBelongsTo(target.path, ownerKey));
  if (kept.length === current.length) return;
  updateState((state) => { state.rvtTargets = kept; }, { kind: 'rvt', action: 'account-change' });
}

export function addRvtTargets3(paths) {
  const incoming = normalizePathList(paths);
  if (!incoming.length) return { added: 0, targets: getRvtTargets3() };
  let added = 0;
  updateState((state) => {
    const targets = normalizeRvtTargets(state.rvtTargets);
    const byKey = new Map(targets.map((target) => [accRvtIdentity(target.path), target]));
    incoming.forEach((path) => {
      const key = accRvtIdentity(path);
      if (!byKey.has(key)) {
        byKey.set(key, { path, checked: true });
        added += 1;
      } else {
        byKey.get(key).path = path;
        byKey.get(key).checked = true;
      }
    });
    state.rvtTargets = Array.from(byKey.values());
  }, { kind: 'rvt', action: 'add' });
  return { added, targets: getRvtTargets3() };
}

export function toggleRvtTarget3(path, checked) {
  const key = String(path || '').trim().toLowerCase();
  if (!key) return getRvtTargets3();
  updateState((state) => {
    state.rvtTargets = normalizeRvtTargets(state.rvtTargets).map((target) => (
      target.path.toLowerCase() === key ? { ...target, checked: !!checked } : target
    ));
  }, { kind: 'rvt', action: 'toggle' });
  return getRvtTargets3();
}

export function setAllRvtTargetsChecked3(checked) {
  updateState((state) => {
    state.rvtTargets = normalizeRvtTargets(state.rvtTargets).map((target) => ({ ...target, checked: !!checked }));
  }, { kind: 'rvt', action: checked ? 'select-all' : 'deselect-all' });
  return getRvtTargets3();
}

export function removeCheckedRvtTargets3() {
  let removed = 0;
  updateState((state) => {
    const before = normalizeRvtTargets(state.rvtTargets);
    const next = before.filter((target) => !target.checked);
    removed = before.length - next.length;
    state.rvtTargets = next;
  }, { kind: 'rvt', action: 'remove-checked' });
  return { removed, targets: getRvtTargets3() };
}

export function clearRvtTargets3() {
  updateState((state) => {
    state.rvtTargets = [];
  }, { kind: 'rvt', action: 'clear' });
  return getRvtTargets3();
}

function updateState(mutator, detail = {}) {
  const next = cloneState(memoryState);
  mutator(next);
  memoryState = normalizeState(next);
  persistState(memoryState);
  emitChange(detail);
}

function readInitialState() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    return normalizeState(raw);
  } catch {
    return normalizeState(null);
  }
}

function hydrateSharedWorkflowState(event) {
  const detail = event?.detail;
  const keys = Array.isArray(detail?.keys) ? detail.keys : [];
  if (detail?.key) keys.push(detail.key);
  if (keys.length && !keys.includes(STORAGE_KEY)) return;

  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    const sharedState = normalizeState(raw);
    const localState = normalizeState(memoryState);
    memoryState = normalizeState({
      ...sharedState,
      presets: {
        bqc: { ...sharedState.presets.bqc, path: localState.presets.bqc.path },
        utility: { ...sharedState.presets.utility, path: localState.presets.utility.path },
        favorites: { ...sharedState.presets.favorites, path: localState.presets.favorites.path }
      },
      rvtTargets: localState.rvtTargets
    });
    emitChange({ kind: 'shared-settings', source: detail?.source || 'host' });
  } catch {
    // Keep the in-memory state if a malformed external value is received.
  }
}

function persistState(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Embedded hosts may block localStorage.
  }
}

function normalizeState(raw) {
  const selected = raw && typeof raw.selected === 'object' ? raw.selected : {};
  const presets = raw && typeof raw.presets === 'object' ? raw.presets : {};
  const featureOrder = raw && typeof raw.featureOrder === 'object' ? raw.featureOrder : {};
  const rvtTargets = normalizeRvtTargets(raw?.rvtTargets);
  return {
    featureOrder: {
      bqc: normalizeIdList(featureOrder.bqc || DEFAULT_FEATURE_ORDER.bqc),
      utility: normalizeIdList(featureOrder.utility || DEFAULT_FEATURE_ORDER.utility),
      favorites: normalizeIdList(featureOrder.favorites || DEFAULT_FEATURE_ORDER.favorites)
    },
    selected: {
      bqc: orderIdsByFeatureOrder(normalizeIdList(selected.bqc || DEFAULT_SELECTED.bqc), featureOrder.bqc),
      utility: orderIdsByFeatureOrder(normalizeIdList(selected.utility || DEFAULT_SELECTED.utility), featureOrder.utility),
      favorites: orderIdsByFeatureOrder(normalizeIdList(selected.favorites || DEFAULT_SELECTED.favorites), featureOrder.favorites)
    },
    presets: {
      bqc: normalizePreset(presets.bqc),
      utility: normalizePreset(presets.utility),
      favorites: normalizePreset(presets.favorites)
    },
    rvtTargets
  };
}

function orderIdsByFeatureOrder(ids, order) {
  const list = normalizeIdList(ids);
  const rank = new Map(normalizeIdList(order).map((id, index) => [id, index]));
  return list
    .map((id, index) => ({ id, index, rank: rank.has(id) ? rank.get(id) : Number.MAX_SAFE_INTEGER }))
    .sort((left, right) => left.rank - right.rank || left.index - right.index)
    .map((item) => item.id);
}

function normalizePreset(raw) {
  return {
    name: String(raw?.name || '').trim(),
    path: String(raw?.path || '').trim(),
    source: String(raw?.source || '').trim()
  };
}

function normalizeMode(mode) {
  if (mode === 'utility') return 'utility';
  if (mode === 'favorites') return 'favorites';
  return 'bqc';
}

function normalizeIdList(ids) {
  const seen = new Set();
  return (Array.isArray(ids) ? ids : [])
    .map((id) => String(id || '').trim())
    .filter(Boolean)
    .filter((id) => {
      if (seen.has(id)) return false;
      seen.add(id);
      return true;
    });
}

function normalizePathList(paths) {
  const seen = new Set();
  return (Array.isArray(paths) ? paths : [])
    .map((path) => String(path || '').trim())
    .filter(Boolean)
    .filter((path) => /\.rvt$/i.test(path))
    .filter((path) => {
      const key = path.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function normalizeRvtTargets(raw) {
  const list = Array.isArray(raw) ? raw : [];
  const seen = new Set();
  return list
    .map((item) => {
      const path = typeof item === 'string' ? item : item?.path;
      return {
        path: String(path || '').trim(),
        checked: typeof item === 'object' ? item.checked !== false : true
      };
    })
    .filter((item) => item.path && /\.rvt$/i.test(item.path))
    .filter((item) => {
      const key = item.path.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function cloneState(state) {
  return JSON.parse(JSON.stringify(state || normalizeState(null)));
}

function emitChange(detail) {
  try {
    window.dispatchEvent(new CustomEvent(WORKFLOW3_CHANGE_EVENT, { detail }));
  } catch {
    // Ignore custom event failures.
  }
}
