import { toast, showExcelSavedDialog } from '../core/dom.js?v=20260731parameterexport1';
import { attachRvtDropZone } from '../core/rvtDrop.js';
import { attachExcelDropZone } from '../core/excelDrop.js';
import { onHost, post } from '../core/bridge.js';

const FEATURE_LABEL = '프로젝트 파일 내 Level 변경';
const DEFAULT_SYNC_COMMENT = 'KKY Tool - 프로젝트 파일 내 Level 변경';
const DRAFT_STORAGE_KEY = 'kky.levelchange.draft.v1';
const DRAFT_SAVE_DELAY_MS = 220;

let activeLevelChangeCleanup = null;
let levelChangeMountSequence = 0;

export function renderLevelChange(root) {
  activeLevelChangeCleanup?.();

  const target = root || document.getElementById('view-root') || document.getElementById('app');
  if (!target) return;
  target.replaceChildren();

  const draft = loadDraft();
  const state = {
    rvtPaths: normalizeRvtPaths(draft.rvtPaths),
    workbookPath: stringOf(draft.workbookPath),
    outputFolder: stringOf(draft.outputFolder),
    syncComment: stringOf(draft.syncComment) || DEFAULT_SYNC_COMMENT,
    imported: null,
    result: null,
    fileSearch: '',
    jobSearch: '',
    busyKind: '',
    activeRequest: null,
    initRequestId: '',
    initSnapshot: null,
    requestSerial: 0,
    instanceId: createInstanceId(),
    fieldRevisions: createFieldRevisions(),
    statusMessage: 'RVT 파일을 등록하고 Excel 작업 지시를 준비해 주세요.',
    statusTone: 'idle',
    progress: createEmptyProgress(),
    persistTimer: 0,
    interactionRestoreGeneration: 0,
    activePointerIds: new Set(),
    compositionActive: false,
    pendingContext: null,
    pendingContextTimer: 0,
    disposed: false,
    hostUnsubscribers: [],
    dropCleanups: [],
    interactionCleanup: null,
    ui: {}
  };

  const page = element('section', 'feature-shell levelchange-page');
  page.dataset.levelchangePage = '1';
  page.append(buildFeatureHeader(), buildWorkspace(state), buildRunPanel(state));
  target.append(page);
  state.ui.page = page;

  state.interactionCleanup = registerInteractionGuards(state);
  state.hostUnsubscribers = registerHostEvents(state);
  state.dropCleanups = registerDropZones(state);

  syncInputsFromState(state);
  syncRvtSurface(state);
  renderRvtRows(state);
  syncWorkbookSurface(state);
  renderValidationSurface(state);
  renderResultSurface(state);
  syncProgressSurface(state);
  syncActionState(state);
  setRunStatus(state, state.statusMessage, state.statusTone);

  const cleanup = () => {
    if (state.disposed) return;
    state.disposed = true;
    flushDraftSave(state);
    state.interactionCleanup?.();
    state.interactionCleanup = null;
    state.hostUnsubscribers.forEach((unsubscribe) => unsubscribe?.());
    state.hostUnsubscribers = [];
    state.dropCleanups.forEach((detach) => detach?.());
    state.dropCleanups = [];
    if (state.pendingContextTimer) window.clearTimeout(state.pendingContextTimer);
    state.pendingContextTimer = 0;
    state.pendingContext = null;
    state.activeRequest = null;
    state.initRequestId = '';
    state.initSnapshot = null;
    window.removeEventListener('hashchange', cleanupOnRouteChange);
    if (activeLevelChangeCleanup === cleanup) activeLevelChangeCleanup = null;
  };
  const cleanupOnRouteChange = () => {
    const route = String(location.hash || '').replace(/^#/, '').split('?')[0].toLowerCase();
    if (route !== 'levelchange') cleanup();
  };

  activeLevelChangeCleanup = cleanup;
  window.addEventListener('hashchange', cleanupOnRouteChange);
  state.initRequestId = createRequestId(state, 'init');
  state.initSnapshot = captureRequestSnapshot(state);
  if (post('levelchange:init', buildRequestPayload(state, state.initRequestId)) === false) {
    state.initRequestId = '';
    state.initSnapshot = null;
    setRunStatus(state, 'Revit에서 Level 변경 설정을 불러오지 못했습니다.', 'error');
  }
}

function buildFeatureHeader() {
  const header = element('header', 'feature-header levelchange-feature-header');
  const heading = element('div', 'feature-heading');
  heading.append(
    element('span', 'feature-kicker', 'Project Level Batch'),
    element('h2', 'feature-title', FEATURE_LABEL),
    element(
      'p',
      'feature-sub',
      '등록한 RVT를 모든 웍셋을 닫고 연 뒤, Excel의 Level·방향·거리대로 이동하고 파일별 영향·오류·동기화 결과를 기록합니다.'
    )
  );
  header.append(heading);
  return header;
}

function buildWorkspace(state) {
  const workspace = element('div', 'levelchange-workspace');
  setScrollKey(workspace, 'workspace');
  workspace.append(buildRvtCard(state), buildWorkbookCard(state), buildValidationCard(state));
  state.ui.workspace = workspace;
  return workspace;
}

function buildRvtCard(state) {
  const card = element('section', 'levelchange-card levelchange-card--rvts');
  card.dataset.levelchangeStep = 'rvt';
  const heading = buildStepHeading(
    '1',
    'RVT 파일 등록',
    'Level을 변경할 프로젝트 파일만 등록해 주세요. 중복 경로는 자동으로 제거됩니다.',
    '미등록'
  );
  state.ui.rvtStepState = heading.state;

  const toolbar = element('div', 'levelchange-toolbar levelchange-rvt-toolbar');
  const searchField = element('label', 'levelchange-search-field');
  searchField.append(element('span', 'levelchange-control-label', '등록 파일 검색'));
  const search = element('input', 'levelchange-input levelchange-search');
  search.type = 'search';
  search.placeholder = '파일명 또는 경로 검색';
  search.autocomplete = 'off';
  search.dataset.levelchangeRvtSearch = '1';
  setFocusKey(search, 'rvt-search');
  search.addEventListener('input', () => {
    state.fileSearch = search.value;
    renderRvtRows(state);
  });
  searchField.append(search);

  const actions = element('div', 'levelchange-toolbar-actions');
  const pickButton = actionButton('RVT 파일 추가', 'primary');
  pickButton.dataset.levelchangePickRvts = '1';
  setFocusKey(pickButton, 'pick-rvts');
  pickButton.addEventListener('click', () => beginRequest(
    state,
    'pick-rvts',
    'levelchange:pick-rvts',
    'RVT 파일 선택창을 여는 중입니다.'
  ));
  const clearButton = actionButton('모두 제거', 'secondary');
  clearButton.dataset.levelchangeClearRvts = '1';
  setFocusKey(clearButton, 'clear-rvts');
  clearButton.addEventListener('click', () => clearRvtPaths(state));
  actions.append(pickButton, clearButton);
  toolbar.append(searchField, actions);

  const dropZone = element('div', 'levelchange-drop-zone levelchange-rvt-drop');
  dropZone.tabIndex = 0;
  dropZone.setAttribute('role', 'button');
  dropZone.setAttribute('aria-label', 'RVT 파일 끌어다 놓기 또는 파일 선택창 열기');
  dropZone.dataset.controlKind = 'drop-zone';
  dropZone.dataset.levelchangeRvtDrop = '1';
  setFocusKey(dropZone, 'rvt-drop');
  const dropIcon = element('span', 'levelchange-drop-icon', 'RVT');
  dropIcon.setAttribute('aria-hidden', 'true');
  const dropCopy = element('div', 'levelchange-drop-copy');
  const dropTitle = element('strong', '', 'RVT 파일을 여기에 놓아 주세요');
  const dropHint = element('span', '', '등록한 파일은 원본 경로에서 처리되며, 중앙 파일은 임시 로컬로 열립니다.');
  dropCopy.append(dropTitle, dropHint);
  const dropCount = element('span', 'levelchange-count-badge', '0개');
  dropZone.append(dropIcon, dropCopy, dropCount);
  const openPickerFromDropZone = (event) => {
    if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
    if (event.type === 'keydown') event.preventDefault();
    pickButton.click();
  };
  dropZone.addEventListener('click', openPickerFromDropZone);
  dropZone.addEventListener('keydown', openPickerFromDropZone);

  const list = element('div', 'levelchange-file-list');
  list.dataset.levelchangeRvtList = '1';
  list.setAttribute('role', 'list');
  setScrollKey(list, 'rvt-list');
  const note = element(
    'p',
    'levelchange-inline-note',
    '실행 중 웍셋은 모두 닫힌 상태로 열리며, Level은 핀 해제 후 이동하고 다시 핀으로 고정됩니다.'
  );
  card.append(heading.root, toolbar, dropZone, list, note);

  Object.assign(state.ui, {
    rvtCard: card,
    rvtSearch: search,
    pickRvtButton: pickButton,
    clearRvtButton: clearButton,
    rvtDropZone: dropZone,
    rvtDropTitle: dropTitle,
    rvtDropHint: dropHint,
    rvtCountBadge: dropCount,
    rvtList: list
  });
  return card;
}

function buildWorkbookCard(state) {
  const card = element('section', 'levelchange-card levelchange-card--workbook');
  card.dataset.levelchangeStep = 'workbook';
  const heading = buildStepHeading(
    '2',
    'Excel 작업 지시',
    '양식에 파일별 Level 이름, 이동 방향(위/아래), 이동 거리(mm)를 입력한 뒤 다시 불러와 주세요.',
    '준비 필요'
  );
  state.ui.workbookStepState = heading.state;

  const actionRow = element('div', 'levelchange-workbook-actions');
  const exportButton = actionButton('Excel 양식 저장', 'primary');
  exportButton.dataset.levelchangeExportTemplate = '1';
  setFocusKey(exportButton, 'export-template');
  exportButton.addEventListener('click', () => exportTemplate(state));
  const pickButton = actionButton('작성한 Excel 선택', 'secondary');
  pickButton.dataset.levelchangePickWorkbook = '1';
  setFocusKey(pickButton, 'pick-workbook');
  pickButton.addEventListener('click', () => pickWorkbook(state));
  const importButton = actionButton('현재 Excel 다시 검증', 'secondary');
  importButton.dataset.levelchangeImportWorkbook = '1';
  setFocusKey(importButton, 'import-workbook');
  importButton.addEventListener('click', () => importWorkbook(state));
  actionRow.append(exportButton, pickButton, importButton);

  const pathField = element('label', 'levelchange-path-field');
  pathField.append(element('span', 'levelchange-control-label', 'Excel 파일 경로'));
  const workbookInput = element('input', 'levelchange-input levelchange-path-input');
  workbookInput.type = 'text';
  workbookInput.placeholder = 'C:\\...\\Project_Level_Change.xlsx';
  workbookInput.spellcheck = false;
  workbookInput.autocomplete = 'off';
  workbookInput.dataset.levelchangeWorkbookPath = '1';
  setFocusKey(workbookInput, 'workbook-path');
  workbookInput.addEventListener('input', () => {
    const next = workbookInput.value;
    if (next === state.workbookPath) return;
    state.workbookPath = next;
    markFieldChanged(state, 'workbookPath');
    const invalidated = invalidateImportedData(state);
    scheduleDraftSave(state);
    syncWorkbookSurface(state);
    if (invalidated) {
      renderValidationSurface(state);
      renderResultSurface(state);
    }
    syncActionState(state);
  });
  pathField.append(workbookInput);

  const dropZone = element('div', 'levelchange-drop-zone levelchange-workbook-drop');
  dropZone.dataset.controlKind = 'drop-zone';
  dropZone.dataset.levelchangeWorkbookDrop = '1';
  const dropIcon = element('span', 'levelchange-drop-icon levelchange-drop-icon--excel', 'XLSX');
  dropIcon.setAttribute('aria-hidden', 'true');
  const dropCopy = element('div', 'levelchange-drop-copy');
  const dropTitle = element('strong', '', '.xlsx 파일을 여기에 놓으면 바로 검증합니다');
  const dropHint = element('span', '', '양식을 Excel에서 저장한 뒤 놓으면 실행 행과 오류를 미리 확인할 수 있습니다.');
  dropCopy.append(dropTitle, dropHint);
  const workbookState = element('span', 'levelchange-state-chip', '미등록');
  dropZone.append(dropIcon, dropCopy, workbookState);

  const status = element('p', 'levelchange-workbook-status', 'RVT 파일을 등록하면 빈 Excel 양식을 저장할 수 있습니다.');
  status.setAttribute('aria-live', 'polite');
  card.append(heading.root, actionRow, pathField, dropZone, status);

  Object.assign(state.ui, {
    workbookCard: card,
    exportTemplateButton: exportButton,
    pickWorkbookButton: pickButton,
    importWorkbookButton: importButton,
    workbookInput,
    workbookDropZone: dropZone,
    workbookDropTitle: dropTitle,
    workbookDropHint: dropHint,
    workbookState,
    workbookStatus: status
  });
  return card;
}

function buildValidationCard(state) {
  const card = element('section', 'levelchange-card levelchange-card--validation');
  card.dataset.levelchangeStep = 'validation';
  const heading = buildStepHeading(
    '3',
    'Excel 검증',
    '실행 대상과 건너뛸 행, 파일·Level·방향·거리 오류를 실행 전에 확인해 주세요.',
    '미검증'
  );
  state.ui.validationStepState = heading.state;

  const summary = element('div', 'levelchange-validation-summary');
  const totalMetric = metric('전체 행', '0');
  const applyMetric = metric('실행', '0');
  const skipMetric = metric('건너뛸', '0');
  const errorMetric = metric('오류', '0', 'danger');
  summary.append(totalMetric.root, applyMetric.root, skipMetric.root, errorMetric.root);

  const message = element('p', 'levelchange-validation-message', 'Excel을 불러오면 검증 결과가 표시됩니다.');
  message.setAttribute('aria-live', 'polite');

  const errorList = element('div', 'levelchange-error-list');
  errorList.dataset.levelchangeErrorList = '1';
  setScrollKey(errorList, 'validation-errors');

  const listToolbar = element('div', 'levelchange-list-toolbar');
  const searchField = element('label', 'levelchange-search-field');
  searchField.append(element('span', 'levelchange-control-label', '검증 행 검색'));
  const jobSearch = element('input', 'levelchange-input levelchange-search');
  jobSearch.type = 'search';
  jobSearch.placeholder = 'RVT, Level, 메모, 오류 검색';
  jobSearch.autocomplete = 'off';
  jobSearch.dataset.levelchangeJobSearch = '1';
  setFocusKey(jobSearch, 'job-search');
  jobSearch.addEventListener('input', () => {
    state.jobSearch = jobSearch.value;
    renderJobRows(state);
  });
  searchField.append(jobSearch);
  const visibleCount = element('span', 'levelchange-visible-count', '0개 표시');
  listToolbar.append(searchField, visibleCount);

  const tableWrap = element('div', 'levelchange-job-list');
  tableWrap.dataset.levelchangeJobList = '1';
  setScrollKey(tableWrap, 'job-list');
  const table = element('table', 'levelchange-job-table');
  const thead = document.createElement('thead');
  const headerRow = document.createElement('tr');
  ['행', 'RVT 파일', 'Level', '방향', '거리(mm)', '상태'].forEach((label) => {
    headerRow.append(element('th', '', label));
  });
  thead.append(headerRow);
  const tbody = document.createElement('tbody');
  table.append(thead, tbody);
  tableWrap.append(table);

  card.append(heading.root, summary, message, errorList, listToolbar, tableWrap);
  Object.assign(state.ui, {
    validationCard: card,
    validationMessage: message,
    validationErrorList: errorList,
    jobSearch,
    jobVisibleCount: visibleCount,
    jobTableBody: tbody,
    jobList: tableWrap,
    validationTotalValue: totalMetric.value,
    validationApplyValue: applyMetric.value,
    validationSkipValue: skipMetric.value,
    validationErrorValue: errorMetric.value
  });
  return card;
}

function buildRunPanel(state) {
  const panel = element('section', 'levelchange-run-panel');
  panel.dataset.levelchangeRunPanel = '1';
  setScrollKey(panel, 'run-panel');

  const intro = element('div', 'levelchange-run-intro');
  intro.append(
    element('span', 'levelchange-run-kicker', 'SAFE BATCH'),
    element('h3', '', 'Level 변경 실행'),
    element('p', '', '검증을 통과한 Excel 실행 행만 처리합니다.')
  );

  const policy = element('div', 'levelchange-policy');
  policy.append(element('strong', '', '고정 처리 정책'));
  const policyList = element('ul', 'levelchange-policy-list');
  [
    '모든 웍셋을 닫고 로컬 파일로 열기',
    'Level 핀 해제 → 이동 → 재핀',
    '영향 객체·삭제·연결 변화를 파일별 Excel로 기록',
    '중앙 파일은 성공 후 Synchronize with Central'
  ].forEach((text) => {
    const item = element('li', '');
    item.append(element('span', 'levelchange-policy-check', '✓'), element('span', '', text));
    policyList.append(item);
  });
  policy.append(policyList);

  const settings = element('div', 'levelchange-run-settings');
  const outputField = element('label', 'levelchange-field');
  outputField.append(element('span', 'levelchange-control-label', '결과 Excel 폴더 (선택)'));
  const outputRow = element('div', 'levelchange-field-row');
  const outputInput = element('input', 'levelchange-input levelchange-path-input');
  outputInput.type = 'text';
  outputInput.placeholder = '비우면 Excel 파일 옆에 자동 생성';
  outputInput.spellcheck = false;
  outputInput.autocomplete = 'off';
  outputInput.dataset.levelchangeOutputFolder = '1';
  setFocusKey(outputInput, 'output-folder');
  outputInput.addEventListener('input', () => {
    state.outputFolder = outputInput.value;
    markFieldChanged(state, 'outputFolder');
    scheduleDraftSave(state);
    syncActionState(state);
  });
  const outputButton = actionButton('찾기', 'secondary');
  outputButton.dataset.levelchangePickOutputFolder = '1';
  setFocusKey(outputButton, 'pick-output-folder');
  outputButton.addEventListener('click', () => pickOutputFolder(state));
  outputRow.append(outputInput, outputButton);
  outputField.append(outputRow);

  const commentField = element('label', 'levelchange-field');
  commentField.append(element('span', 'levelchange-control-label', '동기화 메모'));
  const commentInput = element('textarea', 'levelchange-input levelchange-comment-input');
  commentInput.rows = 2;
  commentInput.maxLength = 240;
  commentInput.dataset.levelchangeSyncComment = '1';
  setFocusKey(commentInput, 'sync-comment');
  commentInput.addEventListener('input', () => {
    state.syncComment = commentInput.value;
    markFieldChanged(state, 'syncComment');
    scheduleDraftSave(state);
  });
  commentField.append(commentInput);
  settings.append(outputField, commentField);

  const readiness = element('div', 'levelchange-readiness');
  readiness.append(element('strong', '', '실행 준비 상태'));
  const readySources = readinessRow('RVT 파일', '미등록');
  const readyWorkbook = readinessRow('Excel 작업 지시', '미등록');
  const readyValidation = readinessRow('Excel 검증', '미검증');
  readiness.append(readySources.root, readyWorkbook.root, readyValidation.root);

  const runButton = actionButton('Level 변경 실행', 'primary');
  runButton.classList.add('levelchange-run-button');
  runButton.dataset.levelchangeRun = '1';
  setFocusKey(runButton, 'run');
  runButton.addEventListener('click', () => runLevelChange(state));

  const status = element('p', 'levelchange-run-status', state.statusMessage);
  status.setAttribute('role', 'status');
  status.setAttribute('aria-live', 'polite');

  const progress = element('div', 'levelchange-progress');
  progress.dataset.levelchangeProgress = '1';
  const progressHead = element('div', 'levelchange-progress-head');
  const progressMessage = element('strong', '', '대기 중');
  const progressPercent = element('span', '', '0%');
  progressHead.append(progressMessage, progressPercent);
  const progressTrack = element('div', 'levelchange-progress-track');
  progressTrack.setAttribute('role', 'progressbar');
  progressTrack.setAttribute('aria-valuemin', '0');
  progressTrack.setAttribute('aria-valuemax', '100');
  progressTrack.setAttribute('aria-valuenow', '0');
  const progressBar = element('span', 'levelchange-progress-bar');
  progressTrack.append(progressBar);
  const progressDetail = element('span', 'levelchange-progress-detail', '실행을 시작하면 파일별 진행 상태가 표시됩니다.');
  progress.append(progressHead, progressTrack, progressDetail);

  const resultSummary = element('div', 'levelchange-result-summary');
  const movedMetric = metric('이동 Level', '0');
  const failedMetric = metric('실패 Level', '0', 'danger');
  const impactMetric = metric('영향 객체', '0');
  const syncMetric = metric('동기화', '0');
  resultSummary.append(movedMetric.root, failedMetric.root, impactMetric.root, syncMetric.root);
  const resultMessage = element('p', 'levelchange-result-message', '아직 실행 결과가 없습니다.');
  const resultList = element('div', 'levelchange-result-list');
  resultList.dataset.levelchangeResultList = '1';
  setScrollKey(resultList, 'result-list');

  const openButton = actionButton('결과 폴더 열기', 'secondary');
  openButton.dataset.levelchangeOpenOutputFolder = '1';
  setFocusKey(openButton, 'open-output-folder');
  openButton.addEventListener('click', () => openOutputFolder(state));

  panel.append(
    intro,
    policy,
    settings,
    readiness,
    runButton,
    status,
    progress,
    resultSummary,
    resultMessage,
    resultList,
    openButton
  );

  Object.assign(state.ui, {
    runPanel: panel,
    outputInput,
    pickOutputButton: outputButton,
    syncCommentInput: commentInput,
    readySources: readySources.root,
    readySourcesValue: readySources.value,
    readyWorkbook: readyWorkbook.root,
    readyWorkbookValue: readyWorkbook.value,
    readyValidation: readyValidation.root,
    readyValidationValue: readyValidation.value,
    runButton,
    runStatus: status,
    progressRoot: progress,
    progressMessage,
    progressPercent,
    progressTrack,
    progressBar,
    progressDetail,
    resultMovedValue: movedMetric.value,
    resultFailedValue: failedMetric.value,
    resultImpactValue: impactMetric.value,
    resultSyncValue: syncMetric.value,
    resultMessage,
    resultList,
    openOutputButton: openButton
  });
  return panel;
}

function buildStepHeading(number, title, description, stateLabel) {
  const root = element('header', 'levelchange-step-heading');
  const index = element('span', 'levelchange-step-index', number);
  index.setAttribute('aria-hidden', 'true');
  const copy = element('div', 'levelchange-step-copy');
  copy.append(element('h3', '', title), element('p', '', description));
  const state = element('span', 'levelchange-step-state', stateLabel);
  root.append(index, copy, state);
  return { root, state };
}

function metric(label, initialValue, tone = '') {
  const root = element('div', `levelchange-metric${tone ? ` levelchange-metric--${tone}` : ''}`);
  const value = element('strong', '', initialValue);
  root.append(element('span', '', label), value);
  return { root, value };
}

function readinessRow(label, initialValue) {
  const root = element('div', 'levelchange-ready-row');
  const mark = element('span', 'levelchange-ready-mark', '·');
  const copy = element('span', 'levelchange-ready-label', label);
  const value = element('strong', '', initialValue);
  root.append(mark, copy, value);
  return { root, value };
}

function actionButton(label, kind = 'secondary') {
  const button = element('button', `btn btn--${kind}`);
  button.type = 'button';
  button.textContent = label;
  return button;
}

function registerDropZones(state) {
  const cleanups = [];
  cleanups.push(attachRvtDropZone(state.ui.rvtDropZone, {
    onDropPaths: (paths) => addRvtPaths(state, paths, { source: 'drop' }),
    onInvalid: (payload) => toast(
      stringOf(pick(payload, 'message', 'Message')) || 'RVT 파일만 등록할 수 있습니다.',
      'warn'
    )
  }));
  cleanups.push(attachExcelDropZone(state.ui.workbookDropZone, {
    onDropPaths: (paths) => acceptWorkbookPath(state, paths?.[0], { source: 'drop', importNow: true }),
    onInvalid: (payload) => toast(
      stringOf(pick(payload, 'message', 'Message')) || '.xlsx 파일 하나만 놓을 수 있습니다.',
      'warn'
    )
  }));
  return cleanups;
}

function registerHostEvents(state) {
  const unsubscribers = [];
  const listen = (eventName, handler) => unsubscribers.push(onHost(eventName, handler));

  listen('levelchange:context', (payload) => {
    if (!acceptInitResponse(state, payload)) return;
    state.initRequestId = '';
    receiveContext(state, payload);
  });
  listen('levelchange:rvts-picked', (payload) => {
    if (!acceptExpectedResponse(state, payload, 'pick-rvts', { allowNativeDrop: true })) return;
    const nativeDrop = isNativeDropPayload(payload);
    if (!nativeDrop && !activeRequestFieldsCurrent(state, ['rvtPaths'])) {
      finishStaleResponse(state, 'pick-rvts', '파일 선택 요청 중 RVT 목록이 변경되어 해당 선택 결과는 적용하지 않았습니다.');
      return;
    }
    finishRequest(state, 'pick-rvts');
    if (isCancelled(payload)) {
      setRunStatus(state, 'RVT 파일 선택을 취소했습니다.', 'idle');
      return;
    }
    const paths = arrayOf(pick(payload, 'paths', 'Paths', 'rvtPaths', 'RvtPaths'));
    if (pick(payload, 'ok', 'Ok') === false && !paths.length) {
      handleHostError(state, payload, 'RVT 파일을 불러오지 못했습니다.');
      return;
    }
    addRvtPaths(state, paths, { source: pick(payload, 'dropped', 'Dropped') ? 'drop' : 'picker' });
  });
  listen('levelchange:template-exported', (payload) => {
    if (!acceptExpectedResponse(state, payload, 'export-template')) return;
    const workbookStillCurrent = activeRequestFieldsCurrent(state, ['rvtPaths', 'workbookPath']);
    finishRequest(state, 'export-template');
    if (isCancelled(payload)) {
      setRunStatus(state, stringOf(pick(payload, 'message', 'Message')) || 'Excel 양식 저장을 취소했습니다.', 'idle');
      return;
    }
    if (pick(payload, 'ok', 'Ok') === false) {
      handleHostError(state, payload, 'Excel 양식을 저장하지 못했습니다.');
      return;
    }
    const path = stringOf(pick(payload, 'path', 'Path'));
    if (path) requestAnimationFrame(() => {
      if (!state.disposed && state.ui.page?.isConnected) showExcelSavedDialog('Level 변경 Excel 양식을 저장했습니다.', path, (savedPath) => post('excel:open', { path: savedPath }));
    });
    if (!workbookStillCurrent) {
      const message = stringOf(pick(payload, 'message', 'Message')) || 'Level 변경 Excel 양식을 저장했습니다.';
      setRunStatus(state, `${message} 저장 요청 중 Excel 경로가 변경되어 현재 입력값은 유지했습니다.`, 'warning');
      if (!path) toast(message, 'success');
      return;
    }
    if (path && path !== state.workbookPath) {
      state.workbookPath = path;
      markFieldChanged(state, 'workbookPath');
    }
    invalidateImportedData(state);
    syncInputsFromState(state);
    syncWorkbookSurface(state);
    renderValidationSurface(state);
    renderResultSurface(state);
    scheduleDraftSave(state);
    syncActionState(state);
    const message = stringOf(pick(payload, 'message', 'Message')) || 'Level 변경 Excel 양식을 저장했습니다.';
    setRunStatus(state, message, 'success');
    if (!path) toast(message, 'success');
  });
  listen('levelchange:workbook-picked', (payload) => {
    if (!acceptExpectedResponse(state, payload, 'pick-workbook', { allowNativeDrop: true })) return;
    const nativeDrop = isNativeDropPayload(payload);
    if (!nativeDrop && !activeRequestFieldsCurrent(state, ['rvtPaths', 'workbookPath'])) {
      finishStaleResponse(state, 'pick-workbook', '파일 선택 요청 중 Excel 경로가 변경되어 해당 선택 결과는 적용하지 않았습니다.');
      return;
    }
    finishRequest(state, 'pick-workbook');
    if (isCancelled(payload)) {
      setRunStatus(state, 'Excel 파일 선택을 취소했습니다.', 'idle');
      return;
    }
    if (pick(payload, 'ok', 'Ok') === false) {
      handleHostError(state, payload, 'Excel 파일을 불러오지 못했습니다.');
      return;
    }
    acceptWorkbookPath(state, pick(payload, 'path', 'Path'), { source: 'picker', importNow: true });
  });
  listen('levelchange:imported', (payload) => {
    if (!acceptExpectedResponse(state, payload, 'import-workbook')) return;
    if (!activeRequestFieldsCurrent(state, ['rvtPaths', 'workbookPath'])) {
      finishStaleResponse(state, 'import-workbook', '검증 중 Excel 경로가 변경되어 이전 검증 결과는 폐기했습니다. 현재 Excel을 다시 검증해 주세요.');
      return;
    }
    finishRequest(state, 'import-workbook');
    state.imported = normalizeImported(payload);
    state.result = null;
    if (state.imported.workbookPath && state.imported.workbookPath !== state.workbookPath) {
      state.workbookPath = state.imported.workbookPath;
      markFieldChanged(state, 'workbookPath');
    }
    syncInputsFromState(state);
    syncWorkbookSurface(state);
    renderValidationSurface(state);
    renderResultSurface(state);
    scheduleDraftSave(state);
    syncActionState(state);
    const message = state.imported.message || (state.imported.ok ? 'Excel 검증을 완료했습니다.' : 'Excel 검증 오류를 확인해 주세요.');
    setRunStatus(state, message, state.imported.ok ? 'success' : 'error');
    toast(message, state.imported.ok ? 'success' : 'warn', state.imported.ok ? 2600 : 5200);
  });
  listen('levelchange:output-folder-picked', (payload) => {
    if (!acceptExpectedResponse(state, payload, 'pick-output-folder')) return;
    if (!activeRequestFieldsCurrent(state, ['outputFolder'])) {
      finishStaleResponse(state, 'pick-output-folder', '폴더 선택 요청 중 결과 폴더 입력이 변경되어 해당 선택 결과는 적용하지 않았습니다.');
      return;
    }
    finishRequest(state, 'pick-output-folder');
    if (isCancelled(payload)) {
      setRunStatus(state, '결과 폴더 선택을 취소했습니다.', 'idle');
      return;
    }
    if (pick(payload, 'ok', 'Ok') === false) {
      handleHostError(state, payload, '결과 폴더를 선택하지 못했습니다.');
      return;
    }
    const outputFolder = stringOf(pick(payload, 'path', 'Path'));
    if (outputFolder !== state.outputFolder) {
      state.outputFolder = outputFolder;
      markFieldChanged(state, 'outputFolder');
    }
    syncInputsFromState(state);
    scheduleDraftSave(state);
    syncActionState(state);
    setRunStatus(state, '결과 Excel 폴더를 지정했습니다.', 'success');
  });
  listen('levelchange:progress', (payload) => {
    if (state.busyKind !== 'run' || !acceptExpectedResponse(state, payload, 'run')) return;
    patchProgress(state, payload);
  });
  listen('levelchange:done', (payload) => {
    if (!acceptExpectedResponse(state, payload, 'run')) return;
    finishRequest(state, 'run');
    state.result = normalizeResult(payload);
    if (state.result.outputFolder && state.result.outputFolder !== state.outputFolder) {
      state.outputFolder = state.result.outputFolder;
      markFieldChanged(state, 'outputFolder');
    }
    state.progress = {
      percent: 100,
      message: '처리 완료',
      detail: state.result.message,
      completed: numberOf(pick(state.result.summary, 'fileCount'), 0),
      total: numberOf(pick(state.result.summary, 'fileCount'), 0)
    };
    syncInputsFromState(state);
    syncProgressSurface(state);
    renderResultSurface(state);
    scheduleDraftSave(state);
    syncActionState(state);
    const message = state.result.message || 'Level 변경 처리를 완료했습니다.';
    setRunStatus(state, message, state.result.ok ? 'success' : 'error');
    toast(message, state.result.ok ? 'success' : 'warn', 5600);
  });
  listen('levelchange:error', (payload) => {
    if (!acceptActiveResponse(state, payload)) return;
    handleHostError(state, payload, 'Level 변경 처리 중 오류가 발생했습니다.');
  });
  listen('levelchange:folder-opened', (payload) => {
    if (!acceptExpectedResponse(state, payload, 'open-output-folder')) return;
    finishRequest(state, 'open-output-folder');
    if (pick(payload, 'ok', 'Ok') === false) {
      handleHostError(state, payload, '결과 폴더를 열지 못했습니다.');
      return;
    }
    setRunStatus(state, '결과 폴더를 열었습니다.', 'success');
  });

  return unsubscribers;
}

function receiveContext(state, payload) {
  if (shouldDeferContext(state)) {
    state.pendingContext = payload;
    return;
  }
  applyContext(state, payload);
}

function applyContext(state, payload) {
  if (!payload || typeof payload !== 'object' || state.disposed) return;
  const settings = pick(payload, 'settings', 'Settings') || {};
  const canApplyRvtPaths = initFieldStillCurrent(state, 'rvtPaths');
  const canApplyWorkbookPath = initFieldStillCurrent(state, 'workbookPath');
  const canApplyOutputFolder = initFieldStillCurrent(state, 'outputFolder');
  const canApplySyncComment = initFieldStillCurrent(state, 'syncComment');
  const workbookEditing = document.activeElement === state.ui.workbookInput;
  const outputEditing = document.activeElement === state.ui.outputInput;
  const commentEditing = document.activeElement === state.ui.syncCommentInput;

  if (canApplyRvtPaths && hasOwnAny(settings, 'rvtPaths', 'RvtPaths')) {
    state.rvtPaths = normalizeRvtPaths(arrayOf(pick(settings, 'rvtPaths', 'RvtPaths')));
  }
  if (canApplyWorkbookPath && !workbookEditing && hasOwnAny(settings, 'workbookPath', 'WorkbookPath')) {
    state.workbookPath = stringOf(pick(settings, 'workbookPath', 'WorkbookPath'));
  }
  if (canApplyOutputFolder && !outputEditing && hasOwnAny(settings, 'outputFolder', 'OutputFolder')) {
    state.outputFolder = stringOf(pick(settings, 'outputFolder', 'OutputFolder'));
  }
  if (canApplySyncComment && !commentEditing && hasOwnAny(settings, 'syncComment', 'SyncComment')) {
    state.syncComment = stringOf(pick(settings, 'syncComment', 'SyncComment')) || DEFAULT_SYNC_COMMENT;
  }
  if (canApplyRvtPaths && canApplyWorkbookPath && hasOwnAny(payload, 'imported', 'Imported')) {
    const imported = pick(payload, 'imported', 'Imported');
    state.imported = imported && typeof imported === 'object' ? normalizeImported(imported) : null;
  }
  if (canApplyRvtPaths && canApplyWorkbookPath && canApplyOutputFolder && canApplySyncComment
      && hasOwnAny(payload, 'result', 'Result')) {
    const result = pick(payload, 'result', 'Result');
    state.result = result && typeof result === 'object' ? normalizeResult(result) : null;
  }
  if (canApplyOutputFolder && state.result?.outputFolder && !outputEditing) state.outputFolder = state.result.outputFolder;
  state.initSnapshot = null;

  syncInputsFromState(state);
  syncRvtSurface(state);
  renderRvtRows(state);
  syncWorkbookSurface(state);
  renderValidationSurface(state);
  renderResultSurface(state);
  scheduleDraftSave(state);
  syncActionState(state);
}

function registerInteractionGuards(state) {
  const page = state.ui.page;
  const roots = interactionRoots(state);
  const contains = (node) => roots.some((root) => root?.contains?.(node));
  const pointerKey = (event) => event?.pointerId == null ? 'primary' : String(event.pointerId);
  const onPointerDown = (event) => {
    if (contains(event.target)) state.activePointerIds.add(pointerKey(event));
  };
  const onPointerEnd = (event) => {
    state.activePointerIds.delete(pointerKey(event));
    schedulePendingContextApply(state);
  };
  const onCompositionStart = (event) => {
    if (contains(event.target)) state.compositionActive = true;
  };
  const onCompositionEnd = () => {
    state.compositionActive = false;
    schedulePendingContextApply(state);
  };
  const onFocusOut = (event) => {
    if (contains(event.target)) schedulePendingContextApply(state);
  };
  const onWindowBlur = () => {
    state.activePointerIds.clear();
    state.compositionActive = false;
    schedulePendingContextApply(state);
  };

  roots.forEach((root) => root.addEventListener('pointerdown', onPointerDown, true));
  window.addEventListener('pointerup', onPointerEnd, true);
  window.addEventListener('pointercancel', onPointerEnd, true);
  roots.forEach((root) => root.addEventListener('compositionstart', onCompositionStart, true));
  roots.forEach((root) => root.addEventListener('compositionend', onCompositionEnd, true));
  roots.forEach((root) => root.addEventListener('focusout', onFocusOut, true));
  window.addEventListener('blur', onWindowBlur, true);

  return () => {
    roots.forEach((root) => root.removeEventListener('pointerdown', onPointerDown, true));
    window.removeEventListener('pointerup', onPointerEnd, true);
    window.removeEventListener('pointercancel', onPointerEnd, true);
    roots.forEach((root) => root.removeEventListener('compositionstart', onCompositionStart, true));
    roots.forEach((root) => root.removeEventListener('compositionend', onCompositionEnd, true));
    roots.forEach((root) => root.removeEventListener('focusout', onFocusOut, true));
    window.removeEventListener('blur', onWindowBlur, true);
    state.activePointerIds.clear();
    state.compositionActive = false;
  };
}

function shouldDeferContext(state) {
  const active = document.activeElement;
  return state.compositionActive
    || state.activePointerIds.size > 0
    || (!!active?.matches?.('input, select, textarea, [contenteditable="true"]') && isInInteractionSurface(state, active));
}

function interactionRoots(state) {
  const roots = [state.ui.page, state.ui.runPanel].filter(Boolean);
  return roots.filter((root, index) => roots.indexOf(root) === index);
}

function isInInteractionSurface(state, node) {
  return interactionRoots(state).some((root) => root?.contains?.(node));
}

function schedulePendingContextApply(state) {
  if (!state.pendingContext || state.pendingContextTimer || state.disposed) return;
  state.pendingContextTimer = window.setTimeout(() => {
    state.pendingContextTimer = 0;
    if (shouldDeferContext(state) || !state.pendingContext) return;
    const payload = state.pendingContext;
    state.pendingContext = null;
    applyContext(state, payload);
  }, 0);
}

function addRvtPaths(state, rawPaths, options = {}) {
  if (state.busyKind) {
    toast('현재 요청이 끝난 뒤 RVT 파일을 변경해 주세요.', 'warn');
    return;
  }
  const incoming = normalizeRvtPaths(rawPaths);
  if (!incoming.length) {
    toast('등록할 수 있는 .rvt 파일이 없습니다.', 'warn');
    return;
  }
  const seen = new Set(state.rvtPaths.map(pathKey));
  const added = incoming.filter((path) => !seen.has(pathKey(path)));
  if (!added.length) {
    toast('이미 등록된 RVT 파일입니다.', 'info');
    return;
  }
  state.rvtPaths.push(...added);
  markFieldChanged(state, 'rvtPaths');
  const invalidated = invalidateImportedData(state);
  syncRvtSurface(state);
  renderRvtRows(state);
  syncWorkbookSurface(state);
  if (invalidated) {
    renderValidationSurface(state);
    renderResultSurface(state);
  }
  scheduleDraftSave(state);
  syncActionState(state);
  const sourceLabel = options.source === 'drop' ? '끌어다 놓은' : '선택한';
  setRunStatus(state, `${sourceLabel} RVT 파일 ${added.length}개를 등록했습니다.`, 'success');
}

function removeRvtPath(state, path) {
  if (state.busyKind) return;
  const key = pathKey(path);
  const next = state.rvtPaths.filter((item) => pathKey(item) !== key);
  if (next.length === state.rvtPaths.length) return;
  state.rvtPaths = next;
  markFieldChanged(state, 'rvtPaths');
  invalidateImportedData(state);
  syncRvtSurface(state);
  renderRvtRows(state);
  syncWorkbookSurface(state);
  renderValidationSurface(state);
  renderResultSurface(state);
  scheduleDraftSave(state);
  syncActionState(state);
  setRunStatus(state, 'RVT 파일을 제거했습니다. Excel을 다시 검증해 주세요.', 'idle');
}

function clearRvtPaths(state) {
  if (state.busyKind || !state.rvtPaths.length) return;
  if (!window.confirm(`등록한 RVT 파일 ${state.rvtPaths.length}개를 목록에서 모두 제거할까요?\n\n원본 파일은 삭제되지 않습니다.`)) return;
  state.rvtPaths = [];
  markFieldChanged(state, 'rvtPaths');
  invalidateImportedData(state);
  syncRvtSurface(state);
  renderRvtRows(state);
  syncWorkbookSurface(state);
  renderValidationSurface(state);
  renderResultSurface(state);
  scheduleDraftSave(state);
  syncActionState(state);
  setRunStatus(state, '등록한 RVT 파일을 모두 제거했습니다.', 'idle');
}

function acceptWorkbookPath(state, rawPath, options = {}) {
  if (state.busyKind) {
    toast('현재 요청이 끝난 뒤 Excel 파일을 불러와 주세요.', 'warn');
    return;
  }
  const path = stringOf(rawPath).trim();
  if (!/\.xlsx$/i.test(path)) {
    toast('Level 변경 양식은 .xlsx 파일만 사용할 수 있습니다.', 'warn');
    return;
  }
  state.workbookPath = path;
  markFieldChanged(state, 'workbookPath');
  invalidateImportedData(state);
  syncInputsFromState(state);
  syncWorkbookSurface(state);
  renderValidationSurface(state);
  renderResultSurface(state);
  scheduleDraftSave(state);
  syncActionState(state);
  setRunStatus(
    state,
    options.source === 'drop'
      ? 'Excel 파일을 끌어다 놓았습니다. 검증을 시작합니다.'
      : 'Excel 파일을 선택했습니다. 검증을 시작합니다.',
    'idle'
  );
  if (options.importNow) importWorkbook(state);
}

function exportTemplate(state) {
  if (!state.rvtPaths.length) {
    toast('먼저 RVT 파일을 하나 이상 등록해 주세요.', 'warn');
    return;
  }
  beginRequest(
    state,
    'export-template',
    'levelchange:export-template',
    'Excel 양식 저장 위치를 선택하는 중입니다.'
  );
}

function pickWorkbook(state) {
  if (!state.rvtPaths.length) {
    toast('먼저 Excel에 포함된 RVT 파일을 등록해 주세요.', 'warn');
    return;
  }
  beginRequest(
    state,
    'pick-workbook',
    'levelchange:pick-workbook',
    'Level 변경 Excel 선택창을 여는 중입니다.'
  );
}

function importWorkbook(state) {
  if (!state.rvtPaths.length) {
    toast('먼저 RVT 파일을 하나 이상 등록해 주세요.', 'warn');
    return;
  }
  if (!/\.xlsx$/i.test(state.workbookPath.trim())) {
    toast('검증할 .xlsx 파일 경로를 확인해 주세요.', 'warn');
    return;
  }
  beginRequest(
    state,
    'import-workbook',
    'levelchange:import-workbook',
    'Excel 행과 실행 조건을 검증하는 중입니다.'
  );
}

function pickOutputFolder(state) {
  beginRequest(
    state,
    'pick-output-folder',
    'levelchange:pick-output-folder',
    '결과 Excel 폴더를 선택하는 중입니다.'
  );
}

function runLevelChange(state) {
  const applyJobs = getApplyJobs(state);
  if (!state.rvtPaths.length || !state.workbookPath.trim() || !state.imported?.ok || !applyJobs.length) {
    toast('RVT 등록, Excel 선택, Excel 검증을 모두 완료해 주세요.', 'warn');
    return;
  }
  const confirmed = window.confirm([
    `RVT 파일 ${new Set(applyJobs.map((job) => pathKey(job.sourceRvtPath))).size}개에서 Level ${applyJobs.length}개를 이동합니다.`,
    '모든 웍셋을 닫고 로컬 파일로 열며, Level 변경에 성공한 중앙 파일은 동기화합니다.',
    '계속할까요?'
  ].join('\n\n'));
  if (!confirmed) return;

  state.result = null;
  state.progress = {
    percent: 0,
    message: 'Level 변경을 준비하는 중입니다.',
    detail: `Level 이동 ${applyJobs.length}건`,
    completed: 0,
    total: new Set(applyJobs.map((job) => pathKey(job.sourceRvtPath))).size
  };
  renderResultSurface(state);
  syncProgressSurface(state);
  beginRequest(state, 'run', 'levelchange:run', 'RVT 파일을 열고 Level 변경을 준비하는 중입니다.');
}

function openOutputFolder(state) {
  const path = state.result?.outputFolder || state.outputFolder;
  if (!path) {
    toast('먼저 결과 폴더를 지정하거나 작업을 실행해 주세요.', 'warn');
    return;
  }
  beginRequest(
    state,
    'open-output-folder',
    'levelchange:open-output-folder',
    '결과 폴더를 여는 중입니다.',
    { path }
  );
}

function beginRequest(state, kind, eventName, message, extraPayload = {}) {
  if (state.busyKind) {
    toast('이미 처리 중인 요청이 있습니다. 잠시 기다려 주세요.', 'warn');
    return false;
  }
  const requestId = createRequestId(state, kind);
  state.busyKind = kind;
  state.activeRequest = { kind, requestId, snapshot: captureRequestSnapshot(state) };
  setRunStatus(state, message, 'busy');
  syncActionState(state);
  syncProgressSurface(state);
  const sent = post(eventName, buildRequestPayload(state, requestId, extraPayload));
  if (sent === false) {
    state.busyKind = '';
    state.activeRequest = null;
    setRunStatus(state, 'Revit으로 요청을 보내지 못했습니다.', 'error');
    syncActionState(state);
    syncProgressSurface(state);
    return false;
  }
  return true;
}

function finishRequest(state, expectedKind) {
  if (!state.busyKind) return;
  if (expectedKind && state.busyKind !== expectedKind) return;
  state.busyKind = '';
  state.activeRequest = null;
  syncActionState(state);
  syncProgressSurface(state);
}

function patchProgress(state, payload) {
  state.progress = {
    percent: clamp(numberOf(pick(payload, 'percent', 'Percent'), 0), 0, 100),
    message: stringOf(pick(payload, 'message', 'Message')) || 'RVT 파일을 처리하는 중입니다.',
    detail: stringOf(pick(payload, 'detail', 'Detail')),
    completed: Math.max(0, numberOf(pick(payload, 'completed', 'Completed'), 0)),
    total: Math.max(0, numberOf(pick(payload, 'total', 'Total'), 0))
  };
  // Progress is intentionally patched in place. Rebuilding the workspace here
  // would replace an active text editor and reset nested scroll positions.
  syncProgressSurface(state);
  setRunStatus(state, state.progress.message, 'busy');
}

function handleHostError(state, payload, fallback) {
  state.busyKind = '';
  state.activeRequest = null;
  const message = stringOf(pick(payload, 'message', 'Message')) || fallback;
  const detail = stringOf(pick(payload, 'detail', 'Detail'));
  const combined = detail && detail !== message ? `${message} ${detail}` : message;
  setRunStatus(state, combined, 'error');
  syncActionState(state);
  syncProgressSurface(state);
  toast(combined, 'error', 5600);
}

function syncRvtSurface(state) {
  const count = state.rvtPaths.length;
  state.ui.rvtCountBadge.textContent = `${count}개`;
  state.ui.rvtDropTitle.textContent = count
    ? `RVT 파일 ${count}개가 등록되었습니다`
    : 'RVT 파일을 여기에 놓아 주세요';
  state.ui.rvtDropHint.textContent = count
    ? '추가 파일을 끌어다 놓아 등록하거나, 검색란에서 등록 경로를 확인해 주세요.'
    : '등록한 파일은 원본 경로에서 처리되며, 중앙 파일은 임시 로컬로 열립니다.';
  setStepState(state.ui.rvtStepState, count ? `${count}개 등록` : '미등록', count ? 'ready' : 'idle');
}

function renderRvtRows(state) {
  const query = normalizeSearch(state.fileSearch);
  const visible = state.rvtPaths.filter((path) => {
    if (!query) return true;
    return normalizeSearch(path).includes(query) || normalizeSearch(fileName(path)).includes(query);
  });
  withInteractionPatch(state, () => {
    const fragment = document.createDocumentFragment();
    if (!visible.length) {
      fragment.append(emptyBlock(
        state.rvtPaths.length ? '검색 조건에 맞는 RVT 파일이 없습니다.' : '아직 등록한 RVT 파일이 없습니다.'
      ));
    } else {
      visible.forEach((path, index) => {
        const row = element('article', 'levelchange-file-row');
        row.setAttribute('role', 'listitem');
        const indexChip = element('span', 'levelchange-file-index', String(state.rvtPaths.indexOf(path) + 1));
        const copy = element('div', 'levelchange-file-copy');
        const name = element('strong', '', fileName(path));
        const fullPath = element('span', '', path);
        fullPath.title = path;
        copy.append(name, fullPath);
        const remove = actionButton('제거', 'secondary');
        remove.classList.add('levelchange-row-remove');
        remove.setAttribute('aria-label', `${fileName(path)} 제거`);
        remove.dataset.levelchangeRemoveRvt = path;
        setFocusKey(remove, `rvt-remove:${stableHash(path)}`);
        remove.addEventListener('click', () => removeRvtPath(state, path));
        row.append(indexChip, copy, remove);
        fragment.append(row);
      });
    }
    state.ui.rvtList.replaceChildren(fragment);
  });
}

function syncWorkbookSurface(state) {
  const hasWorkbook = !!state.workbookPath.trim();
  if (state.imported) {
    state.ui.workbookStatus.textContent = state.imported.message || (state.imported.ok ? 'Excel 검증 완료' : 'Excel 검증 오류');
    setTone(state.ui.workbookStatus, state.imported.ok ? 'success' : 'error');
    setTone(state.ui.workbookState, state.imported.ok ? 'success' : 'error');
    state.ui.workbookState.textContent = state.imported.ok ? '검증 완료' : '오류 확인';
    setStepState(state.ui.workbookStepState, state.imported.ok ? '검증 완료' : '검증 오류', state.imported.ok ? 'ready' : 'error');
    return;
  }
  state.ui.workbookStatus.textContent = hasWorkbook
    ? '작성한 Excel을 다시 검증해야 실행할 수 있습니다.'
    : 'RVT 파일을 등록하면 빈 Excel 양식을 저장할 수 있습니다.';
  setTone(state.ui.workbookStatus, hasWorkbook ? 'warning' : 'idle');
  state.ui.workbookState.textContent = hasWorkbook ? '경로 등록' : '미등록';
  setTone(state.ui.workbookState, hasWorkbook ? 'warning' : 'idle');
  setStepState(state.ui.workbookStepState, hasWorkbook ? '검증 필요' : '준비 필요', hasWorkbook ? 'warning' : 'idle');
}

function renderValidationSurface(state) {
  const imported = state.imported;
  const jobs = imported?.jobs || [];
  const applyCount = jobs.filter(isApplyJob).length;
  const skipCount = jobs.length - applyCount;
  const errorCount = imported?.errors?.length || jobs.filter((job) => !!job.validationMessage).length;
  state.ui.validationTotalValue.textContent = String(jobs.length);
  state.ui.validationApplyValue.textContent = String(applyCount);
  state.ui.validationSkipValue.textContent = String(skipCount);
  state.ui.validationErrorValue.textContent = String(errorCount);

  if (!imported) {
    state.ui.validationMessage.textContent = 'Excel을 불러오면 검증 결과가 표시됩니다.';
    setTone(state.ui.validationMessage, 'idle');
    setStepState(state.ui.validationStepState, '미검증', 'idle');
  } else {
    state.ui.validationMessage.textContent = imported.message || (imported.ok ? 'Excel 검증을 통과했습니다.' : 'Excel 검증 오류를 확인해 주세요.');
    setTone(state.ui.validationMessage, imported.ok ? 'success' : 'error');
    setStepState(
      state.ui.validationStepState,
      imported.ok ? `실행 ${applyCount}건` : `오류 ${errorCount}건`,
      imported.ok ? 'ready' : 'error'
    );
  }

  withInteractionPatch(state, () => {
    const errors = imported?.errors || [];
    const errorFragment = document.createDocumentFragment();
    if (!errors.length) {
      const empty = element('p', 'levelchange-error-empty', imported ? '검증 오류가 없습니다.' : '검증 전입니다.');
      errorFragment.append(empty);
    } else {
      errors.forEach((message, index) => {
        const row = element('div', 'levelchange-error-row');
        row.append(element('span', '', String(index + 1)), element('p', '', stringOf(message)));
        errorFragment.append(row);
      });
    }
    state.ui.validationErrorList.replaceChildren(errorFragment);
  });
  renderJobRows(state);
}

function renderJobRows(state) {
  const jobs = state.imported?.jobs || [];
  const query = normalizeSearch(state.jobSearch);
  const visible = jobs.filter((job) => {
    if (!query) return true;
    return [job.sourceRvtPath, fileName(job.sourceRvtPath), job.levelName, job.note, job.validationMessage, job.direction]
      .some((value) => normalizeSearch(value).includes(query));
  });
  state.ui.jobVisibleCount.textContent = `${visible.length}개 표시`;

  withInteractionPatch(state, () => {
    const fragment = document.createDocumentFragment();
    if (!visible.length) {
      const row = document.createElement('tr');
      const cell = element('td', 'levelchange-table-empty', jobs.length ? '검색 조건에 맞는 행이 없습니다.' : '불러온 Excel 행이 없습니다.');
      cell.colSpan = 6;
      row.append(cell);
      fragment.append(row);
    } else {
      visible.forEach((job) => {
        const apply = isApplyJob(job);
        const invalid = !!job.validationMessage;
        const row = document.createElement('tr');
        row.className = invalid ? 'is-error' : (apply ? 'is-ready' : 'is-skipped');
        row.dataset.rowId = job.rowId;
        const rowNumber = element('td', '', job.excelRowNumber ? String(job.excelRowNumber) : '-');
        const fileCell = element('td', 'levelchange-job-file');
        const fileStrong = element('strong', '', fileName(job.sourceRvtPath));
        fileStrong.title = job.sourceRvtPath;
        fileCell.append(fileStrong, element('span', '', job.note || ''));
        const levelCell = element('td', '', job.levelName || '-');
        const directionCell = element('td', '', directionLabel(job.direction));
        const distanceCell = element('td', '', formatDistance(job.distanceMillimeters));
        const statusCell = element('td', 'levelchange-job-status');
        const chip = element(
          'span',
          `levelchange-state-chip ${invalid ? 'is-error' : (apply ? 'is-success' : 'is-idle')}`,
          invalid ? '오류' : (apply ? '실행 준비' : '건너뛸')
        );
        const detail = element('small', '', job.validationMessage || (apply ? '검증 통과' : '실행 안 함'));
        statusCell.append(chip, detail);
        row.append(rowNumber, fileCell, levelCell, directionCell, distanceCell, statusCell);
        fragment.append(row);
      });
    }
    state.ui.jobTableBody.replaceChildren(fragment);
  });
}

function renderResultSurface(state) {
  const result = state.result;
  const summary = result?.summary || createEmptySummary();
  state.ui.resultMovedValue.textContent = String(summary.movedLevelCount || 0);
  state.ui.resultFailedValue.textContent = String(summary.failedLevelCount || 0);
  state.ui.resultImpactValue.textContent = String(
    (summary.modifiedElementCount || 0)
      + (summary.deletedElementCount || 0)
      + (summary.addedElementCount || 0)
      + (summary.connectionChangedCount || 0)
  );
  state.ui.resultSyncValue.textContent = String(summary.synchronizedFileCount || 0);
  state.ui.resultMessage.textContent = result?.message || '아직 실행 결과가 없습니다.';
  setTone(state.ui.resultMessage, result ? (result.ok ? 'success' : 'error') : 'idle');

  withInteractionPatch(state, () => {
    const fragment = document.createDocumentFragment();
    const files = result?.files || [];
    if (!files.length) {
      fragment.append(emptyBlock('실행을 완료하면 파일별 Level·영향 객체·동기화 결과가 표시됩니다.'));
    } else {
      files.forEach((file) => fragment.append(buildResultFileRow(file)));
    }
    state.ui.resultList.replaceChildren(fragment);
  });
}

function buildResultFileRow(file) {
  const tone = resultFileTone(file);
  const row = element('article', `levelchange-result-row is-${tone}`);
  const head = element('div', 'levelchange-result-row-head');
  const copy = element('div', 'levelchange-result-file-copy');
  copy.append(element('strong', '', file.fileName || fileName(file.sourcePath)), element('span', '', file.sourcePath));
  const status = element('span', `levelchange-state-chip is-${tone}`, resultFileStatusLabel(file, tone));
  head.append(copy, status);
  const facts = element('div', 'levelchange-result-facts');
  facts.append(
    resultFact('Level', `${file.successCount || 0}/${file.levelCount || 0}`),
    resultFact('영향', String(file.impactCount || 0)),
    resultFact('변경 반영', persistenceLabel(file)),
    resultFact('동기화', synchronizationLabel(file))
  );
  const alerts = buildResultAlerts(file);
  const message = element('p', 'levelchange-result-row-message', file.message || '처리 메시지가 없습니다.');
  const report = element('p', 'levelchange-result-report');
  report.classList.toggle('is-warning', !file.reportGenerated);
  report.append(
    element('span', '', file.reportGenerated ? '결과 Excel' : '결과 Excel 미생성'),
    element('strong', '', file.reportPath || '생성되지 않음')
  );
  if (file.reportPath) report.title = file.reportPath;
  const coverage = file.impactCoverage
    ? element('p', 'levelchange-impact-coverage', `영향 추적 범위: ${file.impactCoverage}`)
    : null;
  row.append(head, facts);
  if (alerts) row.append(alerts);
  row.append(message, report);
  if (coverage) row.append(coverage);
  if (file.temporaryLocalRetained && file.localPath) {
    const retained = element('p', 'levelchange-retained-local', `임시 로컬 보존: ${file.localPath}`);
    row.append(retained);
  }
  return row;
}

function buildResultAlerts(file) {
  const alerts = [];
  if (file.unsafeTransactionState) {
    alerts.push({ tone: 'error', text: '트랜잭션 롤백 상태를 확인할 수 없으므로 후속 처리와 중앙 동기화를 안전하게 중단했습니다.' });
  }
  if (file.persistenceReported && !file.changesPersisted) {
    alerts.push({ tone: 'error', text: `Level 변경이 파일 또는 중앙 모델에 반영되었는지 확인할 수 없습니다. (${persistenceLabel(file)})` });
  }
  if (file.synchronizationOutcomeUncertain) {
    alerts.push({ tone: 'error', text: '중앙 동기화 결과가 불명확합니다. 중앙 모델을 직접 확인하기 전에는 동일한 지시를 다시 실행하지 마세요.' });
  }
  if (file.impactCaptureIncomplete) {
    alerts.push({ tone: 'warning', text: '영향 객체 캡처가 일부 누락되었습니다. 결과 Excel의 CAPTURE_INCOMPLETE 행을 확인해 주세요.' });
  }
  if (file.persistenceStatus === 'SynchronizedLocalDirty') {
    alerts.push({ tone: 'warning', text: '중앙 동기화 후 로컬 파일에 추가로 저장되지 않은 변경 사항이 남아 임시 로컬을 보존했습니다.' });
  }
  if (!file.reportGenerated) {
    alerts.push({ tone: 'warning', text: '파일별 결과 Excel을 생성하지 못했습니다. 아래 처리 메시지와 보존된 로컬 파일 경로를 확인해 주세요.' });
  }
  if (!alerts.length) return null;
  const root = element('div', 'levelchange-result-alerts');
  alerts.forEach((alert) => {
    const item = element('p', `levelchange-result-alert is-${alert.tone}`);
    item.append(element('span', '', alert.tone === 'error' ? '!' : '△'), element('span', '', alert.text));
    root.append(item);
  });
  return root;
}

function resultFact(label, value) {
  const root = element('span', 'levelchange-result-fact');
  root.append(element('small', '', label), element('strong', '', value));
  return root;
}

function syncProgressSurface(state) {
  const progress = state.progress || createEmptyProgress();
  const percent = clamp(numberOf(progress.percent, 0), 0, 100);
  state.ui.progressMessage.textContent = progress.message || '대기 중';
  state.ui.progressPercent.textContent = `${Math.round(percent)}%`;
  state.ui.progressBar.style.width = `${percent}%`;
  state.ui.progressTrack.setAttribute('aria-valuenow', String(Math.round(percent)));
  const countText = progress.total > 0 ? ` ${progress.completed}/${progress.total}` : '';
  state.ui.progressDetail.textContent = `${progress.detail || '실행을 시작하면 파일별 진행 상태가 표시됩니다.'}${countText}`;
  state.ui.progressRoot.classList.toggle('is-active', state.busyKind === 'run');
  state.ui.progressRoot.classList.toggle('is-complete', !state.busyKind && percent >= 100);
}

function syncActionState(state) {
  const busy = !!state.busyKind;
  const hasRvts = state.rvtPaths.length > 0;
  const hasWorkbook = /\.xlsx$/i.test(state.workbookPath.trim());
  const applyJobs = getApplyJobs(state);
  const validationReady = !!state.imported?.ok && applyJobs.length > 0;

  state.ui.pickRvtButton.disabled = busy;
  state.ui.clearRvtButton.disabled = busy || !hasRvts;
  state.ui.rvtSearch.disabled = busy && state.busyKind === 'run';
  state.ui.exportTemplateButton.disabled = busy || !hasRvts;
  state.ui.pickWorkbookButton.disabled = busy || !hasRvts;
  state.ui.importWorkbookButton.disabled = busy || !hasRvts || !hasWorkbook;
  state.ui.workbookInput.disabled = busy && state.busyKind === 'run';
  state.ui.jobSearch.disabled = !state.imported?.jobs?.length;
  state.ui.pickOutputButton.disabled = busy;
  state.ui.outputInput.disabled = busy && state.busyKind === 'run';
  state.ui.syncCommentInput.disabled = busy && state.busyKind === 'run';
  state.ui.runButton.disabled = busy || !hasRvts || !hasWorkbook || !validationReady;
  state.ui.runButton.textContent = state.busyKind === 'run' ? 'Level 변경 실행 중...' : 'Level 변경 실행';
  state.ui.openOutputButton.disabled = busy || !(state.result?.outputFolder || state.outputFolder);

  setReadinessState(
    state.ui.readySources,
    state.ui.readySourcesValue,
    hasRvts ? `${state.rvtPaths.length}개` : '미등록',
    hasRvts ? 'ready' : 'idle'
  );
  setReadinessState(
    state.ui.readyWorkbook,
    state.ui.readyWorkbookValue,
    hasWorkbook ? '등록' : '미등록',
    hasWorkbook ? 'ready' : 'idle'
  );
  setReadinessState(
    state.ui.readyValidation,
    state.ui.readyValidationValue,
    validationReady ? `${applyJobs.length}건 실행` : (state.imported ? '오류 확인' : '미검증'),
    validationReady ? 'ready' : (state.imported ? 'error' : 'idle')
  );
}

function syncInputsFromState(state) {
  assignInputValue(state, state.ui.workbookInput, state.workbookPath);
  assignInputValue(state, state.ui.outputInput, state.outputFolder);
  assignInputValue(state, state.ui.syncCommentInput, state.syncComment || DEFAULT_SYNC_COMMENT);
}

function assignInputValue(state, input, value) {
  if (!input) return;
  if (document.activeElement === input && (state.compositionActive || state.activePointerIds.size > 0)) return;
  const next = stringOf(value);
  if (input.value !== next) input.value = next;
}

function setRunStatus(state, message, tone = 'idle') {
  state.statusMessage = stringOf(message);
  state.statusTone = tone;
  if (!state.ui.runStatus) return;
  state.ui.runStatus.textContent = state.statusMessage;
  setTone(state.ui.runStatus, tone);
}

function setStepState(node, label, tone) {
  if (!node) return;
  node.textContent = label;
  setTone(node, tone);
}

function setReadinessState(root, valueNode, label, tone) {
  if (!root || !valueNode) return;
  valueNode.textContent = label;
  setTone(root, tone);
  const mark = root.querySelector('.levelchange-ready-mark');
  if (mark) mark.textContent = tone === 'ready' ? '✓' : (tone === 'error' ? '!' : '·');
}

function setTone(node, tone) {
  if (!node) return;
  ['idle', 'ready', 'success', 'warning', 'error', 'busy'].forEach((name) => node.classList.remove(`is-${name}`));
  node.classList.add(`is-${tone || 'idle'}`);
}

function invalidateImportedData(state) {
  const changed = !!state.imported || !!state.result;
  state.imported = null;
  state.result = null;
  return changed;
}

function getApplyJobs(state) {
  return (state.imported?.jobs || []).filter((job) => isApplyJob(job) && !job.validationMessage);
}

function isApplyJob(job) {
  return String(job?.action || '').trim().toUpperCase() === 'APPLY';
}

function buildSettingsPayload(state) {
  return {
    rvtPaths: [...state.rvtPaths],
    workbookPath: state.workbookPath.trim(),
    outputFolder: state.outputFolder.trim(),
    closeAllWorksetsOnOpen: true,
    synchronizeAfterProcessing: true,
    syncComment: state.syncComment.trim() || DEFAULT_SYNC_COMMENT
  };
}

function buildRequestPayload(state, requestId, extraPayload = {}) {
  return {
    ...buildSettingsPayload(state),
    ...extraPayload,
    requestId: stringOf(requestId)
  };
}

function createInstanceId() {
  levelChangeMountSequence += 1;
  const time = Date.now().toString(36);
  const tick = typeof performance !== 'undefined' && typeof performance.now === 'function'
    ? Math.floor(performance.now() * 1000).toString(36)
    : '0';
  return `${time}-${tick}-${levelChangeMountSequence.toString(36)}`;
}

function createRequestId(state, kind) {
  state.requestSerial += 1;
  return `levelchange-${state.instanceId}-${stringOf(kind) || 'request'}-${state.requestSerial.toString(36)}`;
}

function createFieldRevisions() {
  return {
    rvtPaths: 0,
    workbookPath: 0,
    outputFolder: 0,
    syncComment: 0
  };
}

function markFieldChanged(state, field) {
  if (!state.fieldRevisions || !Object.prototype.hasOwnProperty.call(state.fieldRevisions, field)) return;
  state.fieldRevisions[field] += 1;
}

function captureRequestSnapshot(state) {
  return {
    revisions: { ...state.fieldRevisions },
    settings: buildSettingsPayload(state)
  };
}

function snapshotFieldStillCurrent(state, snapshot, field) {
  if (!snapshot?.revisions || !snapshot?.settings) return false;
  if (snapshot.revisions[field] !== state.fieldRevisions?.[field]) return false;
  if (field === 'rvtPaths') {
    const before = normalizeRvtPaths(snapshot.settings.rvtPaths).map(pathKey);
    const current = normalizeRvtPaths(state.rvtPaths).map(pathKey);
    return before.length === current.length && before.every((value, index) => value === current[index]);
  }
  const currentSettings = buildSettingsPayload(state);
  return stringOf(snapshot.settings[field]) === stringOf(currentSettings[field]);
}

function initFieldStillCurrent(state, field) {
  return snapshotFieldStillCurrent(state, state.initSnapshot, field);
}

function activeRequestFieldsCurrent(state, fields) {
  const snapshot = state.activeRequest?.snapshot;
  return arrayOf(fields).every((field) => snapshotFieldStillCurrent(state, snapshot, field));
}

function finishStaleResponse(state, expectedKind, message) {
  finishRequest(state, expectedKind);
  setRunStatus(state, message, 'warning');
  toast(message, 'warn', 4400);
}

function requestIdOf(payload) {
  return stringOf(pick(payload, 'requestId', 'RequestId')).trim();
}

function isNativeDropPayload(payload) {
  return !requestIdOf(payload) && boolOf(pick(payload, 'dropped', 'Dropped'));
}

function acceptInitResponse(state, payload) {
  const responseId = requestIdOf(payload);
  return !!responseId && !!state.initRequestId && responseId === state.initRequestId;
}

function acceptExpectedResponse(state, payload, expectedKind, options = {}) {
  const responseId = requestIdOf(payload);
  if (options.allowNativeDrop && isNativeDropPayload(payload)) {
    return !state.activeRequest && !state.busyKind;
  }
  const active = state.activeRequest;
  return !!responseId
    && !!active
    && active.kind === expectedKind
    && active.requestId === responseId;
}

function acceptActiveResponse(state, payload) {
  const responseId = requestIdOf(payload);
  return !!responseId
    && !!state.activeRequest
    && state.activeRequest.requestId === responseId;
}

function normalizeImported(payload) {
  const jobs = arrayOf(pick(payload, 'jobs', 'Jobs')).map((raw, index) => ({
    rowId: stringOf(pick(raw, 'rowId', 'RowId')) || `row-${index + 1}`,
    excelRowNumber: Math.max(0, numberOf(pick(raw, 'excelRowNumber', 'ExcelRowNumber'), index + 2)),
    action: stringOf(pick(raw, 'action', 'Action')).trim().toUpperCase() || 'APPLY',
    sourceRvtPath: stringOf(pick(raw, 'sourceRvtPath', 'SourceRvtPath')),
    levelName: stringOf(pick(raw, 'levelName', 'LevelName')),
    direction: stringOf(pick(raw, 'direction', 'Direction')).trim().toUpperCase(),
    distanceMillimeters: numberOf(pick(raw, 'distanceMillimeters', 'DistanceMillimeters'), 0),
    note: stringOf(pick(raw, 'note', 'Note')),
    validationMessage: stringOf(pick(raw, 'validationMessage', 'ValidationMessage'))
  }));
  return {
    ok: boolOf(pick(payload, 'ok', 'Ok')),
    message: stringOf(pick(payload, 'message', 'Message')),
    workbookPath: stringOf(pick(payload, 'workbookPath', 'WorkbookPath')),
    jobs,
    errors: arrayOf(pick(payload, 'errors', 'Errors')).map(stringOf).filter(Boolean)
  };
}

function normalizeResult(payload) {
  const rawSummary = pick(payload, 'summary', 'Summary') || {};
  const summary = {};
  [
    'fileCount',
    'successFileCount',
    'partialFileCount',
    'failedFileCount',
    'requestedLevelCount',
    'movedLevelCount',
    'failedLevelCount',
    'warningCount',
    'modifiedElementCount',
    'deletedElementCount',
    'addedElementCount',
    'connectionChangedCount',
    'synchronizedFileCount'
  ].forEach((name) => {
    summary[name] = Math.max(0, numberOf(pick(rawSummary, name, pascal(name)), 0));
  });
  const files = arrayOf(pick(payload, 'files', 'Files')).map((raw) => {
    const reportPath = stringOf(pick(raw, 'reportPath', 'ReportPath'));
    const persistenceReported = hasOwnAny(
      raw,
      'changesPersisted',
      'ChangesPersisted',
      'persistenceStatus',
      'PersistenceStatus',
      'unsafeTransactionState',
      'UnsafeTransactionState'
    );
    const reportGenerated = hasOwnAny(raw, 'reportGenerated', 'ReportGenerated')
      ? boolOf(pick(raw, 'reportGenerated', 'ReportGenerated'))
      : !!reportPath;
    return {
      sourcePath: stringOf(pick(raw, 'sourcePath', 'SourcePath')),
      fileName: stringOf(pick(raw, 'fileName', 'FileName')),
      status: stringOf(pick(raw, 'status', 'Status')),
      message: stringOf(pick(raw, 'message', 'Message')),
      reportPath,
      localPath: stringOf(pick(raw, 'localPath', 'LocalPath')),
      temporaryLocalRetained: boolOf(pick(raw, 'temporaryLocalRetained', 'TemporaryLocalRetained')),
      synchronizePerformed: boolOf(pick(raw, 'synchronizePerformed', 'SynchronizePerformed')),
      synchronizationOutcome: stringOf(pick(raw, 'synchronizationOutcome', 'SynchronizationOutcome')),
      synchronizationOutcomeUncertain: boolOf(pick(raw, 'synchronizationOutcomeUncertain', 'SynchronizationOutcomeUncertain')),
      savePerformed: boolOf(pick(raw, 'savePerformed', 'SavePerformed')),
      changesPersisted: boolOf(pick(raw, 'changesPersisted', 'ChangesPersisted')),
      persistenceStatus: stringOf(pick(raw, 'persistenceStatus', 'PersistenceStatus')),
      persistenceReported,
      unsafeTransactionState: boolOf(pick(raw, 'unsafeTransactionState', 'UnsafeTransactionState')),
      impactCoverage: stringOf(pick(raw, 'impactCoverage', 'ImpactCoverage')),
      impactCaptureIncomplete: boolOf(pick(raw, 'impactCaptureIncomplete', 'ImpactCaptureIncomplete')),
      reportGenerated,
      levelCount: Math.max(0, numberOf(pick(raw, 'levelCount', 'LevelCount'), 0)),
      successCount: Math.max(0, numberOf(pick(raw, 'successCount', 'SuccessCount'), 0)),
      impactCount: Math.max(0, numberOf(pick(raw, 'impactCount', 'ImpactCount'), 0))
    };
  });
  return {
    ok: boolOf(pick(payload, 'ok', 'Ok')),
    message: stringOf(pick(payload, 'message', 'Message')),
    outputFolder: stringOf(pick(payload, 'outputFolder', 'OutputFolder')),
    summary,
    files
  };
}

function createEmptyProgress() {
  return { percent: 0, message: '대기 중', detail: '', completed: 0, total: 0 };
}

function createEmptySummary() {
  return {
    fileCount: 0,
    successFileCount: 0,
    partialFileCount: 0,
    failedFileCount: 0,
    requestedLevelCount: 0,
    movedLevelCount: 0,
    failedLevelCount: 0,
    warningCount: 0,
    modifiedElementCount: 0,
    deletedElementCount: 0,
    addedElementCount: 0,
    connectionChangedCount: 0,
    synchronizedFileCount: 0
  };
}

function directionLabel(value) {
  const normalized = String(value || '').trim().toUpperCase();
  if (normalized === 'UP' || normalized === '위') return '위';
  if (normalized === 'DOWN' || normalized === '아래') return '아래';
  return value || '-';
}

function formatDistance(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric) || numeric <= 0) return '-';
  return numeric.toLocaleString('ko-KR', { maximumFractionDigits: 3 });
}

function resultFileTone(fileOrStatus) {
  const file = fileOrStatus && typeof fileOrStatus === 'object' ? fileOrStatus : null;
  const status = file ? file.status : fileOrStatus;
  const normalized = String(status || '').trim().toLowerCase();
  if (file?.unsafeTransactionState || file?.synchronizationOutcomeUncertain) return 'error';
  if (file?.persistenceReported && !file.changesPersisted) return 'error';
  if (normalized === 'failed' || normalized === 'error') return 'error';
  if (file?.impactCaptureIncomplete || file?.persistenceStatus === 'SynchronizedLocalDirty' || !file?.reportGenerated) return 'warning';
  if (normalized === 'success') return 'success';
  if (normalized === 'partial') return 'warning';
  return 'error';
}

function resultFileStatusLabel(file, tone) {
  if (file?.unsafeTransactionState) return '안전 중단';
  if (file?.synchronizationOutcomeUncertain) return '중앙 확인 필요';
  if (file?.persistenceReported && !file.changesPersisted) return '변경 미반영';
  const normalized = String(file?.status || '').trim().toLowerCase();
  if (normalized === 'failed' || normalized === 'error') return '실패';
  if (file?.impactCaptureIncomplete) return '추적 일부 누락';
  if (file?.persistenceStatus === 'SynchronizedLocalDirty') return '로컬 확인 필요';
  if (!file?.reportGenerated && tone === 'warning') return '보고서 확인';
  if (normalized === 'success') return '완료';
  if (normalized === 'partial') return '일부 실패';
  if (normalized === 'failed') return '실패';
  return file?.status || '알 수 없음';
}

function persistenceLabel(file) {
  const status = stringOf(file?.persistenceStatus).trim();
  const labels = {
    Synchronized: '중앙 반영 확인',
    SynchronizedLocalDirty: '중앙 반영·로컬 변경',
    SynchronizedVerificationFailed: '동기화 후 검증 실패',
    Saved: '파일 저장 확인',
    NoChanges: '변경 없음',
    AuditDraftFailed: '감사 파일 실패',
    UnsafeTransactionState: '안전 상태 불명',
    ExecutionFailed: '실행 실패',
    SyncOutcomeUnknownLocalSaved: '중앙 불명·로컬 저장',
    SyncOutcomeUnknownLocalSaveFailed: '중앙·로컬 불명',
    SynchronizationFailedLocalSaved: '동기화 실패·로컬 저장',
    SynchronizationAndLocalSaveFailed: '동기화·로컬 저장 실패'
  };
  if (labels[status]) return labels[status];
  if (file?.changesPersisted) return file.savePerformed ? '파일 저장 확인' : '변경 반영 확인';
  return status || (file?.persistenceReported ? '반영 미확인' : '정보 없음');
}

function synchronizationLabel(file) {
  if (file?.synchronizationOutcomeUncertain) return '결과 불명';
  const outcome = stringOf(file?.synchronizationOutcome).trim().toLowerCase();
  if (outcome === 'succeeded') return '완료';
  if (outcome === 'succeededlocaldirty') return '완료·로컬 변경';
  if (outcome === 'outcomeunknown') return '결과 불명';
  if (outcome === 'failed') return '실패';
  if (file?.synchronizePerformed) return '완료';
  if (file?.savePerformed && file?.changesPersisted) return '해당 없음(저장)';
  return '안 함';
}

function normalizeRvtPaths(paths) {
  const result = [];
  const seen = new Set();
  arrayOf(paths).forEach((raw) => {
    const path = stringOf(raw).trim();
    if (!path || !/\.rvt$/i.test(path)) return;
    const key = pathKey(path);
    if (seen.has(key)) return;
    seen.add(key);
    result.push(path);
  });
  return result;
}

function scheduleDraftSave(state) {
  if (state.disposed) return;
  if (state.persistTimer) window.clearTimeout(state.persistTimer);
  state.persistTimer = window.setTimeout(() => {
    state.persistTimer = 0;
    writeDraft(state);
  }, DRAFT_SAVE_DELAY_MS);
}

function flushDraftSave(state) {
  if (state.persistTimer) window.clearTimeout(state.persistTimer);
  state.persistTimer = 0;
  writeDraft(state);
}

function writeDraft(state) {
  try {
    localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify({
      rvtPaths: [...state.rvtPaths],
      workbookPath: state.workbookPath,
      outputFolder: state.outputFolder,
      syncComment: state.syncComment
    }));
  } catch {
  }
}

function loadDraft() {
  try {
    const parsed = JSON.parse(localStorage.getItem(DRAFT_STORAGE_KEY) || '{}');
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function setFocusKey(node, key) {
  if (node && key) node.dataset.levelchangeFocusKey = String(key);
  return node;
}

function setScrollKey(node, key) {
  if (node && key) node.dataset.levelchangeScrollKey = String(key);
  return node;
}

function withInteractionPatch(state, patch) {
  const transaction = beginInteractionPatch(state);
  try {
    patch();
  } finally {
    completeInteractionPatch(state, transaction);
  }
}

function beginInteractionPatch(state) {
  state.interactionRestoreGeneration += 1;
  return {
    generation: state.interactionRestoreGeneration,
    snapshot: captureInteraction(state)
  };
}

function captureInteraction(state) {
  const active = document.activeElement;
  const focusKey = stringOf(active?.dataset?.levelchangeFocusKey);
  const focus = focusKey && isInInteractionSurface(state, active)
    ? captureFocus(active, focusKey)
    : null;
  return {
    focus,
    scroll: getScrollElements(state).map((node) => ({
      node,
      key: stringOf(node.dataset?.levelchangeScrollKey),
      top: Math.max(0, numberOf(node.scrollTop, 0)),
      left: Math.max(0, numberOf(node.scrollLeft, 0))
    }))
  };
}

function captureFocus(node, key) {
  let selectionStart = null;
  let selectionEnd = null;
  let selectionDirection = null;
  try {
    if (typeof node.selectionStart === 'number' && typeof node.selectionEnd === 'number') {
      selectionStart = node.selectionStart;
      selectionEnd = node.selectionEnd;
      selectionDirection = node.selectionDirection || 'none';
    }
  } catch {
  }
  return {
    node,
    key,
    value: 'value' in node ? String(node.value) : null,
    checked: 'checked' in node ? !!node.checked : null,
    indeterminate: 'indeterminate' in node ? !!node.indeterminate : null,
    selectionStart,
    selectionEnd,
    selectionDirection
  };
}

function getScrollElements(state) {
  const candidates = [];
  const add = (node) => {
    if (node) candidates.push(node);
  };
  interactionRoots(state).forEach((root) => {
    if (root.matches?.('[data-levelchange-scroll-key]')) add(root);
    root.querySelectorAll?.('[data-levelchange-scroll-key]').forEach(add);
  });
  [state.ui.workspace, state.ui.runPanel].forEach((start) => {
    let current = start;
    while (current && current !== document.body) {
      add(current);
      current = current.parentElement;
    }
  });
  add(document.scrollingElement || document.documentElement || document.body);
  const seen = new Set();
  return candidates.filter((node) => {
    if (!node || seen.has(node)) return false;
    seen.add(node);
    return true;
  });
}

function completeInteractionPatch(state, transaction) {
  const snapshot = transaction?.snapshot;
  const generation = transaction?.generation;
  if (!snapshot) return;
  const canRestore = () => !state.disposed
    && state.interactionRestoreGeneration === generation
    && !!state.ui.page?.isConnected;
  const restore = (restoreFocusToo = false) => {
    if (!canRestore()) return;
    if (restoreFocusToo) restoreFocus(state, snapshot.focus);
    restoreScroll(state, snapshot.scroll);
  };
  restore(true);
  if (typeof window.requestAnimationFrame === 'function') {
    window.requestAnimationFrame(() => {
      restore(false);
      window.requestAnimationFrame(() => restore(false));
    });
  } else {
    window.setTimeout(() => restore(false), 0);
  }
}

function restoreFocus(state, snapshot) {
  if (!snapshot) return;
  const node = snapshot.node?.isConnected ? snapshot.node : findFocusNode(state, snapshot.key);
  if (!node || node.disabled) return;
  if ('value' in node && snapshot.value !== null && String(node.value) !== snapshot.value) node.value = snapshot.value;
  if ('checked' in node && snapshot.checked !== null) node.checked = snapshot.checked;
  if ('indeterminate' in node && snapshot.indeterminate !== null) node.indeterminate = snapshot.indeterminate;
  if (document.activeElement !== node) {
    try {
      node.focus({ preventScroll: true });
    } catch {
      node.focus?.();
    }
  }
  if (document.activeElement !== node || snapshot.selectionStart === null) return;
  try {
    node.setSelectionRange(snapshot.selectionStart, snapshot.selectionEnd, snapshot.selectionDirection || 'none');
  } catch {
  }
}

function restoreScroll(state, snapshots) {
  arrayOf(snapshots).forEach((snapshot) => {
    const node = snapshot.node?.isConnected ? snapshot.node : findScrollNode(state, snapshot.key);
    if (!node?.isConnected) return;
    const maxTop = Math.max(0, node.scrollHeight - node.clientHeight);
    const maxLeft = Math.max(0, node.scrollWidth - node.clientWidth);
    node.scrollTop = Math.min(Math.max(0, snapshot.top), maxTop);
    node.scrollLeft = Math.min(Math.max(0, snapshot.left), maxLeft);
  });
}

function findFocusNode(state, key) {
  if (!key) return null;
  return interactionRoots(state)
    .flatMap((root) => Array.from(root.querySelectorAll?.('[data-levelchange-focus-key]') || []))
    .find((node) => node.dataset.levelchangeFocusKey === key) || null;
}

function findScrollNode(state, key) {
  if (!key) return null;
  return interactionRoots(state)
    .flatMap((root) => {
      const nodes = Array.from(root.querySelectorAll?.('[data-levelchange-scroll-key]') || []);
      if (root.matches?.('[data-levelchange-scroll-key]')) nodes.unshift(root);
      return nodes;
    })
    .find((node) => node.dataset.levelchangeScrollKey === key) || null;
}

function emptyBlock(message) {
  const root = element('div', 'levelchange-empty');
  root.append(element('span', '', '—'), element('p', '', message));
  return root;
}

function element(tagName, className = '', text = null) {
  const node = document.createElement(tagName);
  if (className) node.className = className;
  if (text !== null && text !== undefined) node.textContent = String(text);
  return node;
}

function fileName(path) {
  const parts = stringOf(path).split(/[\\/]/).filter(Boolean);
  return parts[parts.length - 1] || stringOf(path) || 'RVT';
}

function pathKey(value) {
  return stringOf(value).trim().replace(/\//g, '\\').toLowerCase();
}

function normalizeSearch(value) {
  return stringOf(value).trim().normalize('NFC').toLowerCase();
}

function stableHash(value) {
  const text = pathKey(value);
  let hash = 2166136261;
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

function pick(source, ...names) {
  if (!source || typeof source !== 'object') return undefined;
  for (const name of names) {
    if (Object.prototype.hasOwnProperty.call(source, name)) return source[name];
  }
  return undefined;
}

function hasOwnAny(source, ...names) {
  return !!source && typeof source === 'object'
    && names.some((name) => Object.prototype.hasOwnProperty.call(source, name));
}

function arrayOf(value) {
  if (Array.isArray(value)) return value;
  if (value == null) return [];
  if (typeof value === 'string') return [value];
  try {
    return Array.from(value);
  } catch {
    return [];
  }
}

function stringOf(value) {
  return value == null ? '' : String(value);
}

function numberOf(value, fallback = 0) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : fallback;
}

function boolOf(value) {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value !== 0;
  return /^(true|1|yes)$/i.test(stringOf(value).trim());
}

function isCancelled(payload) {
  return boolOf(pick(payload, 'cancelled', 'Cancelled'));
}

function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value));
}

function pascal(value) {
  const text = stringOf(value);
  return text ? text[0].toUpperCase() + text.slice(1) : '';
}
