import { clear, div, toast, chooseExcelMode, getLastExcelExportLocale, showCompletionSummaryDialog, closeCompletionSummaryDialog, showExcelSavedDialog } from '../core/dom.js?v=20260713scheduleexportlayout1';
import { onHost, post } from '../core/bridge.js';
import { ProgressDialog } from '../core/progress.js?v=20260701a';
import { attachRvtDropZone } from '../core/rvtDrop.js?v=20260707rvtdrop1';
import { attachExcelDropZone } from '../core/excelDrop.js?v=20260710scheduleio1';
import { refreshUiAfterHostDialog } from '../core/hostDialog.js?v=20260701a';

const IDENTITY_HEADERS = new Set([
  'rvt file', 'rvt 파일', '파일명', 'file name', 'filename', 'rvt path',
  'element id', 'elementid', 'id', '요소 id', '요소id',
  'unique id', 'uniqueid', '고유 id', '고유id',
  'family', 'family name', '패밀리', '패밀리 이름',
  'type', 'type name', '타입', '타입 이름', 'category', '카테고리',
  'host rvt file', 'linked element id', 'kky source kind', 'kky import policy'
]);
const SCHEDULEIO_SETTINGS_KEY = 'kky.settings.scheduleio.v1';

let activeScheduleIoCleanup = null;

function normalizeScheduleIoExtractionMode(value) {
  const mode = String(value || '').trim().toLowerCase();
  if (mode === 'schedule' || mode === 'all') return mode;
  return 'elements';
}

function getScheduleIoExtractionModeLabel(value) {
  switch (normalizeScheduleIoExtractionMode(value)) {
    case 'schedule':
      return '스케줄 표시 그대로';
    case 'all':
      return '전체 객체 + 스케줄 필드';
    default:
      return '해당 객체 전체';
  }
}

function normalizeScheduleIoOutputMode(value) {
  return String(value || '').trim().toLowerCase() === 'files' ? 'files' : 'workbook';
}

function normalizeScheduleIoUnitMode(value) {
  return String(value || '').trim().toLowerCase() === 'active' ? 'active' : 'source';
}

function getScheduleIoUnitModeLabel(value) {
  return normalizeScheduleIoUnitMode(value) === 'active' ? '활성 문서 단위' : '원본 스케줄 단위';
}

function canUseScheduleIoUnits(state) {
  return normalizeScheduleIoUnitMode(state.unitMode) !== 'active' || state.activeDocument.canUse;
}

function normalizeScheduleIoSheetLayout(value) {
  const layout = String(value || '').trim().toLowerCase();
  return layout === 'single' || layout === 'category' ? layout : 'schedule';
}

function normalizeScheduleIoExcelMode(value) {
  return String(value || '').trim().toLowerCase() === 'normal' ? 'normal' : 'fast';
}

function normalizeScheduleIoExportLocale(value) {
  return String(value || '').trim().toLowerCase() === 'en' ? 'en' : 'ko';
}

function getScheduleIoOutputModeLabel(value, targetKind = 'batch') {
  if (targetKind !== 'batch') return 'Excel 한 파일';
  return normalizeScheduleIoOutputMode(value) === 'files' ? 'RVT별 Excel' : '통합 Excel';
}

function getScheduleIoSheetLayoutLabel(value) {
  switch (normalizeScheduleIoSheetLayout(value)) {
    case 'single':
      return '한 시트로 통합';
    case 'category':
      return '카테고리별 시트';
    default:
      return '스케줄별 시트';
  }
}

function getEffectiveScheduleIoOutputMode(state, targetKind = state.exportTargetKind) {
  return targetKind === 'batch' ? normalizeScheduleIoOutputMode(state.outputMode) : 'workbook';
}

function loadScheduleIoPreferences() {
  try {
    const value = JSON.parse(localStorage.getItem(SCHEDULEIO_SETTINGS_KEY) || 'null');
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

function normalizeScheduleIoPreferences(value = {}) {
  return {
    mode: value.mode === 'import' ? 'import' : 'export',
    extractionMode: normalizeScheduleIoExtractionMode(value.extractionMode),
    unitMode: normalizeScheduleIoUnitMode(value.unitMode),
    exportTargetKind: value.exportTargetKind === 'batch' ? 'batch' : 'active',
    importTargetKind: value.importTargetKind === 'batch' ? 'batch' : 'active',
    includeLinks: !!value.includeLinks,
    includeFileName: !!value.includeFileName,
    outputMode: normalizeScheduleIoOutputMode(value.outputMode),
    sheetLayout: normalizeScheduleIoSheetLayout(value.sheetLayout),
    excelMode: normalizeScheduleIoExcelMode(value.excelMode),
    exportLocale: normalizeScheduleIoExportLocale(value.exportLocale || getLastExcelExportLocale()),
    clearBlankValues: !!value.clearBlankValues,
    synchronizeActiveDocument: !!value.synchronizeActiveDocument,
    synchronizationComment: String(value.synchronizationComment ?? 'KKY Tool Schedule Excel Import').slice(0, 240)
  };
}

function serializeScheduleIoPreferences(value) {
  return JSON.stringify(normalizeScheduleIoPreferences(value));
}

function applyScheduleIoPreferences(state, value) {
  if (!value || typeof value !== 'object') return;
  const previousMode = state.mode;
  const previousImportTargetKind = state.importTargetKind;
  Object.assign(state, normalizeScheduleIoPreferences(value));
  if (previousImportTargetKind !== state.importTargetKind) {
    state.inspection = null;
    state.inspectionTargetKind = '';
  }
  if (previousMode !== state.mode && state.mode === 'export') state.exportStep = 1;
}

function saveScheduleIoPreferences(state) {
  const serialized = serializeScheduleIoPreferences(state);
  if (serialized === state.lastSavedPreferences) return;
  try {
    localStorage.setItem(SCHEDULEIO_SETTINGS_KEY, serialized);
    state.lastSavedPreferences = serialized;
  } catch {
    return;
  }
  try {
    localStorage.setItem('kky.hub.excelExportLocale', normalizeScheduleIoExportLocale(state.exportLocale));
  } catch {}
}

function attachScheduleIoPreferenceSync(page, state) {
  let saveTimer = 0;
  let applyTimer = 0;
  let pointerInteractionActive = false;
  let compositionActive = false;
  const scheduleSave = () => {
    // If a remote update was waiting while the user started a new edit, the
    // user's current state wins. Persist it before that older value can apply.
    const hasLocalPreferenceChange = serializeScheduleIoPreferences(state) !== state.lastSavedPreferences;
    if (applyTimer && hasLocalPreferenceChange) {
      clearTimeout(applyTimer);
      applyTimer = 0;
      saveScheduleIoPreferences(state);
    }
    clearTimeout(saveTimer);
    saveTimer = window.setTimeout(() => {
      saveTimer = 0;
      saveScheduleIoPreferences(state);
    }, 180);
  };
  const scheduleSaveAfterClick = scheduleSave;
  page.addEventListener('input', scheduleSave);
  page.addEventListener('change', scheduleSave);
  page.addEventListener('click', scheduleSaveAfterClick);

  const containsScheduleIoElement = (element) => !!(
    element
    && (page.contains(element) || state.ui.modal?.contains(element))
  );
  const isEditingControl = (element) => !!(
    containsScheduleIoElement(element)
    && element.matches?.('input, textarea, select, [contenteditable="true"]')
  );
  const tryApply = () => {
    clearTimeout(applyTimer);
    applyTimer = 0;
    if (!page.isConnected) return;
    const value = loadScheduleIoPreferences();
    if (!value) return;
    const serialized = serializeScheduleIoPreferences(value);
    // The shared-settings host echoes a locally saved value back to this WebView.
    // Rebuilding the form for that identical echo used to replace the active input.
    if (serialized === state.lastSavedPreferences) return;
    const active = document.activeElement;
    if (
      state.busy
      || state.modalOpen
      || pointerInteractionActive
      || compositionActive
      || isEditingControl(active)
    ) {
      applyTimer = window.setTimeout(tryApply, 400);
      return;
    }
    const previousMode = state.mode;
    applyScheduleIoPreferences(state, value);
    state.lastSavedPreferences = serialized;
    // 다른 Revit 창의 옵션 변경은 다음 실행에 반영하되, 이미 완료된
    // 추출 결과와 exportToken은 유지한다. 결과창만 남고 내보내기가
    // 동작하지 않는 stale dialog 상태를 만들면 안 된다.
    renderAll(state, { preserveScroll: previousMode === state.mode });
  };
  const retryPendingApply = () => {
    if (!applyTimer) return;
    clearTimeout(applyTimer);
    applyTimer = window.setTimeout(tryApply, 0);
  };
  const onPointerDown = (event) => {
    if (containsScheduleIoElement(event?.target)) pointerInteractionActive = true;
  };
  const onPointerEnd = () => {
    if (!pointerInteractionActive) return;
    pointerInteractionActive = false;
    retryPendingApply();
  };
  const onCompositionStart = (event) => {
    if (containsScheduleIoElement(event?.target)) compositionActive = true;
  };
  const onCompositionEnd = () => {
    if (!compositionActive) return;
    compositionActive = false;
    retryPendingApply();
  };
  const onFocusOut = (event) => {
    if (!containsScheduleIoElement(event?.target)) return;
    window.setTimeout(retryPendingApply, 0);
  };
  const onSharedChange = (event) => {
    const detail = event?.detail;
    const keys = Array.isArray(detail?.keys) ? [...detail.keys] : [];
    if (detail?.key) keys.push(detail.key);
    if (detail?.values && typeof detail.values === 'object') keys.push(...Object.keys(detail.values));
    if (!detail || !keys.length || keys.includes(SCHEDULEIO_SETTINGS_KEY)) tryApply();
  };
  document.addEventListener('pointerdown', onPointerDown, true);
  window.addEventListener('pointerup', onPointerEnd, true);
  window.addEventListener('pointercancel', onPointerEnd, true);
  document.addEventListener('compositionstart', onCompositionStart, true);
  document.addEventListener('compositionend', onCompositionEnd, true);
  document.addEventListener('focusout', onFocusOut, true);
  window.addEventListener('kky:shared-settings-changed', onSharedChange);
  return () => {
    if (saveTimer) saveScheduleIoPreferences(state);
    clearTimeout(saveTimer);
    clearTimeout(applyTimer);
    saveTimer = 0;
    applyTimer = 0;
    page.removeEventListener('input', scheduleSave);
    page.removeEventListener('change', scheduleSave);
    page.removeEventListener('click', scheduleSaveAfterClick);
    document.removeEventListener('pointerdown', onPointerDown, true);
    window.removeEventListener('pointerup', onPointerEnd, true);
    window.removeEventListener('pointercancel', onPointerEnd, true);
    document.removeEventListener('compositionstart', onCompositionStart, true);
    document.removeEventListener('compositionend', onCompositionEnd, true);
    document.removeEventListener('focusout', onFocusOut, true);
    window.removeEventListener('kky:shared-settings-changed', onSharedChange);
  };
}

export function renderScheduleIo(root) {
  activeScheduleIoCleanup?.();

  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);

  const savedPreferences = loadScheduleIoPreferences();
  const state = {
    mode: savedPreferences?.mode === 'import' ? 'import' : 'export',
    exportStep: 1,
    extractionMode: normalizeScheduleIoExtractionMode(savedPreferences?.extractionMode),
    unitMode: normalizeScheduleIoUnitMode(savedPreferences?.unitMode),
    exportTargetKind: savedPreferences?.exportTargetKind === 'batch' ? 'batch' : 'active',
    importTargetKind: savedPreferences?.importTargetKind === 'batch' ? 'batch' : 'active',
    activeDocument: { name: '', path: '', canUse: false, isWorkshared: false },
    sourceKind: 'active',
    sourcePath: '',
    sourceName: '',
    schedules: [],
    selectedScheduleIds: new Set(),
    scheduleQuery: '',
    targetPaths: [],
    includeLinks: !!savedPreferences?.includeLinks,
    includeActiveDocument: false,
    includeFileName: !!savedPreferences?.includeFileName,
    outputMode: normalizeScheduleIoOutputMode(savedPreferences?.outputMode),
    sheetLayout: normalizeScheduleIoSheetLayout(savedPreferences?.sheetLayout),
    excelMode: normalizeScheduleIoExcelMode(savedPreferences?.excelMode),
    exportLocale: normalizeScheduleIoExportLocale(savedPreferences?.exportLocale || getLastExcelExportLocale()),
    workbookPath: '',
    workbookName: '',
    workbookSheets: [],
    selectedSheets: new Set(),
    selectedColumns: new Set(),
    mappings: [],
    inspection: null,
    inspectionTargetKind: '',
    clearBlankValues: !!savedPreferences?.clearBlankValues,
    synchronizeActiveDocument: !!savedPreferences?.synchronizeActiveDocument,
    synchronizationComment: String(savedPreferences?.synchronizationComment ?? 'KKY Tool Schedule Excel Import').slice(0, 240),
    busy: false,
    lastResult: null,
    modalOpen: false,
    modalSnapshot: null,
    interactionRestoreGeneration: 0,
    dropCleanup: null,
    excelDropCleanup: null,
    ui: {}
  };
  state.lastSavedPreferences = serializeScheduleIoPreferences(state);

  const page = div('feature-shell scheduleio-page');
  const workspace = setScheduleIoScrollKey(div('scheduleio-workspace'), 'workspace');
  const runPanel = div('scheduleio-run-panel');
  const modal = buildTargetModal(state);
  page.append(workspace, runPanel);
  target.append(page);
  document.body.append(modal);

  state.ui.workspace = workspace;
  state.ui.runPanel = runPanel;
  state.ui.modal = modal;
  const preferenceCleanup = attachScheduleIoPreferenceSync(page, state);

  const cleanup = () => {
    state.interactionRestoreGeneration += 1;
    state.dropCleanup?.();
    state.excelDropCleanup?.();
    state.dropCleanup = null;
    state.excelDropCleanup = null;
    modal.remove();
    preferenceCleanup();
    closeCompletionSummaryDialog();
    window.removeEventListener('hashchange', cleanupOnRouteChange);
    if (activeScheduleIoCleanup === cleanup) activeScheduleIoCleanup = null;
  };
  const cleanupOnRouteChange = () => {
    const route = String(location.hash || '').replace(/^#/, '').split('?')[0].toLowerCase();
    if (route !== 'scheduleio') cleanup();
  };
  activeScheduleIoCleanup = cleanup;
  window.addEventListener('hashchange', cleanupOnRouteChange);

  registerHostEvents(state);
  renderAll(state);
  post('scheduleio:init', {});
}

function registerHostEvents(state) {
  onHost('scheduleio:init', (payload) => {
    const active = pick(payload, 'activeDocument', 'ActiveDocument') || {};
    state.activeDocument = {
      name: String(pick(active, 'name', 'Name') || ''),
      path: String(pick(active, 'path', 'Path') || ''),
      canUse: !!pick(active, 'canUse', 'CanUse'),
      isWorkshared: !!pick(active, 'isWorkshared', 'IsWorkshared')
    };
    renderAll(state);
    if (state.activeDocument.canUse && state.sourceKind === 'active' && !state.schedules.length) {
      post('scheduleio:load-active-schedules', {});
    }
  });

  onHost('scheduleio:schedules-loaded', (payload) => {
    const catalog = pick(payload, 'catalog', 'Catalog') || {};
    const schedules = arrayOf(pick(catalog, 'schedules', 'Schedules')).map((item) => ({
      id: Number(pick(item, 'id', 'Id')) || 0,
      name: String(pick(item, 'name', 'Name') || ''),
      fieldCount: Number(pick(item, 'fieldCount', 'FieldCount')) || 0
    })).filter((item) => item.id && item.name);
    state.sourceKind = String(pick(catalog, 'sourceKind', 'SourceKind') || 'active').toLowerCase() === 'active' ? 'active' : 'file';
    state.sourcePath = String(pick(catalog, 'sourcePath', 'SourcePath') || '');
    state.sourceName = String(pick(catalog, 'sourceName', 'SourceName') || '');
    state.schedules = schedules;
    state.selectedScheduleIds = new Set([...state.selectedScheduleIds].filter((id) => schedules.some((item) => item.id === id)));
    state.lastResult = null;
    refreshUiAfterHostDialog(() => renderAll(state));
    toast(`${schedules.length}개 스케줄을 불러왔습니다.`, schedules.length ? 'ok' : 'info');
  });

  onHost('scheduleio:targets-picked', (payload) => {
    if (!state.modalOpen) openTargetModal(state);
    appendTargetPaths(state, arrayOf(pick(payload, 'paths', 'Paths')));
    refreshUiAfterHostDialog(() => renderAll(state));
  });

  onHost('scheduleio:workbook-dropped', (payload) => {
    const path = String(pick(payload, 'path', 'Path') || '');
    if (path) post('scheduleio:read-workbook', { path });
  });

  onHost('scheduleio:workbook-loaded', (payload) => {
    const catalog = pick(payload, 'catalog', 'Catalog') || {};
    state.workbookPath = String(pick(catalog, 'path', 'Path') || '');
    state.workbookName = String(pick(catalog, 'fileName', 'FileName') || fileName(state.workbookPath));
    state.workbookSheets = arrayOf(pick(catalog, 'sheets', 'Sheets')).map((sheet) => ({
      name: String(pick(sheet, 'name', 'Name') || ''),
      rowCount: Number(pick(sheet, 'rowCount', 'RowCount')) || 0,
      headers: arrayOf(pick(sheet, 'headers', 'Headers')).map(String)
    })).filter((sheet) => sheet.name);
    state.selectedSheets = new Set(state.workbookSheets.map((sheet) => sheet.name));
    state.selectedColumns.clear();
    state.mappings = [];
    state.inspection = null;
    state.lastResult = null;
    refreshUiAfterHostDialog(() => renderAll(state));
    toast(`${state.workbookSheets.length}개 시트를 읽었습니다.`, state.workbookSheets.length ? 'ok' : 'info');
  });

  onHost('scheduleio:inspection-done', (payload) => {
    state.busy = false;
    ProgressDialog.hide();
    const result = pick(payload, 'result', 'Result') || {};
    state.inspectionTargetKind = String(pick(payload, 'targetKind', 'TargetKind') || 'active');
    state.inspection = {
      instanceParameters: arrayOf(pick(result, 'instanceParameters', 'InstanceParameters')).map(String),
      typeParameters: arrayOf(pick(result, 'typeParameters', 'TypeParameters')).map(String),
      matchedRows: Number(pick(result, 'matchedRows', 'MatchedRows')) || 0,
      missingElements: Number(pick(result, 'missingElements', 'MissingElements')) || 0,
      identityMismatches: Number(pick(result, 'identityMismatches', 'IdentityMismatches')) || 0,
      blockedLinkedRows: Number(pick(result, 'blockedLinkedRows', 'BlockedLinkedRows')) || 0,
      targetFiles: Number(pick(result, 'targetFiles', 'TargetFiles')) || 0,
      message: String(pick(result, 'message', 'Message') || '')
    };
    renderAll(state);
    toast(state.inspection.message || '대상 파라미터를 확인했습니다.', 'ok');
  });

  onHost('scheduleio:progress', (payload) => {
    ProgressDialog.setActions({});
    ProgressDialog.show(String(pick(payload, 'title', 'Title') || 'Schedule Excel 작업'), String(pick(payload, 'message', 'Message') || ''));
    ProgressDialog.update(Number(pick(payload, 'percent', 'Percent')) || 0, String(pick(payload, 'message', 'Message') || ''), '');
  });

  onHost('scheduleio:export-prepared', (payload) => finishRun(state, payload, 'Export'));
  onHost('scheduleio:export-done', (payload) => finishRun(state, payload, 'Export'));
  onHost('scheduleio:export-saved', (payload) => finishSavedExport(state, payload));
  onHost('scheduleio:export-save-error', (payload) => {
    state.busy = false;
    ProgressDialog.hide();
    const message = String(pick(payload, 'message', 'Message') || 'Schedule Export Excel 저장에 실패했습니다.');
    if (state.lastResult) state.lastResult.saveError = message;
    renderAll(state);
    showScheduleResultDialog(state);
    toast(message, 'err', 4200);
  });
  onHost('scheduleio:import-done', (payload) => finishRun(state, payload, 'Import'));
  onHost('scheduleio:import-log-saved', (payload) => finishSavedImportLog(state, payload));
  onHost('scheduleio:import-log-save-cancelled', () => {
    state.busy = false;
    ProgressDialog.hide();
    renderAll(state);
    showScheduleResultDialog(state);
  });
  onHost('scheduleio:import-log-save-error', (payload) => {
    state.busy = false;
    ProgressDialog.hide();
    const message = String(pick(payload, 'message', 'Message') || 'Schedule Import 결과 Excel 저장에 실패했습니다.');
    if (state.lastResult) state.lastResult.importLogSaveError = message;
    renderAll(state);
    showScheduleResultDialog(state);
    toast(message, 'err', 4200);
  });
  onHost('scheduleio:cancelled', () => {
    state.busy = false;
    ProgressDialog.hide();
    renderAll(state);
    showScheduleResultDialog(state);
  });
  onHost('scheduleio:error', (payload) => {
    state.busy = false;
    ProgressDialog.hide();
    state.lastResult = { ok: false, message: String(pick(payload, 'message', 'Message') || 'Schedule 작업 중 오류가 발생했습니다.') };
    renderAll(state);
    showScheduleResultDialog(state);
    toast(state.lastResult.message, 'err', 4200);
  });
}

function finishRun(state, payload, operation) {
  state.busy = false;
  ProgressDialog.hide();
  const raw = pick(payload, 'result', 'Result') || {};
  state.lastResult = {
    ok: pick(raw, 'ok', 'Ok') !== false && pick(payload, 'ok', 'Ok') !== false,
    operation,
    message: String(pick(raw, 'message', 'Message') || `${operation} 작업을 완료했습니다.`),
    outputPath: String(pick(raw, 'outputPath', 'OutputPath') || ''),
    outputFolder: String(pick(raw, 'outputFolder', 'OutputFolder') || ''),
    outputKind: String(pick(raw, 'outputKind', 'OutputKind') || '').toLowerCase(),
    outputFiles: arrayOf(pick(raw, 'outputFiles', 'OutputFiles')).map(String).filter(Boolean),
    exportToken: String(pick(payload, 'exportToken', 'ExportToken') || pick(raw, 'exportToken', 'ExportToken') || ''),
    targetKind: String(pick(payload, 'targetKind', 'TargetKind') || '').toLowerCase(),
    targetFiles: Number(pick(raw, 'targetFiles', 'TargetFiles')) || 0,
    processedRows: Number(pick(raw, 'processedRows', 'ProcessedRows')) || 0,
    changedValues: Number(pick(raw, 'changedValues', 'ChangedValues')) || 0,
    skippedRows: Number(pick(raw, 'skippedRows', 'SkippedRows')) || 0,
    blockedLinkedRows: Number(pick(raw, 'blockedLinkedRows', 'BlockedLinkedRows')) || 0,
    failedRows: Number(pick(raw, 'failedRows', 'FailedRows')) || 0,
    fileResults: parseFileResults(raw)
  };
  if (operation === 'Import') normalizeImportResult(state.lastResult, raw, payload);
  renderAll(state);
  showScheduleResultDialog(state);
  toast(state.lastResult.message, state.lastResult.toastKind || (state.lastResult.ok ? 'ok' : 'err'), 4200);
}

function normalizeImportResult(result, raw, payload) {
  const count = (camel, pascal) => Math.max(0, Number(pick(raw, camel, pascal)) || 0);
  result.matchedRows = count('matchedRows', 'MatchedRows');
  result.unchangedValues = count('unchangedValues', 'UnchangedValues');
  result.skippedBlankValues = count('skippedBlankValues', 'SkippedBlankValues');
  ['noChanges', 'skipped', 'saved', 'synchronized', 'inMemory', 'failed'].forEach((name) => {
    result[`${name}Files`] = count(`${name}Files`, `${name[0].toUpperCase()}${name.slice(1)}Files`);
  });
  const files = result.fileResults;
  const failed = result.failedRows > 0 || result.failedFiles > 0 ||
    files.some((file) => file.outcome === 'failed' || file.outcome === 'partial' || file.persistenceStatus === 'failed');
  const skipped = result.skippedRows > 0 || result.blockedLinkedRows > 0 || result.skippedFiles > 0 ||
    files.some((file) => file.outcome === 'skipped');
  const reportedFailure = pick(raw, 'ok', 'Ok') === false || pick(payload, 'ok', 'Ok') === false;
  if (result.changedValues > 0) result.importStatus = failed || skipped || reportedFailure ? 'partial' : 'changed';
  else if (failed) result.importStatus = 'failed';
  else if (skipped) result.importStatus = 'skipped';
  else if (reportedFailure) result.importStatus = 'failed';
  else if (result.unchangedValues > 0 || result.noChangesFiles > 0 || files.some((file) => file.outcome === 'unchanged')) result.importStatus = 'unchanged';
  else result.importStatus = 'unverified';

  result.serviceMessage = String(pick(raw, 'message', 'Message') || '');
  result.ok = result.importStatus === 'changed' || result.importStatus === 'unchanged';
  const inMemory = result.inMemoryFiles > 0 || files.some((file) => file.persistenceStatus === 'in-memory');
  const changedFiles = files.filter((file) => file.changedValues > 0);
  const persisted = changedFiles.length > 0 && changedFiles.every((file) => ['saved', 'synchronized'].includes(file.persistenceStatus));
  const labels = {
    changed: inMemory ? '문서에 적용됨 · 직접 저장 필요' : persisted ? '적용 및 저장 완료' : '문서에 적용됨 · 저장 상태 확인 필요',
    unchanged: '변경 없음 · 기존 값과 동일',
    partial: '일부만 적용됨 · 파일별 결과 확인 필요',
    failed: '반영 또는 저장 실패 · 파일별 오류 확인 필요',
    skipped: '반영된 값 없음 · 대상과 건너뛴 사유 확인 필요',
    unverified: '반영 결과 확인 필요 · 적용된 값을 확인할 수 없습니다.'
  };
  result.message = labels[result.importStatus];
  result.toastKind = result.importStatus === 'changed' && persisted ? 'ok' : result.ok ? 'info' : 'err';
}

function finishSavedExport(state, payload) {
  state.busy = false;
  ProgressDialog.hide();
  const raw = pick(payload, 'result', 'Result') || {};
  const current = state.lastResult || {};
  const savedFileResults = parseFileResults(raw);
  state.lastResult = {
    ...current,
    ok: pick(raw, 'ok', 'Ok') !== false && pick(payload, 'ok', 'Ok') !== false,
    operation: 'Export',
    message: String(pick(raw, 'message', 'Message') || current.message || 'Excel 저장을 완료했습니다.'),
    outputPath: String(pick(raw, 'outputPath', 'OutputPath') || ''),
    outputFolder: String(pick(raw, 'outputFolder', 'OutputFolder') || ''),
    outputKind: String(pick(raw, 'outputKind', 'OutputKind') || '').toLowerCase(),
    outputFiles: arrayOf(pick(raw, 'outputFiles', 'OutputFiles')).map(String).filter(Boolean),
    exportToken: String(pick(payload, 'exportToken', 'ExportToken') || current.exportToken || ''),
    targetKind: String(pick(payload, 'targetKind', 'TargetKind') || current.targetKind || '').toLowerCase(),
    targetFiles: Number(pick(raw, 'targetFiles', 'TargetFiles')) || current.targetFiles || 0,
    processedRows: Number(pick(raw, 'processedRows', 'ProcessedRows')) || current.processedRows || 0,
    changedValues: Number(pick(raw, 'changedValues', 'ChangedValues')) || current.changedValues || 0,
    skippedRows: Number(pick(raw, 'skippedRows', 'SkippedRows')) || current.skippedRows || 0,
    failedRows: Number(pick(raw, 'failedRows', 'FailedRows')) || current.failedRows || 0,
    fileResults: savedFileResults.length ? savedFileResults : (current.fileResults || []),
    saveError: ''
  };
  renderAll(state);
  showScheduleResultDialog(state);
  if (state.lastResult.outputPath) {
    showExcelSavedDialog(
      state.lastResult.message || 'Schedule Export Excel 저장을 완료했습니다.',
      state.lastResult.outputPath,
      (path) => post('excel:open', { path })
    );
  } else if (state.lastResult.outputFolder) {
    showExcelSavedDialog(
      state.lastResult.message || 'Schedule Export Excel 저장을 완료했습니다.',
      state.lastResult.outputFolder,
      (path) => post('scheduleio:open-output-folder', { path }),
      { description: '저장된 Excel 폴더를 바로 여시겠습니까?', openLabel: '폴더 열기' }
    );
  }
  toast(state.lastResult.message, state.lastResult.ok ? 'ok' : 'err', 4200);
}

function finishSavedImportLog(state, payload) {
  state.busy = false;
  ProgressDialog.hide();
  const raw = pick(payload, 'result', 'Result') || {};
  const outputPath = String(pick(raw, 'outputPath', 'OutputPath') || pick(payload, 'outputPath', 'OutputPath') || '');
  const message = String(
    pick(raw, 'message', 'Message') ||
    pick(payload, 'message', 'Message') ||
    'Schedule Import 결과 Excel 저장을 완료했습니다.'
  );
  const ok = pick(raw, 'ok', 'Ok') !== false && pick(payload, 'ok', 'Ok') !== false;

  if (!ok || !outputPath) {
    const errorMessage = !ok
      ? message
      : '저장된 Schedule Import 결과 Excel 경로를 확인할 수 없습니다.';
    if (state.lastResult) state.lastResult.importLogSaveError = errorMessage;
    renderAll(state);
    showScheduleResultDialog(state);
    toast(errorMessage, 'err', 4200);
    return;
  }

  if (state.lastResult) {
    state.lastResult.importLogSaveError = '';
    state.lastResult.importLogOutputPath = outputPath;
  }
  renderAll(state);
  showExcelSavedDialog(
    message,
    outputPath,
    (path) => post('excel:open', { path })
  );
}

function setScheduleIoFocusKey(element, key) {
  if (element && key) element.dataset.scheduleioFocusKey = String(key);
  return element;
}

function setScheduleIoScrollKey(element, key) {
  if (element && key) element.dataset.scheduleioScrollKey = String(key);
  return element;
}

function getScheduleIoInteractionRoots(state) {
  return [state.ui.workspace, state.ui.runPanel, state.ui.modal].filter(Boolean);
}

function containsScheduleIoInteractionElement(state, element) {
  return !!element && getScheduleIoInteractionRoots(state).some((root) => root === element || root.contains(element));
}

function findScheduleIoKeyedElement(state, dataKey, value) {
  if (!value) return null;
  const property = dataKey === 'scroll' ? 'scheduleioScrollKey' : 'scheduleioFocusKey';
  for (const root of getScheduleIoInteractionRoots(state)) {
    if (root.dataset?.[property] === value) return root;
    const candidates = root.querySelectorAll?.(`[data-scheduleio-${dataKey}-key]`) || [];
    for (const candidate of candidates) {
      if (candidate.dataset?.[property] === value) return candidate;
    }
  }
  return null;
}

function getScheduleIoScrollElements(state) {
  const candidates = [];
  const add = (element) => {
    if (element) candidates.push(element);
  };

  getScheduleIoInteractionRoots(state).forEach((root) => {
    add(root);
    root.querySelectorAll?.('[data-scheduleio-scroll-key]').forEach(add);
  });

  // Responsive shell layouts can move scrolling from the Schedule workspace to
  // one of its persistent ancestors. Capture those too so a narrow Revit pane
  // behaves the same as the full-width layout.
  [state.ui.workspace, state.ui.runPanel].forEach((start) => {
    let current = start?.parentElement;
    while (current && current !== document.body) {
      add(current);
      current = current.parentElement;
    }
  });
  add(document.scrollingElement || document.documentElement || document.body);

  const seen = new Set();
  return candidates.filter((element) => {
    if (!element || seen.has(element)) return false;
    seen.add(element);
    return true;
  });
}

function captureScheduleIoFocus(state) {
  const element = document.activeElement;
  const key = String(element?.dataset?.scheduleioFocusKey || '');
  if (!key || !containsScheduleIoInteractionElement(state, element)) return null;

  let selectionStart = null;
  let selectionEnd = null;
  let selectionDirection = null;
  try {
    if (typeof element.selectionStart === 'number' && typeof element.selectionEnd === 'number') {
      selectionStart = element.selectionStart;
      selectionEnd = element.selectionEnd;
      selectionDirection = element.selectionDirection || 'none';
    }
  } catch {
  }

  return {
    key,
    value: 'value' in element ? String(element.value) : String(element.textContent || ''),
    selectionStart,
    selectionEnd,
    selectionDirection
  };
}

function captureScheduleIoInteraction(state) {
  return {
    scroll: getScheduleIoScrollElements(state).map((element) => ({
      element,
      key: String(element.dataset?.scheduleioScrollKey || ''),
      top: Math.max(0, Number(element.scrollTop) || 0),
      left: Math.max(0, Number(element.scrollLeft) || 0)
    })),
    focus: captureScheduleIoFocus(state)
  };
}

function resolveScheduleIoScrollElement(state, snapshot) {
  if (snapshot?.element?.isConnected) return snapshot.element;
  return snapshot?.key ? findScheduleIoKeyedElement(state, 'scroll', snapshot.key) : null;
}

function restoreScheduleIoScroll(state, snapshot) {
  (snapshot?.scroll || []).forEach((position) => {
    const element = resolveScheduleIoScrollElement(state, position);
    if (!element || !element.isConnected) return;
    const maxTop = Math.max(0, element.scrollHeight - element.clientHeight);
    const maxLeft = Math.max(0, element.scrollWidth - element.clientWidth);
    element.scrollTop = Math.min(Math.max(0, position.top), maxTop);
    element.scrollLeft = Math.min(Math.max(0, position.left), maxLeft);
  });
}

function restoreScheduleIoFocus(state, snapshot) {
  const focus = snapshot?.focus;
  if (!focus) return;
  const element = findScheduleIoKeyedElement(state, 'focus', focus.key);
  if (!element || element.disabled) return;
  try {
    element.focus({ preventScroll: true });
  } catch {
    element.focus?.();
  }
  if (document.activeElement !== element || focus.selectionStart === null) return;
  const value = 'value' in element ? String(element.value) : String(element.textContent || '');
  if (value !== focus.value) return;
  try {
    element.setSelectionRange(
      focus.selectionStart,
      focus.selectionEnd,
      focus.selectionDirection || 'none'
    );
  } catch {
  }
}

function restoreScheduleIoInteraction(state, snapshot, generation) {
  if (!snapshot) return;
  const canRestore = () => (
    state.interactionRestoreGeneration === generation
    && !!state.ui.workspace?.isConnected
  );
  if (!canRestore()) return;
  restoreScheduleIoFocus(state, snapshot);
  restoreScheduleIoScroll(state, snapshot);
  if (typeof window.requestAnimationFrame === 'function') {
    window.requestAnimationFrame(() => {
      if (!canRestore()) return;
      restoreScheduleIoScroll(state, snapshot);
      window.requestAnimationFrame(() => {
        if (canRestore()) restoreScheduleIoScroll(state, snapshot);
      });
    });
  } else {
    window.setTimeout(() => {
      if (canRestore()) restoreScheduleIoScroll(state, snapshot);
    }, 0);
  }
}

function resetScrollPositions(state) {
  getScheduleIoScrollElements(state).forEach((element) => {
    element.scrollTop = 0;
    element.scrollLeft = 0;
  });
}

function renderAll(state, options = {}) {
  state.interactionRestoreGeneration += 1;
  const interactionRestoreGeneration = state.interactionRestoreGeneration;
  const preserveScroll = options.preserveScroll !== false;
  const interactionSnapshot = preserveScroll ? captureScheduleIoInteraction(state) : null;

  renderWorkspace(state);
  renderRunPanel(state);
  renderTargetModal(state);

  if (!preserveScroll) {
    resetScrollPositions(state);
    return;
  }

  restoreScheduleIoInteraction(state, interactionSnapshot, interactionRestoreGeneration);
}

function renderWorkspace(state) {
  const host = state.ui.workspace;
  clear(host);

  const header = div('scheduleio-workspace-head');
  header.innerHTML = `
    <div>
      <span class="scheduleio-kicker">Schedule Data</span>
      <h2>Excel Import / Export</h2>
    </div>
    <div class="scheduleio-mode" role="tablist" aria-label="작업 선택">
      <button type="button" data-mode="export">Export</button>
      <button type="button" data-mode="import">Import</button>
    </div>`;
  header.querySelectorAll('[data-mode]').forEach((button) => {
    const active = button.dataset.mode === state.mode;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-selected', String(active));
    button.setAttribute('tabindex', active ? '0' : '-1');
    button.addEventListener('click', () => {
      if (state.busy || button.dataset.mode === state.mode) return;
      state.mode = button.dataset.mode;
      if (state.mode === 'export') state.exportStep = 1;
      state.lastResult = null;
      renderAll(state, { preserveScroll: false });
    });
  });
  host.append(header);

  if (state.mode === 'export') renderExportWorkspace(state, host);
  else renderImportWorkspace(state, host);
}

function renderExportWorkspace(state, host) {
  host.append(buildExportSteps(state));

  if (state.exportStep === 1) renderExportSourceStep(state, host);
  else if (state.exportStep === 2) renderExportScheduleStep(state, host);
  else renderExportTargetStep(state, host);
}

function canOpenExportStep(state, stepNumber) {
  if (stepNumber <= 1) return true;
  if (stepNumber === 2) return state.schedules.length > 0;
  return state.schedules.length > 0 && state.selectedScheduleIds.size > 0;
}

function buildExportSteps(state) {
  const steps = div('scheduleio-wizard-steps');
  [
    ['1', '기준과 방식'],
    ['2', '스케줄 선택'],
    ['3', '대상 및 저장']
  ].forEach(([number, label], index) => {
    const stepNumber = index + 1;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `${stepNumber === state.exportStep ? 'is-active' : ''}${stepNumber < state.exportStep ? ' is-complete' : ''}`;
    button.innerHTML = `<span>${number}</span><strong>${label}</strong>`;
    button.disabled = !canOpenExportStep(state, stepNumber);
    button.addEventListener('click', () => {
      state.exportStep = stepNumber;
      renderAll(state, { preserveScroll: false });
    });
    steps.append(button);
  });
  return steps;
}

function renderExportSourceStep(state, host) {
  const sourceCard = createCard('기준 스케줄 문서', '활성 문서 또는 스케줄을 모아 둔 RVT에서 기준 정의를 불러옵니다.');
  const sourceActions = div('scheduleio-inline-actions');
  const activeSource = actionButton('활성 문서 스케줄', () => {
    state.sourceKind = 'active';
    state.sourcePath = '';
    state.sourceName = state.activeDocument.name;
    state.schedules = [];
    state.selectedScheduleIds.clear();
    renderAll(state);
    post('scheduleio:load-active-schedules', {});
  }, state.sourceKind === 'active' ? 'primary' : 'secondary');
  activeSource.disabled = state.busy || !state.activeDocument.canUse;
  const fileSource = actionButton('스케줄 RVT 선택', () => post('scheduleio:pick-source-rvt', {}), state.sourceKind === 'file' ? 'primary' : 'secondary');
  fileSource.disabled = state.busy;
  sourceActions.append(activeSource, fileSource);

  const sourceStatus = div('scheduleio-source-status');
  sourceStatus.innerHTML = `
    <span>${state.sourceKind === 'active' ? '활성 문서' : '스케줄 RVT'}</span>
    <strong>${escapeHtml(state.sourceName || (state.sourceKind === 'active' ? state.activeDocument.name : '') || '선택 필요')}</strong>
    <em>${state.schedules.length}개 스케줄</em>`;
  sourceCard.append(sourceActions, sourceStatus);

  const modeCard = createCard('추출 방식', '선택한 스케줄의 표시 열을 어떤 대상 범위와 형태로 Excel에 만들지 선택합니다.');
  modeCard.append(buildExportChoiceGroup(state, 'extractionMode', [
    {
      value: 'schedule',
      title: '스케줄 표시 그대로',
      description: 'Revit 스케줄에 표시되는 행과 열, 그룹·합계·계산 결과를 보이는 형태로 추출합니다.'
    },
    {
      value: 'elements',
      title: '해당 객체 전체',
      description: '스케줄에 해당하는 모든 객체를 Element ID와 스케줄 필드 값으로 추출합니다.'
    },
    {
      value: 'all',
      title: '전체 객체 + 스케줄 필드',
      description: 'BQC와 같은 전체 범위에 표시 열을 적용합니다. 기본 파라미터는 내부 ID, Shared는 GUID, 일반 Project는 정확한 이름으로 매핑합니다. 수치 단위는 다음 단계의 단위 기준을 따르며, 빈값 사유는 Export Log에 집계합니다.'
    }
  ], 'is-extraction-modes'));

  host.append(sourceCard, modeCard);
}

function renderExportScheduleStep(state, host) {
  const scheduleCard = createCard('Export 스케줄', '기준 문서에서 불러온 스케줄 중 대상 RVT에 적용할 항목을 선택합니다.');
  const unitSection = buildExportSettingSection(
    '필드 단위 기준',
    '선택한 모든 스케줄과 추출 대상에 함께 적용합니다.',
    buildExportChoiceGroup(state, 'unitMode', [
      {
        value: 'source',
        title: '원본 스케줄 단위',
        description: '원본의 필드별 단위를 유지합니다. 별도 설정이 없는 필드는 원본 프로젝트 단위를 따릅니다.'
      },
      {
        value: 'active',
        title: '활성 문서 단위',
        description: state.activeDocument.canUse
          ? '필드별 단위 대신 현재 활성 프로젝트 단위를 적용합니다. 여러 RVT도 같은 단위로 추출합니다.'
          : '활성 프로젝트 문서를 연 뒤 선택할 수 있습니다.',
        disabled: !state.activeDocument.canUse
      }
    ], 'is-unit-modes')
  );
  unitSection.classList.add('scheduleio-unit-settings');
  if (!canUseScheduleIoUnits(state)) {
    const warning = div('scheduleio-unit-warning');
    warning.setAttribute('role', 'status');
    warning.textContent = '활성 프로젝트 문서가 없습니다. 원본 스케줄 단위를 선택하거나 프로젝트 문서를 여세요.';
    unitSection.append(warning);
  }
  scheduleCard.append(unitSection);
  const filter = div('scheduleio-list-toolbar');
  const search = document.createElement('input');
  search.type = 'search';
  search.placeholder = '스케줄 검색';
  search.value = state.scheduleQuery;
  setScheduleIoFocusKey(search, 'schedule-query');
  search.addEventListener('input', () => {
    state.scheduleQuery = search.value || '';
    renderScheduleList(state, list);
  });
  const allButton = actionButton(state.selectedScheduleIds.size === state.schedules.length && state.schedules.length ? '전체 해제' : '전체 선택', () => {
    if (state.selectedScheduleIds.size === state.schedules.length) state.selectedScheduleIds.clear();
    else state.selectedScheduleIds = new Set(state.schedules.map((item) => item.id));
    renderAll(state);
  }, 'secondary');
  allButton.disabled = !state.schedules.length;
  filter.append(search, allButton);
  const list = setScheduleIoScrollKey(div('scheduleio-choice-list scheduleio-schedule-list'), 'schedule-list');
  renderScheduleList(state, list);
  scheduleCard.append(filter, list);

  const selectionSummary = div('scheduleio-export-result-flow');
  selectionSummary.innerHTML = `<strong>${state.selectedScheduleIds.size}개 선택</strong><span>${escapeHtml(state.sourceName || state.activeDocument.name || '기준 문서')} · ${escapeHtml(getScheduleIoExtractionModeLabel(state.extractionMode))} · ${escapeHtml(getScheduleIoUnitModeLabel(state.unitMode))}</span>`;
  scheduleCard.append(selectionSummary);
  host.append(scheduleCard);
}

function renderExportTargetStep(state, host) {
  const targetCount = batchExportTargetCount(state);
  const includeLinkedRows = state.extractionMode === 'all' && state.includeLinks;
  const effectiveOutputMode = getEffectiveScheduleIoOutputMode(state);
  const targetCard = createCard('추출 대상', '활성 문서만 추출하거나 등록한 여러 RVT에 같은 기준 스케줄을 적용합니다.');
  targetCard.append(buildExportChoiceGroup(state, 'exportTargetKind', [
    {
      value: 'active',
      title: '활성 문서',
      description: state.activeDocument.canUse
        ? `${state.activeDocument.name || '현재 문서'}에서 바로 데이터를 추출합니다.`
        : '사용 가능한 활성 프로젝트 문서가 없습니다.'
    },
    {
      value: 'batch',
      title: '여러 RVT',
      description: targetCount
        ? `${targetCount}개 문서에서 같은 스케줄 기준으로 추출합니다.`
        : '대상 RVT를 등록한 뒤 일괄 추출합니다.'
    }
  ]));

  if (state.exportTargetKind === 'batch') {
    const batchPanel = div('scheduleio-target-selection-panel');
    batchPanel.innerHTML = `<div><strong>일괄 추출 대상</strong><span>${targetCount ? `${targetCount}개 문서` : '아직 선택된 문서가 없습니다.'}</span></div>`;
    batchPanel.append(actionButton(
      state.targetPaths.length || includesActiveDocumentInBatch(state) ? '대상 문서 관리' : '대상 RVT 등록',
      () => openTargetModal(state),
      targetCount ? 'secondary' : 'primary'
    ));
    targetCard.append(batchPanel);
  }

  if (state.exportTargetKind === 'batch' || state.extractionMode === 'all') {
    const linkOption = div('scheduleio-export-workset-option');
    linkOption.append(toggleLine('링크 파일 포함', state.includeLinks, (checked) => {
      state.includeLinks = checked;
      if (checked && state.extractionMode === 'all') state.includeFileName = true;
      state.lastResult = null;
      renderAll(state);
    }, false, 'include-links'));
    const linkNote = div('scheduleio-option-note');
    if (state.extractionMode === 'all') {
      linkNote.textContent = state.includeLinks
        ? '현재 로드된 직접 Revit 링크도 같은 스케줄 필드로 추출합니다. 원본 링크 파일명은 RVT File에 항상 포함되고 스케줄의 링크 파일명 필드와 중복되지 않으며, 링크 행은 Import에서 항상 제외됩니다.'
        : '대상 문서 자체의 객체만 추출합니다. 링크 문서는 포함하지 않습니다.';
    } else {
      linkNote.textContent = state.includeLinks
        ? '등록 RVT는 모든 워크셋을 열어 기존 추출 방식의 링크 로드 상태를 유지합니다. 활성 문서는 현재 로드 상태를 그대로 사용합니다.'
        : '등록 RVT는 모든 워크셋을 닫아 빠르게 엽니다. 활성 문서는 다시 열지 않습니다.';
    }
    linkOption.append(linkNote);
    targetCard.append(linkOption);
  }

  const fileNameOption = div('scheduleio-export-workset-option');
  const effectiveIncludeFileName = state.includeFileName || includeLinkedRows;
  fileNameOption.append(toggleLine('파일 이름 포함', effectiveIncludeFileName, (checked) => {
    state.includeFileName = checked;
    state.lastResult = null;
    renderAll(state);
  }, includeLinkedRows, 'include-file-name'));
  const fileNameNote = div('scheduleio-option-note');
  fileNameNote.textContent = includeLinkedRows
    ? '링크 행의 원본 문서를 구분해야 하므로 RVT File 열이 자동으로 포함됩니다.'
    : effectiveIncludeFileName
      ? 'Excel에 RVT File 열을 추가합니다. 객체 기반 추출의 Element ID는 항상 포함됩니다.'
      : '파일 이름 열은 추가하지 않습니다. 선택한 스케줄 필드와 Element ID만 추출합니다.';
  fileNameOption.append(fileNameNote);
  targetCard.append(fileNameOption);

  const saveCard = createCard('Excel 저장 설정', '추출을 시작하기 전에 저장 방식, 시트 구성, 처리 속도와 출력 언어를 확정합니다.');
  if (state.exportTargetKind === 'batch') {
    const outputGroup = buildExportChoiceGroup(state, 'outputMode', [
      {
        value: 'workbook',
        title: '통합 Excel',
        description: '등록한 모든 RVT 결과를 하나의 Excel 파일로 저장합니다.'
      },
      {
        value: 'files',
        title: 'RVT별 Excel',
        description: 'RVT 하나를 추출한 즉시 개별 Excel로 저장하고 다음 RVT를 처리합니다.'
      }
    ]);
    outputGroup.dataset.exportLayout = 'outputMode';
    saveCard.append(buildExportSettingSection(
      '저장 방식',
      'RVT별 Excel은 파일마다 추출과 저장을 끝낸 뒤 다음 RVT로 넘어갑니다.',
      outputGroup
    ));
  } else {
    const activeOutput = div('scheduleio-export-result-flow');
    activeOutput.innerHTML = '<strong>저장 방식 · Excel 한 파일</strong><span>활성 문서 Export는 선택한 저장 파일에 바로 생성합니다.</span>';
    saveCard.append(activeOutput);
  }

  saveCard.append(buildExportSettingSection(
    '시트 구성',
    '선택한 스케줄 결과를 Excel 시트에 나누는 기준입니다.',
    buildExportChoiceGroup(state, 'sheetLayout', [
      {
        value: 'schedule',
        title: '스케줄별 시트',
        description: '선택한 스케줄마다 시트를 하나씩 만듭니다.'
      },
      {
        value: 'single',
        title: '한 시트로 통합',
        description: '모든 결과를 한 시트에 합치고 Schedule Name 열을 추가합니다.'
      },
      {
        value: 'category',
        title: '카테고리별 시트',
        description: '스케줄 카테고리별로 시트를 나누고 Schedule Name 열을 추가합니다.'
      }
    ], 'is-extraction-modes')
  ));

  saveCard.append(buildExportSettingSection(
    'Excel 처리',
    '빠른 추출은 열 너비 계산을 생략하고, 일반 추출은 열 너비를 자동으로 맞춥니다.',
    buildExportChoiceGroup(state, 'excelMode', [
      {
        value: 'fast',
        title: '빠른 추출',
        description: '대용량 결과에 권장합니다. 열 너비 자동 맞춤을 생략합니다.'
      },
      {
        value: 'normal',
        title: '일반 추출',
        description: '저장할 때 각 열의 너비를 내용에 맞게 조정합니다.'
      }
    ])
  ));

  saveCard.append(buildExportSettingSection(
    '출력 언어',
    'Excel 헤더와 안내 문구에 적용할 언어입니다.',
    buildExportChoiceGroup(state, 'exportLocale', [
      {
        value: 'ko',
        title: '한글',
        description: '한글 헤더와 안내 문구로 저장합니다.'
      },
      {
        value: 'en',
        title: '영문',
        description: '영문 헤더와 안내 문구로 저장합니다.'
      }
    ])
  ));

  const summaryCard = createCard('추출 요약', '실행 전 선택 내용을 확인합니다.');
  const summary = div('scheduleio-export-summary-grid');
  const exportColumns = state.extractionMode === 'schedule'
    ? `${effectiveIncludeFileName ? 'RVT File + ' : ''}스케줄 표시 열`
    : includeLinkedRows
      ? 'RVT File + 출처/Import 정책 + Element ID/Linked Element ID + 스케줄 필드'
      : `${effectiveIncludeFileName ? 'RVT File + ' : ''}Element ID + 스케줄 필드`;
  summary.innerHTML = `
    <div><span>기준 문서</span><strong>${escapeHtml(state.sourceName || state.activeDocument.name || '선택 필요')}</strong></div>
    <div><span>스케줄</span><strong>${state.selectedScheduleIds.size}개</strong></div>
    <div><span>추출 방식</span><strong>${escapeHtml(getScheduleIoExtractionModeLabel(state.extractionMode))}</strong></div>
    <div><span>필드 단위</span><strong>${escapeHtml(getScheduleIoUnitModeLabel(state.unitMode))}</strong></div>
    <div><span>추출 대상</span><strong>${state.exportTargetKind === 'active' ? '활성 문서' : `${targetCount}개 문서`}</strong></div>
    <div><span>링크 파일</span><strong>${includeLinkedRows ? '포함 · 파일명 표시 · Import 제외' : (state.exportTargetKind === 'batch' && state.includeLinks ? '기존 방식 링크 로드' : '포함 안 함')}</strong></div>
    <div><span>Excel 열</span><strong>${escapeHtml(exportColumns)}</strong></div>
    <div><span>저장 방식</span><strong>${escapeHtml(getScheduleIoOutputModeLabel(effectiveOutputMode, state.exportTargetKind))}</strong></div>
    <div><span>시트 구성</span><strong>${escapeHtml(getScheduleIoSheetLayoutLabel(state.sheetLayout))}</strong></div>
    <div><span>Excel 처리</span><strong>${state.excelMode === 'normal' ? '일반 추출' : '빠른 추출'}</strong></div>
    <div><span>출력 언어</span><strong>${state.exportLocale === 'en' ? '영문' : '한글'}</strong></div>`;
  const resultFlow = div('scheduleio-export-result-flow');
  resultFlow.innerHTML = effectiveOutputMode === 'files'
    ? '<strong>RVT별 순차 추출·저장</strong><span>시작하면 저장 폴더를 먼저 선택한 뒤 RVT 하나를 열고 추출·저장·정리한 다음 다음 RVT로 넘어갑니다.</span>'
    : '<strong>추출과 통합 Excel 저장을 연속 실행</strong><span>시작하면 저장 파일을 먼저 선택한 뒤 대상 RVT를 순차 처리해 하나의 Excel로 저장합니다.</span>';
  summaryCard.append(summary, resultFlow);
  host.append(targetCard, saveCard, summaryCard);
}

function buildExportSettingSection(title, hint, content) {
  const section = div('scheduleio-export-layout');
  const head = div('scheduleio-export-layout-head');
  head.innerHTML = `<strong>${escapeHtml(title)}</strong><span>${escapeHtml(hint)}</span>`;
  section.append(head, content);
  return section;
}

function buildExportChoiceGroup(state, stateKey, options, className = '') {
  const group = div('scheduleio-export-layout-options');
  if (className) group.classList.add(className);
  options.forEach((option) => {
    const selected = state[stateKey] === option.value;
    const label = document.createElement('label');
    label.className = selected ? 'is-active' : '';
    label.innerHTML = `<input type="radio" name="scheduleio-${stateKey}" value="${escapeHtml(option.value)}" ${selected ? 'checked' : ''}><span><strong>${escapeHtml(option.title)}</strong><em>${escapeHtml(option.description)}</em></span>`;
    const input = setScheduleIoFocusKey(label.querySelector('input'), `choice:${stateKey}:${option.value}`);
    input.disabled = !!option.disabled;
    label.classList.toggle('is-disabled', input.disabled);
    input.addEventListener('change', () => {
      if (input.disabled || state.busy) return;
      const previousValue = state[stateKey];
      state[stateKey] = option.value;
      state.lastResult = null;
      if (stateKey === 'importTargetKind' && previousValue !== option.value) {
        state.inspection = null;
        state.inspectionTargetKind = '';
      }
      renderAll(state);
    });
    group.append(label);
  });
  return group;
}

function renderScheduleList(state, host) {
  clear(host);
  const query = state.scheduleQuery.trim().toLowerCase();
  const visible = state.schedules.filter((item) => !query || item.name.toLowerCase().includes(query));
  if (!visible.length) {
    host.append(emptyState(state.schedules.length ? '검색 결과가 없습니다.' : '불러온 스케줄이 없습니다.'));
    return;
  }

  visible.forEach((item) => {
    const row = document.createElement('label');
    row.className = 'scheduleio-choice-row';
    row.innerHTML = `
      <input type="checkbox" ${state.selectedScheduleIds.has(item.id) ? 'checked' : ''}>
      <span><strong>${escapeHtml(item.name)}</strong><em>표시 필드 ${item.fieldCount}개</em></span>`;
    const input = setScheduleIoFocusKey(row.querySelector('input'), `schedule:${item.id}`);
    input.addEventListener('change', (event) => {
      if (event.target.checked) state.selectedScheduleIds.add(item.id);
      else state.selectedScheduleIds.delete(item.id);
      renderAll(state);
    });
    host.append(row);
  });
}

function renderImportWorkspace(state, host) {
  const workbookCard = createCard('1. Import Excel', 'Export 파일 또는 동일한 식별 열을 가진 Excel을 불러옵니다.');
  const picker = div('scheduleio-drop-zone');
  picker.innerHTML = `
    <div><strong>${escapeHtml(state.workbookName || 'Excel 파일 선택')}</strong><span>${escapeHtml(state.workbookPath || '.xlsx 또는 .xls 파일을 끌어다 놓을 수 있습니다.')}</span></div>`;
  const pickButton = actionButton('Excel 선택', () => post('scheduleio:pick-workbook', {}), 'secondary');
  pickButton.disabled = state.busy;
  picker.append(pickButton);
  state.excelDropCleanup?.();
  state.excelDropCleanup = attachExcelDropZone(picker, {
    onDropPaths: (paths) => paths[0] && post('scheduleio:read-workbook', { path: paths[0] }),
    onInvalid: (payload) => toast(payload?.message || 'Excel 파일만 추가할 수 있습니다.', 'err')
  });
  workbookCard.append(picker);

  const sheetColumnGrid = div('scheduleio-two-column');
  const sheetsCard = createSubcard('시트', `${state.selectedSheets.size}/${state.workbookSheets.length}개 선택`);
  const sheetList = setScheduleIoScrollKey(div('scheduleio-choice-list scheduleio-compact-list'), 'sheet-list');
  if (!state.workbookSheets.length) sheetList.append(emptyState('불러온 시트가 없습니다.'));
  state.workbookSheets.forEach((sheet) => {
    const row = document.createElement('label');
    row.className = 'scheduleio-choice-row';
    row.innerHTML = `<input type="checkbox" ${state.selectedSheets.has(sheet.name) ? 'checked' : ''}><span><strong>${escapeHtml(sheet.name)}</strong><em>${sheet.rowCount}행</em></span>`;
    const input = setScheduleIoFocusKey(row.querySelector('input'), `sheet:${sheet.name}`);
    input.addEventListener('change', (event) => {
      if (event.target.checked) state.selectedSheets.add(sheet.name);
      else state.selectedSheets.delete(sheet.name);
      syncSelectedColumns(state);
      renderAll(state);
    });
    sheetList.append(row);
  });
  sheetsCard.append(sheetList);

  const candidateColumns = getCandidateColumns(state);
  const columnsCard = createSubcard('입력할 열', `${state.selectedColumns.size}/${candidateColumns.length}개 선택`);
  const columnList = setScheduleIoScrollKey(div('scheduleio-choice-list scheduleio-compact-list'), 'column-list');
  if (!candidateColumns.length) columnList.append(emptyState('선택 가능한 값 열이 없습니다.'));
  candidateColumns.forEach((column) => {
    const row = document.createElement('label');
    row.className = 'scheduleio-choice-row';
    row.innerHTML = `<input type="checkbox" ${state.selectedColumns.has(column) ? 'checked' : ''}><span><strong>${escapeHtml(column)}</strong></span>`;
    const input = setScheduleIoFocusKey(row.querySelector('input'), `column:${column}`);
    input.addEventListener('change', (event) => {
      toggleImportColumn(state, column, !!event.target.checked);
      renderAll(state);
    });
    columnList.append(row);
  });
  columnsCard.append(columnList);
  sheetColumnGrid.append(sheetsCard, columnsCard);
  workbookCard.append(sheetColumnGrid);

  const targetCard = createCard('2. Import 대상', '활성 문서에 입력하거나 등록한 여러 RVT에 같은 Excel 매핑을 적용합니다.');
  targetCard.append(buildExportChoiceGroup(state, 'importTargetKind', [
    {
      value: 'active',
      title: '활성 문서',
      description: state.activeDocument.canUse
        ? `${state.activeDocument.name || '현재 문서'}에 바로 입력합니다.`
        : '사용 가능한 활성 프로젝트 문서가 없습니다.'
    },
    {
      value: 'batch',
      title: '여러 RVT',
      description: state.targetPaths.length
        ? `등록한 ${state.targetPaths.length}개 RVT에 같은 Excel 매핑을 적용합니다.`
        : '대상 RVT를 등록한 뒤 일괄 입력합니다.'
    }
  ]));

  if (state.importTargetKind === 'batch') {
    const batchPanel = div('scheduleio-target-selection-panel');
    batchPanel.innerHTML = `<div><strong>등록된 대상 RVT</strong><span>${state.targetPaths.length ? `${state.targetPaths.length}개 파일` : '아직 등록된 파일이 없습니다.'}</span></div>`;
    batchPanel.append(actionButton(
      state.targetPaths.length ? '대상 RVT 관리' : '대상 RVT 등록',
      () => openTargetModal(state),
      state.targetPaths.length ? 'secondary' : 'primary'
    ));
    targetCard.append(batchPanel);
  }

  const mappingCard = createCard('3. 파라미터 매핑', 'Excel 열을 Instance 또는 Type 파라미터에 연결합니다.');
  const inspectActions = div('scheduleio-inline-actions');
  const inspectLabel = state.importTargetKind === 'active' ? '활성 문서 파라미터 확인' : '등록 RVT 파라미터 확인';
  const inspectButton = actionButton(inspectLabel, () => inspectImport(state, state.importTargetKind), 'secondary');
  inspectButton.disabled = !canInspect(state, state.importTargetKind);
  inspectActions.append(inspectButton);

  if (state.inspection) {
    const inspection = div('scheduleio-inspection');
    inspection.innerHTML = `
      <strong>${state.inspectionTargetKind === 'active' ? '활성 문서' : '등록 RVT'} 분석 완료</strong>
      <span>일치 ${state.inspection.matchedRows}행</span>
      <span>요소 없음 ${state.inspection.missingElements}행</span>
      <span>Family/Type 불일치 ${state.inspection.identityMismatches}행</span>
      ${state.inspection.blockedLinkedRows > 0 ? `<span>링크 Import 제외 ${state.inspection.blockedLinkedRows}행</span>` : ''}`;
    mappingCard.append(inspectActions, inspection);
  } else {
    mappingCard.append(inspectActions);
  }

  const mapTable = div('scheduleio-mapping-table');
  const mapHead = div('scheduleio-mapping-row scheduleio-mapping-row--head');
  mapHead.innerHTML = '<span>Excel 열</span><span>Binding</span><span>Revit 파라미터</span><span></span>';
  mapTable.append(mapHead);
  if (!state.mappings.length) mapTable.append(emptyState('입력할 열을 선택하면 매핑 행이 생성됩니다.'));
  state.mappings.forEach((mapping, index) => mapTable.append(buildMappingRow(state, mapping, index)));
  mappingCard.append(mapTable, buildParameterDataLists(state));

  const optionsCard = createCard('4. Import 옵션', '빈 셀 처리와 중앙파일 동기화를 설정합니다.');
  const options = div('scheduleio-option-stack');
  options.append(toggleLine('빈 Excel 셀로 기존 값 지우기', state.clearBlankValues, (checked) => { state.clearBlankValues = checked; }, false, 'clear-blank-values'));
  options.append(toggleLine('활성 문서 Import 후 중앙파일과 동기화', state.synchronizeActiveDocument, (checked) => {
    state.synchronizeActiveDocument = checked;
    renderAll(state);
  }, !state.activeDocument.isWorkshared, 'synchronize-active-document'));
  const commentField = div('scheduleio-field');
  commentField.innerHTML = '<label>동기화 코멘트</label><input type="text" maxlength="240" placeholder="KKY Tool Schedule Excel Import">';
  const commentInput = commentField.querySelector('input');
  commentInput.value = state.synchronizationComment;
  setScheduleIoFocusKey(commentInput, 'synchronization-comment');
  commentInput.addEventListener('input', () => { state.synchronizationComment = commentInput.value; });
  const syncNote = div('scheduleio-option-note');
  syncNote.textContent = state.activeDocument.isWorkshared
    ? '여러 RVT Import의 중앙파일과 활성 문서 동기화에 같은 코멘트를 사용합니다.'
    : '여러 RVT Import의 중앙파일 동기화에 이 코멘트를 사용합니다. 활성 문서는 Workshared 문서에서만 동기화할 수 있습니다.';
  options.append(commentField, syncNote);
  optionsCard.append(options);

  host.append(workbookCard, targetCard, mappingCard, optionsCard);
}

function buildMappingRow(state, mapping, index) {
  const row = div('scheduleio-mapping-row');
  const excel = document.createElement('strong');
  excel.textContent = mapping.excelColumn;

  const scope = document.createElement('select');
  scope.innerHTML = '<option value="instance">Instance</option><option value="type">Type</option>';
  scope.value = mapping.scope;
  setScheduleIoFocusKey(scope, `mapping:${mapping.excelColumn}:scope`);
  scope.addEventListener('change', () => {
    mapping.scope = scope.value;
    mapping.parameterName = mapping.parameterName || mapping.excelColumn;
    renderAll(state);
  });

  const parameter = document.createElement('input');
  parameter.type = 'text';
  parameter.placeholder = 'Revit 파라미터 이름';
  parameter.value = mapping.parameterName;
  setScheduleIoFocusKey(parameter, `mapping:${mapping.excelColumn}:parameter`);
  parameter.setAttribute('list', mapping.scope === 'type' ? 'scheduleio-type-parameters' : 'scheduleio-instance-parameters');
  parameter.addEventListener('input', () => { mapping.parameterName = parameter.value; });

  const remove = actionButton('제거', () => {
    state.selectedColumns.delete(mapping.excelColumn);
    state.mappings.splice(index, 1);
    renderAll(state);
  }, 'ghost');
  row.append(excel, scope, parameter, remove);
  return row;
}

function buildParameterDataLists(state) {
  const host = document.createDocumentFragment();
  const instance = document.createElement('datalist');
  instance.id = 'scheduleio-instance-parameters';
  (state.inspection?.instanceParameters || []).forEach((name) => instance.append(new Option(name, name)));
  const type = document.createElement('datalist');
  type.id = 'scheduleio-type-parameters';
  (state.inspection?.typeParameters || []).forEach((name) => type.append(new Option(name, name)));
  host.append(instance, type);
  return host;
}

function renderRunPanel(state) {
  const host = state.ui.runPanel;
  clear(host);

  if (state.mode === 'export') {
    renderExportRunPanel(state, host);
    return;
  }

  renderImportRunPanel(state, host);
}

function renderExportRunPanel(state, host) {
  const targetCount = batchExportTargetCount(state);
  const labels = [
    ['기준과 방식', '기준 스케줄 문서와 Excel 추출 형태를 선택합니다.'],
    ['스케줄 선택', '대상 문서에 적용할 기준 스케줄을 선택합니다.'],
    ['대상 및 저장', '추출 대상과 Excel 저장 방식을 확정한 뒤 실행합니다.']
  ];
  const [title, description] = labels[state.exportStep - 1] || labels[0];
  const card = div('scheduleio-aside-card scheduleio-aside-card--wizard');
  card.innerHTML = `
    <div class="scheduleio-aside-step-head">
      <div><span class="scheduleio-kicker">Export ${state.exportStep}/3</span><h3>${escapeHtml(title)}</h3></div>
      <strong>${state.exportStep}/3</strong>
    </div>
    <p class="scheduleio-aside-description">${escapeHtml(description)}</p>`;

  const stepList = div('scheduleio-aside-steps');
  [
    ['1', '기준과 방식', state.schedules.length > 0],
    ['2', '스케줄 선택', state.selectedScheduleIds.size > 0],
    ['3', '대상 및 저장', canRun(state, state.exportTargetKind)]
  ].forEach(([number, label, complete], index) => {
    const stepNumber = index + 1;
    const row = document.createElement('button');
    row.type = 'button';
    row.className = `${stepNumber === state.exportStep ? 'is-active' : ''}${complete ? ' is-complete' : ''}`;
    row.disabled = !canOpenExportStep(state, stepNumber);
    row.innerHTML = `<span>${number}</span><strong>${escapeHtml(label)}</strong><em>${complete ? '완료' : (stepNumber === state.exportStep ? '설정 중' : '대기')}</em>`;
    row.addEventListener('click', () => {
      state.exportStep = stepNumber;
      renderAll(state, { preserveScroll: false });
    });
    stepList.append(row);
  });
  card.append(stepList);

  const nav = div('scheduleio-aside-nav');
  if (state.exportStep > 1) {
    nav.append(actionButton('이전', () => {
      state.exportStep -= 1;
      renderAll(state, { preserveScroll: false });
    }, 'secondary'));
  }
  if (state.exportStep < 3) {
    const next = actionButton('다음 설정', () => {
      state.exportStep += 1;
      renderAll(state, { preserveScroll: false });
    }, 'primary');
    next.disabled = !canOpenExportStep(state, state.exportStep + 1);
    nav.append(next);
  } else {
    const runLabel = state.exportTargetKind === 'active' ? '활성 문서 데이터 추출' : '여러 RVT 데이터 추출';
    const run = actionButton(runLabel, () => runOperation(state, state.exportTargetKind), 'primary');
    run.disabled = !canRun(state, state.exportTargetKind);
    nav.append(run);
  }
  card.append(nav);

  const readiness = div('scheduleio-readiness');
  readiness.append(readinessRow('기준 문서', state.schedules.length > 0, state.sourceName || state.activeDocument.name || ''));
  readiness.append(readinessRow('스케줄', state.selectedScheduleIds.size > 0, `${state.selectedScheduleIds.size}개`));
  readiness.append(readinessRow(
    '필드 단위',
    canUseScheduleIoUnits(state),
    getScheduleIoUnitModeLabel(state.unitMode),
    '활성 프로젝트 문서 필요'
  ));
  readiness.append(readinessRow(
    '추출 대상',
    state.exportTargetKind === 'active' ? state.activeDocument.canUse : targetCount > 0,
    state.exportTargetKind === 'active' ? (state.activeDocument.name || '활성 문서') : `${targetCount}개 문서`
  ));
  readiness.append(readinessRow(
    'Excel 저장',
    true,
    `${getScheduleIoOutputModeLabel(getEffectiveScheduleIoOutputMode(state), state.exportTargetKind)} · ${getScheduleIoSheetLayoutLabel(state.sheetLayout)}`
  ));
  card.append(readiness);

  const saveNote = div('scheduleio-aside-save-note');
  saveNote.innerHTML = getEffectiveScheduleIoOutputMode(state) === 'files'
    ? '<strong>RVT별 즉시 저장</strong><span>실행 직전에 저장 폴더를 고르고, 각 RVT의 Excel 저장이 끝나면 다음 파일을 처리합니다.</span>'
    : '<strong>저장 위치를 먼저 선택</strong><span>실행 직전에 통합 Excel 저장 파일을 고른 뒤 순차 추출을 시작합니다.</span>';
  host.append(card, saveNote);
}

function renderImportRunPanel(state, host) {
  const runCard = div('scheduleio-aside-card scheduleio-aside-card--run');
  runCard.innerHTML = '<span class="scheduleio-kicker">Run</span><h3>Import 실행</h3>';
  const targetKind = state.importTargetKind;
  const runLabel = targetKind === 'active' ? '활성 문서 Import' : '여러 RVT Import';
  const runButton = actionButton(runLabel, () => runOperation(state, targetKind), 'primary');
  runButton.disabled = !canRun(state, targetKind);
  runCard.append(runButton);

  const readiness = div('scheduleio-readiness');
  readiness.append(readinessRow(
    '실행 대상',
    targetKind === 'active' ? state.activeDocument.canUse : state.targetPaths.length > 0,
    targetKind === 'active' ? (state.activeDocument.name || '활성 문서') : `${state.targetPaths.length}개 RVT`
  ));
  readiness.append(readinessRow('Excel', !!state.workbookPath));
  readiness.append(readinessRow('매핑', getValidMappings(state).length > 0, `${getValidMappings(state).length}개`));
  runCard.append(readiness);

  host.append(runCard);
}

function showScheduleResultDialog(state) {
  const result = state.lastResult;
  if (!result) return;
  const operation = result.operation || (state.mode === 'import' ? 'Import' : 'Export');
  const isImport = operation === 'Import';
  const canExportImportLog = hasImportResultLog(result);
  const actions = [];
  if (result.outputPath) {
    actions.push({ label: '결과 Excel 열기', onClick: () => post('excel:open', { path: result.outputPath }) });
  } else if (result.outputFolder) {
    actions.push({ label: '결과 폴더 열기', onClick: () => post('scheduleio:open-output-folder', { path: result.outputFolder }) });
  }
  const notes = [];
  if (result.saveError) notes.push(result.saveError);
  if (result.importLogSaveError) notes.push(result.importLogSaveError);
  if (result.outputPath) notes.push(`저장 파일: ${result.outputPath}`);
  else if (result.outputFolder) notes.push(`저장 폴더: ${result.outputFolder}`);
  if (isImport) {
    if (result.serviceMessage && !/작업을 완료했습니다\.?$/.test(result.serviceMessage)) notes.push(result.serviceMessage);
    if (Number(result.inMemoryFiles) > 0 || result.fileResults?.some((file) => file.persistenceStatus === 'in-memory')) {
      notes.push('활성 문서에 적용된 변경은 RVT 파일에 자동 저장되지 않았습니다. 문서를 직접 저장하세요.');
    }
    if (Number(result.skippedBlankValues) > 0) notes.push('빈 셀은 기존 값을 유지했습니다. 기존 값을 지우려면 「빈 Excel 셀로 기존 값 지우기」를 선택하세요.');
  }
  if (result.fileResults?.length) {
    notes.push('파일별 결과');
    result.fileResults.forEach((file) => {
      if (isImport) {
        notes.push([
          `${file.fileName} · ${getImportOutcomeLabel(file.outcome)}`,
          `반영 ${file.changedValues}개 · 기존 값과 동일 ${file.unchangedValues}개 · 요소 일치 ${file.matchedRows}행`,
          `빈 셀 제외 ${file.skippedBlankValues}개 · 건너뜀 ${file.skippedRows}행 · 오류 ${file.failedRows}행`,
          `저장 상태: ${getImportPersistenceLabel(file.persistenceStatus)}`,
          file.message
        ].filter(Boolean).join('\n'));
      } else notes.push(`${file.fileName} · 처리 ${file.processedRows} · 건너뜀 ${file.skippedRows} · 오류 ${file.failedRows}`);
    });
  }

  showCompletionSummaryDialog({
    dialogClassName: `completion-summary-dialog--wide${isImport ? ` scheduleio-import-result scheduleio-import-result--${result.importStatus || 'failed'}` : ''}`,
    title: `Schedule ${operation} 결과`,
    message: result.message || `Schedule ${operation} 작업을 완료했습니다.`,
    summaryItems: [
      { label: '대상 파일', value: `${Number(result.targetFiles) || 0}개` },
      { label: '처리 행', value: `${Number(result.processedRows) || 0}개` },
      ...(isImport ? [
        { label: '반영 값', value: `${Number(result.changedValues) || 0}개` },
        { label: '기존 값과 동일', value: `${Number(result.unchangedValues) || 0}개` },
        { label: '요소 일치', value: `${Number(result.matchedRows) || 0}행` },
        { label: '빈 셀 제외', value: `${Number(result.skippedBlankValues) || 0}개` },
        { label: '저장 완료', value: `${(Number(result.savedFiles) || 0) + (Number(result.synchronizedFiles) || 0)}개 파일` },
        ...(Number(result.failedFiles) > 0 ? [{ label: '오류 파일', value: `${Number(result.failedFiles)}개` }] : []),
        ...(Number(result.inMemoryFiles) > 0 ? [{ label: '직접 저장 필요', value: `${Number(result.inMemoryFiles)}개 문서` }] : [])
      ] : []),
      ...(operation === 'Import' && Number(result.blockedLinkedRows) > 0
        ? [{ label: '링크 Import 제외', value: `${Number(result.blockedLinkedRows) || 0}개` }]
        : []),
      { label: '건너뜀', value: `${Number(result.skippedRows) || 0}개` },
      { label: '오류', value: `${Number(result.failedRows) || 0}개` }
    ],
    notes,
    actions,
    confirmLabel: '닫기',
    showExport: (operation === 'Export' && !!result.exportToken) || canExportImportLog,
    exportLabel: operation === 'Import'
      ? '결과 엑셀 내보내기'
      : (result.outputPath || result.outputFolder ? '엑셀 다시 내보내기' : '엑셀 내보내기'),
    exportDisabled: state.busy || (operation === 'Export' && !result.exportToken),
    onExport: () => {
      if (operation === 'Import') saveImportResultLog(state);
      else exportScheduleResult(state);
    }
  });
}

function getImportOutcomeLabel(outcome) {
  return ({ changed: '값 반영', unchanged: '기존 값과 동일', skipped: '반영된 값 없음', partial: '일부만 적용', failed: '반영 또는 저장 실패' })[outcome] || '반영 결과 확인 필요';
}

function getImportPersistenceLabel(status) {
  return ({ saved: 'RVT 저장 완료', synchronized: '중앙파일 동기화 완료', 'in-memory': '문서에 적용됨 · 직접 저장 필요', 'not-needed': '변경 없음 · 저장 불필요', failed: '저장 또는 동기화 실패' })[status] || '확인되지 않음';
}

function hasImportResultLog(result) {
  return result?.operation === 'Import' &&
    (Number(result.skippedRows) > 0 || Number(result.blockedLinkedRows) > 0 || Number(result.failedRows) > 0 ||
      Number(result.failedFiles) > 0 || Number(result.skippedFiles) > 0 || result.fileResults?.some((file) => ['partial', 'failed', 'skipped'].includes(file.outcome)));
}

function saveImportResultLog(state) {
  const result = state.lastResult;
  if (state.busy || !hasImportResultLog(result)) return;

  result.importLogSaveError = '';
  state.busy = true;
  renderAll(state);
  post('scheduleio:save-import-log', {
    excelMode: 'fast',
    locale: getLastExcelExportLocale()
  });
}

async function exportScheduleResult(state) {
  const result = state.lastResult;
  if (!result?.exportToken || state.busy) return;
  const choice = await chooseExcelMode(null, {
    allowSplit: result.targetKind === 'batch',
    defaultLayout: normalizeScheduleIoSheetLayout(state.sheetLayout),
    layoutOptions: [
      {
        value: 'schedule',
        title: '스케줄별 시트',
        description: '선택한 스케줄마다 시트를 하나씩 만듭니다.'
      },
      {
        value: 'single',
        title: '한 시트로 통합',
        description: '모든 결과를 한 시트에 합치고 Schedule Name 열을 추가합니다.'
      },
      {
        value: 'category',
        title: '카테고리별 시트',
        description: '스케줄 카테고리별로 시트를 나누고 Schedule Name 열을 추가합니다.'
      }
    ]
  });
  if (!choice) {
    showScheduleResultDialog(state);
    return;
  }
  const mode = typeof choice === 'object' ? choice.mode : choice;
  const splitByFile = !!(choice && typeof choice === 'object' && choice.splitByFile);
  const sheetLayout = choice && typeof choice === 'object' ? choice.layout : 'schedule';
  state.outputMode = result.targetKind === 'batch' && splitByFile ? 'files' : 'workbook';
  state.sheetLayout = normalizeScheduleIoSheetLayout(sheetLayout);
  state.excelMode = normalizeScheduleIoExcelMode(mode);
  state.exportLocale = normalizeScheduleIoExportLocale(getLastExcelExportLocale());
  saveScheduleIoPreferences(state);
  state.busy = true;
  renderAll(state);
  ProgressDialog.setActions({});
  ProgressDialog.show('Schedule Excel 내보내기', '저장 위치를 선택하고 Excel을 생성하는 중입니다.');
  post('scheduleio:save-export', {
    exportToken: result.exportToken,
    outputMode: state.outputMode,
    sheetLayout: state.sheetLayout,
    excelMode: state.excelMode,
    locale: state.exportLocale
  });
}

function openTargetModal(state) {
  if (!state.modalOpen) {
    state.modalSnapshot = {
      targetPaths: [...state.targetPaths],
      includeActiveDocument: state.includeActiveDocument,
      inspection: state.inspection,
      inspectionTargetKind: state.inspectionTargetKind
    };
  }
  state.modalOpen = true;
  renderTargetModal(state);
}

function cancelTargetModal(state) {
  if (state.modalSnapshot) {
    state.targetPaths = [...state.modalSnapshot.targetPaths];
    state.includeActiveDocument = !!state.modalSnapshot.includeActiveDocument;
    state.inspection = state.modalSnapshot.inspection;
    state.inspectionTargetKind = state.modalSnapshot.inspectionTargetKind;
  }
  state.modalSnapshot = null;
  state.modalOpen = false;
  renderAll(state);
}

function confirmTargetModal(state) {
  state.modalSnapshot = null;
  state.modalOpen = false;
  renderAll(state);
}

function buildTargetModal(state) {
  const overlay = div('scheduleio-modal scheduleio-target-modal is-hidden');
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.innerHTML = `
    <section class="scheduleio-modal-dialog">
      <header><div><h2>대상 RVT 등록</h2><p>여러 RVT Import / Export에 사용할 파일을 관리합니다.</p></div><button type="button" data-close aria-label="닫기">x</button></header>
      <div class="scheduleio-modal-body"></div>
      <footer class="scheduleio-modal-footer"></footer>
    </section>`;
  setScheduleIoScrollKey(overlay.querySelector('.scheduleio-modal-body'), 'target-modal-body');
  overlay.querySelector('.scheduleio-modal-footer').append(
    actionButton('취소', () => cancelTargetModal(state), 'secondary'),
    actionButton('확인', () => confirmTargetModal(state), 'primary')
  );
  overlay.addEventListener('click', (event) => {
    if (event.target === overlay || event.target.closest('[data-close]')) {
      cancelTargetModal(state);
    }
  });
  return overlay;
}

function renderTargetModal(state) {
  const overlay = state.ui.modal;
  overlay.classList.toggle('is-hidden', !state.modalOpen);
  if (!state.modalOpen) {
    state.dropCleanup?.();
    state.dropCleanup = null;
    return;
  }

  const body = overlay.querySelector('.scheduleio-modal-body');
  clear(body);
  if (state.mode === 'export') {
    const activeOption = div('scheduleio-active-document-option');
    activeOption.append(toggleLine('활성 문서 포함', includesActiveDocumentInBatch(state), (checked) => {
      state.includeActiveDocument = checked;
      state.lastResult = null;
      renderAll(state);
    }, !state.activeDocument.canUse, 'include-active-document'));
    const activeNote = div('scheduleio-option-note');
    activeNote.textContent = state.activeDocument.canUse
      ? `${state.activeDocument.name || '현재 활성 문서'}는 다시 열지 않고 등록 RVT와 함께 추출합니다.`
      : '사용 가능한 활성 프로젝트 문서가 없습니다.';
    activeOption.append(activeNote);
    body.append(activeOption);
  }
  const actions = div('scheduleio-modal-actions');
  const add = actionButton('RVT 추가', () => post('scheduleio:pick-target-rvts', {}), 'primary');
  const clearButton = actionButton('목록 비우기', () => {
    state.targetPaths = [];
    state.inspection = null;
    renderAll(state);
  }, 'secondary');
  clearButton.disabled = !state.targetPaths.length;
  actions.append(add, clearButton);

  const drop = div('scheduleio-rvt-drop');
  drop.innerHTML = `<strong>${state.targetPaths.length ? `${state.targetPaths.length}개 RVT 등록됨` : 'RVT 파일을 여기에 놓으세요'}</strong><span>같은 파일명은 한 번만 등록됩니다.</span>`;
  state.dropCleanup?.();
  state.dropCleanup = attachRvtDropZone(drop, {
    onDropPaths: (paths) => {
      appendTargetPaths(state, paths);
      renderAll(state);
    },
    onInvalid: (payload) => toast(payload?.message || 'RVT 파일만 추가할 수 있습니다.', 'err')
  });

  const list = div('scheduleio-target-list');
  if (!state.targetPaths.length) list.append(emptyState('등록된 RVT가 없습니다.'));
  state.targetPaths.forEach((path, index) => {
    const row = div('scheduleio-target-row');
    row.innerHTML = `<span><strong>${escapeHtml(fileName(path))}</strong><em>${escapeHtml(path)}</em></span>`;
    row.append(actionButton('제거', () => {
      state.targetPaths.splice(index, 1);
      state.inspection = null;
      renderAll(state);
    }, 'ghost'));
    list.append(row);
  });
  body.append(actions, drop, list);
}

function runOperation(state, targetKind) {
  if (!canRun(state, targetKind) || state.busy) return;
  saveScheduleIoPreferences(state);
  state.busy = true;
  state.lastResult = null;
  renderAll(state);
  ProgressDialog.setActions({});
  ProgressDialog.show(`Schedule ${state.mode === 'export' ? 'Export' : 'Import'}`, '작업을 준비하는 중입니다.');

  if (state.mode === 'export') {
    const includeLinkedRows = state.extractionMode === 'all' && state.includeLinks;
    post(`scheduleio:export-${targetKind}`, {
      sourceKind: state.sourceKind,
      sourcePath: state.sourcePath,
      scheduleIds: [...state.selectedScheduleIds],
      targetPaths: state.targetPaths,
      extractionMode: state.extractionMode,
      unitMode: normalizeScheduleIoUnitMode(state.unitMode),
      includeLinks: targetKind === 'batch' ? !!state.includeLinks : includeLinkedRows,
      includeActiveDocument: targetKind === 'batch' && includesActiveDocumentInBatch(state),
      includeFileName: state.includeFileName || includeLinkedRows,
      saveBeforeRun: true,
      outputMode: getEffectiveScheduleIoOutputMode(state, targetKind),
      sheetLayout: normalizeScheduleIoSheetLayout(state.sheetLayout),
      excelMode: normalizeScheduleIoExcelMode(state.excelMode),
      locale: normalizeScheduleIoExportLocale(state.exportLocale)
    });
    return;
  }

  post(`scheduleio:import-${targetKind}`, {
    workbookPath: state.workbookPath,
    selectedSheets: [...state.selectedSheets],
    mappings: getValidMappings(state),
    targetPaths: state.targetPaths,
    clearBlankValues: state.clearBlankValues,
    synchronizeActiveDocument: targetKind === 'active' && state.synchronizeActiveDocument,
    synchronizationComment: state.synchronizationComment
  });
}

function inspectImport(state, targetKind) {
  if (!canInspect(state, targetKind) || state.busy) return;
  state.busy = true;
  state.inspection = null;
  renderAll(state);
  ProgressDialog.setActions({});
  ProgressDialog.show('Import 대상 분석', targetKind === 'active' ? '활성 문서 파라미터를 확인하는 중입니다.' : '등록 RVT 파라미터를 확인하는 중입니다.');
  post('scheduleio:inspect-import', {
    workbookPath: state.workbookPath,
    selectedSheets: [...state.selectedSheets],
    targetKind,
    targetPaths: state.targetPaths
  });
}

function canInspect(state, targetKind) {
  if (state.busy || !state.workbookPath || !state.selectedSheets.size) return false;
  if (targetKind === 'active') return state.activeDocument.canUse;
  return state.targetPaths.length > 0;
}

function canRun(state, targetKind) {
  if (state.busy) return false;
  if (targetKind === 'active' && !state.activeDocument.canUse) return false;
  if (targetKind === 'batch') {
    if (state.mode === 'export' && batchExportTargetCount(state) <= 0) return false;
    if (state.mode === 'import' && !state.targetPaths.length) return false;
  }
  if (state.mode === 'export') return state.selectedScheduleIds.size > 0 && canUseScheduleIoUnits(state);
  return !!state.workbookPath && state.selectedSheets.size > 0 && getValidMappings(state).length > 0;
}

function getValidMappings(state) {
  return state.mappings
    .map((mapping) => ({
      excelColumn: String(mapping.excelColumn || '').trim(),
      parameterName: String(mapping.parameterName || '').trim(),
      scope: mapping.scope === 'type' ? 'type' : 'instance'
    }))
    .filter((mapping) => mapping.excelColumn && mapping.parameterName);
}

function getCandidateColumns(state) {
  const selected = state.workbookSheets.filter((sheet) => state.selectedSheets.has(sheet.name));
  const seen = new Set();
  const columns = [];
  selected.flatMap((sheet) => sheet.headers).forEach((header) => {
    const text = String(header || '').trim();
    const key = text.toLowerCase();
    if (!text || IDENTITY_HEADERS.has(key) || seen.has(key)) return;
    seen.add(key);
    columns.push(text);
  });
  return columns;
}

function syncSelectedColumns(state) {
  const available = new Set(getCandidateColumns(state).map((column) => column.toLowerCase()));
  [...state.selectedColumns].forEach((column) => {
    if (!available.has(column.toLowerCase())) state.selectedColumns.delete(column);
  });
  state.mappings = state.mappings.filter((mapping) => state.selectedColumns.has(mapping.excelColumn));
}

function toggleImportColumn(state, column, selected) {
  if (selected) {
    state.selectedColumns.add(column);
    if (!state.mappings.some((mapping) => mapping.excelColumn === column)) {
      state.mappings.push({ excelColumn: column, parameterName: column, scope: 'instance' });
    }
  } else {
    state.selectedColumns.delete(column);
    state.mappings = state.mappings.filter((mapping) => mapping.excelColumn !== column);
  }
  state.lastResult = null;
}

function appendTargetPaths(state, paths) {
  const seen = new Set(state.targetPaths.map((path) => path.toLowerCase()));
  arrayOf(paths).map(String).filter((path) => /\.rvt$/i.test(path)).forEach((path) => {
    const key = path.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    state.targetPaths.push(path);
  });
  state.inspection = null;
  state.lastResult = null;
}

function createCard(title, subtitle) {
  const card = div('scheduleio-card');
  const head = div('scheduleio-card-head');
  head.innerHTML = `<div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(subtitle || '')}</p></div>`;
  card.append(head);
  return card;
}

function createSubcard(title, count) {
  const card = div('scheduleio-subcard');
  const head = div('scheduleio-subcard-head');
  head.innerHTML = `<strong>${escapeHtml(title)}</strong><span>${escapeHtml(count || '')}</span>`;
  card.append(head);
  return card;
}

function actionButton(label, onClick, kind = 'secondary') {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = `btn scheduleio-btn scheduleio-btn--${kind}`;
  button.dataset.directKind = kind === 'primary' ? 'primary' : (kind === 'ghost' ? 'muted' : 'secondary');
  button.textContent = label;
  if (typeof onClick === 'function') button.addEventListener('click', onClick);
  return button;
}

function toggleLine(label, checked, onChange, disabled = false, focusKey = '') {
  const line = document.createElement('label');
  line.className = `scheduleio-toggle-line${disabled ? ' is-disabled' : ''}`;
  line.innerHTML = `<input type="checkbox" ${checked ? 'checked' : ''} ${disabled ? 'disabled' : ''}><span>${escapeHtml(label)}</span>`;
  const input = setScheduleIoFocusKey(line.querySelector('input'), focusKey);
  input.addEventListener('change', (event) => onChange?.(!!event.target.checked));
  return line;
}

function readinessRow(label, ready, detail = '', missingDetail = '필요') {
  const row = div(`scheduleio-ready-row ${ready ? 'is-ready' : ''}`);
  row.innerHTML = `<span>${escapeHtml(label)}</span><strong>${escapeHtml(ready ? (detail || '준비됨') : missingDetail)}</strong>`;
  return row;
}

function emptyState(message) {
  const node = div('scheduleio-empty');
  node.textContent = message;
  return node;
}

function stat(label, value) {
  const node = document.createElement('span');
  node.innerHTML = `${escapeHtml(label)} <strong>${Number(value) || 0}</strong>`;
  return node;
}

function fileName(path) {
  return String(path || '').split(/[\\/]/).pop() || '';
}

function normalizeFilePath(path) {
  return String(path || '').trim().replace(/\//g, '\\').toLowerCase();
}

function stripFileExtension(value) {
  return String(value || '').replace(/\.rvt$/i, '');
}

function includesActiveDocumentInBatch(state) {
  return !!(state.includeActiveDocument && state.activeDocument.canUse);
}

function batchExportTargetCount(state) {
  let count = state.targetPaths.length;
  if (!includesActiveDocumentInBatch(state)) return count;
  const activePath = normalizeFilePath(state.activeDocument.path);
  const duplicate = activePath && state.targetPaths.some((path) => normalizeFilePath(path) === activePath);
  return duplicate ? count : count + 1;
}

function parseFileResults(raw) {
  return arrayOf(pick(raw, 'fileResults', 'FileResults')).map((item, index) => ({
    fileName: stripFileExtension(String(pick(item, 'fileName', 'FileName') || fileName(String(pick(item, 'filePath', 'FilePath') || '')) || `대상 문서 ${index + 1}`)),
    processedRows: Number(pick(item, 'processedRows', 'ProcessedRows')) || 0,
    changedValues: Number(pick(item, 'changedValues', 'ChangedValues')) || 0,
    matchedRows: Number(pick(item, 'matchedRows', 'MatchedRows')) || 0,
    unchangedValues: Number(pick(item, 'unchangedValues', 'UnchangedValues')) || 0,
    skippedBlankValues: Number(pick(item, 'skippedBlankValues', 'SkippedBlankValues')) || 0,
    skippedRows: Number(pick(item, 'skippedRows', 'SkippedRows')) || 0,
    failedRows: Number(pick(item, 'failedRows', 'FailedRows')) || 0,
    outcome: String(pick(item, 'outcome', 'Outcome') || '').toLowerCase(),
    persistenceStatus: String(pick(item, 'persistenceStatus', 'PersistenceStatus') || '').toLowerCase(),
    message: String(pick(item, 'message', 'Message') || '')
  }));
}

function pick(object, ...keys) {
  if (!object) return undefined;
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(object, key)) return object[key];
  }
  return undefined;
}

function arrayOf(value) {
  return Array.isArray(value) ? value : [];
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
