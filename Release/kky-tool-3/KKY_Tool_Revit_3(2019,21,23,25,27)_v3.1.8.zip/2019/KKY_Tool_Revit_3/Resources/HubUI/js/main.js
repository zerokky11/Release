import { createRvtRegistration } from './core/rvtRegistration.js?v=20261008registration1';
import { initTheme, toggleTheme } from './core/theme.js?v=20260731sharedsettings3';
import { beginHostListenerScope, clearHostListenerScope, endHostListenerScope, onHost, post, DEV } from './core/bridge.js';
import { updateTopMost, setActiveDocument, setDocList, setDocumentVisualAidSettings, setScheduleBoardSettings, setUpdateInfo, setUpdateState, renderTopbar } from './core/topbar.js?v=20261012official318';
import { initLogConsole, toggleLogConsole, log } from './core/dom.js?v=20260731parameterexport1';
import { initializeSharedFeatureSettings } from './core/sharedFeatureSettings.js?v=20260825utilityfilenamerules1';
import { renderShell3 } from './core/shell3.js?v=20261012navplus1';
import { setSelectedFeatureIds3 } from './core/workflowState3.js?v=20260731sharedsettings3';
import { createFeatureGuideButton } from './core/featureGuide.js?v=20260916linkbatch1';
import { renderHome } from './views/home.js?v=20261012navplus1';
import { renderGroupView3 } from './views/groupView3.js?v=20261012navplus1';
import { renderRvtRegistration3 } from './views/rvtRegistration3.js?v=20261012navplus1';
import { renderDup } from './views/dup.js?v=20261012official318';
import { renderParamProp } from './views/paramprop.js?v=20261012official318';
import { renderParameterMigration } from './views/parammigration.js?v=20261012official318';
import { renderSharedParamBatch } from './views/sharedparambatch.js?v=20261012official318';
import { renderSegmentPms } from './views/segmentpms.js?v=20260908excelexportopen1';
import { renderGuid } from './views/guid.js?v=20261012official318';
import { renderLinkPath } from './views/linkpath.js?v=20260826releaseprep2';
import { renderLinkSharedCoord } from './views/linksharedcoord.js?v=20260908excelexportopen1';
import { renderCadCirclePlacement } from './views/cadcircleplacement.js?v=20260902foreline2';
import { renderColumnNumberPlacement } from './views/columnnumberplacement.js?v=20260918columnfallback1';
import { renderTerrainDrape } from './views/terraindrape.js?v=20260908terraintest1';
import { renderCentralWorkset } from './views/centralworkset.js?v=20260826centraloutputauto1';
import { renderLevelChange } from './views/levelchange.js?v=20260908excelexportopen1';
import { renderAccCloud } from './views/acccloud.js?v=20261006accname1';
import { renderAccBackup } from './views/accbackup.js?v=20260826releaseprep2';
import { renderMulti } from './views/multi.js?v=20261012navplus1';
import { renderDeliveryCleaner } from './views/deliverycleaner.js?v=20261012deliveryparams1';
import { renderReviewOrganizer } from './views/revieworganizer.js?v=20260910commonsourceheader1';
import { renderParamModifier } from './views/parammodifier.js?v=20261012official318';
import { renderConditionExtract } from './views/conditionextract.js?v=20261012official318';
import { renderLateralNozzle } from './views/lateralnozzle.js?v=20260907rvtnozzleperf1';
import { renderUserManagement } from './views/usermanagement.js?v=20260826releaseprep2';
import { renderScheduleIo } from './views/scheduleio.js?v=20260916scheduleimport1';
import { renderNwcExport } from './views/nwcexport.js?v=20260828nwcexportfolderpicker1';
import { renderNwcCompare } from './views/nwccompare.js?v=20260826releaseprep2';

let _lastTop = null;
let _viewRoot = null;
let _topbarRoot = null;
let _lastHash = null;
let _historyStack = [];
let _suppressHistory = false;
let _activeViewScope = null;
let _activeDirectViewCleanup = null;
const HUB_DEBUG_STAMP = 'release-3.1.8-20261012';

const DIRECT_SHELL3_ROUTES = Object.freeze({
  deliverycleaner: {
    active: 'bqc-results',
    title: 'BQC 결과 정리 - RVT 정리',
    subtitle: '납품용 RVT 정리, 검토, 결과 처리를 3.0 작업대 안에서 실행합니다.',
    mainSlots: [
      { selector: '.direct3-delivery-settings', role: 'settings' }
    ],
    asideItems: [
      { selector: '.deliverycleaner-card--control', title: '실행 및 결과', role: 'run', wrap: false }
    ]
  },
  revieworganizer: {
    active: 'bqc-results',
    title: '다회차 엑셀 결과 정리',
    subtitle: '1차 회신과 2차 결과를 연결해 코멘트와 예외를 반영합니다. RVT 검토를 다시 실행할 필요가 없습니다.',
    backLabel: '결과 정리',
    mainSlots: [],
    asideItems: []
  },
  conditionextract: {
    active: 'bqc',
    title: 'BQC 검토 - 조건별 객체 속성 추출',
    subtitle: '조건 필터와 추출 옵션을 설정하고 활성 문서 또는 RVT 묶음을 검토합니다.',
    mainSlots: [
      { selector: '.conditionextract-page--main .deliverycleaner-card--workspace', role: 'settings' }
    ],
    asideItems: [
      { selector: '.conditionextract-page--main .deliverycleaner-field-stack > .deliverycleaner-card', title: '실행 대상', role: 'run', wrap: false }
    ]
  },
  dup: {
    active: 'utility',
    title: '일반 도구 - 중복 / 자체 간섭 검토',
    subtitle: '단독 실행 기능도 3.0 작업대 레이아웃에서 확인합니다.',
    mainSlots: [
      { selector: '.dup-appliedbar', role: 'settings' },
      { selector: '.dup-body', role: 'result' }
    ],
    asideItems: [
      { selector: '.dup-toolbar .feature-actions', title: '설정 및 실행', role: 'run', wrap: true }
    ]
  },
  paramprop: {
    active: 'utility',
    title: '일반 도구 - 패밀리 공유파라미터 추가/연동',
    subtitle: '공유파라미터 추가와 연동 작업을 3.0 작업대 안에서 실행합니다.',
    mainSlots: [
      { selector: '.paramprop-picker-card', role: 'settings' }
    ],
    asideItems: [
      { selector: '.paramprop-page--main > .feature-header .feature-actions', title: '실행', role: 'run', wrap: true }
    ]
  },
  parammigration: {
    active: 'utility',
    title: '일반 도구 - 공유파라미터 통합 변경',
    subtitle: '기존 정의와 값을 신규 공유파라미터로 옮기고 단계별로 검증합니다.',
    mainSlots: [{ selector: '.parammigration-workspace', role: 'settings' }],
    asideItems: [{ selector: '.parammigration-run-panel', title: '설정 및 실행', role: 'run', wrap: false }]
  },
  segmentpms: {
    active: 'utility',
    title: '일반 도구 - Segment-PMS 비교 검토',
    subtitle: 'RVT 추출, PMS 매핑, 결과 저장 흐름을 한 화면에서 관리합니다.',
    mainSlots: [
      { selector: '.segmentpms-extract', role: 'target' },
      { selector: '.segmentpms-check', role: 'settings' }
    ],
    asideButtonGroups: [
      { selector: '.segmentpms-extract .section-header .feature-actions', title: '1단계 실행', role: 'run', includeText: ['추출 시작', '엑셀 내보내기'] },
      { selector: '.segmentpms-check .section-header .feature-actions', title: '2단계 실행', role: 'run', includeText: ['PMS 양식 추출하기', '매핑 준비', '검토 시작', '엑셀 내보내기'] }
    ]
  },
  parammodifier: {
    active: 'utility',
    title: '일반 도구 - 파라미터 수정기',
    subtitle: '조건 기반 파라미터 일괄 입력을 활성 문서 또는 RVT 묶음에 적용합니다.',
    mainSlots: [
      { selector: '.direct3-parammodifier-options', role: 'settings' },
      { selector: '.parammodifier-settings-card', role: 'settings' }
    ],
    asideButtonGroups: [
      { selector: '.parammodifier-page--main .parammodifier-run-card .deliverycleaner-inline-actions', title: '실행 대상', role: 'run', includeText: ['활성 문서 적용', '여러 RVT 적용'] }
    ]
  },
  linkpath: {
    active: 'linktools',
    title: '링크 도구 - Revit 링크 경로 추출/재지정',
    subtitle: '링크 경로 추출과 엑셀 기준 재지정을 3.0 작업대 안에서 실행합니다.',
    mainSlots: [
      { selector: '.linkpath-card--rvt', role: 'target' },
      { selector: '.linkpath-card--apply', role: 'settings' },
      { selector: '.linkpath-results-panel', role: 'result' }
    ],
    asideButtonGroups: [
      { selector: '.linkpath-card--rvt .linkpath-run-actions', title: '1단계 실행', role: 'run' },
      { selector: '.linkpath-card--apply .linkpath-run-actions', title: '2단계 실행', role: 'run' }
    ]
  },
  linksharedcoord: {
    active: 'linktools',
    title: '링크 도구 - Link 파일 Shared Coordination 검토/설정',
    subtitle: '활성 문서 또는 여러 RVT의 A × 1 기준점을 Excel로 검토하고 호스트 링크 배치를 반영합니다.',
    mainSlots: [
      { selector: '.linksharedcoord-batch', role: 'target' },
      { selector: '.linksharedcoord-host', role: 'target' },
      { selector: '.linksharedcoord-config', role: 'settings' },
      { selector: '.linksharedcoord-target', role: 'settings' },
      { selector: '.linksharedcoord-analysis', role: 'result' }
    ],
    asideItems: [
      { selector: '.linksharedcoord-actions', title: '분석 및 반영', role: 'run', wrap: false }
    ],
    asideButtonGroups: [
      { selector: '.linksharedcoord-batch-review-actions', title: '1단계 실행', role: 'run', className: 'linksharedcoord-batch-aside' },
      { selector: '.linksharedcoord-batch-apply-actions', title: '2단계 실행', role: 'run', className: 'linksharedcoord-batch-aside' }
    ]
  },
  cadcircle: {
    active: 'modeling',
    title: '모델링 - CAD link 기반 Foreline 모델링',
    subtitle: '링크 CAD의 원형을 레이어별로 검출하고 선택한 레벨에 패밀리를 배치합니다.',
    mainSlots: [
      { selector: '.cadcircle-card--setup', role: 'settings' },
      { selector: '.cadcircle-card--preview', role: 'result' }
    ],
    asideItems: [
      { selector: '.cadcircle-card--run', title: '검출 및 배치', role: 'run', wrap: false }
    ]
  },
  columnnumber: {
    active: 'modeling',
    title: '모델링 - 기둥 넘버',
    subtitle: '링크 기둥의 넘버 배치·검토와 구조 모델 자체의 기둥 번호 검토·입력을 수행합니다.',
    mainSlots: [{ selector: '.columnnumber-workspace', role: 'settings' }],
    asideItems: [{ selector: '.columnnumber-run-panel', title: '배치 및 검토', role: 'run', wrap: false }]
  },
  terraindrape: {
    active: 'modeling',
    title: '모델링 - 지형 연동 (TEST)',
    subtitle: '본체 대지에 보완 지형을 연결하고 도로 바닥까지 순서대로 갱신합니다.',
    mainSlots: [
      { selector: '.terraindrape-settings', role: 'settings' },
      { selector: '.terraindrape-targets', role: 'target' },
      { selector: '.terraindrape-supports', role: 'target' },
      { selector: '.terraindrape-results', role: 'result' }
    ],
    asideItems: [
      { selector: '.terraindrape-run', title: '적용 및 연결 관리', role: 'run', wrap: false }
    ]
  },
  centralworkset: {
    active: 'utility',
    title: '일반 도구 - 센트럴 파일생성, 웍셋 추가 Grid/Level, 3D 뷰 권한 적용',
    subtitle: '새 센트럴 생성, 기존 센트럴 웍셋 추가, Grid/Level 및 지정 3D 뷰 권한 적용을 한 화면에서 전환합니다.',
    mainSlots: [
      { selector: '.centralworkset-workspace', role: 'settings' }
    ],
    asideItems: [
      { selector: '.centralworkset-run-panel', title: '실행 및 결과', role: 'run', wrap: false }
    ]
  },
  levelchange: {
    active: 'utility',
    title: '일반 도구 - 프로젝트 파일 내 Level 변경',
    subtitle: '여러 프로젝트 RVT의 Level을 Excel 지시대로 이동하고 영향 객체·오류·동기화 결과를 파일별로 기록합니다.',
    mainSlots: [
      { selector: '.levelchange-workspace', role: 'settings' }
    ],
    asideItems: [
      { selector: '.levelchange-run-panel', title: '검증·실행 및 결과', role: 'run', wrap: false }
    ]
  },
  worksetmanager: {
    active: 'utility',
    title: '일반 도구 - 센트럴 파일생성, 웍셋 추가 Grid/Level, 3D 뷰 권한 적용',
    subtitle: '호환용 웍셋 모드입니다. 같은 통합 기능에서 새 센트럴 생성과 권한 적용 모드로 전환할 수 있습니다.',
    mainSlots: [
      { selector: '.centralworkset-workspace', role: 'settings' }
    ],
    asideItems: [
      { selector: '.centralworkset-run-panel', title: '실행 및 결과', role: 'run', wrap: false }
    ]
  },
  acccloud: {
    active: 'utility',
    title: '일반 도구 - ACC 클라우드 모델 생성 (TEST)',
    subtitle: '파일 RVT를 ACC/Autodesk Docs의 새 Cloud Workshared 모델로 테스트 생성합니다.',
    mainSlots: [
      { selector: '.acccloud-workspace', role: 'settings' }
    ],
    asideItems: [
      { selector: '.acccloud-run-panel', title: '실행 및 원격 상태', role: 'run', wrap: false }
    ]
  },
  accbackup: {
    active: 'utility',
    title: '일반 도구 - ACC 백업 (TEST)',
    subtitle: 'LAN file-based central의 닫힌 snapshot을 ACC ordinary RVT Item의 Version으로 테스트 백업합니다. RCW 병합 기능이 아닙니다.',
    mainSlots: [
      { selector: '.accbackup-workspace', role: 'settings' }
    ],
    asideItems: [
      { selector: '.accbackup-run-panel', title: '백업 queue 및 receipt', role: 'run', wrap: false }
    ]
  },
  lateralnozzle: {
    active: 'utility',
    title: 'Nozzle Code, KTA, 모델링 검토',
    subtitle: 'KTA 양식 단일화, RVT Nozzle 정보 추출, 두 결과 비교를 세 탭에서 실행합니다.',
    mainSlots: [
      { selector: '.lateralnozzle-workspace', role: 'target' }
    ],
    asideItems: []
  },
  guid: {
    active: 'utility',
    title: '일반 도구 - 파라미터 GUID 검토 및 정리',
    subtitle: 'GUID 검토, 삭제용 엑셀, 정리 실행을 같은 작업 흐름으로 관리합니다.',
    mainSlots: [
      { selector: '.guid-panel.segmentpms-extract', role: 'target' },
      { selector: '.guid-process-panel', role: 'settings' },
      { selector: '.guid-result-overview', role: 'result' }
    ],
    asideButtonGroups: []
  },
  sharedparambatch: {
    active: 'utility',
    title: '일반 도구 - 프로젝트 파라미터 일괄 추가',
    subtitle: '공유파라미터 선택, 카테고리 매핑, RVT 일괄 적용을 실행합니다.',
    mainSlots: [
      { selector: '.sharedparambatch-param-workflow', role: 'settings' },
      { selector: '.direct3-spb-options', role: 'settings' },
      { selector: '.sharedparambatch-result', role: 'result' }
    ],
    asideButtonGroups: [
      { selector: '.spb-rvtHeaderLeft .section-actions', title: '대상 RVT', role: 'target', includeText: ['대상 RVT 등록'] }
    ],
    asideItems: [
      { selector: '.spb-headerRight', title: '파라미터 실행', role: 'run', wrap: true }
    ]
  },
  scheduleio: {
    active: 'schedule',
    title: 'Schedule 도구 - Excel Import / Export',
    subtitle: '스케줄 기준 객체 데이터를 활성 문서 또는 여러 RVT에서 Excel로 교환합니다.',
    backRoute: '',
    backLabel: '홈',
    mainSlots: [
      { selector: '.scheduleio-workspace', role: 'settings' }
    ],
    asideItems: [
      { selector: '.scheduleio-run-panel', title: '대상 및 실행', role: 'run', wrap: false }
    ]
  },
  nwcexport: {
    active: 'nwc',
    title: 'NWC Export - 3D View 일괄 추출',
    subtitle: '활성 문서 또는 여러 RVT의 선택한 3D View를 NWC로 추출합니다.',
    backRoute: '',
    backLabel: '홈',
    mainSlots: [
      { selector: '.nwcexport-workspace', role: 'settings' }
    ],
    asideItems: [
      { selector: '.nwcexport-run-panel', title: '대상 및 실행', role: 'run', wrap: false }
    ]
  },
  nwccompare: {
    active: 'nwc',
    title: 'NWC Export - NWC 용량 비교 검토',
    subtitle: '기준 폴더와 현재 폴더의 NWC를 파일명, 용량, 해시로 비교합니다.',
    backRoute: '',
    backLabel: '홈',
    mainSlots: [
      { selector: '.nwccompare-workspace', role: 'settings' }
    ],
    asideItems: [
      { selector: '.nwccompare-run-panel', title: '비교 실행', role: 'run', wrap: false }
    ]
  },
  usermanagement: {
    active: 'home',
    title: '설정 - 사용자 관리',
    subtitle: '사용자 권한과 실행 정책을 3.0 작업대 안에서 확인합니다.',
    asideSelectors: []
  }
});

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', start, { once: true });
} else {
  void start();
}

async function start() {
  try {
    window.kkyHubStartup?.phase('script-load', '화면 스크립트 준비가 완료되었습니다.');
    try {
      await initializeSharedFeatureSettings({ initialWaitMs: 700 });
    } catch (error) {
      console.warn('[main] shared settings initialization failed; using local settings.', error);
      window.kkyHubStartup?.note(`공유 설정을 읽지 못해 현재 설정을 사용합니다: ${error?.message || error}`);
    }
    window.kkyHubStartup?.phase('theme', '화면 표시 설정을 적용합니다.');
    initTheme();
    boot();
  } catch (error) {
    console.error('[main] startup failed', error);
    window.kkyHubStartup?.fail(error);
  }
}

function boot() {
  const bootEl = document.getElementById('boot');
  if (bootEl) bootEl.remove();

  const app = document.getElementById('app');
  if (app) app.hidden = false;

  _viewRoot = document.getElementById('view-root') || app;
  _topbarRoot = document.getElementById('topbar-root') || app;
  renderTopbar(_topbarRoot, false, null);

  initLogConsole();
  log(`[hub] boot ${HUB_DEBUG_STAMP} url=${location.href}`);

  window.addEventListener('keydown', (ev) => {
    if (ev.key === 'F12') {
      ev.preventDefault();
      toggleLogConsole();
      log(`[hub] F12 debug requested ${HUB_DEBUG_STAMP}`);
      try {
        post('ui:open-devtools', { source: 'F12', stamp: HUB_DEBUG_STAMP, href: location.href });
      } catch (err) {
        console.error('[hub] open-devtools post failed', err);
      }
      return;
    }

    const tag = ev.target && ev.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;

    if (ev.ctrlKey && ev.shiftKey && String(ev.key || '').toLowerCase() === 'l') {
      ev.preventDefault();
      toggleTheme();
      log('[hub] theme toggled via Ctrl+Shift+L');
      return;
    }
  });

  try { post('ui:query-topmost'); } catch { }
  try { post('documentvisualaid:query-settings'); } catch { }
  try { post('scheduleboard:query'); } catch { }
  try { post('update:query'); } catch { }
  window.setTimeout(() => {
    try { post('update:check', { silent: true, startup: true }); } catch { }
  }, 900);

  route();
  window.addEventListener('hashchange', route);

  onHost((msg) => {
    try {
      if (!msg || !msg.ev) return;

      if (DEV) {
        try { console.log('[host] <-', msg.ev, msg.payload); } catch { }
      }

      switch (msg.ev) {
        case 'host:topmost': {
          const on = (msg && typeof msg.payload === 'object') ? !!msg.payload.on : !!msg.payload;
          if (_lastTop === on) return;
          _lastTop = on;
          updateTopMost(on);
          break;
        }
        case 'host:doc-changed':
          setActiveDocument(msg.payload || {});
          break;
        case 'host:doc-list':
          setDocList(msg.payload);
          break;
        case 'host:update-info':
          setUpdateInfo(msg.payload || {});
          break;
        case 'host:update-state':
          setUpdateState(msg.payload || {});
          break;
        case 'host:document-visual-aid-settings':
          setDocumentVisualAidSettings(msg.payload || {});
          break;
        case 'host:schedule-board-settings':
          setScheduleBoardSettings(msg.payload || {});
          break;
        default:
          break;
      }
    } catch (e) {
      console.error('[main] onHost dispatch error:', e);
    }
  });

  requestHostContextSync();
  window.addEventListener('focus', requestHostContextSync);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) requestHostContextSync();
  });
}

function requestHostContextSync() {
  try { post('ui:sync-context'); } catch { }
}

function closeDirectRvtModals(options = {}) {
  document.querySelectorAll('.direct3-rvt-modal').forEach((modal) => {
    modal.classList.add('is-hidden');
    if (options.remove) modal.remove();
  });
}

function route() {
  const hash = (location.hash || '').replace('#', '');
  if (_activeDirectViewCleanup) {
    const cleanup = _activeDirectViewCleanup;
    _activeDirectViewCleanup = null;
    try { cleanup(); } catch (error) { log('warn', `화면 정리 중 오류: ${error?.message || error}`); }
  }
  closeDirectRvtModals({ remove: true });
  document.body.classList.toggle('uses-shell3', isShell3Route(hash));
  try { post('ui:route-changed', { route: hash }); } catch { }

  if (!_suppressHistory && _lastHash !== null && _lastHash !== hash) {
    _historyStack.push(_lastHash);
  }
  if (_suppressHistory) _suppressHistory = false;
  if (hash === '') _historyStack = [];
  _lastHash = hash;

  const onBack = () => {
    _historyStack = [];
    location.hash = '';
  };
  const onNavBack = () => {
    if (_historyStack.length === 0) return;
    const prev = _historyStack.pop();
    _suppressHistory = true;
    location.hash = prev ? `#${prev}` : '';
  };

  const withBack = hash !== '';
  renderTopbar(_topbarRoot, withBack, hash === '' ? null : onBack, _historyStack.length > 0, onNavBack);

  if (_activeViewScope) clearHostListenerScope(_activeViewScope);
  const nextScope = `route:${hash || 'home'}`;
  _activeViewScope = nextScope;

  if (_viewRoot) _viewRoot.innerHTML = '';
  const targetRoot = _viewRoot || document.getElementById('app');

  let renderView = renderHome;
  let renderOptions = null;
  switch (hash) {
    case 'bqc':
      renderView = renderGroupView3;
      renderOptions = { mode: 'bqc' };
      break;
    case 'bqc-results':
      renderView = renderGroupView3;
      renderOptions = { mode: 'bqc-results' };
      break;
    case 'utility':
      renderView = renderGroupView3;
      renderOptions = { mode: 'utility' };
      break;
    case 'linktools':
      renderView = renderGroupView3;
      renderOptions = { mode: 'linktools' };
      break;
    case 'modeling':
      renderView = renderGroupView3;
      renderOptions = { mode: 'modeling' };
      break;
    case 'rvt':
      renderView = renderRvtRegistration3;
      break;
    case 'dup': renderView = renderDup; break;
    case 'conn':
      redirectLegacyFeatureToWorkflow3('bqc', ['connector']);
      return;
    case 'export':
      redirectLegacyFeatureToWorkflow3('utility', ['points']);
      return;
    case 'paramprop': renderView = renderParamProp; break;
    case 'parammigration': renderView = renderParameterMigration; break;
    case 'sharedparambatch': renderView = renderSharedParamBatch; break;
    case 'segmentpms': renderView = renderSegmentPms; break;
    case 'guid': renderView = renderGuid; break;
    case 'familylink':
      redirectLegacyFeatureToWorkflow3('utility', ['familylink']);
      return;
    case 'linkworkset':
      redirectLegacyFeatureToWorkflow3('utility', ['linkworkset'], 'linktools');
      return;
    case 'linkbatch':
      post('linkmanager:open', {});
      location.hash = '';
      return;
    case 'linkpath': renderView = renderLinkPath; break;
    case 'linksharedcoord': renderView = renderLinkSharedCoord; break;
    case 'cadcircle': renderView = renderCadCirclePlacement; break;
    case 'columnnumber': renderView = renderColumnNumberPlacement; break;
    case 'terraindrape': renderView = renderTerrainDrape; break;
    case 'centralworkset': renderView = renderCentralWorkset; break;
    case 'levelchange': renderView = renderLevelChange; break;
    case 'acccloud': renderView = renderAccCloud; break;
    case 'accbackup': renderView = renderAccBackup; break;
    case 'worksetmanager':
      renderView = renderCentralWorkset;
      renderOptions = { worksetsOnly: true };
      break;
    case 'settings':
      renderView = renderMulti;
      renderOptions = { workflow3Settings: true };
      break;
    case 'run':
      renderView = renderMulti;
      renderOptions = { workflow3Run: true };
      break;
    case 'multi':
      location.hash = getLegacyMultiRedirectMode();
      return;
    case 'favorites':
      renderView = renderGroupView3;
      renderOptions = { mode: 'favorites', favoriteOnly: true };
      break;
    case 'deliverycleaner': renderView = renderDeliveryCleaner; break;
    case 'revieworganizer': renderView = renderReviewOrganizer; break;
    case 'parammodifier': renderView = renderParamModifier; break;
    case 'conditionextract': renderView = renderConditionExtract; break;
    case 'lateralnozzle': renderView = renderLateralNozzle; break;
    case 'scheduleio': renderView = renderScheduleIo; break;
    case 'nwcexport': renderView = renderNwcExport; break;
    case 'nwccompare': renderView = renderNwcCompare; break;
    case 'tapalign':
      redirectLegacyFeatureToWorkflow3('bqc', ['tapalign']);
      return;
    case 'active-menu':
      redirectToShellRoute('');
      return;
    case 'usermanagement': renderView = renderUserManagement; break;
    default: renderView = renderHome; break;
  }

  beginHostListenerScope(nextScope);
  let rendered;
  try {
    if (DIRECT_SHELL3_ROUTES[hash]) {
      rendered = renderDirectShell3Route(targetRoot, hash, renderView, renderOptions);
    } else if (renderOptions) {
      rendered = renderView(targetRoot, renderOptions);
    } else {
      rendered = renderView(targetRoot);
    }
  } finally {
    endHostListenerScope(nextScope);
  }
  // Legacy URLs can redirect before any view exists. Confirm readiness only
  // after the destination route has rendered, including same-document redirects.
  if (!window.kkyHubStartup?.isReady()) {
    if (!_topbarRoot?.firstElementChild || !_viewRoot?.firstElementChild) {
      throw new Error('메뉴 또는 초기 화면 표시가 완료되지 않았습니다.');
    }
    window.kkyHubStartup?.ready(`초기 화면 표시 완료: ${(location.hash || '#home').slice(0, 120)}`);
  }
  return rendered;
}

function redirectLegacyFeatureToWorkflow3(mode, ids, returnGroup = '') {
  const targetMode = mode === 'utility' ? 'utility' : 'bqc';
  const selected = normalizeRouteIds(ids);
  if (!selected.length) {
    redirectToShellRoute(targetMode);
    return;
  }

  try {
    setSelectedFeatureIds3(targetMode, selected);
    localStorage.setItem('kky.hub.multiMode', targetMode);
    localStorage.setItem('kky.hub.workflow3.pendingSelection', JSON.stringify({
      mode: targetMode,
      selected,
      createdAt: Date.now()
    }));
  } catch {
  }

  const url = new URL(location.href);
  url.hash = 'settings';
  url.searchParams.set('workflow3', String(Date.now()));
  url.searchParams.set('workflow3Settings', '1');
  url.searchParams.set('workflow3Mode', targetMode);
  url.searchParams.set('workflow3Selection', selected.join(','));
  if (returnGroup) url.searchParams.set('workflow3Return', returnGroup);
  else url.searchParams.delete('workflow3Return');
  url.searchParams.delete('workflow3Dialog');
  url.searchParams.delete('workflow3Target');
  url.searchParams.delete('workflow3Rvts');
  location.replace(url.toString());
}

function redirectToShellRoute(hash) {
  const url = new URL(location.href);
  url.hash = hash || '';
  url.searchParams.delete('workflow3Dialog');
  url.searchParams.delete('workflow3Settings');
  url.searchParams.delete('workflow3Target');
  url.searchParams.delete('workflow3Rvts');
  location.replace(url.toString());
}

function normalizeRouteIds(ids) {
  const seen = new Set();
  return (Array.isArray(ids) ? ids : [ids])
    .map((id) => String(id || '').trim())
    .filter(Boolean)
    .filter((id) => {
      if (seen.has(id)) return false;
      seen.add(id);
      return true;
    });
}

function isShell3Route(hash) {
  return hash === '' || hash === 'bqc' || hash === 'bqc-results' || hash === 'utility' || hash === 'linktools' || hash === 'modeling' || hash === 'settings' || hash === 'rvt' || hash === 'run' || hash === 'favorites' || !!DIRECT_SHELL3_ROUTES[hash];
}

function renderDirectShell3Route(targetRoot, hash, renderView, renderOptions = null) {
  const meta = DIRECT_SHELL3_ROUTES[hash] || {};
  const main = document.createElement('div');
  main.className = `direct3-main direct3-main--${hash}`;
  const aside = document.createElement('aside');
  aside.className = `direct3-aside direct3-aside--${hash}`;

  const shell = renderShell3(targetRoot, {
    active: meta.active || 'utility',
    layout: 'direct',
    title: meta.title || '별도 실행 기능',
    subtitle: meta.subtitle || '선택한 기능을 3.0 작업대 안에서 실행합니다.',
    main,
    aside
  });
  shell?.shell?.classList.add(`shell3-direct-route--${hash}`);

  installDirectShell3BackButton(shell?.shell, meta);
  const viewCleanup = renderView(main, { shell3Direct: true, ...(renderOptions || {}) });
  _activeDirectViewCleanup = () => {
    try { if (typeof viewCleanup === 'function') viewCleanup(); }
    finally { main.querySelector('.deliverycleaner-page--main')?._directRvtModal?.dispose(); shell?.cleanup?.(); }
  };
  finalizeDirectShell3Layout(hash, main, aside, meta);

  return shell;
}

function installDirectShell3BackButton(shell, meta = {}) {
  const title = shell?.querySelector('.shell3-title');
  if (!title || title.querySelector('[data-direct-feature-back]')) return;
  const h1 = title.querySelector('h1');
  const subtitle = title.querySelector('p');
  if (!h1 && !subtitle) return;

  const copy = document.createElement('div');
  copy.className = 'shell3-title-copy';
  if (h1) copy.append(h1);
  if (subtitle) copy.append(subtitle);

  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'settings3-top-back shell3-top-back';
  button.dataset.directFeatureBack = '1';
  button.innerHTML = `<span aria-hidden="true">&larr;</span><span>${meta.backLabel || '기능 선택'}</span>`;
  button.addEventListener('click', () => {
    redirectToShellRoute(getDirectFeatureBackRoute(meta));
  });

  title.classList.add('shell3-title-with-back');
  title.replaceChildren(button, copy);
}

function getDirectFeatureBackRoute(meta = {}) {
  if (Object.prototype.hasOwnProperty.call(meta, 'backRoute')) return meta.backRoute || '';
  if (meta.active === 'bqc') return 'bqc';
  if (meta.active === 'bqc-results') return 'bqc-results';
  if (meta.active === 'modeling') return 'modeling';
  if (meta.active === 'linktools') return 'linktools';
  if (meta.active === 'favorites') return 'favorites';
  if (meta.active === 'home') return '';
  return 'utility';
}

function finalizeDirectShell3Layout(hash, main, aside, meta = {}) {
  const page = main.querySelector(':scope > .feature-shell');
  if (page) {
    page.classList.add('direct3-embedded', `direct3-route-${hash}`);
    page.dataset.directRoute = hash;
  }

  prepareDirectRouteLayout(hash, main, meta);
  markDirectMainSlots(main, meta, hash);
  installDirectFeatureGuide(main, meta, hash);

  const moved = [];
  getDirectAsideItems(meta).forEach((item) => {
    const selector = item?.selector;
    if (!selector) return;
    main.querySelectorAll(selector).forEach((node) => {
      if (!node || moved.some((entry) => entry.node === node)) return;
      if (node.closest('.direct3-aside')) return;
      moved.push({ node, item });
    });
  });

  moved.forEach(({ node, item }) => {
    const parent = node.parentElement;
    node.classList.add('direct3-aside-card');
    normalizeDirectAsideNode(node, item);
    aside.append(wrapDirectAsideNode(node, item));
    cleanupDirectEmptyParent(parent);
  });

  moveDirectAsideButtonGroups(main, aside, meta);

  if (!aside.children.length) {
    aside.hidden = true;
    aside.classList.add('is-empty');
    aside.closest('.shell3-aside')?.classList.add('is-empty');
    aside.closest('.shell3-content')?.classList.add('shell3-content--no-aside');
  }
}

function prepareDirectRouteLayout(hash, main) {
  if (hash === 'deliverycleaner') {
    prepareDeliveryCleanerDirectLayout(main);
    return;
  }
  if (hash === 'guid') {
    prepareGuidDirectLayout(main);
    return;
  }
  if (hash === 'sharedparambatch') {
    prepareSharedParamBatchDirectLayout(main);
    return;
  }
  if (hash === 'parammodifier') {
    prepareParamModifierDirectLayout(main);
  }
}

function prepareDeliveryCleanerDirectLayout(main) {
  const page = main.querySelector('.deliverycleaner-page--main');
  const filesCard = page?.querySelector('.deliverycleaner-card--files');
  const controlCard = page?.querySelector('.deliverycleaner-card--control');
  if (!page || !filesCard || !controlCard) return;

  if (!page.querySelector('.direct3-delivery-settings')) {
    const settingsGroup = Array.from(controlCard.querySelectorAll('.deliverycleaner-action-group'))
      .find((group) => group.querySelector('.deliverycleaner-action--settings'));
    if (settingsGroup) {
      const settingsCard = document.createElement('section');
      settingsCard.className = 'deliverycleaner-card direct3-derived-card direct3-delivery-settings';
      settingsCard.innerHTML = `
        <div class="deliverycleaner-card__head">
          <div>
            <h3>정리 설정</h3>
            <p>결과 폴더, 3D 뷰, 필터/VG 설정을 먼저 확인합니다.</p>
          </div>
        </div>
      `;
      settingsCard.append(settingsGroup);
      filesCard.insertAdjacentElement('afterend', settingsCard);
    }
  }

  const modal = createDirectRvtModal(page, {
    key: 'deliverycleaner',
    filesCard,
    title: '대상 RVT 등록',
    subtitle: '정리와 검토를 수행할 RVT를 추가하거나 선택 상태를 관리합니다.'
  });
  if (modal && !filesCard.closest('.direct3-rvt-modal')) {
    modal.body.append(filesCard);
  }

  const grid = controlCard.querySelector('.deliverycleaner-action-grid');
  if (grid && modal && !grid.querySelector('[data-direct-open-rvt="deliverycleaner"]')) {
    const openBtn = createDirectButton('대상 RVT 등록', () => modal.open(), 'secondary');
    openBtn.dataset.directOpenRvt = 'deliverycleaner';
    openBtn.title = '대상 RVT 등록 창을 열어 추가, 선택, 삭제를 관리합니다.';
    grid.prepend(createDirectActionGroup('대상', 'RVT 등록과 선택 목록 관리', openBtn));
  }
}

function prepareGuidDirectLayout(main) {
  // GUID owns its review, settings and result controls. Keep them together;
  // moving buttons by their captions previously hid the review entry points.
  main.querySelector('.guid-page--main')?.classList.add('direct3-guid-workspace');
}
function prepareSharedParamBatchDirectLayout(main) {
  const page = main.querySelector('.sharedparambatch-page--main');
  const rvtSection = page?.querySelector('.spb-rvtHeader')?.closest('.sharedparambatch-section');
  if (!page || !rvtSection) return;

  const rvtOptions = rvtSection.querySelector('.spb-rvtHeaderRight');
  if (rvtOptions && !page.querySelector('.direct3-spb-options')) {
    const optionsCard = document.createElement('section');
    optionsCard.className = 'sharedparambatch-section direct3-spb-options';
    optionsCard.innerHTML = `
      <div class="section-header">
        <div>
          <h3>RVT 적용 옵션</h3>
          <p>여러 RVT 적용 시 열기 방식과 동기화 코멘트를 설정합니다.</p>
        </div>
      </div>
    `;
    optionsCard.append(rvtOptions);
    const paramWorkflow = page.querySelector('.sharedparambatch-param-workflow');
    if (paramWorkflow) paramWorkflow.insertAdjacentElement('afterend', optionsCard);
    else rvtSection.insertAdjacentElement('beforebegin', optionsCard);
  }

  const openModalButton = Array.from(rvtSection.querySelectorAll('button, .btn, .card-btn, .card-action-btn'))
    .find((button) => getDirectButtonText(button).includes('리스트 크게보기'));
  if (openModalButton) {
    openModalButton.textContent = '대상 RVT 등록';
    openModalButton.title = '대상 RVT 등록 창을 열어 추가, 폴더 선택, 삭제를 관리합니다.';
    openModalButton.classList.add('direct3-rvt-launcher');
  }
  rvtSection.classList.add('direct3-hidden-rvt-source');
}

function prepareParamModifierDirectLayout(main) {
  const page = main.querySelector('.parammodifier-page--main');
  const runCard = page?.querySelector('.parammodifier-run-card');
  if (!page || !runCard) return;

  runCard.classList.add('direct3-parammodifier-options');
  const title = runCard.querySelector('.deliverycleaner-card__head h3');
  const sub = runCard.querySelector('.deliverycleaner-card__head p');
  if (title) title.textContent = '동기화 옵션';
  if (sub) sub.textContent = '활성 문서 적용 후 동기화 여부와 코멘트를 설정합니다.';

  const settingsCard = page.querySelector('.parammodifier-settings-card');
  const oldParent = runCard.parentElement;
  if (settingsCard && runCard.previousElementSibling !== settingsCard) {
    settingsCard.insertAdjacentElement('afterend', runCard);
    cleanupDirectEmptyParent(oldParent);
  }
}

function createDirectRvtModal(page, options = {}) {
  if (!page || !options.filesCard) return null;
  if (page._directRvtModal) return page._directRvtModal;
  const key = options.key || 'target';
  const notify = (phase) => page.dispatchEvent(new CustomEvent('kky:direct-rvt-modal', { detail: { key, phase } }));
  const overlay = document.createElement('div');
  overlay.className = 'direct3-rvt-modal is-hidden';
  overlay.dataset.directRvtModal = key;
  overlay.innerHTML = `
    <section class="direct3-rvt-modal__dialog">
      <div class="direct3-rvt-modal__head"></div>
      <div class="direct3-rvt-modal__body"></div>
      <div class="direct3-rvt-modal__footer">
        <button type="button" class="btn btn--secondary" data-direct-cancel-rvt>취소</button>
        <button type="button" class="btn btn--primary" data-direct-confirm-rvt>확인</button>
      </div>
    </section>`;
  const dialog = overlay.firstElementChild;
  const body = overlay.querySelector('.direct3-rvt-modal__body');
  const card = options.filesCard;
  const actions = card.querySelector('.deliverycleaner-inline-actions');
  const tableWrap = card.querySelector('.deliverycleaner-table-wrap');
  card.querySelector('.deliverycleaner-card__head')?.remove();
  card.querySelector('.rvt-drop-hint')?.remove();
  body.append(card);
  const close = () => {
    if (!overlay.classList.contains('is-hidden')) notify('cancel');
    registration.close();
  };
  const registration = createRvtRegistration({
    overlay, dialog, header: dialog.firstElementChild, actions, body, tableWrap,
    table: tableWrap.querySelector('table'), addButton: actions.querySelector('button'),
    footer: overlay.querySelector('.direct3-rvt-modal__footer'),
    subtitle: options.subtitle, cancelOnClose: true, onClose: close
  });
  overlay.addEventListener('click', event => {
    if (event.target.closest('[data-direct-confirm-rvt]')) { notify('confirm'); registration.close(); }
    else if (event.target === overlay || event.target.closest('[data-direct-cancel-rvt]')) close();
  });
  document.body.append(overlay);
  page._directRvtModal = {
    overlay, body,
    open: () => { if (overlay.classList.contains('is-hidden')) notify('open'); registration.open(); },
    close,
    dispose: () => { registration.dispose(); overlay.remove(); page._directRvtModal = null; }
  };
  return page._directRvtModal;
}

function createDirectButton(label, onClick, kind = 'secondary') {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = `btn btn--${kind === 'primary' ? 'primary' : 'secondary'}`;
  button.textContent = label || '실행';
  if (typeof onClick === 'function') button.addEventListener('click', onClick);
  return button;
}

function createDirectActionGroup(title, hint, ...buttons) {
  const group = document.createElement('div');
  group.className = 'deliverycleaner-action-group direct3-generated-action-group';
  const head = document.createElement('div');
  head.className = 'deliverycleaner-action-group__head';
  head.innerHTML = `<strong>${title || '대상'}</strong><span>${hint || ''}</span>`;
  const body = document.createElement('div');
  body.className = 'deliverycleaner-action-group__buttons';
  body.append(...buttons.filter(Boolean));
  group.append(head, body);
  return group;
}

function findDirectButtonByText(root, text) {
  const needle = String(text || '').trim();
  if (!root || !needle) return null;
  return Array.from(root.querySelectorAll('button, .btn, .card-btn, .card-action-btn, .feature-action-btn'))
    .find((button) => getDirectButtonText(button).includes(needle)) || null;
}

function markDirectMainSlots(main, meta = {}, hash = '') {
  const slots = Array.isArray(meta.mainSlots) ? meta.mainSlots : [];
  slots.forEach((slot) => {
    const selector = slot?.selector;
    if (!selector) return;
    main.querySelectorAll(selector).forEach((found) => {
      const node = slot.closest ? found.closest(slot.closest) : found;
      if (!node) return;
      node.classList.add('direct3-main-slot', `direct3-main-slot--${slot.role || 'content'}`);
      if (slot.role) node.dataset.directRole = slot.role;
    });
  });
}

function installDirectFeatureGuide(main, meta = {}, hash = '') {
  if (!main || main.querySelector(':scope > .direct3-guide-bar')) return;
  const button = createFeatureGuideButton(meta.manualSlug || hash, {
    featureLabel: meta.title || '기능',
    inline: true
  });
  if (!button) return;
  const bar = document.createElement('div');
  bar.className = 'direct3-guide-bar';
  bar.append(button);
  main.prepend(bar);
}

function getDirectAsideItems(meta = {}) {
  if (Array.isArray(meta.asideItems) && meta.asideItems.length) return meta.asideItems;
  return (meta.asideSelectors || []).map((selector) => ({ selector, wrap: false }));
}

function moveDirectAsideButtonGroups(main, aside, meta = {}) {
  const groups = Array.isArray(meta.asideButtonGroups) ? meta.asideButtonGroups : [];
  groups.forEach((group) => {
    if (!group?.selector) return;
    const buttons = [];
    main.querySelectorAll(group.selector).forEach((source) => {
      source.querySelectorAll('button, .btn, .card-btn, .card-action-btn, .feature-action-btn').forEach((button) => {
        if (button.closest('.direct3-aside')) return;
        if (button.classList.contains('direct3-hidden')) return;
        if (!matchesDirectButtonGroup(button, group)) return;
        buttons.push(button);
      });
    });
    if (!buttons.length) return;

    const section = createDirectAsideSection(group);
    const actionHost = document.createElement('div');
    actionHost.className = 'direct3-aside-actions';
    buttons.forEach((button) => {
      const parent = button.parentElement;
      stampDirectActionButton(button, group);
      actionHost.append(button);
      cleanupDirectEmptyParent(parent);
    });
    section.append(actionHost);
    aside.append(section);
  });
}

function matchesDirectButtonGroup(button, group = {}) {
  const includeText = Array.isArray(group.includeText) ? group.includeText : [];
  const excludeText = Array.isArray(group.excludeText) ? group.excludeText : [];
  const text = getDirectButtonText(button);
  if (excludeText.length && excludeText.some((pattern) => text.includes(String(pattern)))) return false;
  if (!includeText.length) return true;
  return includeText.some((pattern) => text.includes(String(pattern)));
}

function getDirectButtonText(button) {
  return String(button?.textContent || '').replace(/\s+/g, ' ').trim();
}

function createDirectAsideSection(item = {}) {
  const section = document.createElement('section');
  section.className = 'direct3-aside-section';
  if (item.className) {
    String(item.className).split(/\s+/).filter(Boolean).forEach((name) => section.classList.add(name));
  }
  stampDirectRole(section, item);

  const head = document.createElement('div');
  head.className = 'direct3-aside-section__head';
  const kicker = document.createElement('span');
  kicker.className = 'direct3-kicker';
  kicker.textContent = getDirectRoleLabel(item.role);
  const title = document.createElement('strong');
  title.textContent = item.title || '실행';
  head.append(kicker, title);

  section.append(head);
  return section;
}

function wrapDirectAsideNode(node, item = {}) {
  if (item.wrap === false || node.classList.contains('deliverycleaner-card') || node.classList.contains('parammodifier-run-card') || node.classList.contains('lateralnozzle-card--control')) {
    stampDirectRole(node, item);
    return node;
  }

  const section = createDirectAsideSection({
    ...item,
    title: item.title || inferDirectAsideTitle(node) || '실행'
  });
  section.append(node);
  return section;
}

function stampDirectRole(node, item = {}) {
  if (!node || !item) return;
  if (item.role) node.dataset.directRole = item.role;
  if (item.title) node.dataset.directTitle = item.title;
}

function getDirectRoleLabel(role) {
  switch (role) {
    case 'settings': return 'SETTINGS';
    case 'target': return 'TARGET';
    case 'result': return 'RESULT';
    case 'run':
    default:
      return 'RUN';
  }
}

function inferDirectAsideTitle(node) {
  const section = node?.closest('.section, .deliverycleaner-card, .familylink-card, .guid-panel, .sharedparambatch-section, .paramprop-card');
  const text = section?.querySelector('h3, .paramprop-title, .familylink-results-title, .guid-title h3')?.textContent;
  return String(text || '').trim();
}

function normalizeDirectAsideNode(node, item = {}) {
  node.querySelectorAll('button, .btn, .card-btn, .card-action-btn, .feature-action-btn').forEach((button) => {
    stampDirectActionButton(button, item);
    if (!button.title) {
      const label = String(button.textContent || '').replace(/\s+/g, ' ').trim();
      if (label) button.title = `${label} 실행`;
    }
  });

  node.querySelectorAll('.deliverycleaner-action-group').forEach((group) => {
    const title = group.querySelector('.deliverycleaner-action-group__head strong')?.textContent?.trim() || '';
    const hint = group.querySelector('.deliverycleaner-action-group__head span')?.textContent?.trim() || '';
    if (title || hint) group.title = [title, hint].filter(Boolean).join(' - ');
  });
}

function stampDirectActionButton(button, item = {}) {
  if (!button) return;
  button.classList.add('direct3-action-button');
  if (item.role) button.dataset.directRole = item.role;
  const kind = inferDirectActionButtonKind(button, item.role);
  button.dataset.directKind = kind;
  button.classList.remove('direct3-action-button--primary', 'direct3-action-button--secondary', 'direct3-action-button--muted');
  button.classList.add(`direct3-action-button--${kind}`);
}

function inferDirectActionButtonKind(button, role) {
  const text = getDirectButtonText(button);
  const explicitKind = button.getAttribute('data-direct-kind');
  if (explicitKind === 'primary' || explicitKind === 'secondary' || explicitKind === 'muted') return explicitKind;
  const primaryText = /검토 시작|활성 문서\s*(검토|적용|Import|Export)|선택(?:한)?\s*RVT\s*(검토|적용).*시작?|선택된\s*RVT\s*적용\s*시작|여러\s*RVT\s*(검토|적용|Import|Export)|연동 실행|정리 시작|추출 시작|링크 추출|엑셀 기준 적용|매핑 준비|PMS 등록\/업데이트/;
  if (/삭제|제거|비우기|초기화|취소/.test(text)) return 'muted';
  if (/결과|내보내기|저장|열기|보기|불러오기|양식|선택|설정|추가|폴더|찾아보기/.test(text)) {
    if (!primaryText.test(text)) return 'secondary';
  }
  if (
    primaryText.test(text) ||
    button.matches('.btn--primary, .btn-primary, .segmentpms-primary-action, .deliverycleaner-action--run, #btnParamPropRun, .guid-btn-warning')
  ) {
    return 'primary';
  }
  return role === 'result' ? 'secondary' : 'secondary';
}

function cleanupDirectEmptyParent(parent) {
  if (!parent || !parent.isConnected) return;
  if (parent.children.length > 0) return;
  if (
    parent.classList.contains('deliverycleaner-field-stack') ||
    parent.classList.contains('feature-actions') ||
    parent.classList.contains('familylink-rvt-actions') ||
    parent.classList.contains('guid-action-grid')
  ) {
    parent.remove();
  }
}

function getLegacyMultiRedirectMode() {
  try {
    const mode = localStorage.getItem('kky.hub.multiMode');
    if (mode === 'favorites') return 'favorites';
    return mode === 'utility' ? 'utility' : 'bqc';
  } catch {
    return 'bqc';
  }
}


