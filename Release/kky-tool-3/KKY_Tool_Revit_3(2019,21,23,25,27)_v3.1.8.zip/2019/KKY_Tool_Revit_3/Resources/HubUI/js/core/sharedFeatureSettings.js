import { DEV, onHost, post } from './bridge.js';

const SNAPSHOT_EVENT = 'featuresettings:snapshot';
const ERROR_EVENT = 'featuresettings:error';
const CHANGE_EVENT = 'kky:shared-settings-changed';
const INITIAL_WAIT_MS = 700;
const POLL_INTERVAL_MS = 900;
const LOCAL_DEBOUNCE_MS = 200;

const WORKFLOW_KEY = 'kky.hub.workflow3.v2';
const NWC_COMPARE_KEY = 'kky.nwccompare.settings.v1';
const FAMILY_SUITABILITY_KEYS = new Set([
  'kky.hub.familySuitabilityRecent',
  'kky.hub.familySuitabilityPresets'
]);
const PARAMETER_DUPLICATION_KEYS = new Set([
  'kky.hub.parameterDuplicationPresets',
  'kky.hub.parameterDuplicationRecent'
]);
const PARAMETER_STANDARD_KEY = 'kky.hub.parameterStandardConfig';
const UTILITY_MATERIAL_KEY = 'kky.hub.utilityMaterialConfig';
const FAMILY_LOCAL_FIELDS = new Set([
  'criteriaExcelPath',
  'criteriaRowCount',
  'criteriaComboCount',
  'criteriaSheetCount'
]);
const PARAMETER_DUPLICATION_LOCAL_FIELDS = new Set([
  'sharedParamSourcePath',
  'sharedParamImportCount'
]);

// Existing keys are shared only when they were audited as reusable preferences.
// Unknown legacy keys stay local. New features must use kky.settings.<feature>.v1.
const LEGACY_SHARED_KEYS = new Set([
  'kky_card_order',
  'kky_conn_opts',
  'kky_dup_excl_kw',
  'kky_dup_export_params',
  'kky_dup_mode',
  'kky_dup_rulelib_sel_v1',
  'kky_dup_rulelib_v1',
  'kky_dup_ruleset_v1',
  'kky_dup_scope_mode',
  'kky_dup_tol_mm',
  'kky_dup_tol_unit',
  'kky_favs',
  'kky_guid_settings',
  'kky_spb_cat_presets',
  'kky_tapalign_opts',
  'kky_tapdepth_opts',
  'kky_theme',
  'kky.hub.commonFilterPresets',
  'kky.hub.commonOptions',
  'kky.hub.connectorRecentParams',
  'kky.hub.excelExportLocale',
  'kky.hub.familySuitabilityPresets',
  'kky.hub.familySuitabilityRecent',
  'kky.hub.multiGroupFilter',
  'kky.hub.multiMode',
  'kky.hub.panelSearch.v1',
  'kky.hub.parameterDuplicationPresets',
  'kky.hub.parameterDuplicationRecent',
  'kky.hub.parameterMissingConfig',
  'kky.hub.parameterMissingRecent',
  'kky.hub.parameterStandardConfig',
  'kky.hub.utilityMaterialConfig',
  'kky.hub.quickAccess.v1',
  WORKFLOW_KEY,
  'kky.nwccompare.presets.v1',
  NWC_COMPARE_KEY,
  'kky.nwcexport.settings.v2',
  'kky.settings.nwcexport.workflow.v1'
]);

const DENIED_KEYS = new Set([
  'kky_dup_meta_v1',
  'kky_guid_rvts',
  'kky_last_run',
  'kky_segmentpms_rvt_list',
  'kky.hub.home.deliverySchedule.v1',
  'kky.hub.quickAccess.pending',
  'kky.hub.workflow3.pendingActiveDocument',
  'kky.hub.workflow3.pendingRunTarget',
  'kky.hub.workflow3.pendingRvts',
  'kky.hub.workflow3.pendingSelection',
  'kky.hub.workflow3.pendingSettings',
  'kky.hub.workflow3.settingsNavigationStartedAt'
]);

const NEW_SHARED_KEY_PATTERN = /^kky\.settings\.[a-z0-9][a-z0-9._-]{0,96}\.v1$/;
const FORBIDDEN_NEW_KEY_TOKENS = Object.freeze([
  'auth',
  'credential',
  'document',
  'license',
  'password',
  'pending',
  'progress',
  'result',
  'rvt',
  'secret',
  'session',
  'token',
  'update'
]);

const nativeStorage = typeof Storage === 'undefined'
  ? null
  : {
      clear: Storage.prototype.clear,
      getItem: Storage.prototype.getItem,
      key: Storage.prototype.key,
      removeItem: Storage.prototype.removeItem,
      setItem: Storage.prototype.setItem
    };

const clientId = createClientId();
const remoteState = new Map();
const entryRevisions = new Map();
const pendingChanges = new Map();
const inFlightCommits = new Map();
const initialLocalValues = new Map();

let currentRevision = 0;
let requestSequence = 0;
let applyingRemote = false;
let storageHookInstalled = false;
let listenersInstalled = false;
let firstSnapshotReceived = false;
let firstSnapshotResolve = null;
let firstSnapshotPromise = null;
let initializePromise = null;
let commitTimer = 0;
let pollTimer = 0;

export function initializeSharedFeatureSettings(options = {}) {
  if (initializePromise) return initializePromise;
  initializePromise = initialize(options);
  return initializePromise;
}

export function isSharedFeatureSettingKey(key) {
  const normalized = String(key || '');
  if (!normalized || DENIED_KEYS.has(normalized)) return false;
  if (LEGACY_SHARED_KEYS.has(normalized)) return true;
  if (!NEW_SHARED_KEY_PATTERN.test(normalized)) return false;
  return !FORBIDDEN_NEW_KEY_TOKENS.some((token) => normalized.includes(token));
}

async function initialize(options) {
  installStorageHook();
  captureInitialLocalValues();
  installHostListeners();

  if (DEV) {
    firstSnapshotReceived = true;
    return { source: 'local-dev', revision: currentRevision, received: false };
  }

  firstSnapshotPromise = new Promise((resolve) => {
    firstSnapshotResolve = resolve;
  });

  requestSnapshot(true);
  const waitMs = clampWait(options.initialWaitMs);
  const result = await Promise.race([
    firstSnapshotPromise,
    new Promise((resolve) => window.setTimeout(
      () => resolve({ source: 'local-timeout', revision: currentRevision, received: false }),
      waitMs
    ))
  ]);

  if (!pollTimer) pollTimer = window.setInterval(() => requestSnapshot(false), POLL_INTERVAL_MS);
  return result;
}

function installHostListeners() {
  if (listenersInstalled || DEV) return;
  listenersInstalled = true;
  onHost(SNAPSHOT_EVENT, applySnapshot);
  onHost(ERROR_EVENT, handleHostError);
}

function requestSnapshot(initial) {
  if (DEV) return;
  post('featuresettings:get', {
    requestId: nextRequestId(initial ? 'initial' : 'poll'),
    clientId,
    knownRevision: initial ? 0 : currentRevision
  });
}

function applySnapshot(payload) {
  const snapshot = payload && typeof payload.snapshot === 'object' ? payload.snapshot : (payload || {});
  const snapshotRevision = toRevision(pick(snapshot, 'revision', 'Revision'));
  const entries = arrayOf(pick(snapshot, 'entries', 'Entries'));
  const changedKeys = [];
  const changedValues = {};

  currentRevision = Math.max(currentRevision, snapshotRevision);

  entries.forEach((rawEntry) => {
    const key = String(pick(rawEntry, 'key', 'Key') || '');
    if (!isSharedFeatureSettingKey(key)) return;

    const isDeleted = !!pick(rawEntry, 'isDeleted', 'IsDeleted');
    const entryRevision = toRevision(pick(rawEntry, 'revision', 'Revision'), snapshotRevision);
    const previousRevision = entryRevisions.get(key);
    const rawValue = isDeleted ? null : normalizeWireValue(pick(rawEntry, 'value', 'Value'));
    const sharedValue = isDeleted ? null : sanitizeSharedValue(key, rawValue);

    // Invalid special JSON never reaches localStorage, even if an old host store
    // happens to contain malformed or path-bearing data.
    if (!isDeleted && sharedValue == null) return;
    if (previousRevision != null && entryRevision < previousRevision) return;

    const previousRemote = remoteState.get(key);
    const remoteChanged = !previousRemote
      || previousRemote.isDeleted !== isDeleted
      || previousRemote.value !== sharedValue
      || entryRevision > previousRevision;

    entryRevisions.set(key, entryRevision);
    remoteState.set(key, { isDeleted, value: sharedValue });

    const oldValue = readLocal(key);
    const outstanding = findOutstandingChange(key);
    const valueToApply = outstanding ? outstanding.value : sharedValue;
    const deletionToApply = outstanding ? outstanding.isDeleted : isDeleted;
    const nextValue = mergeRemoteWithLocalParts(key, valueToApply, deletionToApply, oldValue);
    applyLocalValue(key, nextValue);
    const storedValue = readLocal(key);

    if (oldValue !== storedValue) dispatchSyntheticStorageEvent(key, oldValue, storedValue);
    if (remoteChanged || oldValue !== storedValue) {
      changedKeys.push(key);
      changedValues[key] = storedValue;
    }
  });

  settleMatchingCommits(payload, entries);

  if (changedKeys.length) {
    window.dispatchEvent(new CustomEvent(CHANGE_EVENT, {
      detail: {
        keys: Array.from(new Set(changedKeys)),
        values: changedValues,
        revision: currentRevision,
        source: 'host'
      }
    }));
  }

  if (!firstSnapshotReceived) {
    firstSnapshotReceived = true;
    seedMissingLegacyValues();
    firstSnapshotResolve?.({ source: 'host', revision: currentRevision, received: true });
    firstSnapshotResolve = null;
  }

  if (pendingChanges.size) scheduleCommit();
}

function seedMissingLegacyValues() {
  initialLocalValues.forEach((value, key) => {
    // Presence includes tombstones. A removed shared setting must not be
    // resurrected by stale per-process localStorage during first migration.
    if (remoteState.has(key)) return;
    const currentValue = sanitizeSharedValue(key, readLocal(key));
    if (currentValue == null) return;
    queueChange(key, currentValue, false, 0);
  });
}

function installStorageHook() {
  if (storageHookInstalled || !nativeStorage) return;
  storageHookInstalled = true;

  Storage.prototype.setItem = function patchedSetItem(key, value) {
    const normalizedKey = String(key);
    const normalizedValue = String(value);
    const result = nativeStorage.setItem.call(this, normalizedKey, normalizedValue);
    if (isLocalStorage(this) && !applyingRemote) {
      recordLocalMutation(normalizedKey, normalizedValue, false);
    }
    return result;
  };

  Storage.prototype.removeItem = function patchedRemoveItem(key) {
    const normalizedKey = String(key);
    const result = nativeStorage.removeItem.call(this, normalizedKey);
    if (isLocalStorage(this) && !applyingRemote) {
      recordLocalMutation(normalizedKey, null, true);
    }
    return result;
  };

  Storage.prototype.clear = function patchedClear() {
    const removedKeys = isLocalStorage(this) ? listLocalKeys().filter(isSharedFeatureSettingKey) : [];
    const result = nativeStorage.clear.call(this);
    if (isLocalStorage(this) && !applyingRemote) {
      removedKeys.forEach((key) => recordLocalMutation(key, null, true));
    }
    return result;
  };

  if (DEV) {
    window.addEventListener('storage', (event) => {
      const key = String(event?.key || '');
      if (!isSharedFeatureSettingKey(key)) return;
      window.dispatchEvent(new CustomEvent(CHANGE_EVENT, {
        detail: {
          keys: [key],
          values: { [key]: event.newValue },
          revision: currentRevision,
          source: 'browser-storage'
        }
      }));
    });
  }
}

function recordLocalMutation(key, rawValue, isDeleted) {
  if (!isSharedFeatureSettingKey(key)) return;

  const value = isDeleted ? null : sanitizeSharedValue(key, rawValue);
  if (!isDeleted && value == null) return;

  const remote = remoteState.get(key);
  if (remote && remote.isDeleted === isDeleted && remote.value === value) {
    pendingChanges.delete(key);
    return;
  }

  queueChange(key, value, isDeleted, entryRevisions.get(key) || 0);
}

function queueChange(key, value, isDeleted, baseEntryRevision) {
  pendingChanges.set(key, {
    key,
    value: isDeleted ? null : value,
    isDeleted: !!isDeleted,
    baseEntryRevision: toRevision(baseEntryRevision)
  });
  scheduleCommit();
}

function scheduleCommit() {
  if (DEV) return;
  if (commitTimer) window.clearTimeout(commitTimer);
  commitTimer = window.setTimeout(flushChanges, LOCAL_DEBOUNCE_MS);
}

function flushChanges() {
  commitTimer = 0;
  if (DEV || !pendingChanges.size) return;
  if (!firstSnapshotReceived) return;

  const changes = Array.from(pendingChanges.values()).map((change) => ({ ...change }));
  changes.forEach((change) => pendingChanges.delete(change.key));

  const requestId = nextRequestId('commit');
  inFlightCommits.set(requestId, changes);
  post('featuresettings:commit', {
    requestId,
    clientId,
    baseRevision: currentRevision,
    changes
  });
}

function handleHostError(payload) {
  const requestId = String(pick(payload, 'requestId', 'RequestId') || '');
  const failed = requestId ? inFlightCommits.get(requestId) : null;
  if (failed) {
    failed.forEach((change) => {
      if (!pendingChanges.has(change.key)) pendingChanges.set(change.key, change);
    });
    inFlightCommits.delete(requestId);
    window.setTimeout(scheduleCommit, POLL_INTERVAL_MS);
  }
  try {
    console.warn('[shared-settings] host error', pick(payload, 'message', 'Message') || payload);
  } catch {
  }
}

function settleMatchingCommits(payload, snapshotEntries) {
  const requestId = String(pick(payload, 'requestId', 'RequestId') || '');
  if (requestId && inFlightCommits.has(requestId)) {
    inFlightCommits.delete(requestId);
    return;
  }

  const acknowledged = new Map();
  arrayOf(snapshotEntries).forEach((entry) => {
    const key = String(pick(entry, 'key', 'Key') || '');
    if (!key) return;
    const isDeleted = !!pick(entry, 'isDeleted', 'IsDeleted');
    const value = isDeleted ? null : sanitizeSharedValue(key, normalizeWireValue(pick(entry, 'value', 'Value')));
    acknowledged.set(key, { isDeleted, value });
  });

  inFlightCommits.forEach((changes, id) => {
    const allMatched = changes.every((change) => {
      const actual = acknowledged.get(change.key);
      return actual && actual.isDeleted === change.isDeleted && actual.value === change.value;
    });
    if (allMatched) inFlightCommits.delete(id);
  });
}

function findOutstandingChange(key) {
  const pending = pendingChanges.get(key);
  if (pending) return pending;

  let latest = null;
  inFlightCommits.forEach((changes) => {
    const match = changes.find((change) => change.key === key);
    if (match) latest = match;
  });
  return latest;
}

function captureInitialLocalValues() {
  listLocalKeys().forEach((key) => {
    if (!isSharedFeatureSettingKey(key)) return;
    const value = sanitizeSharedValue(key, readLocal(key));
    if (value != null) initialLocalValues.set(key, value);
  });
}

function sanitizeSharedValue(key, rawValue) {
  if (rawValue == null) return null;
  const value = String(rawValue);
  if (key === WORKFLOW_KEY) {
    const parsed = parseObject(value);
    if (!parsed) return null;
    const shared = cloneJson(parsed);
    delete shared.rvtTargets;
    if (shared.presets && typeof shared.presets === 'object' && !Array.isArray(shared.presets)) {
      Object.keys(shared.presets).forEach((mode) => {
        const preset = shared.presets[mode];
        if (!preset || typeof preset !== 'object' || Array.isArray(preset)) return;
        delete preset.path;
      });
    }
    return stableStringify(shared);
  }
  if (key === NWC_COMPARE_KEY) {
    const parsed = parseObject(value);
    if (!parsed) return null;
    const shared = cloneJson(parsed);
    delete shared.baselineFolder;
    delete shared.currentFolder;
    delete shared.manualGroupsByContext;
    return stableStringify(shared);
  }
  if (FAMILY_SUITABILITY_KEYS.has(key)) {
    return sanitizeStructuredValue(value, (field) => FAMILY_LOCAL_FIELDS.has(field));
  }
  if (key === PARAMETER_STANDARD_KEY) {
    return sanitizeStructuredValue(value, (field) => (
      field === 'criteriaExcelPath'
      || field === 'warnings'
      || field.endsWith('Count')
    ));
  }
  if (key === UTILITY_MATERIAL_KEY) {
    return sanitizeStructuredValue(value, (field) => (
      field === 'criteriaExcelPath'
      || field === 'fileNameRuleExcelPath'
      || field === 'warnings'
      || field === 'fileNameRuleWarnings'
      || field === 'projects'
      || field === 'disciplines'
      || field === 'buildings'
      || field.endsWith('Count')
    ));
  }
  if (PARAMETER_DUPLICATION_KEYS.has(key)) {
    return sanitizeStructuredValue(value, (field) => PARAMETER_DUPLICATION_LOCAL_FIELDS.has(field));
  }
  return value;
}

function mergeRemoteWithLocalParts(key, sharedValue, isDeleted, currentValue) {
  if (key === WORKFLOW_KEY) {
    const local = parseObject(currentValue) || {};
    const shared = isDeleted ? {} : (parseObject(sharedValue) || {});
    const next = cloneJson(shared);

    if (Object.prototype.hasOwnProperty.call(local, 'rvtTargets')) {
      next.rvtTargets = cloneJson(local.rvtTargets);
    }

    const localPresets = local.presets && typeof local.presets === 'object' && !Array.isArray(local.presets)
      ? local.presets
      : {};
    const sharedPresets = next.presets && typeof next.presets === 'object' && !Array.isArray(next.presets)
      ? next.presets
      : {};
    const presetModes = new Set([...Object.keys(sharedPresets), ...Object.keys(localPresets)]);
    if (presetModes.size) {
      next.presets = {};
      presetModes.forEach((mode) => {
        const remotePreset = sharedPresets[mode] && typeof sharedPresets[mode] === 'object'
          ? cloneJson(sharedPresets[mode])
          : {};
        const localPreset = localPresets[mode];
        if (localPreset && typeof localPreset === 'object' && Object.prototype.hasOwnProperty.call(localPreset, 'path')) {
          remotePreset.path = String(localPreset.path || '');
        }
        if (Object.keys(remotePreset).length) next.presets[mode] = remotePreset;
      });
    }

    return Object.keys(next).length ? stableStringify(next) : null;
  }

  if (key === NWC_COMPARE_KEY) {
    const local = parseObject(currentValue) || {};
    const shared = isDeleted ? {} : (parseObject(sharedValue) || {});
    const next = cloneJson(shared);
    if (Object.prototype.hasOwnProperty.call(local, 'baselineFolder')) {
      next.baselineFolder = String(local.baselineFolder || '');
    }
    if (Object.prototype.hasOwnProperty.call(local, 'currentFolder')) {
      next.currentFolder = String(local.currentFolder || '');
    }
    if (Object.prototype.hasOwnProperty.call(local, 'manualGroupsByContext')) {
      next.manualGroupsByContext = cloneJson(local.manualGroupsByContext);
    }
    return Object.keys(next).length ? stableStringify(next) : null;
  }

  if (FAMILY_SUITABILITY_KEYS.has(key)) {
    return mergeStructuredLocalFields(
      sharedValue,
      isDeleted,
      currentValue,
      (field) => FAMILY_LOCAL_FIELDS.has(field)
    );
  }

  if (key === PARAMETER_STANDARD_KEY) {
    return mergeStructuredLocalFields(
      sharedValue,
      isDeleted,
      currentValue,
      (field) => field === 'criteriaExcelPath' || field === 'warnings' || field.endsWith('Count')
    );
  }

  if (key === UTILITY_MATERIAL_KEY) {
    return mergeStructuredLocalFields(
      sharedValue,
      isDeleted,
      currentValue,
      (field) => field === 'criteriaExcelPath'
        || field === 'fileNameRuleExcelPath'
        || field === 'warnings'
        || field === 'fileNameRuleWarnings'
        || field === 'projects'
        || field === 'disciplines'
        || field === 'buildings'
        || field.endsWith('Count')
    );
  }

  if (PARAMETER_DUPLICATION_KEYS.has(key)) {
    return mergeStructuredLocalFields(
      sharedValue,
      isDeleted,
      currentValue,
      (field) => PARAMETER_DUPLICATION_LOCAL_FIELDS.has(field)
    );
  }

  return isDeleted ? null : sharedValue;
}

function sanitizeStructuredValue(value, isLocalField) {
  const parsed = parseJson(value);
  if (parsed === undefined) return null;
  return stableStringify(removeLocalFields(parsed, isLocalField));
}

function mergeStructuredLocalFields(sharedValue, isDeleted, currentValue, isLocalField) {
  const local = parseJson(currentValue);
  const shared = isDeleted ? emptyStructureFor(local) : parseJson(sharedValue);
  if (shared === undefined) return null;
  const merged = restoreLocalFields(shared, local, isLocalField);
  if (Array.isArray(merged)) return merged.length ? stableStringify(merged) : null;
  if (merged && typeof merged === 'object') {
    return Object.keys(merged).length ? stableStringify(merged) : null;
  }
  return isDeleted ? null : stableStringify(merged);
}

function removeLocalFields(value, isLocalField) {
  if (Array.isArray(value)) return value.map((item) => removeLocalFields(item, isLocalField));
  if (!value || typeof value !== 'object') return value;

  const result = {};
  Object.keys(value).forEach((field) => {
    if (isLocalField(field)) return;
    result[field] = removeLocalFields(value[field], isLocalField);
  });
  return result;
}

function restoreLocalFields(sharedValue, localValue, isLocalField) {
  if (Array.isArray(sharedValue)) {
    const localArray = Array.isArray(localValue) ? localValue : [];
    const localByIdentity = new Map();
    localArray.forEach((item, index) => {
      localByIdentity.set(getStructuredIdentity(item, index), item);
    });
    return sharedValue.map((item, index) => restoreLocalFields(
      item,
      localByIdentity.get(getStructuredIdentity(item, index)),
      isLocalField
    ));
  }

  if (!sharedValue || typeof sharedValue !== 'object') return cloneJson(sharedValue);
  const localObject = localValue && typeof localValue === 'object' && !Array.isArray(localValue)
    ? localValue
    : {};
  const result = cloneJson(sharedValue);

  Object.keys(localObject).forEach((field) => {
    if (isLocalField(field)) result[field] = cloneJson(localObject[field]);
  });
  Object.keys(result).forEach((field) => {
    if (isLocalField(field)) return;
    if (result[field] && typeof result[field] === 'object') {
      result[field] = restoreLocalFields(result[field], localObject[field], isLocalField);
    }
  });
  return result;
}

function getStructuredIdentity(value, fallbackIndex) {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    const identity = value.name ?? value.key ?? value.id;
    if (identity != null && String(identity).trim()) return `id:${String(identity).trim()}`;
  }
  return `index:${fallbackIndex}`;
}

function emptyStructureFor(value) {
  return Array.isArray(value) ? [] : {};
}

function applyLocalValue(key, value) {
  if (!nativeStorage) return;
  applyingRemote = true;
  try {
    if (value == null) nativeStorage.removeItem.call(window.localStorage, key);
    else nativeStorage.setItem.call(window.localStorage, key, value);
  } catch {
    // The Host snapshot remains authoritative even when localStorage is locked.
  } finally {
    applyingRemote = false;
  }
}

function dispatchSyntheticStorageEvent(key, oldValue, newValue) {
  try {
    window.dispatchEvent(new StorageEvent('storage', {
      key,
      oldValue,
      newValue,
      storageArea: window.localStorage,
      url: location.href
    }));
  } catch {
    const event = new Event('storage');
    Object.defineProperties(event, {
      key: { value: key },
      oldValue: { value: oldValue },
      newValue: { value: newValue },
      storageArea: { value: window.localStorage },
      url: { value: location.href }
    });
    window.dispatchEvent(event);
  }
}

function readLocal(key) {
  if (!nativeStorage) return null;
  try {
    return nativeStorage.getItem.call(window.localStorage, key);
  } catch {
    return null;
  }
}

function listLocalKeys() {
  if (!nativeStorage) return [];
  try {
    const keys = [];
    for (let index = 0; index < window.localStorage.length; index += 1) {
      const key = nativeStorage.key.call(window.localStorage, index);
      if (key != null) keys.push(String(key));
    }
    return keys;
  } catch {
    return [];
  }
}

function isLocalStorage(storage) {
  try {
    return storage === window.localStorage;
  } catch {
    return false;
  }
}

function parseObject(value) {
  if (value == null || value === '') return null;
  try {
    const parsed = typeof value === 'string' ? JSON.parse(value) : value;
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

function parseJson(value) {
  if (value == null || value === '') return undefined;
  try {
    return typeof value === 'string' ? JSON.parse(value) : cloneJson(value);
  } catch {
    return undefined;
  }
}

function cloneJson(value) {
  if (value == null) return value;
  return JSON.parse(JSON.stringify(value));
}

function stableStringify(value) {
  return JSON.stringify(sortJson(value));
}

function sortJson(value) {
  if (Array.isArray(value)) return value.map(sortJson);
  if (!value || typeof value !== 'object') return value;
  const result = {};
  Object.keys(value).sort().forEach((key) => {
    result[key] = sortJson(value[key]);
  });
  return result;
}

function normalizeWireValue(value) {
  if (typeof value === 'string') return value;
  if (value == null) return '';
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

function pick(value, camel, pascal) {
  if (!value || typeof value !== 'object') return undefined;
  if (Object.prototype.hasOwnProperty.call(value, camel)) return value[camel];
  return value[pascal];
}

function arrayOf(value) {
  return Array.isArray(value) ? value : [];
}

function toRevision(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : Math.max(0, Number(fallback) || 0);
}

function clampWait(value) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return INITIAL_WAIT_MS;
  return Math.max(0, Math.min(INITIAL_WAIT_MS, Math.floor(parsed)));
}

function createClientId() {
  try {
    if (typeof crypto?.randomUUID === 'function') return crypto.randomUUID();
  } catch {
  }
  return `webview-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}

function nextRequestId(kind) {
  requestSequence += 1;
  return `${clientId}:${kind}:${Date.now().toString(36)}:${requestSequence}`;
}
