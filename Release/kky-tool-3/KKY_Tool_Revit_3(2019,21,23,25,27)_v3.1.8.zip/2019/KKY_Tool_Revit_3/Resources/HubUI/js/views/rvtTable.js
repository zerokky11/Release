import { isAccRvt, accRvtName, accRvtLabel } from '../core/accRvt.js';
export function getRvtName(path, fallback = '') {
  if (isAccRvt(path)) return accRvtName(path);
  if (!path) return fallback || '';
  const parts = String(path).split(/[/\\]/);
  return parts[parts.length - 1] || fallback || '';
}

export function createRvtTable(options = {}) {
  const table = document.createElement('table');
  table.className = 'segmentpms-table rvt-register-table';
  table.style.tableLayout = 'fixed';

  const colgroup = document.createElement('colgroup');
  colgroup.innerHTML = '<col style="width:44px"><col style="width:56px"><col style="width:280px"><col>';
  table.append(colgroup);

  const thead = document.createElement('thead');
  const headRow = document.createElement('tr');
  const thCheck = document.createElement('th');
  thCheck.style.textAlign = 'center';
  const master = document.createElement('input');
  master.type = 'checkbox';
  thCheck.append(master);

  const thIndex = document.createElement('th');
  thIndex.textContent = '#';
  thIndex.style.textAlign = 'center';

  const thName = document.createElement('th');
  thName.textContent = '파일명';

  const thPath = document.createElement('th');
  thPath.textContent = '파일 경로';

  headRow.append(thCheck, thIndex, thName, thPath);
  thead.append(headRow);

  const tbody = document.createElement('tbody');
  table.append(thead, tbody);
  if (options.registration) tbody.dataset.rvtRegistration = 'true';

  return { table, tbody, master };
}

export function renderRvtRows(tbody, rows, emptyMessage = '등록된 RVT가 없습니다.') {
  const registration = tbody.dataset.rvtRegistration === 'true';
  const previous = tbody._rvtRows || [];
  const reuse = registration && rows.length > 0 && previous.length === rows.length
    && rows.every((row, index) => row.path === previous[index].path);
  const active = registration && tbody.contains(document.activeElement) ? document.activeElement : null;
  const activePath = active ? previous[active.closest('tr')?.rowIndex - 1]?.path : null;
  if (!reuse) tbody.replaceChildren();
  if (!rows.length) {
    const emptyRow = document.createElement('tr'); emptyRow.className = 'empty-row';
    const emptyCell = document.createElement('td'); emptyCell.className = 'empty-cell';
    emptyCell.colSpan = 4; emptyCell.textContent = emptyMessage;
    emptyRow.append(emptyCell); tbody.append(emptyRow);
  }
  rows.forEach((row, idx) => {
    const tr = reuse ? tbody.children[idx] : document.createElement('tr');
    if (!reuse) {
      const ckCell = document.createElement('td'); ckCell.style.textAlign = 'center';
      const ck = document.createElement('input'); ck.type = 'checkbox'; ckCell.append(ck);
      const idxCell = document.createElement('td'); idxCell.style.textAlign = 'center';
      const nameCell = document.createElement('td'); nameCell.className = 'segmentpms-path-cell';
      const pathCell = document.createElement('td'); pathCell.className = 'segmentpms-path-cell';
      tr.append(ckCell, idxCell, nameCell, pathCell); tbody.append(tr);
    }
    const ck = tr.cells[0].firstElementChild;
    ck.checked = !!row.checked;
    ck.onchange = typeof row.onToggle === 'function' ? () => row.onToggle(ck.checked, idx) : null;
    tr.cells[1].textContent = String(row.index);
    tr.cells[2].textContent = row.name || '-';
    tr.cells[2].setAttribute('aria-label', row.name || '-');
    tr.cells[3].textContent = accRvtLabel(row.path) || '-';
    tr.cells[3].setAttribute('aria-label', row.title || accRvtLabel(row.path) || '-');
    if (registration) {
      ck.setAttribute('aria-label', (row.name || getRvtName(row.path) || 'RVT') + ' 선택');
      ck.title = row.title || row.path || '';
      tr.cells[2].title = row.name || '';
      tr.cells[3].title = row.title || row.path || '';
    }
  });
  if (registration) {
    tbody._rvtRows = rows;
    if (active && !active.isConnected) {
      const index = rows.findIndex(row => row.path === activePath);
      const focus = index >= 0 ? tbody.children[index].querySelector('input') : tbody.closest('table').querySelector('thead input');
      if (focus && !focus.disabled) focus.focus({ preventScroll: true });
    }
    tbody.dispatchEvent(new CustomEvent('kky:rvt-rows-rendered', { bubbles: true }));
  }
}
