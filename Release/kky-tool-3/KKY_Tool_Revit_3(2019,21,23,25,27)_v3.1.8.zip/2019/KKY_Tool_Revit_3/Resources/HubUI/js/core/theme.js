import { post } from './bridge.js';

const THEME_KEY = 'kky_theme';
export const THEME_CHANGE_EVENT = 'kkyt:theme-changed';

function getPreferredTheme() {
  let storedTheme;
  try {
    storedTheme = localStorage.getItem(THEME_KEY);
  } catch (error) {
    reportThemeStorageFailure('읽기', error);
    return 'dark';
  }
  if (storedTheme === 'dark' || storedTheme === 'light') return storedTheme;

  const bootTheme = document.documentElement.dataset.theme;
  if (bootTheme === 'dark' || bootTheme === 'light') return bootTheme;

  return 'dark';
}

function notifyTheme(theme) {
  try { post('ui:theme-changed', { theme }); } catch {}
}

export function applyTheme(t) {
  let theme = t === 'light' ? 'light' : 'dark';
  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch (error) {
    reportThemeStorageFailure('저장', error);
    theme = 'dark';
  }
  document.documentElement.dataset.theme = theme;
  try { window.dispatchEvent(new CustomEvent(THEME_CHANGE_EVENT, { detail: { theme } })); } catch {}
  notifyTheme(theme);
}
export function getCurrentTheme() { return getPreferredTheme(); }
export function toggleTheme() { const cur = getPreferredTheme(); applyTheme(cur === 'dark' ? 'light' : 'dark'); }
export function initTheme() { applyTheme(getPreferredTheme()); }

function reportThemeStorageFailure(operation, error) {
  const detail = `화면 표시 설정 ${operation} 실패; 기본 어두운 화면을 사용합니다: ${error?.message || error}`;
  try { console.warn('[theme] storage unavailable', error); } catch {}
  try { window.kkyHubStartup?.note(detail); } catch {}
}

window.addEventListener('kky:shared-settings-changed', (event) => {
  const keys = Array.isArray(event?.detail?.keys) ? event.detail.keys : [];
  if (!keys.includes(THEME_KEY)) return;
  const theme = getPreferredTheme();
  if (document.documentElement.dataset.theme === theme) return;
  document.documentElement.dataset.theme = theme;
  try { window.dispatchEvent(new CustomEvent(THEME_CHANGE_EVENT, { detail: { theme } })); } catch {}
  notifyTheme(theme);
});
