import { clear, div, toast, setBusy, showExcelSavedDialog, chooseExcelMode, showCompletionSummaryDialog } from '../core/dom.js?v=20260731parameterexport1';
import { refreshUiAfterHostDialog } from '../core/hostDialog.js';
import { getLastExcelExportLocale } from '../core/dom.js?v=20260731parameterexport1';
import { attachRvtDropZone } from '../core/rvtDrop.js';
import { createRvtTable, renderRvtRows, getRvtName } from './rvtTable.js?v=20260504a';
import { ProgressDialog } from '../core/progress.js';
import { post, onHost } from '../core/bridge.js';

const LS_RVT_LIST = 'kky_segmentpms_rvt_list';
const SUGGEST_SCORE_THRESHOLD = 70;
let progressHideTimer = null;
const PROGRESS_STAGE_WEIGHT = {
  open: 0,
  start: 0,
  extract: 0.33,
  route: 0.66,
  save: 0.75,
  excel_init: 0.75,
  excel_write: 0.9,
  excel_save: 0.95,
  autofit: 0.98,
  finish: 1,
  done: 1,
  error: 1
};
const PROGRESS_STAGE_TITLE = {
  open: 'RVT를 준비하는 중입니다.',
  start: 'RVT를 준비하는 중입니다.',
  extract: 'Segment를 추출하는 중입니다.',
  route: 'PMS 매핑을 적용하는 중입니다.',
  save: '결과를 저장하는 중입니다.',
  excel_init: '엑셀을 준비하는 중입니다.',
  excel_write: '엑셀을 작성하는 중입니다.',
  excel_save: '엑셀 파일을 저장하는 중입니다.',
  autofit: '열 너비를 맞추는 중입니다.',
  finish: '검토를 마무리하는 중입니다.',
  done: '검토 완료',
  error: '오류 발생'
};
const PROGRESS_STAGE_DETAIL = {
  open: 'Revit 파일을 여는 중입니다.',
  start: 'Revit 파일을 여는 중입니다.',
  extract: 'Segment 데이터를 추출하고 있습니다.',
  route: 'PMS 규칙과 매핑을 준비하고 있습니다.',
  save: '결과를 저장하고 있습니다.',
  excel_init: '엑셀 워크북을 준비하고 있습니다.',
  excel_write: '엑셀 데이터를 작성하고 있습니다.',
  excel_save: '파일을 저장하는 중입니다.',
  autofit: '엑셀 열 너비를 자동으로 맞추고 있습니다.',
  finish: '처리가 곧 완료됩니다.',
  done: '모든 파일 처리가 완료되었습니다.',
  error: 'Segment-PMS 검토 중 오류가 발생했습니다. 현재 RVT/추출 엑셀, PMS 양식, 매핑 선택을 확인한 뒤 다시 실행해 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.'
};
let progressPrevPct = 0;

function loadRvtList() {
  try {
    const arr = JSON.parse(localStorage.getItem(LS_RVT_LIST) || '[]');
    if (Array.isArray(arr)) return arr;
  } catch { }
  return [];
}

function saveRvtList(list) {
  localStorage.setItem(LS_RVT_LIST, JSON.stringify(list || []));
}

export function renderSegmentPms(root) {
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);
  const top = document.querySelector('#topbar-root .topbar') || document.querySelector('.topbar'); if (top) top.classList.add('hub-topbar');

  const state = {
    rvtList: loadRvtList(),
    rvtChecked: new Set(loadRvtList()),
    extractLoaded: false,
    extractSummary: '',
    extractPath: '',
    pmsLoaded: false,
    pmsOpts: [],
    groups: [],
    suggestions: new Map(), // key: groupKey -> {cls, segment}
    selections: new Map(), // groupKey -> {cls, segment, source}
    results: null,
    busy: false,
    progressTimer: null
  };

  const page = div('feature-shell segmentpms-page segmentpms-page--main');
  const header = div('feature-header');
  const heading = div('feature-heading');
  heading.innerHTML = `<span class="feature-kicker">시스템 타입 - PMS</span><h2 class="feature-title">PMS 검토</h2><p class="feature-sub">추출 엑셀과 PMS를 분리해 그룹 단위로 매핑한 뒤 비교합니다.</p>`;
  header.append(heading);
  page.append(header);

  /* Extract section */
  const extractSection = div('section segmentpms-extract');
  const exHeader = document.createElement('div'); exHeader.className = 'section-header';
  exHeader.innerHTML = '<h3>1단계: 추출 (RVT → 엑셀)</h3>';
  const exActions = div('segmentpms-actions-row feature-actions');
  const btnAddRvt = cardBtn('RVT 파일 추가', () => post('segmentpms:rvt-pick-files', {}));
  const btnAddFolder = cardBtn('폴더 선택', () => post('segmentpms:rvt-pick-folder', {}));
  const btnRemoveSel = cardBtn('선택 제거', removeCheckedRvt, 'segmentpms-danger-action');
  const btnClearAll = cardBtn('등록 목록 비우기', () => { state.rvtList = []; state.rvtChecked.clear(); persistRvt(); renderRvtList(); updateButtons(); }, 'segmentpms-danger-action');
  const btnExtract = cardBtn('추출 시작', onExtract, 'segmentpms-primary-action');
  const btnSaveExtract = cardBtn('엑셀 내보내기', () => chooseExcelMode((mode) => post('segmentpms:save-extract', { excelMode: mode || 'fast', locale: getLastExcelExportLocale() })));
  exActions.append(btnAddRvt, btnAddFolder, btnRemoveSel, btnClearAll, btnExtract, btnSaveExtract);
  exHeader.append(exActions);
  const rvtHint = div('rvt-drop-hint');
  rvtHint.textContent = 'RVT 파일 추가, 폴더 선택 또는 탐색기 드래그 앤 드롭으로 여러 .rvt를 바로 등록할 수 있습니다.';

  const { table: rvtTable, tbody: rvtBody, master: rvtMaster } = createRvtTable();
  const rvtBox = div('segmentpms-rvtlist segmentpms-table-wrap rvt-drop-zone');
  rvtBox.append(rvtTable);
  const extractInfo = div('segmentpms-summary segmentpms-summary--status'); extractInfo.textContent = '추출 상태: 미실행';
  const extractLoadRow = div('segmentpms-actions-row segmentpms-actions-row--single');
  const btnLoadExtract = cardBtn('추출 결과 불러오기', () => post('segmentpms:load-extract', {}));
  extractLoadRow.append(btnLoadExtract);
  extractSection.append(exHeader, rvtHint, rvtBox, extractLoadRow, extractInfo);
  attachRvtDropZone(rvtBox, {
    onDropPaths: (paths) => {
      const added = appendDroppedRvts(paths);
      if (!added) {
        toast('이미 등록된 RVT입니다.', 'warn');
        return;
      }
      persistRvt();
      renderRvtList();
      updateButtons();
      toast(`${added}개 RVT를 추가했습니다.`, 'ok');
    },
    onInvalid: () => toast('RVT 파일만 드래그해서 추가할 수 있습니다.', 'warn')
  });
  page.append(extractSection);

  /* Check section */
  const checkSection = div('section segmentpms-check');
  const chHeader = document.createElement('div'); chHeader.className = 'section-header';
  chHeader.innerHTML = '<h3>2단계: 검토 (추출 엑셀 + PMS)</h3>';
  const chActions = div('segmentpms-actions-row feature-actions');
  const btnRegisterPms = cardBtn('PMS 등록/업데이트', () => { setBusy(true, 'PMS 기준표를 불러오는 중입니다.'); state.busy = true; updateButtons(); post('segmentpms:register-pms', {}); }, 'segmentpms-primary-action');
  const btnTemplate = cardBtn('PMS 양식 추출하기', () => { setBusy(true, 'PMS 양식을 저장하는 중입니다.'); state.busy = true; updateButtons(); post('segmentpms:pms-template', {}); });
  const btnPrepare = cardBtn('매핑 준비', onPrepareMapping, 'segmentpms-warning-action');
  const btnRun = cardBtn('검토 시작', onRun, 'segmentpms-primary-action');
  const btnSave = cardBtn('엑셀 내보내기', () => {
    if (!state.results) { toast('먼저 검토를 실행한 뒤 결과를 내보내 주세요.', 'err'); return; }
    chooseExcelMode((mode) => post('segmentpms:save-result', { excelMode: mode || 'fast', locale: getLastExcelExportLocale() }));
  });
  btnSaveExtract.onclick = () => chooseExcelMode((mode) => {
    beginSegmentPmsProgress('추출 결과 내보내기를 준비하는 중입니다.');
    post('segmentpms:save-extract', { excelMode: mode || 'fast', locale: getLastExcelExportLocale() });
  });
  btnSave.onclick = () => {
    if (!state.results) { toast('먼저 검토를 실행한 뒤 결과를 내보내 주세요.', 'err'); return; }
    chooseExcelMode((mode) => {
      beginSegmentPmsProgress('검토 결과 내보내기를 준비하는 중입니다.');
      post('segmentpms:save-result', { excelMode: mode || 'fast', locale: getLastExcelExportLocale() });
    });
  };
  chActions.append(btnLoadExtract, btnRegisterPms, btnTemplate, btnPrepare, btnRun, btnSave);
  btnSaveExtract.onclick = () => startSegmentPmsExport('extract');
  btnSave.onclick = () => startSegmentPmsExport('result');
  chHeader.append(chActions);
  const pmsGuide = div('segmentpms-summary segmentpms-summary--guide');
  pmsGuide.textContent = "처음 사용자는 ‘PMS 양식 추출하기’로 샘플을 내려받아 동일 형식으로 작성해 주세요.";
  checkSection.append(chHeader, pmsGuide);

  const groupTable = document.createElement('table'); groupTable.className = 'segmentpms-table segmentpms-mapping-table';
  groupTable.innerHTML = '<thead><tr><th>Revit 세그먼트 그룹</th><th>사용처</th><th>PMS 세그먼트</th><th>추천</th></tr></thead><tbody></tbody>';
  const groupBody = groupTable.querySelector('tbody');
  const groupTableWrap = div('segmentpms-table-wrap segmentpms-map-wrap');
  groupTableWrap.append(groupTable);
  checkSection.append(groupTableWrap);

  const resInfo = div('segmentpms-summary segmentpms-summary--result'); resInfo.textContent = '검토 결과가 없습니다.';
  checkSection.append(resInfo);
  page.append(checkSection);

  target.append(page);

  renderRvtList();
  updateButtons();
  onHost(handleHost);
  ProgressDialog.setActions({
    onCancel: () => {
      if (!state.busy) return;
      state.busy = false;
      setBusy(false);
      ProgressDialog.hide();
      toast('검토를 취소했습니다.', 'err');
      updateButtons();
    },
    onSkip: () => {
      toast('현재 작업은 다음 파일로 건너뛸 수 없습니다.', 'err');
    }
  });

  function persistRvt() { saveRvtList(state.rvtList); }

  function renderRvtList() {
    const allChecked = state.rvtList.length > 0 && state.rvtList.every(f => state.rvtChecked.has(f));
    rvtMaster.checked = allChecked;
    rvtMaster.disabled = state.rvtList.length === 0;
    rvtMaster.onchange = () => {
      if (rvtMaster.checked) state.rvtChecked = new Set(state.rvtList);
      else state.rvtChecked.clear();
      renderRvtList();
      updateButtons();
    };
    const rows = state.rvtList.map((p, idx) => ({
      checked: state.rvtChecked.has(p),
      index: idx + 1,
      name: getRvtName(p),
      path: p,
      title: p,
      onToggle: (checked) => {
        if (checked) state.rvtChecked.add(p);
        else state.rvtChecked.delete(p);
        updateButtons();
      }
    }));
    renderRvtRows(rvtBody, rows);
    updateButtons();
  }

  function removeCheckedRvt() {
    if (!state.rvtChecked.size) { toast('제거할 항목을 선택해 주세요.', 'err'); return; }
    state.rvtList = state.rvtList.filter(p => !state.rvtChecked.has(p));
    state.rvtChecked.clear(); persistRvt(); renderRvtList(); updateButtons();
  }

  function onExtract() {
    const targets = state.rvtList.filter(p => state.rvtChecked.has(p));
    if (!targets.length) { toast('추출할 RVT를 선택해 주세요.', 'err'); return; }
    state.busy = true; updateButtons();
    ProgressDialog.show('Segment 매핑/검증', '추출 작업을 준비하는 중입니다.');
    ProgressDialog.update(0, '추출 작업을 준비하는 중입니다.', '선택한 RVT와 추출 대상을 정리하는 중입니다.');
    post('segmentpms:extract', { files: targets });
  }

  function onPrepareMapping() {
    if (!state.extractLoaded) { toast('먼저 추출 결과를 불러와 주세요.', 'err'); return; }
    setBusy(true, '매핑을 준비하는 중입니다.'); state.busy = true; updateButtons();
    beginSegmentPmsProgress('매핑을 준비하는 중입니다.');
    post('segmentpms:prepare-mapping', {});
  }

  function buildGroupTable() {
    groupBody.innerHTML = '';
    state.selections.clear();
    if (!state.groups.length) {
      const tr = document.createElement('tr'); const td1 = document.createElement('td'); td1.colSpan = 4; td1.className = 'empty-cell'; td1.textContent = '추출 결과와 PMS를 불러와 매핑을 준비해 주세요.'; tr.append(td1); groupBody.append(tr); updateButtons(); return;
    }
    state.groups.forEach(g => {
      const tr = document.createElement('tr');
      tr.append(td(g.displayKey || g.groupKey));
      tr.append(td(g.usageSummary || ''));

      const pmsSel = document.createElement('select');
      fillPmsOptions(pmsSel);
      const suggLabel = document.createElement('small'); suggLabel.className = 'segmentpms-suggest';
      const localSuggestion = suggestPms(g.displayKey || g.groupKey, state.pmsOpts);
      const backendSuggestion = normalizeSuggestion(state.suggestions.get(g.groupKey));
      const groupSuggestion = normalizeSuggestion(g.suggestedSegmentKey ? { cls: g.suggestedClass, segment: g.suggestedSegmentKey, score: g.score || g.Score } : null);
      const applySuggestion = () => {
        const sug = pickBestSuggestion([backendSuggestion, groupSuggestion, localSuggestion]);
        if (sug && sug.segment && (sug.score || 0) >= SUGGEST_SCORE_THRESHOLD) {
          pmsSel.value = `${sug.cls}|||${sug.segment}`;
          suggLabel.textContent = '추천 적용';
          commitSelection(g.groupKey, pmsSel.value, 'Suggest');
        } else {
          suggLabel.textContent = '';
          commitSelection(g.groupKey, pmsSel.value, 'Manual');
        }
      };
      applySuggestion();

      pmsSel.onchange = () => {
        commitSelection(g.groupKey, pmsSel.value, 'Manual');
        suggLabel.textContent = '';
      };

      const tdPms = document.createElement('td'); tdPms.append(pmsSel);
      const tdSug = document.createElement('td'); tdSug.append(suggLabel);
      tr.append(tdPms, tdSug);
      groupBody.append(tr);
    });
    updateButtons();
  }

  function commitSelection(groupKey, pmsVal, source) {
    const val = String(pmsVal || '');
    const parts = val.split('|||');
    const cls = parts[0] || '';
    const seg = parts[1] || '';
    state.selections.set(groupKey, { groupKey, cls, segment: seg, source: source || 'Manual' });
  }

  function fillPmsOptions(sel) {
    const oldVal = sel.value;
    sel.innerHTML = '';
    sel.append(new Option('(선택)', ''));
    const added = new Set();
    state.pmsOpts.forEach(o => {
      const key = `${o.cls}|||${o.segment}`;
      if (added.has(key)) return;
      added.add(key);
      sel.append(new Option(o.label, key));
    });
    sel.value = oldVal;
  }

  function onRun() {
    if (!state.extractLoaded) { toast('먼저 추출 데이터를 불러와 주세요.', 'err'); return; }
    if (!state.pmsLoaded) { toast('먼저 PMS 기준표를 등록해 주세요.', 'err'); return; }
    const groups = [...state.selections.values()];
    state.results = null;
    setBusy(true, '검토를 실행하는 중입니다.'); state.busy = true; updateButtons();
    ProgressDialog.show('Segment 매핑/검증', '검토를 준비하는 중입니다.');
    ProgressDialog.update(0, '검토를 준비하는 중입니다.', '매핑 선택과 PMS 데이터를 확인하는 중입니다.');
    post('segmentpms:run', { groups });
  }

  function paintResults(payload) {
    state.results = payload || { hasResult: true };
    const resultSummary = summarizeSegmentPmsResults(payload);
    const total = resultSummary.totalCount;
    resInfo.textContent = total > 0
      ? `총 ${total}건의 결과가 준비되었습니다. 정상 ${resultSummary.okCount}건 / 검토 필요 ${resultSummary.reviewCount}건 / 오류 ${resultSummary.errorCount}건`
      : '검토 결과가 없습니다.';
    toast('검토가 완료되었습니다. 필요하면 엑셀로 내보내 주세요.', 'ok');
  }

  function beginSegmentPmsProgress(subtitle) {
    ProgressDialog.show('Segment-PMS 검토', subtitle || '작업을 준비하는 중입니다.');
    ProgressDialog.update(0, subtitle || '작업을 준비하는 중입니다.', '단계별 입력 데이터를 확인하는 중입니다.');
  }

  async function startSegmentPmsExport(kind) {
    if (state.busy) return;
    if (kind === 'extract' && !state.extractLoaded) {
      toast('먼저 추출을 실행하거나 추출 결과를 불러온 뒤 내보내 주세요.', 'err');
      return;
    }
    if (kind === 'result' && !state.results) {
      toast('먼저 검토를 실행한 뒤 결과를 내보내 주세요.', 'err');
      return;
    }

    const excelMode = await chooseExcelMode();
    if (!excelMode) return;
    state.busy = true;
    setBusy(true, '엑셀을 내보내는 중입니다.');
    updateButtons();

    if (kind === 'extract') {
      beginSegmentPmsProgress('추출 결과를 저장하는 중입니다.');
      post('segmentpms:save-extract', { excelMode: excelMode || 'fast', locale: getLastExcelExportLocale() });
      return;
    }

    beginSegmentPmsProgress('검토 결과를 저장하는 중입니다.');
    post('segmentpms:save-result', { excelMode: excelMode || 'fast', locale: getLastExcelExportLocale() });
  }

  function showSegmentPmsCompletionDialog(payload, totalCount) {
    const mappedCount = [...state.selections.values()].filter((item) => item && item.segment).length;
    const groupCount = state.groups.length || 0;
    const resultSummary = summarizeSegmentPmsResults(payload, totalCount);
    const notes = [];

    if (state.extractSummary) notes.push(`추출 기준: ${state.extractSummary}`);
    if (payload?.message) notes.push(String(payload.message));
    if (resultSummary.uncertainCount > 0) notes.push(`분류가 애매한 항목 ${resultSummary.uncertainCount}건은 검토 필요로 집계했습니다.`);

    showCompletionSummaryDialog({
      title: 'Segment-PMS 검토 완료',
      message: '검토가 끝났습니다. 그룹 매핑과 결과를 확인하고 필요하면 바로 엑셀로 내보낼 수 있습니다.',
      summaryItems: [
        { label: '대상 그룹 수', value: String(groupCount) },
        { label: '매핑 적용 그룹 수', value: String(mappedCount) },
        { label: '정상 건수', value: String(resultSummary.okCount) },
        { label: '검토 필요 건수', value: String(resultSummary.reviewCount) },
        { label: '오류 건수', value: String(resultSummary.errorCount) },
        { label: '검토 결과 건수', value: String(resultSummary.totalCount) }
      ],
      notes,
      exportDisabled: !!btnSave.disabled,
      onExport: () => btnSave.click()
    });
  }

  function summarizeSegmentPmsResults(payload, totalCountOverride) {
    const rows = Array.isArray(payload?.compare) ? payload.compare : [];
    const summary = {
      totalCount: Number(totalCountOverride ?? payload?.totalCount) || rows.length || 0,
      okCount: 0,
      reviewCount: 0,
      errorCount: 0,
      uncertainCount: 0
    };

    rows.forEach((row) => {
      const verdict = classifySegmentPmsRow(row);
      if (verdict === 'ok') summary.okCount += 1;
      else if (verdict === 'error') summary.errorCount += 1;
      else if (verdict === 'review') summary.reviewCount += 1;
      else summary.uncertainCount += 1;
    });

    if (!rows.length) return summary;
    if (summary.uncertainCount > 0) {
      summary.reviewCount += summary.uncertainCount;
    }
    const classifiedTotal = summary.okCount + summary.reviewCount + summary.errorCount;
    if (summary.totalCount < classifiedTotal) {
      summary.totalCount = classifiedTotal;
    } else if (summary.totalCount > classifiedTotal) {
      summary.reviewCount += summary.totalCount - classifiedTotal;
    }
    return summary;
  }

  function classifySegmentPmsRow(row) {
    if (!row || typeof row !== 'object') return 'unknown';

    const boolTrue = (...keys) => keys.some((key) => row?.[key] === true);
    const boolFalse = (...keys) => keys.some((key) => row?.[key] === false);
    const tokens = [
      row.status,
      row.result,
      row.compareResult,
      row.issue,
      row.message,
      row.detail,
      row.note,
      row.errorMessage,
      typeof row.error === 'string' ? row.error : ''
    ]
      .map((value) => String(value || '').trim().toLowerCase())
      .filter(Boolean);
    const joined = tokens.join(' | ');

    if (boolTrue('isError', 'hasError', 'error') || /(error|fail|exception|invalid)/.test(joined)) return 'error';
    if (boolFalse('isMatch', 'matched', 'isMatched', 'same', 'isSame', 'ok', 'success') || /(mismatch|different|diff|review|warning|missing|unmapped|not match|not matched)/.test(joined)) return 'review';
    if (boolTrue('isMatch', 'matched', 'isMatched', 'same', 'isSame', 'ok', 'success') || /(^|\W)(ok|match|same|equal|pass|mapped)(\W|$)/.test(joined)) return 'ok';
    return 'unknown';
  }

  function updateButtons() {
    btnRemoveSel.disabled = state.busy || state.rvtChecked.size === 0;
    btnClearAll.disabled = state.busy || state.rvtList.length === 0;
    btnExtract.disabled = state.busy || state.rvtChecked.size === 0;
    btnSaveExtract.disabled = state.busy || !state.extractLoaded;
    btnLoadExtract.disabled = state.busy;
    btnRegisterPms.disabled = state.busy;
    btnTemplate.disabled = state.busy;
    btnPrepare.disabled = state.busy || !state.extractLoaded;
    btnRun.disabled = state.busy || !state.extractLoaded || !state.pmsLoaded;
    btnSave.disabled = state.busy || !state.results;
  }

  function appendDroppedRvts(paths) {
    let added = 0;
    (Array.isArray(paths) ? paths : []).forEach((path) => {
      if (!path) return;
      const exists = state.rvtList.some((item) => item.toLowerCase() === String(path).toLowerCase());
      if (!exists) {
        state.rvtList.push(path);
        added += 1;
      }
      state.rvtChecked.add(path);
    });
    return added;
  }

  function handleHost(msg) {
    if (!msg || !msg.ev) return;
    if (msg.ev === 'segmentpms:saved') {
      setBusy(false); state.busy = false;
      ProgressDialog.hide();
      updateButtons();
      requestAnimationFrame(() => {
        showExcelSavedDialog('Segment-PMS 검토 결과 엑셀을 저장했습니다.', msg.payload?.path, (p) => {
          const target = p || msg.payload?.path;
          if (!target) { toast('저장된 파일 경로가 없습니다. 결과를 다시 저장해 주세요.', 'err'); return; }
          post('excel:open', { path: target });
        });
      });
      return;
    }
    switch (msg.ev) {
      case 'segmentpms:rvt-picked-files':
      case 'segmentpms:rvt-picked-folder': {
        appendDroppedRvts(msg.payload?.paths);
        persistRvt();
        refreshUiAfterHostDialog(() => {
          renderRvtList();
          updateButtons();
        });
        break;
      }
      case 'segmentpms:extract-saved':
        setBusy(false); state.busy = false;
        ProgressDialog.hide();
        if (msg.payload?.cancelled || msg.payload?.ok === false || !msg.payload?.path) {
          updateButtons();
          break;
        }
        state.extractLoaded = true;
        state.extractSummary = msg.payload?.summary || '';
        state.extractPath = msg.payload?.path || '';
        state.results = null;
        extractInfo.textContent = `추출 완료: ${state.extractSummary} (${state.extractPath})`;
        showExcelSavedDialog('Segment-PMS 추출 엑셀을 저장했습니다.', state.extractPath,
          (path) => post('excel:open', { path }));
        post('segmentpms:prepare-mapping', {});
        updateButtons();
        break;
      case 'segmentpms:extract-loaded':
        setBusy(false); state.busy = false;
        state.extractLoaded = true;
        state.extractSummary = msg.payload?.summary || '';
        state.extractPath = msg.payload?.path || '';
        state.results = null;
        extractInfo.textContent = `추출 로드: ${state.extractSummary} (${state.extractPath})`;
        state.groups = msg.payload?.groups || [];
        state.pmsOpts = msg.payload?.pms || state.pmsOpts;
        state.suggestions = buildSuggestionMap(msg.payload?.suggestions || []);
        buildGroupTable();
        updateButtons();
        break;
      case 'segmentpms:mapping-ready':
        setBusy(false); state.busy = false;
        ProgressDialog.hide();
        state.groups = msg.payload?.groups || [];
        state.pmsOpts = msg.payload?.pms || state.pmsOpts;
        state.suggestions = buildSuggestionMap(msg.payload?.suggestions || []);
        buildGroupTable();
        toast('매핑 준비가 완료되었습니다.', 'ok');
        updateButtons();
        break;
      case 'segmentpms:pms-registered':
        setBusy(false); state.busy = false;
        ProgressDialog.hide();
        state.pmsLoaded = true;
        state.pmsOpts = msg.payload?.options || [];
        state.suggestions = buildSuggestionMap(msg.payload?.suggestions || []);
        fillPmsOptions(document.createElement('select'));
        if (state.extractLoaded) post('segmentpms:prepare-mapping', {});
        toast('PMS를 등록했습니다.', 'ok');
        updateButtons();
        break;
      case 'segmentpms:pms-template-saved':
        setBusy(false); state.busy = false;
        showExcelSavedDialog('PMS 양식을 저장했습니다.', msg.payload?.path, (p) => {
          const target = p || msg.payload?.path;
          if (!target) { toast('저장된 PMS 양식 경로가 없습니다. 양식을 다시 저장해 주세요.', 'err'); return; }
          post('excel:open', { path: target });
        });
        updateButtons();
        break;
      case 'segmentpms:result':
        setBusy(false); state.busy = false;
        ProgressDialog.hide();
        paintResults(msg.payload || {});
        requestAnimationFrame(() => showSegmentPmsCompletionDialog(msg.payload || {}, msg.payload?.totalCount ?? (Array.isArray(msg.payload?.compare) ? msg.payload.compare.length : 0)));
        updateButtons();
        break;
      case 'segmentpms:progress':
        handleProgress(msg.payload || {});
        break;
      case 'segmentpms:error':
        setBusy(false); state.busy = false;
        ProgressDialog.hide();
        toast(msg.payload?.message || 'Segment-PMS 검토 중 오류가 발생했습니다. 현재 RVT/추출 엑셀, PMS 양식, 매핑 선택을 확인한 뒤 다시 실행해 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err');
        updateButtons();
        break;
      default: break;
    }
  }
}

function buildSuggestionMap(list) {
  const map = new Map();
  if (!Array.isArray(list)) return map;
  list.forEach(s => {
    const key = s.groupKey || s.GroupKey || s.segmentKey || s.SegmentKey || s.file;
    if (!key) return;
    const rawScore = Number(s.score ?? s.Score ?? 0);
    const score = Number.isFinite(rawScore) ? rawScore : 0;
    map.set(String(key), { pmsClass: s.pmsClass || s.PmsClass, pmsSegmentKey: s.pmsSegmentKey || s.PmsSegmentKey, score });
  });
  return map;
}

function handleProgress(payload) {
  if (progressHideTimer) { clearTimeout(progressHideTimer); progressHideTimer = null; }
  if (!payload) { ProgressDialog.hide(); progressPrevPct = 0; return; }

  const stage = normalizeStage(payload.stage || payload.phase);
  const total = Number(payload.total ?? payload.fileTotal) || 0;
  const index = Number(payload.index ?? payload.fileIndex ?? payload.current) || 0;
  const currentRows = Number(payload.current) || index;
  const percent = computeWeightedPercent(stage, total, index, payload.percent, currentRows);

  const file = payload.file || payload.fileName || '';
  const msg = payload.message || '';
  const title = PROGRESS_STAGE_TITLE[stage] || 'Segment-PMS를 검토하는 중입니다.';
  const subtitle = buildProgressDetail(stage, msg, file);
  const meta = buildProgressMeta(total, index, file);

  ProgressDialog.show('Segment 매핑/검증', title);
  ProgressDialog.update(percent, subtitle, meta);

  if (stage === 'finish' || stage === 'done') {
    progressHideTimer = setTimeout(() => { ProgressDialog.hide(); progressPrevPct = 0; }, 600);
  } else if (stage === 'error') {
    ProgressDialog.hide();
    progressPrevPct = 0;
  }
}

function normalizeSuggestion(sug) {
  if (!sug) return null;
  const cls = sug.cls || sug.pmsClass || sug.suggestedClass || '';
  const segment = sug.segment || sug.pmsSegmentKey || sug.suggestedSegmentKey || '';
  const rawScore = Number(sug.score ?? sug.Score ?? 0);
  const score = Number.isFinite(rawScore) ? rawScore : 0;
  if (!segment) return null;
  return { cls, segment, score };
}

function pickBestSuggestion(candidates) {
  return candidates
    .filter(Boolean)
    .reduce((best, cur) => {
      const curScore = Number.isFinite(cur.score) ? cur.score : 0;
      if (!best || curScore > best.score) return { ...cur, score: curScore };
      return best;
    }, null);
}

function suggestPms(revitSegmentKey, pmsOpts) {
  const tokens = tokenize(revitSegmentKey);
  if (!tokens.length || !Array.isArray(pmsOpts)) return null;
  let best = null;
  pmsOpts.forEach(opt => {
    const optTokens = tokenize(opt.segment);
    if (!optTokens.length) return;
    const matchCount = countOrderedMatches(tokens, optTokens);
    const lenDiff = Math.abs(optTokens.length - tokens.length);
    if (!best || matchCount > best.score || (matchCount === best.score && lenDiff < best.lenDiff)) {
      best = { cls: opt.cls, segment: opt.segment, score: matchCount, lenDiff };
    }
  });
  if (!best || best.score === 0) return null;
  return { cls: best.cls, segment: best.segment, score: best.score || 0 };
}

function tokenize(text) {
  if (!text) return [];
  return String(text)
    .toUpperCase()
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .split(' ')
    .map(t => t.trim())
    .filter(Boolean);
}

function countOrderedMatches(targetTokens, candidateTokens) {
  let idx = 0; let count = 0;
  targetTokens.forEach(t => {
    while (idx < candidateTokens.length) {
      if (t === candidateTokens[idx]) {
        count += 1;
        idx += 1;
        return;
      }
      idx += 1;
    }
  });
  return count;
}

function cardBtn(label, onclick, extraClass = '') {
  const b = document.createElement('button');
  b.type = 'button'; b.className = `btn card-btn${extraClass ? ` ${extraClass}` : ''}`; b.textContent = label; b.onclick = onclick; return b;
}

function td(v) { const t = document.createElement('td'); t.textContent = v == null ? '' : v; return t; }

function normalizeStage(stage) {
  return String(stage || '').toLowerCase();
}

function computeWeightedPercent(stage, total, index, incomingPct, currentRows = 0) {
  const clamp = (n) => Math.max(0, Math.min(100, n));
  const weight = PROGRESS_STAGE_WEIGHT[stage] ?? 0;
  const safeTotal = Math.max(1, total || 1);
  if (stage === 'open' || stage === 'start') progressPrevPct = 0;
  const cursor = Math.max(0, stage.startsWith('excel') || stage === 'autofit' ? currentRows : index);
  const basePct = clamp(weight * 100);
  const ratio = safeTotal > 0 ? Math.min(1, Math.max(0, cursor / safeTotal)) : 0;
  const weightedPct = clamp(basePct + (100 - basePct) * ratio);
  const parsedPct = Number(incomingPct);
  const providedPct = Number.isFinite(parsedPct) ? clamp(parsedPct) : 0;
  const pct = Math.max(progressPrevPct, providedPct, weightedPct);
  progressPrevPct = pct;
  return pct;
}

function buildProgressDetail(stage, message, file) {
  const parts = [];
  const fallback = PROGRESS_STAGE_DETAIL[stage] || '데이터를 처리하고 있습니다.';
  if (message) parts.push(message);
  if (parts.length === 0) parts.push(fallback);
  if (file) parts.push(file);
  return parts.join(' · ');
}

function buildProgressMeta(total, index, file) {
  const bits = [];
  const totalNum = Number(total) || 0;
  const idxNum = Number(index) || 0;
  if (totalNum > 0) bits.push(`${Math.max(idxNum, 0)}/${totalNum}`);
  if (file) bits.push(file);
  return bits.join(' · ');
}
