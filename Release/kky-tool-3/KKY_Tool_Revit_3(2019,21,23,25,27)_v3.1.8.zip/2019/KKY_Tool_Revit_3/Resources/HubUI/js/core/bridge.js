﻿// Resources/HubUI/js/core/bridge.js
// 공개 API: post, onHost, setConn, ping
// - WebView2(Revit) : window.chrome.webview.postMessage
// - DEV(브라우저 단독) : 간단 목업 동작
//
// 변경점
// 1) 웹→호스트 송신을 { ev, payload, __seq } 로 교정  ←★ 중요
// 2) DEV/명시적 토글에서만 상세 로깅: in/out 이벤트, payload 크기(B), 에러 message/stack 출력
// 3) onHost 두 형태 지원: onHost('ev', handler) + onHost((msg)=>{ev,payload})
// 4) 왕복 시간(ms) 표기: 호스트가 __seq를 되돌려주면 측정됨

import { log } from './dom.js';

export let DEV = false;

const VIEW_TEMPLATE_OWNERSHIP_TARGET_KIND = 'view3d-template-workset-v2';
const LEVEL_GRID_OWNERSHIP_TARGET_KIND = 'level-grid-userworkset-v2';
const EXISTING_CENTRAL_OWNERSHIP_TARGET_KIND = 'existing-central-delta-v1';
let __devCentralWorksetExportMode = 'centralize';
const LEVEL_GRID_OWNERSHIP_WORKSET_NAME = 'Shared Levels and Grids';

const hasWebView =
    typeof window !== "undefined" &&
    window.chrome &&
    window.chrome.webview &&
    typeof window.chrome.webview.postMessage === "function";

DEV = !hasWebView;

// -----------------------------
// 내부: 리스너 풀
// -----------------------------
const _byName = new Map();   // ev -> Set<fn(payload)>
const _generic = new Set();  // Set<fn({ ev, payload })>
const _scopedUnsubscribers = new Map(); // scope -> Set<unsubscribe>
let _activeListenerScope = null;

// -----------------------------
// 상세 로깅 / 측정
// -----------------------------
// WebView 배포 환경에서는 payload 전체 직렬화/Blob 생성 비용을 기본적으로 내지 않는다.
// 브라우저 DEV에서는 기존처럼 켜며, 배포 중 진단이 필요하면 Shift+F12로 명시적으로 토글한다.
let VERBOSE = DEV;
let __seq = 0;
const __pending = new Map(); // seq -> { ev, t0 }
const PENDING_TTL_MS = 5 * 60 * 1000;

function _prunePending(now = performance.now()) {
    for (const [seq, item] of __pending) {
        if (!item || now - Number(item.t0 || 0) > PENDING_TTL_MS) __pending.delete(seq);
    }
}

function _sizeOf(obj) {
    try { return new Blob([JSON.stringify(obj)]).size; } catch { return 0; }
}
function _logIn(ev, payload, extra = "") {
    if (!VERBOSE) return;
    const sz = _sizeOf(payload);
    log(`[bridge] ← in ${ev}${extra} (${sz}B)`, payload);
}
function _logOut(ev, payload) {
    if (!VERBOSE) return;
    const sz = _sizeOf(payload);
    log(`[bridge] → out ${ev} (${sz}B)`, payload);
}
function _logErr(ctx, err) {
    const msg = err && err.message ? err.message : String(err);
    const stk = err && err.stack ? `\n${err.stack}` : '';
    console.error(`[bridge] ${ctx} error: ${msg}${stk}`, err);
}

// Shift+F12 → 상세로그 토글
window.addEventListener('keydown', (e) => {
    if (e.key === 'F12' && e.shiftKey) {
        VERBOSE = !VERBOSE;
        if (!VERBOSE) __pending.clear();
        console.log(`[bridge] verbose ${VERBOSE ? "ON" : "OFF"}`);
    }
});

window.addEventListener('message', (event) => {
    const data = event?.data;
    if (!data || typeof data !== 'object') return;
    if (data.type !== 'kky:host-forward' || !data.ev) return;
    _emitHost(String(data.ev), data.payload || {}, data.meta || {});
});

// -----------------------------
// 내부: 호스트 메시지 브로드캐스트
// -----------------------------
function _emitHost(ev, payload, meta) {
    // 왕복 시간 표기(호스트가 __seq를 반사하는 경우)
    let extra = "";
    const seq = meta?.__seq;
    if (seq && __pending.has(seq)) {
        const t0 = __pending.get(seq).t0;
        const dt = (performance.now() - t0).toFixed(1);
        extra = ` [${dt}ms,#${seq}]`;
        __pending.delete(seq);
    }
    _logIn(ev, payload, extra);

    // 이름 기반
    const set = _byName.get(ev);
    if (set && set.size) {
        for (const fn of set) {
            try { fn(payload); }
            catch (e) { _logErr(`onHost("${ev}") handler`, e); }
        }
    }
    // 제네릭 기반
    if (_generic.size) {
        for (const fn of _generic) {
            try { fn({ ev, payload }); }
            catch (e) { _logErr("onHost(generic) handler", e); }
        }
    }
}

// -----------------------------
// 공개: onHost(handler) | onHost('ev', handler)
// -----------------------------
function _trackScopedUnsubscribe(unsubscribe) {
    if (!_activeListenerScope || typeof unsubscribe !== "function") return unsubscribe;

    const scope = _activeListenerScope;
    if (!_scopedUnsubscribers.has(scope)) _scopedUnsubscribers.set(scope, new Set());

    let done = false;
    const scopedUnsubscribe = () => {
        if (done) return;
        done = true;
        try { unsubscribe(); }
        finally { _scopedUnsubscribers.get(scope)?.delete(scopedUnsubscribe); }
    };

    _scopedUnsubscribers.get(scope).add(scopedUnsubscribe);
    return scopedUnsubscribe;
}

export function beginHostListenerScope(scope) {
    const key = String(scope || "").trim();
    if (!key) {
        _activeListenerScope = null;
        return;
    }

    clearHostListenerScope(key);
    _activeListenerScope = key;
}

export function endHostListenerScope(scope) {
    const key = String(scope || "").trim();
    if (!key || _activeListenerScope === key) _activeListenerScope = null;
}

export function clearHostListenerScope(scope) {
    const key = String(scope || "").trim();
    if (!key) return;

    const unsubscribers = _scopedUnsubscribers.get(key);
    if (!unsubscribers || !unsubscribers.size) {
        _scopedUnsubscribers.delete(key);
        return;
    }

    for (const unsubscribe of Array.from(unsubscribers)) {
        try { unsubscribe(); }
        catch (e) { _logErr(`clearHostListenerScope("${key}")`, e); }
    }
    _scopedUnsubscribers.delete(key);
}

export function onHost(arg1, arg2) {
    // onHost((msg)=>{})
    if (typeof arg1 === "function" && !arg2) {
        _generic.add(arg1);
        return _trackScopedUnsubscribe(() => _generic.delete(arg1));
    }
    // onHost('ev', handler)
    const ev = String(arg1 || "");
    const handler = arg2;
    if (!ev || typeof handler !== "function") return () => { };
    if (!_byName.has(ev)) _byName.set(ev, new Set());
    _byName.get(ev).add(handler);
    return _trackScopedUnsubscribe(() => _byName.get(ev)?.delete(handler));
}

// -----------------------------
// 공개: post(ev, payload) — ★ 호스트로 ev 키로 보냄
// -----------------------------
export function post(ev, payload = {}) {
    _logOut(ev, payload);

    const seq = ++__seq;
    if (VERBOSE) {
        _prunePending();
        __pending.set(seq, { ev, t0: performance.now() });
    }

    if (!DEV) {
        try {
            // 호스트가 __seq를 그대로 실어 응답(ev/payload)와 함께 돌려주면 왕복시간 측정 가능
            window.chrome.webview.postMessage({ ev, payload, __seq: seq });
            return true;
        } catch (e) {
            __pending.delete(seq);
            _logErr(`post("${ev}")`, e);
            _emitHost("host:error", {
                message: "Revit으로 요청을 보내지 못했습니다.",
                detail: e?.message || String(e),
                sourceEvent: String(ev || "")
            }, {});
            return false;
        }
    }

    // === DEV 목업 ===
    switch (ev) {
        case "ui:toggle-topmost": {
            __devTopMost = !__devTopMost;
            _emitHost("host:topmost", { on: __devTopMost }, { __seq: seq });
            break;
        }
        case "ui:open-external": {
            try {
                const url = payload && payload.url ? String(payload.url) : "";
                if (url) window.open(url, "_blank", "noopener,noreferrer");
            } catch (e) {
                _logErr('post("ui:open-external")', e);
            }
            break;
        }
        case "dup:run": {
            const rows = [
                { id: "12345", category: "Pipes", family: "Pipe Fitting", type: "Elbow - 90deg", groupId: 1, connectedCount: 2, connectedIds: "12346,12347", candidate: true },
                { id: "20011", category: "Pipes", family: "Pipe", type: "DN50", groupId: 1, connectedCount: 1, connectedIds: "20012", candidate: false },
            ];
            _emitHost("dup:list", { data: rows }, { __seq: seq });
            break;
        }
        case "duplicate:export": {
            _emitHost("dup:exported", { path: "C:\\Temp\\duplicate.xlsx" }, { __seq: seq });
            break;
        }
        case "connector:run": {
            const rows = [
                {
                    Id1: 101, Id2: 102, Category1: "Pipe", Category2: "Pipe", Family1: "Pipe", Family2: "Pipe",
                    "Distance (inch)": 0.12, ConnectionType: "Butt", ParamName: "System Type",
                    Value1: "Domestic Cold Water", Value2: "Domestic Cold Water", Status: "OK"
                },
            ];
            _emitHost("connector:done", { rows }, { __seq: seq });
            break;
        }
        case "export:preview": {
            const rows = [
                {
                    File: "Sample_A.rvt", "ProjectPoint_E(mm)": 100.0, "ProjectPoint_N(mm)": 200.0, "ProjectPoint_Z(mm)": 0.0,
                    "SurveyPoint_E(mm)": 110.0, "SurveyPoint_N(mm)": 210.0, "SurveyPoint_Z(mm)": 5.0,
                    "InternalOrigin_E(mm)": 105.0, "InternalOrigin_N(mm)": 205.0, "InternalOrigin_Z(mm)": 2.5,
                    "TrueNorthAngle(deg)": 23.5
                },
            ];
            _emitHost("export:previewed", { rows }, { __seq: seq });
            break;
        }
        case "export:save-excel": {
            _emitHost("export:saved", { path: "C:\\Temp\\points.xlsx" }, { __seq: seq });
            break;
        }
        case "paramprop:run": {
            _emitHost("paramprop:done", { ok: true, status: "succeeded", message: "(DEV) 완료" }, { __seq: seq });
            _emitHost("paramprop:report", { report: "(DEV) 완료" }, { __seq: seq });
            break;
        }
        case "sharedparam:status": {
            _emitHost("sharedparam:status", {
                status: "ok",
                statusLabel: "연결됨",
                path: "C:\\Sample\\SharedParameters.txt",
                warning: ""
            }, { __seq: seq });
            break;
        }
        case "sharedparam:list": {
            _emitHost("sharedparam:list", {
                ok: true,
                message: "",
                items: [
                    { name: "Comments", guid: "11111111-1111-1111-1111-111111111111", groupName: "Text", dataTypeToken: "Text" },
                    { name: "Mark", guid: "22222222-2222-2222-2222-222222222222", groupName: "Identity", dataTypeToken: "Text" },
                    { name: "Type Comments", guid: "33333333-3333-3333-3333-333333333333", groupName: "Text", dataTypeToken: "Text" },
                    { name: "System Abbreviation", guid: "44444444-4444-4444-4444-444444444444", groupName: "MEP", dataTypeToken: "Text" }
                ]
            }, { __seq: seq });
            break;
        }
        case "hub:pick-rvt": {
            _emitHost("hub:rvt-picked", {
                paths: ["C:\\Sample\\HQ-MEP-A.rvt", "C:\\Sample\\HQ-MEP-B.rvt"]
            }, { __seq: seq });
            break;
        }
        case "hub:pick-rvt-folder": {
            _emitHost("hub:rvt-picked", {
                paths: ["C:\\Sample\\HQ-MEP-C.rvt", "C:\\Sample\\HQ-MEP-OLD.rvt"]
            }, { __seq: seq });
            break;
        }
        case "familylink:init": {
            _emitHost("familylink:sharedparams", {
                sourcePath: "C:\\Sample\\SharedParameters.txt",
                items: [
                    { name: "PARAM_A", guid: "11111111-1111-1111-1111-111111111111", groupName: "GroupA", dataTypeToken: "Text" },
                    { name: "PARAM_B", guid: "22222222-2222-2222-2222-222222222222", groupName: "GroupB", dataTypeToken: "Length" }
                ]
            }, { __seq: seq });
            break;
        }
        case "familylink:pick-rvts": {
            _emitHost("familylink:rvts-picked", { paths: ["C:\\Sample\\ProjectA.rvt", "C:\\Sample\\ProjectB.rvt"] }, { __seq: seq });
            break;
        }
        case "familylink:run": {
            _emitHost("familylink:progress", { percent: 25, message: "(DEV) 스캔 중입니다." }, { __seq: seq });
            _emitHost("familylink:result", {
                schema: ["ProjectPath", "HostFamilyName", "HostFamilyCategory", "NestedFamilyName", "NestedTypeName", "NestedCategory", "TargetParamName", "ExpectedGuid", "FoundScope", "NestedParamGuid", "NestedParamDataType", "AssocHostParamName", "HostParamGuid", "HostParamIsShared", "Issue", "Notes"],
                rows: [
                    {
                        ProjectPath: "C:\\Sample\\ProjectA.rvt",
                        HostFamilyName: "HostA",
                        HostFamilyCategory: "Generic Model",
                        NestedFamilyName: "NestedA",
                        NestedTypeName: "Type01",
                        NestedCategory: "Generic Model",
                        TargetParamName: "PARAM_A",
                        ExpectedGuid: "11111111-1111-1111-1111-111111111111",
                        FoundScope: "InstanceParam",
                        NestedParamGuid: "11111111-1111-1111-1111-111111111111",
                        NestedParamDataType: "Text",
                        AssocHostParamName: "PARAM_A",
                        HostParamGuid: "11111111-1111-1111-1111-111111111111",
                        HostParamIsShared: "True",
                        Issue: "OK",
                        Notes: ""
                    }
                ]
            }, { __seq: seq });
            break;
        }
        case "familylink:export": {
            _emitHost("familylink:exported", { ok: true, path: "C:\\Temp\\FamilyLinkAudit.xlsx" }, { __seq: seq });
            break;
        }
        case "scheduleio:init": {
            _emitHost("scheduleio:init", {
                ok: true,
                activeDocument: { name: "Project1", path: "C:\\Sample\\Project1.rvt", canUse: true, isWorkshared: true }
            }, { __seq: seq });
            break;
        }
        case "scheduleio:load-active-schedules": {
            _emitHost("scheduleio:schedules-loaded", {
                ok: true,
                catalog: {
                    sourceKind: "active",
                    sourcePath: "C:\\Sample\\Project1.rvt",
                    sourceName: "Project1.rvt",
                    schedules: [
                        { id: 9101, name: "MEP Equipment Schedule", fieldCount: 8 },
                        { id: 9102, name: "Pipe Accessories Schedule", fieldCount: 11 }
                    ]
                }
            }, { __seq: seq });
            break;
        }
        case "scheduleio:pick-source-rvt": {
            _emitHost("scheduleio:schedules-loaded", {
                ok: true,
                catalog: {
                    sourceKind: "file",
                    sourcePath: "C:\\Sample\\Schedule_Master.rvt",
                    sourceName: "Schedule_Master.rvt",
                    schedules: [
                        { id: 9201, name: "Equipment Export", fieldCount: 10 },
                        { id: 9202, name: "Support Export", fieldCount: 7 }
                    ]
                }
            }, { __seq: seq });
            break;
        }
        case "scheduleio:pick-target-rvts": {
            _emitHost("scheduleio:targets-picked", {
                ok: true,
                paths: ["C:\\Sample\\Area_A.rvt", "C:\\Sample\\Area_B.rvt"]
            }, { __seq: seq });
            break;
        }
        case "scheduleio:pick-workbook":
        case "scheduleio:read-workbook": {
            _emitHost("scheduleio:workbook-loaded", {
                ok: true,
                catalog: {
                    path: "C:\\Sample\\KKY_Schedule_Export.xlsx",
                    fileName: "KKY_Schedule_Export.xlsx",
                    sheets: [
                        {
                            name: "MEP Equipment Schedule",
                            rowCount: 18,
                            headers: [
                                "RVT File",
                                "Host RVT File",
                                "KKY Source Kind",
                                "KKY Import Policy",
                                "Element ID",
                                "Linked Element ID",
                                "Family",
                                "Type",
                                "Category",
                                "Comments",
                                "Mark"
                            ]
                        },
                        {
                            name: "Pipe Accessories Schedule",
                            rowCount: 12,
                            headers: [
                                "RVT File",
                                "Host RVT File",
                                "KKY Source Kind",
                                "KKY Import Policy",
                                "Element ID",
                                "Linked Element ID",
                                "Family",
                                "Type",
                                "Category",
                                "Comments",
                                "System Abbreviation"
                            ]
                        }
                    ]
                }
            }, { __seq: seq });
            break;
        }
        case "scheduleio:inspect-import": {
            _emitHost("scheduleio:inspection-done", {
                ok: true,
                targetKind: payload?.targetKind || "active",
                result: {
                    instanceParameters: ["Comments", "Mark", "System Abbreviation"],
                    typeParameters: ["Type Comments", "Type Mark"],
                    matchedRows: 28,
                    missingElements: 0,
                    identityMismatches: 0,
                    blockedLinkedRows: 2,
                    targetFiles: payload?.targetKind === "batch" ? 2 : 1,
                    message: "(DEV) Import 대상 파라미터를 확인했습니다. 링크 문서 행 2개는 Import 대상에서 제외했습니다."
                }
            }, { __seq: seq });
            break;
        }
        case "scheduleio:export-active":
        case "scheduleio:export-batch": {
            const targetFiles = ev.endsWith("batch") ? 2 : 1;
            const extractionMode = payload?.extractionMode === "schedule"
                ? "schedule"
                : (payload?.extractionMode === "all" ? "all" : "elements");
            const rowLabel = extractionMode === "schedule"
                ? "표시 행"
                : (extractionMode === "all" ? "전체 대상 객체" : "객체");
            const includeLinkedRows = extractionMode === "all" && payload?.includeLinks === true;
            const linkedRowCount = includeLinkedRows ? 6 : 0;
            const processedRows = 30 + linkedRowCount;
            const linkedMessage = includeLinkedRows
                ? ` 로드된 Revit 링크에서 ${linkedRowCount}개 객체를 포함했으며 링크 행은 Import에서 제외됩니다.`
                : "";
            _emitHost("scheduleio:progress", { title: "Schedule Excel Export", percent: 55, message: "(DEV) 스케줄 데이터를 추출하는 중입니다." }, { __seq: seq });
            _emitHost("scheduleio:export-prepared", {
                ok: true,
                targetKind: targetFiles > 1 ? "batch" : "active",
                extractionMode,
                exportToken: targetFiles > 1 ? "dev-schedule-batch" : "dev-schedule-active",
                result: {
                    ok: true,
                    message: `(DEV) 대상 ${targetFiles}개에서 ${processedRows}개 ${rowLabel}를 추출했습니다.${linkedMessage} 결과에서 엑셀 내보내기를 선택하세요.`,
                    targetFiles,
                    processedRows,
                    changedValues: 0,
                    skippedRows: 0,
                    failedRows: 0
                }
            }, { __seq: seq });
            break;
        }
        case "scheduleio:save-export": {
            const folderOutput = payload?.outputMode === "files";
            const batch = String(payload?.exportToken || "").includes("batch");
            _emitHost("scheduleio:export-saved", {
                ok: true,
                targetKind: batch ? "batch" : "active",
                exportToken: payload?.exportToken || "",
                result: {
                    ok: true,
                    message: folderOutput ? "(DEV) RVT별 Excel 저장을 완료했습니다." : "(DEV) 통합 Excel 저장을 완료했습니다.",
                    outputPath: folderOutput ? "" : "C:\\Temp\\KKY_Schedule_Export.xlsx",
                    outputFolder: "C:\\Temp",
                    outputKind: folderOutput ? "folder" : "workbook",
                    outputFiles: folderOutput
                        ? ["C:\\Temp\\Area_A_Schedule_Export.xlsx", "C:\\Temp\\Area_B_Schedule_Export.xlsx"]
                        : ["C:\\Temp\\KKY_Schedule_Export.xlsx"],
                    targetFiles: batch ? 2 : 1,
                    processedRows: 30,
                    changedValues: 0,
                    skippedRows: 0,
                    failedRows: 0
                }
            }, { __seq: seq });
            break;
        }
        case "scheduleio:open-output-folder":
            break;
        case "scheduleio:import-active":
        case "scheduleio:import-batch": {
            const targetFiles = ev.endsWith("batch") ? 2 : 1;
            _emitHost("scheduleio:progress", { title: "Schedule Excel Import", percent: 65, message: "(DEV) Revit 파라미터에 값을 입력하는 중입니다." }, { __seq: seq });
            _emitHost("scheduleio:import-done", {
                ok: true,
                targetKind: targetFiles > 1 ? "batch" : "active",
                result: {
                    ok: true,
                    message: `(DEV) 대상 ${targetFiles}개에 24개 값을 반영했습니다. 링크 문서 행 2개는 Import 대상에서 제외했습니다.`,
                    outputPath: "",
                    targetFiles,
                    processedRows: 30,
                    changedValues: 24,
                    skippedRows: 6,
                    blockedLinkedRows: 2,
                    failedRows: 0
                }
            }, { __seq: seq });
            break;
        }
        case "lateralnozzle:init": {
            _emitHost("lateralnozzle:init", {
                settings: { excelPaths: [], outputFolder: "" },
                result: null,
                rvtSettings: {
                    rvtPaths: [],
                    utilityParameterName: "UTILITY",
                    lateralParameterName: "LATERAL NO",
                    nozzleCodeParameterNames: ["NOZZLE CODE 01", "NOZZLE CODE 02"],
                    additionalParameterNames: ["SYSTEM ABBREVIATION", "LEVEL"]
                },
                rvtResult: null,
                comparisonState: {
                    hasRecentKtaResult: false,
                    hasRecentRvtResult: false,
                    ktaWorkbookPath: "",
                    rvtWorkbookPath: "",
                    result: null
                }
            }, { __seq: seq });
            break;
        }
        case "lateralnozzle:pick-excels": {
            _emitHost("lateralnozzle:excels-picked", {
                ok: true,
                paths: ["C:\\Sample\\KTA_Form_A.xlsx", "C:\\Sample\\KTA_Form_B.xlsx"]
            }, { __seq: seq });
            break;
        }
        case "lateralnozzle:run": {
            _emitHost("lateralnozzle:progress", { title: "노즐코드 KTA 단일화", percent: 35, message: "(DEV) 엑셀 읽는 중입니다.", detail: "KTA_Form_A.xlsx" }, { __seq: seq });
            _emitHost("lateralnozzle:done", {
                ok: true,
                message: "(DEV) 추출 완료: 6건 · 형식 진단 1건",
                outputFolder: "C:\\Temp",
                resultWorkbookPath: "",
                fileCount: 2,
                canExport: true,
                summary: {
                    totalFileCount: 2,
                    successCount: 1,
                    failCount: 1,
                    noDataCount: 0,
                    extractedRowCount: 6,
                    remarkRowCount: 1
                },
                files: [
                    {
                        filePath: "C:\\Sample\\KTA_Form_A.xlsx",
                        fileName: "KTA_Form_A.xlsx",
                        status: "Success",
                        sheetCount: 1,
                        recognizedSheetCount: 1,
                        headerFailureCount: 0,
                        extractedRowCount: 6,
                        remarkRowCount: 1,
                        message: "1개 시트에서 6건 추출",
                        sheets: [{
                            sheetName: "KTA",
                            status: "Success",
                            usedRange: "A1:D8",
                            headerBlockCount: 1,
                            extractedRowCount: 6,
                            message: "헤더 블록 1개 인식, 6건 추출"
                        }]
                    },
                    {
                        filePath: "C:\\Sample\\KTA_Form_B.xlsx",
                        fileName: "KTA_Form_B.xlsx",
                        status: "Fail",
                        sheetCount: 1,
                        recognizedSheetCount: 0,
                        headerFailureCount: 1,
                        extractedRowCount: 0,
                        remarkRowCount: 0,
                        message: "1개 시트에서 KTA 헤더 블록을 인식하지 못했습니다. 시트별 형식 진단을 확인해 주세요.",
                        sheets: [{
                            sheetName: "노즐목록",
                            status: "HeaderNotFound",
                            usedRange: "A1:C22",
                            headerBlockCount: 0,
                            extractedRowCount: 0,
                            message: "KTA 헤더 블록 인식 실패. 검색 범위 A1:C22. 누락 헤더: No. 발견: UT명=A1=\"UTILITY\" / 배관No=B1=\"LATERAL NO\" / Nozzle Code=C1=\"Nozzle Code\". 인식 표기: UT명/UTILITY, 배관No/배관번호/LATERAL NO, Nozzle Code, No/No."
                        }]
                    }
                ]
            }, { __seq: seq });
            break;
        }
        case "lateralnozzle:export": {
            _emitHost("lateralnozzle:exported", {
                ok: true,
                path: "C:\\Temp\\노즐코드_KTA_단일화.xlsx",
                excelMode: "normal"
            }, { __seq: seq });
            break;
        }
        case "lateralnozzle:rvt-pick-files": {
            _emitHost("lateralnozzle:rvt-files-picked", {
                ok: true,
                paths: ["C:\\Sample\\UTILITY_A.rvt", "C:\\Sample\\UTILITY_B.rvt"]
            }, { __seq: seq });
            break;
        }
        case "lateralnozzle:rvt-run": {
            _emitHost("lateralnozzle:rvt-progress", {
                title: "RVT Nozzle 정보 추출",
                percent: 55,
                message: "(DEV) 파이프 피팅과 악세사리의 Nozzle 파라미터를 읽는 중입니다.",
                detail: "UTILITY_A.rvt"
            }, { __seq: seq });
            _emitHost("lateralnozzle:rvt-done", {
                ok: true,
                message: "(DEV) RVT Nozzle 정보 7행을 추출했습니다.",
                outputFolder: "C:\\Temp",
                resultWorkbookPath: "",
                fileCount: 2,
                canExport: true,
                additionalParameterNames: Array.isArray(payload?.additionalParameterNames) ? payload.additionalParameterNames : [],
                additionalParameterCount: Array.isArray(payload?.additionalParameterNames) ? payload.additionalParameterNames.length : 0,
                additionalFamilyOrTypeKeywords: Array.isArray(payload?.additionalFamilyOrTypeKeywords) ? payload.additionalFamilyOrTypeKeywords : [],
                additionalKeywordCount: Array.isArray(payload?.additionalFamilyOrTypeKeywords) ? payload.additionalFamilyOrTypeKeywords.length : 0,
                summary: {
                    totalFileCount: 2,
                    successCount: 2,
                    failCount: 0,
                    noDataCount: 0,
                    candidateCount: 42,
                    filterParameterFoundCount: 40,
                    missingFilterParameterCount: 2,
                    nozzleObjectCount: 5,
                    extractedRowCount: 7,
                    missingUtilityCount: 0,
                    missingLateralCount: 1,
                    missingNozzleCodeCount: 0,
                    missingCoordinateCount: 0,
                    coordinateFallbackCount: 0,
                    ambiguousParameterCount: 1,
                    remarkRowCount: 2
                },
                files: [
                    {
                        filePath: "C:\\Sample\\UTILITY_A.rvt",
                        fileName: "UTILITY_A.rvt",
                        status: "Success",
                        candidateCount: 24,
                        filterParameterFoundCount: 23,
                        missingFilterParameterCount: 1,
                        nozzleObjectCount: 3,
                        extractedRowCount: 5,
                        missingUtilityCount: 0,
                        missingLateralCount: 0,
                        missingNozzleCodeCount: 0,
                        missingCoordinateCount: 0,
                        coordinateFallbackCount: 0,
                        ambiguousParameterCount: 0,
                        coordinateSystem: "공유좌표(mm)",
                        projectLocationName: "Shared Site",
                        projectPositionSummary: "E=125000mm, N=340000mm, EL=0mm, Angle=0deg",
                        message: "대상 24개 / NOZZLE 객체 3개 / 매핑 결과 5행 / 'NOZZLE VALVE' 파라미터 누락 1개 / 공유좌표(mm)"
                    },
                    {
                        filePath: "C:\\Sample\\UTILITY_B.rvt",
                        fileName: "UTILITY_B.rvt",
                        status: "Success",
                        candidateCount: 18,
                        filterParameterFoundCount: 17,
                        missingFilterParameterCount: 1,
                        nozzleObjectCount: 2,
                        extractedRowCount: 2,
                        missingUtilityCount: 0,
                        missingLateralCount: 1,
                        missingNozzleCodeCount: 0,
                        missingCoordinateCount: 0,
                        coordinateFallbackCount: 0,
                        ambiguousParameterCount: 1,
                        coordinateSystem: "공유좌표(mm)",
                        projectLocationName: "Shared Site",
                        projectPositionSummary: "E=125000mm, N=340000mm, EL=0mm, Angle=0deg",
                        message: "대상 18개 / NOZZLE 객체 2개 / 매핑 결과 2행 / 'NOZZLE VALVE' 파라미터 누락 1개 / LATERAL 누락 1건 / 중복 이름 파라미터 충돌 1건"
                    }
                ]
            }, { __seq: seq });
            break;
        }
        case "lateralnozzle:rvt-export": {
            _emitHost("lateralnozzle:rvt-exported", {
                ok: true,
                path: "C:\\Temp\\RVT_Nozzle_정보_추출.xlsx",
                excelMode: "normal"
            }, { __seq: seq });
            break;
        }
        case "lateralnozzle:compare-pick-kta": {
            _emitHost("lateralnozzle:compare-kta-picked", {
                ok: true,
                path: "C:\\Sample\\노즐코드_KTA_단일화.xlsx"
            }, { __seq: seq });
            break;
        }
        case "lateralnozzle:compare-pick-rvt": {
            _emitHost("lateralnozzle:compare-rvt-picked", {
                ok: true,
                path: "C:\\Sample\\RVT_Nozzle_정보_추출.xlsx"
            }, { __seq: seq });
            break;
        }
        case "lateralnozzle:compare-invalidate": {
            break;
        }
        case "lateralnozzle:compare-run": {
            _emitHost("lateralnozzle:compare-done", {
                ok: true,
                message: "(DEV) KTA와 RVT 결과 비교를 완료했습니다.",
                resultWorkbookPath: "",
                canExport: true,
                totalComparisonRowCount: 6,
                summary: {
                    ktaRowCount: 8,
                    rvtRowCount: 9,
                    rvtObjectCount: 7,
                    matchedQuantity: 5,
                    quantityMismatchKeyCount: 1,
                    attributeMismatchCount: 1,
                    ktaOnlyKeyCount: 1,
                    rvtOnlyKeyCount: 1,
                    ktaDuplicateKeyCount: 1,
                    rvtDuplicateKeyCount: 1,
                    reviewCandidateMatchCount: 1,
                    incompleteRowCount: 1,
                    spatialSequenceGroupCount: 4,
                    spatialSequenceNormalCount: 1,
                    spatialSequenceSuspectedCount: 1,
                    spatialSequenceDeferredCount: 1,
                    spatialSequenceInsufficientCount: 1,
                    spatialSequenceDuplicateNumberGroupCount: 1,
                    spatialSequenceMissingNumberGroupCount: 1
                },
                previewRows: [
                    { statusLabel: "일치", utility: "UT-01", lateralNo: "L-001", nozzleCode: "NZ-A_001", ktaCount: 1, rvtCount: 1, matchedCount: 1, diagnosis: "수량과 속성 일치", ktaFileName: "KTA_Form_A.xlsx", ktaSheet: "KTA", ktaRowCell: "C12:F12", rvtFileName: "UTILITY_A.rvt", rvtElementId: "1101", rvtCategory: "Pipe Accessories", rvtFamily: "SPECIAL-NOZZLE", rvtType: "TYPE-A" },
                    { statusLabel: "수량 불일치", utility: "UT-01", lateralNo: "L-002", nozzleCode: "NZ-A_002", ktaCount: 2, rvtCount: 1, matchedCount: 1, diagnosis: "KTA 1건 초과", ktaFileName: "KTA_Form_A.xlsx | KTA_Form_B.xlsx", ktaSheet: "KTA | KTA", ktaRowCell: "C18:F18 | C9:F9", rvtFileName: "UTILITY_A.rvt", rvtElementId: "1102", rvtCategory: "Pipe Accessories", rvtFamily: "SPECIAL-NOZZLE", rvtType: "TYPE-B" },
                    { statusLabel: "속성 불일치", utility: "UT-02 ↔ UT-03", lateralNo: "L-003", nozzleCode: "NZ-A_003", ktaCount: 1, rvtCount: 1, matchedCount: 0, diagnosis: "동일 코드, UTILITY 불일치", ktaFileName: "KTA_Form_A.xlsx", ktaSheet: "KTA", ktaRowCell: "C24:F24", rvtFileName: "UTILITY_A.rvt", rvtElementId: "1103", rvtCategory: "Pipe Fittings", rvtFamily: "NOZZLE-ELBOW", rvtType: "TYPE-C" },
                    { statusLabel: "KTA만", utility: "UT-04", lateralNo: "L-004", nozzleCode: "NZ-A_004", ktaCount: 1, rvtCount: 0, matchedCount: 0, diagnosis: "RVT 본 결과에는 없고 검토 후보에서 발견", ktaFileName: "KTA_Form_A.xlsx", ktaSheet: "KTA", ktaRowCell: "C31:F31", rvtFileName: "", rvtElementId: "", rvtCategory: "", rvtFamily: "", rvtType: "" },
                    { statusLabel: "RVT만", utility: "UT-05", lateralNo: "L-005", nozzleCode: "NZ-A_005", ktaCount: 0, rvtCount: 1, matchedCount: 0, diagnosis: "KTA 단일화 결과에 없음", ktaFileName: "", ktaSheet: "", ktaRowCell: "", rvtFileName: "UTILITY_B.rvt", rvtElementId: "2201", rvtCategory: "Pipe Accessories", rvtFamily: "SPECIAL-NOZZLE", rvtType: "TYPE-D" }
                ],
                diagnostics: [
                    "(DEV) 구버전 KTA 결과는 원본 파일·시트·행 위치가 없을 수 있습니다.",
                    "[순서 이상 의심] UTILITY_A.rvt / UT-01 / L-001 / NZ-A: 공간 순서 [NZ-A_001 → NZ-A_003 → NZ-A_002]"
                ]
            }, { __seq: seq });
            break;
        }
        case "lateralnozzle:compare-export": {
            _emitHost("lateralnozzle:compare-exported", {
                ok: true,
                path: "C:\\Temp\\KTA_RVT_Nozzle_비교.xlsx",
                excelMode: "normal"
            }, { __seq: seq });
            break;
        }
        case "linksharedcoord:init": {
            _emitHost("linksharedcoord:context", __devLinkSharedCoordContext(), { __seq: seq });
            break;
        }
        case "linksharedcoord:analyze": {
            _emitHost("linksharedcoord:analyzed", __devLinkSharedCoordAnalysis(payload), { __seq: seq });
            break;
        }
        case "linksharedcoord:apply": {
            _emitHost("linksharedcoord:applied", {
                ...__devLinkSharedCoordAnalysis(payload),
                ok: true,
                analysisToken: payload?.analysisToken || "dev-sharedcoord-1",
                message: "(DEV) 호스트 링크 인스턴스에 분석된 이동·회전을 적용했습니다."
            }, { __seq: seq });
            break;
        }
        case "linksharedcoord:publish": {
            _emitHost("linksharedcoord:published", {
                ok: true,
                cancelled: false,
                published: true,
                linkPositionsSaved: true,
                analysisToken: payload?.analysisToken || "dev-sharedcoord-1",
                projectLocationName: payload?.targetProjectLocationName || "A동_A1",
                message: "(DEV) Shared Site Publish와 링크 파일 저장을 완료했습니다."
            }, { __seq: seq });
            break;
        }
        case "linksharedcoord:batch-pick-rvts": {
            _emitHost("linksharedcoord:batch-rvts-picked", { paths: ["C:\\Sample\\HOST_A.rvt", "C:\\Sample\\HOST_B.rvt"] }, { __seq: seq });
            break;
        }
        case "linksharedcoord:batch-pick-excel": {
            _emitHost("linksharedcoord:batch-excel-picked", { path: "C:\\Temp\\LinkSharedCoord_Review.xlsx" }, { __seq: seq });
            break;
        }
        case "linksharedcoord:batch-scan": {
            const rows = __devLinkSharedCoordBatchRows(false);
            _emitHost("linksharedcoord:batch-rows", { ok: true, source: "scan", applyReady: false, datasetToken: "", rows, summary: { hostCount: 2, rowCount: rows.length, errorCount: 1 } }, { __seq: seq });
            break;
        }
        case "linksharedcoord:batch-export": {
            _emitHost("linksharedcoord:batch-exported", { ok: true, path: "C:\\Temp\\LinkSharedCoord_Review.xlsx" }, { __seq: seq });
            break;
        }
        case "linksharedcoord:batch-export-template": {
            _emitHost("linksharedcoord:batch-template-exported", {
                ok: true,
                path: "C:\\Temp\\LinkSharedCoord_Template.xlsx"
            }, { __seq: seq });
            break;
        }
        case "linksharedcoord:batch-import": {
            const rows = __devLinkSharedCoordBatchRows(true);
            _emitHost("linksharedcoord:batch-rows", { ok: true, source: "import", applyReady: true, datasetToken: "dev-linksharedcoord-dataset-1", workbookPath: payload?.path || "C:\\Temp\\LinkSharedCoord_Review.xlsx", rows, summary: { hostCount: 2, rowCount: rows.length, errorCount: 1 } }, { __seq: seq });
            break;
        }
        case "linksharedcoord:batch-apply": {
            const rows = __devLinkSharedCoordBatchRows(true).map((row) => row.Action === "APPLY" ? { ...row, ApplyStatus: "CHANGED", ApplyMessage: "(DEV) 호스트 배치를 적용했습니다." } : row);
            _emitHost("linksharedcoord:batch-applied", { ok: true, applyReady: false, datasetToken: "", rows, summary: { hostCount: 2, rowCount: rows.length, changedCount: 1, errorCount: 1 } }, { __seq: seq });
            break;
        }
        case "acccloud:init": {
            _emitHost("acccloud:context", {
                ok: true,
                revitMajor: 2025,
                supportedMajor: true,
                supportState: "SUPPORTED",
                supportMessage: "Revit 2025: ACC Cloud Workshared 생성 지원 (DEV)",
                revitLoginUsername: "DEV.AUTODESK.USER",
                workbookPath: "",
                resultWorkbookPath: "",
                trustedResultCount: __devAccCloudTrustedRows.size,
                blockedTargetKeys: [...__devAccCloudBlockedTargetKeys],
                rows: []
            }, { __seq: seq });
            break;
        }
        case "acccloud:pick-rvts": {
            _emitHost("acccloud:rvts-picked", {
                ok: true,
                paths: [
                    "C:\\Sample\\Campus_Seed.rvt",
                    "C:\\Sample\\Plant_Seed.rvt"
                ],
                rows: [
                    __devAccCloudRow("C:\\Sample\\Campus_Seed.rvt", 0),
                    __devAccCloudRow("C:\\Sample\\Plant_Seed.rvt", 1)
                ]
            }, { __seq: seq });
            break;
        }
        case "acccloud:export-template": {
            _emitHost("acccloud:template-exported", {
                ok: true,
                path: "C:\\Temp\\KKY_ACC_Cloud_Jobs.xlsx",
                message: "(DEV) ACC 전용 Excel 양식을 저장했습니다."
            }, { __seq: seq });
            break;
        }
        case "acccloud:export-results": {
            const requestRows = Array.isArray(payload?.rows) ? payload.rows : [];
            const trustedRows = [];
            const unmatchedRows = [];
            requestRows.forEach((row, index) => {
                const trusted = __devAccCloudTrustedRows.get(String(row?.rowId || '').toLowerCase());
                if (trusted && __devAccCloudRequestFingerprint(trusted) === __devAccCloudRequestFingerprint(row)) trustedRows.push(trusted);
                else unmatchedRows.push(index + 1);
            });
            if (!requestRows.length || unmatchedRows.length) {
                _emitHost("acccloud:error", {
                    ok: false,
                    message: "ACC 결과 저장 실패",
                    detail: `(DEV) ${unmatchedRows.join(', ') || '전체'}행의 Host 신뢰 결과가 없어 불완전한 batch 영수증을 저장하지 않습니다.`
                }, { __seq: seq });
                break;
            }
            _emitHost("acccloud:results-exported", {
                ok: true,
                path: "C:\\Temp\\KKY_ACC_Cloud_Results.xlsx",
                resultCount: trustedRows.length,
                omittedCount: 0,
                message: `(DEV) Host 신뢰 결과 ${trustedRows.length}개를 저장했습니다.`
            }, { __seq: seq });
            break;
        }
        case "acccloud:pick-workbook": {
            _emitHost("acccloud:workbook-picked", {
                ok: true,
                path: "C:\\Temp\\KKY_ACC_Cloud_Jobs.xlsx"
            }, { __seq: seq });
            break;
        }
        case "acccloud:import-workbook": {
            const workbookPath = String(payload?.path || "C:\\Temp\\KKY_ACC_Cloud_Jobs.xlsx");
            _emitHost("acccloud:rows", {
                ok: true,
                source: "workbook",
                workbookPath,
                rows: [
                    __devAccCloudRow("C:\\Sample\\Campus_Seed.rvt", 0, {
                        rowId: "dev-acc-campus-a",
                        modelName: "Campus_ARCHIVE_A.rvt",
                        folderId: "urn:adsk.wipprod:fs.folder:co.devFolderA",
                        addWorksets: ["Architecture", "Coordination"]
                    }),
                    __devAccCloudRow("C:\\Sample\\Campus_Seed.rvt", 1, {
                        rowId: "dev-acc-campus-b",
                        modelName: "Campus_ARCHIVE_B.rvt",
                        folderId: "urn:adsk.wipprod:fs.folder:co.devFolderB",
                        addWorksets: ["Architecture", "MEP"]
                    })
                ]
            }, { __seq: seq });
            break;
        }
        case "acccloud:run": {
            const rows = Array.isArray(payload?.rows) ? payload.rows : [];
            const blockedIndex = rows.findIndex((row) => String(row?.action || '').trim().toUpperCase() === 'APPLY' && __devAccCloudBlockedTargetKeys.has(__devAccCloudTargetKey(row)));
            if (blockedIndex >= 0) {
                _emitHost("acccloud:error", {
                    ok: false,
                    message: "ACC 클라우드 재실행 차단",
                    detail: `(DEV) ${blockedIndex + 1}행 target은 원격 생성됨/불확정 latch 상태입니다. 다른 target을 사용하세요.`
                }, { __seq: seq });
                break;
            }
            _emitHost("acccloud:progress", {
                percent: 18,
                message: `(DEV) ${rows.length}개 cloud target 사전 검증 중`
            }, { __seq: seq });
            setTimeout(() => {
                _emitHost("acccloud:progress", {
                    percent: 66,
                    message: "(DEV) SaveAsCloudModel 및 fresh-open 검증 중"
                }, { __seq: seq });
            }, 130);
            setTimeout(() => {
                const completedRows = rows.map((row, index) => ({
                    ...__devAccCloudRow(row?.sourcePath, index, row || {}),
                    status: "VERIFIED",
                    message: "(DEV) ACC Cloud Workshared 모델을 만들고 fresh-open 검증했습니다.",
                    cloudProjectGuid: String(row?.projectGuid || ""),
                    cloudModelGuid: `10000000-0000-0000-0000-${String(index + 1).padStart(12, '0')}`,
                    cloudRegion: String(row?.region || "US"),
                    cloudFolderId: String(row?.folderId || ""),
                    docsUrl: `https://acc.autodesk.com/docs/files/projects/${String(row?.projectGuid || "11111111-1111-1111-1111-111111111111")}`,
                    remoteCreated: true,
                    manualCleanupRequired: false,
                    persistenceState: "REMOTE_CREATED_VERIFIED",
                    verifiedFreshOpen: true,
                    existingWorksets: [],
                    createdWorksets: Array.isArray(row?.addWorksets) ? row.addWorksets : [],
                    skippedWorksets: []
                }));
                completedRows.forEach((row) => {
                    __devAccCloudTrustedRows.set(String(row.rowId || '').toLowerCase(), row);
                    __devAccCloudBlockedTargetKeys.add(__devAccCloudTargetKey(row));
                });
                _emitHost("acccloud:completed", {
                    ok: true,
                    rows: completedRows,
                    trustedResultCount: __devAccCloudTrustedRows.size,
                    blockedTargetKeys: [...__devAccCloudBlockedTargetKeys],
                    summary: {
                        totalCount: completedRows.length,
                        verifiedCount: completedRows.length,
                        failedCount: 0,
                        manualCleanupRequiredCount: 0
                    }
                }, { __seq: seq });
            }, 320);
            break;
        }
        case "centralworkset:init": {
            _emitHost("centralworkset:context", {
                activeDocument: {
                    name: "ACTIVE_MEP.rvt",
                    path: "C:\\Sample\\ACTIVE_MEP.rvt",
                    canUse: true,
                    isWorkshared: true,
                    isCentral: true,
                    isLocal: false
                },
                activeDocumentPolicyMessage: "원본 또는 2단계 출력이 현재 활성 문서이면 수정사항을 저장하고 문서를 닫은 뒤 strict detach 배치를 수행합니다. 원본이 센트럴이면 안전상 닫힌 상태로 유지하고, 로컬·일반 RVT 원본만 자동 재오픈합니다.",
                rows: [],
                workbookPath: ""
            }, { __seq: seq });
            break;
        }
        case "centralworkset:add-active": {
            _emitHost("centralworkset:active-added", {
                requestId: String(payload?.requestId || ""),
                row: __devCentralWorksetRow("C:\\Sample\\ACTIVE_MEP.rvt", 0, {
                    rowId: "dev-centralworkset-active",
                    sourceType: "central",
                    isWorkshared: true,
                    isCentral: true,
                    isLocal: false,
                    isOpen: true,
                    existingWorksets: ["Shared Levels and Grids", "Workset1", "MEP Links"]
                })
            }, { __seq: seq });
            break;
        }
        case "centralworkset:pick-rvts": {
            _emitHost("centralworkset:rvts-picked", {
                requestId: String(payload?.requestId || ""),
                paths: [
                    "C:\\Sample\\Campus_Central.rvt",
                    "C:\\Sample\\Campus_Local_kkyki.rvt",
                    "C:\\Sample\\Standalone_Model.rvt",
                    "C:\\Sample\\Unknown_Metadata.rvt"
                ]
            }, { __seq: seq });
            break;
        }
        case "centralworkset:inspect": {
            const paths = Array.isArray(payload?.paths) ? payload.paths : [];
            const requestId = String(payload?.requestId || "");
            _emitHost("centralworkset:progress", {
                requestId,
                percent: 32,
                message: "(DEV) RVT 종류와 현재 웍셋을 확인하는 중입니다.",
                detail: `${paths.length}개 파일`
            }, { __seq: seq });
            setTimeout(() => {
                _emitHost("centralworkset:rows", {
                    requestId,
                    source: "inspect",
                    rows: paths.map((path, index) => __devCentralWorksetRow(path, index,
                        String(path || "").toLowerCase().includes("unknown_metadata") ? {
                            missingConnectedCentral: true,
                            status: "warning",
                            message: "(DEV) RVT 기본 정보를 미리 읽지 못했습니다. 실행 시 Detach(Preserve)로 열어 실제 유형과 웍셋을 다시 판정합니다."
                        } : index === 1 ? {
                            missingConnectedCentral: true,
                            status: "warning",
                            message: "(DEV) 기존 연결 센트럴을 찾을 수 없습니다. 등록한 로컬/복사본 자체를 웍셋 유지 디태치하여 새 센트럴로 만들 수 있습니다."
                        } : {}))
                }, { __seq: seq });
            }, 180);
            break;
        }
        case "centralworkset:pick-common-folder": {
            _emitHost("centralworkset:common-folder-picked", {
                requestId: String(payload?.requestId || ""),
                folder: "C:\\Temp\\NewCentrals"
            }, { __seq: seq });
            break;
        }
        case "centralworkset:pick-row-output": {
            const sourcePath = String(payload?.sourcePath || "C:\\Sample\\Model.rvt");
            const sourceFileName = __devCentralWorksetFileName(sourcePath);
            _emitHost("centralworkset:row-output-picked", {
                requestId: String(payload?.requestId || ""),
                rowId: String(payload?.rowId || ""),
                sourcePath,
                path: `C:\\Temp\\NewCentrals\\${sourceFileName}`
            }, { __seq: seq });
            break;
        }
        case "centralworkset:export-template": {
            __devCentralWorksetExportMode = String(payload?.mode || 'centralize').trim().toLowerCase();
            _emitHost("centralworkset:template-exported", {
                requestId: String(payload?.requestId || ""),
                ok: true,
                path: "C:\\Temp\\CentralWorkset_Template.xlsx",
                message: "(DEV) Excel 양식을 저장했습니다."
            }, { __seq: seq });
            break;
        }
        case "centralworkset:pick-workbook": {
            _emitHost("centralworkset:workbook-picked", {
                requestId: String(payload?.requestId || ""),
                path: "C:\\Temp\\CentralWorkset_Template.xlsx"
            }, { __seq: seq });
            break;
        }
        case "centralworkset:import-workbook": {
            const workbookPath = String(payload?.path || "C:\\Temp\\CentralWorkset_Template.xlsx");
            const requestId = String(payload?.requestId || "");
            const operation = __devCentralWorksetExportMode === 'ownership'
                ? 'OWNERSHIP'
                : __devCentralWorksetExportMode === 'worksets'
                    ? 'WORKSETS'
                    : __devCentralWorksetExportMode === 'all'
                        ? 'ALL'
                        : 'CENTRALIZE';
            const ownershipRows = operation === 'OWNERSHIP'
                ? [
                    __devCentralWorksetRow("C:\\Sample\\Campus_Central.rvt", 0, {
                        rowId: "dev-workbook-ownership-central",
                        operation,
                        ownershipWorkbookTrusted: true,
                        outputCentralPath: "",
                        addWorksets: [],
                        retain3DViewOwnership: true,
                        ownership3DViewNames: ["{3D}", "Coordination 3D"],
                        retainViewTemplateOwnership: true,
                        ownershipViewTemplateNames: ["Coordination 3D Template"],
                        retainLevelGridWorksetOwnership: true,
                        pinLevelGridElements: false,
                        existingCentralOwnershipTargetKind: EXISTING_CENTRAL_OWNERSHIP_TARGET_KIND
                    }),
                    __devCentralWorksetRow("C:\\Sample\\Campus_Local_kkyki.rvt", 1, {
                        rowId: "dev-workbook-ownership-local",
                        operation,
                        ownershipWorkbookTrusted: true,
                        outputCentralPath: "",
                        addWorksets: [],
                        retain3DViewOwnership: false,
                        retainViewTemplateOwnership: false,
                        retainLevelGridWorksetOwnership: true,
                        pinLevelGridElements: true,
                        existingCentralOwnershipTargetKind: EXISTING_CENTRAL_OWNERSHIP_TARGET_KIND
                    })
                ]
                : null;
            _emitHost("centralworkset:rows", {
                requestId,
                source: "workbook",
                workbookPath,
                rows: ownershipRows || [
                    __devCentralWorksetRow("C:\\Sample\\Campus_Central.rvt", 0, {
                        rowId: "dev-workbook-campus-central-output-a",
                        operation,
                        outputCentralPath: "C:\\Temp\\NewCentrals\\Campus_Central_A.rvt",
                        addWorksets: ["Architecture", "Coordination"],
                        retain3DViewOwnership: true,
                        ownership3DViewNames: ["{3D}", "Coordination 3D"],
                        retainViewTemplateOwnership: true,
                        ownershipViewTemplateNames: ["Coordination 3D Template", "Issue 3D Template"],
                        viewTemplateOwnershipTargetKind: VIEW_TEMPLATE_OWNERSHIP_TARGET_KIND,
                        pinAndRetainLevelGridOwnership: true,
                        levelGridOwnershipTargetKind: LEVEL_GRID_OWNERSHIP_TARGET_KIND
                    }),
                    __devCentralWorksetRow("C:\\Sample\\Campus_Central.rvt", 1, {
                        rowId: "dev-workbook-campus-central-output-b",
                        operation,
                        outputCentralPath: "C:\\Temp\\NewCentrals\\Campus_Central_B.rvt",
                        addWorksets: ["Architecture - Copy", "Coordination - Copy"]
                    }),
                    __devCentralWorksetRow("C:\\Sample\\Campus_Local_kkyki.rvt", 1, {
                        rowId: "dev-workbook-campus-local",
                        operation,
                        outputCentralPath: "C:\\Temp\\NewCentrals\\Campus_Local_kkyki.rvt",
                        addWorksets: ["MEP", "Revit Links"]
                    }),
                    __devCentralWorksetRow("C:\\Sample\\Standalone_Model.rvt", 2, {
                        rowId: "dev-workbook-standalone",
                        operation,
                        outputCentralPath: "C:\\Temp\\NewCentrals\\Standalone_Model.rvt",
                        addWorksets: ["Workset1", "Shared Levels and Grids"]
                    })
                ]
            }, { __seq: seq });
            break;
        }
        case "centralworkset:run": {
            const mode = String(payload?.mode || "all").trim().toLowerCase();
            const requestId = String(payload?.requestId || "");
            const rows = Array.isArray(payload?.rows) ? payload.rows : [];
            _emitHost("centralworkset:progress", {
                requestId,
                percent: 18,
                message: "(DEV) 사용자 웍셋 CloseAll 상태로 RVT를 여는 중입니다.",
                detail: `${rows.length}개 파일`
            }, { __seq: seq });
            setTimeout(() => {
                _emitHost("centralworkset:progress", {
                    requestId,
                    percent: 72,
                    message: mode === "worksets"
                        ? "(DEV) 사용자 웍셋을 추가하는 중입니다."
                        : mode === "ownership"
                            ? "(DEV) 기존 센트럴 권한을 적용하고 검증하는 중입니다."
                            : "(DEV) 새 센트럴 파일을 저장하는 중입니다.",
                    detail: mode === "ownership" ? "fresh inspect / synchronize / fresh verify" : "strict detach / SaveAsCentral"
                }, { __seq: seq });
            }, 160);
            setTimeout(() => {
                const completedRows = rows.map((row, index) => __devCentralWorksetCompletedRow(row, index, mode));
                const createdWorksetCount = completedRows.reduce((sum, row) => sum + row.createdWorksets.length, 0);
                const skippedWorksetCount = completedRows.reduce((sum, row) => sum + row.skippedWorksets.length, 0);
                const ownedViewTemplateCount = completedRows.reduce((sum, row) => sum + row.ownedViewTemplateNames.length, 0);
                const ownedLevelGridCount = completedRows.reduce((sum, row) => sum + Number(row.ownedLevelGridCount || 0), 0);
                const ownedLevelGridWorksetCount = completedRows.reduce((sum, row) => sum + row.ownedLevelGridWorksetNames.length, 0);
                _emitHost("centralworkset:completed", {
                    requestId,
                    ok: true,
                    mode,
                    rows: completedRows,
                    summary: {
                        totalCount: completedRows.length,
                        successCount: completedRows.length,
                        failedCount: 0,
                        centralCreatedCount: (mode === "worksets" || mode === "ownership") ? 0 : completedRows.length,
                        createdWorksetCount,
                        skippedWorksetCount,
                        ownedViewTemplateCount,
                        ownedLevelGridCount,
                        ownedLevelGridWorksetCount,
                        message: `(DEV) ${completedRows.length}개 RVT 처리를 완료했습니다.`
                    }
                }, { __seq: seq });
            }, 360);
            break;
        }
        case "centralworkset:open-output-folder": {
            console.debug("[DEV] centralworkset output folder:", payload?.path || "");
            break;
        }
        case "levelchange:init": {
            _emitHost("levelchange:context", {
                requestId: String(payload?.requestId || ""),
                settings: {
                    rvtPaths: Array.isArray(payload?.rvtPaths) ? payload.rvtPaths : [],
                    workbookPath: String(payload?.workbookPath || ""),
                    outputFolder: String(payload?.outputFolder || ""),
                    closeAllWorksetsOnOpen: true,
                    synchronizeAfterProcessing: true,
                    syncComment: String(payload?.syncComment || "KKY Tool - 프로젝트 파일 내 Level 변경")
                },
                imported: null,
                result: null
            }, { __seq: seq });
            break;
        }
        case "levelchange:pick-rvts": {
            _emitHost("levelchange:rvts-picked", {
                requestId: String(payload?.requestId || ""),
                ok: true,
                paths: ["C:\\Sample\\Campus_MEP_Central.rvt", "C:\\Sample\\Plant_MEP_Central.rvt"]
            }, { __seq: seq });
            break;
        }
        case "levelchange:export-template": {
            _emitHost("levelchange:template-exported", {
                requestId: String(payload?.requestId || ""),
                ok: true,
                path: "C:\\Temp\\Project_Level_Change.xlsx",
                message: "(DEV) Level 변경 Excel 양식을 저장했습니다."
            }, { __seq: seq });
            break;
        }
        case "levelchange:pick-workbook": {
            _emitHost("levelchange:workbook-picked", {
                requestId: String(payload?.requestId || ""),
                ok: true,
                path: "C:\\Temp\\Project_Level_Change.xlsx"
            }, { __seq: seq });
            break;
        }
        case "levelchange:import-workbook": {
            const requestId = String(payload?.requestId || "");
            const paths = Array.isArray(payload?.rvtPaths) && payload.rvtPaths.length
                ? payload.rvtPaths
                : ["C:\\Sample\\Campus_MEP_Central.rvt"];
            _emitHost("levelchange:imported", {
                requestId,
                ok: true,
                message: "(DEV) 2개 Level 이동 지시를 불러왔습니다.",
                workbookPath: String(payload?.workbookPath || "C:\\Temp\\Project_Level_Change.xlsx"),
                jobs: [
                    { rowId: "dev-level-1", excelRowNumber: 2, action: "APPLY", sourceRvtPath: String(paths[0]), levelName: "L01", direction: "UP", distanceMillimeters: 150, note: "", validationMessage: "" },
                    { rowId: "dev-level-2", excelRowNumber: 3, action: "APPLY", sourceRvtPath: String(paths[Math.min(1, paths.length - 1)]), levelName: "L02", direction: "DOWN", distanceMillimeters: 75, note: "", validationMessage: "" }
                ],
                errors: []
            }, { __seq: seq });
            break;
        }
        case "levelchange:pick-output-folder": {
            _emitHost("levelchange:output-folder-picked", {
                requestId: String(payload?.requestId || ""),
                ok: true,
                path: "C:\\Temp\\LevelChange_Results"
            }, { __seq: seq });
            break;
        }
        case "levelchange:run": {
            const requestId = String(payload?.requestId || "");
            _emitHost("levelchange:progress", {
                requestId,
                current: 0,
                total: 2,
                percent: 12,
                message: "(DEV) 모든 사용자 웍셋을 닫고 임시 local을 여는 중입니다.",
                detail: "Campus_MEP_Central.rvt"
            }, { __seq: seq });
            setTimeout(() => {
                _emitHost("levelchange:progress", {
                    requestId,
                    current: 1,
                    total: 2,
                    percent: 66,
                    message: "(DEV) Level 이동 영향 객체와 Revit 실패를 기록하는 중입니다.",
                    detail: "L01 / +150 mm"
                }, { __seq: seq });
            }, 120);
            setTimeout(() => {
                _emitHost("levelchange:done", {
                    requestId,
                    ok: true,
                    message: "(DEV) 2개 Level 이동과 파일별 결과 추출을 완료했습니다.",
                    outputFolder: String(payload?.outputFolder || "C:\\Temp\\LevelChange_Results"),
                    summary: {
                        fileCount: 2,
                        successFileCount: 2,
                        partialFileCount: 0,
                        failedFileCount: 0,
                        requestedLevelCount: 2,
                        movedLevelCount: 2,
                        failedLevelCount: 0,
                        warningCount: 1,
                        errorCount: 0,
                        modifiedElementCount: 18,
                        deletedElementCount: 0,
                        addedElementCount: 0,
                        connectionChangedCount: 2,
                        synchronizedFileCount: 2
                    },
                    files: ["Campus_MEP_Central.rvt", "Plant_MEP_Central.rvt"].map((fileName, index) => ({
                        sourcePath: `C:\\Sample\\${fileName}`,
                        fileName,
                        status: "Success",
                        message: "Level 1개 이동 완료",
                        reportPath: `C:\\Temp\\LevelChange_Results\\${fileName.replace(/\.rvt$/i, "")}_LevelChange.xlsx`,
                        centralPath: `C:\\Sample\\${fileName}`,
                        localPath: "",
                        temporaryLocalRetained: false,
                        synchronizePerformed: true,
                        synchronizationOutcome: "Succeeded",
                        synchronizationOutcomeUncertain: false,
                        savePerformed: false,
                        changesPersisted: true,
                        persistenceStatus: "Synchronized",
                        unsafeTransactionState: false,
                        impactCoverage: "모든 사용자 웍셋을 닫은 상태의 DocumentChanged ID와 로드 가능한 요소 스냅샷 기준",
                        impactCaptureIncomplete: false,
                        reportGenerated: true,
                        levelCount: 1,
                        successCount: 1,
                        impactCount: index === 0 ? 12 : 8
                    }))
                }, { __seq: seq });
            }, 280);
            break;
        }
        case "levelchange:open-output-folder": {
            _emitHost("levelchange:folder-opened", {
                requestId: String(payload?.requestId || ""),
                ok: true,
                path: String(payload?.path || "C:\\Temp\\LevelChange_Results")
            }, { __seq: seq });
            break;
        }
        case "utilitymaterial:filename-rule-template": {
            setTimeout(() => {
                _emitHost("utilitymaterial:filename-rule-template-saved", {
                    ok: true,
                    path: "C:\\Temp\\KKY_UTILITY_기반_재질_오류_파일명_매핑_규칙.xlsx"
                }, { __seq: seq });
            }, 180);
            break;
        }
        default: {
            console.debug("[DEV] post noop:", ev, payload);
            break;
        }
    }
    return true;
}

// -----------------------------
// 공개: 연결 상태 칩
// -----------------------------
export function setConn(ok) {
    const chip = document.querySelector('#connChip');
    if (!chip) return;
    chip.classList.toggle('is-active', !!ok);
    chip.classList.toggle('is-disconnected', !ok);
    const label = chip.querySelector('.chip-text');
    if (label) label.textContent = ok ? '연결됨' : '연결 끊김';
}

// -----------------------------
// 공개: ping
// -----------------------------
export function ping() {
    if (!DEV) { setConn(true); return; }
    setConn(false);
    setTimeout(() => setConn(true), 350);
}

// -----------------------------
// 초기: 호스트 메시지 수신(WebView2)
// -----------------------------
if (!DEV) {
    window.chrome.webview.addEventListener("message", (e) => {
        const data = e?.data;
        if (!data) return;
        const ev = data.ev || data.name || "";  // 호스트가 ev 또는 name 둘 다 가능
        _emitHost(ev, data.payload, { __seq: data.__seq });
    });
}

// -----------------------------
// DEV 초기 상태
// -----------------------------
let __devTopMost = false;
const __devAccCloudTrustedRows = new Map();
const __devAccCloudBlockedTargetKeys = new Set();

function __devAccCloudTargetKey(row) {
    const guid = (value) => String(value || '').trim().replace(/^b\./i, '').replace(/[{}-]/g, '').toLowerCase();
    const keyText = (value) => String(value || '').trim().normalize('NFC').toLowerCase();
    let modelName = String(row?.modelName || '').trim().normalize('NFC');
    if (modelName && !/\.rvt$/i.test(modelName)) modelName += '.rvt';
    return [guid(row?.accountGuid), guid(row?.projectGuid), keyText(row?.folderId), keyText(modelName)].join('|');
}

function __devAccCloudRequestFingerprint(row) {
    const exactList = (value) => (Array.isArray(value) ? value : []).map((item) => String(item || '').trim().normalize('NFC')).filter(Boolean).join('\u001f');
    const parts = [
        String(row?.rowId || '').trim().normalize('NFC').toLowerCase(),
        String(row?.action || '').trim().toUpperCase(),
        String(row?.sourcePath || '').trim().normalize('NFC').toLowerCase(),
        __devAccCloudTargetKey(row),
        String(row?.region || 'US').trim().toUpperCase(),
        String(row?.mode || 'cloud-workshared').trim().toLowerCase(),
        exactList(row?.addWorksets),
        String(Boolean(row?.retain3DViewOwnership)),
        exactList(row?.ownership3DViewNames),
        String(Boolean(row?.retainViewTemplateOwnership)),
        exactList(row?.ownershipViewTemplateNames),
        String(Boolean(row?.pinAndRetainLevelGridOwnership)),
        String(row?.viewTemplateOwnershipTargetKind || VIEW_TEMPLATE_OWNERSHIP_TARGET_KIND).trim(),
        String(row?.levelGridOwnershipTargetKind || LEVEL_GRID_OWNERSHIP_TARGET_KIND).trim()
    ];
    return parts.map((value) => `${value.length}:${value}`).join('');
}

function __devAccCloudRow(path, index, overrides = {}) {
    const sourcePath = String(path || "");
    const sourceFileName = __devCentralWorksetFileName(sourcePath) || `Model_${index + 1}.rvt`;
    return {
        rowId: `dev-acccloud-${index + 1}-${sourceFileName}`,
        action: "APPLY",
        sourcePath,
        accountGuid: "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
        projectGuid: "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb",
        folderId: `urn:adsk.wipprod:fs.folder:co.devFolder${index + 1}`,
        region: "US",
        modelName: sourceFileName,
        mode: "cloud-workshared",
        addWorksets: [],
        retain3DViewOwnership: false,
        ownership3DViewNames: [],
        retainViewTemplateOwnership: false,
        ownershipViewTemplateNames: [],
        pinAndRetainLevelGridOwnership: false,
        status: "PENDING",
        message: "",
        remoteCreated: false,
        manualCleanupRequired: false,
        persistenceState: "",
        verifiedFreshOpen: false,
        existingWorksets: [],
        createdWorksets: [],
        skippedWorksets: [],
        ...overrides
    };
}

function __devCentralWorksetRow(path, index, overrides = {}) {
    const sourcePath = String(path || "");
    const sourceFileName = __devCentralWorksetFileName(sourcePath) || `Model_${index + 1}.rvt`;
    const lower = sourceFileName.toLowerCase();
    const isUnknown = lower.includes("unknown");
    const isStandalone = !isUnknown && (lower.includes("standalone") || lower.includes("일반"));
    const isLocal = !isUnknown && !isStandalone && (lower.includes("local") || lower.includes("로컬"));
    const isCentral = !isUnknown && !isStandalone && !isLocal;
    const centralPath = isLocal ? "C:\\Sample\\Campus_Central.rvt" : isCentral ? sourcePath : "";
    const existingWorksets = isUnknown || isStandalone
        ? []
        : isLocal
            ? ["Shared Levels and Grids", "Workset1", "Revit Links"]
            : ["Shared Levels and Grids", "Workset1", "Architecture"];
    return {
        rowId: `dev-centralworkset-${index + 1}-${sourceFileName}`,
        operation: "",
        ownershipWorkbookTrusted: false,
        sourcePath,
        originalSourcePath: sourcePath,
        sourceFileName,
        sourceType: isUnknown ? "unknown" : isStandalone ? "standalone" : isLocal ? "local" : "central",
        isWorkshared: !isUnknown && !isStandalone,
        isCentral,
        isLocal,
        isStandalone,
        isOpen: false,
        isNewerVersion: false,
        isCurrentVersion: !isUnknown,
        isFamily: false,
        isCloud: false,
        format: isUnknown ? "" : "RVT",
        centralPath,
        originalCentralPath: centralPath,
        missingConnectedCentral: false,
        existingWorksets,
        outputCentralPath: `C:\\Temp\\NewCentrals\\${sourceFileName}`,
        addWorksets: [],
        retain3DViewOwnership: false,
        ownership3DViewNames: [],
        owned3DViewNames: [],
        retainViewTemplateOwnership: false,
        ownershipViewTemplateNames: [],
        viewTemplateOwnershipTargetKind: VIEW_TEMPLATE_OWNERSHIP_TARGET_KIND,
        ownedViewTemplateNames: [],
        pinAndRetainLevelGridOwnership: false,
        levelGridOwnershipTargetKind: LEVEL_GRID_OWNERSHIP_TARGET_KIND,
        retainLevelGridWorksetOwnership: false,
        pinLevelGridElements: false,
        existingCentralOwnershipTargetKind: "",
        resolvedOwnershipCentralPath: "",
        ownedLevelGridCount: 0,
        ownedLevelGridWorksetNames: [],
        action: "APPLY",
        status: "ready",
        message: "(DEV) RVT 정보 확인 완료",
        createdCentral: false,
        persistedChanges: false,
        persistenceState: "NONE",
        requiresManualVerification: false,
        createdWorksets: [],
        skippedWorksets: [],
        ...overrides
    };
}

function __devCentralWorksetCompletedRow(raw, index, mode) {
    const row = __devCentralWorksetRow(raw?.sourcePath, index, raw || {});
    const normalizedMode = String(mode || "").trim().toLowerCase();
    const createsCentral = normalizedMode === "centralize" || normalizedMode === "all";
    const ownershipOnly = normalizedMode === "ownership";
    const existing = Array.isArray(row.existingWorksets) ? row.existingWorksets.map((name) => String(name)) : [];
    const existingKeys = new Set(existing.map((name) => name.trim()));
    const requested = Array.isArray(row.addWorksets) ? row.addWorksets.map((name) => String(name).trim()).filter(Boolean) : [];
    const createdWorksets = normalizedMode === "centralize" ? [] : requested.filter((name) => !existingKeys.has(name));
    const skippedWorksets = normalizedMode === "centralize" ? [] : requested.filter((name) => existingKeys.has(name));
    const outputPath = String(row.outputCentralPath || "");
    const resultPath = createsCentral && outputPath ? outputPath : String(row.sourcePath || "");
    const originalSourcePath = String(row.originalSourcePath || row.sourcePath || "");
    const originalCentralPath = String(row.originalCentralPath || row.centralPath || "");
    const persistedChanges = ownershipOnly ? false : (createsCentral || createdWorksets.length > 0);
    const retain3DViewOwnership = !!row.retain3DViewOwnership;
    const ownership3DViewNames = Array.isArray(row.ownership3DViewNames)
        ? [...new Set(row.ownership3DViewNames.map((name) => String(name).trim()).filter(Boolean))]
        : [];
    const owned3DViewNames = (createsCentral || ownershipOnly) && retain3DViewOwnership ? [...ownership3DViewNames] : [];
    const retainViewTemplateOwnership = !!row.retainViewTemplateOwnership;
    const ownershipViewTemplateNames = Array.isArray(row.ownershipViewTemplateNames)
        ? [...new Set(row.ownershipViewTemplateNames.map((name) => String(name).trim()).filter(Boolean))]
        : [];
    const ownedViewTemplateNames = (createsCentral || ownershipOnly) && retainViewTemplateOwnership ? [...ownershipViewTemplateNames] : [];
    const pinAndRetainLevelGridOwnership = !!row.pinAndRetainLevelGridOwnership;
    const retainLevelGridWorksetOwnership = ownershipOnly && !!row.retainLevelGridWorksetOwnership;
    const pinLevelGridElements = ownershipOnly && retainLevelGridWorksetOwnership && !!row.pinLevelGridElements;
    const levelGridRequested = ownershipOnly ? retainLevelGridWorksetOwnership : pinAndRetainLevelGridOwnership;
    const ownedLevelGridCount = (ownershipOnly ? pinLevelGridElements : (createsCentral && pinAndRetainLevelGridOwnership)) ? 12 + index : 0;
    const ownedLevelGridWorksetNames = (createsCentral || ownershipOnly) && levelGridRequested
        ? [LEVEL_GRID_OWNERSHIP_WORKSET_NAME]
        : [];
    const viewTemplateWorksetMessage = createsCentral && retainViewTemplateOwnership && ownedViewTemplateNames.length > 0
        ? ' 지정 3D 템플릿 ViewWorkset의 Owner=현재 사용자·Editable=Yes를 검증했고, Revit 필수 pair/internal closure 외 비대상 View/템플릿은 포함되지 않았습니다.'
        : '';
    const levelGridWorksetMessage = (createsCentral || ownershipOnly) && levelGridRequested
        ? ` exact-name ${LEVEL_GRID_OWNERSHIP_WORKSET_NAME} UserWorkset Owner=현재 사용자·Editable=Yes${ownedLevelGridCount ? ` 및 본문 Level/Grid ${ownedLevelGridCount}개 Pin` : ''}을 검증했습니다.`
        : '';
    const mergedWorksets = [...existing];
    createdWorksets.forEach((name) => {
        if (!mergedWorksets.includes(name)) mergedWorksets.push(name);
    });
    return {
        ...row,
        sourcePath: resultPath,
        originalSourcePath,
        sourceFileName: __devCentralWorksetFileName(resultPath),
        sourceType: createsCentral ? "central" : row.sourceType,
        isWorkshared: createsCentral ? true : row.isWorkshared,
        isCentral: createsCentral ? true : row.isCentral,
        isLocal: createsCentral ? false : row.isLocal,
        isStandalone: createsCentral ? false : row.isStandalone,
        isOpen: false,
        centralPath: createsCentral ? outputPath : row.centralPath,
        missingConnectedCentral: createsCentral ? false : !!row.missingConnectedCentral,
        originalCentralPath,
        existingWorksets: mergedWorksets,
        action: "APPLY",
        status: "completed",
        message: (normalizedMode === "centralize"
            ? "(DEV) 새 센트럴 파일을 만들었습니다."
            : normalizedMode === "worksets"
                ? `(DEV) 웍셋 ${createdWorksets.length}개를 추가했습니다.`
                : normalizedMode === "ownership"
                    ? "(DEV) 기존 센트럴 권한을 적용하고 fresh-open 검증했습니다. 실제 변경이 없어도 검증 성공으로 처리합니다."
                    : `(DEV) 새 센트럴 생성 및 웍셋 ${createdWorksets.length}개 추가를 완료했습니다.`) + viewTemplateWorksetMessage + levelGridWorksetMessage,
        createdCentral: createsCentral,
        persistedChanges,
        persistenceState: (persistedChanges || ownershipOnly) ? "VERIFIED" : "NONE",
        requiresManualVerification: false,
        retain3DViewOwnership,
        ownership3DViewNames,
        owned3DViewNames,
        retainViewTemplateOwnership,
        ownershipViewTemplateNames,
        viewTemplateOwnershipTargetKind: VIEW_TEMPLATE_OWNERSHIP_TARGET_KIND,
        ownedViewTemplateNames,
        pinAndRetainLevelGridOwnership,
        levelGridOwnershipTargetKind: LEVEL_GRID_OWNERSHIP_TARGET_KIND,
        retainLevelGridWorksetOwnership,
        pinLevelGridElements,
        existingCentralOwnershipTargetKind: ownershipOnly ? EXISTING_CENTRAL_OWNERSHIP_TARGET_KIND : "",
        ownershipWorkbookTrusted: ownershipOnly ? true : !!row.ownershipWorkbookTrusted,
        resolvedOwnershipCentralPath: ownershipOnly ? String(row.centralPath || row.sourcePath || "") : "",
        outputCentralPath: ownershipOnly ? "" : (createsCentral ? outputPath : row.outputCentralPath),
        ownedLevelGridCount,
        ownedLevelGridWorksetNames,
        createdWorksets,
        skippedWorksets
    };
}

function __devCentralWorksetFileName(path) {
    const parts = String(path || "").split(/[\\/]/);
    return parts[parts.length - 1] || "";
}

function __devLinkSharedCoordContext() {
    return {
        ok: true,
        hostDocument: {
            title: "SITE_COORDINATION.rvt",
            path: "C:\\Sample\\SITE_COORDINATION.rvt"
        },
        activeProjectLocation: {
            id: "host-site-1",
            name: "SITE_Shared",
            bearingDegrees: 12.5
        },
        links: [
            {
                id: 71001,
                name: "A동_건축.rvt : 1",
                fileName: "A동_건축.rvt",
                loaded: true,
                pinned: false,
                nested: false,
                cloud: false,
                scenarioBased: false,
                scenarioStatusKnown: true,
                originalPlacementMethod: "확인 불가 (Revit API 미제공)",
                currentPlacementMethod: "Shared Coordinates (현재 Shared Site 관계)",
                currentPlacementMethodCode: "SHARED_COORDINATES",
                currentPlacementDetails: "Shared Site 'A동_A1'와 현재 Transform이 일치합니다.",
                instanceSharedSiteName: "A동_A1",
                instanceSharedSiteStatus: "ASSIGNED",
                linkedDocumentActiveProjectLocationName: "Internal",
                grids: ["A", "B", "1", "2"],
                levels: [
                    { id: 81001, name: "1FL", preferred: true },
                    { id: 81002, name: "2FL" },
                    { id: 81003, name: "ROOF" }
                ],
                existingSites: [
                    { id: "site-a1", name: "A동_A1", preferred: true, isCurrentSharedSite: true },
                    { id: "internal", name: "Internal" }
                ]
            },
            {
                id: 71002,
                name: "B동_Cloud.rvt : 1",
                fileName: "B동_Cloud.rvt",
                loaded: true,
                nested: false,
                cloud: true,
                scenarioBased: false,
                scenarioStatusKnown: true,
                levels: [{ id: 82001, name: "1FL", preferred: true }],
                existingSites: [{ id: "site-b1", name: "B동_A1", preferred: true }]
            },
            {
                id: 71003,
                name: "A동_설비_중첩.rvt : 1",
                fileName: "A동_설비_중첩.rvt",
                loaded: true,
                nested: true,
                cloud: false,
                scenarioBased: false,
                scenarioStatusKnown: true,
                levels: [{ id: 83001, name: "1FL", preferred: true }],
                existingSites: [{ id: "site-m1", name: "MEP_A1", preferred: true }]
            }
        ],
        defaults: {
            anchorGrid1: "A",
            anchorGrid2: "1",
            directionMode: "secondIntersection",
            directionGrid1: "A",
            directionGrid2: "2",
            targetSource: "linkedSite",
            unit: "mm"
        }
    };
}

function __devLinkSharedCoordAnalysis(payload) {
    const manual = payload?.manual || {};
    const useManual = payload?.targetSource === "manual";
    const target = {
        east: useManual ? Number(manual.east || 0) : 125000,
        north: useManual ? Number(manual.north || 0) : 83000,
        elevation: useManual ? Number(manual.elevation || 0) : 0,
        bearingDegrees: useManual ? Number(manual.bearingDegrees || 0) : 12.5
    };
    const current = { east: 124850, north: 83120, elevation: 0, bearingDegrees: 12.25 };
    return {
        ok: true,
        analysisToken: `dev-sharedcoord-${Date.now()}`,
        anchorSummary: `${payload?.anchorGrid1 || "A"} × ${payload?.anchorGrid2 || "1"} · ${payload?.levelName || "1FL"} · 방향 ${payload?.directionGrid1 || "A"} × ${payload?.directionGrid2 || "2"}`,
        originalPlacementMethod: "확인 불가 (Revit API 미제공)",
        currentPlacementMethod: "Shared Coordinates (현재 Shared Site 관계)",
        currentPlacementMethodCode: "SHARED_COORDINATES",
        currentPlacementDetails: "Shared Site 'A동_A1'와 현재 Transform이 일치합니다.",
        instanceSharedSiteName: "A동_A1",
        instanceSharedSiteStatus: "ASSIGNED",
        linkedDocumentActiveProjectLocationName: "Internal",
        targetProjectLocationName: payload?.targetProjectLocationName || "A동_A1",
        current,
        target,
        delta: {
            east: target.east - current.east,
            north: target.north - current.north,
            elevation: target.elevation - current.elevation,
            bearingDegrees: target.bearingDegrees - current.bearingDegrees,
            bearingDegreesClockwise: target.bearingDegrees - current.bearingDegrees,
            rotationDegreesCounterClockwise: current.bearingDegrees - target.bearingDegrees
        },
        warnings: Number(payload?.linkInstanceId) === 71002 ? ["Cloud 링크는 분석과 호스트 배치만 가능하며 Publish는 지원하지 않습니다."] : [],
        canApply: true,
        canPublish: Number(payload?.linkInstanceId) !== 71002,
        message: "(DEV) A × 1 기준 Shared Coordination 분석을 완료했습니다."
    };
}

function __devLinkSharedCoordBatchRows(imported) {
    return [
        {
            Action: imported ? "APPLY" : "REVIEW",
            HostFileName: "HOST_A.rvt",
            HostFilePath: "C:\\Sample\\HOST_A.rvt",
            LinkInstanceName: "A동_건축.rvt : 1",
            OriginalPlacementMethod: "확인 불가 (Revit API 미제공)",
            CurrentPlacementMethod: "Shared Coordinates (현재 Shared Site 관계)",
            CurrentPlacementMethodCode: "SHARED_COORDINATES",
            CurrentPlacementDetails: "Shared Site 'A동_A1'와 현재 Transform이 일치합니다.",
            InstanceSharedSiteName: "A동_A1",
            InstanceSharedSiteStatus: "ASSIGNED",
            LinkedDocumentActiveProjectLocationName: "Internal",
            InstanceWorksetName: "Shared Levels and Grids",
            LinkedFileStatus: "Loaded",
            Loaded: true,
            InstanceInfoAvailable: true,
            TransformAvailable: true,
            InstanceTransformE: 124850,
            InstanceTransformN: 83120,
            InstanceTransformZ: 0,
            InstanceTransformBearingDegrees: 12.25,
            ReviewStatus: "READY",
            ReviewMessage: "A × 1 / 1FL 좌표 상세 검토 완료",
          CanApply: true,
          ApplyStatus: imported ? "PENDING" : "NOT_REQUESTED",
          ApplyMessage: imported ? "현재 모델 재검토 후 APPLY 대기" : ""
        },
        {
            Action: "REVIEW",
            HostFileName: "HOST_B.rvt",
            HostFilePath: "C:\\Sample\\HOST_B.rvt",
            LinkInstanceName: "B동_구조.rvt",
            OriginalPlacementMethod: "확인 불가 (Revit API 미제공)",
            CurrentPlacementMethod: "확인 불가 (링크 인스턴스 정보 없음)",
            CurrentPlacementMethodCode: "UNAVAILABLE",
            CurrentPlacementDetails: "닫힌 웍셋 스캔에서 링크 타입 메타데이터만 확인했습니다.",
            InstanceSharedSiteName: "",
            InstanceSharedSiteStatus: "UNAVAILABLE",
            LinkedDocumentActiveProjectLocationName: "",
            TypeWorksetName: "Revit Links",
            LinkedFileStatus: "InClosedWorkset",
            Loaded: false,
            InstanceInfoAvailable: false,
            TransformAvailable: false,
            ReviewStatus: "BLOCKED",
            ReviewMessage: "링크 객체 메타데이터만 추출됨 · 좌표 상세 검토 필요",
            ApplyStatus: "",
            ApplyMessage: ""
        }
    ];
}
