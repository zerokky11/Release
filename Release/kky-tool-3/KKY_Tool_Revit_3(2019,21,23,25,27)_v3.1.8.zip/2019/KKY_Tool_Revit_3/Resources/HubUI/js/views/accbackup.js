import { clear, div, toast } from '../core/dom.js?v=20260731parameterexport1';
import { onHost, post } from '../core/bridge.js';
import { createFeatureGuideButton } from '../core/featureGuide.js?v=20260916linkbatch1';

let activeCleanup = null;

export function renderAccBackup(root) {
  activeCleanup?.();
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);

  const state = {
    revitMajor: 0,
    profiles: [],
    jobs: [],
    connected: new Map(),
    realWriteGate: false,
    hostOnlyWarning: '',
    profile: defaultProfile(),
    options: { hubs: [], projects: [], topfolders: [], contents: [] },
    busy: false,
    cleanup: [],
    ui: {}
  };

  const page = div('feature-shell accbackup-page');
  page.innerHTML = `
    <header class="feature-header accbackup-header">
      <div class="feature-heading">
        <span class="feature-kicker">ACC / Autodesk Docs · TEST · ordinary RVT versioning</span>
        <h2 class="feature-title">ACC 백업 (TEST)</h2>
        <p class="feature-sub">LAN file-based central의 성공 SWC를 신호로 닫힌 local snapshot을 만들고, 별도 ACC 일반 RVT Item에 Version으로 보관합니다. 기본값은 외부 write 없는 dry-run입니다.</p>
      </div>
    </header>`;
  const header = page.querySelector('.accbackup-header');
  const headerActions = div('feature-actions');
  const guideButton = createFeatureGuideButton('accbackup', { featureLabel: 'ACC 백업' });
  if (header && guideButton) {
    headerActions.append(guideButton);
    header.append(headerActions);
  }
  const workspace = div('accbackup-workspace');
  const runPanel = div('accbackup-run-panel');
  page.append(workspace, runPanel);
  target.append(page);
  state.ui.workspace = workspace;
  state.ui.runPanel = runPanel;

  registerHostEvents(state);
  render(state);
  post('accbackup:init', {});

  const cleanup = () => {
    state.cleanup.splice(0).forEach((dispose) => { try { dispose?.(); } catch { } });
    if (activeCleanup === cleanup) activeCleanup = null;
  };
  activeCleanup = cleanup;
}

function registerHostEvents(state) {
  const listen = (name, handler) => state.cleanup.push(onHost(name, handler));
  listen('accbackup:context', (payload) => {
    state.revitMajor = integer(payload?.revitMajor);
    state.profiles = array(payload?.profiles);
    state.jobs = array(payload?.jobs);
    state.realWriteGate = bool(payload?.realWriteGate);
    state.hostOnlyWarning = String(payload?.hostOnlyWarning || '');
    state.connected = new Map(array(payload?.credentialConnectionIds).map((entry) => [String(entry?.connectionProfileId || ''), bool(entry?.connected)]));
    const existing = state.profiles.find((entry) => entry?.profileId === state.profile.profileId) || state.profiles[0];
    if (existing) state.profile = normalizeProfile(existing, state.revitMajor);
    else state.profile = normalizeProfile(state.profile, state.revitMajor);
    state.busy = false;
    render(state);
  });
  listen('accbackup:central-picked', (payload) => {
    state.busy = false;
    if (payload?.ok && payload?.sourceCentralPath) {
      state.profile.sourceCentralPath = String(payload.sourceCentralPath);
      render(state);
      toast('LAN file-based central을 등록했습니다.', 'ok');
    } else render(state);
  });
  listen('accbackup:profile-saved', (payload) => {
    if (payload?.profile) state.profile = normalizeProfile(payload.profile, state.revitMajor);
    state.busy = false;
    render(state);
    toast('ACC backup profile을 durable queue 설정에 저장했습니다. token/signed URL은 저장하지 않습니다.', 'ok', 5200);
  });
  listen('accbackup:run-queued', (payload) => {
    state.busy = false;
    render(state);
    toast('수동 백업 job을 durable queue에 기록했습니다. Revit API가 닫힌 staging snapshot을 생성한 뒤 처리합니다.', 'ok', 5200);
  });
  listen('accbackup:auth-started', () => toast('시스템 브라우저에서 Autodesk 로그인을 완료하세요. token은 Windows Credential Manager에만 저장됩니다.', 'info', 7000));
  listen('accbackup:auth-result', (payload) => {
    state.busy = false;
    if (payload?.ok) toast(payload?.disconnected ? 'APS 연결 정보를 제거했습니다.' : 'APS 연결을 완료했습니다.', 'ok');
    else toast(String(payload?.message || 'APS 연결에 실패했습니다.'), 'err', 7200);
    post('accbackup:status', {});
  });
  listen('accbackup:browser-result', (payload) => {
    state.busy = false;
    const scope = String(payload?.scope || '');
    if (!payload?.ok) {
      toast(String(payload?.message || 'ACC browser 조회에 실패했습니다.'), 'err', 7200);
      render(state);
      return;
    }
    state.options[scope] = array(payload?.entries);
    render(state);
    toast(`${state.options[scope].length}개 ACC 항목을 조회했습니다. 목록에서 하나를 선택하세요.`, 'ok');
  });
  listen('accbackup:error', (payload) => {
    state.busy = false;
    render(state);
    const detail = String(payload?.detail || '').trim();
    toast(detail ? `${payload?.message || 'ACC backup 오류'} · ${detail}` : String(payload?.message || 'ACC backup 오류'), 'err', 7600);
  });
}

function render(state) {
  renderWorkspace(state);
  renderRunPanel(state);
}

function renderWorkspace(state) {
  const root = state.ui.workspace;
  clear(root);
  const guard = div(`accbackup-guard ${state.realWriteGate ? 'is-gated' : 'is-dry'}`);
  guard.innerHTML = state.realWriteGate
    ? '<strong>TEST write gate 활성</strong><span>그래도 profile의 dry-run 해제와 테스트 폴더 확인이 모두 필요하다. RCW Item은 항상 차단한다.</span>'
    : '<strong>TEST 기본값: dry-run</strong><span>이 PC는 실제 ACC write gate가 비활성이다. snapshot·hash·queue·mock/계약 검증만 수행하며 외부 ACC Version을 만들지 않는다.</span>';
  root.append(guard);

  const contract = div('accbackup-contract');
  contract.innerHTML = `<strong>안전 계약</strong><ul><li>SWC 콜백은 durable queue만 기록한다. Save/SaveAs/Close/업로드를 호출하지 않는다.</li><li>live central, native <code>_backup</code>, Desktop Connector를 직접 복사·감시하지 않는다.</li><li><code>CreateNewLocal</code> 결과인 닫힌 staging RVT만 hash·upload한다. target이 RCW/C4R이면 fail-closed다.</li></ul>`;
  root.append(contract);

  const form = div('accbackup-card accbackup-form');
  form.append(sectionTitle('1. LAN source / trigger', '성공 SWC + 10분 debounce, 최대 30분이 기본값이다. profile 저장 후에만 자동 감지가 켜진다.'));
  form.append(rowText('Source LAN central', 'sourceCentralPath', state.profile.sourceCentralPath, 'UNC 또는 절대 .rvt 경로', true));
  const sourcePicker = button('중앙 RVT 선택', () => send(state, 'accbackup:pick-central', {}), 'secondary');
  sourcePicker.classList.add('accbackup-source-picker');
  form.append(sourcePicker);
  form.append(rowNumber('Source Revit major', 'sourceRevitVersion', state.profile.sourceRevitVersion || state.revitMajor || '', 2019));
  form.append(rowSelect('Trigger', 'triggerMode', state.profile.triggerMode, [
    ['successful-swc-debounced', '성공 SWC + debounce (권장)'],
    ['successful-swc-every', '성공 SWC마다'],
    ['manual', '수동만']
  ]));
  form.append(rowNumber('Debounce minutes', 'debounceMinutes', state.profile.debounceMinutes, 1));
  form.append(rowNumber('Maximum interval minutes', 'maxBackupIntervalMinutes', state.profile.maxBackupIntervalMinutes, 1));
  form.append(rowCheck('Enabled', 'enabled', state.profile.enabled, 'profile 저장 후 successful SWC 자동 감지를 켠다.'));
  root.append(form);

  const auth = div('accbackup-card accbackup-form');
  auth.append(sectionTitle('2. APS PKCE connection', 'Public Client ID와 loopback redirect만 profile에 저장한다. access/refresh token은 Windows Credential Manager에만 저장한다.'));
  auth.append(rowText('Connection profile ID (local label)', 'connectionProfileId', state.profile.connectionProfileId, 'test-pc02'));
  auth.append(rowText('APS public Client ID (secret 금지)', 'oauthClientId', state.profile.oauthClientId, 'APS App Client ID'));
  auth.append(rowText('Loopback redirect URI (APS 등록값과 완전 일치)', 'oauthRedirectUri', state.profile.oauthRedirectUri, 'http://127.0.0.1:55999/aps/'));
  const authGuide = div('accbackup-id-guide');
  authGuide.innerHTML = '<strong>여기에는 GUID를 입력하지 않는다.</strong><span>Connection profile ID는 이 PC의 연결 별칭일 뿐이다. APS Developer 앱의 <b>Client ID</b>만 넣고 Client secret·token은 절대 넣지 마세요. redirect URI는 APS 앱에 등록한 값과 문자·포트·마지막 <code>/</code>까지 같아야 합니다.</span>';
  auth.append(authGuide);
  const connection = state.connected.get(String(state.profile.connectionProfileId || 'default'));
  const authActions = div('accbackup-actions');
  authActions.append(button(connection ? '연결 해제' : 'Autodesk 연결', () => {
    collectForm(state);
    send(state, connection ? 'accbackup:auth-disconnect' : 'accbackup:auth-start', oauthPayload(state));
  }, connection ? 'secondary' : 'primary'));
  authActions.append(statusChip(connection ? '연결됨' : '연결 필요', connection ? 'ok' : 'warn'));
  auth.append(authActions);
  root.append(auth);

  const target = div('accbackup-card accbackup-form');
  target.append(sectionTitle('3. ACC ordinary RVT target', 'Hub → Project → Folder → 고정 ordinary RVT Item 순서로 고른다. RCW/C4R Item은 선택·업로드 모두 차단한다.'));
  const targetGuide = div('accbackup-id-guide');
  targetGuide.innerHTML = '<strong>ACC ID는 수동으로 찾지 않아도 된다.</strong><span>Autodesk 연결 후 각 목록 버튼을 위에서 아래 순서로 누르고 결과에서 선택하세요. 이 화면은 APS가 반환한 원문 ID를 그대로 사용한다: Hub/Project의 <code>b.…</code>와 Folder/Item의 <code>urn:…</code>를 자르거나 GUID로 바꾸지 마세요. 하위 folder를 고르면 Folder contents를 한 번 더 눌러 들어갑니다.</span>';
  target.append(targetGuide);
  target.append(browserRow(state, 'hubs', 'Hub ID (browser 선택)', 'hubId', state.profile.hubId, 'Hub 목록'));
  target.append(browserRow(state, 'projects', 'Project ID (browser 선택)', 'projectId', state.profile.projectId, 'Project 목록'));
  target.append(browserRow(state, 'topfolders', 'Folder ID (browser 선택)', 'folderId', state.profile.folderId, 'Top folder 목록'));
  target.append(browserRow(state, 'contents', 'Target Item ID (ordinary RVT)', 'targetItemId', state.profile.targetItemId, 'Folder contents'));
  target.append(rowText('Target ordinary RVT name', 'targetItemName', state.profile.targetItemName, 'A-Building-ARC.rvt'));
  root.append(target);

  const testMode = div('accbackup-card accbackup-form accbackup-test-mode');
  testMode.append(sectionTitle('4. TEST 실행 모드', '실제 ACC write는 아래 두 확인과 이 PC의 TEST write gate가 모두 충족될 때만 허용된다.'));
  const modeSummary = div('accbackup-test-summary');
  modeSummary.innerHTML = state.realWriteGate
    ? '<strong>이 PC의 TEST write gate가 활성 상태다.</strong><span>전용 테스트 project/folder인지 확인한 뒤에만 dry-run을 해제하세요.</span>'
    : '<strong>이 PC의 TEST write gate가 비활성 상태다.</strong><span>아래 확인을 켜도 외부 ACC write는 발생하지 않는다.</span>';
  testMode.append(modeSummary);
  testMode.append(rowCheck('Dry-run 유지', 'dryRun', state.profile.dryRun, '기본값. snapshot·hash·queue만 검증하고 실제 APS write를 하지 않는다.'));
  testMode.append(rowCheck('전용 테스트 folder 확인', 'testFolderWriteConfirmed', state.profile.testFolderWriteConfirmed, '운영 project/folder에는 켜지 마세요. 실제 write에는 이 확인도 필요하다.'));
  root.append(testMode);

  const save = div('accbackup-save-row');
  save.append(button('TEST Profile 저장', () => { collectForm(state); send(state, 'accbackup:save-profile', profilePayload(state)); }, 'primary', state.busy));
  save.append(button('상태 새로고침', () => send(state, 'accbackup:status', {}), 'secondary', state.busy));
  root.append(save);
}

function renderRunPanel(state) {
  const root = state.ui.runPanel;
  clear(root);
  const card = div('accbackup-run-card');
  card.append(sectionTitle('TEST 실행 / receipt', 'ACC Version이 확인되기 전에는 “백업됨”으로 표시하지 않는다. dry-run은 실제 Version receipt가 아니다.'));
  const profileId = String(state.profile.profileId || '');
  card.append(button('TEST 백업 지금 실행', () => { collectForm(state); if (!profileId) { toast('먼저 TEST Profile 저장을 실행하세요.', 'warn'); return; } send(state, 'accbackup:run-now', { profileId }); }, 'primary', state.busy));
  const warning = div('accbackup-restore-note');
  warning.textContent = state.hostOnlyWarning || 'Host only backup; external links may not be included.';
  card.append(warning);
  const list = div('accbackup-job-list');
  const rows = state.jobs.filter((job) => !profileId || job?.profileId === profileId).slice(0, 18);
  if (!rows.length) list.innerHTML = '<p class="accbackup-empty">기록된 backup job이 없다.</p>';
  rows.forEach((job) => {
    const row = div('accbackup-job');
    const stateName = String(job?.state || 'UNKNOWN');
    row.innerHTML = `<div><strong>${escapeHtml(stateName)}</strong><span>${escapeHtml(job?.requestedAtUtc || '')}</span></div><small>${escapeHtml(job?.snapshotDocumentIdentity || job?.requestedDocumentIdentity || '')}</small><small>${escapeHtml(job?.lastErrorMessageSafe || '')}</small>`;
    if (['FAILED_MANUAL_ACTION', 'AMBIGUOUS'].includes(stateName)) row.append(button('재시도', () => send(state, 'accbackup:retry', { jobId: job?.jobId }), 'secondary'));
    list.append(row);
  });
  card.append(list);
  root.append(card);
}

function browserRow(state, scope, label, field, value, buttonLabel) {
  const row = div('accbackup-browser-row');
  row.append(rowText(label, field, value, `${label} ID`));
  row.append(button(buttonLabel, () => {
    collectForm(state);
    send(state, 'accbackup:browse', { ...oauthPayload(state), scope, hubId: state.profile.hubId, projectId: state.profile.projectId, folderId: state.profile.folderId });
  }, 'secondary', state.busy));
  const options = array(state.options[scope]);
  if (options.length) {
    const select = document.createElement('select');
    select.className = 'accbackup-browser-select';
    select.innerHTML = `<option value="">조회 결과 선택…</option>${options.map((entry) => `<option value="${escapeAttr(entry?.id)}" ${entry?.isRcw ? 'disabled' : ''}>${escapeHtml(entry?.name || entry?.id)}${entry?.isFolder ? ' · folder 열기' : entry?.isRcw ? ' · RCW 차단' : ''}</option>`).join('')}`;
    select.addEventListener('change', () => {
      if (!select.value) return;
      const selected = options.find((entry) => String(entry?.id || '') === select.value);
      if (scope === 'contents' && selected?.isFolder) {
        state.profile.folderId = select.value;
        state.profile.targetItemId = '';
        state.options.contents = [];
        toast(`하위 folder “${selected?.name || select.value}”를 대상 folder로 설정했습니다. Folder contents를 다시 누르세요.`, 'ok', 6200);
        render(state);
        return;
      }
      state.profile[field] = select.value;
      if (scope === 'contents' && selected?.name) state.profile.targetItemName = String(selected.name);
      const input = document.querySelector(`[data-accbackup-field="${field}"]`);
      if (input) input.value = select.value;
      if (scope === 'contents') {
        const nameInput = document.querySelector('[data-accbackup-field="targetItemName"]');
        if (nameInput) nameInput.value = state.profile.targetItemName;
      }
    });
    row.append(select);
  }
  return row;
}

function sectionTitle(title, subtitle) {
  const header = div('accbackup-card-title');
  header.innerHTML = `<div><strong>${escapeHtml(title)}</strong><span>${escapeHtml(subtitle)}</span></div>`;
  return header;
}

function rowText(label, field, value, placeholder, readonly = false) {
  const row = div('accbackup-field');
  row.innerHTML = `<label>${escapeHtml(label)}</label><input data-accbackup-field="${escapeAttr(field)}" type="text" spellcheck="false" ${readonly ? 'readonly' : ''} value="${escapeAttr(value)}" placeholder="${escapeAttr(placeholder)}" />`;
  return row;
}

function rowNumber(label, field, value, min) {
  const row = div('accbackup-field');
  row.innerHTML = `<label>${escapeHtml(label)}</label><input data-accbackup-field="${escapeAttr(field)}" type="number" min="${min}" value="${escapeAttr(value)}" />`;
  return row;
}

function rowSelect(label, field, value, options) {
  const row = div('accbackup-field');
  const select = document.createElement('select');
  select.dataset.accbackupField = field;
  options.forEach(([key, text]) => { const option = document.createElement('option'); option.value = key; option.textContent = text; option.selected = key === value; select.append(option); });
  const caption = document.createElement('label'); caption.textContent = label;
  row.append(caption, select);
  return row;
}

function rowCheck(label, field, checked, hint) {
  const row = div('accbackup-check');
  row.innerHTML = `<label><input data-accbackup-field="${escapeAttr(field)}" type="checkbox" ${checked ? 'checked' : ''}/><strong>${escapeHtml(label)}</strong></label><span>${escapeHtml(hint)}</span>`;
  return row;
}

function button(label, handler, kind = 'secondary', disabled = false) {
  const element = document.createElement('button');
  element.type = 'button'; element.className = `btn btn-${kind}`; element.textContent = label; element.disabled = !!disabled; element.addEventListener('click', handler); return element;
}

function statusChip(text, tone) { const chip = document.createElement('span'); chip.className = `accbackup-status is-${tone}`; chip.textContent = text; return chip; }

function collectForm(state) {
  document.querySelectorAll('[data-accbackup-field]').forEach((input) => {
    const field = input.dataset.accbackupField;
    if (!field) return;
    state.profile[field] = input.type === 'checkbox' ? input.checked : input.value;
  });
  state.profile = normalizeProfile(state.profile, state.revitMajor);
}

function profilePayload(state) { return { ...state.profile }; }
function oauthPayload(state) { return { connectionProfileId: state.profile.connectionProfileId, oauthClientId: state.profile.oauthClientId, oauthRedirectUri: state.profile.oauthRedirectUri }; }
function send(state, event, payload) { state.busy = true; post(event, payload); }

function defaultProfile() {
  return { profileId: '', enabled: false, sourceCentralPath: '', sourceRevitVersion: '', connectionProfileId: 'default', oauthClientId: '', oauthRedirectUri: 'http://127.0.0.1:55999/aps/', hubId: '', projectId: '', folderId: '', targetItemId: '', targetItemName: '', triggerMode: 'successful-swc-debounced', debounceMinutes: 10, maxBackupIntervalMinutes: 30, dryRun: true, testFolderWriteConfirmed: false };
}
function normalizeProfile(value, revitMajor) {
  const profile = { ...defaultProfile(), ...(value || {}) };
  profile.sourceRevitVersion = integer(profile.sourceRevitVersion) || integer(revitMajor) || '';
  profile.debounceMinutes = Math.max(1, integer(profile.debounceMinutes) || 10);
  profile.maxBackupIntervalMinutes = Math.max(profile.debounceMinutes, integer(profile.maxBackupIntervalMinutes) || 30);
  profile.enabled = bool(profile.enabled); profile.dryRun = bool(profile.dryRun); profile.testFolderWriteConfirmed = bool(profile.testFolderWriteConfirmed);
  return profile;
}
function array(value) { return Array.isArray(value) ? value : []; }
function bool(value) { return value === true || ['true', '1', 'yes', 'on'].includes(String(value || '').toLowerCase()); }
function integer(value) { const parsed = Number.parseInt(String(value ?? ''), 10); return Number.isFinite(parsed) ? parsed : 0; }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]); }
function escapeAttr(value) { return escapeHtml(value); }
