import { post } from './core/bridge.js';
import { initTheme } from './core/theme.js';
import { renderCentralWorkset } from './views/centralworkset.js?v=20260826centraloutputauto1';

const params = new URLSearchParams(window.location.search);
const requestedMode = String(params.get('mode') || '').trim().toLowerCase();
const mode = requestedMode === 'worksets' ? 'worksets' : 'centralize';
const root = document.getElementById('view-root');

initTheme();
renderCentralWorkset(root, {
  mode,
  worksetsOnly: mode === 'worksets',
  detachedWindow: true
});

document.documentElement.dataset.centralWorksetMode = mode;
document.title = mode === 'worksets'
  ? 'KKY Tool - 웍셋 추가'
  : 'KKY Tool - 센트럴·웍셋·권한 설정';

window.requestAnimationFrame(() => {
  post('centralworkset:window-ready', { mode });
});
