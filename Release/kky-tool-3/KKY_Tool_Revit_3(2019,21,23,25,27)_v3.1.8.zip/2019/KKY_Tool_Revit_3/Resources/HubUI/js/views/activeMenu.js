// Resources/HubUI/js/views/activeMenu.js
import { clear, div } from '../core/dom.js?v=20260731parameterexport1';
import {
  bindHubEntryContextMenu,
  getHubEntries,
  openHubEntry,
  setHubPanelSearch
} from '../core/hubFavorites.js?v=20260917columnnumber1';

const MULTI_MODE_KEY = 'kky.hub.multiMode';

const GROUPS = [
  {
    title: 'BQC 검토',
    label: '납품 시 BQC 검토',
    mode: 'bqc',
    desc: '납품 전 모델 품질 검토 기능을 한 화면에서 선택합니다.'
  },
  {
    title: '일반 도구',
    label: '일반 도구',
    mode: 'utility',
    desc: '반복 작업, 파라미터 정리, 링크 점검 도구를 실행합니다.'
  }
];

export function renderActiveMenu(root) {
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);

  const view = div('active-menu');
  const hero = div('home-choice-hero');
  hero.innerHTML = `
    <p>작업 그룹</p>
    <h2>필요한 기능 그룹을 선택하세요</h2>`;

  const groupGrid = div('active-menu-grid');
  GROUPS.forEach((group) => groupGrid.append(buildGroupCard(group)));

  const featureGrid = div('home-feature-grid');
  GROUPS.forEach((group) => featureGrid.append(buildFeaturePanel(group)));

  view.append(hero, groupGrid, featureGrid);
  target.append(view);
}

function buildGroupCard(group) {
  const card = document.createElement('button');
  card.type = 'button';
  card.className = 'active-menu-card';
  card.innerHTML = `
    <div class="active-menu-card__body">
      <div>
        <h3>${escapeHtml(group.title)}</h3>
        <p>${escapeHtml(group.desc)}</p>
      </div>
      <span class="active-menu-card__icon" aria-hidden="true">></span>
    </div>
    <span class="btn active-menu-cta">기능 선택</span>`;
  card.addEventListener('click', () => openMode(group.mode));
  return card;
}

function buildFeaturePanel(group) {
  const panel = div('home-feature-panel');
  const entries = getHubEntries({ groupLabel: group.label });

  panel.innerHTML = `
    <div class="home-feature-panel__head">
      <div>
        <span>${escapeHtml(group.label)}</span>
        <h3>${escapeHtml(group.title)}</h3>
      </div>
      <button class="btn btn--secondary" type="button">전체 열기</button>
    </div>`;

  const openAll = panel.querySelector('button');
  openAll.addEventListener('click', () => openMode(group.mode));

  const list = div('home-feature-list');
  entries.forEach((entry) => list.append(buildFeatureButton(entry)));
  panel.append(list);
  return panel;
}

function buildFeatureButton(entry) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'home-feature-item';
  button.innerHTML = `
    <strong class="home-feature-item__title">${escapeHtml(entry.label)}</strong>
    <span class="home-feature-item__desc">${escapeHtml(entry.desc || '')}</span>`;
  button.addEventListener('click', () => openEntry(entry));
  bindHubEntryContextMenu(button, entry.id);
  return button;
}

function openMode(mode) {
  const nextMode = mode === 'utility' ? 'utility' : 'bqc';
  setMultiMode(nextMode);
  setHubPanelSearch(nextMode, { query: '', entryId: '' });
  location.hash = nextMode === 'utility' ? '#utility' : '#bqc';
}

function openEntry(entry) {
  if (!entry) return;
  if (entry.route === 'multi') {
    const mode = entry.multiMode === 'utility' ? 'utility' : 'bqc';
    setMultiMode(mode);
    setHubPanelSearch(mode, { query: '', entryId: entry.id || '' });
  }
  openHubEntry(entry.id);
}

function setMultiMode(mode) {
  try {
    localStorage.setItem(MULTI_MODE_KEY, mode);
  } catch {
    // Embedded hosts may block localStorage in restricted environments.
  }
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
