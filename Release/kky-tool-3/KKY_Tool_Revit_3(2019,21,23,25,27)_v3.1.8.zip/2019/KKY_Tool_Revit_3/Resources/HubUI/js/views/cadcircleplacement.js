import { clear, div, toast } from '../core/dom.js?v=20260731parameterexport1';
import { onHost, post } from '../core/bridge.js';

export const CAD_CIRCLE_EVENTS = Object.freeze({
  init: 'cadcircle:init',
  layers: 'cadcircle:layers',
  scan: 'cadcircle:scan',
  apply: 'cadcircle:apply',
  context: 'cadcircle:context',
  layersResult: 'cadcircle:layers-result',
  preview: 'cadcircle:preview',
  result: 'cadcircle:result',
  error: 'cadcircle:error',
  documentChanged: 'host:doc-changed'
});

const SCHEMA_VERSION = 1;
const DEFAULT_TOLERANCE = Object.freeze({
  endpointMm: 1,
  planeMm: 1,
  fitAbsoluteMm: 1,
  fitRelativePercent: 1,
  horizontalAngleDeg: 1,
  duplicateCenterMm: 1,
  duplicateDiameterMm: 1,
  minimumDiameterMm: 0,
  maximumDiameterMm: null,
  minimumStraightSegments: 8,
  minimumCoverageDegrees: 350,
  maximumAngularGapDegrees: 45
});
const DEFAULT_PAGE_SIZE = 100;
const MAX_RESULT_ROWS = 200;

let requestSerial = 0;
let activeController = null;
let activeCleanup = null;
const queuedHostMessages = [];

export function renderCadCirclePlacement(root, options = {}) {
  activeCleanup?.();

  const target = root || document.getElementById('view-root') || document.getElementById('app');
  if (!target) throw new Error('CAD 원 배치 화면을 렌더링할 루트 요소가 없습니다.');
  clear(target);

  const state = createState(options);
  const page = div('cadcircle-page feature-shell');
  page.innerHTML = buildPageMarkup();
  target.append(page);
  state.page = page;
  state.ui = collectUi(page);
  // Shell3는 렌더 후 실행 카드를 main에서 aside로 이동한다. 이동 전후 모두 같은
  // 이벤트/상태 조회 범위에 남도록 page가 아니라 shell content를 interaction root로 쓴다.
  state.interactionRoot = page.closest('.shell3-content') || page;

  const unsubscribers = [];
  const domCleanups = [];
  let destroyed = false;

  const receive = (eventOrMessage, optionalPayload) => {
    const message = normalizeIncomingMessage(eventOrMessage, optionalPayload);
    if (!message.ev || !Object.values(CAD_CIRCLE_EVENTS).includes(message.ev)) return false;

    switch (message.ev) {
      case CAD_CIRCLE_EVENTS.context:
        handleContext(state, message.payload, options);
        break;
      case CAD_CIRCLE_EVENTS.layersResult:
        handleLayersResult(state, message.payload);
        break;
      case CAD_CIRCLE_EVENTS.preview:
        handlePreview(state, message.payload);
        break;
      case CAD_CIRCLE_EVENTS.result:
        handleResult(state, message.payload);
        break;
      case CAD_CIRCLE_EVENTS.error:
        handleError(state, message.payload);
        break;
      case CAD_CIRCLE_EVENTS.documentChanged:
        handleDocumentChanged(state, message.payload, options);
        break;
      default:
        return false;
    }
    notifyState(state, options);
    return true;
  };

  [
    CAD_CIRCLE_EVENTS.context,
    CAD_CIRCLE_EVENTS.layersResult,
    CAD_CIRCLE_EVENTS.preview,
    CAD_CIRCLE_EVENTS.result,
    CAD_CIRCLE_EVENTS.error,
    CAD_CIRCLE_EVENTS.documentChanged
  ].forEach((eventName) => {
    unsubscribers.push(onHost(eventName, (payload) => receive(eventName, payload)));
    const customHandler = (event) => receive(eventName, event?.detail ?? event?.payload ?? {});
    window.addEventListener(eventName, customHandler);
    domCleanups.push(() => window.removeEventListener(eventName, customHandler));
  });

  bindUi(state, options, domCleanups);

  const routeCleanup = () => {
    window.setTimeout(() => {
      if (!page.isConnected) cleanup(false);
    }, 0);
  };
  window.addEventListener('hashchange', routeCleanup);
  domCleanups.push(() => window.removeEventListener('hashchange', routeCleanup));

  const controller = {
    mountRoot: target,
    receive,
    requestInit: () => requestInit(state, options),
    requestLayers: (linkKey, force = false) => requestLinkLayers(state, options, linkKey, force),
    requestScan: () => requestScan(state, options),
    requestApply: () => requestApply(state, options),
    buildScanPayload: () => buildScanPayload(state, createRequestId('scan')),
    buildApplyPayload: () => buildApplyPayload(state, createRequestId('apply')),
    getState: () => createPublicStateSnapshot(state),
    destroy: () => cleanup(true)
  };

  function cleanup(removePage) {
    if (destroyed) return;
    destroyed = true;
    unsubscribers.splice(0).forEach((unsubscribe) => {
      try { unsubscribe?.(); } catch { /* route cleanup must stay non-fatal */ }
    });
    domCleanups.splice(0).forEach((dispose) => {
      try { dispose?.(); } catch { /* route cleanup must stay non-fatal */ }
    });
    if (removePage && page.isConnected) page.remove();
    if (activeController === controller) activeController = null;
    if (activeCleanup === cleanup) activeCleanup = null;
  }

  activeController = controller;
  activeCleanup = cleanup;

  renderAll(state);

  if (options.initialContext) {
    const initialContext = correlateInitialContext(options.initialContext);
    state.requestIds.init = getResponseRequestId(initialContext);
    receive(CAD_CIRCLE_EVENTS.context, initialContext);
  }
  while (queuedHostMessages.length) {
    const message = queuedHostMessages.shift();
    receive(message.ev, message.payload);
  }
  if (options.autoInit !== false && !state.contextLoaded) requestInit(state, options);

  return controller;
}

export const mountCadCirclePlacement = renderCadCirclePlacement;

export function receiveCadCircleMessage(eventOrMessage, optionalPayload) {
  const message = normalizeIncomingMessage(eventOrMessage, optionalPayload);
  if (!message.ev) return false;
  if (activeController) return activeController.receive(message.ev, message.payload);
  queuedHostMessages.push(message);
  if (queuedHostMessages.length > 20) queuedHostMessages.shift();
  return true;
}

export function destroyCadCirclePlacement() {
  activeController?.destroy();
}

function createState(options) {
  return {
    page: null,
    ui: {},
    options,
    contextLoaded: false,
    context: {
      document: {},
      unitLabel: 'mm',
      links: [],
      levels: [],
      families: [],
      parameters: [],
      defaults: {}
    },
    linkConfig: new Map(),
    layerRequests: new Map(),
    layerStatus: new Map(),
    layerErrors: new Map(),
    familyKey: '',
    typeKey: '',
    diameterParameterKey: '',
    heightParameterKey: '',
    sourceLayerParameterKey: '',
    tolerance: { ...DEFAULT_TOLERANCE },
    existingPolicy: 'skip',
    candidates: [],
    selectedCandidates: new Set(),
    scanId: '',
    previewSummary: {},
    previewMessage: '',
    filter: {
      query: '',
      linkKey: '',
      layerKey: '',
      status: 'accepted',
      page: 1,
      pageSize: DEFAULT_PAGE_SIZE
    },
    result: null,
    busy: '',
    requestIds: { init: '', scan: '', apply: '' },
    statusMessage: '프로젝트 정보를 불러오는 중입니다.',
    lastError: null
  };
}

function buildPageMarkup() {
  return `
    <header class="feature-header cadcircle-header">
      <div class="feature-heading cadcircle-heading">
        <span class="feature-kicker">CAD 링크 · 자동 모델링</span>
        <h2 class="feature-title">CAD link 기반 Foreline 모델링</h2>
        <p class="feature-sub">CAD 링크의 원형 geometry를 레이어별로 검출하고 선택한 레벨에 패밀리를 배치합니다.</p>
      </div>
      <div class="feature-actions cadcircle-header-actions">
        <button type="button" class="btn btn-outline" data-action="reload-context">프로젝트 새로고침</button>
      </div>
    </header>

    <div class="cadcircle-workspace">
      <main class="cadcircle-main">
        <section class="cadcircle-card cadcircle-card--setup" aria-labelledby="cadcircle-setup-title">
          <div class="cadcircle-card-head">
            <div>
              <span class="cadcircle-step">01 · 설정</span>
              <h3 id="cadcircle-setup-title">CAD 링크와 배치 기준</h3>
              <p>링크별 레이어를 고르고, 배치할 레벨과 높이를 지정합니다.</p>
            </div>
            <span class="cadcircle-state-pill" data-ref="context-state">대기</span>
          </div>

          <div class="cadcircle-section">
            <div class="cadcircle-section-head">
              <div>
                <h4>CAD 링크 · 레이어 · 레벨</h4>
                <p>같은 CAD 파일이 여러 번 배치된 경우 링크 인스턴스별로 설정할 수 있습니다.</p>
              </div>
              <span class="cadcircle-count" data-ref="link-count">0개</span>
            </div>
            <div class="cadcircle-link-list" data-ref="link-list" aria-live="polite"></div>
          </div>

          <div class="cadcircle-divider" role="presentation"></div>

          <div class="cadcircle-section">
            <div class="cadcircle-section-head">
              <div>
                <h4>패밀리와 파라미터 매핑</h4>
                <p>직경·높이와 원본 CAD 레이어명을 패밀리 인스턴스 파라미터에 입력합니다.</p>
              </div>
            </div>
            <div class="cadcircle-field-grid cadcircle-field-grid--mapping">
              <label class="cadcircle-field">
                <span>패밀리</span>
                <select data-ref="family-select" aria-label="대상 패밀리"></select>
              </label>
              <label class="cadcircle-field">
                <span>타입</span>
                <select data-ref="type-select" aria-label="대상 패밀리 타입"></select>
              </label>
              <label class="cadcircle-field">
                <span>Diameter 파라미터</span>
                <select data-ref="diameter-parameter" aria-label="직경 매핑 파라미터"></select>
              </label>
              <label class="cadcircle-field">
                <span>Height 파라미터</span>
                <select data-ref="height-parameter" aria-label="높이 매핑 파라미터"></select>
              </label>
              <label class="cadcircle-field">
                <span>CAD 레이어 파라미터</span>
                <select data-ref="source-layer-parameter" aria-label="CAD 원본 레이어명 매핑 파라미터"></select>
              </label>
            </div>
            <p class="cadcircle-inline-note">Diameter와 Height에는 쓰기 가능한 인스턴스 Length 파라미터만, CAD 레이어에는 쓰기 가능한 인스턴스 Text 파라미터만 표시됩니다.</p>
          </div>

          <details class="cadcircle-advanced">
            <summary>원 검출 허용오차와 범위</summary>
            <div class="cadcircle-field-grid cadcircle-field-grid--tolerance">
              <label class="cadcircle-field">
                <span>끝점 연결 허용오차 <small>mm</small></span>
                <input type="number" min="0.01" max="100" step="0.1" data-setting="endpointMm">
              </label>
              <label class="cadcircle-field">
                <span>평면 이탈 허용오차 <small>mm</small></span>
                <input type="number" min="0.01" max="100" step="0.1" data-setting="planeMm">
              </label>
              <label class="cadcircle-field">
                <span>원형도 절대오차 <small>mm</small></span>
                <input type="number" min="0.01" max="100" step="0.1" data-setting="fitAbsoluteMm">
              </label>
              <label class="cadcircle-field">
                <span>원형도 상대오차 <small>%</small></span>
                <input type="number" min="0.01" max="20" step="0.1" data-setting="fitRelativePercent">
              </label>
              <label class="cadcircle-field">
                <span>수평 각도 허용오차 <small>°</small></span>
                <input type="number" min="0.01" max="45" step="0.1" data-setting="horizontalAngleDeg">
              </label>
              <label class="cadcircle-field">
                <span>중복 중심 허용오차 <small>mm</small></span>
                <input type="number" min="0.01" max="100" step="0.1" data-setting="duplicateCenterMm">
              </label>
              <label class="cadcircle-field">
                <span>중복 직경 허용오차 <small>mm</small></span>
                <input type="number" min="0.01" max="100" step="0.1" data-setting="duplicateDiameterMm">
              </label>
              <label class="cadcircle-field">
                <span>최소 직경 <small>mm</small></span>
                <input type="number" min="0" step="1" data-setting="minimumDiameterMm">
              </label>
              <label class="cadcircle-field">
                <span>최대 직경 <small>mm · 비우면 제한 없음</small></span>
                <input type="number" min="0" step="1" data-setting="maximumDiameterMm">
              </label>
              <label class="cadcircle-field">
                <span>최소 직선 세그먼트 <small>개</small></span>
                <input type="number" min="4" max="4096" step="1" data-setting="minimumStraightSegments">
              </label>
              <label class="cadcircle-field">
                <span>최소 원주 범위 <small>°</small></span>
                <input type="number" min="180" max="360" step="1" data-setting="minimumCoverageDegrees">
              </label>
              <label class="cadcircle-field">
                <span>최대 각도 공백 <small>°</small></span>
                <input type="number" min="1" max="180" step="1" data-setting="maximumAngularGapDegrees">
              </label>
            </div>
          </details>

          <div class="cadcircle-setup-actions">
            <p class="cadcircle-action-note" data-ref="scan-note">링크와 레이어를 선택하면 스캔할 수 있습니다.</p>
            <button type="button" class="btn btn-primary cadcircle-scan-button" data-action="scan">원형 스캔</button>
          </div>
        </section>

        <section class="cadcircle-card cadcircle-card--preview" aria-labelledby="cadcircle-preview-title">
          <div class="cadcircle-card-head cadcircle-card-head--preview">
            <div>
              <span class="cadcircle-step">02 · 미리보기</span>
              <h3 id="cadcircle-preview-title">검출 후보 검토</h3>
              <p data-ref="preview-message">스캔 전입니다. 적용 전에 중심 좌표와 직경을 검토할 수 있습니다.</p>
            </div>
            <div class="cadcircle-preview-actions">
              <button type="button" class="btn btn-outline btn-sm" data-action="select-visible">현재 목록 선택</button>
              <button type="button" class="btn btn-ghost btn-sm" data-action="clear-selection">선택 해제</button>
            </div>
          </div>

          <div class="cadcircle-metrics" data-ref="preview-metrics"></div>

          <div class="cadcircle-preview-toolbar">
            <label class="cadcircle-search">
              <span class="sr-only">후보 검색</span>
              <input type="search" data-ref="candidate-search" placeholder="레이어, 링크, 후보 ID 검색">
            </label>
            <select data-ref="candidate-link-filter" aria-label="링크 필터"></select>
            <select data-ref="candidate-layer-filter" aria-label="레이어 필터"></select>
            <select data-ref="candidate-status-filter" aria-label="검출 상태 필터">
              <option value="accepted">사용 가능</option>
              <option value="selected">선택됨</option>
              <option value="rejected">제외됨</option>
              <option value="all">전체</option>
            </select>
          </div>

          <div class="cadcircle-table-wrap" data-ref="candidate-table-wrap">
            <table class="cadcircle-table">
              <thead>
                <tr>
                  <th class="cadcircle-cell-check"><span class="sr-only">선택</span></th>
                  <th>상태</th>
                  <th>링크 / 레이어</th>
                  <th>X</th>
                  <th>Y</th>
                  <th>Z</th>
                  <th>Diameter</th>
                  <th>표현</th>
                  <th>검출 품질</th>
                </tr>
              </thead>
              <tbody data-ref="candidate-body"></tbody>
            </table>
          </div>

          <div class="cadcircle-pagination">
            <span data-ref="candidate-range">0개</span>
            <div>
              <label>
                <span class="sr-only">페이지당 표시 개수</span>
                <select data-ref="page-size">
                  <option value="50">50개씩</option>
                  <option value="100" selected>100개씩</option>
                  <option value="250">250개씩</option>
                  <option value="500">500개씩</option>
                </select>
              </label>
              <button type="button" class="btn btn-ghost btn-sm" data-action="previous-page">이전</button>
              <span data-ref="page-label">1 / 1</span>
              <button type="button" class="btn btn-ghost btn-sm" data-action="next-page">다음</button>
            </div>
          </div>
        </section>
      </main>

      <aside class="cadcircle-card cadcircle-card--run" aria-labelledby="cadcircle-run-title">
        <div class="cadcircle-card-head">
          <div>
            <span class="cadcircle-step">03 · 실행</span>
            <h3 id="cadcircle-run-title">검증 후 배치</h3>
            <p>선택한 후보만 현재 Revit 프로젝트에 생성합니다.</p>
          </div>
        </div>

        <div class="cadcircle-validation" data-ref="validation" aria-live="polite"></div>

        <label class="cadcircle-field">
          <span>기존 배치 인스턴스 처리</span>
          <select data-ref="existing-policy">
            <option value="skip">동일 출처는 건너뛰기</option>
            <option value="create">항상 새로 생성</option>
          </select>
        </label>

        <button type="button" class="btn btn-primary cadcircle-apply-button" data-action="apply">선택 후보 배치</button>
        <p class="cadcircle-run-status" data-ref="run-status" role="status">프로젝트 정보를 확인하고 있습니다.</p>

        <div class="cadcircle-divider" role="presentation"></div>

        <section class="cadcircle-result" aria-labelledby="cadcircle-result-title">
          <div class="cadcircle-section-head">
            <div>
              <h4 id="cadcircle-result-title">실행 결과</h4>
              <p>생성·갱신·건너뜀·실패를 구분해 표시합니다.</p>
            </div>
          </div>
          <div data-ref="result-surface"></div>
        </section>
      </aside>
    </div>
  `;
}

function collectUi(page) {
  const refs = {};
  page.querySelectorAll('[data-ref]').forEach((element) => {
    refs[element.dataset.ref] = element;
  });
  return refs;
}

function bindUi(state, options, domCleanups = []) {
  const interactionRoot = state.interactionRoot || state.page;
  const handleClick = (event) => {
    const actionElement = event.target.closest('[data-action]');
    if (!actionElement || !interactionRoot.contains(actionElement)) return;
    const action = actionElement.dataset.action;

    switch (action) {
      case 'reload-context':
        requestInit(state, options);
        break;
      case 'scan':
        requestScan(state, options);
        break;
      case 'apply':
        requestApply(state, options);
        break;
      case 'select-all-layers':
      case 'clear-all-layers': {
        const linkKey = actionElement.closest('[data-link-key]')?.dataset.linkKey || '';
        const config = state.linkConfig.get(linkKey);
        const link = findLink(state, linkKey);
        if (!config || !link) return;
        config.layerKeys = action === 'select-all-layers'
          ? new Set(link.layers.filter((layer) => layer.available !== false).map((layer) => layer.key))
          : new Set();
        renderLinks(state);
        invalidatePreview(state, '레이어 설정이 변경되었습니다. 다시 스캔해 주세요.');
        break;
      }
      case 'select-visible':
        getFilteredCandidates(state).forEach((candidate) => {
          if (candidate.selectable) state.selectedCandidates.add(candidate.key);
        });
        renderPreview(state);
        renderValidation(state);
        break;
      case 'clear-selection':
        state.selectedCandidates.clear();
        renderPreview(state);
        renderValidation(state);
        break;
      case 'previous-page':
        state.filter.page = Math.max(1, state.filter.page - 1);
        renderCandidateRows(state);
        break;
      case 'next-page': {
        const count = getFilteredCandidates(state).length;
        const pageCount = Math.max(1, Math.ceil(count / state.filter.pageSize));
        state.filter.page = Math.min(pageCount, state.filter.page + 1);
        renderCandidateRows(state);
        break;
      }
      default:
        break;
    }
    notifyState(state, options);
  };
  interactionRoot.addEventListener('click', handleClick);
  domCleanups.push(() => interactionRoot.removeEventListener('click', handleClick));

  const handleChange = (event) => {
    const element = event.target;
    if (!(element instanceof HTMLElement)) return;

    if (element.matches('[data-link-enabled]')) {
      const linkKey = element.dataset.linkEnabled || '';
      const config = state.linkConfig.get(linkKey);
      if (config) config.enabled = element.checked === true;
      invalidatePreview(state, 'CAD 링크 선택이 변경되었습니다. 다시 스캔해 주세요.');
      if (config?.enabled) requestLinkLayers(state, options, linkKey, false);
    } else if (element.matches('[data-link-level]')) {
      const config = state.linkConfig.get(element.dataset.linkLevel || '');
      if (config) config.levelKey = String(element.value || '');
      renderValidation(state);
    } else if (element.matches('[data-link-height]')) {
      const config = state.linkConfig.get(element.dataset.linkHeight || '');
      if (config) config.height = nullableNumber(element.value);
      renderValidation(state);
    } else if (element.matches('[data-layer-key]')) {
      const config = state.linkConfig.get(element.dataset.layerLink || '');
      if (config) {
        if (element.checked) config.layerKeys.add(element.dataset.layerKey || '');
        else config.layerKeys.delete(element.dataset.layerKey || '');
      }
      invalidatePreview(state, 'CAD 레이어 선택이 변경되었습니다. 다시 스캔해 주세요.');
    } else if (element === state.ui['family-select']) {
      state.familyKey = String(element.value || '');
      state.typeKey = '';
      state.diameterParameterKey = '';
      state.heightParameterKey = '';
      state.sourceLayerParameterKey = '';
      renderFamilyMapping(state);
      renderValidation(state);
    } else if (element === state.ui['type-select']) {
      state.typeKey = String(element.value || '');
      state.diameterParameterKey = '';
      state.heightParameterKey = '';
      state.sourceLayerParameterKey = '';
      renderFamilyMapping(state);
      renderValidation(state);
    } else if (element === state.ui['diameter-parameter']) {
      state.diameterParameterKey = String(element.value || '');
      renderValidation(state);
    } else if (element === state.ui['height-parameter']) {
      state.heightParameterKey = String(element.value || '');
      renderValidation(state);
    } else if (element === state.ui['source-layer-parameter']) {
      state.sourceLayerParameterKey = String(element.value || '');
      renderValidation(state);
    } else if (element.matches('[data-setting]')) {
      const key = element.dataset.setting;
      state.tolerance[key] = element.type === 'checkbox' ? element.checked : nullableNumber(element.value);
      invalidatePreview(state, '검출 허용오차가 변경되었습니다. 다시 스캔해 주세요.');
    } else if (element.matches('[data-candidate-key]')) {
      const key = element.dataset.candidateKey || '';
      if (element.checked) state.selectedCandidates.add(key);
      else state.selectedCandidates.delete(key);
      renderPreviewMetrics(state);
      renderValidation(state);
    } else if (element === state.ui['candidate-link-filter']) {
      state.filter.linkKey = String(element.value || '');
      state.filter.layerKey = '';
      state.filter.page = 1;
      renderPreviewFilters(state);
      renderCandidateRows(state);
    } else if (element === state.ui['candidate-layer-filter']) {
      state.filter.layerKey = String(element.value || '');
      state.filter.page = 1;
      renderCandidateRows(state);
    } else if (element === state.ui['candidate-status-filter']) {
      state.filter.status = String(element.value || 'accepted');
      state.filter.page = 1;
      renderCandidateRows(state);
    } else if (element === state.ui['page-size']) {
      state.filter.pageSize = Math.max(1, Number(element.value) || DEFAULT_PAGE_SIZE);
      state.filter.page = 1;
      renderCandidateRows(state);
    } else if (element === state.ui['existing-policy']) {
      state.existingPolicy = String(element.value || 'skip');
    }
    updateActionState(state);
    notifyState(state, options);
  };
  interactionRoot.addEventListener('change', handleChange);
  domCleanups.push(() => interactionRoot.removeEventListener('change', handleChange));

  state.ui['candidate-search']?.addEventListener('input', (event) => {
    state.filter.query = String(event.target.value || '').trim().toLocaleLowerCase();
    state.filter.page = 1;
    renderCandidateRows(state);
  });
}

function requestInit(state, options) {
  if (state.busy) return false;
  const requestId = createRequestId('init');
  resetLayerRequestState(state);
  state.requestIds.scan = '';
  state.requestIds.apply = '';
  resetPreviewAndResult(state);
  state.requestIds.init = requestId;
  state.busy = 'init';
  state.lastError = null;
  state.statusMessage = '현재 프로젝트의 CAD 링크, 레벨, 패밀리를 불러오는 중입니다.';
  renderAll(state);
  return sendHostRequest(state, options, CAD_CIRCLE_EVENTS.init, {
    schemaVersion: SCHEMA_VERSION,
    requestId,
    client: {
      feature: 'cad-circle-placement',
      supportsMultipleLinks: true,
      supportsCandidateSelection: true,
      expectedCoordinateSpace: 'host-revit-internal'
    }
  });
}

function requestLinkLayers(state, options, linkKey, force = false) {
  if (!state.contextLoaded || state.busy === 'init' || state.busy === 'apply') return false;
  const link = findLink(state, linkKey);
  if (!link || link.available === false) return false;

  const pendingRequestId = state.layerRequests.get(link.key) || '';
  const status = state.layerStatus.get(link.key) || '';
  if (!force && (pendingRequestId || status === 'loaded')) return false;

  const requestId = createRequestId('layers');
  state.layerRequests.set(link.key, requestId);
  state.layerStatus.set(link.key, 'loading');
  state.layerErrors.delete(link.key);
  renderLinks(state);
  updateActionState(state);

  const payload = {
    requestId,
    selectedDocument: buildSelectedDocumentPayload(state),
    selectedDocumentExplicit: true,
    linkElementId: link.hostId ?? link.key
  };

  let sent = true;
  try {
    options.onRequest?.({ ev: CAD_CIRCLE_EVENTS.layers, payload });
    window.dispatchEvent(new CustomEvent('cadcircle:ui-request', {
      detail: { ev: CAD_CIRCLE_EVENTS.layers, payload }
    }));
    const sender = typeof options.postMessage === 'function' ? options.postMessage : post;
    sent = sender(CAD_CIRCLE_EVENTS.layers, payload) !== false;
  } catch (error) {
    sent = false;
    console.error(`[cadcircle] ${CAD_CIRCLE_EVENTS.layers} request failed`, error);
  }

  if (!sent && state.layerRequests.get(link.key) === requestId) {
    state.layerRequests.delete(link.key);
    state.layerStatus.set(link.key, 'error');
    state.layerErrors.set(link.key, 'CAD 레이어 조회 요청을 Revit 호스트로 보내지 못했습니다.');
    renderLinks(state);
    updateActionState(state);
    toast(state.layerErrors.get(link.key), 'err', 3600);
  }
  return sent;
}

function requestEnabledLinkLayers(state, options, force = false) {
  state.context.links.forEach((link) => {
    if (state.linkConfig.get(link.key)?.enabled) requestLinkLayers(state, options, link.key, force);
  });
}

function resetLayerRequestState(state) {
  state.layerRequests.clear();
  state.layerStatus.clear();
  state.layerErrors.clear();
}

function requestScan(state, options) {
  if (state.busy) return false;
  const validation = validateState(state, 'scan');
  if (validation.errors.length) {
    renderValidation(state, validation);
    toast(validation.errors[0], 'err', 3600);
    return false;
  }

  const requestId = createRequestId('scan');
  state.requestIds.scan = requestId;
  state.busy = 'scan';
  state.lastError = null;
  state.result = null;
  state.statusMessage = '선택한 CAD 링크와 레이어에서 원형 geometry를 분석하고 있습니다.';
  renderAll(state);
  return sendHostRequest(state, options, CAD_CIRCLE_EVENTS.scan, buildScanPayload(state, requestId));
}

function requestApply(state, options) {
  if (state.busy) return false;
  const validation = validateState(state, 'apply');
  if (validation.errors.length) {
    renderValidation(state, validation);
    toast(validation.errors[0], 'err', 3800);
    return false;
  }

  const requestId = createRequestId('apply');
  state.requestIds.apply = requestId;
  state.busy = 'apply';
  state.lastError = null;
  state.result = null;
  state.statusMessage = `선택한 원형 후보 ${state.selectedCandidates.size}개를 배치하고 있습니다.`;
  renderAll(state);
  return sendHostRequest(state, options, CAD_CIRCLE_EVENTS.apply, buildApplyPayload(state, requestId));
}

function sendHostRequest(state, options, eventName, payload) {
  let sent = true;
  try {
    options.onRequest?.({ ev: eventName, payload });
    window.dispatchEvent(new CustomEvent('cadcircle:ui-request', { detail: { ev: eventName, payload } }));
    const sender = typeof options.postMessage === 'function' ? options.postMessage : post;
    sent = sender(eventName, payload) !== false;
  } catch (error) {
    sent = false;
    console.error(`[cadcircle] ${eventName} request failed`, error);
  }

  if (!sent) {
    const operation = requestOperationFromEvent(eventName);
    if (operation) state.requestIds[operation] = '';
    state.busy = '';
    state.lastError = { message: 'Revit 호스트로 요청을 보내지 못했습니다.' };
    state.statusMessage = state.lastError.message;
    renderAll(state);
    toast(state.lastError.message, 'err', 3600);
  }
  return sent;
}

function buildScanPayload(state, requestId) {
  const type = findType(state, state.typeKey);
  const enabledLinks = state.context.links.filter((link) => state.linkConfig.get(link.key)?.enabled);
  const layerKeys = uniqueHostValues(enabledLinks.flatMap((link) => {
    const config = state.linkConfig.get(link.key);
    return link.layers
      .filter((layer) => config?.layerKeys.has(layer.key))
      .map((layer) => layer.hostId ?? layer.name);
  }));
  return {
    requestId,
    selectedDocument: buildSelectedDocumentPayload(state),
    selectedDocumentExplicit: true,
    linkElementIds: enabledLinks.map((link) => link.hostId ?? link.key),
    layerKeys,
    linkSelections: enabledLinks.map((link) => {
      const config = state.linkConfig.get(link.key);
      return {
        linkElementId: link.hostId ?? link.key,
        layerKeys: uniqueHostValues(link.layers
          .filter((layer) => config?.layerKeys.has(layer.key))
          .map((layer) => layer.hostId ?? layer.name))
      };
    }),
    familySymbolElementId: type?.hostId ?? state.typeKey,
    tolerance: buildTolerancePayload(state),
    includeRejected: true
  };
}

function buildApplyPayload(state, requestId) {
  const selected = state.candidates.filter((candidate) => state.selectedCandidates.has(candidate.key));
  const type = findType(state, state.typeKey);
  const diameterParameter = findParameter(state, state.diameterParameterKey);
  const heightParameter = findParameter(state, state.heightParameterKey);
  const sourceLayerParameter = findTextParameter(state, state.sourceLayerParameterKey);
  const rules = state.context.links
    .filter((link) => state.linkConfig.get(link.key)?.enabled)
    .map((link) => {
      const config = state.linkConfig.get(link.key);
      const candidates = selected.filter((candidate) => (
        candidate.linkKey === link.key || idEquals(candidate.linkHostId, link.hostId)
      ));
      const layers = link.layers.filter((layer) => config?.layerKeys.has(layer.key));
      return {
        linkElementId: link.hostId ?? link.key,
        layerKeys: uniqueHostValues(layers.map((layer) => layer.hostId ?? layer.name)),
        candidateIds: candidates.map((candidate) => candidate.hostId ?? candidate.key),
        familySymbolElementId: type?.hostId ?? state.typeKey,
        baseLevelElementId: findLevel(state, config?.levelKey)?.hostId ?? config?.levelKey,
        heightMillimeters: config?.height,
        diameterParameterKey: diameterParameter?.hostKey ?? state.diameterParameterKey,
        heightParameterKey: heightParameter?.hostKey ?? state.heightParameterKey,
        sourceLayerParameterKey: sourceLayerParameter?.hostKey ?? state.sourceLayerParameterKey
      };
    })
    .filter((rule) => rule.candidateIds.length > 0);

  return {
    requestId,
    selectedDocument: buildSelectedDocumentPayload(state),
    selectedDocumentExplicit: true,
    rules,
    tolerance: buildTolerancePayload(state),
    skipExisting: state.existingPolicy === 'skip'
  };
}

function buildLinkPayloads(state, includePlacement) {
  return state.context.links
    .filter((link) => state.linkConfig.get(link.key)?.enabled)
    .map((link) => {
      const config = state.linkConfig.get(link.key);
      const level = findLevel(state, config.levelKey);
      const layers = link.layers.filter((layer) => config.layerKeys.has(layer.key));
      const payload = {
        linkId: link.hostId ?? link.key,
        linkUniqueId: link.uniqueId || null,
        linkName: link.name,
        layerIds: layers.map((layer) => layer.hostId ?? layer.key),
        layerNames: layers.map((layer) => layer.name)
      };
      if (includePlacement) {
        payload.placement = {
          levelId: level?.hostId ?? config.levelKey,
          levelName: level?.name || '',
          levelProjectElevation: level?.projectElevation ?? null,
          height: config.height,
          heightUnit: 'mm',
          useCadZ: false
        };
      }
      return payload;
    });
}

function buildSelectedDocumentPayload(state) {
  const documentInfo = objectFrom(state.context.document);
  const name = readString(documentInfo, ['name', 'title'], '');
  return {
    name,
    title: readString(documentInfo, ['title', 'name'], name),
    path: readString(documentInfo, ['path', 'filePath'], '')
  };
}

function buildTolerancePayload(state) {
  const value = state.tolerance;
  return {
    endpointMillimeters: value.endpointMm,
    planeMillimeters: value.planeMm,
    horizontalAngleDegrees: value.horizontalAngleDeg,
    absoluteRadialMillimeters: value.fitAbsoluteMm,
    relativeRadialRatio: Number(value.fitRelativePercent) / 100,
    minimumLineSegments: value.minimumStraightSegments,
    minimumDiameterMillimeters: value.minimumDiameterMm,
    maximumDiameterMillimeters: value.maximumDiameterMm,
    duplicateCenterMillimeters: value.duplicateCenterMm,
    duplicateDiameterMillimeters: value.duplicateDiameterMm,
    minimumCoverageDegrees: value.minimumCoverageDegrees,
    maximumAngularGapDegrees: value.maximumAngularGapDegrees
  };
}

function parameterPayload(parameter, fallbackKey) {
  if (!parameter) return { key: fallbackKey || null };
  return {
    key: parameter.hostKey ?? parameter.key,
    id: parameter.hostId ?? null,
    guid: parameter.guid || null,
    name: parameter.name,
    scope: parameter.scope || 'instance',
    dataType: parameter.dataType || 'Length'
  };
}

function handleContext(state, payload, options = {}) {
  if (isStaleResponse(payload, state.requestIds.init)) return;
  const context = normalizeContext(payload);
  if (context.ok === false) {
    handleError(state, payload, 'init');
    return;
  }

  const sameDocument = documentIdentityMatches(state.context.document, context.document);
  const previousLinks = state.context.links;
  state.requestIds.init = '';
  state.requestIds.scan = '';
  state.requestIds.apply = '';
  resetLayerRequestState(state);
  resetPreviewAndResult(state);
  if (!sameDocument) resetDocumentMapping(state);
  else carryForwardLinkLayers(context.links, previousLinks);
  state.context = context;
  state.contextLoaded = true;
  state.busy = '';
  state.lastError = null;
  state.statusMessage = context.message || '프로젝트 정보를 불러왔습니다.';
  mergeToleranceDefaults(state, context.defaults?.tolerance || context.tolerance);
  mergeLinkConfiguration(state);
  applyDefaultFamilyMapping(state);
  renderAll(state);
  requestEnabledLinkLayers(state, options, true);
}

function handleLayersResult(state, payload) {
  const result = normalizeLayerDiscoveryResult(payload, state);
  const link = result.link;
  if (!link) return;

  const expectedRequestId = state.layerRequests.get(link.key) || '';
  if (isStaleResponse(payload, expectedRequestId)) return;
  state.layerRequests.delete(link.key);

  if (result.ok === false) {
    state.layerStatus.set(link.key, 'error');
    state.layerErrors.set(link.key, result.message || 'CAD 레이어를 불러오지 못했습니다.');
    renderLinks(state);
    renderValidation(state);
    updateActionState(state);
    toast(state.layerErrors.get(link.key), 'err', 3600);
    return;
  }

  const selectionChanged = replaceLinkLayers(state, link, result.layers);
  state.layerStatus.set(link.key, 'loaded');
  state.layerErrors.delete(link.key);
  if (selectionChanged && (state.scanId || state.candidates.length)) {
    invalidatePreview(state, `${link.name}: 레이어 구성이 변경되었습니다. 다시 스캔해 주세요.`);
  } else {
    renderLinks(state);
    renderValidation(state);
    updateActionState(state);
  }
}

function handlePreview(state, payload) {
  if (isStaleResponse(payload, state.requestIds.scan)) return;
  const preview = normalizePreview(payload, state);
  if (preview.ok === false) {
    handleError(state, payload, 'scan');
    return;
  }

  state.requestIds.scan = '';
  state.busy = '';
  state.lastError = null;
  state.scanId = preview.scanId;
  state.candidates = preview.candidates;
  state.previewSummary = preview.summary;
  state.previewMessage = preview.message
    || (preview.discoveredLayerCount && !preview.candidates.length
      ? `CAD 레이어 ${preview.discoveredLayerCount}개를 발견했습니다. 배치할 레이어를 선택한 뒤 다시 스캔해 주세요.`
      : `원형 후보 ${preview.candidates.length}개를 검출했습니다.`);
  state.selectedCandidates = new Set(
    preview.candidates
      .filter((candidate) => candidate.selectable && candidate.selected !== false)
      .map((candidate) => candidate.key)
  );
  state.filter.page = 1;
  state.result = null;
  state.statusMessage = state.previewMessage;
  renderAll(state);
  toast(
    state.previewMessage,
    preview.candidates.some((item) => item.selectable) || preview.discoveredLayerCount ? 'ok' : 'err',
    3200
  );
}

function handleResult(state, payload) {
  if (isStaleResponse(payload, state.requestIds.apply)) return;
  const result = normalizeResult(payload);
  state.requestIds.apply = '';
  state.busy = '';
  state.lastError = result.ok === false ? { message: result.message } : null;
  state.result = result;
  state.statusMessage = result.message || (result.ok === false ? '패밀리 배치에 실패했습니다.' : '패밀리 배치가 완료되었습니다.');
  renderAll(state);
  toast(state.statusMessage, result.ok === false ? 'err' : 'ok', 3800);
}

function handleError(state, payload, operationHint = '') {
  const normalized = normalizeError(payload);
  const operation = normalizeRequestOperation(operationHint || normalized.operation || state.busy);
  if (operation === 'layers') {
    handleLayerRequestError(state, payload, normalized);
    return;
  }
  const expectedRequestId = operation ? state.requestIds[operation] : '';
  if (!operation || isStaleResponse(payload, expectedRequestId)) return;
  state.requestIds[operation] = '';
  if (operation === 'init') state.contextLoaded = false;
  state.busy = '';
  state.lastError = normalized;
  state.statusMessage = normalized.message;
  renderAll(state);
  toast(normalized.message, 'err', 4200);
}

function handleLayerRequestError(state, payload, normalized) {
  const requestId = normalized.requestId || getResponseRequestId(payload);
  if (!requestId) return;
  const envelope = objectFrom(payload);
  const source = objectFrom(envelope.error || envelope.data || envelope);
  const linkElementId = readAny(source, ['linkElementId', 'linkId', 'importInstanceId'])
    ?? readAny(envelope, ['linkElementId', 'linkId', 'importInstanceId']);
  const link = state.context.links.find((item) => idEquals(item.hostId, linkElementId))
    || state.context.links.find((item) => state.layerRequests.get(item.key) === requestId)
    || null;
  if (!link || state.layerRequests.get(link.key) !== requestId) return;

  state.layerRequests.delete(link.key);
  state.layerStatus.set(link.key, 'error');
  state.layerErrors.set(link.key, normalized.message || 'CAD 레이어를 불러오지 못했습니다.');
  renderLinks(state);
  renderValidation(state);
  updateActionState(state);
  toast(state.layerErrors.get(link.key), 'err', 4200);
}

function handleDocumentChanged(state, payload, options) {
  const incomingDocument = objectFrom(payload);
  if (state.contextLoaded && documentIdentityMatches(state.context.document, incomingDocument)) return;

  state.requestIds.init = '';
  state.requestIds.scan = '';
  state.requestIds.apply = '';
  resetLayerRequestState(state);
  state.busy = '';
  state.contextLoaded = false;
  resetPreviewAndResult(state);
  resetDocumentMapping(state);
  state.context = {
    document: incomingDocument,
    unitLabel: 'mm',
    links: [],
    levels: [],
    families: [],
    parameters: [],
    defaults: {}
  };
  state.lastError = null;
  state.statusMessage = '활성 프로젝트가 변경되어 정보를 다시 불러오는 중입니다.';
  renderAll(state);

  window.setTimeout(() => {
    if (state.page?.isConnected && !state.busy && !state.contextLoaded) requestInit(state, options);
  }, 0);
}

function resetPreviewAndResult(state) {
  state.candidates = [];
  state.selectedCandidates.clear();
  state.scanId = '';
  state.previewSummary = {};
  state.previewMessage = '';
  state.result = null;
  state.filter = {
    query: '',
    linkKey: '',
    layerKey: '',
    status: 'accepted',
    page: 1,
    pageSize: DEFAULT_PAGE_SIZE
  };
}

function resetDocumentMapping(state) {
  state.linkConfig.clear();
  resetLayerRequestState(state);
  state.familyKey = '';
  state.typeKey = '';
  state.diameterParameterKey = '';
  state.heightParameterKey = '';
  state.sourceLayerParameterKey = '';
}

function renderAll(state) {
  renderContextState(state);
  renderLinks(state);
  renderFamilyMapping(state);
  renderTolerance(state);
  renderPreview(state);
  renderValidation(state);
  renderResult(state);
  updateActionState(state);
}

function renderContextState(state) {
  const pill = state.ui['context-state'];
  if (!pill) return;
  pill.className = 'cadcircle-state-pill';
  if (state.busy === 'init') {
    pill.textContent = '불러오는 중';
    pill.classList.add('is-busy');
  } else if (state.lastError && !state.contextLoaded) {
    pill.textContent = '오류';
    pill.classList.add('is-error');
  } else if (state.contextLoaded) {
    pill.textContent = '준비됨';
    pill.classList.add('is-ready');
  } else {
    pill.textContent = '대기';
  }
  if (state.ui['link-count']) state.ui['link-count'].textContent = `${state.context.links.length}개`;
}

function renderLinks(state) {
  const container = state.ui['link-list'];
  if (!container) return;
  const links = state.context.links;
  if (!state.contextLoaded) {
    container.innerHTML = emptyMarkup('프로젝트 정보를 기다리고 있습니다.');
    return;
  }
  if (!links.length) {
    container.innerHTML = emptyMarkup('현재 프로젝트에서 사용 가능한 CAD 링크를 찾지 못했습니다.');
    return;
  }

  container.innerHTML = links.map((link) => {
    const config = state.linkConfig.get(link.key) || createLinkConfig(link, state, false);
    const disabled = link.available === false;
    const layerStatus = state.layerStatus.get(link.key) || '';
    const layersLoading = layerStatus === 'loading';
    const layersFailed = layerStatus === 'error';
    const controlsDisabled = disabled || Boolean(state.busy);
    const levelOptions = [
      '<option value="">레벨 선택</option>',
      ...state.context.levels.map((level) => optionMarkup(
        level.key,
        level.elevationDisplay ? `${level.name} · ${level.elevationDisplay}` : level.name,
        config.levelKey === level.key
      ))
    ].join('');
    const layers = link.layers.length
      ? link.layers.map((layer) => {
        const checked = config.layerKeys.has(layer.key);
        const layerDisabled = layer.available === false;
        const count = layer.detectedCount ?? layer.primitiveCount ?? layer.count;
        return `
          <label class="cadcircle-layer ${layerDisabled ? 'is-disabled' : ''}">
            <input type="checkbox"
                   data-layer-link="${escapeAttr(link.key)}"
                   data-layer-key="${escapeAttr(layer.key)}"
                   ${checked ? 'checked' : ''}
                   ${layerDisabled || !config.enabled || layersLoading || controlsDisabled ? 'disabled' : ''}>
            <span title="${escapeAttr(layer.name)}">${escapeHtml(layer.name)}</span>
            ${count == null ? '' : `<small>${formatInteger(count)}</small>`}
          </label>`;
      }).join('')
      : emptyMarkup(
        layersLoading
          ? 'CAD 레이어를 불러오는 중입니다.'
          : (layersFailed
            ? (state.layerErrors.get(link.key) || 'CAD 레이어를 불러오지 못했습니다. 링크를 다시 선택해 주세요.')
            : '링크를 선택하면 CAD 레이어를 자동으로 불러옵니다.'),
        true
      );
    const layerHint = layersLoading && link.layers.length
      ? '<p class="cadcircle-inline-note">CAD 레이어 구성을 새로고침하는 중입니다.</p>'
      : '';
    const linkStatusText = layersLoading
      ? '레이어 로드 중'
      : (layersFailed ? '레이어 오류' : (disabled ? (link.statusText || '사용 불가') : (link.statusText || '로드됨')));

    return `
      <article class="cadcircle-link ${config.enabled ? 'is-enabled' : ''} ${disabled ? 'is-disabled' : ''}" data-link-key="${escapeAttr(link.key)}">
        <div class="cadcircle-link-head">
          <label class="cadcircle-link-toggle">
            <input type="checkbox" data-link-enabled="${escapeAttr(link.key)}" ${config.enabled ? 'checked' : ''} ${controlsDisabled ? 'disabled' : ''}>
            <span class="cadcircle-link-mark" aria-hidden="true"></span>
            <span class="cadcircle-link-copy">
              <strong title="${escapeAttr(link.name)}">${escapeHtml(link.name)}</strong>
              <small title="${escapeAttr(link.path || link.uniqueId || '')}">${escapeHtml(link.path || link.statusText || '현재 프로젝트의 CAD 링크')}</small>
            </span>
          </label>
          <span class="cadcircle-link-status ${disabled || layersFailed ? 'is-error' : ''}">${escapeHtml(linkStatusText)}</span>
        </div>

        <div class="cadcircle-link-placement">
          <label class="cadcircle-field">
            <span>Base Level</span>
            <select data-link-level="${escapeAttr(link.key)}" ${controlsDisabled || !config.enabled ? 'disabled' : ''}>${levelOptions}</select>
          </label>
          <label class="cadcircle-field cadcircle-height-field">
            <span>Height <small>mm</small></span>
            <input type="number" min="0.01" step="1" placeholder="예: 2700"
                   data-link-height="${escapeAttr(link.key)}"
                   value="${config.height == null ? '' : escapeAttr(config.height)}"
                   ${controlsDisabled || !config.enabled ? 'disabled' : ''}>
          </label>
        </div>

        <div class="cadcircle-layer-head">
          <span>검출 레이어 <strong>${config.layerKeys.size}</strong> / ${link.layers.length}</span>
          <div>
            <button type="button" class="cadcircle-text-button" data-action="select-all-layers" ${controlsDisabled || !config.enabled || layersLoading ? 'disabled' : ''}>전체 선택</button>
            <button type="button" class="cadcircle-text-button" data-action="clear-all-layers" ${controlsDisabled || !config.enabled || layersLoading ? 'disabled' : ''}>해제</button>
          </div>
        </div>
        ${layerHint}
        <div class="cadcircle-layer-list ${!config.enabled || layersLoading ? 'is-disabled' : ''}">${layers}</div>
      </article>`;
  }).join('');
}

function renderFamilyMapping(state) {
  const familySelect = state.ui['family-select'];
  const typeSelect = state.ui['type-select'];
  const diameterSelect = state.ui['diameter-parameter'];
  const heightSelect = state.ui['height-parameter'];
  const sourceLayerSelect = state.ui['source-layer-parameter'];
  if (!familySelect || !typeSelect || !diameterSelect || !heightSelect || !sourceLayerSelect) return;

  familySelect.innerHTML = [
    '<option value="">패밀리 선택</option>',
    ...state.context.families.map((family) => optionMarkup(family.key, family.name, state.familyKey === family.key))
  ].join('');
  familySelect.value = state.familyKey;
  familySelect.disabled = !state.contextLoaded || !state.context.families.length || Boolean(state.busy);

  const family = findFamily(state, state.familyKey);
  const types = family?.types || [];
  if (state.typeKey && !types.some((type) => type.key === state.typeKey)) state.typeKey = '';
  typeSelect.innerHTML = [
    '<option value="">타입 선택</option>',
    ...types.map((type) => optionMarkup(type.key, type.name, state.typeKey === type.key))
  ].join('');
  typeSelect.value = state.typeKey;
  typeSelect.disabled = !family || !types.length || Boolean(state.busy);

  const parameters = getAvailableParameters(state);
  const textParameters = getAvailableTextParameters(state);
  if (state.diameterParameterKey && !parameters.some((parameter) => parameter.key === state.diameterParameterKey)) {
    state.diameterParameterKey = '';
  }
  if (state.heightParameterKey && !parameters.some((parameter) => parameter.key === state.heightParameterKey)) {
    state.heightParameterKey = '';
  }
  if (state.sourceLayerParameterKey
    && !textParameters.some((parameter) => parameter.key === state.sourceLayerParameterKey)) {
    state.sourceLayerParameterKey = '';
  }
  const parameterOptions = parameters.map((parameter) => optionMarkup(
    parameter.key,
    parameter.guid ? `${parameter.name} · 공유 파라미터` : parameter.name,
    false
  ));
  diameterSelect.innerHTML = ['<option value="">Diameter 파라미터 선택</option>', ...parameterOptions].join('');
  heightSelect.innerHTML = ['<option value="">Height 파라미터 선택</option>', ...parameterOptions].join('');
  sourceLayerSelect.innerHTML = [
    '<option value="">CAD 레이어 파라미터 선택</option>',
    ...textParameters.map((parameter) => optionMarkup(
      parameter.key,
      parameter.guid ? `${parameter.name} · 공유 파라미터` : parameter.name,
      false
    ))
  ].join('');
  diameterSelect.value = state.diameterParameterKey;
  heightSelect.value = state.heightParameterKey;
  sourceLayerSelect.value = state.sourceLayerParameterKey;
  diameterSelect.disabled = !state.typeKey || !parameters.length || Boolean(state.busy);
  heightSelect.disabled = !state.typeKey || !parameters.length || Boolean(state.busy);
  sourceLayerSelect.disabled = !state.typeKey || !textParameters.length || Boolean(state.busy);
}

function renderTolerance(state) {
  state.page.querySelectorAll('[data-setting]').forEach((element) => {
    const key = element.dataset.setting;
    const value = state.tolerance[key];
    if (element.type === 'checkbox') element.checked = value === true;
    else element.value = value == null ? '' : String(value);
    element.disabled = Boolean(state.busy);
  });
}

function renderPreview(state) {
  if (state.ui['preview-message']) {
    state.ui['preview-message'].textContent = state.previewMessage
      || (state.busy === 'scan'
        ? 'CAD geometry를 분석하고 있습니다. 링크 크기에 따라 시간이 걸릴 수 있습니다.'
        : '스캔 전입니다. 적용 전에 중심 좌표와 직경을 검토할 수 있습니다.');
  }
  renderPreviewMetrics(state);
  renderPreviewFilters(state);
  renderCandidateRows(state);
}

function renderPreviewMetrics(state) {
  const target = state.ui['preview-metrics'];
  if (!target) return;
  const accepted = state.candidates.filter((candidate) => candidate.selectable).length;
  const rejected = state.candidates.length - accepted;
  const duplicates = numberFrom(state.previewSummary, ['duplicates', 'duplicateCount', 'deduplicated'], 0);
  target.innerHTML = [
    metricMarkup('전체 후보', state.candidates.length),
    metricMarkup('사용 가능', accepted, 'success'),
    metricMarkup('선택됨', state.selectedCandidates.size, 'accent'),
    metricMarkup('제외 / 중복', `${rejected} / ${duplicates}`, rejected ? 'warning' : '')
  ].join('');
}

function renderPreviewFilters(state) {
  const linkSelect = state.ui['candidate-link-filter'];
  const layerSelect = state.ui['candidate-layer-filter'];
  if (!linkSelect || !layerSelect) return;
  const candidateLinkKeys = new Set(state.candidates.map((candidate) => candidate.linkKey).filter(Boolean));
  const links = state.context.links.filter((link) => candidateLinkKeys.has(link.key));
  linkSelect.innerHTML = [
    '<option value="">모든 링크</option>',
    ...links.map((link) => optionMarkup(link.key, link.name, state.filter.linkKey === link.key))
  ].join('');
  if (state.filter.linkKey && !candidateLinkKeys.has(state.filter.linkKey)) state.filter.linkKey = '';
  linkSelect.value = state.filter.linkKey;

  const layerMap = new Map();
  state.candidates
    .filter((candidate) => !state.filter.linkKey || candidate.linkKey === state.filter.linkKey)
    .forEach((candidate) => {
      if (candidate.layerKey) layerMap.set(candidate.layerKey, candidate.layerName || candidate.layerKey);
    });
  if (state.filter.layerKey && !layerMap.has(state.filter.layerKey)) state.filter.layerKey = '';
  layerSelect.innerHTML = [
    '<option value="">모든 레이어</option>',
    ...Array.from(layerMap, ([key, name]) => optionMarkup(key, name, state.filter.layerKey === key))
  ].join('');
  layerSelect.value = state.filter.layerKey;
}

function renderCandidateRows(state) {
  const tbody = state.ui['candidate-body'];
  if (!tbody) return;
  const filtered = getFilteredCandidates(state);
  const pageCount = Math.max(1, Math.ceil(filtered.length / state.filter.pageSize));
  state.filter.page = Math.min(Math.max(1, state.filter.page), pageCount);
  const start = (state.filter.page - 1) * state.filter.pageSize;
  const rows = filtered.slice(start, start + state.filter.pageSize);
  const unit = escapeHtml(state.context.unitLabel || 'mm');

  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="9" class="cadcircle-table-empty">${state.busy === 'scan' ? '원형 geometry를 분석하고 있습니다…' : '현재 조건에 해당하는 후보가 없습니다.'}</td></tr>`;
  } else {
    tbody.innerHTML = rows.map((candidate) => {
      const selected = state.selectedCandidates.has(candidate.key);
      const stateClass = candidate.selectable ? 'is-accepted' : 'is-rejected';
      const statusLabel = candidate.selectable ? (selected ? '선택' : '사용 가능') : '제외';
      const quality = candidate.selectable
        ? [formatConfidence(candidate.confidence), candidate.maxResidualDisplay || displayNumber(candidate.maxResidual, unit)].filter(Boolean).join(' · ')
        : candidate.reason || '검출 기준 미충족';
      return `
        <tr class="${stateClass} ${selected ? 'is-selected' : ''}">
          <td class="cadcircle-cell-check">
            <input type="checkbox" data-candidate-key="${escapeAttr(candidate.key)}" ${selected ? 'checked' : ''} ${candidate.selectable ? '' : 'disabled'} aria-label="${escapeAttr(candidate.key)} 후보 선택">
          </td>
          <td><span class="cadcircle-candidate-state ${stateClass}">${statusLabel}</span></td>
          <td class="cadcircle-source-cell">
            <strong title="${escapeAttr(candidate.linkName)}">${escapeHtml(candidate.linkName || '-')}</strong>
            <span title="${escapeAttr(candidate.layerName)}">${escapeHtml(candidate.layerName || '-')}</span>
          </td>
          <td class="cadcircle-number">${displayCoordinate(candidate.xDisplay, candidate.x)}</td>
          <td class="cadcircle-number">${displayCoordinate(candidate.yDisplay, candidate.y)}</td>
          <td class="cadcircle-number">${displayCoordinate(candidate.zDisplay, candidate.z)}</td>
          <td class="cadcircle-number cadcircle-diameter">${displayCoordinate(candidate.diameterDisplay, candidate.diameter)}</td>
          <td>${escapeHtml(candidate.representation || '-')}</td>
          <td class="cadcircle-quality" title="${escapeAttr(quality)}">${escapeHtml(quality || '-')}</td>
        </tr>`;
    }).join('');
  }

  const end = Math.min(start + rows.length, filtered.length);
  if (state.ui['candidate-range']) {
    state.ui['candidate-range'].textContent = filtered.length
      ? `${formatInteger(start + 1)}–${formatInteger(end)} / ${formatInteger(filtered.length)}개`
      : '0개';
  }
  if (state.ui['page-label']) state.ui['page-label'].textContent = `${state.filter.page} / ${pageCount}`;
  const previous = state.page.querySelector('[data-action="previous-page"]');
  const next = state.page.querySelector('[data-action="next-page"]');
  if (previous) previous.disabled = state.filter.page <= 1;
  if (next) next.disabled = state.filter.page >= pageCount;
}

function renderValidation(state, validation = validateState(state, 'apply')) {
  const target = state.ui.validation;
  if (!target) return;
  if (!state.contextLoaded) {
    target.innerHTML = validationMarkup('waiting', '프로젝트 정보 대기', ['CAD 링크와 패밀리 정보를 불러오고 있습니다.']);
    return;
  }
  if (validation.errors.length) {
    target.innerHTML = validationMarkup('error', `${validation.errors.length}개 항목 확인 필요`, validation.errors);
  } else if (validation.warnings.length) {
    target.innerHTML = validationMarkup('warning', '배치 가능 · 주의사항 있음', validation.warnings);
  } else {
    target.innerHTML = validationMarkup('ready', '배치 준비 완료', [
      `${state.selectedCandidates.size}개 후보를 ${enabledLinkCount(state)}개 CAD 링크 설정으로 배치합니다.`
    ]);
  }
}

function renderResult(state) {
  const target = state.ui['result-surface'];
  if (!target) return;
  if (!state.result) {
    target.innerHTML = emptyMarkup(state.lastError?.message || '아직 실행 결과가 없습니다.');
    return;
  }

  const result = state.result;
  const summary = result.summary || {};
  const created = numberFrom(summary, ['created', 'createdCount', 'success', 'succeeded'], 0);
  const updated = numberFrom(summary, ['updated', 'updatedCount'], 0);
  const skipped = numberFrom(summary, ['skipped', 'skippedCount'], 0);
  const failed = numberFrom(summary, ['failed', 'failedCount', 'errors', 'errorCount'], 0);
  const rows = result.items.slice(0, MAX_RESULT_ROWS);
  target.innerHTML = `
    <div class="cadcircle-result-message ${result.ok === false ? 'is-error' : 'is-success'}">${escapeHtml(result.message || '배치가 완료되었습니다.')}</div>
    <div class="cadcircle-result-metrics">
      ${metricMarkup('생성', created, 'success')}
      ${metricMarkup('갱신', updated, 'accent')}
      ${metricMarkup('건너뜀', skipped, 'warning')}
      ${metricMarkup('실패', failed, failed ? 'error' : '')}
    </div>
    ${rows.length ? `
      <div class="cadcircle-result-list">
        ${rows.map((item) => {
          const status = normalizeResultStatus(item.status || item.result || (item.ok === false ? 'failed' : 'created'));
          return `
            <article class="cadcircle-result-row is-${status}">
              <div>
                <strong>${escapeHtml(item.label || item.candidateId || item.id || statusLabel(status))}</strong>
                <span>${escapeHtml(item.message || item.reason || statusLabel(status))}</span>
              </div>
              <small>${escapeHtml(item.elementId == null ? '' : `Element ${item.elementId}`)}</small>
            </article>`;
        }).join('')}
      </div>
      ${result.items.length > MAX_RESULT_ROWS ? `<p class="cadcircle-inline-note">결과 ${formatInteger(result.items.length)}개 중 앞의 ${MAX_RESULT_ROWS}개만 표시합니다.</p>` : ''}` : ''}
  `;
}

function updateActionState(state) {
  const interactionRoot = state.interactionRoot || state.page;
  const scanButton = interactionRoot.querySelector('[data-action="scan"]');
  const applyButton = interactionRoot.querySelector('[data-action="apply"]');
  const reloadButton = interactionRoot.querySelector('[data-action="reload-context"]');
  const scanValidation = validateState(state, 'scan');
  const applyValidation = validateState(state, 'apply');

  if (scanButton) {
    scanButton.disabled = Boolean(state.busy) || scanValidation.errors.length > 0;
    scanButton.textContent = state.busy === 'scan' ? '원형 분석 중…' : '원형 스캔';
  }
  if (applyButton) {
    applyButton.disabled = Boolean(state.busy) || applyValidation.errors.length > 0;
    applyButton.textContent = state.busy === 'apply'
      ? '패밀리 배치 중…'
      : `선택 후보 ${formatInteger(state.selectedCandidates.size)}개 배치`;
  }
  if (reloadButton) reloadButton.disabled = Boolean(state.busy);
  if (state.ui['existing-policy']) state.ui['existing-policy'].disabled = Boolean(state.busy);
  if (state.ui['scan-note']) {
    const selectedLayerCount = state.context.links.reduce((count, link) => {
      const config = state.linkConfig.get(link.key);
      return count + (config?.enabled ? config.layerKeys.size : 0);
    }, 0);
    state.ui['scan-note'].textContent = scanValidation.errors[0]
      || (selectedLayerCount
        ? `${enabledLinkCount(state)}개 링크의 선택 레이어 ${selectedLayerCount}개를 스캔합니다.`
        : '선택 레이어가 없으므로 전체 레이어를 검색하고 레이어 목록을 먼저 발견합니다.');
    state.ui['scan-note'].classList.toggle('is-error', Boolean(scanValidation.errors.length));
  }
  if (state.ui['run-status']) {
    state.ui['run-status'].textContent = state.statusMessage;
    state.ui['run-status'].className = 'cadcircle-run-status';
    if (state.busy) state.ui['run-status'].classList.add('is-busy');
    else if (state.lastError) state.ui['run-status'].classList.add('is-error');
    else if (state.result?.ok !== false) state.ui['run-status'].classList.add('is-success');
  }
  state.page.setAttribute('aria-busy', state.busy ? 'true' : 'false');
}

function validateState(state, phase) {
  const errors = [];
  const warnings = [];
  if (!state.contextLoaded) return { errors: ['프로젝트 정보를 먼저 불러와야 합니다.'], warnings };

  const enabled = state.context.links.filter((link) => state.linkConfig.get(link.key)?.enabled);
  if (!enabled.length) errors.push('스캔할 CAD 링크를 하나 이상 선택해 주세요.');
  const loadingLinks = enabled.filter((link) => state.layerStatus.get(link.key) === 'loading');
  if (phase === 'scan' && loadingLinks.length) {
    errors.push(`CAD 레이어를 불러오는 중입니다: ${loadingLinks.map((link) => link.name).join(', ')}`);
  }
  enabled.forEach((link) => {
    const config = state.linkConfig.get(link.key);
    if (phase === 'apply') {
      if (!config?.layerKeys.size) errors.push(`${link.name}: 배치에 사용할 CAD 레이어를 하나 이상 선택해 주세요.`);
      if (!config?.levelKey) errors.push(`${link.name}: Base Level을 선택해 주세요.`);
      if (!(Number(config?.height) > 0)) errors.push(`${link.name}: Height를 0보다 큰 값으로 입력해 주세요.`);
    }
  });

  if (!state.familyKey) errors.push('원형 검출에 사용할 대상 패밀리를 선택해 주세요.');
  if (!state.typeKey) errors.push('원형 검출에 사용할 패밀리 타입을 선택해 주세요.');

  const toleranceKeys = [
    'endpointMm',
    'planeMm',
    'fitAbsoluteMm',
    'fitRelativePercent',
    'duplicateCenterMm',
    'duplicateDiameterMm',
    'minimumCoverageDegrees',
    'maximumAngularGapDegrees'
  ];
  toleranceKeys.forEach((key) => {
    if (!(Number(state.tolerance[key]) > 0)) errors.push('모든 필수 허용오차를 0보다 크게 입력해 주세요.');
  });
  if (state.tolerance.maximumDiameterMm != null
    && Number(state.tolerance.maximumDiameterMm) > 0
    && Number(state.tolerance.maximumDiameterMm) <= Number(state.tolerance.minimumDiameterMm || 0)) {
    errors.push('최대 직경은 최소 직경보다 커야 합니다.');
  }
  const boundedMillimeterToleranceKeys = ['endpointMm', 'planeMm', 'fitAbsoluteMm', 'duplicateCenterMm', 'duplicateDiameterMm'];
  if (boundedMillimeterToleranceKeys.some((key) => Number(state.tolerance[key]) > 100)) {
    errors.push('검출·중복 허용오차는 각각 100 mm 이하로 입력해 주세요.');
  }
  if (!Number.isFinite(Number(state.tolerance.horizontalAngleDeg)) || Number(state.tolerance.horizontalAngleDeg) < 0.01 || Number(state.tolerance.horizontalAngleDeg) > 45) {
    errors.push('수평 각도 허용오차는 0.01° 이상 45° 이하로 입력해 주세요.');
  }
  if (!Number.isInteger(Number(state.tolerance.minimumStraightSegments))
    || Number(state.tolerance.minimumStraightSegments) < 4
    || Number(state.tolerance.minimumStraightSegments) > 4096) {
    errors.push('최소 직선 세그먼트는 4 이상 4096 이하의 정수여야 합니다.');
  }
  if (Number(state.tolerance.minimumCoverageDegrees) < 180 || Number(state.tolerance.minimumCoverageDegrees) > 360) {
    errors.push('최소 원주 범위는 180° 이상 360° 이하로 입력해 주세요.');
  }
  if (Number(state.tolerance.maximumAngularGapDegrees) < 1 || Number(state.tolerance.maximumAngularGapDegrees) > 180) {
    errors.push('최대 각도 공백은 1° 이상 180° 이하로 입력해 주세요.');
  }

  if (phase === 'apply') {
    if (!state.scanId && !state.candidates.length) errors.push('먼저 CAD 원형을 스캔해 주세요.');
    if (!state.selectedCandidates.size) errors.push('배치할 원형 후보를 하나 이상 선택해 주세요.');
    if (!state.diameterParameterKey) errors.push('Diameter 매핑 파라미터를 선택해 주세요.');
    if (!state.heightParameterKey) errors.push('Height 매핑 파라미터를 선택해 주세요.');
    if (!state.sourceLayerParameterKey) errors.push('CAD 레이어명을 입력할 Text 파라미터를 선택해 주세요.');
    else if (!findTextParameter(state, state.sourceLayerParameterKey)) {
      errors.push('선택한 CAD 레이어 파라미터는 쓰기 가능한 인스턴스 Text 파라미터가 아닙니다.');
    }
    if (state.diameterParameterKey && state.diameterParameterKey === state.heightParameterKey) {
      errors.push('Diameter와 Height는 서로 다른 인스턴스 파라미터를 선택해야 합니다.');
    }
    const rejected = state.candidates.filter((candidate) => !candidate.selectable).length;
    if (rejected) warnings.push(`${rejected}개 후보는 폐합성·평면성·원형도 기준을 통과하지 못해 제외됩니다.`);
    if (state.existingPolicy === 'create') warnings.push('기존 인스턴스 확인 없이 항상 생성하므로 재실행 시 중복될 수 있습니다.');
  }

  return { errors: uniqueStrings(errors), warnings: uniqueStrings(warnings) };
}

function normalizeContext(payload) {
  const envelope = objectFrom(payload);
  const source = objectFrom(envelope.context || envelope.data || envelope.payload || envelope);
  const levelsRaw = firstArray(source.levels, source.projectLevels, envelope.levels);
  const typesRaw = firstArray(source.types, source.familyTypes, envelope.types);
  const parametersRaw = firstArray(source.parameters, source.instanceParameters, source.lengthParameters, envelope.parameters);
  const textParametersRaw = firstArray(
    source.textParameters,
    source.instanceTextParameters,
    envelope.textParameters,
    envelope.instanceTextParameters
  );
  const layersRaw = firstArray(source.layers, source.cadLayers, envelope.layers);
  const layersByLink = objectFrom(source.layersByLink || source.linkLayers || envelope.layersByLink);
  const familySymbolsRaw = firstArray(source.familySymbols, envelope.familySymbols);
  const familiesRaw = firstArray(source.families, source.loadedFamilies, envelope.families);
  const linksRaw = firstArray(source.links, source.cadLinks, source.importInstances, envelope.links);

  const levels = levelsRaw.map(normalizeLevel).filter((item) => item.key);
  const globalParameters = uniqueParameters([
    ...parametersRaw.map((item, index) => normalizeParameter(item, index, '', 'Length')),
    ...textParametersRaw.map((item, index) => normalizeParameter(item, index, '', 'Text'))
  ]).filter((item) => item.key);
  const families = familySymbolsRaw.length
    ? groupFlatFamilySymbols(familySymbolsRaw, globalParameters)
    : familiesRaw.map((item, familyIndex) => normalizeFamily(
      item,
      familyIndex,
      typesRaw,
      globalParameters
    )).filter((item) => item.key);

  const links = linksRaw.map((item, linkIndex) => {
    const normalized = normalizeLink(item, linkIndex);
    const embedded = firstArray(item?.layers, item?.cadLayers, item?.subcategories);
    const mapped = firstArray(
      layersByLink[normalized.key],
      layersByLink[String(normalized.hostId ?? '')],
      layersRaw.filter((layer) => idEquals(readAny(layer, ['linkId', 'importInstanceId', 'ownerId']), normalized.hostId))
    );
    normalized.layers = (embedded.length ? embedded : mapped)
      .map((layer, layerIndex) => normalizeLayer(layer, layerIndex, normalized))
      .filter((layer) => layer.key);
    return normalized;
  }).filter((item) => item.key);

  const defaults = objectFrom(source.defaults || envelope.defaults);
  return {
    ok: readBoolean(source, ['ok', 'success'], readBoolean(envelope, ['ok', 'success'], true)),
    message: readString(source, ['message', 'statusMessage'], readString(envelope, ['message'], '')),
    document: objectFrom(source.document || source.activeDocument || envelope.document),
    unitLabel: readString(source, ['unitLabel', 'displayUnit', 'lengthUnit'], readString(envelope, ['unitLabel', 'displayUnit'], 'mm')),
    links,
    levels,
    families,
    parameters: globalParameters,
    defaults,
    tolerance: objectFrom(source.tolerance || source.detectionTolerance || envelope.tolerance)
  };
}

function normalizeLayerDiscoveryResult(payload, state) {
  const envelope = objectFrom(payload);
  const source = objectFrom(envelope.data || envelope.result || envelope.payload || envelope);
  const linkElementId = readAny(source, ['linkElementId', 'linkId', 'importInstanceId'])
    ?? readAny(envelope, ['linkElementId', 'linkId', 'importInstanceId']);
  const requestId = getResponseRequestId(payload);
  const link = state.context.links.find((item) => idEquals(item.hostId, linkElementId))
    || state.context.links.find((item) => state.layerRequests.get(item.key) === requestId)
    || null;
  const rawLayers = firstArray(source.layers, source.items, envelope.layers, envelope.items);
  const layers = link
    ? rawLayers.map((item, index) => normalizeLayer(item, index, link)).filter((item) => item.key)
    : [];
  return {
    requestId,
    link,
    linkElementId,
    ok: readBoolean(source, ['ok', 'success'], readBoolean(envelope, ['ok', 'success'], true)),
    message: readString(source, ['message', 'statusMessage'], readString(envelope, ['message'], '')),
    layers
  };
}

function carryForwardLinkLayers(nextLinks, previousLinks) {
  nextLinks.forEach((link) => {
    if (link.layers.length) return;
    const previous = previousLinks.find((item) => (
      (link.uniqueId && item.uniqueId && link.uniqueId === item.uniqueId)
      || idEquals(link.hostId, item.hostId)
    ));
    if (previous?.layers?.length) link.layers = previous.layers.map((layer) => ({ ...layer }));
  });
}

function replaceLinkLayers(state, link, incomingLayers) {
  const config = state.linkConfig.get(link.key);
  const previousLayers = link.layers || [];
  const previousSelection = new Set(config?.layerKeys || []);
  const useLayerDefaults = previousLayers.length === 0 && previousSelection.size === 0;
  const nextLayers = [];

  incomingLayers.forEach((incoming) => {
    const previous = previousLayers.find((item) => layerIdentityMatches(item, incoming));
    const layer = previous
      ? { ...previous, ...incoming, key: previous.key }
      : incoming;
    if (!nextLayers.some((item) => layerIdentityMatches(item, layer))) nextLayers.push(layer);
  });

  const nextSelection = new Set();
  nextLayers.forEach((layer) => {
    const previous = previousLayers.find((item) => layerIdentityMatches(item, layer));
    const wasSelected = previous
      ? previousSelection.has(previous.key)
      : previousSelection.has(layer.key);
    if (wasSelected
      || (useLayerDefaults && layer.selectedByDefault)
      || (useLayerDefaults && link.defaultLayerIds.some(
        (id) => idEquals(id, layer.hostId) || idEquals(id, layer.graphicsStyleElementId)
      ))) {
      nextSelection.add(layer.key);
    }
  });

  link.layers = nextLayers;
  if (config) config.layerKeys = nextSelection;
  return !setEquals(previousSelection, nextSelection);
}

function layerIdentityMatches(left, right) {
  if (!left || !right) return false;
  if (left.graphicsStyleElementId != null && right.graphicsStyleElementId != null
    && idEquals(left.graphicsStyleElementId, right.graphicsStyleElementId)) return true;
  if (left.hostId != null && right.hostId != null && idEquals(left.hostId, right.hostId)) return true;
  return Boolean(left.name && right.name
    && String(left.name).toLocaleLowerCase() === String(right.name).toLocaleLowerCase());
}

function setEquals(left, right) {
  if (left.size !== right.size) return false;
  for (const value of left) {
    if (!right.has(value)) return false;
  }
  return true;
}

function normalizePreview(payload, state) {
  const envelope = objectFrom(payload);
  const source = objectFrom(envelope.preview || envelope.data || envelope.result || envelope);
  const discoveredLayerCount = mergePreviewLayers(state, source, envelope);
  mergePreviewParameterOptions(state, source, envelope);
  const rows = firstArray(source.candidates, source.rows, source.items, source.circles, envelope.candidates, envelope.rows);
  const unit = readString(source, ['unitLabel', 'displayUnit', 'unit'], state.context.unitLabel || 'mm');
  const candidates = rows.map((item, index) => normalizeCandidate(item, index, state, unit));
  return {
    ok: readBoolean(source, ['ok', 'success'], readBoolean(envelope, ['ok', 'success'], true)),
    message: readString(source, ['message', 'statusMessage'], readString(envelope, ['message'], '')),
    scanId: readString(source, ['scanId', 'sessionId', 'previewId'], readString(envelope, ['scanId'], state.requestIds.scan)),
    summary: objectFrom(source.summary || source.counts || envelope.summary),
    discoveredLayerCount,
    candidates
  };
}

function normalizeResult(payload) {
  const envelope = objectFrom(payload);
  const source = objectFrom(envelope.result || envelope.data || envelope.payload || envelope);
  const summary = { ...objectFrom(source.summary || source.counts || envelope.summary) };
  copyCount(summary, 'created', source, envelope, ['created', 'createdCount']);
  copyCount(summary, 'updated', source, envelope, ['updated', 'updatedCount']);
  copyCount(summary, 'skipped', source, envelope, ['skipped', 'skippedCount']);
  copyCount(summary, 'failed', source, envelope, ['failed', 'failedCount']);
  return {
    ok: readBoolean(source, ['ok', 'success'], readBoolean(envelope, ['ok', 'success'], true)),
    message: readString(source, ['message', 'statusMessage'], readString(envelope, ['message'], '')),
    summary,
    items: firstArray(source.items, source.rows, source.results, source.failures, envelope.items)
      .map((item) => objectFrom(item))
  };
}

function copyCount(target, targetKey, source, envelope, aliases) {
  const value = readAny(source, aliases) ?? readAny(envelope, aliases);
  const number = nullableNumber(value);
  if (number != null) target[targetKey] = number;
}

function mergePreviewLayers(state, source, envelope) {
  const entries = [];
  const direct = firstArray(source.layers, source.layerInfos, envelope.layers, envelope.layerInfos);
  direct.forEach((item) => {
    const group = objectFrom(item);
    const embedded = firstArray(group.layers, group.items);
    if (embedded.length) {
      const linkElementId = readAny(group, ['linkElementId', 'linkId', 'importInstanceId']);
      embedded.forEach((layer) => entries.push({ ...objectFrom(layer), linkElementId }));
    } else {
      entries.push(group);
    }
  });

  const byLink = objectFrom(source.layersByLink || envelope.layersByLink);
  Object.entries(byLink).forEach(([linkElementId, layers]) => {
    firstArray(layers, objectFrom(layers).items).forEach((layer) => {
      entries.push({ ...objectFrom(layer), linkElementId });
    });
  });

  let added = 0;
  const groupedByLink = new Map();
  entries.forEach((entry) => {
    const linkElementId = readAny(entry, ['linkElementId', 'linkId', 'importInstanceId', 'ownerElementId']);
    const link = state.context.links.find((item) => idEquals(item.hostId, linkElementId))
      || findLink(state, keyFrom(linkElementId, ''));
    if (!link) return;
    const normalized = normalizeLayer(entry, link.layers.length, link);
    if (!state.linkConfig.has(link.key)) state.linkConfig.set(link.key, createLinkConfig(link, state, false));
    if (!groupedByLink.has(link.key)) groupedByLink.set(link.key, { link, layers: [] });
    groupedByLink.get(link.key).layers.push(normalized);
  });
  groupedByLink.forEach(({ link, layers }) => {
    added += layers.filter((layer) => !link.layers.some((existing) => layerIdentityMatches(existing, layer))).length;
    replaceLinkLayers(state, link, layers);
    state.layerRequests.delete(link.key);
    state.layerStatus.set(link.key, 'loaded');
    state.layerErrors.delete(link.key);
  });
  return added;
}

function mergePreviewParameterOptions(state, source, envelope) {
  const rawOptions = source.parameterOptions ?? envelope.parameterOptions;
  const optionObject = objectFrom(rawOptions);
  const lengthItems = firstArray(
    rawOptions,
    optionObject.items,
    optionObject.parameters,
    [
      ...firstArray(optionObject.diameter, optionObject.diameterParameters),
      ...firstArray(optionObject.height, optionObject.heightParameters)
    ]
  );
  const rawTextOptions = source.textParameterOptions ?? envelope.textParameterOptions;
  const textOptionObject = objectFrom(rawTextOptions);
  const textItems = firstArray(
    rawTextOptions,
    textOptionObject.items,
    textOptionObject.parameters,
    textOptionObject.sourceLayer,
    textOptionObject.sourceLayerParameters
  );
  if (!lengthItems.length && !textItems.length) return;

  const type = findType(state, state.typeKey);
  if (!type) return;
  const previousDiameter = findParameter(state, state.diameterParameterKey)?.hostKey;
  const previousHeight = findParameter(state, state.heightParameterKey)?.hostKey;
  const previousSourceLayer = findTextParameter(state, state.sourceLayerParameterKey)?.hostKey;
  type.parameters = uniqueParameters([
    ...lengthItems.map((item, index) => normalizeParameter(item, index, type.key, 'Length')),
    ...textItems.map((item, index) => normalizeParameter(item, index, type.key, 'Text'))
  ]);
  state.diameterParameterKey = type.parameters.find((parameter) => idEquals(parameter.hostKey, previousDiameter))?.key || '';
  state.heightParameterKey = type.parameters.find((parameter) => idEquals(parameter.hostKey, previousHeight))?.key || '';
  state.sourceLayerParameterKey = type.parameters.find((parameter) => idEquals(parameter.hostKey, previousSourceLayer))?.key || '';

  const defaults = {
    ...objectFrom(optionObject.defaults),
    ...objectFrom(textOptionObject.defaults),
    ...objectFrom(source.parameterDefaults || envelope.parameterDefaults)
  };
  if (!state.diameterParameterKey) {
    state.diameterParameterKey = findParameterKey(
      type.parameters,
      defaults.diameterParameterId,
      defaults.diameterParameterGuid,
      defaults.diameterParameterKey || defaults.diameterParameterName
    );
  }
  if (!state.heightParameterKey) {
    state.heightParameterKey = findParameterKey(
      type.parameters,
      defaults.heightParameterId,
      defaults.heightParameterGuid,
      defaults.heightParameterKey || defaults.heightParameterName
    );
  }
  if (!state.sourceLayerParameterKey) {
    state.sourceLayerParameterKey = findParameterKey(
      getAvailableTextParameters(state),
      defaults.sourceLayerParameterId,
      defaults.sourceLayerParameterGuid,
      defaults.sourceLayerParameterKey || defaults.sourceLayerParameterName
    );
  }
}

function normalizeError(payload) {
  const envelope = objectFrom(payload);
  const source = objectFrom(envelope.error || envelope.data || envelope);
  const message = readString(source, ['message', 'errorMessage', 'detail'], readString(envelope, ['message'], 'CAD 원형 배치 중 오류가 발생했습니다.'));
  return {
    message,
    code: readString(source, ['code', 'errorCode'], ''),
    detail: readString(source, ['detail', 'stack'], ''),
    sourceEvent: readString(source, ['sourceEvent', 'requestEvent'], ''),
    operation: readString(source, ['operation', 'requestOperation'], readString(envelope, ['operation'], '')),
    requestId: getResponseRequestId(payload)
  };
}

function normalizeLevel(item, index) {
  const source = objectFrom(item);
  const hostId = readAny(source, ['id', 'elementId', 'levelId', 'value']);
  const elevationMillimeters = nullableNumber(readAny(source, ['elevationMillimeters']));
  return {
    key: keyFrom(hostId, `level-${index}`),
    hostId,
    name: readString(source, ['name', 'label', 'levelName', 'text'], `Level ${index + 1}`),
    projectElevation: elevationMillimeters ?? nullableNumber(readAny(source, ['projectElevation', 'elevationInternal', 'elevation'])),
    elevationDisplay: readString(
      source,
      ['elevationDisplay', 'displayElevation', 'formattedElevation'],
      elevationMillimeters == null ? '' : `${formatNumber(elevationMillimeters)} mm`
    )
  };
}

function groupFlatFamilySymbols(symbols, globalParameters) {
  const groups = new Map();
  symbols.forEach((item, symbolIndex) => {
    const source = objectFrom(item);
    const familyName = readString(source, ['familyName', 'family', 'ownerFamilyName'], '이름 없는 패밀리');
    const familyId = readAny(source, ['familyId', 'ownerFamilyId']);
    const familyKey = `family-name:${familyName}`;
    if (!groups.has(familyKey)) {
      groups.set(familyKey, {
        key: familyKey,
        hostId: familyId,
        name: familyName,
        placementType: readString(source, ['placementType', 'familyPlacementType'], ''),
        supported: readBoolean(source, ['supported', 'canPlace', 'available'], true),
        parameters: [],
        types: []
      });
    }
    const family = groups.get(familyKey);
    family.types.push(normalizeType(source, symbolIndex, familyKey, [], globalParameters));
    if (family.hostId == null && familyId != null) family.hostId = familyId;
  });
  return Array.from(groups.values()).sort((left, right) => left.name.localeCompare(right.name, 'ko'));
}

function normalizeFamily(item, index, flatTypes, globalParameters) {
  const source = objectFrom(item);
  const hostId = readAny(source, ['id', 'elementId', 'familyId', 'value']);
  const key = keyFrom(hostId, `family-${index}`);
  const embeddedTypes = firstArray(source.types, source.symbols, source.familyTypes);
  const matchingFlatTypes = flatTypes.filter((type) => idEquals(readAny(type, ['familyId', 'ownerFamilyId']), hostId));
  const familyParameters = uniqueParameters([
    ...firstArray(source.parameters, source.instanceParameters, source.lengthParameters)
      .map((parameter, parameterIndex) => normalizeParameter(parameter, parameterIndex, key, 'Length')),
    ...firstArray(source.instanceTextParameters, source.textParameters)
      .map((parameter, parameterIndex) => normalizeParameter(parameter, parameterIndex, key, 'Text'))
  ]);
  const types = (embeddedTypes.length ? embeddedTypes : matchingFlatTypes)
    .map((type, typeIndex) => normalizeType(type, typeIndex, key, familyParameters, globalParameters))
    .filter((type) => type.key);
  return {
    key,
    hostId,
    name: readString(source, ['name', 'label', 'familyName', 'text'], `Family ${index + 1}`),
    placementType: readString(source, ['placementType', 'familyPlacementType'], ''),
    supported: readBoolean(source, ['supported', 'canPlace', 'available'], true),
    parameters: familyParameters,
    types
  };
}

function normalizeType(item, index, familyKey, familyParameters, globalParameters) {
  const source = objectFrom(item);
  const hostId = readAny(source, ['id', 'elementId', 'symbolId', 'typeId', 'value']);
  const key = keyFrom(hostId, `${familyKey}-type-${index}`);
  const embeddedParameters = uniqueParameters([
    ...firstArray(
      source.instanceLengthParameters,
      source.parameters,
      source.instanceParameters,
      source.lengthParameters,
      source.diameterParameters,
      source.heightParameters
    )
      .map((parameter, parameterIndex) => normalizeParameter(parameter, parameterIndex, key, 'Length')),
    ...firstArray(source.instanceTextParameters, source.textParameters, source.sourceLayerParameters)
      .map((parameter, parameterIndex) => normalizeParameter(parameter, parameterIndex, key, 'Text')),
    ...familyParameters,
    ...globalParameters.filter((parameter) => !parameter.typeKey || parameter.typeKey === key)
  ]);
  return {
    key,
    hostId,
    familyKey,
    name: readString(source, ['name', 'label', 'typeName', 'symbolName', 'text'], `Type ${index + 1}`),
    parameters: embeddedParameters
  };
}

function normalizeParameter(item, index, ownerKey = '', defaultDataType = 'Length') {
  if (typeof item === 'string' || typeof item === 'number') {
    return {
      key: String(item),
      hostKey: item,
      hostId: null,
      guid: '',
      name: String(item),
      scope: 'instance',
      dataType: defaultDataType,
      writable: true,
      typeKey: ''
    };
  }
  const source = objectFrom(item);
  const hostId = readAny(source, ['id', 'elementId', 'parameterId']);
  const guid = readString(source, ['guid', 'parameterGuid', 'sharedGuid'], '');
  const name = readString(source, ['name', 'displayName', 'label', 'parameterName', 'text'], `Parameter ${index + 1}`);
  const explicitKey = readAny(source, ['key', 'parameterKey', 'value']);
  const hostKey = explicitKey || (guid ? `guid:${guid}` : (hostId ?? name));
  return {
    key: `${ownerKey ? `${ownerKey}:` : ''}${keyFrom(hostKey, `parameter-${index}`)}`,
    hostKey,
    hostId,
    guid,
    name,
    scope: readString(source, ['scope', 'binding', 'parameterScope'], readBoolean(source, ['isType', 'typeParameter'], false) ? 'type' : 'instance').toLocaleLowerCase(),
    dataType: readString(source, ['dataType', 'specType', 'type', 'dataTypeToken'], defaultDataType),
    writable: !readBoolean(source, ['readOnly', 'isReadOnly'], false)
      && readBoolean(source, ['isWritable', 'writable', 'canWrite', 'userModifiable'], true),
    typeKey: keyFrom(readAny(source, ['typeId', 'symbolId']), '')
  };
}

function normalizeLink(item, index) {
  const source = objectFrom(item);
  const hostId = readAny(source, ['elementId', 'linkElementId', 'id', 'importInstanceId', 'linkId', 'value']);
  return {
    key: keyFrom(hostId, `link-${index}`),
    hostId,
    uniqueId: readString(source, ['uniqueId', 'linkUniqueId', 'instanceUniqueId'], ''),
    name: readString(source, ['name', 'label', 'displayName', 'instanceName', 'fileName'], `CAD Link ${index + 1}`),
    path: readString(source, ['path', 'filePath', 'externalPath', 'sourcePath'], ''),
    statusText: readString(source, ['statusText', 'status', 'loadStatus'], ''),
    available: readBoolean(source, ['available', 'isLoaded', 'loaded', 'canUse'], true),
    selectedByDefault: readBoolean(source, ['selected', 'selectedByDefault', 'isSelected'], false),
    defaultLevelKey: keyFrom(readAny(source, ['levelId', 'baseLevelId', 'defaultLevelId']), ''),
    defaultHeight: nullableNumber(readAny(source, ['height', 'defaultHeight', 'heightMm'])),
    defaultLayerIds: firstArray(source.defaultLayerIds, source.selectedLayerIds),
    layers: []
  };
}

function normalizeLayer(item, index, link) {
  if (typeof item === 'string' || typeof item === 'number') {
    return {
      key: `${link.key}:layer:${String(item)}`,
      hostId: item,
      graphicsStyleElementId: item,
      name: String(item),
      available: true,
      selectedByDefault: false,
      count: null
    };
  }
  const source = objectFrom(item);
  const hostId = readAny(source, ['key', 'layerKey', 'id', 'elementId', 'graphicsStyleId', 'layerId', 'value']);
  const graphicsStyleElementId = readAny(source, ['graphicsStyleElementId', 'graphicsStyleId', 'layerId']);
  const name = readString(source, ['name', 'displayName', 'label', 'layerName', 'text'], `Layer ${index + 1}`);
  return {
    key: `${link.key}:layer:${keyFrom(hostId || name, index)}`,
    hostId,
    graphicsStyleElementId,
    name,
    available: readBoolean(source, ['available', 'visible', 'canUse'], true),
    selectedByDefault: readBoolean(source, ['selected', 'selectedByDefault', 'isSelected'], false),
    primitiveCount: nullableNumber(readAny(source, ['primitiveCount', 'geometryCount'])),
    detectedCount: nullableNumber(readAny(source, ['detectedCount', 'circleCount'])),
    count: nullableNumber(readAny(source, ['count', 'itemCount']))
  };
}

function normalizeCandidate(item, index, state, unit) {
  const source = objectFrom(item);
  const center = objectFrom(source.centerHostInternal || source.centerModel || source.center || source.point || source.location);
  const hostId = readAny(source, ['id', 'candidateId', 'geometryId', 'sourceId']);
  const stableKey = readString(source, ['stableKey', 'candidateKey', 'sourceKey'], '');
  const linkHostId = readAny(source, ['linkElementId', 'linkId', 'importInstanceId', 'sourceLinkId']);
  const link = state.context.links.find((entry) => idEquals(entry.hostId, linkHostId))
    || findLink(state, readString(source, ['linkKey'], ''));
  const rawLayerId = readAny(source, ['layerKey', 'layerId', 'graphicsStyleId', 'sourceLayerId']);
  const rawLayerName = readString(source, ['layerName', 'layer', 'graphicsStyleName'], '');
  const layer = link?.layers.find((entry) => idEquals(entry.hostId, rawLayerId) || entry.name === rawLayerName);
  const x = nullableNumber(readAny(center, ['x', 'X']) ?? readAny(source, ['centerXMillimeters', 'x', 'centerX']));
  const y = nullableNumber(readAny(center, ['y', 'Y']) ?? readAny(source, ['centerYMillimeters', 'y', 'centerY']));
  const z = nullableNumber(readAny(center, ['z', 'Z']) ?? readAny(source, ['centerZMillimeters', 'z', 'centerZ']));
  const diameter = nullableNumber(readAny(source, ['diameterMillimeters', 'diameter', 'diameterInternal', 'diameterValue', 'd']));
  const fallbackKey = [link?.key || linkHostId || 'link', layer?.key || rawLayerId || rawLayerName || 'layer', x, y, diameter, index].join('|');
  const status = readString(source, ['status', 'state', 'validationStatus'], '').toLocaleLowerCase();
  const rejectionCode = readString(source, ['rejectionCode', 'reasonCode'], '');
  const explicitlyAccepted = readAny(source, ['accepted', 'isAccepted', 'valid', 'isValid']);
  const rejectedByStatus = /reject|invalid|error|excluded|duplicate|open|failed/.test(status) || Boolean(rejectionCode);
  const accepted = explicitlyAccepted == null ? !rejectedByStatus : Boolean(explicitlyAccepted);
  const selectable = readBoolean(source, ['selectable', 'canSelect'], accepted) && accepted;
  const candidateKey = stableKey
    ? stableKey
    : `${link?.key || keyFrom(linkHostId, 'link')}:candidate:${keyFrom(hostId, fallbackKey)}`;
  return {
    key: candidateKey,
    stableKey,
    hostId,
    linkKey: link?.key || keyFrom(linkHostId, ''),
    linkHostId,
    linkName: link?.name || readString(source, ['linkName', 'sourceLinkName'], ''),
    layerKey: layer?.key || `${link?.key || linkHostId || 'link'}:layer:${keyFrom(rawLayerId || rawLayerName, 'unknown')}`,
    layerHostId: rawLayerId,
    layerName: layer?.name || rawLayerName,
    x,
    y,
    z,
    diameter,
    xDisplay: readString(source, ['xDisplay', 'displayX'], readString(center, ['xDisplay'], '')),
    yDisplay: readString(source, ['yDisplay', 'displayY'], readString(center, ['yDisplay'], '')),
    zDisplay: readString(source, ['zDisplay', 'displayZ'], readString(center, ['zDisplay'], '')),
    diameterDisplay: readString(source, ['diameterDisplay', 'displayDiameter'], ''),
    unit: readString(source, ['unit', 'displayUnit'], unit),
    representation: readString(source, ['representation', 'representationKind', 'geometryType', 'sourceType', 'sourceKind'], ''),
    confidence: readAny(source, ['confidence', 'confidenceScore', 'score']),
    maxResidual: nullableNumber(readAny(source, ['maxResidualMillimeters', 'maxResidual', 'maximumResidual', 'fitError'])),
    maxResidualDisplay: readString(source, ['maxResidualDisplay', 'fitErrorDisplay'], ''),
    rejectionCode,
    reason: readString(source, ['reason', 'rejectionReason', 'message', 'notes'], rejectionCode),
    accepted,
    selectable,
    selected: readBoolean(source, ['selected', 'selectedByDefault'], accepted)
  };
}

function mergeLinkConfiguration(state) {
  const previous = state.linkConfig;
  const next = new Map();
  const defaultLinkKeys = new Set(firstArray(state.context.defaults?.selectedLinkIds).map(String));
  state.context.links.forEach((link, index) => {
    const old = previous.get(link.key);
    const config = createLinkConfig(link, state, index === 0);
    if (old) {
      config.enabled = old.enabled && link.available !== false;
      config.levelKey = old.levelKey || config.levelKey;
      config.height = old.height ?? config.height;
      config.layerKeys = new Set([...old.layerKeys].filter((key) => link.layers.some((layer) => layer.key === key)));
    } else if (defaultLinkKeys.size) {
      config.enabled = defaultLinkKeys.has(String(link.hostId)) || defaultLinkKeys.has(link.key);
    }
    next.set(link.key, config);
  });
  state.linkConfig = next;
}

function createLinkConfig(link, state, enableFirst) {
  const defaultLevel = keyFrom(
    link.defaultLevelKey
      || state.context.defaults?.levelId
      || state.context.defaults?.baseLevelId,
    ''
  );
  const defaultLayers = new Set();
  link.layers.forEach((layer) => {
    if (layer.selectedByDefault
      || link.defaultLayerIds.some((id) => idEquals(id, layer.hostId) || String(id) === layer.key)) {
      defaultLayers.add(layer.key);
    }
  });
  return {
    enabled: link.available !== false && (link.selectedByDefault || enableFirst),
    levelKey: defaultLevel,
    height: link.defaultHeight ?? nullableNumber(state.context.defaults?.heightMm ?? state.context.defaults?.height),
    layerKeys: defaultLayers
  };
}

function applyDefaultFamilyMapping(state) {
  const defaults = state.context.defaults || {};
  if (!findFamily(state, state.familyKey)) {
    state.familyKey = findKeyByHostId(state.context.families, defaults.familyId)
      || state.context.families.find((family) => family.supported !== false)?.key
      || '';
  }
  const family = findFamily(state, state.familyKey);
  if (!family) return;
  if (!family.types.some((type) => type.key === state.typeKey)) {
    state.typeKey = findKeyByHostId(family.types, defaults.familySymbolElementId ?? defaults.typeId)
      || family.types[0]?.key
      || '';
  }
  const parameters = getAvailableParameters(state);
  if (!parameters.some((parameter) => parameter.key === state.diameterParameterKey)) {
    state.diameterParameterKey = findParameterKey(parameters, defaults.diameterParameterId, defaults.diameterParameterGuid, defaults.diameterParameterName);
  }
  if (!parameters.some((parameter) => parameter.key === state.heightParameterKey)) {
    state.heightParameterKey = findParameterKey(parameters, defaults.heightParameterId, defaults.heightParameterGuid, defaults.heightParameterName);
  }
  const textParameters = getAvailableTextParameters(state);
  if (!textParameters.some((parameter) => parameter.key === state.sourceLayerParameterKey)) {
    state.sourceLayerParameterKey = findParameterKey(
      textParameters,
      defaults.sourceLayerParameterId,
      defaults.sourceLayerParameterGuid,
      defaults.sourceLayerParameterName
    );
  }
}

function mergeToleranceDefaults(state, incoming) {
  const source = objectFrom(incoming);
  const aliases = {
    endpointMm: ['endpointMm', 'endpointTolerance', 'endpointToleranceMm', 'endpointMillimeters'],
    planeMm: ['planeMm', 'planeTolerance', 'planeToleranceMm', 'planeMillimeters'],
    fitAbsoluteMm: ['fitAbsoluteMm', 'circleFitAbsoluteTolerance', 'fitToleranceMm', 'absoluteRadialMillimeters'],
    fitRelativePercent: ['fitRelativePercent', 'circleFitRelativeTolerancePercent', 'relativeRadialPercent'],
    horizontalAngleDeg: ['horizontalAngleDeg', 'horizontalAngleToleranceDegrees', 'horizontalAngleDegrees'],
    duplicateCenterMm: ['duplicateCenterMm', 'duplicateCenterTolerance', 'duplicateCenterMillimeters'],
    duplicateDiameterMm: ['duplicateDiameterMm', 'duplicateDiameterTolerance', 'duplicateDiameterMillimeters'],
    minimumDiameterMm: ['minimumDiameterMm', 'minimumDiameter', 'minimumDiameterMillimeters'],
    maximumDiameterMm: ['maximumDiameterMm', 'maximumDiameter', 'maximumDiameterMillimeters'],
    minimumStraightSegments: ['minimumStraightSegments', 'minimumLineSegments'],
    minimumCoverageDegrees: ['minimumCoverageDegrees'],
    maximumAngularGapDegrees: ['maximumAngularGapDegrees']
  };
  Object.entries(aliases).forEach(([key, names]) => {
    const value = readAny(source, names);
    if (value == null) return;
    state.tolerance[key] = nullableNumber(value);
  });
  const relativeRatio = nullableNumber(readAny(source, ['relativeRadialRatio']));
  if (relativeRatio != null) state.tolerance.fitRelativePercent = relativeRatio * 100;
}

function invalidatePreview(state, message) {
  if (!state.candidates.length && !state.scanId) {
    renderLinks(state);
    renderValidation(state);
    updateActionState(state);
    return;
  }
  state.candidates = [];
  state.selectedCandidates.clear();
  state.scanId = '';
  state.previewSummary = {};
  state.previewMessage = message;
  state.result = null;
  renderLinks(state);
  renderPreview(state);
  renderValidation(state);
  renderResult(state);
  updateActionState(state);
}

function getFilteredCandidates(state) {
  const query = state.filter.query;
  return state.candidates.filter((candidate) => {
    if (state.filter.linkKey && candidate.linkKey !== state.filter.linkKey) return false;
    if (state.filter.layerKey && candidate.layerKey !== state.filter.layerKey) return false;
    if (state.filter.status === 'accepted' && !candidate.selectable) return false;
    if (state.filter.status === 'rejected' && candidate.selectable) return false;
    if (state.filter.status === 'selected' && !state.selectedCandidates.has(candidate.key)) return false;
    if (!query) return true;
    return [candidate.key, candidate.linkName, candidate.layerName, candidate.representation, candidate.reason]
      .some((value) => String(value || '').toLocaleLowerCase().includes(query));
  });
}

function getAvailableParameters(state) {
  const type = findType(state, state.typeKey);
  const family = findFamily(state, state.familyKey);
  return uniqueParameters([...(type?.parameters || []), ...(family?.parameters || []), ...state.context.parameters])
    .filter((parameter) => parameter.writable !== false && parameter.scope !== 'type' && isLengthParameter(parameter));
}

function getAvailableTextParameters(state) {
  const type = findType(state, state.typeKey);
  const family = findFamily(state, state.familyKey);
  return uniqueParameters([...(type?.parameters || []), ...(family?.parameters || []), ...state.context.parameters])
    .filter((parameter) => parameter.writable !== false && parameter.scope !== 'type' && isTextParameter(parameter));
}

function isLengthParameter(parameter) {
  const dataType = String(parameter?.dataType || '').toLocaleLowerCase();
  return !dataType || /length|길이|spec:length|autodesk\.spec\.aec:length/.test(dataType);
}

function isTextParameter(parameter) {
  const dataType = String(parameter?.dataType || '').toLocaleLowerCase();
  return /text|string|문자|autodesk\.spec.*string/.test(dataType);
}

function findFamily(state, key) {
  return state.context.families.find((family) => family.key === key) || null;
}

function findType(state, key) {
  for (const family of state.context.families) {
    const type = family.types.find((item) => item.key === key);
    if (type) return type;
  }
  return null;
}

function findParameter(state, key) {
  return getAvailableParameters(state).find((parameter) => parameter.key === key) || null;
}

function findTextParameter(state, key) {
  return getAvailableTextParameters(state).find((parameter) => parameter.key === key) || null;
}

function findLink(state, key) {
  return state.context.links.find((link) => link.key === key) || null;
}

function findLevel(state, key) {
  return state.context.levels.find((level) => level.key === key) || null;
}

function findKeyByHostId(items, hostId) {
  if (hostId == null) return '';
  return items.find((item) => idEquals(item.hostId, hostId))?.key || '';
}

function findParameterKey(parameters, id, guid, name) {
  return parameters.find((parameter) => (
    (id != null && idEquals(parameter.hostId, id))
    || (guid && parameter.guid.toLocaleLowerCase() === String(guid).toLocaleLowerCase())
    || (name && (parameter.name === String(name) || idEquals(parameter.hostKey, name)))
  ))?.key || '';
}

function enabledLinkCount(state) {
  return state.context.links.filter((link) => state.linkConfig.get(link.key)?.enabled).length;
}

function createPublicStateSnapshot(state) {
  return {
    contextLoaded: state.contextLoaded,
    busy: state.busy,
    scanId: state.scanId,
    familyKey: state.familyKey,
    typeKey: state.typeKey,
    diameterParameterKey: state.diameterParameterKey,
    heightParameterKey: state.heightParameterKey,
    sourceLayerParameterKey: state.sourceLayerParameterKey,
    layerRequests: Object.fromEntries(state.layerRequests),
    layerStatus: Object.fromEntries(state.layerStatus),
    layerErrors: Object.fromEntries(state.layerErrors),
    existingPolicy: state.existingPolicy,
    tolerance: { ...state.tolerance },
    links: buildLinkPayloads(state, true),
    candidateCount: state.candidates.length,
    selectedCandidateKeys: Array.from(state.selectedCandidates),
    result: state.result ? { ...state.result } : null,
    error: state.lastError ? { ...state.lastError } : null
  };
}

function notifyState(state, options) {
  const snapshot = createPublicStateSnapshot(state);
  try { options.onStateChange?.(snapshot); } catch (error) { console.error('[cadcircle] onStateChange failed', error); }
  window.dispatchEvent(new CustomEvent('cadcircle:ui-state', { detail: snapshot }));
}

function normalizeIncomingMessage(eventOrMessage, optionalPayload) {
  if (typeof eventOrMessage === 'string') return { ev: eventOrMessage, payload: objectOrValue(optionalPayload) };
  const source = objectFrom(eventOrMessage);
  return {
    ev: readString(source, ['ev', 'event', 'type', 'name'], ''),
    payload: objectOrValue(source.payload ?? source.data ?? source.detail ?? optionalPayload ?? {})
  };
}

function isStaleResponse(payload, expectedRequestId) {
  const received = getResponseRequestId(payload);
  return !expectedRequestId || !received || received !== expectedRequestId;
}

function getResponseRequestId(payload) {
  const envelope = objectFrom(payload);
  const nestedSources = [
    envelope,
    objectFrom(envelope.data),
    objectFrom(envelope.context),
    objectFrom(envelope.preview),
    objectFrom(envelope.result),
    objectFrom(envelope.error)
  ];
  for (const source of nestedSources) {
    const requestId = readString(source, ['requestId', 'correlationId'], '').trim();
    if (requestId) return requestId;
  }
  return '';
}

function correlateInitialContext(payload) {
  const source = objectFrom(payload);
  const requestId = getResponseRequestId(source) || createRequestId('initial-context');
  return { ...source, requestId };
}

function requestOperationFromEvent(eventName) {
  if (eventName === CAD_CIRCLE_EVENTS.init) return 'init';
  if (eventName === CAD_CIRCLE_EVENTS.layers) return 'layers';
  if (eventName === CAD_CIRCLE_EVENTS.scan) return 'scan';
  if (eventName === CAD_CIRCLE_EVENTS.apply) return 'apply';
  return '';
}

function normalizeRequestOperation(value) {
  const normalized = String(value || '').trim().toLocaleLowerCase();
  if (normalized === 'context' || normalized === 'init') return 'init';
  if (normalized === 'layers' || normalized === 'layer' || normalized === 'layers-result') return 'layers';
  if (normalized === 'preview' || normalized === 'scan') return 'scan';
  if (normalized === 'result' || normalized === 'apply') return 'apply';
  return '';
}

function documentIdentityMatches(leftValue, rightValue) {
  const left = objectFrom(leftValue);
  const right = objectFrom(rightValue);
  const leftPath = normalizeDocumentIdentityText(readString(left, ['path', 'filePath'], ''));
  const rightPath = normalizeDocumentIdentityText(readString(right, ['path', 'filePath'], ''));
  if (leftPath && rightPath) return leftPath === rightPath;

  const leftName = normalizeDocumentIdentityText(readString(left, ['name', 'title'], ''));
  const rightName = normalizeDocumentIdentityText(readString(right, ['name', 'title'], ''));
  return Boolean(leftName && rightName && leftName === rightName);
}

function normalizeDocumentIdentityText(value) {
  return String(value || '').trim().replace(/\//g, '\\').toLocaleLowerCase();
}

function createRequestId(kind) {
  requestSerial += 1;
  return `cadcircle-${kind}-${Date.now().toString(36)}-${requestSerial.toString(36)}`;
}

function objectFrom(value) {
  const parsed = parseJsonish(value);
  return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
}

function objectOrValue(value) {
  return parseJsonish(value);
}

function parseJsonish(value) {
  if (typeof value !== 'string') return value ?? {};
  const text = value.trim();
  if (!text || (!text.startsWith('{') && !text.startsWith('['))) return { message: value };
  try { return JSON.parse(text); } catch { return { message: value }; }
}

function firstArray(...values) {
  for (const value of values) {
    if (Array.isArray(value)) return value;
    const parsed = parseJsonish(value);
    if (Array.isArray(parsed)) return parsed;
  }
  return [];
}

function readAny(source, keys) {
  for (const key of keys) {
    if (source && Object.prototype.hasOwnProperty.call(source, key) && source[key] != null) return source[key];
  }
  return null;
}

function readString(source, keys, fallback = '') {
  const value = readAny(source, keys);
  return value == null ? fallback : String(value);
}

function readBoolean(source, keys, fallback) {
  const value = readAny(source, keys);
  if (value == null) return fallback;
  if (typeof value === 'string') {
    const normalized = value.trim().toLocaleLowerCase();
    if (['false', '0', 'no', 'off', 'unloaded'].includes(normalized)) return false;
    if (['true', '1', 'yes', 'on', 'loaded'].includes(normalized)) return true;
  }
  return Boolean(value);
}

function numberFrom(source, keys, fallback = 0) {
  const value = nullableNumber(readAny(source, keys));
  return value == null ? fallback : value;
}

function nullableNumber(value) {
  if (value == null || value === '') return null;
  const normalized = typeof value === 'string' ? value.replace(/,/g, '').trim() : value;
  const number = Number(normalized);
  return Number.isFinite(number) ? number : null;
}

function keyFrom(value, fallback) {
  if (value == null || value === '') return String(fallback ?? '');
  return String(value);
}

function idEquals(left, right) {
  return left != null && right != null && String(left) === String(right);
}

function uniqueStrings(values) {
  return Array.from(new Set(values.filter(Boolean)));
}

function uniqueHostValues(values) {
  const seen = new Set();
  const result = [];
  values.forEach((value) => {
    if (value == null || value === '') return;
    const key = `${typeof value}:${String(value)}`;
    if (seen.has(key)) return;
    seen.add(key);
    result.push(value);
  });
  return result;
}

function uniqueParameters(parameters) {
  const map = new Map();
  parameters.filter(Boolean).forEach((parameter) => {
    const identity = parameter.guid || parameter.hostId || parameter.hostKey || parameter.key || parameter.name;
    if (!map.has(String(identity))) map.set(String(identity), parameter);
  });
  return Array.from(map.values());
}

function optionMarkup(value, label, selected) {
  return `<option value="${escapeAttr(value)}" ${selected ? 'selected' : ''}>${escapeHtml(label)}</option>`;
}

function emptyMarkup(message, compact = false) {
  return `<div class="cadcircle-empty ${compact ? 'is-compact' : ''}"><span aria-hidden="true">○</span><p>${escapeHtml(message)}</p></div>`;
}

function metricMarkup(label, value, tone = '') {
  return `<div class="cadcircle-metric ${tone ? `is-${tone}` : ''}"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`;
}

function validationMarkup(tone, title, items) {
  return `
    <div class="cadcircle-validation-head is-${escapeAttr(tone)}">
      <span aria-hidden="true">${tone === 'ready' ? '✓' : tone === 'error' ? '!' : tone === 'warning' ? '△' : '…'}</span>
      <strong>${escapeHtml(title)}</strong>
    </div>
    <ul>${items.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}</ul>`;
}

function displayCoordinate(display, value) {
  if (display) return escapeHtml(display);
  if (value == null) return '-';
  return escapeHtml(formatNumber(value));
}

function displayNumber(value, unit) {
  return value == null ? '' : `${formatNumber(value)} ${unit}`;
}

function formatNumber(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return '-';
  return new Intl.NumberFormat('ko-KR', { maximumFractionDigits: 3 }).format(number);
}

function formatInteger(value) {
  const number = Number(value);
  return Number.isFinite(number) ? new Intl.NumberFormat('ko-KR', { maximumFractionDigits: 0 }).format(number) : '0';
}

function formatConfidence(value) {
  if (value == null || value === '') return '';
  if (typeof value === 'string' && !Number.isFinite(Number(value))) return value;
  const number = Number(value);
  if (!Number.isFinite(number)) return '';
  return number <= 1 ? `신뢰도 ${Math.round(number * 100)}%` : `신뢰도 ${Math.round(number)}%`;
}

function normalizeResultStatus(value) {
  const status = String(value || '').toLocaleLowerCase();
  if (/fail|error|invalid/.test(status)) return 'failed';
  if (/skip|duplicate|ignored/.test(status)) return 'skipped';
  if (/update|changed/.test(status)) return 'updated';
  return 'created';
}

function statusLabel(status) {
  return ({ created: '생성', updated: '갱신', skipped: '건너뜀', failed: '실패' })[status] || status;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, '&#96;');
}

if (typeof window !== 'undefined') {
  window.KKYCadCirclePlacement = Object.assign(window.KKYCadCirclePlacement || {}, {
    events: CAD_CIRCLE_EVENTS,
    mount: renderCadCirclePlacement,
    render: renderCadCirclePlacement,
    receive: receiveCadCircleMessage,
    destroy: destroyCadCirclePlacement,
    getState: () => activeController?.getState() || null,
    requestInit: () => activeController?.requestInit() ?? false,
    requestLayers: (linkKey, force = false) => activeController?.requestLayers(linkKey, force) ?? false,
    requestScan: () => activeController?.requestScan() ?? false,
    requestApply: () => activeController?.requestApply() ?? false
  });
}
