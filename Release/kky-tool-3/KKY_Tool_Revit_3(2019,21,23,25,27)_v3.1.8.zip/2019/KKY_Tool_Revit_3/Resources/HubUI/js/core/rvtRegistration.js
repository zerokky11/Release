// Opt-in presentation for existing RVT registration controls; state stays in each view.
let nextDialogId = 0;
export function createRvtRegistration(options) {
  const { overlay, dialog, header, actions, body, tableWrap, table, onClose } = options;
  const mode = options.openClass || 'is-hidden';
  const titleId = 'rvt-registration-title-' + (++nextDialogId);
  const oldTitle = options.subtitle || header.querySelector('h3, .sharedparambatch-modal__title')?.textContent || '';
  overlay.classList.add('rvt-registration');
  dialog.classList.add('rvt-registration__dialog');
  header.classList.add('rvt-registration__header');
  body.classList.add('rvt-registration__body');
  tableWrap.classList.add('rvt-registration__viewport');
  table.classList.add('rvt-registration__table');
  dialog.setAttribute('role', 'dialog');
  dialog.setAttribute('aria-modal', 'true');
  dialog.setAttribute('aria-labelledby', titleId);
  const titleBox = document.createElement('div');
  const title = document.createElement('h3');
  title.id = titleId; title.textContent = '대상 RVT 등록';
  const subtitle = document.createElement('p'); subtitle.textContent = oldTitle;
  const count = document.createElement('span');
  count.className = 'rvt-registration__count'; count.setAttribute('aria-live', 'polite');
  titleBox.append(title, subtitle, count);
  const x = document.createElement('button'); x.type = 'button';
  x.className = 'btn btn--secondary rvt-registration__close';
  x.textContent = '×'; x.setAttribute('aria-label', options.cancelOnClose ? '취소하고 닫기' : '닫기');
  x.addEventListener('click', onClose);
  header.replaceChildren(titleBox, x);
  actions.classList.add('rvt-registration__actions');
  actions.querySelectorAll('button').forEach(button => button.classList.add('btn', 'btn--secondary'));
  options.addButton.classList.remove('btn--secondary');
  options.addButton.classList.add('btn--primary');
  dialog.insertBefore(actions, body);
  let footer = options.footer;
  if (!footer) { footer = document.createElement('div'); dialog.append(footer); }
  footer.classList.add('rvt-registration__footer');
  if (options.closeButton) {
    options.closeButton.classList.add('btn', 'btn--secondary');
    footer.append(options.closeButton);
  }
  const empty = options.empty || document.createElement('div');
  empty.classList.add('rvt-registration__empty');
  if (!options.empty) {
    const strong = document.createElement('strong'); strong.textContent = '등록된 RVT가 없습니다.';
    const text = document.createElement('span'); text.textContent = 'RVT 추가를 누르거나 탐색기에서 .rvt 파일을 끌어오세요.';
    const add = document.createElement('button'); add.type = 'button';
    add.className = 'btn btn--primary'; add.textContent = 'RVT 추가';
    add.addEventListener('click', () => options.addButton.click());
    empty.append(strong, text, add); tableWrap.append(empty);
  } else {
    const text = empty.querySelector('span');
    if (text) text.textContent = 'RVT 추가를 누르거나 탐색기에서 .rvt 파일을 끌어오세요.';
  }
  let opener = null, opened = false, disposed = false;
  const refresh = () => {
    const rows = Array.from(table.querySelectorAll('tbody input[type="checkbox"]'));
    const selected = rows.filter(row => row.checked).length;
    const master = table.querySelector('thead input[type="checkbox"]');
    if (master) {
      master.checked = rows.length > 0 && selected === rows.length;
      master.indeterminate = selected > 0 && selected < rows.length;
      master.disabled = rows.length === 0;
      master.setAttribute('aria-label', '등록된 RVT 전체 선택');
    }
    count.textContent = '등록 ' + rows.length + '개 · 선택 ' + selected + '개';
    empty.style.display = rows.length ? 'none' : 'flex';
    table.style.display = rows.length ? 'table' : 'none';
    const emptyAdd = empty.querySelector('button');
    if (emptyAdd) emptyAdd.disabled = options.addButton.disabled;
  };
  const focusable = () => Array.from(dialog.querySelectorAll('button, input, select, textarea, a[href], [tabindex]'))
    .filter(el => !el.disabled && el.tabIndex >= 0 && el.getClientRects().length);
  const keydown = event => {
    if (!opened || !overlay.isConnected || event.isComposing || event.keyCode === 229) return;
    // A host picker or removed row can leave focus on body. Other open dialogs
    // keep their own keyboard handling (for example the progress window).
    if (!overlay.contains(event.target) && event.target !== document.body) return;
    if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); onClose(); }
    if (event.key !== 'Tab') return;
    const list = focusable(); if (!list.length) return;
    const first = list[0], last = list[list.length - 1];
    if (!overlay.contains(document.activeElement)) { event.preventDefault(); first.focus(); }
    else if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  };
  // Delegated refresh runs after the existing per-view checkbox callback.
  overlay.addEventListener('change', refresh);
  overlay.addEventListener('kky:rvt-rows-rendered', refresh);
  const api = {
    refresh,
    open() {
      if (disposed) return;
      if (!opened) { opener = document.activeElement; opened = true; document.addEventListener('keydown', keydown); }
      if (mode === 'is-open') overlay.classList.add('is-open'); else overlay.classList.remove('is-hidden');
      overlay.setAttribute('aria-hidden', 'false'); refresh();
      if (!overlay.contains(document.activeElement)) (options.addButton.disabled ? x : options.addButton).focus({ preventScroll: true });
    },
    close() {
      if (mode === 'is-open') overlay.classList.remove('is-open'); else overlay.classList.add('is-hidden');
      overlay.setAttribute('aria-hidden', 'true');
      document.removeEventListener('keydown', keydown);
      const restore = opened && opener?.isConnected; opened = false;
      if (restore) opener.focus({ preventScroll: true });
      opener = null;
    },
    dispose() {
      if (disposed) return; disposed = true; opened = false; opener = null;
      overlay.removeEventListener('change', refresh);
      overlay.removeEventListener('kky:rvt-rows-rendered', refresh);
      document.removeEventListener('keydown', keydown);
      x.removeEventListener('click', onClose);
    }
  };
  overlay.setAttribute('aria-hidden', 'true');
  refresh();
  return api;
}

