// Resources/HubUI/js/views/rvtRegistration3.js
import { clear, div, toast } from '../core/dom.js?v=20260731parameterexport1';
import { onHost, post } from '../core/bridge.js';
import { isAccRvt, accRvtName, accRvtLabel, rememberAccRvtLocations } from '../core/accRvt.js';
import { attachRvtDropZone } from '../core/rvtDrop.js?v=20260506a';
import { getTopbarState, TOPBAR_STATE_CHANGE_EVENT } from '../core/topbar.js?v=20261012official318';
import { renderShell3 } from '../core/shell3.js?v=20261012official318';
import { getFeatureById3 } from '../core/featureCatalog3.js?v=20260917columnnumber1';
import {
  addRvtTargets3,
  clearRvtTargets3,
  getCheckedRvtPaths3,
  getRvtTargets3,
  getSelectedFeatureIds3,
  removeCheckedRvtTargets3,
  removeOtherAccUsers3,
  setAllRvtTargetsChecked3,
  toggleRvtTarget3,
  WORKFLOW3_CHANGE_EVENT
} from '../core/workflowState3.js?v=20260731sharedsettings3';

const WORKFLOW3_PENDING_SELECTION_KEY = 'kky.hub.workflow3.pendingSelection';
const WORKFLOW3_PENDING_RVTS_KEY = 'kky.hub.workflow3.pendingRvts';
const WORKFLOW3_PENDING_RUN_TARGET_KEY = 'kky.hub.workflow3.pendingRunTarget';
const WORKFLOW3_PENDING_ACTIVE_DOCUMENT_KEY = 'kky.hub.workflow3.pendingActiveDocument';
const MULTI_MODE_KEY = 'kky.hub.multiMode';

export function renderRvtRegistration3(root) {
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);
  const dialogMode = isWorkflow3DialogMode();
  const requestedTargetMode = readRequestedTargetMode();
  const directMode = requestedTargetMode === 'active' || requestedTargetMode === 'rvt';

  const state = {
    targetMode: requestedTargetMode || (getRvtTargets3().length ? 'rvt' : 'active'),
    directMode
  };

  const main = div(`workflow3-main rvt3-main${directMode ? ' rvt3-main--direct' : ''}`);
  const targetPanel = div('shell3-panel rvt3-target-panel rvt-drop-zone');
  if (!directMode) main.append(buildSteps());
  main.append(targetPanel);

  const simpleAside = state.directMode || state.targetMode === 'active';
  const aside = div(`workflow3-aside rvt3-aside${simpleAside ? ' rvt3-aside--active' : ''}`);
  const scope = div('shell3-panel rvt3-scope');
  const support = div('shell3-panel rvt3-feature-queue');
  const note = div('shell3-notice');
  note.innerHTML = '<strong>여러 RVT 검토</strong><span>왼쪽 목록에서 체크된 RVT만 실행 대상으로 넘어갑니다. 결과 요약과 엑셀 저장은 실행 단계의 기존 흐름을 그대로 사용합니다.</span>';
  if (simpleAside) aside.append(support);
  else aside.append(scope, support, note);

  const pageTitle = state.targetMode === 'rvt' ? '여러 RVT 검토' : '활성 문서 검토';
  const pageSubtitle = state.targetMode === 'rvt'
    ? 'RVT를 추가하거나 끌어다 놓고, 체크한 파일만 검토 대상으로 확정합니다.'
    : '현재 열린 Revit 문서 중 검토할 문서를 간단히 선택합니다.';

  if (dialogMode) {
    renderWorkflow3DialogShell(target, {
      kicker: 'KKY Tool 3.0',
      title: pageTitle,
      subtitle: pageSubtitle,
      main,
      aside
    });
  } else {
    renderShell3(target, {
      active: 'rvt',
      layout: 'workflow',
      title: pageTitle,
      subtitle: pageSubtitle,
      main,
      aside
    });
    installRvt3BackButton(target);
  }

  let renderGeneration = 0;
  const render = () => {
    const generation = ++renderGeneration;
    const focusedKey = target.contains(document.activeElement) ? document.activeElement?.dataset?.rvtFocusKey : null;
    const scrolls = [];
    for (let node = targetPanel; node; node = node.parentElement) scrolls.push([node, node.scrollTop, node.scrollLeft]);
    const list = targetPanel.querySelector('.rvt3-table');
    const listScroll = list ? [list.scrollTop, list.scrollLeft] : null;
    renderTargetPanel(targetPanel, state, render);
    if (state.targetMode === 'rvt' && !state.directMode) renderScope(scope, state);
    renderFeatureQueue(support);
    const restore = () => {
      if (generation !== renderGeneration || !main.isConnected) return;
      if (focusedKey) [...target.querySelectorAll('[data-rvt-focus-key]')].find(node => node.dataset.rvtFocusKey === focusedKey)?.focus({ preventScroll: true });
      scrolls.forEach(([node, top, left]) => { node.scrollTop = top; node.scrollLeft = left; });
      const currentList = targetPanel.querySelector('.rvt3-table');
      if (listScroll && currentList) { currentList.scrollTop = listScroll[0]; currentList.scrollLeft = listScroll[1]; }
    };
    restore();
    requestAnimationFrame(restore);
  };

  attachRvtDropZone(targetPanel, {
    onDropPaths: (paths) => {
      state.targetMode = 'rvt';
      const result = addRvtTargets3(paths);
      if (result.added > 0) toast(`${result.added}개 RVT를 추가했습니다.`, 'ok');
      else toast('이미 등록된 RVT입니다.', 'warn');
      render();
    },
    onInvalid: () => toast('RVT 파일만 드래그해서 추가할 수 있습니다.', 'warn')
  });

  const onChange = () => {
    if (!main.isConnected) {
      window.removeEventListener(WORKFLOW3_CHANGE_EVENT, onChange);
      window.removeEventListener(TOPBAR_STATE_CHANGE_EVENT, onChange);
      return;
    }
    render();
  };

  onHost('hub:rvt-picked', (payload) => {
    if (!main.isConnected) return;
    rememberAccRvtLocations(payload?.locations);
    const paths = Array.isArray(payload?.paths) ? payload.paths : [];
    state.targetMode = 'rvt';
    const result = addRvtTargets3(paths);
    if (paths.length && result.added === 0) toast('이미 등록된 RVT입니다.', 'warn');
    else if (result.added > 0) toast(`${result.added}개 RVT를 추가했습니다.`, 'ok');
    render();
  });

  onHost('hub:acc-context', (payload) => {
    if (!main.isConnected) return;
    removeOtherAccUsers3(String(payload?.ownerKey || ''));
  });
  post('hub:acc-context', {});

  window.addEventListener(WORKFLOW3_CHANGE_EVENT, onChange);
  window.addEventListener(TOPBAR_STATE_CHANGE_EVENT, onChange);
  render();
}

function buildSteps() {
  const steps = div('workflow3-steps');
  const mode = getCurrentWorkflowMode();
  const featureRoute = mode === 'favorites' ? '#favorites' : (mode === 'utility' ? '#utility' : '#bqc');
  const items = [
    { step: '1단계', title: '기능 선택', route: featureRoute },
    { step: '2단계', title: '기능 설정', action: goToWorkflow3Settings },
    { step: '3단계', title: '대상 선택', active: true },
    { step: '4단계', title: '실행 준비', action: () => continueToWorkflow3Run() }
  ];
  items.forEach((item) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `workflow3-step${item.active ? ' is-active' : ''}`;
    button.innerHTML = `<span>${escapeHtml(item.step)}</span><strong>${escapeHtml(item.title)}</strong>`;
    button.addEventListener('click', () => {
      if (item.route) location.hash = item.route.replace(/^#/, '');
      else if (typeof item.action === 'function') item.action();
    });
    steps.append(button);
  });
  return steps;
}

function renderTargetPanel(host, state, rerender) {
  clear(host);
  const targets = getRvtTargets3();
  const checked = getCheckedRvtPaths3();
  if (state.directMode && state.targetMode === 'rvt') {
    host.append(buildPanelHead('RVT Target', 'RVT 검토 대상', `${checked.length}/${targets.length || 0}`));
    host.append(buildRvtTargetBlock(targets, checked));
    return;
  }
  if (state.directMode && state.targetMode === 'active') {
    host.append(buildPanelHead('Active Document', '활성 문서 검토 대상', '선택'));
    host.append(buildActiveDocumentPickerBlock());
    return;
  }

  host.append(buildPanelHead('Target', '최종 실행 대상', state.targetMode === 'rvt' ? `${checked.length}/${targets.length}` : '활성 문서'));

  const modes = div('rvt3-mode-grid');
  modes.append(
    buildModeCard('active', '현재 활성 문서', getActiveDocumentLabel(), state.targetMode, () => {
      state.targetMode = 'active';
      rerender();
    }),
    buildModeCard('rvt', '등록 RVT', targets.length ? `${targets.length}개 등록, ${checked.length}개 선택` : '여러 RVT 배치 실행', state.targetMode, () => {
      state.targetMode = 'rvt';
      rerender();
    })
  );
  host.append(modes);

  if (state.targetMode === 'active') {
    host.append(buildActiveTargetBlock());
  } else {
    host.append(buildRvtTargetBlock(targets, checked));
  }
}

function buildModeCard(mode, title, desc, activeMode, onClick) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = `rvt3-mode-card${mode === activeMode ? ' is-active' : ''}`;
  button.innerHTML = `<strong>${escapeHtml(title)}</strong><span>${escapeHtml(desc || '')}</span>`;
  button.addEventListener('click', onClick);
  return button;
}

function buildActiveTargetBlock() {
  const block = div('rvt3-active-target');
  const doc = getRunnableActiveDocument();
  block.innerHTML = `
    <div>
      <strong>${escapeHtml(getActiveDocumentLabel())}</strong>
      <span>${escapeHtml(getActiveDocumentPath() || '현재 Revit에서 열린 문서를 대상으로 실행합니다.')}</span>
    </div>`;
  const button = makeButton('검토 시작', () => continueToWorkflow3Run({ targetMode: 'active', activeDocument: doc, autoRun: true }), 'shell3-btn shell3-btn--primary rvt3-compact-btn');
  block.append(button);
  return block;
}

function buildActiveDocumentPickerBlock() {
  const docs = normalizeTopbarDocuments(getTopbarState().documents).filter((doc) => !isLinkedDocument(doc));
  const active = normalizeDocumentItem(getTopbarState().activeDocument || {});
  const activeFallback = !isLinkedDocument(active) && (active.name || active.path) ? active : null;
  const available = docs.length ? docs : (activeFallback ? [activeFallback] : []);
  const block = div('rvt3-active-picker');

  if (!available.length) {
    const fallback = div('rvt3-active-target rvt3-active-target--single');
    fallback.innerHTML = `
      <div>
        <strong>현재 활성 문서 확인</strong>
        <span>화면 목록이 비어 있어도 Revit에서 열린 일반 문서를 다시 찾아 검토합니다.</span>
      </div>`;
    const button = makeButton('검토 시작', () => continueToWorkflow3Run({ targetMode: 'active', activeDocument: {}, autoRun: true }), 'shell3-btn shell3-btn--primary rvt3-compact-btn');
    fallback.append(button);
    block.append(fallback);
    return block;
  }

  if (available.length === 1) {
    const doc = available[0];
    const card = div('rvt3-active-target rvt3-active-target--single');
    card.innerHTML = `
      <div>
        <strong>${escapeHtml(doc.name || '현재 활성 문서')}</strong>
        <span>${escapeHtml(doc.path || '저장되지 않은 문서')}</span>
      </div>`;
    const button = makeButton('검토 시작', () => continueToWorkflow3Run({ targetMode: 'active', activeDocument: doc, autoRun: true }), 'shell3-btn shell3-btn--primary rvt3-compact-btn');
    card.append(button);
    block.append(card);
    return block;
  }

  const list = div('rvt3-doc-select-list');
  available.forEach((doc) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `rvt3-doc-choice${isSameDocument(doc, active) ? ' is-active' : ''}`;
    button.innerHTML = `
      <div>
        <strong>${escapeHtml(doc.name || '문서')}</strong>
        <span>${escapeHtml(doc.path || '저장되지 않은 문서')}</span>
      </div>
      <em>${isSameDocument(doc, active) ? '현재 활성' : '선택'}</em>`;
    button.addEventListener('click', () => activateAndContinueDocument(doc));
    list.append(button);
  });
  block.append(list);
  return block;
}

function buildRvtTargetBlock(targets, checked) {
  const block = div('rvt3-rvt-target');
  const toolbar = div('rvt3-inline-toolbar');
  const add = makeButton('RVT 추가', () => post('hub:pick-rvt', {}), 'shell3-btn shell3-btn--primary rvt3-compact-btn');
  const acc = makeButton('ACC 모델 추가', () => post('hub:pick-acc-models', {}), 'shell3-btn shell3-btn--primary rvt3-compact-btn');
  const openedAcc = makeButton('열린 클라우드 모델 추가', () => post('hub:pick-open-acc-models', {}), 'shell3-btn shell3-btn--ghost rvt3-compact-btn');
  const folder = makeButton('폴더 추가', () => post('hub:pick-rvt-folder', {}), 'shell3-btn shell3-btn--ghost rvt3-compact-btn');
  const selectAll = makeButton('전체 선택', () => setAllRvtTargetsChecked3(true), 'shell3-btn shell3-btn--ghost rvt3-compact-btn');
  const deselectAll = makeButton('선택 해제', () => setAllRvtTargetsChecked3(false), 'shell3-btn shell3-btn--ghost rvt3-compact-btn');
  const remove = makeButton('선택 삭제', () => {
    const result = removeCheckedRvtTargets3();
    if (!result.removed) toast('삭제할 RVT를 선택해 주세요.', 'warn');
  }, 'shell3-btn shell3-btn--ghost rvt3-compact-btn');
  const clearAll = makeButton('목록 비우기', () => {
    if (getRvtTargets3().length) clearRvtTargets3();
  }, 'shell3-btn shell3-btn--ghost rvt3-compact-btn');
  const run = makeButton('실행 준비로', () => continueToWorkflow3Run({ targetMode: 'rvt' }), 'shell3-btn shell3-btn--primary rvt3-run-btn');
  remove.disabled = checked.length === 0;
  clearAll.disabled = targets.length === 0;
  run.disabled = checked.length === 0;
  toolbar.append(add, acc, openedAcc, folder, selectAll, deselectAll, remove, clearAll, run);
  block.append(toolbar);

  const hint = div('rvt3-inline-hint');
  hint.textContent = '로컬 파일은 RVT 추가로, 클라우드 모델은 ACC 모델 추가로 등록하세요. ACC 모델은 실행할 때 클라우드에서 열며, Revit이 작업용 캐시를 관리합니다. 체크된 모델만 다음 단계에서 검토합니다.';
  block.append(hint);

  if (!targets.length) {
    const empty = div('rvt3-empty');
    empty.innerHTML = '<strong>등록된 RVT가 없습니다.</strong><span>파일을 끌어놓거나 RVT 추가를 눌러 등록해 주세요.</span>';
    block.append(empty);
  } else {
    const table = div('rvt3-table');
    table.append(buildTableHeader());
    targets.forEach((target, index) => table.append(buildTargetRow(target, index)));
    block.append(table);
  }

  const footer = div('rvt3-target-footer');
  const summary = document.createElement('span');
  summary.textContent = checked.length ? `${checked.length}개 RVT를 검토 대상으로 선택했습니다.` : '검토할 RVT를 체크해 주세요.';
  footer.append(summary);
  block.append(footer);
  return block;
}

function buildTableHeader() {
  const row = div('rvt3-row rvt3-row--head');
  row.innerHTML = '<span></span><span>파일</span><span>상태</span><span>검토 범위</span><span>선택</span>';
  return row;
}

function buildTargetRow(target, index) {
  const row = div('rvt3-row');
  row.dataset.checked = target.checked ? 'true' : 'false';
  const status = getTargetStatus(target.path);

  const check = document.createElement('button');
  check.type = 'button';
  check.dataset.rvtFocusKey = target.path;
  check.className = 'rvt3-check';
  check.textContent = target.checked ? '✓' : '';
  check.setAttribute('aria-label', `${getPathLeafLabel(target.path)} 선택`);
  check.addEventListener('click', (ev) => {
    ev.stopPropagation();
    toggleRvtTarget3(target.path, !target.checked);
  });

  const file = div('rvt3-file');
  file.innerHTML = `<strong>${escapeHtml(getPathLeafLabel(target.path) || `RVT ${index + 1}`)}</strong><span>${escapeHtml(accRvtLabel(target.path))}</span>`;

  const statusEl = document.createElement('span');
  statusEl.className = `shell3-tag ${status.tone ? `shell3-tag--${status.tone}` : ''}`.trim();
  statusEl.textContent = status.label;

  const scope = document.createElement('span');
  scope.className = 'rvt3-scope-label';
  scope.textContent = status.scope;

  const selected = document.createElement('span');
  selected.className = 'rvt3-selected-label';
  selected.textContent = target.checked ? '검토' : '제외';

  row.append(check, file, statusEl, scope, selected);
  row.addEventListener('click', () => toggleRvtTarget3(target.path, !target.checked));
  return row;
}

function renderScope(host, state) {
  clear(host);
  const targets = getRvtTargets3();
  const checked = getCheckedRvtPaths3();
  const mode = getCurrentWorkflowMode();
  const selectedFeatures = getCurrentWorkflowSelectedIds(mode);
  host.append(buildPanelHead('Scope', '실행 범위', state.targetMode === 'rvt' ? `${checked.length}/${targets.length || 0}` : '활성 문서'));

  const body = div('shell3-context-list');
  body.append(buildContextRow('기능 그룹', mode === 'utility' ? '일반 도구' : 'BQC 검토'));
  body.append(buildContextRow('대상 방식', state.targetMode === 'rvt' ? '등록 RVT 배치 실행' : '현재 활성 문서'));
  body.append(buildContextRow('선택된 RVT', checked.length ? `${checked.length}개 파일` : '선택 없음'));
  body.append(buildContextRow('활성 문서', getActiveDocumentLabel()));
  body.append(buildContextRow('검토 기능', summarizeFeatures(selectedFeatures)));
  host.append(body);

  const actions = div('shell3-button-row');
  const settingsBtn = makeButton('기능 설정으로', goToWorkflow3Settings, 'shell3-btn shell3-btn--ghost rvt3-compact-btn');
  const continueBtn = makeButton('실행 요약으로', () => continueToWorkflow3Run({ targetMode: state.targetMode }), 'shell3-btn shell3-btn--primary rvt3-compact-btn');
  continueBtn.disabled = state.targetMode === 'rvt' && checked.length === 0;
  actions.append(settingsBtn, continueBtn);
  host.append(actions);
}

function renderFeatureQueue(host) {
  clear(host);
  const mode = getCurrentWorkflowMode();
  const selectedFeatures = getCurrentWorkflowSelectedIds(mode);
  host.append(buildPanelHead('Features', '검토 기능', `${selectedFeatures.length}개`));
  const body = div('rvt3-feature-list');
  if (!selectedFeatures.length) {
    const empty = div('rvt3-empty');
    empty.innerHTML = '<strong>선택된 기능이 없습니다.</strong><span>기능 선택 단계에서 실행할 기능을 먼저 선택해 주세요.</span>';
    body.append(empty);
  } else {
    selectedFeatures.forEach((id) => {
      const feature = getFeatureById3(id);
      const row = div('rvt3-feature-row');
      row.innerHTML = `
        <strong>${escapeHtml(feature?.label || id)}</strong>
        <span>${escapeHtml(feature?.categoryLabel || feature?.groupLabel || '검토 기능')}</span>`;
      body.append(row);
    });
  }
  host.append(body);
}

function installRvt3BackButton(target) {
  const shell = target.querySelector('.shell3');
  const title = target.querySelector('.shell3-title');
  if (!shell || !title || title.querySelector('[data-rvt3-back]')) return;
  shell.classList.add('rvt3-shell');
  const copy = div('settings3-top-title-copy');
  while (title.firstChild) copy.append(title.firstChild);
  const back = document.createElement('button');
  back.type = 'button';
  back.className = 'settings3-top-back rvt3-top-back';
  back.dataset.rvt3Back = '1';
  back.innerHTML = '<span aria-hidden="true">&larr;</span><span>뒤로가기</span>';
  back.addEventListener('click', goToWorkflow3Settings);
  title.classList.add('settings3-title-with-back');
  title.append(back, copy);
}

function continueToWorkflow3Run(options = {}) {
  const targetMode = options.targetMode === 'rvt' ? 'rvt' : 'active';
  const targets = getRvtTargets3();
  const checked = getCheckedRvtPaths3();
  if (targetMode === 'rvt' && !checked.length) {
    toast('검토할 RVT를 1개 이상 선택해 주세요.', 'warn');
    return;
  }

  const mode = getCurrentWorkflowMode();
  const selected = getCurrentWorkflowSelectedIds(mode);
  if (!selected.length) {
    toast('기능 선택 단계에서 실행할 기능을 먼저 선택해 주세요.', 'warn');
    return;
  }

  try {
    localStorage.setItem('kky.hub.multiMode', mode);
    localStorage.setItem(WORKFLOW3_PENDING_SELECTION_KEY, JSON.stringify({ mode, selected, createdAt: Date.now() }));
    if (targetMode === 'rvt') {
      localStorage.setItem(WORKFLOW3_PENDING_RVTS_KEY, JSON.stringify({
        paths: targets.map((target) => target.path),
        checkedPaths: checked,
        createdAt: Date.now()
      }));
      localStorage.removeItem(WORKFLOW3_PENDING_ACTIVE_DOCUMENT_KEY);
    } else {
      localStorage.removeItem(WORKFLOW3_PENDING_RVTS_KEY);
      persistWorkflow3ActiveDocument(options.activeDocument || getTopbarState().activeDocument || {});
    }
    localStorage.setItem(WORKFLOW3_PENDING_RUN_TARGET_KEY, JSON.stringify({ targetMode, createdAt: Date.now() }));
  } catch {
  }

  const url = new URL(location.href);
  url.hash = 'run';
  url.searchParams.set('workflow3', String(Date.now()));
  url.searchParams.set('workflow3Mode', mode);
  url.searchParams.set('workflow3Selection', selected.join(','));
  url.searchParams.set('workflow3Rvts', targetMode === 'rvt' ? '1' : '0');
  url.searchParams.set('workflow3Target', targetMode);
  if (options.autoRun === true) url.searchParams.set('workflow3AutoRun', '1');
  else url.searchParams.delete('workflow3AutoRun');
  url.searchParams.delete('workflow3Settings');
  if (isWorkflow3DialogMode()) {
    url.searchParams.set('workflow3Dialog', '1');
    postWorkflow3ParentMessage({
      type: 'kky:workflow3-route',
      href: url.toString()
    });
    return;
  }
  location.replace(url.toString());
}

function activateAndContinueDocument(doc) {
  const target = normalizeDocumentItem(doc || {});
  const active = normalizeDocumentItem(getTopbarState().activeDocument || {});
  const proceed = () => continueToWorkflow3Run({ targetMode: 'active', activeDocument: target.path || target.name ? target : active, autoRun: true });
  if (!target.path || isSameDocument(target, active)) {
    proceed();
    return;
  }
  let done = false;
  const unsubscribeOk = onHost('host:doc-activated', () => {
    if (done) return;
    done = true;
    unsubscribeOk();
    unsubscribeErr();
    window.setTimeout(proceed, 120);
  });
  const unsubscribeErr = onHost('host:doc-activate-error', (payload) => {
    if (done) return;
    done = true;
    unsubscribeOk();
    unsubscribeErr();
    toast(payload?.message || '선택한 문서를 활성화하지 못했습니다.', 'err');
  });
  post('hub:activate-document', target);
  window.setTimeout(() => {
    if (done) return;
    done = true;
    unsubscribeOk();
    unsubscribeErr();
    proceed();
  }, 900);
}

function persistWorkflow3ActiveDocument(doc) {
  const target = normalizeDocumentItem(doc || {});
  try {
    if (!target.name && !target.path) {
      localStorage.removeItem(WORKFLOW3_PENDING_ACTIVE_DOCUMENT_KEY);
      return;
    }
    localStorage.setItem(WORKFLOW3_PENDING_ACTIVE_DOCUMENT_KEY, JSON.stringify({
      ...target,
      createdAt: Date.now()
    }));
  } catch {
  }
}

function renderWorkflow3DialogShell(target, options = {}) {
  clear(target);
  const page = div('workflow3-dialog-page');
  page.innerHTML = `
    <header class="workflow3-dialog-titlebar">
      <div>
        <span class="shell3-kicker">${escapeHtml(options.kicker || 'KKY Tool 3.0')}</span>
        <h1>${escapeHtml(options.title || '')}</h1>
        <p>${escapeHtml(options.subtitle || '')}</p>
      </div>
      <button class="shell3-btn shell3-btn--ghost" type="button" data-dialog-close>닫기</button>
    </header>`;
  const body = div('workflow3-dialog-body');
  body.append(options.main, options.aside);
  page.append(body);
  target.append(page);
  page.querySelector('[data-dialog-close]')?.addEventListener('click', () => {
    postWorkflow3ParentMessage({ type: 'kky:workflow3-close-dialog' });
  });
}

function isWorkflow3DialogMode() {
  try {
    if (!(window.parent && window.parent !== window)) return false;
    return new URLSearchParams(location.search || '').get('workflow3Dialog') === '1';
  } catch {
    return false;
  }
}

function readRequestedTargetMode() {
  try {
    const params = new URLSearchParams(location.search || '');
    const target = String(params.get('workflow3Target') || '').trim().toLowerCase();
    if (target === 'rvt') return 'rvt';
    if (target === 'active') return 'active';
    if (params.get('workflow3Rvts') === '1') return 'rvt';
  } catch {
  }
  try {
    const raw = localStorage.getItem(WORKFLOW3_PENDING_RUN_TARGET_KEY);
    const pending = raw ? JSON.parse(raw) : null;
    const target = String(pending?.targetMode || '').trim().toLowerCase();
    if (target === 'rvt') return 'rvt';
    if (target === 'active') return 'active';
  } catch {
  }
  return '';
}

function postWorkflow3ParentMessage(message) {
  try {
    if (window.parent && window.parent !== window) {
      window.parent.postMessage(message, '*');
    }
  } catch {
  }
}

function goToWorkflow3Settings() {
  const mode = getCurrentWorkflowMode();
  const selected = getCurrentWorkflowSelectedIds(mode);
  if (!selected.length) {
    toast('기능 선택 단계에서 실행할 기능을 먼저 선택해 주세요.', 'warn');
    return;
  }
  try {
    localStorage.setItem('kky.hub.multiMode', mode);
    localStorage.setItem(WORKFLOW3_PENDING_SELECTION_KEY, JSON.stringify({ mode, selected, createdAt: Date.now() }));
  } catch {
  }
  const url = new URL(location.href);
  url.hash = 'settings';
  url.searchParams.set('workflow3', String(Date.now()));
  url.searchParams.set('workflow3Settings', '1');
  url.searchParams.set('workflow3Mode', mode);
  url.searchParams.set('workflow3Selection', selected.join(','));
  url.searchParams.delete('workflow3Dialog');
  url.searchParams.delete('workflow3Target');
  url.searchParams.delete('workflow3Rvts');
  location.replace(url.toString());
}

function getCurrentWorkflowMode() {
  const fromUrl = readWorkflow3SelectionFromUrl();
  if (fromUrl?.mode) return fromUrl.mode;

  const pending = readWorkflow3PendingSelection();
  if (pending?.mode) return pending.mode;

  try {
    const stored = normalizeWorkflowMode(localStorage.getItem(MULTI_MODE_KEY));
    if (stored) return stored;
  } catch {
  }

  const utilitySelected = getSelectedFeatureIds3('utility');
  const favoriteSelected = getSelectedFeatureIds3('favorites');
  const bqcSelected = getSelectedFeatureIds3('bqc');
  if (favoriteSelected.length && !utilitySelected.length && !bqcSelected.length) return 'favorites';
  if (utilitySelected.length && !bqcSelected.length) return 'utility';
  return 'bqc';
}

function getCurrentWorkflowSelectedIds(mode) {
  const key = normalizeWorkflowMode(mode) || 'bqc';
  const fromUrl = readWorkflow3SelectionFromUrl();
  if (fromUrl?.mode === key && fromUrl.selected.length) return fromUrl.selected;

  const pending = readWorkflow3PendingSelection();
  if (pending?.mode === key && pending.selected.length) return pending.selected;

  return getSelectedFeatureIds3(key);
}

function readWorkflow3SelectionFromUrl() {
  try {
    const params = new URLSearchParams(location.search || '');
    const mode = normalizeWorkflowMode(params.get('workflow3Mode'));
    const selected = normalizeIdList(
      String(params.get('workflow3Selection') || '')
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean)
    );
    if (!mode && !selected.length) return null;
    return { mode: mode || 'bqc', selected };
  } catch {
    return null;
  }
}

function readWorkflow3PendingSelection() {
  try {
    const raw = localStorage.getItem(WORKFLOW3_PENDING_SELECTION_KEY);
    if (!raw) return null;
    const pending = JSON.parse(raw);
    const mode = normalizeWorkflowMode(pending?.mode);
    const selected = normalizeIdList(pending?.selected);
    if (!mode && !selected.length) return null;
    return { mode: mode || 'bqc', selected };
  } catch {
    return null;
  }
}

function normalizeWorkflowMode(value) {
  if (value === 'favorites') return 'favorites';
  return value === 'utility' ? 'utility' : value === 'bqc' ? 'bqc' : '';
}

function normalizeIdList(ids) {
  const seen = new Set();
  return (Array.isArray(ids) ? ids : [])
    .map((id) => String(id || '').trim())
    .filter(Boolean)
    .filter((id) => {
      if (seen.has(id)) return false;
      seen.add(id);
      return true;
    });
}

function buildPanelHead(kicker, title, count) {
  const head = div('shell3-panel-head');
  head.innerHTML = `
    <div><span class="shell3-kicker">${escapeHtml(kicker)}</span><h2>${escapeHtml(title)}</h2></div>
    <span class="shell3-tag">${escapeHtml(count)}</span>`;
  return head;
}

function buildContextRow(title, desc) {
  const row = div('shell3-context-row');
  row.innerHTML = `<strong>${escapeHtml(title)}</strong><span>${escapeHtml(desc)}</span>`;
  return row;
}

function makeButton(label, onClick, className) {
  const button = document.createElement('button');
  button.dataset.rvtFocusKey = label;
  button.type = 'button';
  button.className = className || 'shell3-btn shell3-btn--ghost';
  button.textContent = label;
  button.addEventListener('click', onClick);
  return button;
}

function summarizeFeatures(ids) {
  const names = (Array.isArray(ids) ? ids : [])
    .map((id) => getFeatureById3(id)?.label || id)
    .filter(Boolean);
  if (!names.length) return '선택된 기능 없음';
  return names.length > 3 ? `${names.slice(0, 3).join(', ')} 외 ${names.length - 3}개` : names.join(', ');
}

function getTargetStatus(path) {
  if (isAccRvt(path)) return { tone: 'ok', label: 'ACC 모델', scope: '실행 시 권한 확인' };
  const name = getPathLeafLabel(path).toLowerCase();
  if (name.includes('old') || name.includes('backup')) return { tone: 'warn', label: '확인 필요', scope: '버전 확인' };
  if (name.includes('link')) return { tone: 'warn', label: '경고', scope: '링크 확인' };
  return { tone: 'ok', label: '준비됨', scope: '전체 모델' };
}

function getActiveDocumentLabel() {
  const doc = getTopbarState().activeDocument || {};
  return getDocumentName(doc) || '문서 없음';
}

function getActiveDocumentPath() {
  const doc = getTopbarState().activeDocument || {};
  return getDocumentPath(doc);
}

function getRunnableActiveDocument() {
  const active = normalizeDocumentItem(getTopbarState().activeDocument || {});
  if (!isLinkedDocument(active) && (active.name || active.path)) return active;
  const firstHost = normalizeTopbarDocuments(getTopbarState().documents).find((doc) => !isLinkedDocument(doc));
  return firstHost || {};
}

function getDocumentName(doc = {}) {
  return String(doc.name || doc.Name || doc.title || doc.Title || '').trim();
}

function getDocumentPath(doc = {}) {
  return String(doc.path || doc.Path || doc.filePath || doc.FilePath || '').trim();
}

function normalizeTopbarDocuments(docs) {
  const seen = new Set();
  return (Array.isArray(docs) ? docs : [])
    .map(normalizeDocumentItem)
    .filter((doc) => doc.name || doc.path)
    .filter((doc) => {
      const key = (doc.path || doc.name).toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function normalizeDocumentItem(doc = {}) {
  return {
    name: getDocumentName(doc),
    path: getDocumentPath(doc),
    isLinked: doc?.isLinked === true || doc?.IsLinked === true || doc?.linked === true || doc?.Linked === true || doc?.isLink === true || doc?.IsLink === true
  };
}

function isLinkedDocument(doc = {}) {
  return normalizeDocumentItem(doc).isLinked === true;
}

function isSameDocument(left, right) {
  const a = normalizeDocumentItem(left || {});
  const b = normalizeDocumentItem(right || {});
  const ak = (a.path || a.name).toLowerCase();
  const bk = (b.path || b.name).toLowerCase();
  return !!ak && ak === bk;
}

function getPathLeafLabel(path) {
  if (isAccRvt(path)) return accRvtName(path);
  const text = String(path || '').trim();
  return text.split(/[\\/]/).filter(Boolean).pop() || text;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
