import { clear, div, toast, setBusy, showCompletionSummaryDialog, showExcelSavedDialog, chooseExcelMode, getLastExcelExportLocale } from '../core/dom.js?v=20260731parameterexport1';
import { ProgressDialog } from '../core/progress.js';
import { post, onHost } from '../core/bridge.js';
import { attachExcelDropZone } from '../core/excelDrop.js';
import { attachRvtDropZone } from '../core/rvtDrop.js';

const LATERAL_NOZZLE_SETTINGS_KEY = 'kky.settings.lateralnozzle.v1';
let activeLateralNozzlePreferenceCleanup = null;

export function renderLateralNozzle(root) {
  activeLateralNozzlePreferenceCleanup?.();
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);

  const savedSettings = loadLateralNozzlePreferences();
  const savedAdditionalKeywordsText = savedSettings.additionalFamilyOrTypeKeywordsText
    ?? savedSettings.additionalIncludedFamilyOrTypeNamesText
    ?? '';
  const savedActiveTab = ['kta', 'rvt', 'compare'].includes(savedSettings.activeTab)
    ? savedSettings.activeTab
    : 'kta';
  const state = {
    excelPaths: [],
    checked: new Set(),
    lastResult: null,
    activeTab: savedActiveTab,
    rvtPaths: [],
    rvtChecked: new Set(),
    utilityParameterName: savedSettings.utilityParameterName || '',
    lateralParameterName: savedSettings.lateralParameterName || '',
    nozzleCodeParameterNamesText: savedSettings.nozzleCodeParameterNamesText || '',
    additionalParameterNamesText: savedSettings.additionalParameterNamesText || '',
    additionalFamilyOrTypeKeywordsText: String(savedAdditionalKeywordsText || ''),
    parameterPreferenceOwner: {
      utility: Object.prototype.hasOwnProperty.call(savedSettings, 'utilityParameterName'),
      lateral: Object.prototype.hasOwnProperty.call(savedSettings, 'lateralParameterName'),
      nozzle: Object.prototype.hasOwnProperty.call(savedSettings, 'nozzleCodeParameterNamesText'),
      additionalParameters: Object.prototype.hasOwnProperty.call(savedSettings, 'additionalParameterNamesText'),
      additionalKeywords: Object.prototype.hasOwnProperty.call(savedSettings, 'additionalFamilyOrTypeKeywordsText')
        || Object.prototype.hasOwnProperty.call(savedSettings, 'additionalIncludedFamilyOrTypeNamesText')
    },
    rvtLastResult: null,
    comparisonKtaMode: savedSettings.comparisonKtaMode === 'file' ? 'file' : 'recent',
    comparisonRvtMode: savedSettings.comparisonRvtMode === 'file' ? 'file' : 'recent',
    comparisonKtaWorkbookPath: '',
    comparisonRvtWorkbookPath: '',
    hasRecentKtaResult: false,
    hasRecentRvtResult: false,
    comparisonLastResult: null,
    busy: false,
    busyMode: '',
    acceptProgress: false,
    lastSavedPreferences: JSON.stringify(savedSettings || {}),
    ui: {}
  };

  const page = div('feature-shell deliverycleaner-page lateralnozzle-page lateralnozzle-page--main');
  page.innerHTML = `
    <div class="feature-header deliverycleaner-header">
      <div class="feature-heading">
        <span class="feature-kicker">일반 도구 · Excel / RVT 워크플로</span>
        <h2 class="feature-title">Nozzle Code, KTA, 모델링 검토</h2>
        <p class="feature-sub">KTA 양식 단일화, RVT Nozzle 정보 추출, 두 결과의 수량·누락·중복·위치를 한 화면에서 검토합니다.</p>
      </div>
    </div>
  `;

  const workspace = div('lateralnozzle-workspace');
  const tabs = buildWorkflowTabs(state);
  const ktaPanel = div('lateralnozzle-tab-panel lateralnozzle-tab-panel--kta');
  ktaPanel.id = 'lateralnozzle-panel-kta';
  ktaPanel.setAttribute('role', 'tabpanel');
  ktaPanel.setAttribute('aria-labelledby', 'lateralnozzle-tab-kta');
  const ktaLayout = div('deliverycleaner-top-grid lateralnozzle-layout');
  ktaLayout.append(buildControlCard(state), buildFileCard(state));
  ktaPanel.append(ktaLayout);

  const rvtPanel = div('lateralnozzle-tab-panel lateralnozzle-tab-panel--rvt');
  rvtPanel.id = 'lateralnozzle-panel-rvt';
  rvtPanel.setAttribute('role', 'tabpanel');
  rvtPanel.setAttribute('aria-labelledby', 'lateralnozzle-tab-rvt');
  const rvtLayout = div('deliverycleaner-top-grid lateralnozzle-layout lateralnozzle-rvt-layout');
  rvtLayout.append(buildRvtControlCard(state), buildRvtFileCard(state));
  rvtPanel.append(rvtLayout);

  const comparePanel = buildComparisonPanel(state);

  state.ui.tabPanels = { kta: ktaPanel, rvt: rvtPanel, compare: comparePanel };
  workspace.append(tabs, ktaPanel, rvtPanel, comparePanel);
  page.append(workspace);
  target.append(page);
  syncWorkflowTabs(state);
  window.requestAnimationFrame(() => syncWorkflowTabs(state));
  activeLateralNozzlePreferenceCleanup = attachLateralNozzlePreferenceSync(page, state);

  onHost('lateralnozzle:init', (payload) => applyHostState(state, payload));
  onHost('lateralnozzle:excels-picked', (payload) => {
    const paths = Array.isArray(payload?.paths) ? payload.paths : [];
    if (!paths.length) return;

    const added = appendExcelPaths(state, paths);
    renderExcelTable(state);
    renderRunSummary(state);
    renderResultSummary(state);
    updateActionState(state);

    if (added > 0) toast(`${added}\uac1c \uc5d1\uc140 \ud30c\uc77c\uc744 \ucd94\uac00\ud588\uc2b5\ub2c8\ub2e4.`, 'ok');
  });
  onHost('lateralnozzle:progress', (payload) => {
    if (!state.acceptProgress || !state.busy || state.busyMode !== 'kta') return;
    ProgressDialog.setActions({});
    ProgressDialog.show(payload?.title || '\ub178\uc990\ucf54\ub4dc KTA \ub2e8\uc77c\ud654', payload?.message || '');
    ProgressDialog.update(Number(payload?.percent) || 0, payload?.message || '', payload?.detail || '');
  });
  onHost('lateralnozzle:done', (payload) => {
    state.acceptProgress = false;
    ProgressDialog.hide();
    setPageBusy(state, false);

    state.lastResult = {
      ok: payload?.ok !== false,
      message: payload?.message || '',
      outputFolder: payload?.outputFolder || '',
      resultWorkbookPath: payload?.resultWorkbookPath || '',
      summary: payload?.summary || {},
      files: Array.isArray(payload?.files) ? payload.files : [],
      fileCount: Number(payload?.fileCount) || 0,
      canExport: payload?.canExport === true
    };
    state.hasRecentKtaResult = true;
    state.comparisonLastResult = null;

    renderRunSummary(state);
    renderResultSummary(state);
    updateActionState(state);
    renderComparisonState(state);
    toast(payload?.message || '\ub178\uc990\ucf54\ub4dc KTA \ub2e8\uc77c\ud654\uac00 \uc644\ub8cc\ub418\uc5c8\uc2b5\ub2c8\ub2e4.', payload?.ok === false ? 'err' : 'ok', 3200);
    showLateralNozzleResultDialog(state, payload || {});
  });
  onHost('lateralnozzle:exported', (payload) => {
    ProgressDialog.hide();
    setPageBusy(state, false);
    if (payload?.cancelled) return;
    if (payload?.ok === false) {
      toast(payload?.message || '노즐코드 KTA 단일화 결과 엑셀 저장에 실패했습니다. 저장 경로 권한과 파일이 열려 있는지 확인해 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err', 3600);
      return;
    }
    if (!payload?.path) return;

    if (state.lastResult) state.lastResult.resultWorkbookPath = payload.path;
    window.setTimeout(() => {
      showExcelSavedDialog('노즐코드 KTA 단일화 엑셀을 저장했습니다.', payload.path, (path) => post('excel:open', { path }));
    }, 120);
  });
  onHost('lateralnozzle:error', (payload) => {
    state.acceptProgress = false;
    ProgressDialog.hide();
    setPageBusy(state, false);
    renderRunSummary(state);
    renderResultSummary(state);
    updateActionState(state);
    renderComparisonState(state);
    toast(payload?.message || '노즐코드 KTA 단일화 중 오류가 발생했습니다. 선택한 엑셀 파일과 KTA 양식 상태를 확인한 뒤 다시 실행해 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err', 3600);
  });

  onHost('lateralnozzle:rvt-files-picked', (payload) => {
    const paths = Array.isArray(payload?.paths) ? payload.paths : [];
    if (!paths.length) return;
    const added = appendRvtPaths(state, paths);
    renderRvtTable(state);
    renderRvtRunSummary(state);
    renderRvtResultSummary(state);
    updateRvtActionState(state);
    if (added > 0) toast(`${added}개 RVT 파일을 추가했습니다.`, 'ok');
  });
  onHost('lateralnozzle:rvt-progress', (payload) => {
    if (!state.acceptProgress || !state.busy || !['rvt', 'rvt-export'].includes(state.busyMode)) return;
    ProgressDialog.setActions({});
    ProgressDialog.show(payload?.title || 'RVT Nozzle 정보 추출', payload?.message || '');
    ProgressDialog.update(Number(payload?.percent) || 0, payload?.message || '', payload?.detail || '');
  });
  onHost('lateralnozzle:rvt-done', (payload) => {
    state.acceptProgress = false;
    ProgressDialog.hide();
    setPageBusy(state, false);
    state.comparisonLastResult = null;
    state.rvtLastResult = normalizeRvtResult(payload);
    state.hasRecentRvtResult = true;
    state.comparisonLastResult = null;
    renderRvtRunSummary(state);
    renderRvtResultSummary(state);
    updateRvtActionState(state);
    renderComparisonState(state);
    toast(payload?.message || 'RVT Nozzle 정보 추출이 완료되었습니다.', payload?.ok === false ? 'err' : 'ok', 3400);
    showRvtResultDialog(state, state.rvtLastResult || {});
  });
  onHost('lateralnozzle:rvt-exported', (payload) => {
    state.acceptProgress = false;
    ProgressDialog.hide();
    setPageBusy(state, false);
    if (payload?.cancelled) return;
    if (payload?.ok === false) {
      toast(payload?.message || 'RVT Nozzle 정보 엑셀 저장에 실패했습니다.', 'err', 3600);
      return;
    }
    if (!payload?.path) return;
    if (state.rvtLastResult) state.rvtLastResult.resultWorkbookPath = payload.path;
    window.setTimeout(() => {
      showExcelSavedDialog('RVT Nozzle 정보 엑셀을 저장했습니다.', payload.path, (path) => post('excel:open', { path }));
    }, 120);
  });
  onHost('lateralnozzle:rvt-error', (payload) => {
    state.acceptProgress = false;
    ProgressDialog.hide();
    setPageBusy(state, false);
    renderRvtRunSummary(state);
    renderRvtResultSummary(state);
    updateRvtActionState(state);
    renderComparisonState(state);
    toast(payload?.message || 'RVT Nozzle 정보 추출 중 오류가 발생했습니다.', 'err', 3800);
  });

  onHost('lateralnozzle:compare-kta-picked', (payload) => {
    if (!payload?.path) return;
    state.comparisonKtaWorkbookPath = String(payload.path);
    state.comparisonKtaMode = 'file';
    if (state.ui.comparisonKtaMode) state.ui.comparisonKtaMode.value = 'file';
    state.comparisonLastResult = null;
    saveLateralNozzlePreferences(state);
    renderComparisonState(state);
  });
  onHost('lateralnozzle:compare-rvt-picked', (payload) => {
    if (!payload?.path) return;
    state.comparisonRvtWorkbookPath = String(payload.path);
    state.comparisonRvtMode = 'file';
    if (state.ui.comparisonRvtMode) state.ui.comparisonRvtMode.value = 'file';
    state.comparisonLastResult = null;
    saveLateralNozzlePreferences(state);
    renderComparisonState(state);
  });
  onHost('lateralnozzle:compare-progress', (payload) => {
    if (!state.busy || state.busyMode !== 'compare') return;
    ProgressDialog.setActions({});
    ProgressDialog.show(payload?.title || 'KTA ↔ RVT 비교', payload?.message || '비교하는 중입니다.');
    ProgressDialog.update(Number(payload?.percent) || 0, payload?.message || '', payload?.detail || '');
  });
  onHost('lateralnozzle:compare-done', (payload) => {
    ProgressDialog.hide();
    setPageBusy(state, false);
    state.comparisonLastResult = normalizeComparisonResult(payload);
    renderComparisonState(state);
    toast(payload?.message || 'KTA와 RVT 결과 비교가 완료되었습니다.', payload?.ok === false ? 'err' : 'ok', 3400);
    showComparisonResultDialog(state, state.comparisonLastResult || {});
  });
  onHost('lateralnozzle:compare-exported', (payload) => {
    ProgressDialog.hide();
    setPageBusy(state, false);
    if (payload?.cancelled) return;
    if (payload?.ok === false) {
      toast(payload?.message || 'KTA·RVT 비교 결과 엑셀 저장에 실패했습니다.', 'err', 3600);
      return;
    }
    if (!payload?.path) return;
    if (state.comparisonLastResult) state.comparisonLastResult.resultWorkbookPath = payload.path;
    window.setTimeout(() => {
      showExcelSavedDialog('KTA·RVT 비교 결과 엑셀을 저장했습니다.', payload.path, (path) => post('excel:open', { path }));
    }, 120);
  });
  onHost('lateralnozzle:compare-error', (payload) => {
    ProgressDialog.hide();
    setPageBusy(state, false);
    renderComparisonState(state);
    toast(payload?.message || 'KTA와 RVT 결과 비교 중 오류가 발생했습니다.', 'err', 3800);
  });

  renderExcelTable(state);
  renderRunSummary(state);
  renderResultSummary(state);
  updateActionState(state);
  renderRvtTable(state);
  renderRvtRunSummary(state);
  renderRvtResultSummary(state);
  updateRvtActionState(state);
  renderComparisonState(state);
  post('lateralnozzle:init', {});
}

function buildWorkflowTabs(state) {
  const tabList = div('deliverycleaner-tabs lateralnozzle-tabs');
  tabList.id = 'lateralnozzle-workflow-tabs';
  tabList.setAttribute('role', 'tablist');
  tabList.setAttribute('aria-label', 'Nozzle Code 작업 선택');

  const definitions = [
    { key: 'kta', id: 'lateralnozzle-tab-kta', panelId: 'lateralnozzle-panel-kta', label: 'KTA 단일화' },
    { key: 'rvt', id: 'lateralnozzle-tab-rvt', panelId: 'lateralnozzle-panel-rvt', label: 'RVT Nozzle 정보 추출' },
    { key: 'compare', id: 'lateralnozzle-tab-compare', panelId: 'lateralnozzle-panel-compare', label: 'KTA ↔ RVT 비교' }
  ];
  const buttons = {};
  definitions.forEach((definition, index) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'deliverycleaner-tab lateralnozzle-tab';
    button.id = definition.id;
    button.textContent = definition.label;
    button.dataset.lateralnozzleTab = definition.key;
    button.setAttribute('role', 'tab');
    button.setAttribute('aria-controls', definition.panelId);
    button.addEventListener('click', () => setActiveWorkflowTab(state, definition.key));
    button.addEventListener('keydown', (event) => {
      const currentIndex = definitions.findIndex((item) => item.key === definition.key);
      let nextIndex = currentIndex;
      if (event.key === 'ArrowRight') nextIndex = (currentIndex + 1) % definitions.length;
      else if (event.key === 'ArrowLeft') nextIndex = (currentIndex - 1 + definitions.length) % definitions.length;
      else if (event.key === 'Home') nextIndex = 0;
      else if (event.key === 'End') nextIndex = definitions.length - 1;
      else return;
      event.preventDefault();
      const next = definitions[nextIndex];
      setActiveWorkflowTab(state, next.key);
      buttons[next.key]?.focus({ preventScroll: true });
    });
    buttons[definition.key] = button;
    tabList.append(button);
  });
  state.ui.tabButtons = buttons;
  return tabList;
}

function setActiveWorkflowTab(state, key) {
  const next = ['kta', 'rvt', 'compare'].includes(key) ? key : 'kta';
  if (state.activeTab === next) return;
  state.activeTab = next;
  saveLateralNozzlePreferences(state);
  syncWorkflowTabs(state);
}

function syncWorkflowTabs(state) {
  ['kta', 'rvt', 'compare'].forEach((key) => {
    const active = state.activeTab === key;
    const button = state.ui.tabButtons?.[key];
    const panel = state.ui.tabPanels?.[key];
    if (button) {
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-selected', active ? 'true' : 'false');
      button.tabIndex = active ? 0 : -1;
    }
    if (panel) panel.hidden = !active;
  });
}

function buildControlCard(state) {
  const card = div('deliverycleaner-card lateralnozzle-card lateralnozzle-card--control');
  card.innerHTML = `
    <div class="deliverycleaner-card__head">
      <div>
        <h3>\uc5d1\uc140 \ub4f1\ub85d \ubc0f \uc2e4\ud589</h3>
        <p>\ud30c\uc77c \ucd94\uac00\uc640 \ucd94\ucd9c \uc2e4\ud589\uc744 \ud55c \uc601\uc5ed\uc5d0\uc11c \ubc14\ub85c \uc9c4\ud589\ud569\ub2c8\ub2e4.</p>
      </div>
    </div>
  `;

  const actions = div('deliverycleaner-inline-actions lateralnozzle-actions');
  const addBtn = actionButton('\uc5d1\uc140 \ucd94\uac00', () => post('lateralnozzle:pick-excels', {}));
  const runBtn = actionButton('\ucd94\ucd9c \uc2dc\uc791', () => runExtraction(state), 'primary');
  const removeBtn = actionButton('\uc120\ud0dd \uc81c\uac70', () => {
    state.excelPaths = state.excelPaths.filter((path) => !state.checked.has(path));
    state.checked = new Set(state.excelPaths);
    renderExcelTable(state);
    renderRunSummary(state);
    renderResultSummary(state);
    updateActionState(state);
  });
  const clearBtn = actionButton('\ubaa9\ub85d \uc9c0\uc6b0\uae30', () => {
    state.excelPaths = [];
    state.checked.clear();
    renderExcelTable(state);
    renderRunSummary(state);
    renderResultSummary(state);
    updateActionState(state);
  });
  actions.append(addBtn, runBtn, removeBtn, clearBtn);

  const runSummary = div('deliverycleaner-summary-box lateralnozzle-summary-box');
  const validation = div('deliverycleaner-note lateralnozzle-rule-note');
  const resultSummary = div('deliverycleaner-summary-box lateralnozzle-result-box');
  const diagnostics = div('lateralnozzle-diagnostics');
  diagnostics.hidden = true;

  card.append(actions, runSummary, validation, resultSummary, diagnostics);

  state.ui.addBtn = addBtn;
  state.ui.runBtn = runBtn;
  state.ui.removeBtn = removeBtn;
  state.ui.clearBtn = clearBtn;
  state.ui.runSummary = runSummary;
  state.ui.validation = validation;
  state.ui.resultSummary = resultSummary;
  state.ui.diagnostics = diagnostics;
  return card;
}

function buildFileCard(state) {
  const card = div('deliverycleaner-card lateralnozzle-card lateralnozzle-card--list');
  card.innerHTML = `
    <div class="deliverycleaner-card__head">
      <div>
        <h3>\uc5d1\uc140 \ud30c\uc77c \ubaa9\ub85d</h3>
        <p>\ud30c\uc77c\uba85\uacfc \uacbd\ub85c\ub97c \ub113\uac8c \ud655\uc778\ud558\uba74\uc11c \uc120\ud0dd \uc0c1\ud0dc\ub97c \uad00\ub9ac\ud569\ub2c8\ub2e4.</p>
      </div>
    </div>
  `;

  const hint = div('rvt-drop-hint lateralnozzle-drop-hint');
  hint.textContent = '\ud0d0\uc0c9\uae30\uc5d0\uc11c .xlsx \ub610\ub294 .xls \ud30c\uc77c\uc744 \uc774 \uc601\uc5ed\uc73c\ub85c \ub04c\uc5b4\uc624\uba74 \ubc14\ub85c \ucd94\uac00\ub429\ub2c8\ub2e4. \uc62c\ubc14\ub978 \uc5d1\uc140 \ud30c\uc77c\uc740 \uc798\ubabb\ub41c \ud615\uc2dd \uacbd\uace0\uac00 \ub728\uc9c0 \uc54a\ub3c4\ub85d \ubcc4\ub3c4 \ub4dc\ub86d \uacbd\ub85c\ub85c \ucc98\ub9ac\ud569\ub2c8\ub2e4.';

  const tableWrap = div('rvt-expand-table rvt-drop-zone lateralnozzle-drop-zone');
  const table = document.createElement('table');
  table.className = 'segmentpms-table rvt-register-table lateralnozzle-table';
  table.innerHTML = `
    <colgroup>
      <col style="width:44px">
      <col style="width:56px">
      <col style="width:260px">
      <col>
    </colgroup>
    <thead>
      <tr>
        <th style="text-align:center;"><input type="checkbox"></th>
        <th style="text-align:center;">#</th>
        <th>\ud30c\uc77c\uba85</th>
        <th>\ud30c\uc77c \uacbd\ub85c</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  tableWrap.append(table);

  attachExcelDropZone(tableWrap, {
    onDropPaths: (paths) => {
      const added = appendExcelPaths(state, paths);
      renderExcelTable(state);
      renderRunSummary(state);
      renderResultSummary(state);
      updateActionState(state);

      if (added > 0) toast(`${added}\uac1c \uc5d1\uc140 \ud30c\uc77c\uc744 \ucd94\uac00\ud588\uc2b5\ub2c8\ub2e4.`, 'ok');
      else toast('\uc774\ubbf8 \ub4f1\ub85d\ub41c \uc5d1\uc140 \ud30c\uc77c\uc785\ub2c8\ub2e4.', 'warn');
    },
    onInvalid: (payload) => {
      toast(payload?.message || '\uc5d1\uc140 \ud30c\uc77c(.xlsx, .xls)\ub9cc \ucd94\uac00\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4.', 'warn', 2600);
    }
  });

  const note = div('deliverycleaner-note lateralnozzle-file-note');
  note.textContent = '\uac01 \ud30c\uc77c\uc758 \ubaa8\ub4e0 \uc2dc\ud2b8\ub97c \uac80\uc0ac\ud574 UT\uba85 / \ubc30\uad00No / Nozzle Code /  No \ud5e4\ub354 \ube14\ub85d\uc744 \ucc3e\uace0, Nozzle Code\uc640  No\ub97c \uc774\uc5b4 \ud558\ub098\uc758 \uacb0\uacfc \uac12\uc73c\ub85c \uc815\ub9ac\ud569\ub2c8\ub2e4.';

  card.append(hint, tableWrap, note);

  state.ui.tableBody = table.querySelector('tbody');
  state.ui.masterCheck = table.querySelector('thead input[type="checkbox"]');
  return card;
}

function buildRvtControlCard(state) {
  const card = div('deliverycleaner-card lateralnozzle-card lateralnozzle-card--control lateralnozzle-rvt-control');
  card.innerHTML = `
    <div class="deliverycleaner-card__head">
      <div>
        <h3>파라미터 설정 및 실행</h3>
        <p>기본 NOZZLE 마커와 추가 키워드 후보에서 읽을 파라미터명을 지정합니다.</p>
      </div>
    </div>
  `;

  const fields = div('deliverycleaner-field-stack lateralnozzle-parameter-fields');
  const utilityField = createRvtParameterField('UTILITY 파라미터', 'UTILITY 값을 읽을 파라미터명', state.utilityParameterName);
  const lateralField = createRvtParameterField('LATERAL 파라미터', 'LATERAL 번호를 읽을 파라미터명', state.lateralParameterName);
  const nozzleField = document.createElement('label');
  nozzleField.className = 'deliverycleaner-field lateralnozzle-mapping-field';
  const nozzleLabel = document.createElement('span');
  nozzleLabel.textContent = 'Nozzle Code 매핑 파라미터';
  const nozzleInput = document.createElement('textarea');
  nozzleInput.rows = 5;
  nozzleInput.placeholder = '쉼표, 세미콜론 또는 줄바꿈으로 구분\n예: NOZZLE CODE 01\nNOZZLE CODE 02';
  nozzleInput.value = state.nozzleCodeParameterNamesText;
  nozzleInput.dataset.lateralnozzleFocusKey = 'rvt-nozzle-parameter-names';
  const nozzleHint = document.createElement('small');
  nozzleHint.textContent = '값이 있는 매핑 파라미터마다 입력 순서대로 한 행을 만들고, 모두 비어 있으면 누락 진단을 남깁니다. 추가 키워드 후보를 노즐로 확정할 때는 타입값이 아닌 인스턴스 매핑값만 근거로 사용합니다.';
  nozzleField.append(nozzleLabel, nozzleInput, nozzleHint);

  const additionalParametersField = document.createElement('label');
  additionalParametersField.className = 'deliverycleaner-field lateralnozzle-mapping-field';
  const additionalParametersLabel = document.createElement('span');
  additionalParametersLabel.textContent = '추가 확인 파라미터 (선택)';
  const additionalParametersInput = document.createElement('textarea');
  additionalParametersInput.rows = 3;
  additionalParametersInput.placeholder = '결과에 같이 표시할 파라미터명을 입력\n쉼표, 세미콜론 또는 줄바꿈으로 구분';
  additionalParametersInput.value = state.additionalParameterNamesText;
  additionalParametersInput.dataset.lateralnozzleFocusKey = 'rvt-additional-parameter-names';
  const additionalParametersHint = document.createElement('small');
  additionalParametersHint.textContent = '각 객체에서 인스턴스 값을 우선 읽고, 인스턴스 값이 비어 있으면 타입 값을 읽습니다. 결과 Excel에는 입력한 파라미터마다 별도 열을 만듭니다.';
  additionalParametersField.append(additionalParametersLabel, additionalParametersInput, additionalParametersHint);

  const additionalKeywordsField = document.createElement('label');
  additionalKeywordsField.className = 'deliverycleaner-field lateralnozzle-mapping-field';
  const additionalKeywordsLabel = document.createElement('span');
  additionalKeywordsLabel.textContent = '추가 노즐 후보 패밀리/타입 키워드 (선택)';
  const additionalKeywordsInput = document.createElement('textarea');
  additionalKeywordsInput.rows = 4;
  additionalKeywordsInput.placeholder = '한 줄에 하나씩 입력\n패밀리 또는 타입 포함: NOZZLE\n패밀리와 타입 각각 포함: ABC::NOZZLE';
  additionalKeywordsInput.value = state.additionalFamilyOrTypeKeywordsText;
  additionalKeywordsInput.dataset.lateralnozzleFocusKey = 'rvt-additional-family-or-type-keywords';
  const additionalKeywordsHint = document.createElement('small');
  additionalKeywordsHint.textContent = '파이프 피팅/파이프 악세사리 안에서 대소문자를 구분하지 않고 찾습니다. keyword는 패밀리명 또는 타입명에 포함되면 후보가 되고, familyKeyword::typeKeyword는 패밀리명과 타입명에 각각 포함되어야 합니다. 여러 줄은 OR입니다. 키워드만으로 본 결과에 포함하지 않으며, Nozzle Code 매핑 인스턴스값이 하나 이상 있으면 추가 확정하고 없으면 「추가 노즐 검토 후보」 시트로 분리합니다. 배관 연결은 진단 정보일 뿐 선정 조건이 아닙니다.';
  additionalKeywordsField.append(additionalKeywordsLabel, additionalKeywordsInput, additionalKeywordsHint);
  fields.append(utilityField.field, lateralField.field, nozzleField, additionalParametersField, additionalKeywordsField);

  const syncInputs = () => {
    state.utilityParameterName = utilityField.input.value;
    state.lateralParameterName = lateralField.input.value;
    state.nozzleCodeParameterNamesText = nozzleInput.value;
    state.additionalParameterNamesText = additionalParametersInput.value;
    state.additionalFamilyOrTypeKeywordsText = additionalKeywordsInput.value;
    state.parameterPreferenceOwner.utility = true;
    state.parameterPreferenceOwner.lateral = true;
    state.parameterPreferenceOwner.nozzle = true;
    state.parameterPreferenceOwner.additionalParameters = true;
    state.parameterPreferenceOwner.additionalKeywords = true;
    saveLateralNozzlePreferences(state);
    renderRvtRunSummary(state);
    updateRvtActionState(state);
  };
  utilityField.input.addEventListener('input', syncInputs);
  lateralField.input.addEventListener('input', syncInputs);
  nozzleInput.addEventListener('input', syncInputs);
  additionalParametersInput.addEventListener('input', syncInputs);
  additionalKeywordsInput.addEventListener('input', syncInputs);

  const actions = div('deliverycleaner-inline-actions lateralnozzle-actions');
  const addBtn = actionButton('RVT 추가', () => post('lateralnozzle:rvt-pick-files', {}));
  const runBtn = actionButton('정보 추출 시작', () => runRvtExtraction(state), 'primary');
  const removeBtn = actionButton('선택 제거', () => {
    state.rvtPaths = state.rvtPaths.filter((path) => !state.rvtChecked.has(path));
    state.rvtChecked = new Set(state.rvtPaths);
    renderRvtTable(state);
    renderRvtRunSummary(state);
    renderRvtResultSummary(state);
    updateRvtActionState(state);
  });
  const clearBtn = actionButton('목록 지우기', () => {
    state.rvtPaths = [];
    state.rvtChecked.clear();
    renderRvtTable(state);
    renderRvtRunSummary(state);
    renderRvtResultSummary(state);
    updateRvtActionState(state);
  });
  actions.append(addBtn, runBtn, removeBtn, clearBtn);

  const runSummary = div('deliverycleaner-summary-box lateralnozzle-summary-box');
  const validation = div('deliverycleaner-note lateralnozzle-rule-note');
  const resultSummary = div('deliverycleaner-summary-box lateralnozzle-result-box');
  const diagnostics = div('lateralnozzle-diagnostics');
  diagnostics.hidden = true;
  // 파일 등록과 실행 진입점은 긴 파라미터 입력 영역보다 먼저 보여 준다.
  card.append(actions, fields, runSummary, validation, resultSummary, diagnostics);

  state.ui.rvtUtilityInput = utilityField.input;
  state.ui.rvtLateralInput = lateralField.input;
  state.ui.rvtNozzleInput = nozzleInput;
  state.ui.rvtAdditionalParametersInput = additionalParametersInput;
  state.ui.rvtAdditionalKeywordsInput = additionalKeywordsInput;
  state.ui.rvtAddBtn = addBtn;
  state.ui.rvtRunBtn = runBtn;
  state.ui.rvtRemoveBtn = removeBtn;
  state.ui.rvtClearBtn = clearBtn;
  state.ui.rvtRunSummary = runSummary;
  state.ui.rvtValidation = validation;
  state.ui.rvtResultSummary = resultSummary;
  state.ui.rvtDiagnostics = diagnostics;
  return card;
}

function createRvtParameterField(labelText, placeholder, value) {
  const field = document.createElement('label');
  field.className = 'deliverycleaner-field';
  const label = document.createElement('span');
  label.textContent = labelText;
  const input = document.createElement('input');
  input.type = 'text';
  input.placeholder = placeholder;
  input.value = value || '';
  input.autocomplete = 'off';
  input.dataset.lateralnozzleFocusKey = labelText;
  field.append(label, input);
  return { field, input };
}

function buildRvtFileCard(state) {
  const card = div('deliverycleaner-card lateralnozzle-card lateralnozzle-card--list lateralnozzle-rvt-list');
  card.innerHTML = `
    <div class="deliverycleaner-card__head">
      <div>
        <h3>RVT 파일 목록</h3>
        <p>파이프 피팅/악세사리 안에서 기본 마커와 입력한 추가 패밀리·타입 키워드 후보를 검사합니다. 여러 RVT를 한 번에 등록할 수 있습니다.</p>
      </div>
    </div>
  `;

  const hint = div('rvt-drop-hint lateralnozzle-drop-hint');
  hint.textContent = 'RVT 추가 버튼을 누르거나 탐색기에서 .rvt 파일을 이 영역으로 끌어오면 바로 추가됩니다.';
  const tableWrap = div('rvt-expand-table rvt-drop-zone lateralnozzle-drop-zone');
  const table = document.createElement('table');
  table.className = 'segmentpms-table rvt-register-table lateralnozzle-table';
  table.innerHTML = `
    <colgroup><col style="width:44px"><col style="width:56px"><col style="width:260px"><col></colgroup>
    <thead><tr><th style="text-align:center;"><input type="checkbox"></th><th style="text-align:center;">#</th><th>파일명</th><th>파일 경로</th></tr></thead>
    <tbody></tbody>
  `;
  tableWrap.append(table);
  attachRvtDropZone(tableWrap, {
    onDropPaths: (paths) => {
      const added = appendRvtPaths(state, paths);
      renderRvtTable(state);
      renderRvtRunSummary(state);
      renderRvtResultSummary(state);
      updateRvtActionState(state);
      if (added > 0) toast(`${added}개 RVT 파일을 추가했습니다.`, 'ok');
      else toast('이미 등록된 RVT 파일입니다.', 'warn');
    },
    onInvalid: (payload) => toast(payload?.message || 'RVT 파일(.rvt)만 추가할 수 있습니다.', 'warn', 2600)
  });

  const note = div('deliverycleaner-note lateralnozzle-file-note');
  note.textContent = '정렬: UTILITY 값 우선 → 같은 UTILITY 안에서 LATERAL 그룹의 대표 X(중앙값) 오름차순 → 그룹 안 Y 내림차순 → X 오름차순. 좌표는 활성 Project Location의 공유좌표(mm)를 사용합니다.';
  card.append(hint, tableWrap, note);
  state.ui.rvtTableBody = table.querySelector('tbody');
  state.ui.rvtMasterCheck = table.querySelector('thead input[type="checkbox"]');
  return card;
}

function buildComparisonPanel(state) {
  const panel = div('lateralnozzle-tab-panel lateralnozzle-tab-panel--compare');
  panel.id = 'lateralnozzle-panel-compare';
  panel.setAttribute('role', 'tabpanel');
  panel.setAttribute('aria-labelledby', 'lateralnozzle-tab-compare');

  const layout = div('deliverycleaner-top-grid lateralnozzle-layout lateralnozzle-compare-layout');
  const controlCard = div('deliverycleaner-card lateralnozzle-card lateralnozzle-card--control lateralnozzle-compare-control');
  controlCard.innerHTML = `
    <div class="deliverycleaner-card__head">
      <div>
        <h3>비교 대상 선택</h3>
        <p>같은 실행 세션의 최근 결과를 사용하거나 저장된 표준 결과 Excel을 선택합니다.</p>
      </div>
    </div>
  `;

  const fields = div('deliverycleaner-field-stack lateralnozzle-parameter-fields');
  const ktaSource = createComparisonSourceField(
    'KTA 단일화 결과',
    state.comparisonKtaMode,
    () => post('lateralnozzle:compare-pick-kta', {})
  );
  const rvtSource = createComparisonSourceField(
    'RVT Nozzle 추출 결과',
    state.comparisonRvtMode,
    () => post('lateralnozzle:compare-pick-rvt', {})
  );
  fields.append(ktaSource.field, rvtSource.field);

  const onSourceModeChange = () => {
    state.comparisonKtaMode = ktaSource.select.value === 'file' ? 'file' : 'recent';
    state.comparisonRvtMode = rvtSource.select.value === 'file' ? 'file' : 'recent';
    state.comparisonLastResult = null;
    saveLateralNozzlePreferences(state);
    renderComparisonState(state);
    post('lateralnozzle:compare-invalidate', {});
  };
  ktaSource.select.addEventListener('change', onSourceModeChange);
  rvtSource.select.addEventListener('change', onSourceModeChange);

  const actions = div('deliverycleaner-inline-actions lateralnozzle-actions');
  const runBtn = actionButton('비교 시작', () => runComparison(state), 'primary');
  const exportBtn = actionButton('비교 결과 Excel 저장', () => promptComparisonExcelExport(state));
  actions.append(runBtn, exportBtn);

  const runSummary = div('deliverycleaner-summary-box lateralnozzle-summary-box');
  const validation = div('deliverycleaner-note lateralnozzle-rule-note');
  validation.textContent = '기본 비교키는 UTILITY + LATERAL NO + Nozzle Code입니다. 앞뒤/연속 공백과 대소문자만 정규화하고, 하이픈·언더스코어·선행 0은 보존합니다.';
  controlCard.append(fields, actions, runSummary, validation);

  const resultCard = div('deliverycleaner-card lateralnozzle-card lateralnozzle-card--list lateralnozzle-compare-result');
  resultCard.innerHTML = `
    <div class="deliverycleaner-card__head">
      <div>
        <h3>비교 결과</h3>
        <p>일치·수량 차이·한쪽 누락·속성 불일치·중복과 같은 래테럴의 번호 공간 순서를 확인합니다.</p>
      </div>
    </div>
  `;
  const resultSummary = div('deliverycleaner-summary-box lateralnozzle-result-box');
  const tableWrap = div('rvt-expand-table lateralnozzle-drop-zone');
  const table = document.createElement('table');
  table.className = 'segmentpms-table rvt-register-table lateralnozzle-table lateralnozzle-compare-table';
  table.innerHTML = `
    <colgroup>
      <col style="width:120px"><col style="width:130px"><col style="width:150px"><col style="width:180px">
      <col style="width:76px"><col style="width:76px"><col style="width:76px"><col style="width:240px">
      <col style="width:180px"><col style="width:150px"><col style="width:150px">
      <col style="width:180px"><col style="width:120px"><col style="width:170px"><col style="width:190px"><col style="width:170px">
    </colgroup>
    <thead><tr><th>상태</th><th>UTILITY</th><th>LATERAL NO</th><th>Nozzle Code</th><th>KTA</th><th>RVT</th><th>일치</th><th>진단</th><th>KTA 파일명</th><th>KTA 시트</th><th>KTA 행/열</th><th>RVT 파일명</th><th>RVT ElementId</th><th>RVT Category</th><th>RVT Family</th><th>RVT Type</th></tr></thead>
    <tbody></tbody>
  `;
  tableWrap.append(table);
  const diagnostics = div('lateralnozzle-diagnostics');
  diagnostics.hidden = true;
  const note = div('deliverycleaner-note lateralnozzle-file-note');
  note.textContent = 'RVT 검토 후보와 번호 공간 순서는 확정 수량 판정에 영향을 주지 않는 보조검사입니다. KTA 원본 위치와 RVT 객체 정보는 화면과 비교 Excel에서 위치가 포함되는 각 결과 시트의 독립 열로 확인할 수 있습니다.';
  resultCard.append(resultSummary, tableWrap, diagnostics, note);
  layout.append(controlCard, resultCard);
  panel.append(layout);

  state.ui.comparisonKtaMode = ktaSource.select;
  state.ui.comparisonRvtMode = rvtSource.select;
  state.ui.comparisonKtaPickBtn = ktaSource.pickButton;
  state.ui.comparisonRvtPickBtn = rvtSource.pickButton;
  state.ui.comparisonKtaSourceStatus = ktaSource.status;
  state.ui.comparisonRvtSourceStatus = rvtSource.status;
  state.ui.comparisonRunBtn = runBtn;
  state.ui.comparisonExportBtn = exportBtn;
  state.ui.comparisonRunSummary = runSummary;
  state.ui.comparisonValidation = validation;
  state.ui.comparisonResultSummary = resultSummary;
  state.ui.comparisonTableBody = table.querySelector('tbody');
  state.ui.comparisonDiagnostics = diagnostics;
  return panel;
}

function createComparisonSourceField(labelText, mode, onPick) {
  const field = document.createElement('label');
  field.className = 'deliverycleaner-field lateralnozzle-comparison-source';
  const label = document.createElement('span');
  label.textContent = labelText;
  const select = document.createElement('select');
  select.dataset.lateralnozzleFocusKey = `compare-${labelText}`;
  select.innerHTML = '<option value="recent">최근 실행 결과 사용</option><option value="file">저장된 결과 Excel 사용</option>';
  select.value = mode === 'file' ? 'file' : 'recent';
  const pickButton = actionButton('결과 Excel 선택', onPick);
  const status = document.createElement('small');
  field.append(label, select, pickButton, status);
  return { field, select, pickButton, status };
}

function applyHostState(state, payload) {
  const settings = payload?.settings || {};
  state.excelPaths = Array.isArray(settings.excelPaths) ? [...settings.excelPaths] : [];
  state.checked = new Set(state.excelPaths);
  state.lastResult = payload?.result
    ? {
      ...payload.result,
      files: Array.isArray(payload?.result?.files) ? payload.result.files : [],
      fileCount: Number(payload?.result?.fileCount) || 0,
      canExport: payload?.result?.canExport === true
    }
    : null;

  const rvtSettings = payload?.rvtSettings || {};
  state.rvtPaths = Array.isArray(rvtSettings.rvtPaths) ? [...rvtSettings.rvtPaths] : [];
  state.rvtChecked = new Set(state.rvtPaths);
  const hostUtility = String(rvtSettings.utilityParameterName || '').trim();
  const hostLateral = String(rvtSettings.lateralParameterName || '').trim();
  const hostNozzleNames = Array.isArray(rvtSettings.nozzleCodeParameterNames)
    ? rvtSettings.nozzleCodeParameterNames.map((name) => String(name || '').trim()).filter(Boolean)
    : [];
  const hostAdditionalParameterNames = Array.isArray(rvtSettings.additionalParameterNames)
    ? parseParameterNames(rvtSettings.additionalParameterNames)
    : [];
  const hostNewAdditionalKeywords = Array.isArray(rvtSettings.additionalFamilyOrTypeKeywords)
    ? normalizeAdditionalFamilyOrTypeKeywords(rvtSettings.additionalFamilyOrTypeKeywords)
    : [];
  const hostLegacyAdditionalKeywords = Array.isArray(rvtSettings.additionalIncludedFamilyOrTypeNames)
    ? normalizeAdditionalFamilyOrTypeKeywords(rvtSettings.additionalIncludedFamilyOrTypeNames)
    : [];
  const hostAdditionalKeywordsSource = hostNewAdditionalKeywords.length
    ? hostNewAdditionalKeywords
    : hostLegacyAdditionalKeywords;
  const hostAdditionalKeywords = Array.isArray(hostAdditionalKeywordsSource)
    ? normalizeAdditionalFamilyOrTypeKeywords(hostAdditionalKeywordsSource)
    : [];
  if (hostUtility && !state.parameterPreferenceOwner.utility) state.utilityParameterName = hostUtility;
  if (hostLateral && !state.parameterPreferenceOwner.lateral) state.lateralParameterName = hostLateral;
  if (hostNozzleNames.length && !state.parameterPreferenceOwner.nozzle) state.nozzleCodeParameterNamesText = hostNozzleNames.join('\n');
  if (hostAdditionalParameterNames.length && !state.parameterPreferenceOwner.additionalParameters) {
    state.additionalParameterNamesText = hostAdditionalParameterNames.join('\n');
  }
  if (hostAdditionalKeywords.length && !state.parameterPreferenceOwner.additionalKeywords) {
    state.additionalFamilyOrTypeKeywordsText = hostAdditionalKeywords.join('\n');
  }
  applyInputValueIfIdle(state.ui.rvtUtilityInput, state.utilityParameterName);
  applyInputValueIfIdle(state.ui.rvtLateralInput, state.lateralParameterName);
  applyInputValueIfIdle(state.ui.rvtNozzleInput, state.nozzleCodeParameterNamesText);
  applyInputValueIfIdle(state.ui.rvtAdditionalParametersInput, state.additionalParameterNamesText);
  applyInputValueIfIdle(state.ui.rvtAdditionalKeywordsInput, state.additionalFamilyOrTypeKeywordsText);
  state.rvtLastResult = payload?.rvtResult ? normalizeRvtResult(payload.rvtResult) : null;
  const comparisonState = payload?.comparisonState || payload?.comparison || {};
  state.hasRecentKtaResult = comparisonState.hasRecentKtaResult === true || !!state.lastResult;
  state.hasRecentRvtResult = comparisonState.hasRecentRvtResult === true || !!state.rvtLastResult;
  if (comparisonState.ktaWorkbookPath) state.comparisonKtaWorkbookPath = String(comparisonState.ktaWorkbookPath);
  if (comparisonState.rvtWorkbookPath) state.comparisonRvtWorkbookPath = String(comparisonState.rvtWorkbookPath);
  state.comparisonLastResult = comparisonState.result
    ? normalizeComparisonResult(comparisonState.result)
    : state.comparisonLastResult;

  renderExcelTable(state);
  renderRunSummary(state);
  renderResultSummary(state);
  updateActionState(state);
  renderRvtTable(state);
  renderRvtRunSummary(state);
  renderRvtResultSummary(state);
  updateRvtActionState(state);
  renderComparisonState(state);
  syncWorkflowTabs(state);
}

function applyInputValueIfIdle(input, value) {
  if (!input || document.activeElement === input) return;
  const next = String(value || '');
  if (input.value !== next) input.value = next;
}

function normalizeRvtResult(payload) {
  const additionalParameterNames = Array.isArray(payload?.additionalParameterNames)
    ? parseParameterNames(payload.additionalParameterNames)
    : [];
  const newAdditionalKeywords = Array.isArray(payload?.additionalFamilyOrTypeKeywords)
    ? normalizeAdditionalFamilyOrTypeKeywords(payload.additionalFamilyOrTypeKeywords)
    : [];
  const legacyAdditionalKeywords = Array.isArray(payload?.additionalIncludedFamilyOrTypeNames)
    ? normalizeAdditionalFamilyOrTypeKeywords(payload.additionalIncludedFamilyOrTypeNames)
    : [];
  const additionalKeywords = newAdditionalKeywords.length ? newAdditionalKeywords : legacyAdditionalKeywords;
  const summary = payload?.summary && typeof payload.summary === 'object' && !Array.isArray(payload.summary)
    ? { ...payload.summary }
    : {};
  const reviewCandidateCount = Number(
    summary.additionalReviewCandidateCount
      ?? summary.reviewCandidateCount
      ?? payload?.reviewCandidateCount
  ) || 0;
  summary.additionalReviewCandidateCount = reviewCandidateCount;
  summary.reviewCandidateCount = reviewCandidateCount;
  const files = (Array.isArray(payload?.files) ? payload.files : []).map((file) => ({
    ...(file || {}),
    additionalReviewCandidateCount: Number(
      file?.additionalReviewCandidateCount ?? file?.reviewCandidateCount
    ) || 0
  }));
  return {
    ok: payload?.ok !== false,
    message: payload?.message || '',
    outputFolder: payload?.outputFolder || '',
    resultWorkbookPath: payload?.resultWorkbookPath || '',
    additionalParameterNames,
    additionalParameterCount: Number(payload?.additionalParameterCount) || additionalParameterNames.length,
    additionalFamilyOrTypeKeywords: additionalKeywords,
    additionalKeywordCount: Number(payload?.additionalKeywordCount ?? payload?.additionalIncludedFamilyOrTypeNameCount) || additionalKeywords.length,
    reviewCandidateCount,
    summary,
    files,
    fileCount: Number(payload?.fileCount) || 0,
    canExport: payload?.canExport === true
  };
}

function normalizeComparisonResult(payload) {
  const summary = payload?.summary && typeof payload.summary === 'object' && !Array.isArray(payload.summary)
    ? { ...payload.summary }
    : {};
  const previewRowsSource = payload?.previewRows ?? payload?.rows ?? payload?.comparisons;
  const diagnosticsSource = payload?.diagnostics ?? payload?.inputDiagnostics;
  return {
    ok: payload?.ok !== false,
    message: String(payload?.message || ''),
    resultWorkbookPath: String(payload?.resultWorkbookPath || ''),
    ktaSourceLabel: String(payload?.ktaSourceLabel || ''),
    rvtSourceLabel: String(payload?.rvtSourceLabel || ''),
    summary,
    previewRows: Array.isArray(previewRowsSource) ? previewRowsSource : [],
    previewRowCount: Number(payload?.previewRowCount) || (Array.isArray(previewRowsSource) ? previewRowsSource.length : 0),
    totalComparisonRowCount: Number(payload?.totalComparisonRowCount ?? summary.totalComparisonRowCount) || 0,
    diagnostics: Array.isArray(diagnosticsSource) ? diagnosticsSource : [],
    canExport: payload?.canExport === true
  };
}

function renderComparisonState(state) {
  if (state.ui.comparisonKtaMode) state.ui.comparisonKtaMode.value = state.comparisonKtaMode === 'file' ? 'file' : 'recent';
  if (state.ui.comparisonRvtMode) state.ui.comparisonRvtMode.value = state.comparisonRvtMode === 'file' ? 'file' : 'recent';

  if (state.ui.comparisonKtaSourceStatus) {
    state.ui.comparisonKtaSourceStatus.textContent = state.comparisonKtaMode === 'file'
      ? (state.comparisonKtaWorkbookPath || '선택된 KTA 결과 Excel이 없습니다.')
      : (state.hasRecentKtaResult ? '최근 KTA 단일화 결과를 사용할 수 있습니다.' : '최근 KTA 단일화 결과가 없습니다.');
  }
  if (state.ui.comparisonRvtSourceStatus) {
    state.ui.comparisonRvtSourceStatus.textContent = state.comparisonRvtMode === 'file'
      ? (state.comparisonRvtWorkbookPath || '선택된 RVT 결과 Excel이 없습니다.')
      : (state.hasRecentRvtResult ? '최근 RVT Nozzle 추출 결과를 사용할 수 있습니다.' : '최근 RVT Nozzle 추출 결과가 없습니다.');
  }

  const validation = getComparisonValidationMessage(state);
  if (state.ui.comparisonRunSummary) {
    const ktaLabel = state.comparisonKtaMode === 'file'
      ? (getFileName(state.comparisonKtaWorkbookPath) || 'Excel 미선택')
      : (state.hasRecentKtaResult ? '최근 결과 준비됨' : '최근 결과 없음');
    const rvtLabel = state.comparisonRvtMode === 'file'
      ? (getFileName(state.comparisonRvtWorkbookPath) || 'Excel 미선택')
      : (state.hasRecentRvtResult ? '최근 결과 준비됨' : '최근 결과 없음');
    state.ui.comparisonRunSummary.innerHTML = `<strong>KTA: ${escapeHtml(ktaLabel)}</strong><span>RVT: ${escapeHtml(rvtLabel)}</span>`;
  }
  if (state.ui.comparisonValidation) {
    state.ui.comparisonValidation.textContent = validation || '비교 가능: 완전 일치, 수량 불일치, KTA만, RVT만, 속성 불일치, 중복, 원본 위치 및 번호 공간 순서를 검사합니다.';
  }

  const result = state.comparisonLastResult;
  const summary = result?.summary || {};
  if (state.ui.comparisonResultSummary) {
    if (!result) {
      state.ui.comparisonResultSummary.innerHTML = '<strong>아직 비교 결과가 없습니다.</strong><span>양쪽 결과를 준비한 뒤 비교 시작을 눌러 주세요.</span>';
    } else {
      const previewCount = Number(result.previewRowCount) || 0;
      const totalCount = Number(result.totalComparisonRowCount) || 0;
      const previewNotice = totalCount > previewCount
        ? `미리보기 ${previewCount}/${totalCount}항목 · 전체 항목과 모든 위치는 비교 결과 Excel에서 확인`
        : `비교 항목 ${totalCount}개 · 모든 위치는 비교 결과 Excel에서 확인`;
      state.ui.comparisonResultSummary.innerHTML = `
        <strong>${escapeHtml(result.message || '비교 완료')}</strong>
        <span>KTA ${comparisonNumber(summary, 'ktaRowCount')}행 · RVT ${comparisonNumber(summary, 'rvtRowCount')}행 · RVT 객체 ${comparisonNumber(summary, 'rvtObjectCount')}개</span>
        <span>일치 ${comparisonNumber(summary, 'matchedQuantity')}건 · 수량 불일치 ${comparisonNumber(summary, 'quantityMismatchKeyCount')}키 · 속성 불일치 ${comparisonNumber(summary, 'attributeMismatchCount')}건</span>
        <span>KTA만 ${comparisonNumber(summary, 'ktaOnlyKeyCount')}키 · RVT만 ${comparisonNumber(summary, 'rvtOnlyKeyCount')}키 · 검토 후보 발견 ${comparisonNumber(summary, 'reviewCandidateMatchCount')}건</span>
        <span>KTA 중복 ${comparisonNumber(summary, 'ktaDuplicateKeyCount')}키 · RVT 중복 ${comparisonNumber(summary, 'rvtDuplicateKeyCount')}키 · 비교 불가 ${comparisonNumber(summary, 'incompleteRowCount')}행</span>
        <span>공간 순서 정상 추정 ${comparisonNumber(summary, 'spatialSequenceNormalCount')}그룹 · 이상 의심 ${comparisonNumber(summary, 'spatialSequenceSuspectedCount')}그룹 · 판정 보류 ${comparisonNumber(summary, 'spatialSequenceDeferredCount')}그룹 · 데이터 부족 ${comparisonNumber(summary, 'spatialSequenceInsufficientCount')}그룹</span>
        <span>번호 중복 ${comparisonNumber(summary, 'spatialSequenceDuplicateNumberGroupCount')}그룹 · 번호 누락 ${comparisonNumber(summary, 'spatialSequenceMissingNumberGroupCount')}그룹</span>
        <span>${escapeHtml(previewNotice)}</span>
      `;
    }
  }

  renderComparisonPreviewTable(state, result?.previewRows || []);
  renderComparisonDiagnostics(state, result?.diagnostics || []);
  updateComparisonActionState(state);
}

function renderComparisonPreviewTable(state, rows) {
  const tbody = state.ui.comparisonTableBody;
  if (!tbody) return;
  tbody.innerHTML = '';
  const visibleRows = (Array.isArray(rows) ? rows : []).slice(0, 200);
  if (!visibleRows.length) {
    const tr = document.createElement('tr');
    tr.className = 'empty-row';
    const td = document.createElement('td');
    td.colSpan = 16;
    td.className = 'empty-cell';
    td.textContent = '표시할 비교 항목이 없습니다.';
    tr.append(td);
    tbody.append(tr);
    return;
  }

  visibleRows.forEach((item) => {
    const tr = document.createElement('tr');
    [
      item?.statusLabel ?? item?.status,
      item?.utility,
      item?.lateralNo,
      item?.nozzleCode,
      item?.ktaCount,
      item?.rvtCount,
      item?.matchedCount,
      item?.diagnosis ?? item?.message,
      item?.ktaFileName ?? item?.ktaLocation,
      item?.ktaSheet,
      item?.ktaRowCell,
      item?.rvtFileName ?? item?.rvtLocation,
      item?.rvtElementId,
      item?.rvtCategory,
      item?.rvtFamily,
      item?.rvtType
    ].forEach((value, index) => {
      const td = document.createElement('td');
      td.textContent = String(value ?? '');
      if (index >= 4 && index <= 6) td.style.textAlign = 'center';
      if (index >= 7) {
        td.className = 'segmentpms-path-cell lateralnozzle-path-cell';
        td.title = String(value ?? '');
      }
      tr.append(td);
    });
    tbody.append(tr);
  });
}

function renderComparisonDiagnostics(state, diagnostics) {
  const mount = state.ui.comparisonDiagnostics;
  if (!mount) return;
  mount.innerHTML = '';
  const items = Array.isArray(diagnostics) ? diagnostics.filter(Boolean).slice(0, 12) : [];
  mount.hidden = items.length === 0;
  items.forEach((item) => {
    const line = div('deliverycleaner-note lateralnozzle-file-note');
    line.textContent = typeof item === 'string'
      ? item
      : String(item?.message || item?.detail || '비교 진단');
    mount.append(line);
  });
}

function comparisonNumber(summary, key) {
  return Number(summary?.[key]) || 0;
}

function renderExcelTable(state) {
  const tbody = state.ui.tableBody;
  if (!tbody) return;

  tbody.innerHTML = '';
  if (!state.excelPaths.length) {
    const tr = document.createElement('tr');
    tr.className = 'empty-row';
    const td = document.createElement('td');
    td.colSpan = 4;
    td.className = 'empty-cell';
    td.textContent = '\ub4f1\ub85d\ub41c \uc5d1\uc140 \ud30c\uc77c\uc774 \uc5c6\uc2b5\ub2c8\ub2e4.';
    tr.append(td);
    tbody.append(tr);
  } else {
    state.excelPaths.forEach((path, index) => {
      const tr = document.createElement('tr');

      const checkCell = document.createElement('td');
      checkCell.style.textAlign = 'center';
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.className = 'lateralnozzle-excel-row-check';
      checkbox.dataset.excelPathIndex = String(index);
      checkbox.setAttribute('aria-label', `${getFileName(path)} 실행 대상`);
      checkbox.checked = state.checked.has(path);
      checkbox.addEventListener('change', () => {
        if (checkbox.checked) state.checked.add(path);
        else state.checked.delete(path);
        syncExcelSelectionControls(state);
        renderRunSummary(state);
        updateActionState(state);
      });
      checkCell.append(checkbox);

      const indexCell = document.createElement('td');
      indexCell.style.textAlign = 'center';
      indexCell.textContent = String(index + 1);

      const nameCell = document.createElement('td');
      nameCell.className = 'segmentpms-path-cell lateralnozzle-path-cell';
      nameCell.textContent = getFileName(path);
      nameCell.setAttribute('aria-label', getFileName(path));

      const pathCell = document.createElement('td');
      pathCell.className = 'segmentpms-path-cell lateralnozzle-path-cell';
      pathCell.textContent = path;
      pathCell.setAttribute('aria-label', path || '-');

      tr.append(checkCell, indexCell, nameCell, pathCell);
      tbody.append(tr);
    });
  }

  if (state.ui.masterCheck) {
    state.ui.masterCheck.onchange = () => {
      state.checked = state.ui.masterCheck.checked ? new Set(state.excelPaths) : new Set();
      syncExcelSelectionControls(state);
      renderRunSummary(state);
      updateActionState(state);
    };
  }
  syncExcelSelectionControls(state);
}

function syncExcelSelectionControls(state) {
  const master = state.ui.masterCheck;
  const allChecked = state.excelPaths.length > 0 && state.excelPaths.every((path) => state.checked.has(path));
  if (master) {
    master.disabled = state.excelPaths.length === 0;
    master.checked = allChecked;
    master.indeterminate = state.checked.size > 0 && !allChecked;
  }
  state.ui.tableBody?.querySelectorAll('.lateralnozzle-excel-row-check').forEach((checkbox) => {
    const path = state.excelPaths[Number(checkbox.dataset.excelPathIndex) || 0];
    checkbox.checked = !!path && state.checked.has(path);
  });
}

function renderRunSummary(state) {
  if (!state.ui.runSummary || !state.ui.validation) return;

  const selectedCount = getCheckedExcelPaths(state).length;
  state.ui.runSummary.innerHTML = `
    <strong>\ub4f1\ub85d \ud30c\uc77c ${state.excelPaths.length}\uac1c</strong>
    <span>\uc2e4\ud589 \ub300\uc0c1 ${selectedCount}\uac1c</span>
  `;
  state.ui.validation.textContent = '\uac80\uc0ac \uaddc\uce59: 1) UTILITY / LATERAL NO / Nozzle Code \uc911 \ud558\ub098\ub77c\ub3c4 \ube44\uba74 \ube44\uace0\uc5d0 \ub204\ub77d \ud56d\ubaa9 \ud45c\uc2dc 2) Nozzle Code\ub294 Nozzle Code +  No \uac12\uc744 "_" \ub85c \uc774\uc5b4 \ub9cc\ub4e4\uba70 3) \ucd5c\uc885 Nozzle Code\ub294 \ubc18\ub4dc\uc2dc "_000" \ud615\ud0dc\uc758 \uc22b\uc790 3\uc790\ub9ac\ub85c \ub05d\ub098\uc57c \ud558\uba70, \uc544\ub2c8\uba74 \ube44\uace0\uc5d0 \ud615\uc2dd \ubd88\uc77c\uce58 \ud45c\uc2dc';
}

function renderResultSummary(state) {
  if (!state.ui.resultSummary) return;

  state.ui.resultSummary.textContent = '';
  const result = state.lastResult;
  if (!result) {
    appendResultLine(state.ui.resultSummary, '\ucd5c\uadfc \uacb0\uacfc \uc5c6\uc74c', true);
    appendResultLine(state.ui.resultSummary, '\uc2e4\ud589\uc774 \ub05d\ub098\uba74 \ucc98\ub9ac \ud30c\uc77c \uc218\uc640 \ucd94\ucd9c \uac74\uc218, \ube44\uace0 \uac74\uc218\ub97c \uc5ec\uae30\uc5d0 \ud45c\uc2dc\ud569\ub2c8\ub2e4.');
    renderDiagnostics(state);
    return;
  }

  const summary = result.summary || {};
  const diagnostics = collectDiagnostics(result);
  appendResultLine(state.ui.resultSummary, result.message || '\ucc98\ub9ac\uac00 \uc644\ub8cc\ub418\uc5c8\uc2b5\ub2c8\ub2e4.', true);
  appendResultLine(state.ui.resultSummary, `\ucc98\ub9ac \ud30c\uc77c ${Number(result.fileCount) || 0}\uac1c`);
  appendResultLine(state.ui.resultSummary, `\uc131\uacf5 ${Number(summary.successCount) || 0}\uac1c / \uc2e4\ud328 ${Number(summary.failCount) || 0}\uac1c / \ucd94\ucd9c \uc5c6\uc74c ${Number(summary.noDataCount) || 0}\uac1c`);
  appendResultLine(state.ui.resultSummary, `\ucd94\ucd9c ${Number(summary.extractedRowCount) || 0}\uac74 / \ube44\uace0 ${Number(summary.remarkRowCount) || 0}\uac74`);
  if (diagnostics.length > 0) appendResultLine(state.ui.resultSummary, `\ud615\uc2dd \uc9c4\ub2e8 ${diagnostics.length}\uac74`);
  renderDiagnostics(state, diagnostics);
}

function renderRvtRunSummary(state) {
  if (!state.ui.rvtRunSummary || !state.ui.rvtValidation) return;
  const selectedCount = getCheckedRvtPaths(state).length;
  const mappingNames = parseNozzleCodeParameterNames(state.nozzleCodeParameterNamesText);
  const additionalParameterNames = parseParameterNames(state.additionalParameterNamesText);
  const additionalKeywords = parseAdditionalFamilyOrTypeKeywords(state.additionalFamilyOrTypeKeywordsText);
  state.ui.rvtRunSummary.innerHTML = `
    <strong>등록 RVT ${state.rvtPaths.length}개 · 실행 대상 ${selectedCount}개</strong>
    <span>Nozzle Code 매핑 파라미터 ${mappingNames.length}개 · 추가 확인 파라미터 ${additionalParameterNames.length}개 · 추가 후보 키워드 ${additionalKeywords.length}개</span>
  `;
  const validation = getRvtValidationMessage(state);
  state.ui.rvtValidation.textContent = validation
    ? `입력 확인: ${validation}`
    : '기본 대상은 NOZZLE VALVE(인스턴스 우선, 없으면 타입) 값이 NOZZLE인 객체입니다. 추가 키워드는 패밀리명/타입명의 대소문자 무시 포함 검색으로 후보만 찾습니다. 후보 중 Nozzle Code 매핑 인스턴스값이 하나 이상 있으면 본 결과에 추가하고, 값이 없으면 「추가 노즐 검토 후보」 시트로 분리합니다. 배관 연결 여부는 진단만 하며 선정에는 사용하지 않습니다.';
  state.ui.rvtValidation.classList.toggle('is-invalid', !!validation);
}

function renderRvtResultSummary(state) {
  const mount = state.ui.rvtResultSummary;
  if (!mount) return;
  mount.textContent = '';
  const result = state.rvtLastResult;
  if (!result) {
    appendResultLine(mount, '최근 RVT 추출 결과 없음', true);
    appendResultLine(mount, '실행 후 파일별 대상 객체, NOZZLE 객체, 매핑 결과 행과 누락 진단을 표시합니다.');
    renderRvtDiagnostics(state);
    return;
  }

  const summary = result.summary || {};
  appendResultLine(mount, result.message || 'RVT Nozzle 정보 추출이 완료되었습니다.', true);
  appendResultLine(mount, `처리 파일 ${Number(result.fileCount) || 0}개 · 성공 ${Number(summary.successCount) || 0} · 실패 ${Number(summary.failCount) || 0} · 추출 없음 ${Number(summary.noDataCount) || 0}`);
  appendResultLine(mount, `대상 객체 ${Number(summary.candidateCount) || 0}개 · NOZZLE 객체 ${Number(summary.nozzleObjectCount) || 0}개 · 매핑 결과 ${Number(summary.extractedRowCount) || 0}행`);
  appendResultLine(mount, `추가 키워드 설정 ${Number(result.additionalKeywordCount) || 0}개 · 키워드 일치 ${Number(summary.additionalKeywordMatchedCount) || 0}개 · 기본 마커 중복 ${Number(summary.additionalAlreadySelectedByMarkerCount) || 0}개 · 인스턴스 매핑값으로 추가 확정 ${Number(summary.additionalMappingConfirmedCount) || 0}개 · 검토 후보 ${Number(summary.additionalReviewCandidateCount) || 0}개 · 입력 키워드 미적용 ${Number(summary.unmatchedAdditionalKeywordCount) || 0}개`);
  appendResultLine(mount, `추가 키워드 객체 연결 진단: 직접 배관 연결 ${Number(summary.additionalDirectConnectedCount) || 0}개 · 연결 확인 필요 ${Number(summary.additionalConnectionIssueCount) || 0}개 (선정 조건 아님)`);
  appendResultLine(mount, `NOZZLE VALVE 파라미터 발견 ${Number(summary.filterParameterFoundCount) || 0} · 누락 ${Number(summary.missingFilterParameterCount) || 0}`);
  appendResultLine(mount, `UTILITY 누락 ${Number(summary.missingUtilityCount) || 0} · LATERAL 누락 ${Number(summary.missingLateralCount) || 0} · Nozzle Code 전체 누락 ${Number(summary.missingNozzleCodeCount) || 0}`);
  appendResultLine(mount, `좌표 누락 ${Number(summary.missingCoordinateCount) || 0} · 내부좌표 대체 ${Number(summary.coordinateFallbackCount) || 0} · 중복 이름 파라미터 충돌 ${Number(summary.ambiguousParameterCount) || 0}`);
  renderRvtDiagnostics(state);
}

function collectRvtDiagnostics(result) {
  return (Array.isArray(result?.files) ? result.files : []).filter((file) => {
    const status = String(file?.status || '').toLowerCase();
    return status !== 'success'
      || Number(file?.missingFilterParameterCount) > 0
      || Number(file?.missingUtilityCount) > 0
      || Number(file?.missingLateralCount) > 0
      || Number(file?.missingNozzleCodeCount) > 0
      || Number(file?.missingCoordinateCount) > 0
      || Number(file?.coordinateFallbackCount) > 0
      || Number(file?.ambiguousParameterCount) > 0
      || Number(file?.additionalReviewCandidateCount) > 0
      || Number(file?.additionalConnectionIssueCount) > 0
      || Number(file?.unmatchedAdditionalKeywordCount) > 0;
  });
}

function renderRvtDiagnostics(state) {
  const mount = state.ui.rvtDiagnostics;
  if (!mount) return;
  const diagnostics = collectRvtDiagnostics(state.rvtLastResult);
  mount.textContent = '';
  mount.hidden = diagnostics.length === 0;
  if (!diagnostics.length) return;
  const heading = document.createElement('strong');
  heading.textContent = `RVT 추출 진단 ${diagnostics.length}건`;
  mount.append(heading);
  diagnostics.forEach((file, index) => {
    const details = document.createElement('details');
    if (index === 0) details.open = true;
    const summary = document.createElement('summary');
    summary.textContent = `[${rvtStatusLabel(file?.status)}] ${file?.fileName || file?.filePath || '파일명 없음'}`;
    const message = document.createElement('p');
    message.textContent = file?.message || '세부 진단이 없습니다.';
    const coordinate = document.createElement('p');
    const projectLocation = file?.projectLocationName || '이름 없음';
    const projectPosition = file?.projectPositionSummary || '위치 정보 없음';
    coordinate.textContent = `Project Location: ${projectLocation} · ${projectPosition}`;
    const additionalKeywords = document.createElement('p');
    additionalKeywords.textContent = `추가 키워드 일치 ${Number(file?.additionalKeywordMatchedCount) || 0} · 기본 마커 중복 ${Number(file?.additionalAlreadySelectedByMarkerCount) || 0} · 인스턴스 매핑값으로 추가 확정 ${Number(file?.additionalMappingConfirmedCount) || 0} · 검토 후보 ${Number(file?.additionalReviewCandidateCount) || 0} · 입력 키워드 미적용 ${Number(file?.unmatchedAdditionalKeywordCount) || 0}`;
    const connectionDiagnostic = document.createElement('p');
    connectionDiagnostic.textContent = `연결 진단: 직접 배관 연결 ${Number(file?.additionalDirectConnectedCount) || 0} · 연결 확인 필요 ${Number(file?.additionalConnectionIssueCount) || 0} (선정 조건 아님)`;
    details.append(summary, message, additionalKeywords, connectionDiagnostic, coordinate);
    mount.append(details);
  });
}

function rvtStatusLabel(status) {
  switch (String(status || '').toLowerCase()) {
    case 'success': return '추출 완료·확인 필요';
    case 'nodata': return '추출 대상 없음';
    default: return '처리 실패';
  }
}

function appendResultLine(mount, text, strong = false) {
  const node = document.createElement(strong ? 'strong' : 'span');
  node.textContent = String(text || '');
  mount.append(node);
}

function collectDiagnostics(result) {
  const diagnostics = [];
  const files = Array.isArray(result?.files) ? result.files : [];

  files.forEach((file) => {
    const fileName = file?.fileName || file?.filePath || '\ud30c\uc77c\uba85 \uc5c6\uc74c';
    const sheets = Array.isArray(file?.sheets) ? file.sheets : [];
    let sheetDiagnosticCount = 0;

    sheets.forEach((sheet) => {
      const status = String(sheet?.status || '');
      if (!['headernotfound', 'partialsuccess', 'partialnodata', 'nodata', 'fail'].includes(status.toLowerCase())) return;
      sheetDiagnosticCount += 1;
      diagnostics.push({
        fileName,
        sheetName: sheet?.sheetName || '\uc2dc\ud2b8\uba85 \uc5c6\uc74c',
        status,
        message: sheet?.message || '\ucd94\ucd9c \uc2e4\ud328 \uc6d0\uc778 \uc815\ubcf4\uac00 \uc5c6\uc2b5\ub2c8\ub2e4.'
      });
    });

    const isFileFailure = String(file?.status || '').toLowerCase() === 'fail';
    const isGenericHeaderFailure = String(file?.message || '').includes('KTA \ud5e4\ub354 \ube14\ub85d');
    if (isFileFailure && (sheetDiagnosticCount === 0 || !isGenericHeaderFailure)) {
      diagnostics.push({
        fileName,
        sheetName: '',
        status: file?.status || 'Fail',
        message: file?.message || '\ud30c\uc77c\uc744 \ucc98\ub9ac\ud558\uc9c0 \ubabb\ud588\uc2b5\ub2c8\ub2e4.'
      });
    }
  });

  return diagnostics;
}

function renderDiagnostics(state, preparedDiagnostics = null) {
  const mount = state?.ui?.diagnostics;
  if (!mount) return;

  const diagnostics = preparedDiagnostics || collectDiagnostics(state?.lastResult);
  mount.textContent = '';
  mount.hidden = diagnostics.length === 0;
  if (!diagnostics.length) return;

  const heading = document.createElement('strong');
  heading.textContent = `\ucd94\ucd9c \uc2e4\ud328\u00b7\ud615\uc2dd \uc9c4\ub2e8 ${diagnostics.length}\uac74`;
  mount.append(heading);

  diagnostics.forEach((item, index) => {
    const details = document.createElement('details');
    if (index === 0) details.open = true;

    const summary = document.createElement('summary');
    const location = item.sheetName ? `${item.fileName} / ${item.sheetName}` : item.fileName;
    summary.textContent = `[${diagnosticStatusLabel(item.status)}] ${location}`;

    const message = document.createElement('p');
    message.textContent = item.message;
    details.append(summary, message);
    mount.append(details);
  });
}

function diagnosticStatusLabel(status) {
  switch (String(status || '').toLowerCase()) {
    case 'headernotfound': return '\ud5e4\ub354 \uc778\uc2dd \uc2e4\ud328';
    case 'partialsuccess': return '\uc77c\ubd80 \uad6c\uac04 \ud615\uc2dd \ubd88\uc77c\uce58';
    case 'partialnodata': return '\ud615\uc2dd \ubd88\uc77c\uce58\u00b7\ucd94\ucd9c \uc5c6\uc74c';
    case 'nodata': return '\ucd94\ucd9c \ub300\uc0c1 \uc5c6\uc74c';
    default: return '\ucc98\ub9ac \uc2e4\ud328';
  }
}

function renderRvtTable(state) {
  const tbody = state.ui.rvtTableBody;
  if (!tbody) return;
  tbody.innerHTML = '';
  if (!state.rvtPaths.length) {
    const tr = document.createElement('tr');
    tr.className = 'empty-row';
    const td = document.createElement('td');
    td.colSpan = 4;
    td.className = 'empty-cell';
    td.textContent = '등록된 RVT 파일이 없습니다.';
    tr.append(td);
    tbody.append(tr);
  } else {
    state.rvtPaths.forEach((path, index) => {
      const tr = document.createElement('tr');
      const checkCell = document.createElement('td');
      checkCell.style.textAlign = 'center';
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.className = 'lateralnozzle-rvt-row-check';
      checkbox.dataset.rvtPathIndex = String(index);
      checkbox.setAttribute('aria-label', `${getFileName(path)} 실행 대상`);
      checkbox.checked = state.rvtChecked.has(path);
      checkbox.addEventListener('change', () => {
        if (checkbox.checked) state.rvtChecked.add(path);
        else state.rvtChecked.delete(path);
        syncRvtSelectionControls(state);
        renderRvtRunSummary(state);
        updateRvtActionState(state);
      });
      checkCell.append(checkbox);
      const indexCell = document.createElement('td');
      indexCell.style.textAlign = 'center';
      indexCell.textContent = String(index + 1);
      const nameCell = document.createElement('td');
      nameCell.className = 'segmentpms-path-cell lateralnozzle-path-cell';
      nameCell.textContent = getFileName(path);
      nameCell.setAttribute('aria-label', getFileName(path));
      const pathCell = document.createElement('td');
      pathCell.className = 'segmentpms-path-cell lateralnozzle-path-cell';
      pathCell.textContent = path;
      pathCell.setAttribute('aria-label', path || '-');
      tr.append(checkCell, indexCell, nameCell, pathCell);
      tbody.append(tr);
    });
  }

  if (state.ui.rvtMasterCheck) {
    state.ui.rvtMasterCheck.onchange = () => {
      state.rvtChecked = state.ui.rvtMasterCheck.checked ? new Set(state.rvtPaths) : new Set();
      syncRvtSelectionControls(state);
      renderRvtRunSummary(state);
      updateRvtActionState(state);
    };
  }
  syncRvtSelectionControls(state);
}

function syncRvtSelectionControls(state) {
  const master = state.ui.rvtMasterCheck;
  const allChecked = state.rvtPaths.length > 0 && state.rvtPaths.every((path) => state.rvtChecked.has(path));
  if (master) {
    master.disabled = state.rvtPaths.length === 0;
    master.checked = allChecked;
    master.indeterminate = state.rvtChecked.size > 0 && !allChecked;
  }
  state.ui.rvtTableBody?.querySelectorAll('.lateralnozzle-rvt-row-check').forEach((checkbox) => {
    const path = state.rvtPaths[Number(checkbox.dataset.rvtPathIndex) || 0];
    checkbox.checked = !!path && state.rvtChecked.has(path);
  });
}

function updateActionState(state) {
  const hasFiles = state.excelPaths.length > 0;
  const hasChecked = getCheckedExcelPaths(state).length > 0;
  if (state.ui.addBtn) state.ui.addBtn.disabled = !!state.busy;
  if (state.ui.runBtn) state.ui.runBtn.disabled = !hasChecked || !!state.busy;
  if (state.ui.removeBtn) state.ui.removeBtn.disabled = !hasChecked || !!state.busy;
  if (state.ui.clearBtn) state.ui.clearBtn.disabled = !hasFiles || !!state.busy;
}

function updateRvtActionState(state) {
  const hasFiles = state.rvtPaths.length > 0;
  const hasChecked = getCheckedRvtPaths(state).length > 0;
  const valid = !getRvtValidationMessage(state);
  if (state.ui.rvtAddBtn) state.ui.rvtAddBtn.disabled = !!state.busy;
  if (state.ui.rvtRunBtn) state.ui.rvtRunBtn.disabled = !hasChecked || !valid || !!state.busy;
  if (state.ui.rvtRemoveBtn) state.ui.rvtRemoveBtn.disabled = !hasChecked || !!state.busy;
  if (state.ui.rvtClearBtn) state.ui.rvtClearBtn.disabled = !hasFiles || !!state.busy;
}

function updateComparisonActionState(state) {
  const valid = !getComparisonValidationMessage(state);
  if (state.ui.comparisonKtaMode) state.ui.comparisonKtaMode.disabled = !!state.busy;
  if (state.ui.comparisonRvtMode) state.ui.comparisonRvtMode.disabled = !!state.busy;
  if (state.ui.comparisonKtaPickBtn) state.ui.comparisonKtaPickBtn.disabled = !!state.busy;
  if (state.ui.comparisonRvtPickBtn) state.ui.comparisonRvtPickBtn.disabled = !!state.busy;
  if (state.ui.comparisonRunBtn) state.ui.comparisonRunBtn.disabled = !valid || !!state.busy;
  if (state.ui.comparisonExportBtn) {
    state.ui.comparisonExportBtn.disabled = !valid || state.comparisonLastResult?.canExport !== true || !!state.busy;
  }
}

function getComparisonValidationMessage(state) {
  if (state.comparisonKtaMode === 'file') {
    if (!String(state.comparisonKtaWorkbookPath || '').trim()) return 'KTA 단일화 결과 Excel을 선택해 주세요.';
  } else if (!state.hasRecentKtaResult) {
    return '최근 KTA 단일화 결과가 없습니다. KTA를 실행하거나 저장된 결과 Excel을 선택해 주세요.';
  }

  if (state.comparisonRvtMode === 'file') {
    if (!String(state.comparisonRvtWorkbookPath || '').trim()) return 'RVT Nozzle 추출 결과 Excel을 선택해 주세요.';
  } else if (!state.hasRecentRvtResult) {
    return '최근 RVT Nozzle 추출 결과가 없습니다. RVT 추출을 실행하거나 저장된 결과 Excel을 선택해 주세요.';
  }
  return '';
}

function runExtraction(state) {
  const paths = getCheckedExcelPaths(state);
  if (!paths.length) {
    toast('실행할 엑셀 파일을 1개 이상 선택해 주세요.', 'warn');
    return;
  }

  state.comparisonLastResult = null;
  state.hasRecentKtaResult = false;
  renderComparisonState(state);
  state.acceptProgress = true;
  setPageBusy(state, true, 'kta');
  ProgressDialog.setActions({});
  ProgressDialog.show('노즐코드 KTA 단일화', '엑셀 파일을 읽는 중입니다.');
  ProgressDialog.update(0, '엑셀 파일을 읽는 중입니다.', '선택한 엑셀 파일 목록과 변환 대상을 정리하는 중입니다.');
  post('lateralnozzle:run', {
    excelPaths: paths,
    outputFolder: ''
  });
}

function runRvtExtraction(state) {
  const paths = getCheckedRvtPaths(state);
  const validation = getRvtValidationMessage(state);
  if (validation) {
    toast(validation, 'warn', 3200);
    return;
  }
  state.comparisonLastResult = null;
  state.hasRecentRvtResult = false;
  renderComparisonState(state);
  state.acceptProgress = true;
  setPageBusy(state, true, 'rvt');
  ProgressDialog.setActions({});
  ProgressDialog.show('RVT Nozzle 정보 추출', 'RVT 파일을 확인하는 중입니다.');
  ProgressDialog.update(0, 'RVT 파일을 확인하는 중입니다.', '사용자 웍셋을 모두 닫은 상태로 파이프 피팅과 악세사리를 검사합니다.');
  post('lateralnozzle:rvt-run', {
    rvtPaths: paths,
    utilityParameterName: state.utilityParameterName.trim(),
    lateralParameterName: state.lateralParameterName.trim(),
    nozzleCodeParameterNames: parseNozzleCodeParameterNames(state.nozzleCodeParameterNamesText),
    additionalParameterNames: parseParameterNames(state.additionalParameterNamesText),
    // Keep the legacy bridge property for installed hosts while its meaning is now keyword rules.
    additionalIncludedFamilyOrTypeNames: parseAdditionalFamilyOrTypeKeywords(state.additionalFamilyOrTypeKeywordsText),
    additionalFamilyOrTypeKeywords: parseAdditionalFamilyOrTypeKeywords(state.additionalFamilyOrTypeKeywordsText),
    outputFolder: ''
  });
}

function runComparison(state) {
  const validation = getComparisonValidationMessage(state);
  if (validation) {
    toast(validation, 'warn', 3400);
    return;
  }
  state.comparisonLastResult = null;
  setPageBusy(state, true, 'compare');
  ProgressDialog.setActions({});
  ProgressDialog.show('KTA ↔ RVT 비교', '두 결과를 읽고 비교하는 중입니다.');
  ProgressDialog.update(10, '두 결과를 읽고 비교하는 중입니다.', 'UTILITY, LATERAL NO, Nozzle Code와 발생 위치를 정규화하고 있습니다.');
  post('lateralnozzle:compare-run', {
    ktaSourceMode: state.comparisonKtaMode,
    rvtSourceMode: state.comparisonRvtMode,
    ktaWorkbookPath: state.comparisonKtaWorkbookPath,
    rvtWorkbookPath: state.comparisonRvtWorkbookPath
  });
}

async function promptLateralNozzleExcelExport(state) {
  const excelMode = await chooseExcelMode();
  if (!excelMode) return;

  setPageBusy(state, true, 'kta');
  ProgressDialog.setActions({});
  ProgressDialog.show('엑셀 내보내기', '엑셀 저장을 준비하는 중입니다.');
  ProgressDialog.update(0, '엑셀 저장을 준비하는 중입니다.', '결과 엑셀 저장 옵션을 정리하는 중입니다.');
  post('lateralnozzle:export', { excelMode: excelMode || 'fast', locale: getLastExcelExportLocale() });
}

async function promptRvtNozzleExcelExport(state) {
  const excelMode = await chooseExcelMode();
  if (!excelMode) return;
  state.acceptProgress = true;
  setPageBusy(state, true, 'rvt-export');
  ProgressDialog.setActions({});
  ProgressDialog.show('엑셀 내보내기', 'RVT Nozzle 결과 저장을 준비하는 중입니다.');
  ProgressDialog.update(0, '엑셀 저장을 준비하는 중입니다.', '좌표 열은 숫자 형식으로 작성한 뒤 숨김 처리합니다.');
  post('lateralnozzle:rvt-export', { excelMode: excelMode || 'fast', locale: getLastExcelExportLocale() });
}

async function promptComparisonExcelExport(state) {
  if (state.comparisonLastResult?.canExport !== true) {
    toast('저장할 비교 결과가 없습니다. 먼저 비교를 실행해 주세요.', 'warn');
    return;
  }
  const excelMode = await chooseExcelMode();
  if (!excelMode) return;
  setPageBusy(state, true, 'compare');
  ProgressDialog.setActions({});
  ProgressDialog.show('비교 결과 Excel 내보내기', '비교 결과 저장을 준비하는 중입니다.');
  ProgressDialog.update(0, '비교 결과 저장을 준비하는 중입니다.', '요약, 전체 비교, 한쪽 누락, 중복과 위치 상세 시트를 구성합니다.');
  post('lateralnozzle:compare-export', { excelMode: excelMode || 'fast', locale: getLastExcelExportLocale() });
}

function showLateralNozzleResultDialog(state, payload = {}) {
  const summary = payload?.summary || state?.lastResult?.summary || {};
  const fileCount = Number(payload?.fileCount ?? state?.lastResult?.fileCount) || 0;
  const successCount = Number(summary.successCount) || 0;
  const failCount = Number(summary.failCount) || 0;
  const noDataCount = Number(summary.noDataCount) || 0;
  const extractedRowCount = Number(summary.extractedRowCount) || 0;
  const remarkRowCount = Number(summary.remarkRowCount) || 0;
  const diagnostics = collectDiagnostics({
    files: Array.isArray(payload?.files) ? payload.files : state?.lastResult?.files
  });

  const notes = [
    `\ucd94\ucd9c \uc5c6\uc74c ${noDataCount}\uac1c`,
    '\uacb0\uacfc \uc2dc\ud2b8\ub294 UTILITY / LATERAL NO / Nozzle Code / \ube44\uace0 \uad6c\uc131\uc73c\ub85c \uc800\uc7a5\ub429\ub2c8\ub2e4.',
    'Nozzle Code \uc5f4\uc740 \uc6d0\ubcf8 \uc591\uc2dd\uc758 Nozzle Code\uc640  No \uac12\uc744 "_" \ub85c \uc774\uc5b4 \uc0dd\uc131\ud569\ub2c8\ub2e4.',
    '\ube44\uace0\uc5d0\ub294 \ud544\uc218 \ud56d\ubaa9 \ub204\ub77d\uacfc Nozzle Code \ud615\uc2dd \ubd88\uc77c\uce58\uac00 \ud45c\uc2dc\ub429\ub2c8\ub2e4.'
  ];
  diagnostics.slice(0, 8).forEach((item) => {
    const location = item.sheetName ? `${item.fileName} / ${item.sheetName}` : item.fileName;
    notes.push(`[${diagnosticStatusLabel(item.status)}] ${location}: ${item.message}`);
  });
  if (diagnostics.length > 8) notes.push(`\ucd94\uac00 \uc9c4\ub2e8 ${diagnostics.length - 8}\uac74\uc740 \uba54\uc778 \ud654\uba74\uacfc \uacb0\uacfc \uc5d1\uc140\uc758 Logs \uc2dc\ud2b8\uc5d0\uc11c \ud655\uc778\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4.`);

  showCompletionSummaryDialog({
    title: '\ub178\uc990\ucf54\ub4dc KTA \ub2e8\uc77c\ud654 \uc644\ub8cc',
    message: payload?.message || '\ucd94\ucd9c\uc774 \uc644\ub8cc\ub418\uc5c8\uc2b5\ub2c8\ub2e4. \ud544\uc694\ud558\uba74 \uacb0\uacfc \uc5d1\uc140\uc744 \uc800\uc7a5\ud558\uc138\uc694.',
    summaryItems: [
      { label: '\ub300\uc0c1 \ud30c\uc77c', value: `${fileCount}\uac1c` },
      { label: '\uc131\uacf5', value: `${successCount}\uac1c` },
      { label: '\uc2e4\ud328', value: `${failCount}\uac1c` },
      { label: '\ucd94\ucd9c \ud589', value: `${extractedRowCount}\uac74` },
      { label: '\ube44\uace0 \ud589', value: `${remarkRowCount}\uac74` }
    ],
    notes,
    exportLabel: '\ub178\uc990\ucf54\ub4dc KTA \ub2e8\uc77c\ud654 \uc5d1\uc140',
    showExport: payload?.canExport === true || state?.lastResult?.canExport === true,
    onExport: () => promptLateralNozzleExcelExport(state)
  });
}

function showRvtResultDialog(state, payload = {}) {
  const summary = payload?.summary || state?.rvtLastResult?.summary || {};
  const files = Array.isArray(payload?.files) ? payload.files : state?.rvtLastResult?.files || [];
  const resultAdditionalKeywordsSource = Array.isArray(payload?.additionalFamilyOrTypeKeywords)
    ? payload.additionalFamilyOrTypeKeywords
    : payload?.additionalIncludedFamilyOrTypeNames;
  const resultAdditionalKeywords = Array.isArray(resultAdditionalKeywordsSource)
    ? normalizeAdditionalFamilyOrTypeKeywords(resultAdditionalKeywordsSource)
    : state?.rvtLastResult?.additionalFamilyOrTypeKeywords || [];
  const additionalKeywordCount = Number(payload?.additionalKeywordCount
    ?? payload?.additionalIncludedFamilyOrTypeNameCount
    ?? state?.rvtLastResult?.additionalKeywordCount) || resultAdditionalKeywords.length;
  const resultAdditionalParameterNames = Array.isArray(payload?.additionalParameterNames)
    ? parseParameterNames(payload.additionalParameterNames)
    : state?.rvtLastResult?.additionalParameterNames || [];
  const additionalParameterCount = Number(payload?.additionalParameterCount
    ?? state?.rvtLastResult?.additionalParameterCount) || resultAdditionalParameterNames.length;
  const diagnostics = collectRvtDiagnostics({ files });
  const notes = [
    '정렬 순서: UTILITY → LATERAL 그룹 대표 X 오름차순 → Y 내림차순 → X 오름차순.',
    'Nozzle Code 매핑 파라미터는 입력 개수 제한 없이, 한 객체에서 값이 있는 파라미터마다 결과 행을 하나씩 생성합니다.',
    `추가 확인 파라미터 ${additionalParameterCount}개는 객체별 별도 열과 비교 위치 상세에 함께 기록합니다.`,
    `추가 후보 키워드 ${additionalKeywordCount}개: 대소문자를 구분하지 않고 패밀리명 또는 타입명에 키워드가 포함된 인스턴스를 후보로 확인했습니다.`,
    '입력 문법: keyword는 패밀리명 또는 타입명 중 하나에 포함되면 일치합니다. familyKeyword::typeKeyword는 패밀리명과 타입명에 각각 포함되어야 하며, 여러 줄은 OR입니다.',
    '키워드만으로는 본 결과에 포함하지 않습니다. 기본 NOZZLE 마커가 없더라도 Nozzle Code 매핑 인스턴스값이 하나 이상 있으면 추가 확정하고, 값이 전부 비어 있으면 「추가 노즐 검토 후보」 시트로 분리합니다.',
    '배관 직접 연결 여부는 진단 정보로만 기록합니다. 연결되지 않았거나 커넥터를 확인할 수 없어도 매핑 인스턴스값이 있으면 본 결과에서 제외하지 않습니다.',
    'X/Y는 활성 Project Location 공유좌표(mm)의 숫자 열로 저장되며 기본 숨김 처리됩니다. 공유좌표 변환 실패 시 내부좌표는 보존하되 전역 정렬에서는 제외합니다.',
    '결과 행에는 Source RVT·ElementId·Category·Family·Type이 각각 독립 열로 표시되고, 매핑 파라미터명과 RVT 경로는 숨김 열에 보존됩니다. 검토 후보도 별도 시트의 독립 열에서 객체 정보·유효 매핑값·진단 사유를 확인할 수 있습니다.'
  ];
  diagnostics.slice(0, 8).forEach((file) => {
    notes.push(`[${rvtStatusLabel(file?.status)}] ${file?.fileName || file?.filePath || '파일명 없음'}: ${file?.message || '세부 진단 없음'}`);
  });
  if (diagnostics.length > 8) notes.push(`추가 진단 ${diagnostics.length - 8}건은 메인 화면과 결과 엑셀의 요약/Logs 시트에서 확인할 수 있습니다.`);

  showCompletionSummaryDialog({
    title: 'RVT Nozzle 정보 추출 완료',
    message: payload?.message || 'RVT Nozzle 정보 추출이 완료되었습니다.',
    summaryItems: [
      { label: '대상 파일', value: `${Number(payload?.fileCount ?? state?.rvtLastResult?.fileCount) || 0}개` },
      { label: 'NOZZLE 객체', value: `${Number(summary.nozzleObjectCount) || 0}개` },
      { label: '매핑 결과', value: `${Number(summary.extractedRowCount) || 0}행` },
      { label: '추가 키워드 일치', value: `${Number(summary.additionalKeywordMatchedCount) || 0}개` },
      { label: '기본 마커와 중복', value: `${Number(summary.additionalAlreadySelectedByMarkerCount) || 0}개` },
      { label: '매핑값으로 추가 확정', value: `${Number(summary.additionalMappingConfirmedCount) || 0}개` },
      { label: '추가 노즐 검토 후보', value: `${Number(summary.additionalReviewCandidateCount) || 0}개` },
      { label: '직접 배관 연결', value: `${Number(summary.additionalDirectConnectedCount) || 0}개` },
      { label: '연결 확인 필요', value: `${Number(summary.additionalConnectionIssueCount) || 0}개` },
      { label: '입력 키워드 미적용', value: `${Number(summary.unmatchedAdditionalKeywordCount) || 0}개` },
      { label: '실패', value: `${Number(summary.failCount) || 0}개` },
      { label: '파라미터 충돌', value: `${Number(summary.ambiguousParameterCount) || 0}건` },
      { label: '비고 행', value: `${Number(summary.remarkRowCount) || 0}건` }
    ],
    notes,
    exportLabel: 'RVT Nozzle 정보 엑셀',
    showExport: payload?.canExport === true || state?.rvtLastResult?.canExport === true,
    onExport: () => promptRvtNozzleExcelExport(state)
  });
}

function showComparisonResultDialog(state, payload = {}) {
  const summary = payload?.summary || {};
  const comparisonOk = payload?.ok !== false;
  const notes = [
    '완전 일치는 UTILITY + LATERAL NO + Nozzle Code의 정규화 키와 발생 수량이 모두 같은 경우입니다.',
    '동일 Nozzle Code가 양쪽에서 각각 한 번만 나타날 때 Utility 또는 Lateral 차이를 속성 불일치로 연결합니다.',
    'RVT 검토 후보는 확정 결과 수량에서 제외하며, KTA 누락 항목과 연결되는 경우에만 별도 진단합니다.',
    '번호 공간 순서는 같은 RVT·UTILITY·LATERAL·코드 접두부에서 안정적인 단일 X/Y 경로일 때만 판정하며 정방향·역방향을 모두 허용합니다.',
    'KTA 파일·시트·행/열과 RVT 파일·ElementId·Category·Family·Type은 화면 미리보기와 비교 결과 Excel에서 위치가 포함되는 각 결과 시트의 별도 열로 확인할 수 있습니다.'
  ];
  (Array.isArray(payload?.diagnostics) ? payload.diagnostics : []).slice(0, 6).forEach((item) => {
    notes.push(typeof item === 'string' ? item : String(item?.message || item?.detail || '비교 진단'));
  });

  showCompletionSummaryDialog({
    title: comparisonOk ? 'KTA ↔ RVT 비교 완료' : 'KTA ↔ RVT 비교 입력 오류',
    message: payload?.message || (comparisonOk
      ? 'KTA 단일화 결과와 RVT Nozzle 추출 결과를 비교했습니다.'
      : '선택한 결과 Excel의 형식과 입력 진단을 확인해 주세요.'),
    summaryItems: [
      { label: 'KTA 행', value: `${comparisonNumber(summary, 'ktaRowCount')}건` },
      { label: 'RVT 매핑 행', value: `${comparisonNumber(summary, 'rvtRowCount')}건` },
      { label: 'RVT 객체', value: `${comparisonNumber(summary, 'rvtObjectCount')}개` },
      { label: '일치 수량', value: `${comparisonNumber(summary, 'matchedQuantity')}건` },
      { label: '수량 불일치', value: `${comparisonNumber(summary, 'quantityMismatchKeyCount')}키` },
      { label: '속성 불일치', value: `${comparisonNumber(summary, 'attributeMismatchCount')}건` },
      { label: 'KTA만', value: `${comparisonNumber(summary, 'ktaOnlyKeyCount')}키` },
      { label: 'RVT만', value: `${comparisonNumber(summary, 'rvtOnlyKeyCount')}키` },
      { label: 'KTA 중복', value: `${comparisonNumber(summary, 'ktaDuplicateKeyCount')}키` },
      { label: 'RVT 중복', value: `${comparisonNumber(summary, 'rvtDuplicateKeyCount')}키` },
      { label: '검토 후보 발견', value: `${comparisonNumber(summary, 'reviewCandidateMatchCount')}건` },
      { label: '비교 불가', value: `${comparisonNumber(summary, 'incompleteRowCount')}행` },
      { label: '공간 순서 이상', value: `${comparisonNumber(summary, 'spatialSequenceSuspectedCount')}그룹` },
      { label: '공간 판정 보류', value: `${comparisonNumber(summary, 'spatialSequenceDeferredCount')}그룹` },
      { label: '번호 중복', value: `${comparisonNumber(summary, 'spatialSequenceDuplicateNumberGroupCount')}그룹` },
      { label: '번호 누락', value: `${comparisonNumber(summary, 'spatialSequenceMissingNumberGroupCount')}그룹` }
    ],
    notes,
    exportLabel: 'KTA·RVT 비교 결과 Excel',
    showExport: payload?.canExport === true,
    onExport: () => promptComparisonExcelExport(state)
  });
}

function appendExcelPaths(state, paths) {
  let added = 0;
  (Array.isArray(paths) ? paths : []).forEach((path) => {
    const normalized = String(path || '').trim();
    if (!normalized) return;
    if (!state.excelPaths.some((item) => samePath(item, normalized))) {
      state.excelPaths.push(normalized);
      added += 1;
    }
    state.checked.add(normalized);
  });
  return added;
}

function appendRvtPaths(state, paths) {
  let added = 0;
  (Array.isArray(paths) ? paths : []).forEach((path) => {
    const normalized = String(path || '').trim();
    if (!normalized || !/\.rvt$/i.test(normalized)) return;
    if (!state.rvtPaths.some((item) => samePath(item, normalized))) {
      state.rvtPaths.push(normalized);
      added += 1;
    }
    state.rvtChecked.add(normalized);
  });
  return added;
}

function getCheckedExcelPaths(state) {
  return state.excelPaths.filter((path) => state.checked.has(path));
}

function getCheckedRvtPaths(state) {
  return state.rvtPaths.filter((path) => state.rvtChecked.has(path));
}

function parseParameterNames(value) {
  const names = [];
  const seen = new Set();
  const rawNames = Array.isArray(value) ? value : String(value || '').split(/[,;\r\n]+/);
  rawNames.forEach((rawName) => {
    const name = String(rawName || '').trim();
    const key = name.toLowerCase();
    if (!name || seen.has(key)) return;
    seen.add(key);
    names.push(name);
  });
  return names;
}

function parseNozzleCodeParameterNames(value) {
  return parseParameterNames(value);
}

function normalizeAdditionalFamilyOrTypeKeywords(value) {
  const rawKeywords = Array.isArray(value)
    ? value
    : String(value || '').split(/\r\n?|\n/);
  const keywords = [];
  const seen = new Set();
  rawKeywords.forEach((rawKeyword) => {
    const keyword = String(rawKeyword || '').trim();
    const key = keyword.toLowerCase();
    if (!keyword || seen.has(key)) return;
    seen.add(key);
    keywords.push(keyword);
  });
  return keywords;
}

function parseAdditionalFamilyOrTypeKeywords(value) {
  return normalizeAdditionalFamilyOrTypeKeywords(value);
}

function getRvtValidationMessage(state) {
  if (!getCheckedRvtPaths(state).length) return '실행할 RVT 파일을 1개 이상 선택해 주세요.';
  if (!String(state.utilityParameterName || '').trim()) return 'UTILITY 값을 읽을 파라미터명을 입력해 주세요.';
  if (!String(state.lateralParameterName || '').trim()) return 'LATERAL 값을 읽을 파라미터명을 입력해 주세요.';
  const mappingNames = parseNozzleCodeParameterNames(state.nozzleCodeParameterNamesText);
  if (!mappingNames.length) return 'Nozzle Code 매핑 파라미터명을 1개 이상 입력해 주세요.';
  return '';
}

function loadLateralNozzlePreferences() {
  try {
    const parsed = JSON.parse(localStorage.getItem(LATERAL_NOZZLE_SETTINGS_KEY) || '{}');
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function applyLateralNozzlePreferences(state, value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return;
  state.activeTab = ['kta', 'rvt', 'compare'].includes(value.activeTab) ? value.activeTab : 'kta';
  state.comparisonKtaMode = value.comparisonKtaMode === 'file' ? 'file' : 'recent';
  state.comparisonRvtMode = value.comparisonRvtMode === 'file' ? 'file' : 'recent';
  state.utilityParameterName = String(value.utilityParameterName || '');
  state.lateralParameterName = String(value.lateralParameterName || '');
  state.nozzleCodeParameterNamesText = String(value.nozzleCodeParameterNamesText || '');
  state.additionalParameterNamesText = String(value.additionalParameterNamesText || '');
  state.additionalFamilyOrTypeKeywordsText = String(
    value.additionalFamilyOrTypeKeywordsText
      ?? value.additionalIncludedFamilyOrTypeNamesText
      ?? ''
  );
  state.parameterPreferenceOwner.utility = true;
  state.parameterPreferenceOwner.lateral = true;
  state.parameterPreferenceOwner.nozzle = true;
  state.parameterPreferenceOwner.additionalParameters = true;
  state.parameterPreferenceOwner.additionalKeywords = true;
}

function saveLateralNozzlePreferences(state) {
  const serialized = JSON.stringify({
    activeTab: ['kta', 'rvt', 'compare'].includes(state.activeTab) ? state.activeTab : 'kta',
    comparisonKtaMode: state.comparisonKtaMode === 'file' ? 'file' : 'recent',
    comparisonRvtMode: state.comparisonRvtMode === 'file' ? 'file' : 'recent',
    utilityParameterName: String(state.utilityParameterName || ''),
    lateralParameterName: String(state.lateralParameterName || ''),
    nozzleCodeParameterNamesText: String(state.nozzleCodeParameterNamesText || ''),
    additionalParameterNamesText: String(state.additionalParameterNamesText || ''),
    additionalFamilyOrTypeKeywordsText: String(state.additionalFamilyOrTypeKeywordsText || '')
  });
  if (serialized === state.lastSavedPreferences) return;
  try {
    localStorage.setItem(LATERAL_NOZZLE_SETTINGS_KEY, serialized);
    state.lastSavedPreferences = serialized;
  } catch { }
}

function attachLateralNozzlePreferenceSync(page, state) {
  let applyTimer = 0;
  let routeTimer = 0;
  const tryApply = () => {
    clearTimeout(applyTimer);
    if (!page.isConnected) return;
    const active = document.activeElement;
    const editing = !!active && page.contains(active) && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName || '');
    if (state.busy || editing) {
      applyTimer = window.setTimeout(tryApply, 400);
      return;
    }
    const value = loadLateralNozzlePreferences();
    applyLateralNozzlePreferences(state, value);
    state.lastSavedPreferences = JSON.stringify(value || {});
    applyInputValueIfIdle(state.ui.rvtUtilityInput, state.utilityParameterName);
    applyInputValueIfIdle(state.ui.rvtLateralInput, state.lateralParameterName);
    applyInputValueIfIdle(state.ui.rvtNozzleInput, state.nozzleCodeParameterNamesText);
    applyInputValueIfIdle(state.ui.rvtAdditionalParametersInput, state.additionalParameterNamesText);
    applyInputValueIfIdle(state.ui.rvtAdditionalKeywordsInput, state.additionalFamilyOrTypeKeywordsText);
    syncWorkflowTabs(state);
    renderRvtRunSummary(state);
    updateRvtActionState(state);
    renderComparisonState(state);
  };
  const onSharedChange = (event) => {
    if (!isSharedPreferenceEventFor(event, LATERAL_NOZZLE_SETTINGS_KEY)) return;
    tryApply();
  };
  const cleanup = () => {
    clearTimeout(applyTimer);
    clearTimeout(routeTimer);
    window.removeEventListener('kky:shared-settings-changed', onSharedChange);
    window.removeEventListener('hashchange', onRouteChange);
    if (activeLateralNozzlePreferenceCleanup === cleanup) activeLateralNozzlePreferenceCleanup = null;
  };
  const onRouteChange = () => {
    clearTimeout(routeTimer);
    routeTimer = window.setTimeout(() => {
      if (!page.isConnected) cleanup();
    }, 0);
  };
  window.addEventListener('kky:shared-settings-changed', onSharedChange);
  window.addEventListener('hashchange', onRouteChange);
  return cleanup;
}

function isSharedPreferenceEventFor(event, key) {
  const detail = event?.detail;
  if (!detail) return true;
  const keys = Array.isArray(detail.keys) ? [...detail.keys] : [];
  if (detail.key) keys.push(detail.key);
  if (detail.values && typeof detail.values === 'object') keys.push(...Object.keys(detail.values));
  return !keys.length || keys.includes(key);
}

function samePath(left, right) {
  return String(left || '').toLowerCase() === String(right || '').toLowerCase();
}

function getFileName(path) {
  const parts = String(path || '').split(/[/\\]/);
  return parts[parts.length - 1] || '';
}

function actionButton(label, onClick, variant = 'secondary') {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = `btn ${variant === 'primary' ? 'btn--primary' : 'btn--secondary'}`;
  btn.textContent = label;
  btn.addEventListener('click', onClick);
  return btn;
}

function setPageBusy(state, on, mode = '') {
  state.busy = !!on;
  state.busyMode = state.busy ? mode : '';
  if (!state.busy) state.acceptProgress = false;
  const busyLabel = state.busyMode === 'rvt' || state.busyMode === 'rvt-export'
    ? (state.busyMode === 'rvt-export'
      ? 'RVT Nozzle 정보 엑셀을 저장하는 중입니다.'
      : 'RVT Nozzle 정보 추출 작업을 처리하는 중입니다.')
    : state.busyMode === 'compare'
      ? 'KTA와 RVT 결과를 비교하는 중입니다.'
      : 'KTA 단일화 작업을 처리하는 중입니다.';
  setBusy(on, on ? busyLabel : '');
  updateActionState(state);
  updateRvtActionState(state);
  updateComparisonActionState(state);
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
