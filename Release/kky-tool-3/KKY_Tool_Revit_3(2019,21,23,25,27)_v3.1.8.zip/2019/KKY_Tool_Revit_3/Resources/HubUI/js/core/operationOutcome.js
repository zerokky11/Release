export function resultValue(raw, key) {
  return raw?.[key] ?? raw?.[key[0].toUpperCase() + key.slice(1)];
}

export function resultCount(raw, key, fallback = 0) {
  const value = resultValue(raw, key);
  if (value === undefined || value === null || value === '') return fallback;
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, number) : fallback;
}

// Counts also protect the UI when older hosts omit Status or return an optimistic Ok flag.
export function operationOutcome(raw, counts = {}) {
  const explicit = String(resultValue(raw, 'status') || '').toLowerCase();
  const failures = Number(counts.failureCount || 0) + Number(counts.partialCount || 0) + Number(counts.rejectedCount || 0);
  const changed = Number(counts.changedCount || 0);
  const success = Number(counts.successCount || 0);
  let status;
  if (explicit === 'cancelled' || explicit === 'canceled') status = 'cancelled';
  else if (failures > 0) status = changed > 0 || success > 0 || Number(counts.partialCount) > 0 ? 'partial' : 'failed';
  else if (explicit === 'partial') status = 'partial';
  else if (explicit === 'failed' || explicit === 'fail' || resultValue(raw, 'ok') === false && explicit !== 'notargets' && explicit !== 'nochange') status = 'failed';
  else if (explicit === 'notargets' || explicit === 'notarget' || counts.targetCount === 0 || (counts.skippedCount > 0 && !success && !changed)) status = 'notargets';
  else if (explicit === 'nochange' || (counts.noChangeCount > 0 && !success && !changed)) status = 'nochange';
  else if (counts.noDataCount > 0 && !success && !changed) status = 'nodata';
  else status = 'success';
  const labels = { success: '완료', partial: '일부 실패', failed: '실패', notargets: counts.noTargetLabel || '적용 대상 없음', nochange: '변경 없음', nodata: '추출 결과 없음', cancelled: '취소' };
  const messages = { success: '작업이 완료되었습니다.', partial: '일부 작업을 처리하지 못했습니다. 실패 수량과 이유를 확인하세요.', failed: '작업을 처리하지 못했습니다. 실패 이유를 확인하세요.', notargets: '처리할 대상이 없습니다.', nochange: '변경된 값이 없습니다.', nodata: '조건에 일치하는 추출 결과가 없습니다.', cancelled: '작업이 취소되었습니다.' };
  return { status, label: labels[status], tone: status === 'failed' ? 'err' : status === 'partial' ? 'warn' : status === 'success' || status === 'nochange' ? 'ok' : 'info', message: String(resultValue(raw, 'message') || messages[status]) };
}
