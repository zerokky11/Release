import {
  clear,
  div,
  toast,
  showExcelSavedDialog,
  showCompletionSummaryDialog,
  closeCompletionSummaryDialog
} from '../core/dom.js?v=20260731parameterexport1';
import { refreshUiAfterHostDialog } from '../core/hostDialog.js';
import { ProgressDialog } from '../core/progress.js';
import { onHost, post } from '../core/bridge.js';

let activeCentralWorksetCleanup = null;
let localRowSequence = 0;
const INVALID_WORKSET_CHARACTERS = /[{}\[\]|;<>?`~]/;
const ROW_IDENTITY_SOURCE = 'source';
const ROW_IDENTITY_ROW_ID = 'rowId';
const VIEW_TEMPLATE_OWNERSHIP_TARGET_KIND = 'view3d-template-workset-v2';
const LEVEL_GRID_OWNERSHIP_TARGET_KIND = 'level-grid-userworkset-v2';
const LEVEL_GRID_OWNERSHIP_WORKSET_NAME = 'Shared Levels and Grids';
const EXISTING_CENTRAL_OWNERSHIP_TARGET_KIND = 'existing-central-delta-v1';
const CENTRAL_WORKSET_FEATURE_LABEL = '센트럴 파일생성, 웍셋 추가 Grid/Level, 3D 뷰 권한 적용';

export function renderCentralWorkset(root, options = {}) {
  activeCentralWorksetCleanup?.();

  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);
  const initialMode = normalizeOperationMode(options?.mode || (options?.worksetsOnly === true ? 'worksets' : 'centralize'));
  const worksetsOnly = initialMode === 'worksets';
  const ownershipOnly = false;
  const detachedWindow = options?.detachedWindow === true;

  const state = {
    worksetsOnly,
    ownershipOnly,
    operationMode: initialMode,
    detachedWindow,
    instanceId: `centralworkset-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    activeDocument: null,
    activePolicyMessage: '',
    rows: [],
    checkedRowIds: new Set(),
    selectedRowId: '',
    fileSearch: '',
    fileFilter: 'all',
    draftRevision: 0,
    draftTimer: 0,
    pendingRemoteDraft: null,
    remoteDraftApplyTimer: 0,
    activePointerIds: new Set(),
    compositionActive: false,
    interactionCleanup: null,
    disposed: false,
    navigatorTimer: 0,
    interactionRestoreGeneration: 0,
    requestSequence: 0,
    activeRequestId: '',
    activeRequestKind: '',
    awaitingWorkbookPick: false,
    workbookReplaceConfirmed: false,
    bulkEditorOpen: false,
    exportRequested: false,
    operationOwner: false,
    runRequested: false,
    commonFolder: '',
    workbookPath: '',
    overwriteExisting: false,
    busy: false,
    progressVisible: false,
    lastMode: '',
    lastSummary: null,
    hostUnsubscribers: [],
    ui: {}
  };

  const page = div(`feature-shell centralworkset-page${worksetsOnly ? ' centralworkset-page--worksets-only' : ''}${ownershipOnly ? ' centralworkset-page--ownership-only' : ''}${detachedWindow ? ' centralworkset-page--detached' : ''}`);
  const header = div('feature-header centralworkset-feature-header');
  const heading = div('feature-heading');
  const title = CENTRAL_WORKSET_FEATURE_LABEL;
  const subtitle = '센트럴 저장 경로를 입력하면 새 센트럴을 만들고, 비우면 기존 센트럴에 Grid/Level·3D 뷰·3D 뷰 템플릿 권한을 적용합니다.';
  heading.innerHTML = `
    <span class="feature-kicker">Central / Workset</span>
    <h2 class="feature-title">${title}</h2>
    <p class="feature-sub">${subtitle}</p>`;
  header.append(heading);
  if (detachedWindow) {
    const headerActions = div('centralworkset-window-actions');
    const centralMode = actionButton('센트럴 생성·권한 적용', () => switchCentralWorksetMode(state, 'centralize'), isCreateMode(initialMode) ? 'primary' : 'ghost');
    const worksetMode = actionButton('웍셋만 확인·추가', () => switchCentralWorksetMode(state, 'worksets'), worksetsOnly ? 'primary' : 'ghost');
    const closeButton = actionButton('작업창 숨기기 (설정 유지)', () => {
      if (state.busy) {
        toast('실행 중에는 작업창을 숨길 수 없습니다. 작업이 끝난 후 다시 시도하세요.', 'warn');
        return;
      }
      post('centralworkset:close-window', {});
    }, 'ghost');
    headerActions.append(centralMode, worksetMode, closeButton);
    header.append(headerActions);
    state.ui.centralModeButton = centralMode;
    state.ui.worksetModeButton = worksetMode;
    state.ui.closeWindowButton = closeButton;
  }

  const workspace = div('centralworkset-workspace');
  const runPanel = div('centralworkset-run-panel');
  page.append(header, workspace, runPanel);
  target.append(page);

  state.ui.page = page;
  state.ui.workspace = workspace;
  state.ui.runPanel = runPanel;
  syncHeaderActions(state);

  state.interactionCleanup = registerCentralWorksetDraftInteraction(state);
  state.hostUnsubscribers = registerHostEvents(state);
  renderWorkspace(state);
  renderRunPanel(state);
  post('centralworkset:init', {});

  const cleanupOnRouteChange = () => {
    const route = String(location.hash || '').replace(/^#/, '').split('?')[0].toLowerCase();
    const expectedRoute = state.worksetsOnly ? 'worksetmanager' : 'centralworkset';
    if (route !== expectedRoute) cleanup();
  };
  const cleanup = () => {
    if (state.disposed) return;
    state.disposed = true;
    state.interactionCleanup?.();
    state.interactionCleanup = null;
    discardPendingRemoteDraft(state);
    state.hostUnsubscribers.forEach((unsubscribe) => unsubscribe?.());
    state.hostUnsubscribers = [];
    if (state.draftTimer) flushDraftBroadcast(state);
    if (state.navigatorTimer) window.clearTimeout(state.navigatorTimer);
    state.navigatorTimer = 0;
    closeCompletionSummaryDialog();
    ProgressDialog.hide();
    window.removeEventListener('hashchange', cleanupOnRouteChange);
    if (activeCentralWorksetCleanup === cleanup) activeCentralWorksetCleanup = null;
  };

  activeCentralWorksetCleanup = cleanup;
  window.addEventListener('hashchange', cleanupOnRouteChange);
}

function registerHostEvents(state) {
  const unsubscribers = [];
  const listen = (eventName, handler) => unsubscribers.push(onHost(eventName, handler));

  listen('centralworkset:window-context', (payload) => {
    const draft = pick(payload, 'draft', 'Draft');
    if (draft && typeof draft === 'object') applyDraft(state, draft);
    ensureSelectedRow(state);
    renderWorkspace(state);
    renderRunPanel(state);
  });

  listen('centralworkset:draft-sync', (payload) => {
    if (!payload || typeof payload !== 'object') return;
    const sourceId = String(pick(payload, 'sourceId', 'SourceId') || '');
    // The Host broadcasts its normalized draft back to every Central/Workset
    // WebView, including the sender. The local editor already owns this exact
    // revision, so rebuilding it here would destroy IME/focus/caret and reset
    // the nested settings scroll position on every debounced keystroke.
    if (sourceId && sourceId === state.instanceId) return;
    receiveCentralWorksetRemoteDraft(state, payload);
  });

  listen('centralworkset:context', (payload) => {
    state.activeDocument = normalizeActiveDocument(pick(payload, 'activeDocument', 'ActiveDocument'));
    state.activePolicyMessage = String(
      pick(payload, 'activeDocumentPolicyMessage', 'ActiveDocumentPolicyMessage', 'policyMessage', 'PolicyMessage') ||
      state.activePolicyMessage ||
      ''
    ).trim();
    const incomingRows = arrayOf(pick(payload, 'rows', 'Rows'));
    if (incomingRows.length) replaceRows(state, incomingRows, { preserveEdits: true });
    state.workbookPath = String(pick(payload, 'workbookPath', 'WorkbookPath') || state.workbookPath || '').trim();
    ensureSelectedRow(state);
    renderWorkspace(state);
    renderRunPanel(state);
  });

  listen('centralworkset:active-added', (payload) => {
    const request = matchActiveRequest(state, payload, ['add-active']);
    if (!request) return;
    finishActiveRequest(state, request);
    const raw = pick(payload, 'row', 'Row') || payload;
    if (!raw || typeof raw !== 'object') {
      renderWorkspace(state);
      renderRunPanel(state);
      return;
    }
    const activeSourceKey = normalizePathKey(pick(raw, 'sourcePath', 'SourcePath'));
    const alreadyRegistered = !!activeSourceKey && state.rows.some((row) => normalizePathKey(row.sourcePath) === activeSourceKey);
    mergeRows(state, [raw], { preserveEdits: true, checkIncoming: true });
    ensureSelectedRow(state);
    renderWorkspace(state);
    renderRunPanel(state);
    scheduleDraftBroadcast(state);
    if (alreadyRegistered) toast('이미 등록된 활성 문서입니다. 기존 경로와 웍셋 설정을 유지했습니다.', 'info');
  });

  listen('centralworkset:rvts-picked', (payload) => {
    const dropped = toBoolean(pick(payload, 'dropped', 'Dropped')) ||
      !!String(pick(payload, 'dropOrigin', 'DropOrigin') || '').trim();
    if (dropped) {
      if (state.busy || state.activeRequestId) {
        toast('현재 작업이 끝난 뒤 RVT 파일을 다시 놓아 주세요.', 'warn');
        return;
      }
    } else {
      const request = matchActiveRequest(state, payload, ['pick-rvts']);
      if (!request) return;
      finishActiveRequest(state, request);
    }
    const paths = normalizePathList(pick(payload, 'paths', 'Paths'));
    addAndInspectPaths(state, paths);
    refreshUiAfterHostDialog(() => {
      renderWorkspace(state);
      renderRunPanel(state);
    });
  });

  listen('centralworkset:rows', (payload) => {
    const request = matchActiveRequest(state, payload, ['inspect', 'import-workbook']);
    if (!request) return;
    const initiatedHere = state.operationOwner;
    const source = String(pick(payload, 'source', 'Source') || '').trim().toLowerCase();
    const incomingRows = arrayOf(pick(payload, 'rows', 'Rows'));
    if (source.includes('import') || source.includes('workbook') || source === 'excel') {
      replaceRows(state, incomingRows, {
        preserveEdits: false,
        checkIncoming: true,
        identityKind: ROW_IDENTITY_ROW_ID
      });
      state.overwriteExisting = false;
      const importedOperation = uniformApplyOperation(state.rows);
      if (importedOperation === 'WORKSETS') setCentralWorksetModeState(state, 'worksets');
      else setCentralWorksetModeState(state, 'centralize');
    } else {
      mergeRows(state, incomingRows, { preserveEdits: true, checkIncoming: true });
    }
    state.workbookPath = String(pick(payload, 'workbookPath', 'WorkbookPath') || state.workbookPath || '').trim();
    ensureSelectedRow(state);
    finishActiveRequest(state, request);
    renderWorkspace(state);
    renderRunPanel(state);
    scheduleDraftBroadcast(state);
    if (initiatedHere && (source.includes('import') || source.includes('workbook') || source === 'excel')) {
      toast(`${state.rows.length}개 작업 행을 Excel에서 불러왔습니다.`, 'ok');
    }
  });

  listen('centralworkset:common-folder-picked', (payload) => {
    const request = matchActiveRequest(state, payload, ['pick-common-folder']);
    if (!request) return;
    finishActiveRequest(state, request);
    const folder = String(pick(payload, 'folder', 'Folder') || '').trim();
    if (!folder) {
      renderWorkspace(state);
      renderRunPanel(state);
      return;
    }
    const affectedRows = state.rows.filter((row) => {
      const nextPath = joinWindowsPath(folder, row.sourceFileName || fileName(row.sourcePath));
      return normalizePathKey(row.outputCentralPath) !== normalizePathKey(nextPath);
    });
    const configuredRows = affectedRows.filter((row) => String(row.outputCentralPath || '').trim());
    if (affectedRows.length) {
      const message = [
        `선택한 폴더로 ${affectedRows.length}개 파일의 새 센트럴 경로를 다시 설정할까요?`,
        configuredRows.length ? `기존에 입력한 개별 경로 ${configuredRows.length}개가 바뀝니다.` : '',
        '실행 제외 파일의 설정도 다음 작업을 위해 같이 바뀝니다.'
      ].filter(Boolean).join('\n');
      if (!window.confirm(message)) return;
    }
    state.commonFolder = folder;
    state.overwriteExisting = false;
    state.rows.forEach((row) => {
      invalidateOwnershipWorkbookTrust(row);
      row.outputCentralPath = joinWindowsPath(folder, row.sourceFileName || fileName(row.sourcePath));
      row.owned3DViewNames = [];
      row.ownedViewTemplateNames = [];
      row.ownedLevelGridCount = 0;
      row.ownedLevelGridWorksetNames = [];
    });
    scheduleDraftBroadcast(state);
    refreshUiAfterHostDialog(() => {
      renderWorkspace(state);
      renderRunPanel(state);
    });
  });

  listen('centralworkset:row-output-picked', (payload) => {
    const request = matchActiveRequest(state, payload, ['pick-row-output']);
    if (!request) return;
    finishActiveRequest(state, request);
    const rowId = String(pick(payload, 'rowId', 'RowId') || '').trim();
    const path = String(pick(payload, 'path', 'Path') || '').trim();
    const row = findRow(state, rowId, String(pick(payload, 'sourcePath', 'SourcePath') || ''));
    if (!row || !path) {
      renderWorkspace(state);
      renderRunPanel(state);
      return;
    }
    invalidateOwnershipWorkbookTrust(row);
    row.outputCentralPath = path;
    row.owned3DViewNames = [];
    row.ownedViewTemplateNames = [];
    row.ownedLevelGridCount = 0;
    row.ownedLevelGridWorksetNames = [];
    state.overwriteExisting = false;
    scheduleDraftBroadcast(state);
    refreshUiAfterHostDialog(() => {
      renderWorkspace(state);
      renderRunPanel(state);
    });
  });

  listen('centralworkset:template-exported', (payload) => {
    const request = matchActiveRequest(state, payload, ['export-template']);
    if (!request) return;
    const requestedHere = state.exportRequested;
    finishActiveRequest(state, request);
    renderWorkspace(state);
    renderRunPanel(state);
    const ok = !!pick(payload, 'ok', 'Ok');
    const path = String(pick(payload, 'path', 'Path') || '').trim();
    if (ok && path) {
      state.workbookPath = path;
      if (!requestedHere) return;
      requestAnimationFrame(() => showExcelSavedDialog(
        '센트럴/웍셋 Excel 양식을 저장했습니다.',
        path,
        (savedPath) => post('excel:open', { path: savedPath })
      ));
      return;
    }
    if (requestedHere) toast(String(pick(payload, 'message', 'Message') || 'Excel 양식 저장이 취소되었거나 실패했습니다.'), ok ? 'info' : 'err');
  });

  listen('centralworkset:workbook-picked', (payload) => {
    const dropped = toBoolean(pick(payload, 'dropped', 'Dropped')) ||
      !!String(pick(payload, 'dropOrigin', 'DropOrigin') || '').trim();
    let request = null;
    if (!dropped) {
      request = matchActiveRequest(state, payload, ['pick-workbook']);
      if (!request || !state.awaitingWorkbookPick) return;
    }
    const path = String(pick(payload, 'path', 'Path') || '').trim();
    const replaceConfirmed = state.workbookReplaceConfirmed;
    if (request) finishActiveRequest(state, request);
    if (!path) {
      state.workbookReplaceConfirmed = false;
      renderWorkspace(state);
      renderRunPanel(state);
      return;
    }
    if (dropped) {
      state.workbookReplaceConfirmed = false;
      if (state.busy) {
        toast('현재 작업이 끝난 뒤 Excel 파일을 다시 놓아 주세요.', 'warn');
        return;
      }
      const replaceConfirmed = !state.rows.length || window.confirm([
        `놓은 Excel 파일로 현재 ${state.rows.length}개 작업 행과 설정을 교체할까요?`,
        '덮어쓰기 허용은 안전을 위해 OFF로 초기화됩니다. 취소하면 현재 설정을 유지합니다.'
      ].join('\n'));
      if (!replaceConfirmed) return;
      state.workbookPath = path;
      startWorkbookImport(state, path, { replaceConfirmed: true });
      return;
    }
    state.workbookPath = path;
    state.workbookReplaceConfirmed = false;
    startWorkbookImport(state, path, { replaceConfirmed });
    refreshUiAfterHostDialog(() => {
      renderWorkspace(state);
      renderRunPanel(state);
    });
  });

  listen('centralworkset:progress', (payload) => {
    if (!matchActiveRequest(state, payload, ['inspect', 'import-workbook', 'run'])) return;
    const percent = clampPercent(pick(payload, 'percent', 'Percent'));
    const message = String(pick(payload, 'message', 'Message') || 'RVT를 처리하는 중입니다.');
    const detail = String(pick(payload, 'detail', 'Detail') || '');
    const becameBusy = !state.busy;
    state.busy = true;
    if (state.operationOwner && !state.progressVisible) {
      state.progressVisible = true;
      showCentralProgress('센트럴 파일 / 웍셋 작업', message);
    }
    if (state.operationOwner) ProgressDialog.update(percent, message, detail);
    if (becameBusy) renderWorkspace(state);
    syncHeaderActions(state);
    renderRunPanel(state);
  });

  listen('centralworkset:completed', (payload) => {
    const request = matchActiveRequest(state, payload, ['run']);
    if (!request) return;
    const incomingRows = arrayOf(pick(payload, 'rows', 'Rows'));
    const completedMode = String(pick(payload, 'mode', 'Mode') || state.lastMode || '').trim().toLowerCase();
    if (incomingRows.length) applyCompletedRows(state, incomingRows, completedMode);
    ensureSelectedRow(state);
    state.lastSummary = pick(payload, 'summary', 'Summary') || {};
    const ok = pick(payload, 'ok', 'Ok') !== false;
    const shouldShowResult = state.runRequested;
    state.lastMode = completedMode || state.lastMode;
    finishActiveRequest(state, request);
    renderWorkspace(state);
    renderRunPanel(state);
    if (shouldShowResult) showCompletedDialog(state, ok, state.lastSummary);
  });

  listen('centralworkset:error', (payload) => {
    const responseRequestId = String(pick(payload, 'requestId', 'RequestId') || '').trim();
    if (!state.activeRequestId &&
        responseRequestId.startsWith(`${state.instanceId}:`)) return;
    const request = state.activeRequestId
      ? matchActiveRequest(state, payload, [state.activeRequestKind])
      : null;
    if (state.activeRequestId && !request) return;
    const message = String(pick(payload, 'message', 'Message') || '센트럴 파일/웍셋 처리 중 오류가 발생했습니다.');
    const detail = String(pick(payload, 'detail', 'Detail') || '').trim();
    const shouldNotify = !!request || state.operationOwner || state.runRequested || !state.busy;
    if (request) finishActiveRequest(state, request);
    renderWorkspace(state);
    renderRunPanel(state);
    if (shouldNotify) toast(detail ? `${message} · ${detail}` : message, 'err', 5200);
  });

  listen('centralworkset:close-blocked', (payload) => {
    toast(String(pick(payload, 'message', 'Message') || '현재 작업이 끝난 뒤 다시 시도하세요.'), 'warn', 4600);
  });

  listen('host:excel-drop-invalid', (payload) => {
    toast(String(pick(payload, 'message', 'Message') || '.xlsx 파일 하나만 놓을 수 있습니다.'), 'warn', 4600);
  });

  return unsubscribers;
}

function registerCentralWorksetDraftInteraction(state) {
  const page = state.ui.page;
  if (!page) return () => {};

  const pointerKey = (event) => event?.pointerId == null ? 'primary' : String(event.pointerId);
  const finishInteraction = () => schedulePendingRemoteDraftApply(state);
  const onPointerDown = (event) => {
    state.activePointerIds.add(pointerKey(event));
  };
  const onPointerEnd = (event) => {
    state.activePointerIds.delete(pointerKey(event));
    finishInteraction();
  };
  const onWindowBlur = () => {
    state.activePointerIds.clear();
    state.compositionActive = false;
    finishInteraction();
  };
  const onCompositionStart = (event) => {
    if (isCentralWorksetDraftEditor(state, event.target)) state.compositionActive = true;
  };
  const onCompositionEnd = () => {
    state.compositionActive = false;
    // compositionend can be followed by the final input event. Let that event
    // update local state before deciding whether the remote draft is still newer.
    finishInteraction();
  };
  const onFocusOut = () => {
    // focusout precedes focusin when moving between editors, so wait until the
    // active element and any pointer-triggered change event have settled.
    finishInteraction();
  };

  window.addEventListener('pointerdown', onPointerDown, true);
  window.addEventListener('pointerup', onPointerEnd, true);
  window.addEventListener('pointercancel', onPointerEnd, true);
  window.addEventListener('blur', onWindowBlur, true);
  page.addEventListener('compositionstart', onCompositionStart, true);
  page.addEventListener('compositionend', onCompositionEnd, true);
  page.addEventListener('focusout', onFocusOut, true);

  return () => {
    window.removeEventListener('pointerdown', onPointerDown, true);
    window.removeEventListener('pointerup', onPointerEnd, true);
    window.removeEventListener('pointercancel', onPointerEnd, true);
    window.removeEventListener('blur', onWindowBlur, true);
    page.removeEventListener('compositionstart', onCompositionStart, true);
    page.removeEventListener('compositionend', onCompositionEnd, true);
    page.removeEventListener('focusout', onFocusOut, true);
    state.activePointerIds.clear();
    state.compositionActive = false;
  };
}

function isCentralWorksetDraftEditor(state, element) {
  return !!element?.matches?.('input, select, textarea') &&
    containsCentralWorksetInteractionElement(state, element);
}

function shouldDeferCentralWorksetRemoteDraft(state) {
  return state.compositionActive ||
    state.activePointerIds.size > 0 ||
    isCentralWorksetDraftEditor(state, document.activeElement);
}

function receiveCentralWorksetRemoteDraft(state, draft) {
  if (!state || state.disposed || !draft || typeof draft !== 'object') return;

  // This local write will be published after the remote event, so it wins.
  if (state.draftTimer) return;

  // Host payloads are full-state drafts. Coalesce while editing and retain only
  // the most recently delivered remote state.
  state.pendingRemoteDraft = draft;
  if (shouldDeferCentralWorksetRemoteDraft(state)) return;
  applyPendingCentralWorksetRemoteDraft(state);
}

function schedulePendingRemoteDraftApply(state) {
  if (!state || state.disposed || !state.pendingRemoteDraft || state.remoteDraftApplyTimer) return;
  state.remoteDraftApplyTimer = window.setTimeout(() => {
    state.remoteDraftApplyTimer = 0;
    applyPendingCentralWorksetRemoteDraft(state);
  }, 0);
}

function applyPendingCentralWorksetRemoteDraft(state) {
  if (!state || state.disposed || !state.pendingRemoteDraft) return;
  if (state.draftTimer || shouldDeferCentralWorksetRemoteDraft(state)) return;

  const draft = state.pendingRemoteDraft;
  state.pendingRemoteDraft = null;
  if (state.remoteDraftApplyTimer) window.clearTimeout(state.remoteDraftApplyTimer);
  state.remoteDraftApplyTimer = 0;
  applyDraft(state, draft);
  ensureSelectedRow(state);
  renderWorkspace(state);
  renderRunPanel(state);
}

function discardPendingRemoteDraft(state) {
  if (!state) return;
  if (state.remoteDraftApplyTimer) window.clearTimeout(state.remoteDraftApplyTimer);
  state.remoteDraftApplyTimer = 0;
  state.pendingRemoteDraft = null;
}

function setCentralWorksetFocusKey(element, key) {
  if (element && key) element.dataset.centralworksetFocusKey = String(key);
  return element;
}

function setCentralWorksetScrollKey(element, key) {
  if (element && key) element.dataset.centralworksetScrollKey = String(key);
  return element;
}

function getCentralWorksetInteractionRoots(state) {
  return [state.ui.workspace, state.ui.runPanel].filter(Boolean);
}

function containsCentralWorksetInteractionElement(state, element) {
  return !!element && getCentralWorksetInteractionRoots(state)
    .some((root) => root === element || root.contains(element));
}

function findCentralWorksetKeyedElement(state, dataKey, value) {
  if (!value) return null;
  const property = dataKey === 'scroll' ? 'centralworksetScrollKey' : 'centralworksetFocusKey';
  for (const root of getCentralWorksetInteractionRoots(state)) {
    if (root.dataset?.[property] === value) return root;
    const candidates = root.querySelectorAll?.(`[data-centralworkset-${dataKey}-key]`) || [];
    for (const candidate of candidates) {
      if (candidate.dataset?.[property] === value) return candidate;
    }
  }
  return null;
}

function getCentralWorksetScrollElements(state) {
  const candidates = [];
  const add = (element) => {
    if (element) candidates.push(element);
  };

  getCentralWorksetInteractionRoots(state).forEach((root) => {
    add(root);
    root.querySelectorAll?.('[data-centralworkset-scroll-key]').forEach(add);
  });

  // Depending on Revit/WebView width, scrolling can belong to a persistent
  // shell ancestor instead of the detached detail itself. Preserve both.
  [state.ui.workspace, state.ui.runPanel].forEach((start) => {
    let current = start?.parentElement;
    while (current && current !== document.body) {
      add(current);
      current = current.parentElement;
    }
  });
  add(document.scrollingElement || document.documentElement || document.body);

  const seen = new Set();
  return candidates.filter((element) => {
    if (!element || seen.has(element)) return false;
    seen.add(element);
    return true;
  });
}

function captureCentralWorksetFocus(state) {
  const element = document.activeElement;
  const key = String(element?.dataset?.centralworksetFocusKey || '');
  if (!key || !containsCentralWorksetInteractionElement(state, element)) return null;

  let selectionStart = null;
  let selectionEnd = null;
  let selectionDirection = null;
  try {
    if (typeof element.selectionStart === 'number' && typeof element.selectionEnd === 'number') {
      selectionStart = element.selectionStart;
      selectionEnd = element.selectionEnd;
      selectionDirection = element.selectionDirection || 'none';
    }
  } catch {
  }

  return {
    element,
    key,
    value: 'value' in element ? String(element.value) : String(element.textContent || ''),
    selectionStart,
    selectionEnd,
    selectionDirection
  };
}

function captureCentralWorksetInteraction(state) {
  return {
    scroll: getCentralWorksetScrollElements(state).map((element) => ({
      element,
      key: String(element.dataset?.centralworksetScrollKey || ''),
      top: Math.max(0, Number(element.scrollTop) || 0),
      left: Math.max(0, Number(element.scrollLeft) || 0)
    })),
    focus: captureCentralWorksetFocus(state)
  };
}

function resolveCentralWorksetScrollElement(state, snapshot) {
  if (snapshot?.element?.isConnected) return snapshot.element;
  return snapshot?.key ? findCentralWorksetKeyedElement(state, 'scroll', snapshot.key) : null;
}

function restoreCentralWorksetScroll(state, snapshot) {
  (snapshot?.scroll || []).forEach((position) => {
    const element = resolveCentralWorksetScrollElement(state, position);
    if (!element || !element.isConnected) return;
    const maxTop = Math.max(0, element.scrollHeight - element.clientHeight);
    const maxLeft = Math.max(0, element.scrollWidth - element.clientWidth);
    element.scrollTop = Math.min(Math.max(0, position.top), maxTop);
    element.scrollLeft = Math.min(Math.max(0, position.left), maxLeft);
  });
}

function restoreCentralWorksetFocus(state, snapshot) {
  const focus = snapshot?.focus;
  if (!focus) return;
  const element = focus.element?.isConnected
    ? focus.element
    : findCentralWorksetKeyedElement(state, 'focus', focus.key);
  if (!element || element.disabled) return;
  if (document.activeElement !== element) {
    try {
      element.focus({ preventScroll: true });
    } catch {
      element.focus?.();
    }
  }
  if (document.activeElement !== element || focus.selectionStart === null) return;
  const value = 'value' in element ? String(element.value) : String(element.textContent || '');
  if (value !== focus.value) return;
  try {
    element.setSelectionRange(
      focus.selectionStart,
      focus.selectionEnd,
      focus.selectionDirection || 'none'
    );
  } catch {
  }
}

function beginCentralWorksetInteractionRender(state, options = {}) {
  state.interactionRestoreGeneration += 1;
  return {
    generation: state.interactionRestoreGeneration,
    snapshot: options.preserveInteraction === false ? null : captureCentralWorksetInteraction(state)
  };
}

function completeCentralWorksetInteractionRender(state, transaction) {
  const snapshot = transaction?.snapshot;
  const generation = transaction?.generation;
  if (!snapshot) return;
  const canRestore = () => (
    state.interactionRestoreGeneration === generation
    && !!state.ui.workspace?.isConnected
  );
  const restore = () => {
    if (!canRestore()) return;
    restoreCentralWorksetFocus(state, snapshot);
    restoreCentralWorksetScroll(state, snapshot);
  };

  restore();
  if (typeof window.requestAnimationFrame === 'function') {
    window.requestAnimationFrame(() => {
      if (!canRestore()) return;
      restoreCentralWorksetScroll(state, snapshot);
      window.requestAnimationFrame(() => {
        if (canRestore()) restoreCentralWorksetScroll(state, snapshot);
      });
    });
  } else {
    window.setTimeout(() => {
      if (canRestore()) restoreCentralWorksetScroll(state, snapshot);
    }, 0);
  }
}

function renderWorkspace(state, options = {}) {
  const host = state.ui.workspace;
  if (!host) return;
  const interaction = beginCentralWorksetInteractionRender(state, options);
  clear(host);
  host.append(buildDetachedWorkspace(state));
  completeCentralWorksetInteractionRender(state, interaction);
}

function requestActiveDocument(state) {
  beginHostRequest(state, 'add-active', 'centralworkset:add-active', {});
}

function requestRvtPicker(state) {
  beginHostRequest(state, 'pick-rvts', 'centralworkset:pick-rvts', {});
}

function requestCommonFolder(state) {
  beginHostRequest(state, 'pick-common-folder', 'centralworkset:pick-common-folder', {});
}

function requestRowOutput(state, row) {
  if (!row) return;
  beginHostRequest(state, 'pick-row-output', 'centralworkset:pick-row-output', {
    rowId: row.rowId,
    sourcePath: row.sourcePath,
    currentPath: row.outputCentralPath || ''
  });
}

function buildDetachedWorkspace(state) {
  const shell = div('centralworkset-batch-shell');
  shell.classList.toggle('is-locked', state.busy);
  shell.inert = state.busy;
  shell.setAttribute('aria-busy', state.busy ? 'true' : 'false');
  shell.append(buildDetachedCommandBar(state));

  const body = div('centralworkset-batch-body');
  body.append(buildDetachedFileNavigator(state), buildDetachedFileDetail(state));
  shell.append(body);
  return shell;
}

function buildCentralWorksetModeTabs(state) {
  const tabs = div('centralworkset-mode-tabs');
  tabs.setAttribute('role', 'tablist');
  tabs.setAttribute('aria-label', '센트럴 및 웍셋 작업 방식');

  const addTab = (mode, kicker, title, description) => {
    const active = mode === currentOperationMode(state);
    const tab = document.createElement('button');
    tab.type = 'button';
    tab.className = `centralworkset-mode-tab${active ? ' is-active' : ''}`;
    tab.setAttribute('role', 'tab');
    tab.setAttribute('aria-selected', active ? 'true' : 'false');
    tab.dataset.centralworksetMode = mode;
    setCentralWorksetFocusKey(tab, `mode:${mode}`);
    tab.disabled = state.busy;
    tab.innerHTML = `<span>${kicker}</span><strong>${title}</strong><small>${description}</small>`;
    tab.addEventListener('click', () => switchCentralWorksetMode(state, mode));
    tabs.append(tab);
  };

  addTab(
    'centralize',
    '통합 설정',
    '센트럴 생성·권한 적용',
    '경로 입력=새 센트럴 · 경로 비움=기존 센트럴 권한'
  );
  addTab(
    'worksets',
    '웍셋 전용',
    '웍셋 확인·추가',
    '기존·연결 센트럴에 신규 웍셋만 추가'
  );
  return tabs;
}

function buildDetachedCommandBar(state) {
  const bar = div('centralworkset-batch-commandbar');
  const steps = div('centralworkset-process-steps');
  const stepMode = currentOperationMode(state);
  const stepIssues = collectCentralValidationIssues(state.rows, stepMode);
  const stepSummary = summarizeRows(state.rows, stepMode);
  const canRunStep = stepSummary.applyRowCount > 0 && !stepIssues.length &&
    (stepMode !== 'worksets' || stepSummary.newWorksetCount > 0);
  steps.innerHTML = `
    <span class="is-active"><b>1</b> RVT 등록·확인</span>
    <span class="${state.rows.length ? 'is-active' : ''}"><b>2</b> 파일별 설정</span>
    <span class="${canRunStep ? 'is-active' : ''}"><b>3</b> 검증·실행</span>`;

  const actions = div('centralworkset-batch-actions');
  const activeButton = actionButton('활성 문서 추가', () => requestActiveDocument(state), 'secondary');
  activeButton.disabled = state.busy || state.activeDocument?.canUse === false;
  const addButton = actionButton('RVT 파일 추가', () => requestRvtPicker(state), 'primary');
  addButton.disabled = state.busy;
  const inspectButton = actionButton('정보 다시 읽기', () => inspectCurrentRows(state), 'secondary');
  inspectButton.disabled = state.busy || !state.rows.length;
  actions.append(activeButton, addButton, inspectButton);

  if (isCreateMode(stepMode)) {
    const folderButton = actionButton('공통 출력 폴더', () => requestCommonFolder(state), 'secondary');
    folderButton.disabled = state.busy || !state.rows.length;
    actions.append(folderButton);
  }

  const excelExport = actionButton('Excel 내보내기', () => exportTemplate(state), 'ghost');
  excelExport.disabled = state.busy || !state.rows.length;
  const excelImport = actionButton('Excel 불러오기', () => requestWorkbookPick(state), 'ghost');
  excelImport.disabled = state.busy;
  const clearButton = actionButton('목록 비우기', () => clearRows(state), 'ghost');
  clearButton.disabled = state.busy || !state.rows.length;
  actions.append(excelExport, excelImport, clearButton);

  const bulk = document.createElement('details');
  bulk.className = 'centralworkset-bulk-worksets';
  bulk.open = state.bulkEditorOpen;
  bulk.addEventListener('toggle', () => { state.bulkEditorOpen = bulk.open; });
  const bulkSummary = document.createElement('summary');
  bulkSummary.innerHTML = '<strong>여러 파일에 공통 웍셋 추가</strong><span>필요할 때 펼쳐서 실행 포함 파일 전체에 한 번에 적용합니다.</span>';
  const bulkBody = div('centralworkset-bulk-worksets-body');
  const bulkInput = document.createElement('textarea');
  bulkInput.rows = 2;
  bulkInput.className = 'centralworkset-workset-input centralworkset-workset-input--bulk';
  setCentralWorksetFocusKey(bulkInput, 'bulk-worksets');
  bulkInput.placeholder = '예: A-건축; S-구조; M-기계';
  bulkInput.disabled = state.busy || !state.rows.some((row) => !isSkippedRow(row));
  const bulkApply = actionButton('공통 웍셋 추가', () => {
    const names = parseWorksets(bulkInput.value);
    if (!names.length) {
      toast('공통으로 추가할 웍셋 이름을 입력해 주세요.', 'warn');
      return;
    }
    const invalidNames = validateWorksetNameList(names);
    if (invalidNames.length) {
      toast(invalidNames[0], 'warn', 5200);
      return;
    }
    let changed = 0;
    state.rows.forEach((row) => {
      if (isSkippedRow(row)) return;
      const before = row.addWorksets.length;
      const nextNames = distinctNames([...row.addWorksets, ...names]);
      if (nextNames.length !== before) invalidateOwnershipWorkbookTrust(row);
      row.addWorksets = nextNames;
      if (row.addWorksets.length !== before) {
        row.owned3DViewNames = [];
        row.ownedViewTemplateNames = [];
        row.ownedLevelGridCount = 0;
        row.ownedLevelGridWorksetNames = [];
        changed += 1;
      }
    });
    bulkInput.value = '';
    state.bulkEditorOpen = false;
    scheduleDraftBroadcast(state);
    renderWorkspace(state);
    renderRunPanel(state);
    toast(`${changed}개 실행 포함 파일에 공통 웍셋을 반영했습니다.`, changed ? 'ok' : 'info', 5200);
  }, 'secondary');
  bulkApply.disabled = state.busy || !state.rows.some((row) => !isSkippedRow(row));
  bulkBody.append(bulkInput, bulkApply);
  bulk.append(bulkSummary, bulkBody);

  bar.append(buildCentralWorksetModeTabs(state), steps, actions);
  if (stepMode !== 'ownership') bar.append(bulk);
  return bar;
}

function buildDetachedFileNavigator(state) {
  const nav = div('centralworkset-file-navigator');
  const header = div('centralworkset-file-nav-header');
  const copy = document.createElement('div');
  const applyCount = state.rows.filter((row) => !isSkippedRow(row)).length;
  copy.innerHTML = `<span>RVT JOBS</span><h3>작업 행 ${state.rows.length}개</h3><p>실행 포함 ${applyCount} · 제외 ${state.rows.length - applyCount}</p>`;
  header.append(copy);

  const master = document.createElement('label');
  master.className = 'centralworkset-apply-master';
  master.dataset.applyMaster = 'true';
  const masterInput = document.createElement('input');
  masterInput.type = 'checkbox';
  setCentralWorksetFocusKey(masterInput, 'visible-files-include');
  const masterCopy = document.createElement('span');
  masterInput.addEventListener('change', () => {
    const visibleRows = getFilteredRows(state);
    if (!visibleRows.length) return;
    visibleRows.forEach((row) => {
      invalidateOwnershipWorkbookTrust(row);
      row.action = masterInput.checked ? 'APPLY' : 'SKIP';
    });
    scheduleDraftBroadcast(state);
    renderWorkspace(state);
    renderRunPanel(state);
  });
  master.append(masterInput, masterCopy);
  header.append(master);

  const filters = div('centralworkset-file-filters');
  const search = document.createElement('input');
  search.type = 'search';
  search.placeholder = '파일명·경로 검색';
  search.value = state.fileSearch;
  setCentralWorksetFocusKey(search, 'file-search');
  search.addEventListener('input', () => {
    state.fileSearch = search.value;
    refreshDetachedFileList(state, nav);
  });
  const filter = document.createElement('select');
  [
    ['all', '전체 상태'],
    ['apply', '실행 포함'],
    ['skip', '실행 제외'],
    ['issue', '확인 필요'],
    ['ready', '실행 준비'],
    ['failed', '실패 결과']
  ].forEach(([value, label]) => {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    filter.append(option);
  });
  filter.value = state.fileFilter;
  setCentralWorksetFocusKey(filter, 'file-filter');
  filter.addEventListener('change', () => {
    state.fileFilter = filter.value;
    refreshDetachedFileList(state, nav);
  });
  filters.append(search, filter);

  const list = setCentralWorksetScrollKey(div('centralworkset-file-list'), 'file-list');
  list.dataset.fileList = 'true';
  fillDetachedFileList(state, list);
  nav.append(header, filters, list);
  updateDetachedMaster(state, nav);
  return nav;
}

function refreshDetachedFileList(state, nav) {
  const list = nav?.querySelector('[data-file-list]');
  if (!list) return;
  const interaction = beginCentralWorksetInteractionRender(state);
  const filtered = getFilteredRows(state);
  const selectedVisible = filtered.some((row) => row.rowId === state.selectedRowId);
  if (!selectedVisible) state.selectedRowId = filtered[0]?.rowId || '';
  fillDetachedFileList(state, list, filtered);
  updateDetachedMaster(state, nav);
  const oldDetail = state.ui.workspace?.querySelector('.centralworkset-file-detail');
  if (oldDetail) oldDetail.replaceWith(buildDetachedFileDetail(state));
  completeCentralWorksetInteractionRender(state, interaction);
}

function scheduleDetachedNavigatorRefresh(state) {
  if (state.busy) return;
  if (state.navigatorTimer) window.clearTimeout(state.navigatorTimer);
  state.navigatorTimer = window.setTimeout(() => {
    state.navigatorTimer = 0;
    const nav = state.ui.workspace?.querySelector('.centralworkset-file-navigator');
    const list = nav?.querySelector('[data-file-list]');
    if (!nav || !list) return;
    const interaction = beginCentralWorksetInteractionRender(state);
    fillDetachedFileList(state, list, getFilteredRows(state));
    updateDetachedMaster(state, nav);
    completeCentralWorksetInteractionRender(state, interaction);
  }, 80);
}

function getFilteredRows(state) {
  const mode = currentOperationMode(state);
  const query = state.fileSearch.trim().toLocaleLowerCase();
  return state.rows.filter((row) => {
    const searchable = [
      row.sourceFileName,
      row.sourcePath,
      row.outputCentralPath,
      row.worksetTargetPath,
      row.centralPath,
      ...normalizeStringList(row.existingWorksets),
      ...normalizeStringList(row.addWorksets),
      ...normalizeExactNameList(row.ownership3DViewNames),
      ...normalizeExactNameList(row.owned3DViewNames),
      ...normalizeExactNameList(row.ownershipViewTemplateNames),
      ...normalizeExactNameList(row.ownedViewTemplateNames),
      ...normalizeExactNameList(row.ownedLevelGridWorksetNames)
    ].filter(Boolean).join(' ').toLocaleLowerCase();
    if (query && !searchable.includes(query)) return false;
    const issues = validateCentralRow(row, mode);
    switch (state.fileFilter) {
      case 'apply': return !isSkippedRow(row);
      case 'skip': return isSkippedRow(row);
      case 'issue': return !isSkippedRow(row) && issues.length > 0;
      case 'ready': return !isSkippedRow(row) && !isErrorStatus(row.status) && issues.length === 0;
      case 'failed': return isErrorStatus(row.status);
      default: return true;
    }
  });
}

function updateDetachedMaster(state, nav) {
  const master = nav?.querySelector('[data-apply-master]');
  const input = master?.querySelector('input');
  const copy = master?.querySelector('span');
  if (!input || !copy) return;
  const visibleRows = getFilteredRows(state);
  const visibleApplyCount = visibleRows.filter((row) => !isSkippedRow(row)).length;
  input.checked = visibleRows.length > 0 && visibleApplyCount === visibleRows.length;
  input.indeterminate = visibleApplyCount > 0 && visibleApplyCount < visibleRows.length;
  input.disabled = state.busy || !visibleRows.length;
  const scoped = state.fileFilter !== 'all' || !!state.fileSearch.trim();
  copy.textContent = scoped
    ? ` 현재 표시 ${visibleRows.length}개 실행 포함`
    : ` 등록 전체 ${visibleRows.length}개 실행 포함`;
  master.title = scoped
    ? '현재 검색·필터에 보이는 파일만 변경합니다.'
    : '등록된 모든 파일을 변경합니다.';
}

function fillDetachedFileList(state, list, filteredRows = null) {
  clear(list);
  const mode = currentOperationMode(state);
  const filtered = filteredRows || getFilteredRows(state);

  if (!filtered.length) {
    list.append(buildEmptyState(state.rows.length ? '검색 결과가 없습니다.' : '등록된 RVT가 없습니다.', state.rows.length
      ? '검색어나 상태 필터를 바꿔 보세요.'
      : '상단에서 RVT 파일을 여러 개 추가하세요.'));
    return;
  }

  filtered.forEach((row) => list.append(buildDetachedFileItem(state, row, mode)));
}

function buildDetachedFileItem(state, row, mode) {
  const item = div('centralworkset-file-item');
  item.classList.toggle('is-selected', row.rowId === state.selectedRowId);
  item.classList.toggle('is-skipped', isSkippedRow(row));
  const issues = validateCentralRow(row, mode);
  const warnings = collectCentralRowWarnings(row, mode);
  if ((issues.length || warnings.length) && !isSkippedRow(row)) item.classList.add('has-warning');

  const include = document.createElement('input');
  include.type = 'checkbox';
  setCentralWorksetFocusKey(include, `row:${row.rowId}:navigator-include`);
  include.checked = !isSkippedRow(row);
  include.disabled = state.busy;
  include.title = include.checked ? '이 파일은 실행에 포함됩니다.' : '이 파일은 실행에서 제외됩니다.';
  include.addEventListener('click', (event) => event.stopPropagation());
  include.addEventListener('change', () => {
    invalidateOwnershipWorkbookTrust(row);
    row.action = include.checked ? 'APPLY' : 'SKIP';
    scheduleDraftBroadcast(state);
    renderWorkspace(state);
    renderRunPanel(state);
  });

  const select = document.createElement('button');
  select.type = 'button';
  select.className = 'centralworkset-file-select';
  setCentralWorksetFocusKey(select, `row:${row.rowId}:select`);
  const displayName = row.sourceFileName || fileName(row.sourcePath) || 'RVT';
  const sourcePath = row.sourcePath || '경로 없음';
  const statusText = isSkippedRow(row)
    ? '실행 제외'
    : (issues[0] || warnings[0] || (row.message || '실행 준비'));
  const ownershipMeta = mode !== 'worksets' && row.retain3DViewOwnership
    ? ` · 3D 뷰 권한 ${row.ownership3DViewNames.length}개`
    : '';
  const viewTemplateOwnershipMeta = mode !== 'worksets' && row.retainViewTemplateOwnership
    ? ` · 3D 템플릿 ViewWorkset ${row.ownershipViewTemplateNames.length}개`
    : '';
  const levelGridRequested = isUnifiedLevelGridOwnershipRequested(row);
  const levelGridMeta = mode !== 'worksets' && levelGridRequested
    ? ` · Grid/Level Pin + ${LEVEL_GRID_OWNERSHIP_WORKSET_NAME} 권한${hasVerifiedLevelGridOwnershipResult(row) ? ` 검증 ${row.ownedLevelGridCount}개` : ''}`
    : '';
  const sourceKey = normalizePathKey(row.sourcePath);
  const repeatedSource = !!sourceKey && state.rows.filter((candidate) => normalizePathKey(candidate.sourcePath) === sourceKey).length > 1;
  const outputPath = String(row.outputCentralPath || '').trim();
  const outputMeta = repeatedSource ? ` · 출력 ${fileName(outputPath) || '미지정'}` : '';
  select.innerHTML = `
    <strong title="${escapeHtml(displayName)}">${escapeHtml(displayName)}</strong>
    <small class="centralworkset-file-path" title="${escapeHtml(sourcePath)}">${escapeHtml(sourcePath)}</small>
    <span class="centralworkset-file-meta"${outputPath ? ` title="${escapeHtml(outputPath)}"` : ''}>${escapeHtml(typeBadgeLabel(row))} · 기존 웍셋 ${row.existingWorksets.length}개 · 추가 ${analyzeRequestedWorksets(row).newNames.length}개${escapeHtml(ownershipMeta)}${escapeHtml(viewTemplateOwnershipMeta)}${escapeHtml(levelGridMeta)}${escapeHtml(outputMeta)}</span>
    <small class="centralworkset-file-status" title="${escapeHtml(statusText)}">${escapeHtml(statusText)}</small>`;
  select.addEventListener('click', () => {
    state.selectedRowId = row.rowId;
    scheduleDraftBroadcast(state);
    renderWorkspace(state);
  });

  const remove = document.createElement('button');
  remove.type = 'button';
  remove.className = 'centralworkset-file-remove';
  setCentralWorksetFocusKey(remove, `row:${row.rowId}:remove`);
  remove.textContent = '×';
  remove.title = '목록에서 제거';
  remove.disabled = state.busy;
  remove.addEventListener('click', () => {
    if (!window.confirm(`${row.sourceFileName || '선택 파일'}을 목록에서 제거할까요? 원본 파일은 삭제되지 않습니다.`)) return;
    state.rows = state.rows.filter((candidate) => candidate.rowId !== row.rowId);
    ensureSelectedRow(state);
    scheduleDraftBroadcast(state);
    renderWorkspace(state);
    renderRunPanel(state);
  });

  item.append(include, select, remove);
  return item;
}

function buildDetachedFileDetail(state) {
  const detail = div('centralworkset-file-detail');
  const row = state.rows.find((candidate) => candidate.rowId === state.selectedRowId) || null;
  if (!row) {
    detail.append(buildEmptyState('상세 설정할 파일이 없습니다.', '왼쪽에서 RVT를 등록하거나 검색 결과의 파일을 선택하세요.'));
    return detail;
  }

  const mode = currentOperationMode(state);
  const rowMode = mode === 'centralize' ? automaticModeForRow(row) : mode;
  const issues = validateCentralRow(row, mode);
  const warnings = collectCentralRowWarnings(row, mode);
  const head = div('centralworkset-detail-head');
  const title = document.createElement('div');
  const displayName = row.sourceFileName || fileName(row.sourcePath) || 'RVT';
  title.innerHTML = `
    <span>SELECTED RVT</span>
    <h3 title="${escapeHtml(displayName)}">${escapeHtml(displayName)}</h3>
    <p title="${escapeHtml(row.sourcePath)}">${escapeHtml(row.sourcePath || '경로 없음')}</p>`;
  const include = document.createElement('label');
  include.className = 'centralworkset-detail-apply';
  const includeInput = document.createElement('input');
  includeInput.type = 'checkbox';
  setCentralWorksetFocusKey(includeInput, `row:${row.rowId}:detail-include`);
  includeInput.checked = !isSkippedRow(row);
  includeInput.disabled = state.busy;
  includeInput.addEventListener('change', () => {
    invalidateOwnershipWorkbookTrust(row);
    row.action = includeInput.checked ? 'APPLY' : 'SKIP';
    scheduleDraftBroadcast(state);
    renderWorkspace(state);
    renderRunPanel(state);
  });
  include.append(includeInput, document.createTextNode(' 이 파일 실행 포함'));
  head.append(title, include);

  const facts = div('centralworkset-detail-facts');
  facts.append(
    detailFact('파일 종류', typeBadgeLabel(row)),
    detailFact('Revit 버전', row.format || '-'),
    detailFact('연결 센트럴', row.missingConnectedCentral
      ? (rowMode === 'all' ? '연결 확인 실패 · 등록한 로컬/복사본 자체를 웍셋 유지 디태치' : '연결 확인 실패 · 실행 불가')
      : (row.centralPath || (row.isCentral ? row.sourcePath : '-'))),
    detailFact('처리 상태', row.requiresManualVerification
      ? '수동 확인 필요'
      : (row.message || statusLabel(row.status) || '설정 중'))
  );

  const content = setCentralWorksetScrollKey(
    div('centralworkset-detail-content'),
    `row:${row.rowId}:mode:${mode}:detail`
  );
  if (isCreateMode(mode)) content.append(buildDetachedOutputEditor(state, row, mode));
  else content.append(buildDetachedWorksetTarget(row, mode));
  if (mode !== 'worksets') content.append(buildDetached3DViewOwnershipEditor(state, row, mode));
  content.append(buildDetachedExistingWorksets(row));
  if (mode !== 'ownership') content.append(buildDetachedWorksetEditor(state, row));

  const status = div(`centralworkset-detail-status${(issues.length || warnings.length) && !isSkippedRow(row) ? ' has-warning' : ''}`);
  if (isSkippedRow(row)) {
    status.innerHTML = '<strong>실행 제외</strong><span>설정은 유지되지만 이번 작업에서는 처리하지 않습니다.</span>';
  } else if (row.requiresManualVerification) {
    status.innerHTML = `<strong>수동 확인 필요</strong><span>${escapeHtml(row.message || '저장 여부를 자동으로 확인하지 못했습니다. 대상 RVT를 직접 확인한 뒤 새 목록으로 다시 등록하세요.')}</span>`;
  } else if (issues.length) {
    status.innerHTML = `<strong>확인 필요</strong><span>${escapeHtml(issues.join(' · '))}</span>`;
  } else if (warnings.length) {
    status.innerHTML = `<strong>경고 · 실행 가능</strong><span>${escapeHtml(warnings.join(' · '))}</span>`;
  } else {
    status.innerHTML = '<strong>실행 준비</strong><span>경로와 파일 상태가 현재 화면 기준으로 준비되었습니다.</span>';
  }

  detail.append(head, facts, content, status);
  return detail;
}

function buildDetachedOutputEditor(state, row, mode = 'centralize') {
  const section = div('centralworkset-detail-section centralworkset-detail-section--output');
  const header = document.createElement('div');
  header.innerHTML = '<span>출력 경로</span><h4>센트럴 저장 경로 (선택)</h4><p>입력하면 새 센트럴을 만들고, 비우면 등록한 기존 센트럴 또는 로컬의 연결 센트럴에 아래 권한만 적용합니다.</p>';
  const line = div('centralworkset-input-line');
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'centralworkset-path-input';
  setCentralWorksetFocusKey(input, `row:${row.rowId}:output-path`);
  input.value = row.outputCentralPath || '';
  input.placeholder = '새 센트럴을 만들 때만 입력 · 예: D:\\Central\\Project_A.rvt';
  input.disabled = state.busy || isSkippedRow(row);
  const issue = div('centralworkset-row-issue');
  const syncIssue = () => {
    const issues = validateCentralRow(row, mode);
    issue.textContent = issues[0] || outputPathHint(row);
    issue.classList.toggle('is-warning', !!issues.length);
  };
  input.addEventListener('input', () => {
    invalidateOwnershipWorkbookTrust(row);
    row.outputCentralPath = input.value.trim();
    row.owned3DViewNames = [];
    row.ownedViewTemplateNames = [];
    row.ownedLevelGridCount = 0;
    row.ownedLevelGridWorksetNames = [];
    state.overwriteExisting = false;
    syncIssue();
    scheduleDraftBroadcast(state);
    scheduleDetachedNavigatorRefresh(state);
    renderRunPanel(state);
  });
  const browse = actionButton('경로 선택', () => requestRowOutput(state, row), 'secondary');
  browse.disabled = state.busy || isSkippedRow(row);
  line.append(input, browse);
  syncIssue();
  section.append(header, line, issue);
  return section;
}

function buildDetached3DViewOwnershipEditor(state, row, mode = 'centralize') {
  const section = div('centralworkset-detail-section centralworkset-detail-section--ownership');
  const header = document.createElement('div');
  header.innerHTML = '<span>권한 설정</span><h4>Grid/Level · 3D 뷰 · 3D 뷰 템플릿 권한</h4><p>센트럴 저장 경로가 있든 비어 있든 같은 옵션을 사용합니다. 새 센트럴은 저장 후, 빈 경로는 기존·연결 센트럴에 적용합니다.</p>';

  const toggle = document.createElement('label');
  toggle.className = 'centralworkset-ownership-toggle';
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  setCentralWorksetFocusKey(checkbox, `row:${row.rowId}:retain-3d-view`);
  checkbox.checked = !!row.retain3DViewOwnership;
  checkbox.disabled = state.busy || isSkippedRow(row);
  const toggleCopy = document.createElement('span');
  toggleCopy.innerHTML = '<strong>지정 3D 뷰만 현재 사용자 소유로 유지</strong><small>끄면 3D 뷰 권한은 다시 확보하지 않습니다. 3D 뷰 템플릿과 Level/Grid 옵션은 각각 별도로 적용됩니다.</small>';
  toggle.append(checkbox, toggleCopy);

  const editor = div('centralworkset-ownership-editor');
  const inputLabel = document.createElement('label');
  inputLabel.textContent = '3D 뷰 이름 · 한 줄에 하나 · 대소문자/공백까지 정확히 일치';
  const input = document.createElement('textarea');
  input.className = 'centralworkset-workset-textarea centralworkset-ownership-textarea';
  setCentralWorksetFocusKey(input, `row:${row.rowId}:ownership-3d-view-names`);
  input.rows = 4;
  input.placeholder = '{3D}\nCoordination 3D\nMEP 3D';
  input.value = row.ownership3DViewNames.join('\n');
  const feedback = div('centralworkset-ownership-feedback');

  const sync = () => {
    editor.hidden = !row.retain3DViewOwnership;
    input.disabled = state.busy || isSkippedRow(row) || !row.retain3DViewOwnership;
    clear(feedback);
    if (!row.retain3DViewOwnership) return;

    const requested = normalizeExactNameList(row.ownership3DViewNames);
    const validation = validate3DViewOwnership(row, mode);
    const count = document.createElement('div');
    count.className = `centralworkset-ownership-count${validation.length ? ' has-warning' : ''}`;
    count.textContent = validation[0] || `권한 확보 요청 ${requested.length}개 · 이름은 정확히 일치하는 비템플릿 View3D만 처리합니다.`;
    feedback.append(count);
    if (requested.length) feedback.append(buildNameGroup('권한 확보 요청', requested, 'ownership'));
    if (row.owned3DViewNames.length) feedback.append(buildNameGroup('권한 확보 확인', row.owned3DViewNames, 'owned'));
  };

  checkbox.addEventListener('change', () => {
    invalidateOwnershipWorkbookTrust(row);
    row.retain3DViewOwnership = checkbox.checked;
    row.owned3DViewNames = [];
    row.ownedViewTemplateNames = [];
    row.ownedLevelGridCount = 0;
    row.ownedLevelGridWorksetNames = [];
    sync();
    scheduleDraftBroadcast(state);
    scheduleDetachedNavigatorRefresh(state);
    renderRunPanel(state);
  });
  input.addEventListener('input', () => {
    invalidateOwnershipWorkbookTrust(row);
    row.ownership3DViewNames = parseExactLineNames(input.value);
    row.owned3DViewNames = [];
    row.ownedViewTemplateNames = [];
    row.ownedLevelGridCount = 0;
    row.ownedLevelGridWorksetNames = [];
    sync();
    scheduleDraftBroadcast(state);
    scheduleDetachedNavigatorRefresh(state);
    renderRunPanel(state);
  });

  const viewTemplateToggle = document.createElement('label');
  viewTemplateToggle.className = 'centralworkset-ownership-toggle centralworkset-ownership-toggle--view-template';
  const viewTemplateCheckbox = document.createElement('input');
  viewTemplateCheckbox.type = 'checkbox';
  setCentralWorksetFocusKey(viewTemplateCheckbox, `row:${row.rowId}:retain-view-template`);
  viewTemplateCheckbox.checked = !!row.retainViewTemplateOwnership;
  viewTemplateCheckbox.disabled = state.busy || isSkippedRow(row);
  const viewTemplateCopy = document.createElement('span');
  viewTemplateCopy.innerHTML = '<strong>지정 3D 뷰 템플릿의 ViewWorkset을 현재 사용자 소유·편집 가능으로 유지</strong><small>이름이 정확히 일치하는 View3D 템플릿의 primary ViewWorkset을 소유하고, 새 로컬에서 Owner=현재 사용자·Editable=Yes를 확인합니다. Revit이 강제하는 같은 ViewWorkset 및 필수 pair·Sun/Shadow·내부 closure의 추가 ViewWorkset이 함께 소유될 수 있습니다. 해당 ViewWorkset/closure에 비대상 View 또는 3D 템플릿이 포함되면 안전을 위해 실행을 차단합니다. 평면·단면·스케줄 템플릿, 공유 필터, Project Standards 정의는 별도 대상이 아닙니다.</small>';
  viewTemplateToggle.append(viewTemplateCheckbox, viewTemplateCopy);

  const viewTemplateEditor = div('centralworkset-ownership-editor centralworkset-view-template-editor');
  const viewTemplateInputLabel = document.createElement('label');
  viewTemplateInputLabel.textContent = '3D 뷰 템플릿 이름 · 한 줄에 하나 · 대소문자/공백까지 정확히 일치';
  const viewTemplateInput = document.createElement('textarea');
  viewTemplateInput.className = 'centralworkset-workset-textarea centralworkset-ownership-textarea';
  setCentralWorksetFocusKey(viewTemplateInput, `row:${row.rowId}:ownership-view-template-names`);
  viewTemplateInput.rows = 4;
  viewTemplateInput.placeholder = 'Coordination 3D Template\nIssue 3D Template\nNavisworks 3D Template';
  viewTemplateInput.value = row.ownershipViewTemplateNames.join('\n');
  const viewTemplateFeedback = div('centralworkset-ownership-feedback');

  const syncViewTemplate = () => {
    viewTemplateEditor.hidden = !row.retainViewTemplateOwnership;
    viewTemplateInput.disabled = state.busy || isSkippedRow(row) || !row.retainViewTemplateOwnership;
    clear(viewTemplateFeedback);
    if (!row.retainViewTemplateOwnership) return;

    const requested = normalizeExactNameList(row.ownershipViewTemplateNames);
    const validation = validateViewTemplateOwnership(row, mode);
    const count = document.createElement('div');
    count.className = `centralworkset-ownership-count${validation.length ? ' has-warning' : ''}`;
    count.textContent = validation[0] || `ViewWorkset 소유·편집 요청 ${requested.length}개 · 새 로컬에서 Owner=현재 사용자·Editable=Yes를 검증합니다.`;
    viewTemplateFeedback.append(count);
    if (requested.length) viewTemplateFeedback.append(buildNameGroup('3D 뷰 템플릿 ViewWorkset 소유·편집 요청', requested, 'ownership'));
    if (row.ownedViewTemplateNames.length) viewTemplateFeedback.append(buildNameGroup('Owner=현재 사용자 · Editable=Yes 검증', row.ownedViewTemplateNames, 'owned'));
  };

  viewTemplateCheckbox.addEventListener('change', () => {
    invalidateOwnershipWorkbookTrust(row);
    row.retainViewTemplateOwnership = viewTemplateCheckbox.checked;
    row.owned3DViewNames = [];
    row.ownedViewTemplateNames = [];
    row.ownedLevelGridCount = 0;
    row.ownedLevelGridWorksetNames = [];
    syncViewTemplate();
    scheduleDraftBroadcast(state);
    scheduleDetachedNavigatorRefresh(state);
    renderRunPanel(state);
  });
  viewTemplateInput.addEventListener('input', () => {
    invalidateOwnershipWorkbookTrust(row);
    row.ownershipViewTemplateNames = parseExactLineNames(viewTemplateInput.value);
    row.owned3DViewNames = [];
    row.ownedViewTemplateNames = [];
    row.ownedLevelGridCount = 0;
    row.ownedLevelGridWorksetNames = [];
    syncViewTemplate();
    scheduleDraftBroadcast(state);
    scheduleDetachedNavigatorRefresh(state);
    renderRunPanel(state);
  });

  const levelGridToggle = document.createElement('label');
  levelGridToggle.className = 'centralworkset-ownership-toggle centralworkset-ownership-toggle--level-grid';
  const levelGridCheckbox = document.createElement('input');
  levelGridCheckbox.type = 'checkbox';
  setCentralWorksetFocusKey(levelGridCheckbox, `row:${row.rowId}:retain-level-grid-workset`);
  levelGridCheckbox.checked = isUnifiedLevelGridOwnershipRequested(row);
  levelGridCheckbox.indeterminate = !!row.retainLevelGridWorksetOwnership && !row.pinLevelGridElements && !row.pinAndRetainLevelGridOwnership;
  levelGridCheckbox.disabled = state.busy || isSkippedRow(row);
  const levelGridCopy = document.createElement('span');
  levelGridCopy.innerHTML = '<strong>Grid/Level 핀 + Shared Levels and Grids 웍셋 권한</strong><small>본문 Grid/Level을 Pin하고 exact-name Shared Levels and Grids UserWorkset을 현재 사용자 Owner/Editable 상태로 유지합니다. 링크 모델은 제외합니다. 같은 Workset의 다른 요소도 다른 사용자가 수정하지 못할 수 있습니다.</small>';
  levelGridToggle.append(levelGridCheckbox, levelGridCopy);

  const pinLevelGridToggle = document.createElement('label');
  pinLevelGridToggle.className = 'centralworkset-ownership-toggle centralworkset-ownership-toggle--pin-elements';
  const pinLevelGridCheckbox = document.createElement('input');
  pinLevelGridCheckbox.type = 'checkbox';
  setCentralWorksetFocusKey(pinLevelGridCheckbox, `row:${row.rowId}:pin-level-grid-elements`);
  pinLevelGridCheckbox.checked = !!row.pinLevelGridElements;
  const pinLevelGridCopy = document.createElement('span');
  pinLevelGridCopy.innerHTML = '<strong>본문 Level/Grid 요소도 Pin</strong><small>Workset 권한 유지와 함께만 사용할 수 있습니다. 링크 모델의 Level/Grid는 제외합니다.</small>';
  pinLevelGridToggle.append(pinLevelGridCheckbox, pinLevelGridCopy);
  pinLevelGridToggle.hidden = true;

  const levelGridFeedback = div('centralworkset-ownership-count centralworkset-level-grid-feedback');
  const syncLevelGrid = () => {
    const verifiedResult = hasVerifiedLevelGridOwnershipResult(row);
    clear(levelGridFeedback);
    const requested = isUnifiedLevelGridOwnershipRequested(row);
    pinLevelGridCheckbox.disabled = true;
    pinLevelGridToggle.classList.toggle('is-disabled', pinLevelGridCheckbox.disabled);
    if (!requested) {
      levelGridFeedback.hidden = true;
      return;
    }
    levelGridFeedback.hidden = false;
    const resultCopy = document.createElement('div');
    resultCopy.textContent = verifiedResult
      ? `직전 실행 검증: Level/Grid Pin ${row.ownedLevelGridCount}개 · ${LEVEL_GRID_OWNERSHIP_WORKSET_NAME} Owner=현재 사용자·Editable=Yes`
      : (row.retainLevelGridWorksetOwnership && !row.pinLevelGridElements && !row.pinAndRetainLevelGridOwnership
        ? `기존 1.9 양식 설정: ${LEVEL_GRID_OWNERSHIP_WORKSET_NAME} 웍셋 권한만 유지하고 Grid/Level Pin은 변경하지 않습니다.`
        : `실행 시 본문 Grid/Level을 Pin하고 exact-name ${LEVEL_GRID_OWNERSHIP_WORKSET_NAME} UserWorkset을 Owner=현재 사용자·Editable=Yes로 유지한 뒤 새 로컬에서 검증합니다.`);
    levelGridFeedback.append(resultCopy);
    if (verifiedResult) {
      levelGridFeedback.append(buildNameGroup('Owner=현재 사용자 · Editable=Yes 검증 Workset', row.ownedLevelGridWorksetNames, 'owned'));
    }
  };
  levelGridCheckbox.addEventListener('change', () => {
    invalidateOwnershipWorkbookTrust(row);
    row.pinAndRetainLevelGridOwnership = levelGridCheckbox.checked;
    row.retainLevelGridWorksetOwnership = false;
    row.pinLevelGridElements = false;
    levelGridCheckbox.indeterminate = false;
    row.ownedViewTemplateNames = [];
    row.ownedLevelGridCount = 0;
    row.ownedLevelGridWorksetNames = [];
    syncLevelGrid();
    scheduleDraftBroadcast(state);
    scheduleDetachedNavigatorRefresh(state);
    renderRunPanel(state);
  });
  pinLevelGridCheckbox.addEventListener('change', () => {
    invalidateOwnershipWorkbookTrust(row);
    row.pinLevelGridElements = row.retainLevelGridWorksetOwnership && pinLevelGridCheckbox.checked;
    row.ownedLevelGridCount = 0;
    row.ownedLevelGridWorksetNames = [];
    syncLevelGrid();
    scheduleDraftBroadcast(state);
    scheduleDetachedNavigatorRefresh(state);
    renderRunPanel(state);
  });

  editor.append(inputLabel, input, feedback);
  viewTemplateEditor.append(viewTemplateInputLabel, viewTemplateInput, viewTemplateFeedback);
  section.append(header, toggle, editor, viewTemplateToggle, viewTemplateEditor, levelGridToggle, levelGridFeedback);
  sync();
  syncViewTemplate();
  syncLevelGrid();
  return section;
}

function buildDetachedWorksetTarget(row, mode = 'worksets') {
  const section = div('centralworkset-detail-section centralworkset-detail-section--output');
  const ownershipOnly = mode === 'ownership';
  const target = ownershipOnly
    ? effectiveOwnershipTarget(row)
    : effectiveWorksetTarget(row, true);
  const targetDisplay = row.missingConnectedCentral
    ? (target ? `${target} · 센트럴 연결 확인 실패` : '연결 센트럴을 확인하지 못함')
    : (target || '연결 센트럴 경로 없음');
  section.innerHTML = `
    <div><span>STEP 2-A</span><h4>${ownershipOnly ? '권한 적용 대상 센트럴' : '웍셋 적용 대상 센트럴'}</h4><p>${escapeHtml(row.missingConnectedCentral
      ? (row.message || '연결된 센트럴을 확인하지 못해 실행할 수 없습니다. 등록한 RVT의 센트럴 연결을 확인한 뒤 파일 정보를 다시 읽으세요.')
      : (ownershipOnly
        ? '아래 경로는 화면 힌트입니다. 실행 시 Service가 SourceRvtPath를 다시 검사해 실제 기존·연결 센트럴을 확정하며 OutputCentralPath는 비워 둡니다.'
        : '새 파일을 만들지 않고 아래 기존 센트럴에만 웍셋을 추가합니다.'))}</p></div>
    <strong class="centralworkset-target-path${row.missingConnectedCentral ? ' is-missing' : ''}" title="${escapeHtml(targetDisplay)}">${escapeHtml(targetDisplay)}</strong>`;
  return section;
}

function buildDetachedExistingWorksets(row) {
  const section = div('centralworkset-detail-section centralworkset-detail-section--existing');
  const header = document.createElement('div');
  header.innerHTML = `<span>CURRENT</span><h4>현재 사용자 웍셋 ${row.existingWorksets.length}개</h4><p>선택한 RVT 한 개의 웍셋만 표시합니다.</p>`;
  const search = document.createElement('input');
  search.type = 'search';
  search.className = 'centralworkset-workset-search';
  setCentralWorksetFocusKey(search, `row:${row.rowId}:existing-workset-search`);
  search.placeholder = '현재 웍셋 검색';
  const list = setCentralWorksetScrollKey(
    div('centralworkset-existing-list'),
    `row:${row.rowId}:existing-worksets`
  );
  const fill = () => {
    clear(list);
    const query = search.value.trim().toLocaleLowerCase();
    const names = row.existingWorksets.filter((name) => !query || name.toLocaleLowerCase().includes(query));
    if (!names.length) {
      const empty = document.createElement('span');
      empty.className = 'centralworkset-muted';
      empty.textContent = row.existingWorksets.length
        ? '검색 결과가 없습니다.'
        : isUnknownSourceType(row)
          ? 'RVT 유형과 웍셋은 실행 시 Detach(Preserve)로 연 뒤 다시 판정합니다.'
          : row.isWorkshared
            ? '확인된 사용자 웍셋이 없습니다.'
            : '일반 RVT는 아직 사용자 웍셋이 없습니다.';
      list.append(empty);
      return;
    }
    names.forEach((name, index) => {
      const item = document.createElement('div');
      item.innerHTML = `<span>${index + 1}</span><strong title="${escapeHtml(name)}">${escapeHtml(name)}</strong>`;
      list.append(item);
    });
  };
  search.addEventListener('input', fill);
  fill();
  section.append(header, search, list);
  return section;
}

function buildDetachedWorksetEditor(state, row) {
  const section = div('centralworkset-detail-section centralworkset-detail-section--add');
  const header = document.createElement('div');
  header.innerHTML = '<span>STEP 2-B</span><h4>추가할 사용자 웍셋</h4><p>완전히 같은 이름만 자동으로 건너뜁니다. 대소문자가 다르면 다른 이름으로 처리하며, 입력 개수 제한은 없습니다.</p>';
  const input = document.createElement('textarea');
  input.className = 'centralworkset-workset-textarea';
  setCentralWorksetFocusKey(input, `row:${row.rowId}:add-worksets`);
  input.rows = 4;
  input.placeholder = 'A-건축\nS-구조\nM-기계';
  input.value = row.addWorksets.join('\n');
  input.disabled = state.busy || isSkippedRow(row);
  const preview = div('centralworkset-workset-analysis');
  const fillPreview = () => {
    clear(preview);
    const analysis = analyzeRequestedWorksets(row);
    const stats = div('centralworkset-workset-analysis-stats');
    stats.append(
      stat('입력', `${analysis.requested.length}개`),
      stat('신규', `${analysis.newNames.length}개`),
      stat('기존 중복', `${analysis.duplicates.length}개`)
    );
    preview.append(stats);
    if (analysis.newNames.length) preview.append(buildNameGroup('새로 생성', analysis.newNames, 'new'));
    if (analysis.duplicates.length) preview.append(buildNameGroup('자동 건너뜀', analysis.duplicates, 'duplicate'));
    const nameIssues = validateWorksetNameList(analysis.requested);
    if (nameIssues.length) {
      const warning = div('centralworkset-workset-validation');
      warning.textContent = nameIssues.join(' · ');
      preview.append(warning);
    }
  };
  input.addEventListener('input', () => {
    invalidateOwnershipWorkbookTrust(row);
    row.addWorksets = parseWorksets(input.value);
    row.owned3DViewNames = [];
    row.ownedViewTemplateNames = [];
    row.ownedLevelGridCount = 0;
    row.ownedLevelGridWorksetNames = [];
    fillPreview();
    scheduleDraftBroadcast(state);
    scheduleDetachedNavigatorRefresh(state);
    renderRunPanel(state);
  });
  fillPreview();
  section.append(header, input, preview);
  return section;
}

function buildNameGroup(label, names, tone) {
  const group = div(`centralworkset-name-group centralworkset-name-group--${tone}`);
  const title = document.createElement('strong');
  title.textContent = label;
  const list = div('centralworkset-name-group-list');
  names.forEach((name) => {
    const item = document.createElement('span');
    item.textContent = name;
    list.append(item);
  });
  group.append(title, list);
  return group;
}

function detailFact(label, value) {
  const item = div('centralworkset-detail-fact');
  const caption = document.createElement('span');
  caption.textContent = label;
  const text = document.createElement('strong');
  text.textContent = value || '-';
  text.title = value || '-';
  item.append(caption, text);
  return item;
}

function typeBadgeLabel(row) {
  if (String(row?.sourceType || '').toLowerCase() === 'pending') return '확인 중';
  if (isUnknownSourceType(row)) return '유형 확인 필요';
  if (row?.isCentral) return '센트럴';
  if (row?.isLocal) return '로컬';
  if (row?.isWorkshared) return 'Workshared';
  return '일반 RVT';
}

function renderRunPanel(state) {
  const host = state.ui.runPanel;
  if (!host) return;
  const interaction = beginCentralWorksetInteractionRender(state);
  clear(host);

  const mode = currentOperationMode(state);
  const worksetsOnly = mode === 'worksets';
  const automaticBatch = worksetsOnly ? { mode: 'worksets', issue: '' } : resolveAutomaticBatchMode(state.rows);
  const resolvedMode = automaticBatch.mode || 'centralize';
  const ownershipOnly = !worksetsOnly && resolvedMode === 'ownership';
  const summary = summarizeRows(state.rows, resolvedMode);
  const worksetSummary = summarizeRows(state.rows, 'worksets');
  const centralIssues = collectCentralValidationIssues(state.rows, 'centralize');
  const worksetIssues = collectCentralValidationIssues(state.rows, 'worksets');
  const ownershipIssues = collectCentralValidationIssues(state.rows, 'ownership');
  const currentConfiguredIssues = worksetsOnly ? worksetIssues : centralIssues;
  const heading = div('centralworkset-run-heading');
  heading.innerHTML = worksetsOnly
    ? '<span>검증·실행</span><h3>기존 센트럴 웍셋 추가</h3><p>기존 센트럴 파일에 새 사용자 웍셋만 추가합니다.</p>'
    : '<span>검증·실행</span><h3>설정대로 자동 실행</h3><p>센트럴 저장 경로가 있으면 새 센트럴을 만들고, 비어 있으면 기존 센트럴에 선택한 권한만 적용합니다.</p>';

  const stats = div('centralworkset-run-stats');
  if (ownershipOnly) {
    stats.append(
      stat('실행 RVT', `${summary.applyRowCount}개${summary.skippedRowCount ? ` · 제외 ${summary.skippedRowCount}` : ''}`),
      stat('센트럴 대상', `${summary.outputReadyCount}/${summary.applyRowCount}`),
      stat('3D 뷰 권한', `${summary.ownershipViewCount}개 · ${summary.ownershipRowCount}파일`),
      stat('3D 템플릿 ViewWorkset', `${summary.viewTemplateOwnershipCount}개 · ${summary.viewTemplateOwnershipRowCount}파일`),
      stat('Level/Grid Workset', `${summary.levelGridOwnershipRowCount}파일`)
    );
  } else if (worksetsOnly) {
    stats.append(
      stat('실행 RVT', `${worksetSummary.applyRowCount}개${worksetSummary.skippedRowCount ? ` · 제외 ${worksetSummary.skippedRowCount}` : ''}`),
      stat('센트럴 대상', `${worksetSummary.outputReadyCount}/${worksetSummary.applyRowCount}`),
      stat('신규 웍셋', `${worksetSummary.newWorksetCount}개`),
      stat('중복 건너뜀', `${worksetSummary.duplicateWorksetCount}개`)
    );
  } else {
    stats.append(
      stat('실행 RVT', `${summary.applyRowCount}개${summary.skippedRowCount ? ` · 제외 ${summary.skippedRowCount}` : ''}`),
      stat('준비 상태', `${summary.outputReadyCount}/${summary.applyRowCount}`),
      stat('신규 웍셋', `${worksetSummary.newWorksetCount}개`),
      stat('3D 뷰 권한', `${summary.ownershipViewCount}개 · ${summary.ownershipRowCount}파일`),
      stat('3D 템플릿 ViewWorkset', `${summary.viewTemplateOwnershipCount}개 · ${summary.viewTemplateOwnershipRowCount}파일`),
      stat('레벨·그리드 Pin/Workset', `${summary.levelGridOwnershipRowCount}파일 · Pin ${summary.ownedLevelGridCount}개 · Workset ${summary.ownedLevelGridWorksetCount}개`)
    );
  }

  const readiness = div('centralworkset-readiness');
  if (ownershipOnly) {
    readiness.append(
      readinessRow('파일 등록', summary.applyRowCount > 0, summary.applyRowCount ? `${summary.applyRowCount}개 실행 포함` : '실행 포함 대상 없음'),
      readinessRow('기존 센트럴', summary.applyRowCount > 0 && ownershipIssues.length === 0,
        !summary.applyRowCount ? '실행 포함 대상 없음' : (ownershipIssues.length ? `${ownershipIssues.length}건 확인 필요` : '화면 입력 검증 통과')),
      readinessRow('권한 요청', hasOwnershipRequest(state.rows), hasOwnershipRequest(state.rows) ? '하나 이상 선택됨' : '권한 옵션 없음')
    );
  } else if (worksetsOnly) {
    readiness.append(
      readinessRow('파일 등록', worksetSummary.applyRowCount > 0, worksetSummary.applyRowCount ? `${worksetSummary.applyRowCount}개 실행 포함` : '실행 포함 대상 없음'),
      readinessRow('센트럴 대상', worksetSummary.applyRowCount > 0 && worksetIssues.length === 0,
        !worksetSummary.applyRowCount ? '실행 포함 대상 없음' : (worksetIssues.length ? `${worksetIssues.length}건 확인 필요` : '화면 입력 검증 통과')),
      readinessRow('웍셋 입력', worksetSummary.newWorksetCount > 0, worksetSummary.newWorksetCount ? `${worksetSummary.newWorksetCount}개 신규` : '추가할 이름 없음')
    );
  } else {
    readiness.append(
      readinessRow('파일 등록', summary.applyRowCount > 0, summary.applyRowCount ? `${summary.applyRowCount}개 실행 포함` : '실행 포함 대상 없음'),
      readinessRow('경로 자동 판단', summary.applyRowCount > 0 && currentConfiguredIssues.length === 0,
        !summary.applyRowCount ? '실행 포함 대상 없음' : (currentConfiguredIssues.length ? `${currentConfiguredIssues.length}건 확인 필요` : '화면 입력 검증 통과')),
      readinessRow('웍셋 입력', worksetSummary.newWorksetCount > 0, worksetSummary.newWorksetCount ? `${worksetSummary.newWorksetCount}개 신규` : '선택 사항')
    );
  }

  const overwrite = (worksetsOnly || resolvedMode !== 'all') ? null : buildOverwriteControl(state);

  const buttons = div('centralworkset-run-buttons');
  if (worksetsOnly) {
    const worksets = actionButton('웍셋 추가 실행', () => runMode(state, 'worksets'), 'primary strong');
    worksets.disabled = state.busy || !worksetSummary.applyRowCount || !worksetSummary.newWorksetCount || worksetIssues.length > 0;
    if (!worksetSummary.newWorksetCount) worksets.title = '기존 웍셋과 다른 새 이름을 하나 이상 입력하세요.';
    const centralize = actionButton('센트럴 파일 만들기 탭', () => switchCentralWorksetMode(state, 'centralize'), 'ghost');
    centralize.disabled = state.busy;
    buttons.append(worksets, centralize);
  } else {
    const runConfigured = actionButton('설정대로 실행', () => {
      const resolution = resolveAutomaticBatchMode(state.rows);
      if (resolution.issue || !resolution.mode) {
        toast(resolution.issue || '실행 설정을 확인해 주세요.', 'warn', 5200);
        return;
      }
      runMode(state, resolution.mode);
    }, 'primary strong');
    const worksetOnly = actionButton('웍셋 확인·추가 탭', () => switchCentralWorksetMode(state, 'worksets'), 'ghost');
    runConfigured.disabled = state.busy || !summary.applyRowCount || currentConfiguredIssues.length > 0 || !automaticBatch.mode;
    worksetOnly.disabled = state.busy;
    buttons.append(runConfigured, worksetOnly);
  }

  const runNote = setCentralWorksetScrollKey(div('centralworkset-run-note'), 'run-note');
  runNote.innerHTML = worksetsOnly ? `
    <strong>웍셋 단독 실행</strong>
    <span>센트럴과 로컬 RVT는 사용자 웍셋을 닫아 빠르게 연 뒤, 기존 센트럴에 새 사용자 웍셋만 추가하고 동기화합니다.</span>
    <span>일반 RVT는 대상 센트럴이 없으므로 먼저 센트럴 파일 생성 화면에서 중앙화해야 합니다.</span>` : `
    <strong>출력 경로 하나로 자동 판단</strong>
    <span>센트럴 저장 경로 입력: 새 센트럴 생성 + 추가 웍셋 + 선택 권한 적용.</span>
    <span>센트럴 저장 경로 비움: 기존·연결 센트럴에 선택 권한만 적용. 이 경우 현재 Excel 양식을 내보내 설정한 뒤 다시 불러와야 합니다.</span>
    <span>Grid/Level 옵션은 본문 Grid/Level Pin과 exact-name Shared Levels and Grids UserWorkset Owner/Editable 유지를 한 번에 적용합니다.</span>`;

  const existingCentralMode = resolvedMode === 'worksets' || resolvedMode === 'ownership';
  const folder = existingCentralMode ? firstWorksetTargetFolder(state.rows) : firstOutputFolder(state.rows);
  const openFolder = actionButton(existingCentralMode ? '첫 센트럴 폴더 열기' : '첫 출력 폴더 열기', () => {
    const path = existingCentralMode ? firstWorksetTargetFolder(state.rows) : firstOutputFolder(state.rows);
    if (path) post('centralworkset:open-output-folder', { path });
  }, 'ghost');
  openFolder.disabled = state.busy || !folder;

  const parts = [heading];
  if (state.busy) {
    const busy = div('centralworkset-busy');
    busy.innerHTML = `<span></span><strong>${escapeHtml(runModeLabel(state.lastMode))} 진행 중</strong>`;
    parts.push(busy);
  }
  parts.push(stats, readiness);
  if (overwrite) parts.push(overwrite);
  parts.push(buttons, runNote, openFolder);
  host.append(...parts);
  completeCentralWorksetInteractionRender(state, interaction);
}

function buildOverwriteControl(state) {
  const overwrite = document.createElement('label');
  overwrite.className = 'centralworkset-overwrite';
  const overwriteInput = document.createElement('input');
  overwriteInput.type = 'checkbox';
  setCentralWorksetFocusKey(overwriteInput, 'overwrite-existing');
  overwriteInput.checked = state.overwriteExisting;
  overwriteInput.disabled = state.busy;
  overwriteInput.addEventListener('change', () => {
    if (overwriteInput.checked) {
      const confirmed = window.confirm('기존 출력 파일 덮어쓰기를 허용할까요? 같은 경로의 RVT가 있으면 교체될 수 있습니다.');
      if (!confirmed) {
        overwriteInput.checked = false;
        return;
      }
    }
    state.overwriteExisting = overwriteInput.checked;
    scheduleDraftBroadcast(state);
    renderRunPanel(state);
  });
  const overwriteCopy = document.createElement('span');
  overwriteCopy.innerHTML = '<strong>기존 출력 파일 덮어쓰기</strong><small>기본값은 OFF입니다. 켜면 실행 전 다시 확인합니다.</small>';
  overwrite.append(overwriteInput, overwriteCopy);
  return overwrite;
}

function addAndInspectPaths(state, paths) {
  if (state.busy || state.activeRequestId) {
    toast('현재 작업이 끝난 뒤 RVT 파일을 다시 추가하세요.', 'warn');
    return;
  }
  const normalized = normalizePathList(paths);
  if (!normalized.length) return;
  const existing = new Set(state.rows.map((row) => normalizePathKey(row.sourcePath)).filter(Boolean));
  const addedPaths = normalized.filter((path) => !existing.has(normalizePathKey(path)));
  if (!addedPaths.length) {
    toast('이미 등록된 RVT입니다.', 'warn');
    return;
  }

  addedPaths.forEach((path) => {
    const row = normalizeRow({
      rowId: makeLocalRowId(path),
      sourcePath: path,
      sourceFileName: fileName(path),
      sourceType: 'pending',
      format: '',
      existingWorksets: [],
      addWorksets: [],
      outputCentralPath: ''
    });
    state.rows.push(row);
    state.checkedRowIds.add(row.rowId);
  });
  ensureSelectedRow(state);
  scheduleDraftBroadcast(state);
  renderWorkspace(state);
  renderRunPanel(state);
  startInspection(state, addedPaths);
}

function inspectCurrentRows(state) {
  const paths = normalizePathList(state.rows.map((row) => row.sourcePath));
  if (!paths.length) {
    toast('다시 읽을 저장된 RVT 경로가 없습니다.', 'warn');
    return;
  }
  startInspection(state, paths);
}

function startInspection(state, paths) {
  if (!paths?.length || state.busy || state.activeRequestId) return;
  state.lastMode = 'inspect';
  flushDraftBroadcast(state);
  if (!beginHostRequest(state, 'inspect', 'centralworkset:inspect', { paths }, { owner: true, progress: true })) return;
  showCentralProgress('RVT 정보 확인', '파일 종류와 현재 웍셋을 확인하는 중입니다.');
  ProgressDialog.update(5, 'RVT 정보 확인', `${paths.length}개 파일`);
  renderWorkspace(state);
  syncHeaderActions(state);
  renderRunPanel(state);
}

function exportTemplate(state) {
  if (!state.rows.length || state.busy) return;
  const mode = currentOperationMode(state);
  // Export creates a template from registered RVT rows. Operation-specific
  // completeness belongs to Excel import/preflight/run, because the user must
  // be able to fill Output/AddWorksets/ownership options in the workbook.
  state.lastMode = 'export';
  beginHostRequest(state, 'export-template', 'centralworkset:export-template', {
    mode,
    rows: serializeRows(state.rows, mode, { forExport: true })
  }, { exportRequested: true });
}

function requestWorkbookPick(state) {
  if (state.busy) return;
  const replaceConfirmed = !state.rows.length || window.confirm([
    `Excel 설정을 불러오면 현재 ${state.rows.length}개 작업 행과 설정을 교체합니다.`,
    '덮어쓰기 허용은 안전을 위해 OFF로 초기화됩니다. 계속할까요? 원본 RVT는 변경하지 않습니다.'
  ].join('\n'));
  if (!replaceConfirmed) return;
  state.workbookReplaceConfirmed = true;
  if (!beginHostRequest(state, 'pick-workbook', 'centralworkset:pick-workbook', {
    sourceId: state.instanceId
  }, { awaitingWorkbookPick: true })) {
    state.workbookReplaceConfirmed = false;
  }
}

function startWorkbookImport(state, path, options = {}) {
  const workbookPath = String(path || '').trim();
  if (!workbookPath || state.busy) return;
  if (state.rows.length && !options.replaceConfirmed) {
    const confirmed = window.confirm([
      `Excel 설정으로 현재 ${state.rows.length}개 작업 행과 설정을 교체할까요?`,
      '불러오면 덮어쓰기 허용은 OFF로 초기화됩니다. 취소하면 현재 설정을 그대로 유지합니다.'
    ].join('\n'));
    if (!confirmed) return;
  }
  state.workbookPath = workbookPath;
  state.lastMode = 'import';
  if (!beginHostRequest(state, 'import-workbook', 'centralworkset:import-workbook', {
    path: workbookPath
  }, { owner: true, progress: true })) return;
  showCentralProgress('Excel 설정 불러오기', '파일별 출력 경로와 추가 웍셋을 읽는 중입니다.');
  ProgressDialog.update(15, 'Excel 설정 불러오기', workbookPath);
  renderWorkspace(state);
  syncHeaderActions(state);
  renderRunPanel(state);
}

function runMode(state, mode) {
  if (state.busy || !state.rows.length) return;
  const label = runModeLabel(mode);
  const requiresNewCentralPath = mode === 'centralize' || mode === 'all';
  // 통합 화면에서는 실제 Service mode(ALL/OWNERSHIP/WORKSETS)를 실행 직전에
  // 정하되, 가져온 구버전 Operation과의 불필요한 화면 mismatch는 만들지 않는다.
  const validationMode = currentOperationMode(state) === 'centralize' ? 'centralize' : mode;
  const centralIssues = collectCentralValidationIssues(state.rows, validationMode);
  const summary = summarizeRows(state.rows, mode);

  if (!summary.applyRowCount) {
    toast('실행에 포함된 파일이 없습니다. 왼쪽 파일 목록에서 하나 이상을 실행 포함으로 바꿔 주세요.', 'warn');
    return;
  }

  if (centralIssues.length) {
    const targetLabel = requiresNewCentralPath ? '센트럴 출력 경로' : '웍셋 대상 중앙 경로';
    toast(`${targetLabel} ${centralIssues.length}건을 먼저 확인해 주세요.`, 'warn', 4600);
    return;
  }
  if (mode === 'worksets' && !summary.newWorksetCount) {
    toast('기존 웍셋과 다른 새 웍셋 이름을 한 개 이상 입력해 주세요.', 'warn');
    return;
  }

  const addsWorksets = mode === 'worksets' || mode === 'all';
  const confirmation = [
    `${label}을 시작할까요?`,
    `실행 대상 RVT: ${summary.applyRowCount}개`,
    summary.skippedRowCount ? `실행 제외: ${summary.skippedRowCount}개` : '',
    `열린 활성 문서: ${state.rows.filter((row) => row.isOpen && !isSkippedRow(row)).length}개`,
    state.rows.some((row) => row.isOpen && !isSkippedRow(row))
      ? '활성 문서는 수정 사항을 저장하고 닫은 뒤 웍셋을 유지한 채 분리해 처리합니다. 센트럴 원본은 자동으로 다시 열지 않습니다.'
      : '',
    addsWorksets
      ? `새로 추가할 웍셋: ${summary.newWorksetCount}개`
      : (summary.newWorksetCount ? `입력된 웍셋 ${summary.newWorksetCount}개는 이번 센트럴 생성에서 추가하지 않음` : ''),
    (requiresNewCentralPath || mode === 'ownership') && summary.ownershipViewCount
      ? `현재 사용자 소유로 유지할 3D 뷰: ${summary.ownershipViewCount}개 (${summary.ownershipRowCount}개 파일)`
      : '',
    (requiresNewCentralPath || mode === 'ownership') && summary.viewTemplateOwnershipCount
      ? `ViewWorkset을 현재 사용자 소유·편집 가능으로 유지할 3D 뷰 템플릿: ${summary.viewTemplateOwnershipCount}개 (${summary.viewTemplateOwnershipRowCount}개 파일, Revit 필수 pair/internal closure의 추가 ViewWorkset 포함 가능, 비대상 View/템플릿 포함 시 차단)`
      : '',
    (requiresNewCentralPath || mode === 'ownership') && summary.levelGridOwnershipRowCount
      ? (mode === 'ownership'
        ? `exact-name ${LEVEL_GRID_OWNERSHIP_WORKSET_NAME} UserWorkset Owner=current/Editable=Yes 유지: ${summary.levelGridOwnershipRowCount}개 파일${state.rows.some((row) => !isSkippedRow(row) && row.pinLevelGridElements) ? ' · 선택 행의 본문 Level/Grid Pin 포함' : ''}`
        : `등록 RVT 본문의 모든 Level/Grid Pin + exact-name ${LEVEL_GRID_OWNERSHIP_WORKSET_NAME} UserWorkset Owner=current/Editable=Yes 유지: ${summary.levelGridOwnershipRowCount}개 파일 (같은 Workset의 비-Level/Grid 요소도 다른 사용자가 수정하지 못할 수 있음, 다른 UserWorkset·개별 요소 대여 반납, 링크 모델 제외)`)
      : '',
    requiresNewCentralPath && summary.missingConnectedCentralCount
      ? `기존 센트럴 경로 없음: ${summary.missingConnectedCentralCount}개 · 등록한 로컬/복사본 자체를 웍셋 유지 디태치하여 새 센트럴로 생성`
      : '',
    requiresNewCentralPath && state.overwriteExisting
      ? '기존 출력 파일 덮어쓰기: 허용'
      : (requiresNewCentralPath ? '기존 출력 파일 덮어쓰기: 허용 안 함' : '')
  ].filter(Boolean).join('\n');
  if (!window.confirm(confirmation)) return;

  state.lastMode = mode;
  flushDraftBroadcast(state);
  if (!beginHostRequest(state, 'run', 'centralworkset:run', {
    mode,
    rows: serializeRows(state.rows, mode, { forRun: true }),
    overwriteExisting: requiresNewCentralPath && !!state.overwriteExisting
  }, { owner: true, progress: true, runRequested: true })) return;
  showCentralProgress(label, 'RVT 처리 준비 중입니다.');
  ProgressDialog.update(2, label, `${state.rows.length}개 파일`);
  renderWorkspace(state);
  syncHeaderActions(state);
  renderRunPanel(state);
}

function clearRows(state) {
  if (state.busy || !state.rows.length) return;
  if (!window.confirm([
    `등록된 ${state.rows.length}개 RVT와 파일별 경로·웍셋 설정을 모두 비울까요?`,
    '원본 RVT는 삭제하지 않지만 현재 작업 설정은 되돌릴 수 없습니다.'
  ].join('\n'))) return;
  state.rows = [];
  state.checkedRowIds.clear();
  state.selectedRowId = '';
  state.commonFolder = '';
  state.workbookPath = '';
  state.overwriteExisting = false;
  state.fileSearch = '';
  state.fileFilter = 'all';
  state.lastSummary = null;
  scheduleDraftBroadcast(state);
  renderWorkspace(state);
  renderRunPanel(state);
}

function replaceRows(state, incomingRows, options = {}) {
  const previous = state.rows;
  const normalized = arrayOf(incomingRows).map((raw) => {
    const fallback = options.preserveEdits ? findMatchingRawRow(previous, raw) : null;
    const row = normalizeRow(raw, fallback, { identityKind: options.identityKind });
    return fallback ? preserveEditableRowState(row, fallback) : row;
  });
  state.rows = dedupeRows(normalized);
  syncCheckedRows(state, options.checkIncoming !== false);
}

function mergeRows(state, incomingRows, options = {}) {
  const next = [...state.rows];
  arrayOf(incomingRows).forEach((raw) => {
    const existingIndex = findMatchingRowIndex(next, raw, { identityKind: options.identityKind });
    const sourceMatches = findSourceMatchingRowIndexes(next, pick(raw, 'sourcePath', 'SourcePath'));
    if (existingIndex < 0 && sourceMatches.length > 1 && sourceMatches.every((index) => next[index].rowIdentity === ROW_IDENTITY_ROW_ID)) {
      sourceMatches.forEach((index) => {
        const previous = next[index];
        let normalized = normalizeRow({
          ...raw,
          rowId: previous.rowId,
          rowIdentity: ROW_IDENTITY_ROW_ID
        }, options.preserveEdits ? previous : null, { identityKind: ROW_IDENTITY_ROW_ID });
        if (options.preserveEdits) normalized = preserveEditableRowState(normalized, previous);
        next.splice(index, 1, normalized);
        if (options.checkIncoming) state.checkedRowIds.add(normalized.rowId);
      });
      return;
    }
    const previous = existingIndex >= 0 ? next[existingIndex] : null;
    let normalized = normalizeRow(raw, options.preserveEdits ? previous : null, { identityKind: options.identityKind });
    if (options.preserveEdits && previous) normalized = preserveEditableRowState(normalized, previous);
    if (existingIndex >= 0) next.splice(existingIndex, 1, normalized);
    else next.push(normalized);
    if (options.checkIncoming) state.checkedRowIds.add(normalized.rowId);
    if (previous && previous.rowId !== normalized.rowId) state.checkedRowIds.delete(previous.rowId);
  });
  state.rows = dedupeRows(next);
  syncCheckedRows(state, false);
}

function preserveEditableRowState(next, previous) {
  if (!next || !previous) return next;
  next.operation = normalizeRowOperation(previous.operation);
  next.outputCentralPath = String(previous.outputCentralPath || '').trim();
  next.worksetTargetPath = String(previous.worksetTargetPath || next.worksetTargetPath || '').trim();
  next.addWorksets = normalizeStringList(previous.addWorksets);
  next.retain3DViewOwnership = !!previous.retain3DViewOwnership;
  next.ownership3DViewNames = normalizeExactNameList(previous.ownership3DViewNames);
  next.retainViewTemplateOwnership = !!previous.retainViewTemplateOwnership;
  next.ownershipViewTemplateNames = normalizeExactNameList(previous.ownershipViewTemplateNames);
  next.pinAndRetainLevelGridOwnership = !!previous.pinAndRetainLevelGridOwnership;
  next.retainLevelGridWorksetOwnership = !!previous.retainLevelGridWorksetOwnership;
  next.pinLevelGridElements = !!previous.pinLevelGridElements;
  next.existingCentralOwnershipTargetKind = String(previous.existingCentralOwnershipTargetKind || '').trim();
  next.action = normalizeServiceAction(previous.action);
  next.originalSourcePath = String(previous.originalSourcePath || next.originalSourcePath || previous.sourcePath || '').trim();
  next.originalCentralPath = String(previous.originalCentralPath || next.originalCentralPath || '').trim();
  return next;
}

function applyCompletedRows(state, incomingRows, completedMode) {
  const previousRows = state.rows;
  const normalizedMode = String(completedMode || '').trim().toLowerCase();
  const next = arrayOf(incomingRows).map((raw) => {
    const previous = findMatchingRawRow(previousRows, raw);
    const identityKind = previous?.rowIdentity;
    const row = normalizeRow(raw, previous, { identityKind });
    const incomingTarget = String(pick(raw, 'outputCentralPath', 'OutputCentralPath') || '').trim();

    if (normalizedMode === 'worksets') {
      row.outputCentralPath = String(previous?.outputCentralPath || '').trim();
      row.worksetTargetPath = incomingTarget || previous?.worksetTargetPath || effectiveWorksetTarget(row, true);
    } else if ((normalizedMode === 'centralize' || normalizedMode === 'all') &&
               isSuccessfulStatus(row.status) && row.outputCentralPath) {
      row.worksetTargetPath = row.outputCentralPath;
      row.centralPath = row.outputCentralPath;
    }

    row.originalSourcePath = String(row.originalSourcePath || previous?.originalSourcePath || row.sourcePath || '').trim();
    row.originalCentralPath = String(row.originalCentralPath || previous?.originalCentralPath || '').trim();
    return row;
  });
  state.rows = dedupeRows(next);
  syncCheckedRows(state, false);
}

function syncCheckedRows(state, checkIncoming) {
  const validIds = new Set(state.rows.map((row) => row.rowId));
  state.checkedRowIds = new Set(Array.from(state.checkedRowIds).filter((id) => validIds.has(id)));
  if (checkIncoming) state.rows.forEach((row) => state.checkedRowIds.add(row.rowId));
}

function ensureSelectedRow(state) {
  const selectedExists = state.rows.some((row) => row.rowId === state.selectedRowId);
  if (!selectedExists) state.selectedRowId = state.rows[0]?.rowId || '';
}

function buildDraftPayload(state) {
  const operationMode = currentOperationMode(state);
  return {
    sourceId: state.instanceId,
    revision: state.draftRevision,
    rows: serializeRows(state.rows, operationMode, { forDraft: true }),
    operationMode,
    commonFolder: state.commonFolder || '',
    workbookPath: state.workbookPath || '',
    overwriteExisting: !!state.overwriteExisting,
    selectedRowId: state.selectedRowId || '',
    checkedRowIds: Array.from(state.checkedRowIds)
  };
}

function applyDraft(state, draft) {
  if (!draft || typeof draft !== 'object') return;
  const revision = Number(pick(draft, 'revision', 'Revision'));
  const hostSanitized = toBoolean(pick(draft, 'hostSanitized', 'HostSanitized'));
  if (!hostSanitized && Number.isFinite(revision) && revision < state.draftRevision) return;
  if (Object.prototype.hasOwnProperty.call(draft, 'rows') || Object.prototype.hasOwnProperty.call(draft, 'Rows')) {
    replaceRows(state, arrayOf(pick(draft, 'rows', 'Rows')), { preserveEdits: false, checkIncoming: false });
  }
  if (Object.prototype.hasOwnProperty.call(draft, 'commonFolder') || Object.prototype.hasOwnProperty.call(draft, 'CommonFolder')) {
    state.commonFolder = String(pick(draft, 'commonFolder', 'CommonFolder') || '').trim();
  }
  if (Object.prototype.hasOwnProperty.call(draft, 'workbookPath') || Object.prototype.hasOwnProperty.call(draft, 'WorkbookPath')) {
    state.workbookPath = String(pick(draft, 'workbookPath', 'WorkbookPath') || '').trim();
  }
  if (Object.prototype.hasOwnProperty.call(draft, 'overwriteExisting') || Object.prototype.hasOwnProperty.call(draft, 'OverwriteExisting')) {
    state.overwriteExisting = toBoolean(pick(draft, 'overwriteExisting', 'OverwriteExisting'));
  }
  if (Object.prototype.hasOwnProperty.call(draft, 'operationMode') || Object.prototype.hasOwnProperty.call(draft, 'OperationMode')) {
    const incomingMode = String(pick(draft, 'operationMode', 'OperationMode') || '').trim().toLowerCase();
    if (incomingMode === 'centralize' || incomingMode === 'all' || incomingMode === 'worksets' || incomingMode === 'ownership') {
      setCentralWorksetModeState(state, incomingMode);
    }
  }
  const selectedRowId = String(pick(draft, 'selectedRowId', 'SelectedRowId') || '').trim();
  if (selectedRowId) state.selectedRowId = selectedRowId;
  if (Object.prototype.hasOwnProperty.call(draft, 'checkedRowIds') || Object.prototype.hasOwnProperty.call(draft, 'CheckedRowIds')) {
    const checked = normalizeStringList(pick(draft, 'checkedRowIds', 'CheckedRowIds'));
    state.checkedRowIds = new Set(checked);
  }
  if (Number.isFinite(revision)) state.draftRevision = Math.max(state.draftRevision, revision);
  ensureSelectedRow(state);
}

function scheduleDraftBroadcast(state) {
  if (!state) return;
  // A local mutation after a queued remote payload is the latest write.
  discardPendingRemoteDraft(state);
  if (state.draftTimer) window.clearTimeout(state.draftTimer);
  state.draftTimer = window.setTimeout(() => {
    state.draftTimer = 0;
    flushDraftBroadcast(state);
  }, 140);
}

function flushDraftBroadcast(state) {
  if (!state) return;
  discardPendingRemoteDraft(state);
  if (state.draftTimer) window.clearTimeout(state.draftTimer);
  state.draftTimer = 0;
  state.draftRevision += 1;
  post('centralworkset:draft-changed', buildDraftPayload(state));
}

function switchCentralWorksetMode(state, mode) {
  if (!state || state.busy || state.activeRequestId) {
    toast('현재 작업이 끝난 뒤 작업 방식을 전환하세요.', 'warn');
    return;
  }

  const normalizedMode = normalizeOperationMode(mode);
  if (currentOperationMode(state) === normalizedMode) return;

  setCentralWorksetModeState(state, normalizedMode);
  state.lastMode = '';
  syncHeaderActions(state);
  renderWorkspace(state);
  renderRunPanel(state);
}

function normalizeOperationMode(value) {
  const normalized = String(value || '').trim().toLowerCase();
  if (normalized === 'worksets') return 'worksets';
  // all/ownership은 기존 URL·draft 호환 값이다. 보이는 화면은 Output 경로로
  // 실행 종류를 판단하는 통합 화면 하나로 합친다.
  return 'centralize';
}

function isCreateMode(mode) {
  const normalized = String(mode || '').trim().toLowerCase();
  return normalized === 'centralize' || normalized === 'all';
}

function operationForMode(mode) {
  switch (String(mode || '').trim().toLowerCase()) {
    case 'worksets': return 'WORKSETS';
    case 'ownership': return 'OWNERSHIP';
    case 'all': return 'ALL';
    default: return 'CENTRALIZE';
  }
}

function normalizeRowOperation(value) {
  return String(value || '').trim().toUpperCase();
}

function uniformApplyOperation(rows) {
  const operations = new Set(arrayOf(rows)
    .filter((row) => !isSkippedRow(row))
    .map((row) => normalizeRowOperation(row?.operation))
    .filter(Boolean));
  return operations.size === 1 ? Array.from(operations)[0] : '';
}

function hasOwnershipRequest(rows) {
  return arrayOf(rows).some((row) => !isSkippedRow(row) && (
    (row?.retain3DViewOwnership && normalizeExactNameList(row?.ownership3DViewNames).length > 0) ||
    (row?.retainViewTemplateOwnership && normalizeExactNameList(row?.ownershipViewTemplateNames).length > 0) ||
    isUnifiedLevelGridOwnershipRequested(row)
  ));
}

function isUnifiedLevelGridOwnershipRequested(row) {
  return !!row?.pinAndRetainLevelGridOwnership || !!row?.retainLevelGridWorksetOwnership;
}

function hasAnyOwnershipInput(row) {
  return !!row?.retain3DViewOwnership ||
    !!row?.retainViewTemplateOwnership ||
    isUnifiedLevelGridOwnershipRequested(row) ||
    normalizeExactNameList(row?.ownership3DViewNames).length > 0 ||
    normalizeExactNameList(row?.ownershipViewTemplateNames).length > 0;
}

function automaticModeForRow(row) {
  if (String(row?.outputCentralPath || '').trim()) return 'all';
  if (!hasAnyOwnershipInput(row) && normalizeStringList(row?.addWorksets).length) return 'worksets';
  return 'ownership';
}

function resolveAutomaticBatchMode(rows) {
  const modes = new Set(arrayOf(rows)
    .filter((row) => !isSkippedRow(row))
    .map(automaticModeForRow));
  if (!modes.size) return { mode: '', issue: '실행에 포함된 파일이 없습니다.' };
  if (modes.size === 1) return { mode: Array.from(modes)[0], issue: '' };
  if (modes.has('all')) {
    return {
      mode: '',
      issue: "새 센트럴 생성 행과 기존 센트럴 작업 행을 한 번에 섞을 수 없습니다. 실행할 행의 '센트럴 저장 경로'를 모두 입력하거나 모두 비워 주세요."
    };
  }
  return {
    mode: '',
    issue: '기존 센트럴 권한 적용과 웍셋 추가 행을 한 번에 섞을 수 없습니다. 두 작업을 나누어 실행하세요.'
  };
}

function invalidateOwnershipWorkbookTrust(row) {
  if (!row) return;
  const ownershipContract = row.ownershipWorkbookTrusted === true ||
    normalizeRowOperation(row.operation) === 'OWNERSHIP' ||
    String(row.existingCentralOwnershipTargetKind || '') === EXISTING_CENTRAL_OWNERSHIP_TARGET_KIND;
  if (!ownershipContract) return;
  row.ownershipWorkbookTrusted = false;
  row.resolvedOwnershipCentralPath = '';
  row.owned3DViewNames = [];
  row.ownedViewTemplateNames = [];
  row.ownedLevelGridCount = 0;
  row.ownedLevelGridWorksetNames = [];
  row.createdCentral = false;
  row.persistedChanges = false;
  row.persistenceState = 'NONE';
}

function currentOperationMode(state) {
  return normalizeOperationMode(state?.operationMode || (state?.worksetsOnly ? 'worksets' : 'centralize'));
}

function setCentralWorksetModeState(state, mode) {
  if (!state) return;
  const normalized = normalizeOperationMode(mode);
  state.operationMode = normalized;
  state.worksetsOnly = normalized === 'worksets';
  state.ownershipOnly = false;
  state.ui.page?.classList.toggle('centralworkset-page--worksets-only', state.worksetsOnly);
  state.ui.page?.classList.toggle('centralworkset-page--ownership-only', state.ownershipOnly);
  if (state.worksetsOnly) state.overwriteExisting = false;
}

function normalizeRow(raw, fallback = null, options = {}) {
  const sourcePath = String(pick(raw, 'sourcePath', 'SourcePath') || fallback?.sourcePath || '').trim();
  const rowId = String(pick(raw, 'rowId', 'RowId') || fallback?.rowId || makeLocalRowId(sourcePath)).trim();
  const rowIdentity = normalizeRowIdentity(
    options.identityKind || pick(raw, 'rowIdentity', 'RowIdentity') || fallback?.rowIdentity
  );
  const incomingOutput = pick(raw, 'outputCentralPath', 'OutputCentralPath');
  const incomingAddWorksets = pick(raw, 'addWorksets', 'AddWorksets');
  const incomingExistingWorksets = pick(raw, 'existingWorksets', 'ExistingWorksets');
  const incomingWorksetTarget = pick(raw, 'worksetTargetPath', 'WorksetTargetPath');
  const incomingOwnership3DViewNames = pick(raw, 'ownership3DViewNames', 'Ownership3DViewNames');
  const incomingOwned3DViewNames = pick(raw, 'owned3DViewNames', 'Owned3DViewNames');
  const incomingOwnershipViewTemplateNames = pick(raw, 'ownershipViewTemplateNames', 'OwnershipViewTemplateNames');
  const incomingOwnedViewTemplateNames = pick(raw, 'ownedViewTemplateNames', 'OwnedViewTemplateNames');
  const rawViewTemplateOwnershipTargetKind = String(
    pick(raw, 'viewTemplateOwnershipTargetKind', 'ViewTemplateOwnershipTargetKind') || ''
  ).trim();
  const fallbackViewTemplateOwnershipTargetKind = String(
    fallback?.viewTemplateOwnershipTargetKind || ''
  ).trim();
  const incomingRetainViewTemplateOwnership = pick(
    raw,
    'retainViewTemplateOwnership',
    'RetainViewTemplateOwnership'
  );
  const hasIncomingViewTemplateOwnershipFields =
    rawViewTemplateOwnershipTargetKind !== '' ||
    incomingRetainViewTemplateOwnership != null ||
    incomingOwnershipViewTemplateNames != null ||
    incomingOwnedViewTemplateNames != null;
  const hasCurrentViewTemplateOwnershipContract = hasIncomingViewTemplateOwnershipFields
    ? rawViewTemplateOwnershipTargetKind === VIEW_TEMPLATE_OWNERSHIP_TARGET_KIND
    : fallbackViewTemplateOwnershipTargetKind === VIEW_TEMPLATE_OWNERSHIP_TARGET_KIND;
  const incomingPinAndRetainLevelGridOwnership = pick(
    raw,
    'pinAndRetainLevelGridOwnership',
    'PinAndRetainLevelGridOwnership'
  );
  const incomingOwnedLevelGridCount = pick(raw, 'ownedLevelGridCount', 'OwnedLevelGridCount');
  const incomingOwnedLevelGridWorksetNames = pick(
    raw,
    'ownedLevelGridWorksetNames',
    'OwnedLevelGridWorksetNames'
  );
  const incomingOperation = pick(raw, 'operation', 'Operation');
  const incomingRetainLevelGridWorksetOwnership = pick(
    raw,
    'retainLevelGridWorksetOwnership',
    'RetainLevelGridWorksetOwnership'
  );
  const incomingPinLevelGridElements = pick(raw, 'pinLevelGridElements', 'PinLevelGridElements');
  const incomingOwnershipTargetKind = pick(
    raw,
    'existingCentralOwnershipTargetKind',
    'ExistingCentralOwnershipTargetKind'
  );
  const incomingResolvedOwnershipCentralPath = pick(
    raw,
    'resolvedOwnershipCentralPath',
    'ResolvedOwnershipCentralPath'
  );
  const rawLevelGridOwnershipTargetKind = String(
    pick(raw, 'levelGridOwnershipTargetKind', 'LevelGridOwnershipTargetKind') || ''
  ).trim();
  const fallbackLevelGridOwnershipTargetKind = String(
    fallback?.levelGridOwnershipTargetKind || ''
  ).trim();
  const hasIncomingLevelGridOwnershipFields =
    rawLevelGridOwnershipTargetKind !== '' ||
    incomingPinAndRetainLevelGridOwnership != null ||
    incomingOwnedLevelGridCount != null ||
    incomingOwnedLevelGridWorksetNames != null;
  const hasCurrentLevelGridOwnershipContract = hasIncomingLevelGridOwnershipFields
    ? rawLevelGridOwnershipTargetKind === LEVEL_GRID_OWNERSHIP_TARGET_KIND
    : fallbackLevelGridOwnershipTargetKind === LEVEL_GRID_OWNERSHIP_TARGET_KIND;

  const normalized = {
    rowId,
    rowIdentity,
    operation: normalizeRowOperation(incomingOperation == null ? fallback?.operation : incomingOperation),
    ownershipWorkbookTrusted: toBoolean(
      pick(raw, 'ownershipWorkbookTrusted', 'OwnershipWorkbookTrusted'),
      fallback?.ownershipWorkbookTrusted
    ),
    sourcePath,
    originalSourcePath: String(pick(raw, 'originalSourcePath', 'OriginalSourcePath') || fallback?.originalSourcePath || sourcePath || '').trim(),
    originalCentralPath: String(pick(raw, 'originalCentralPath', 'OriginalCentralPath') || fallback?.originalCentralPath || '').trim(),
    sourceFileName: String(pick(raw, 'sourceFileName', 'SourceFileName') || fallback?.sourceFileName || fileName(sourcePath) || '').trim(),
    sourceType: String(pick(raw, 'sourceType', 'SourceType') || fallback?.sourceType || '').trim(),
    isWorkshared: toBoolean(pick(raw, 'isWorkshared', 'IsWorkshared'), fallback?.isWorkshared),
    isCentral: toBoolean(pick(raw, 'isCentral', 'IsCentral'), fallback?.isCentral),
    isLocal: toBoolean(pick(raw, 'isLocal', 'IsLocal'), fallback?.isLocal),
    isStandalone: toBoolean(pick(raw, 'isStandalone', 'IsStandalone'), fallback?.isStandalone),
    isOpen: toBoolean(pick(raw, 'isOpen', 'IsOpen'), fallback?.isOpen),
    isNewerVersion: toBoolean(pick(raw, 'isNewerVersion', 'IsNewerVersion'), fallback?.isNewerVersion),
    isCurrentVersion: toBoolean(pick(raw, 'isCurrentVersion', 'IsCurrentVersion'), fallback?.isCurrentVersion),
    isFamily: toBoolean(pick(raw, 'isFamily', 'IsFamily'), fallback?.isFamily),
    isCloud: toBoolean(pick(raw, 'isCloud', 'IsCloud'), fallback?.isCloud),
    format: String(pick(raw, 'format', 'Format') || fallback?.format || '').trim(),
    centralPath: String(pick(raw, 'centralPath', 'CentralPath') || fallback?.centralPath || '').trim(),
    missingConnectedCentral: toBoolean(pick(raw, 'missingConnectedCentral', 'MissingConnectedCentral'), fallback?.missingConnectedCentral),
    existingWorksets: incomingExistingWorksets == null
      ? normalizeStringList(fallback?.existingWorksets)
      : normalizeStringList(incomingExistingWorksets),
    outputCentralPath: incomingOutput == null
      ? String(fallback?.outputCentralPath || '').trim()
      : String(incomingOutput || '').trim(),
    worksetTargetPath: incomingWorksetTarget == null
      ? String(fallback?.worksetTargetPath || '').trim()
      : String(incomingWorksetTarget || '').trim(),
    addWorksets: incomingAddWorksets == null
      ? normalizeStringList(fallback?.addWorksets)
      : normalizeStringList(incomingAddWorksets),
    retain3DViewOwnership: toBoolean(pick(raw, 'retain3DViewOwnership', 'Retain3DViewOwnership'), fallback?.retain3DViewOwnership),
    ownership3DViewNames: incomingOwnership3DViewNames == null
      ? normalizeExactNameList(fallback?.ownership3DViewNames)
      : normalizeExactNameList(incomingOwnership3DViewNames),
    owned3DViewNames: incomingOwned3DViewNames == null
      ? normalizeExactNameList(fallback?.owned3DViewNames)
      : normalizeExactNameList(incomingOwned3DViewNames),
    retainViewTemplateOwnership: hasCurrentViewTemplateOwnershipContract
      ? toBoolean(incomingRetainViewTemplateOwnership, fallback?.retainViewTemplateOwnership)
      : false,
    ownershipViewTemplateNames: hasCurrentViewTemplateOwnershipContract
      ? (incomingOwnershipViewTemplateNames == null
        ? normalizeExactNameList(fallback?.ownershipViewTemplateNames)
        : normalizeExactNameList(incomingOwnershipViewTemplateNames))
      : [],
    viewTemplateOwnershipTargetKind: VIEW_TEMPLATE_OWNERSHIP_TARGET_KIND,
    ownedViewTemplateNames: hasCurrentViewTemplateOwnershipContract
      ? (incomingOwnedViewTemplateNames == null
        ? normalizeExactNameList(fallback?.ownedViewTemplateNames)
        : normalizeExactNameList(incomingOwnedViewTemplateNames))
      : [],
    pinAndRetainLevelGridOwnership: hasCurrentLevelGridOwnershipContract
      ? toBoolean(incomingPinAndRetainLevelGridOwnership, fallback?.pinAndRetainLevelGridOwnership)
      : false,
    retainLevelGridWorksetOwnership: toBoolean(
      incomingRetainLevelGridWorksetOwnership,
      fallback?.retainLevelGridWorksetOwnership
    ),
    pinLevelGridElements: toBoolean(incomingPinLevelGridElements, fallback?.pinLevelGridElements),
    existingCentralOwnershipTargetKind: String(
      incomingOwnershipTargetKind == null
        ? (fallback?.existingCentralOwnershipTargetKind || '')
        : (incomingOwnershipTargetKind || '')
    ).trim(),
    resolvedOwnershipCentralPath: String(
      incomingResolvedOwnershipCentralPath == null
        ? (fallback?.resolvedOwnershipCentralPath || '')
        : (incomingResolvedOwnershipCentralPath || '')
    ).trim(),
    levelGridOwnershipTargetKind: LEVEL_GRID_OWNERSHIP_TARGET_KIND,
    ownedLevelGridCount: hasCurrentLevelGridOwnershipContract
      ? toNonNegativeInteger(incomingOwnedLevelGridCount, fallback?.ownedLevelGridCount)
      : 0,
    ownedLevelGridWorksetNames: hasCurrentLevelGridOwnershipContract
      ? (incomingOwnedLevelGridWorksetNames == null
        ? normalizeExactNameList(fallback?.ownedLevelGridWorksetNames)
        : normalizeExactNameList(incomingOwnedLevelGridWorksetNames))
      : [],
    action: normalizeServiceAction(pick(raw, 'action', 'Action') ?? fallback?.action),
    status: String(pick(raw, 'status', 'Status') || '').trim(),
    message: String(pick(raw, 'message', 'Message') || '').trim(),
    persistenceState: String(pick(raw, 'persistenceState', 'PersistenceState') || fallback?.persistenceState || 'NONE').trim().toUpperCase(),
    requiresManualVerification: toBoolean(pick(raw, 'requiresManualVerification', 'RequiresManualVerification'), fallback?.requiresManualVerification),
    createdCentral: toBoolean(pick(raw, 'createdCentral', 'CreatedCentral'), fallback?.createdCentral),
    persistedChanges: toBoolean(pick(raw, 'persistedChanges', 'PersistedChanges'), fallback?.persistedChanges),
    createdWorksets: normalizeStringList(pick(raw, 'createdWorksets', 'CreatedWorksets')),
    skippedWorksets: normalizeStringList(pick(raw, 'skippedWorksets', 'SkippedWorksets'))
  };
  if (!hasVerified3DOwnershipResult(normalized)) normalized.owned3DViewNames = [];
  if (!hasVerifiedViewTemplateOwnershipResult(normalized)) normalized.ownedViewTemplateNames = [];
  if (!hasVerifiedLevelGridOwnershipResult(normalized)) {
    normalized.ownedLevelGridCount = 0;
    normalized.ownedLevelGridWorksetNames = [];
  }
  return normalized;
}

function hasVerifiedCentralOwnershipResult(row) {
  const status = String(row?.status || '').trim().toLowerCase();
  const verified = (status === 'succeeded' || status === 'completed') &&
    String(row?.persistenceState || '').trim().toUpperCase() === 'VERIFIED' &&
    row?.requiresManualVerification !== true;
  if (!verified) return false;
  if (normalizeRowOperation(row?.operation) === 'OWNERSHIP') {
    return row?.createdCentral === false &&
      row?.ownershipWorkbookTrusted === true &&
      String(row?.existingCentralOwnershipTargetKind || '') === EXISTING_CENTRAL_OWNERSHIP_TARGET_KIND &&
      !String(row?.outputCentralPath || '').trim() &&
      isAbsoluteWindowsRvtPath(row?.resolvedOwnershipCentralPath);
  }
  return row?.createdCentral === true && row?.persistedChanges === true;
}

function hasVerified3DOwnershipResult(row) {
  const requested = normalizeExactNameList(row?.ownership3DViewNames);
  const owned = normalizeExactNameList(row?.owned3DViewNames);
  return hasVerifiedCentralOwnershipResult(row) &&
    row?.retain3DViewOwnership === true &&
    requested.length > 0 &&
    exactNameSetsEqual(requested, owned);
}

function hasVerifiedViewTemplateOwnershipResult(row) {
  const requested = normalizeExactNameList(row?.ownershipViewTemplateNames);
  const owned = normalizeExactNameList(row?.ownedViewTemplateNames);
  return hasVerifiedCentralOwnershipResult(row) &&
    row?.retainViewTemplateOwnership === true &&
    requested.length > 0 &&
    exactNameSetsEqual(requested, owned);
}

function hasVerifiedLevelGridOwnershipResult(row) {
  return hasVerifiedCentralOwnershipResult(row) && isUnifiedLevelGridOwnershipRequested(row) &&
    exactNameSetsEqual(row?.ownedLevelGridWorksetNames, [LEVEL_GRID_OWNERSHIP_WORKSET_NAME]);
}

function exactNameSetsEqual(left, right) {
  const leftNames = normalizeExactNameList(left);
  const rightNames = normalizeExactNameList(right);
  if (leftNames.length !== rightNames.length) return false;
  const rightSet = new Set(rightNames);
  return leftNames.every((name) => rightSet.has(name));
}

function serializeRows(rows, mode = '', options = {}) {
  const normalizedMode = String(mode || '').trim().toLowerCase();
  const ownershipOnly = normalizedMode === 'ownership';
  const worksetsOnly = normalizedMode === 'worksets';
  const forExport = options?.forExport === true;
  const forRun = options?.forRun === true;
  const passiveSerialization = !forExport && !forRun;
  const exportedOperation = worksetsOnly ? 'WORKSETS' : 'AUTO';
  return rows.map((row) => ({
    rowId: row.rowId,
    rowIdentity: normalizeRowIdentity(row.rowIdentity),
    operation: forExport
      ? exportedOperation
      : forRun
        ? operationForMode(normalizedMode)
        : normalizeRowOperation(row.operation),
    sourcePath: row.sourcePath,
    originalSourcePath: row.originalSourcePath || row.sourcePath,
    originalCentralPath: row.originalCentralPath || '',
    sourceFileName: row.sourceFileName,
    sourceType: row.sourceType,
    isWorkshared: !!row.isWorkshared,
    isCentral: !!row.isCentral,
    isLocal: !!row.isLocal,
    isStandalone: !!row.isStandalone,
    isOpen: !!row.isOpen,
    isNewerVersion: !!row.isNewerVersion,
    isCurrentVersion: !!row.isCurrentVersion,
    isFamily: !!row.isFamily,
    isCloud: !!row.isCloud,
    format: row.format,
    centralPath: row.centralPath,
    missingConnectedCentral: !!row.missingConnectedCentral,
    existingWorksets: [...row.existingWorksets],
    outputCentralPath: ownershipOnly
      ? ''
      : worksetsOnly
      ? effectiveWorksetTarget(row, true)
      : row.outputCentralPath,
    worksetTargetPath: row.worksetTargetPath || '',
    addWorksets: ownershipOnly ? [] : [...row.addWorksets],
    retain3DViewOwnership: passiveSerialization
      ? !!row.retain3DViewOwnership
      : worksetsOnly ? false : !!row.retain3DViewOwnership,
    ownership3DViewNames: passiveSerialization
      ? [...row.ownership3DViewNames]
      : worksetsOnly ? [] : [...row.ownership3DViewNames],
    owned3DViewNames: [...row.owned3DViewNames],
    retainViewTemplateOwnership: passiveSerialization
      ? !!row.retainViewTemplateOwnership
      : worksetsOnly ? false : !!row.retainViewTemplateOwnership,
    ownershipViewTemplateNames: passiveSerialization
      ? [...row.ownershipViewTemplateNames]
      : worksetsOnly ? [] : [...row.ownershipViewTemplateNames],
    viewTemplateOwnershipTargetKind: VIEW_TEMPLATE_OWNERSHIP_TARGET_KIND,
    ownedViewTemplateNames: [...row.ownedViewTemplateNames],
    pinAndRetainLevelGridOwnership: passiveSerialization
      ? !!row.pinAndRetainLevelGridOwnership
      : ownershipOnly || worksetsOnly
        ? false
        : !!row.pinAndRetainLevelGridOwnership || (!!row.retainLevelGridWorksetOwnership && !!row.pinLevelGridElements),
    levelGridOwnershipTargetKind: LEVEL_GRID_OWNERSHIP_TARGET_KIND,
    retainLevelGridWorksetOwnership: passiveSerialization
      ? !!row.retainLevelGridWorksetOwnership
      : worksetsOnly
        ? false
        : ownershipOnly
        ? !!row.retainLevelGridWorksetOwnership || !!row.pinAndRetainLevelGridOwnership
        : forExport ? !!row.retainLevelGridWorksetOwnership : false,
    pinLevelGridElements: passiveSerialization
      ? !!row.pinLevelGridElements
      : worksetsOnly
        ? false
        : ownershipOnly
        ? !!row.pinLevelGridElements || !!row.pinAndRetainLevelGridOwnership
        : forExport ? !!row.pinLevelGridElements : false,
    existingCentralOwnershipTargetKind: passiveSerialization
      ? String(row.existingCentralOwnershipTargetKind || '').trim()
      : ownershipOnly
        ? (forExport ? EXISTING_CENTRAL_OWNERSHIP_TARGET_KIND : String(row.existingCentralOwnershipTargetKind || '').trim())
        : '',
    resolvedOwnershipCentralPath: '',
    ownedLevelGridCount: toNonNegativeInteger(row.ownedLevelGridCount),
    ownedLevelGridWorksetNames: [...row.ownedLevelGridWorksetNames],
    action: normalizeServiceAction(row.action),
    status: row.status,
    message: row.message,
    persistenceState: row.persistenceState || 'NONE',
    requiresManualVerification: !!row.requiresManualVerification,
    createdCentral: !!row.createdCentral,
    persistedChanges: !!row.persistedChanges,
    createdWorksets: [...row.createdWorksets],
    skippedWorksets: [...row.skippedWorksets]
  }));
}

function summarizeRows(rows, mode = 'centralize') {
  const safeRows = arrayOf(rows);
  const normalizedMode = String(mode || '').trim().toLowerCase();
  let outputReadyCount = 0;
  let requestedWorksetCount = 0;
  let newWorksetCount = 0;
  let duplicateWorksetCount = 0;
  let applyRowCount = 0;
  let skippedRowCount = 0;
  let ownershipRowCount = 0;
  let ownershipViewCount = 0;
  let ownedViewCount = 0;
  let viewTemplateOwnershipRowCount = 0;
  let viewTemplateOwnershipCount = 0;
  let ownedViewTemplateCount = 0;
  let levelGridOwnershipRowCount = 0;
  let ownedLevelGridCount = 0;
  let ownedLevelGridWorksetCount = 0;
  let missingConnectedCentralCount = 0;
  safeRows.forEach((row) => {
    if (isSkippedRow(row)) {
      skippedRowCount += 1;
      return;
    }
    applyRowCount += 1;
    if (row.missingConnectedCentral) missingConnectedCentralCount += 1;
    if (normalizedMode !== 'worksets' && row.retain3DViewOwnership) {
      ownershipRowCount += 1;
      ownershipViewCount += normalizeExactNameList(row.ownership3DViewNames).length;
      ownedViewCount += normalizeExactNameList(row.owned3DViewNames).length;
    }
    if (normalizedMode !== 'worksets' && row.retainViewTemplateOwnership) {
      viewTemplateOwnershipRowCount += 1;
      viewTemplateOwnershipCount += normalizeExactNameList(row.ownershipViewTemplateNames).length;
      ownedViewTemplateCount += normalizeExactNameList(row.ownedViewTemplateNames).length;
    }
    const levelGridRequested = isUnifiedLevelGridOwnershipRequested(row);
    if (normalizedMode !== 'worksets' && levelGridRequested) {
      levelGridOwnershipRowCount += 1;
      ownedLevelGridCount += toNonNegativeInteger(row.ownedLevelGridCount);
      ownedLevelGridWorksetCount += normalizeExactNameList(row.ownedLevelGridWorksetNames).length;
    }
    if (!validateCentralRow(row, mode).length) outputReadyCount += 1;
    const analysis = normalizedMode === 'ownership'
      ? { requested: [], duplicates: [], newNames: [] }
      : analyzeRequestedWorksets(row);
    requestedWorksetCount += analysis.requested.length;
    newWorksetCount += analysis.newNames.length;
    duplicateWorksetCount += analysis.duplicates.length;
  });
  return {
    rowCount: safeRows.length,
    applyRowCount,
    skippedRowCount,
    outputReadyCount,
    requestedWorksetCount,
    newWorksetCount,
    duplicateWorksetCount,
    ownershipRowCount,
    ownershipViewCount,
    ownedViewCount,
    viewTemplateOwnershipRowCount,
    viewTemplateOwnershipCount,
    ownedViewTemplateCount,
    levelGridOwnershipRowCount,
    ownedLevelGridCount,
    ownedLevelGridWorksetCount,
    missingConnectedCentralCount
  };
}

function analyzeRequestedWorksets(row) {
  const requested = normalizeStringList(row?.addWorksets);
  const existingKeys = new Set(normalizeStringList(row?.existingWorksets).map(normalizeNameKey));
  const duplicates = requested.filter((name) => existingKeys.has(normalizeNameKey(name)));
  const newNames = requested.filter((name) => !existingKeys.has(normalizeNameKey(name)));
  return { requested, duplicates, newNames };
}

function validate3DViewOwnership(row, mode = 'centralize') {
  const normalizedMode = String(mode || '').trim().toLowerCase();
  if (normalizedMode === 'worksets' || !row?.retain3DViewOwnership) return [];
  return normalizeExactNameList(row?.ownership3DViewNames).length
    ? []
    : ['3D 뷰 소유권 옵션을 켰습니다. 정확히 일치할 비템플릿 3D 뷰 이름을 한 줄에 하나 이상 입력해 주세요.'];
}

function validateViewTemplateOwnership(row, mode = 'centralize') {
  const normalizedMode = String(mode || '').trim().toLowerCase();
  if (normalizedMode === 'worksets' || !row?.retainViewTemplateOwnership) return [];
  return normalizeExactNameList(row?.ownershipViewTemplateNames).length
    ? []
    : ['3D 뷰 템플릿 ViewWorkset 소유·편집 옵션을 켰습니다. 정확히 일치할 3D 뷰 템플릿 이름을 한 줄에 하나 이상 입력해 주세요.'];
}

function collectCentralRowWarnings(row, mode = 'centralize') {
  const requestedMode = String(mode || '').trim().toLowerCase();
  const normalizedMode = requestedMode === 'centralize' ? automaticModeForRow(row) : requestedMode;
  if (normalizedMode === 'worksets' || normalizedMode === 'ownership' || isSkippedRow(row)) return [];
  const warnings = [];
  if (row?.missingConnectedCentral) {
    warnings.push('기존 연결 센트럴을 찾거나 안전하게 확인할 수 없지만, 등록한 로컬/복사본 자체를 웍셋 유지 디태치하여 새 센트럴로 만들 수 있습니다.');
  }
  if (isWarningStatus(row?.status) && row?.message) {
    const message = String(row.message).trim();
    if (message && !warnings.includes(message)) warnings.push(message);
  }
  return warnings;
}

function collectCentralValidationIssues(rows, mode = 'centralize') {
  const issues = [];
  const outputMap = new Map();
  const normalizedMode = String(mode).toLowerCase();
  const automatic = normalizedMode === 'centralize';
  const protectedInputPaths = collectProtectedInputPathKeys(rows);
  arrayOf(rows).forEach((row) => {
    if (isSkippedRow(row)) return;
    validateCentralRow(row, mode).forEach((message) => issues.push({ rowId: row.rowId, message }));
    const rowMode = automatic ? automaticModeForRow(row) : normalizedMode;
    const existingCentralMode = rowMode === 'worksets' || rowMode === 'ownership';
    const output = rowMode === 'worksets'
      ? effectiveWorksetTarget(row, true)
      : rowMode === 'ownership'
        ? effectiveOwnershipTarget(row)
        : row.outputCentralPath;
    const key = normalizePathKey(output);
    if (!key) return;
    const ownProtectedInputPaths = existingCentralMode
      ? new Set()
      : collectProtectedInputPathKeys([row]);
    if (!existingCentralMode && protectedInputPaths.has(key) && !ownProtectedInputPaths.has(key)) {
      const message = '새 센트럴 출력 경로가 등록된 원본 RVT 또는 연결 센트럴 경로와 충돌합니다.';
      issues.push({ rowId: row.rowId, message });
    }
    if (outputMap.has(key)) {
      issues.push({
        rowId: row.rowId,
        message: rowMode === 'worksets'
          ? '다른 파일과 웍셋 적용 대상 센트럴이 같습니다.'
          : rowMode === 'ownership'
            ? '다른 파일과 권한 적용 대상 센트럴이 같습니다.'
            : '다른 파일과 새 센트럴 출력 경로가 같습니다.'
      });
    } else {
      outputMap.set(key, row.rowId);
    }
  });
  if (automatic) {
    const batch = resolveAutomaticBatchMode(rows);
    if (batch.issue) issues.push({ rowId: '', message: batch.issue });
  }
  return issues;
}

function collectProtectedInputPathKeys(rows) {
  const result = new Set();
  arrayOf(rows).forEach((row) => {
    [
      row?.sourcePath,
      row?.originalSourcePath,
      row?.centralPath,
      row?.originalCentralPath
    ].forEach((path) => {
      const key = normalizePathKey(path);
      if (key) result.add(key);
    });
  });
  return result;
}

function validateCentralRow(row, mode = 'centralize') {
  const issues = [];
  if (isSkippedRow(row)) return issues;
  const requestedMode = String(mode || '').trim().toLowerCase();
  const automatic = requestedMode === 'centralize';
  const normalizedMode = automatic ? automaticModeForRow(row) : requestedMode;
  const rowOperation = normalizeRowOperation(row?.operation);
  const expectedOperation = operationForMode(normalizedMode);
  if (!automatic && rowOperation && rowOperation !== expectedOperation) {
    issues.push(`현재 실행 방식 ${expectedOperation}과 Excel Operation ${rowOperation}이 다릅니다.`);
  }
  if (row?.requiresManualVerification) {
    issues.push('이전 작업의 저장 여부를 자동으로 확인하지 못했습니다. 대상 RVT를 직접 확인한 뒤 새 목록으로 다시 등록하세요.');
    return issues;
  }
  if (String(row?.sourceType || '').trim().toLowerCase() === 'pending') {
    issues.push('RVT 파일 정보를 확인하는 중입니다.');
    return issues;
  }
  const fatalSourceIssue = describeFatalCentralSource(row);
  if (fatalSourceIssue) {
    issues.push(isErrorStatus(row?.status) && row?.message ? row.message : fatalSourceIssue);
    return issues;
  }
  if (isErrorStatus(row?.status)) {
    issues.push(row?.message || '이전 파일 확인 또는 실행이 실패했습니다. 파일 정보를 다시 읽어 확인하세요.');
    return issues;
  }
  const sourcePath = String(row?.sourcePath || '').trim();
  if (!sourcePath || !isAbsoluteWindowsPath(sourcePath) || !/\.rvt$/i.test(sourcePath)) {
    issues.push('원본 RVT 절대 경로를 확인해 주세요.');
  }
  const output = normalizedMode === 'worksets'
    ? effectiveWorksetTarget(row, true)
    : normalizedMode === 'ownership'
      ? effectiveOwnershipTarget(row)
      : String(row?.outputCentralPath || '').trim();
  if (!output) {
    issues.push(normalizedMode === 'worksets'
      ? '기존 센트럴 또는 연결된 센트럴 경로가 없습니다. 일반 RVT는 먼저 센트럴 파일을 생성하세요.'
      : normalizedMode === 'ownership'
        ? '기존 센트럴 또는 안전하게 확인된 연결 센트럴 경로가 없습니다.'
        : '새 센트럴 파일 경로를 입력해 주세요.');
  }
  else if (!isAbsoluteWindowsPath(output)) issues.push('절대 경로를 입력해 주세요.');
  else if (!/\.rvt$/i.test(output)) issues.push('출력 파일 확장자는 .rvt여야 합니다.');
  const requiresDifferentPath = normalizedMode === 'centralize' || normalizedMode === 'all';
  if (normalizedMode === 'worksets' && row?.missingConnectedCentral) {
    issues.push(row?.message || '연결된 기존 센트럴을 확인하지 못했습니다. 등록한 RVT의 센트럴 연결을 확인한 뒤 파일 정보를 다시 읽으세요.');
  }
  if (normalizedMode === 'ownership') {
    if (normalizeRowOperation(row?.operation) !== 'OWNERSHIP' ||
        String(row?.existingCentralOwnershipTargetKind || '') !== EXISTING_CENTRAL_OWNERSHIP_TARGET_KIND ||
        row?.ownershipWorkbookTrusted !== true) {
      issues.push('기존 센트럴 권한 적용은 현재 화면에서 Excel을 내보내 설정한 뒤 다시 불러온 행만 실행할 수 있습니다.');
    }
    if (row?.missingConnectedCentral || row?.isStandalone || (!row?.isCentral && !String(row?.centralPath || '').trim())) {
      issues.push('기존 센트럴 또는 안전하게 확인된 연결 센트럴이 없어 권한만 적용할 수 없습니다.');
    }
    if (row?.pinLevelGridElements && !row?.retainLevelGridWorksetOwnership && !row?.pinAndRetainLevelGridOwnership) {
      issues.push('본문 Level/Grid Pin은 Shared Levels and Grids Workset 권한 유지와 함께만 선택할 수 있습니다.');
    }
    if (!row?.retain3DViewOwnership && !row?.retainViewTemplateOwnership && !isUnifiedLevelGridOwnershipRequested(row)) {
      issues.push('적용할 권한 옵션을 하나 이상 선택해 주세요.');
    }
    if (normalizeStringList(row?.addWorksets).length) {
      issues.push('센트럴 저장 경로를 비운 기존 센트럴 권한 적용에서는 추가 웍셋을 함께 입력할 수 없습니다. 두 작업을 나누어 실행하세요.');
    }
  }
  if ((normalizedMode === 'centralize' || normalizedMode === 'all') &&
      !row?.pinAndRetainLevelGridOwnership &&
      (!!row?.retainLevelGridWorksetOwnership !== !!row?.pinLevelGridElements)) {
    issues.push('구버전 Grid/Level 권한 설정이 일부만 선택되어 있습니다. 보이는 그리드·레벨 핀 + 웍셋 권한 옵션을 다시 선택해 주세요.');
  }
  const protectedSources = [
    row?.sourcePath,
    row?.originalSourcePath,
    row?.centralPath,
    row?.originalCentralPath
  ].map(normalizePathKey).filter(Boolean);
  if (requiresDifferentPath && output && protectedSources.includes(normalizePathKey(output))) {
    issues.push('원본 RVT와 기존 연결 센트럴이 아닌 새 경로를 지정해 주세요.');
  }
  if (normalizedMode === 'worksets' || normalizedMode === 'all') {
    issues.push(...validateWorksetNameList(row?.addWorksets));
  }
  issues.push(...validate3DViewOwnership(row, normalizedMode));
  issues.push(...validateViewTemplateOwnership(row, normalizedMode));
  return issues;
}

function describeFatalCentralSource(row) {
  if (row?.isFamily) return '패밀리 문서는 처리할 수 없습니다.';
  if (row?.isCloud) return '등록한 원본 자체가 클라우드/서버 모델이면 이 기능에서 처리할 수 없습니다.';
  if (row?.isNewerVersion) return '현재 Revit보다 새 버전으로 저장된 RVT입니다.';
  return '';
}

function effectiveWorksetTarget(row, preferExistingCentral = false) {
  const existingCentral = row?.worksetTargetPath || row?.centralPath || row?.originalCentralPath || (row?.isCentral ? row?.sourcePath : '');
  return String(preferExistingCentral
    ? existingCentral
    : (row?.outputCentralPath || existingCentral || '')
  ).trim();
}

function effectiveOwnershipTarget(row) {
  return String(
    row?.resolvedOwnershipCentralPath ||
    row?.centralPath ||
    row?.originalCentralPath ||
    (row?.isCentral ? row?.sourcePath : '') ||
    ''
  ).trim();
}

function showCompletedDialog(state, ok, summary) {
  const derived = deriveCompletionSummary(state.rows, summary);
  const actions = [];
  // 보이는 화면은 통합 centralize 상태를 유지하므로 완료 직후의 실제 실행
  // mode를 기준으로 폴더 동작을 정한다. 그렇지 않으면 기존 센트럴 권한
  // 실행 뒤에도 빈 새-출력 경로를 찾게 된다.
  const completedMode = String(state?.lastMode || '').trim().toLowerCase();
  const existingCentralMode = completedMode === 'worksets' || completedMode === 'ownership';
  const folder = existingCentralMode ? firstWorksetTargetFolder(state.rows) : firstOutputFolder(state.rows);
  if (folder) {
    actions.push({
      label: existingCentralMode ? '센트럴 폴더 열기' : '출력 폴더 열기',
      onClick: () => post('centralworkset:open-output-folder', { path: folder })
    });
  }
  showCompletionSummaryDialog({
    title: ok ? '센트럴/웍셋 작업 완료' : '센트럴/웍셋 작업 결과',
    message: ok ? `${runModeLabel(state.lastMode)}을 완료했습니다.` : '일부 파일을 처리하지 못했습니다. 아래 결과와 행별 메시지를 확인하세요.',
    summaryItems: [
      { label: '대상 파일', value: `${derived.totalCount}개` },
      { label: '성공', value: `${derived.successCount}개` },
      { label: '실패', value: `${derived.failedCount}개` },
      ...(derived.manualVerificationCount ? [{ label: '수동 확인', value: `${derived.manualVerificationCount}개` }] : []),
      { label: '생성 센트럴', value: `${derived.centralCreatedCount}개` },
      { label: '추가 웍셋', value: `${derived.createdWorksetCount}개` },
      { label: '건너뛴 웍셋', value: `${derived.skippedWorksetCount}개` },
      ...(derived.requestedOwnershipViewCount
        ? [{ label: '3D 뷰 권한', value: `${derived.owned3DViewCount}/${derived.requestedOwnershipViewCount}개` }]
        : []),
      ...(derived.requestedViewTemplateOwnershipCount
        ? [{ label: '3D 템플릿 ViewWorkset', value: `${derived.ownedViewTemplateCount}/${derived.requestedViewTemplateOwnershipCount}개 · Owner/Editable 검증` }]
        : []),
      ...(derived.requestedLevelGridOwnershipRowCount
        ? [{ label: '레벨·그리드 Pin + Shared Levels and Grids', value: `Pin ${derived.ownedLevelGridCount}개 · Workset ${derived.ownedLevelGridWorksetCount}/${derived.requestedLevelGridOwnershipRowCount}개 Owner/Editable 검증` }]
        : [])
    ],
    notes: [
      derived.manualVerificationCount
        ? `수동 확인 ${derived.manualVerificationCount}개는 저장 결과를 자동 판정할 수 없습니다. 원본과 대상 RVT를 직접 확인한 뒤 파일을 새로 등록하세요.`
        : '',
      derived.retryableFailedCount
        ? `그 밖의 실패 ${derived.retryableFailedCount}개는 행 메시지를 확인하고 파일 정보를 다시 읽은 뒤 재실행하세요.`
        : ''
    ].filter(Boolean),
    actions,
    showExport: false,
    confirmLabel: '확인'
  });
}

function deriveCompletionSummary(rows, summary) {
  const safeRows = arrayOf(rows);
  const totalCount = numberFrom(summary, ['totalCount', 'rowCount', 'fileCount'], safeRows.length);
  const failedByRows = safeRows.filter((row) => isErrorStatus(row.status)).length;
  const manualVerificationCount = safeRows.filter((row) => row.requiresManualVerification).length;
  const successByRows = safeRows.filter((row) => row.status && !isErrorStatus(row.status)).length;
  const failedCount = numberFrom(summary, ['failedCount', 'failureCount', 'errorCount'], failedByRows);
  return {
    totalCount,
    successCount: numberFrom(summary, ['successCount', 'completedCount', 'succeededCount'], successByRows || Math.max(0, totalCount - failedByRows)),
    failedCount,
    manualVerificationCount,
    retryableFailedCount: Math.max(0, failedCount - manualVerificationCount),
    centralCreatedCount: numberFrom(summary, ['centralCreatedCount', 'createdCentralCount', 'centralCount'], safeRows.filter((row) => row.createdCentral).length),
    createdWorksetCount: numberFrom(summary, ['createdWorksetCount', 'worksetCreatedCount'], safeRows.reduce((sum, row) => sum + row.createdWorksets.length, 0)),
    skippedWorksetCount: numberFrom(summary, ['skippedWorksetCount', 'worksetSkippedCount'], safeRows.reduce((sum, row) => sum + row.skippedWorksets.length, 0)),
    requestedOwnershipViewCount: safeRows.reduce((sum, row) => sum + (row.retain3DViewOwnership ? row.ownership3DViewNames.length : 0), 0),
    owned3DViewCount: safeRows.reduce((sum, row) => sum + row.owned3DViewNames.length, 0),
    requestedViewTemplateOwnershipCount: safeRows.reduce(
      (sum, row) => sum + (row.retainViewTemplateOwnership ? row.ownershipViewTemplateNames.length : 0),
      0
    ),
    ownedViewTemplateCount: safeRows.reduce((sum, row) => sum + row.ownedViewTemplateNames.length, 0),
    requestedLevelGridOwnershipRowCount: safeRows.filter(
      (row) => !isSkippedRow(row) && (
        normalizeRowOperation(row.operation) === 'OWNERSHIP'
          ? row.retainLevelGridWorksetOwnership
          : row.pinAndRetainLevelGridOwnership
      )
    ).length,
    ownedLevelGridCount: toNonNegativeInteger(numberFrom(
      summary,
      ['ownedLevelGridCount'],
      safeRows.reduce((sum, row) => sum + toNonNegativeInteger(row.ownedLevelGridCount), 0)
    )),
    ownedLevelGridWorksetCount: toNonNegativeInteger(numberFrom(
      summary,
      ['ownedLevelGridWorksetCount'],
      safeRows.reduce((sum, row) => sum + normalizeExactNameList(row.ownedLevelGridWorksetNames).length, 0)
    ))
  };
}

function beginHostRequest(state, kind, eventName, payload = {}, options = {}) {
  if (!state || state.busy || state.activeRequestId) return '';
  state.requestSequence = (Number(state.requestSequence) || 0) + 1;
  const safeKind = String(kind || 'request').replace(/[^a-z0-9-]+/gi, '-').toLowerCase();
  const requestId = `${state.instanceId}:${safeKind}:${state.requestSequence}`;

  state.activeRequestId = requestId;
  state.activeRequestKind = safeKind;
  state.busy = true;
  state.operationOwner = options.owner === true;
  state.progressVisible = options.progress === true;
  state.runRequested = options.runRequested === true;
  state.exportRequested = options.exportRequested === true;
  state.awaitingWorkbookPick = options.awaitingWorkbookPick === true;
  syncHeaderActions(state);
  renderRunPanel(state);

  post('centralworkset:client-busy', { busy: true, requestId, kind: safeKind });
  post(eventName, { ...(payload || {}), requestId });
  return requestId;
}

function matchActiveRequest(state, payload, expectedKinds = []) {
  if (!state?.activeRequestId || !state.activeRequestKind) return null;
  const allowed = new Set(arrayOf(expectedKinds).map((value) => String(value || '').trim().toLowerCase()).filter(Boolean));
  if (allowed.size && !allowed.has(state.activeRequestKind)) return null;

  const responseId = String(pick(payload, 'requestId', 'RequestId') || '').trim();
  if (responseId) {
    if (responseId !== state.activeRequestId) return null;
  } else if (window.chrome?.webview?.postMessage) {
    return null;
  }

  return { id: state.activeRequestId, kind: state.activeRequestKind };
}

function finishActiveRequest(state, request) {
  if (!state || !request || request.id !== state.activeRequestId) return false;
  const completedKind = state.activeRequestKind;
  state.activeRequestId = '';
  state.activeRequestKind = '';
  state.busy = false;
  state.progressVisible = false;
  state.operationOwner = false;
  state.runRequested = false;
  if (completedKind === 'export-template') state.exportRequested = false;
  if (completedKind === 'pick-workbook') {
    state.awaitingWorkbookPick = false;
    state.workbookReplaceConfirmed = false;
  }
  ProgressDialog.hide();
  syncHeaderActions(state);
  post('centralworkset:client-busy', { busy: false, requestId: request.id, kind: completedKind });
  return true;
}

function syncHeaderActions(state) {
  const mode = currentOperationMode(state);
  if (state.ui.centralModeButton) state.ui.centralModeButton.disabled = state.busy || isCreateMode(mode);
  if (state.ui.worksetModeButton) state.ui.worksetModeButton.disabled = state.busy || mode === 'worksets';
  if (state.ui.closeWindowButton) {
    state.ui.closeWindowButton.disabled = state.busy;
    state.ui.closeWindowButton.textContent = state.busy
      ? '작업 진행 중 · 숨기기 잠금'
      : '작업창 숨기기 (설정 유지)';
  }
}

function showCentralProgress(title, subtitle) {
  ProgressDialog.setActions({ onCancel: null, onSkip: null });
  ProgressDialog.show(title, subtitle);
}

function buildStepHeader(number, title, description) {
  const header = div('centralworkset-step-header');
  const numberEl = div('centralworkset-step-number');
  numberEl.textContent = number;
  const copy = div('centralworkset-step-copy');
  const titleEl = document.createElement('h3');
  titleEl.textContent = title;
  const descriptionEl = document.createElement('p');
  descriptionEl.textContent = description;
  copy.append(titleEl, descriptionEl);
  header.append(numberEl, copy);
  return header;
}

function buildEmptyState(title, message) {
  const empty = div('centralworkset-empty');
  const titleEl = document.createElement('strong');
  titleEl.textContent = title;
  const messageEl = document.createElement('span');
  messageEl.textContent = message;
  empty.append(titleEl, messageEl);
  return empty;
}

function actionButton(label, onClick, kind = 'secondary') {
  const button = document.createElement('button');
  button.type = 'button';
  const kinds = String(kind || 'secondary').split(/\s+/).filter(Boolean);
  button.className = `btn ${kinds.includes('primary') ? 'btn--primary' : (kinds.includes('ghost') ? 'centralworkset-btn--ghost' : 'btn--secondary')}`;
  if (kinds.includes('strong')) button.classList.add('centralworkset-btn--strong');
  button.textContent = label;
  button.addEventListener('click', onClick);
  return button;
}

function stat(label, value) {
  const item = div('centralworkset-stat');
  const labelEl = document.createElement('span');
  labelEl.textContent = label;
  const valueEl = document.createElement('strong');
  valueEl.textContent = value;
  item.append(labelEl, valueEl);
  return item;
}

function readinessRow(label, ready, detail) {
  const item = div(`centralworkset-readiness-row ${ready ? 'is-ready' : 'is-pending'}`);
  const labelEl = document.createElement('span');
  labelEl.textContent = label;
  const detailEl = document.createElement('strong');
  detailEl.textContent = detail;
  item.append(labelEl, detailEl);
  return item;
}

function statusLabel(status) {
  const value = String(status || '').trim();
  if (!value) return '대기';
  if (isErrorStatus(value)) return '실패';
  if (/skip|ignored|건너/i.test(value)) return '건너뜀';
  if (/success|complete|created|done|ok|changed|성공|완료|생성/i.test(value)) return '완료';
  return value;
}

function outputPathHint(row) {
  if (!String(row?.outputCentralPath || '').trim()) {
    const target = effectiveOwnershipTarget(row);
    return target
      ? `비워 둠 · 새 파일을 만들지 않고 기존 센트럴에 권한 적용: ${target}`
      : '비워 둠 · 기존 센트럴 권한 적용을 선택했습니다. 연결 센트럴을 확인할 수 있는 RVT가 필요합니다.';
  }
  if (isUnknownSourceType(row)) {
    return 'RVT 기본 정보를 미리 확인하지 못했습니다. 실행 시 Detach(Preserve)로 열어 실제 유형과 웍셋을 판정한 뒤 새 센트럴로 저장합니다.';
  }
  if (row.isCentral) return '기존 센트럴은 웍셋 유지 Detach 후 이 경로에 새 센트럴로 저장됩니다.';
  if (row.isLocal) return '등록한 로컬 파일 자체를 웍셋 유지 Detach한 뒤 이 경로에 새 센트럴로 저장합니다.';
  return '일반 RVT는 워크셰어링을 활성화한 뒤 이 경로에 센트럴로 저장합니다.';
}

function isUnknownSourceType(row) {
  return String(row?.sourceType || '').trim().toLowerCase() === 'unknown';
}

function normalizeActiveDocument(raw) {
  if (!raw || typeof raw !== 'object') return { name: '', path: '', canUse: false };
  return {
    name: String(pick(raw, 'name', 'Name', 'title', 'Title') || ''),
    path: String(pick(raw, 'path', 'Path') || ''),
    canUse: pick(raw, 'canUse', 'CanUse') !== false,
    isWorkshared: !!pick(raw, 'isWorkshared', 'IsWorkshared'),
    isCentral: !!pick(raw, 'isCentral', 'IsCentral'),
    isLocal: !!pick(raw, 'isLocal', 'IsLocal')
  };
}

function normalizeStringList(value) {
  if (Array.isArray(value)) return distinctNames(value);
  if (value == null) return [];
  return parseWorksets(String(value));
}

function normalizeExactNameList(value) {
  if (Array.isArray(value)) return distinctExactNames(value);
  if (value == null) return [];
  return parseExactLineNames(String(value));
}

function parseExactLineNames(value) {
  return distinctExactNames(String(value || '').split(/\r?\n|\r/));
}

function distinctExactNames(values) {
  const result = [];
  const seen = new Set();
  arrayOf(values).forEach((value) => {
    const name = String(value == null ? '' : value).trim();
    if (!name || seen.has(name)) return;
    seen.add(name);
    result.push(name);
  });
  return result;
}

function parseWorksets(value) {
  return distinctNames(String(value || '').split(/[;\r\n]+/));
}

function distinctNames(values) {
  const result = [];
  const seen = new Set();
  arrayOf(values).forEach((value) => {
    const name = String(value == null ? '' : value).trim();
    const key = normalizeNameKey(name);
    if (!name || seen.has(key)) return;
    seen.add(key);
    result.push(name);
  });
  return result;
}

function normalizeNameKey(value) {
  return String(value || '').trim();
}

function validateWorksetNameList(value) {
  const names = normalizeStringList(value);
  const issues = [];
  const invalid = names.find((name) => INVALID_WORKSET_CHARACTERS.test(name));
  if (invalid) {
    issues.push(`웍셋 이름에 사용할 수 없는 문자가 있습니다: ${invalid}`);
  }
  return issues;
}

function normalizePathList(value) {
  const seen = new Set();
  const result = [];
  arrayOf(value).forEach((raw) => {
    const path = String(raw || '').trim();
    const key = normalizePathKey(path);
    if (!path || !key || seen.has(key) || !/\.rvt$/i.test(path)) return;
    seen.add(key);
    result.push(path);
  });
  return result;
}

function normalizePathKey(value) {
  return String(value || '').trim().replace(/\//g, '\\').replace(/\\+$/g, '').toLowerCase();
}

function isAbsoluteWindowsPath(value) {
  const path = String(value || '').trim().replace(/\//g, '\\');
  return /^[A-Za-z]:\\/.test(path) || /^\\\\[^\\]+\\[^\\]+/.test(path);
}

function isAbsoluteWindowsRvtPath(value) {
  const path = String(value || '').trim();
  return isAbsoluteWindowsPath(path) && /\.rvt$/i.test(path);
}

function joinWindowsPath(folder, name) {
  const left = String(folder || '').trim().replace(/[\\/]+$/g, '');
  const right = String(name || '').trim().replace(/^[\\/]+/g, '');
  return left && right ? `${left}\\${right}` : left || right;
}

function firstOutputFolder(rows) {
  const path = arrayOf(rows).map((row) => row.outputCentralPath).find(Boolean);
  if (!path) return '';
  const normalized = String(path).replace(/\//g, '\\');
  const index = normalized.lastIndexOf('\\');
  return index > 0 ? normalized.slice(0, index) : '';
}

function firstWorksetTargetFolder(rows) {
  const path = arrayOf(rows)
    .map((row) => row?.resolvedOwnershipCentralPath || effectiveWorksetTarget(row, true))
    .find(Boolean);
  if (!path) return '';
  const normalized = String(path).replace(/\//g, '\\');
  const index = normalized.lastIndexOf('\\');
  return index > 0 ? normalized.slice(0, index) : '';
}

function fileName(path) {
  const parts = String(path || '').split(/[/\\]/);
  return parts[parts.length - 1] || '';
}

function findRow(state, rowId, sourcePath) {
  const id = String(rowId || '').trim();
  const sourceKey = normalizePathKey(sourcePath);
  if (id) {
    return state.rows.find((row) => row.rowId === id) || null;
  }
  return state.rows.find((row) => sourceKey && normalizePathKey(row.sourcePath) === sourceKey) || null;
}

function findMatchingRawRow(rows, raw) {
  const index = findMatchingRowIndex(rows, raw);
  return index >= 0 ? rows[index] : null;
}

function findMatchingRowIndex(rows, raw, options = {}) {
  const id = String(pick(raw, 'rowId', 'RowId') || '').trim();
  if (id) {
    const exactIndex = rows.findIndex((row) => row.rowId === id);
    if (exactIndex >= 0) return exactIndex;
  }
  const identityKind = normalizeRowIdentity(
    options.identityKind || pick(raw, 'rowIdentity', 'RowIdentity')
  );
  if (identityKind === ROW_IDENTITY_ROW_ID) return -1;
  const sourceKey = normalizePathKey(pick(raw, 'sourcePath', 'SourcePath'));
  const sourceMatches = findSourceMatchingRowIndexes(rows, sourceKey);
  return sourceMatches.length === 1 ? sourceMatches[0] : -1;
}

function findSourceMatchingRowIndexes(rows, sourcePathOrKey) {
  const sourceKey = normalizePathKey(sourcePathOrKey);
  if (!sourceKey) return [];
  const result = [];
  arrayOf(rows).forEach((row, index) => {
    if (normalizePathKey(row?.sourcePath) === sourceKey) result.push(index);
  });
  return result;
}

function dedupeRows(rows) {
  const result = [];
  const seenIdentityKeys = new Set();
  const seenRowIds = new Set();
  arrayOf(rows).forEach((row) => {
    if (!row || typeof row !== 'object') return;
    let rowId = String(row.rowId || '').trim();
    let rowIdKey = normalizeRowIdKey(rowId);
    if (!rowId || seenRowIds.has(rowIdKey)) {
      rowId = makeLocalRowId(row.sourcePath);
      row.rowId = rowId;
      rowIdKey = normalizeRowIdKey(rowId);
    }
    seenRowIds.add(rowIdKey);
    const identityKind = normalizeRowIdentity(row.rowIdentity);
    row.rowIdentity = identityKind;
    const sourceKey = normalizePathKey(row.sourcePath);
    // Manual/active/file-picker registration stays source based. Excel rows are the only
    // rows allowed to share a source and therefore use their workbook RowId as identity.
    const key = identityKind === ROW_IDENTITY_ROW_ID
      ? `id:${rowId}`
      : (sourceKey ? `source:${sourceKey}` : `id:${rowId}`);
    if (seenIdentityKeys.has(key)) return;
    seenIdentityKeys.add(key);
    result.push(row);
  });
  return result;
}

function normalizeRowIdentity(value) {
  const normalized = String(value || '').trim().toLowerCase();
  return normalized === 'rowid' || normalized === 'workbook' || normalized === 'excel' || normalized === 'import'
    ? ROW_IDENTITY_ROW_ID
    : ROW_IDENTITY_SOURCE;
}

function normalizeRowIdKey(value) {
  return String(value || '').trim().toLowerCase();
}

function makeLocalRowId(path) {
  localRowSequence += 1;
  const key = normalizePathKey(path).replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(-48);
  return `local-${Date.now().toString(36)}-${localRowSequence.toString(36)}-${key || 'active'}`;
}

function toBoolean(value, fallback = false) {
  if (value == null) return !!fallback;
  if (typeof value === 'string') return /^(true|1|yes|y)$/i.test(value.trim());
  return !!value;
}

function toNonNegativeInteger(value, fallback = 0) {
  const candidate = value == null ? fallback : value;
  const number = Number(candidate);
  return Number.isFinite(number) ? Math.max(0, Math.trunc(number)) : 0;
}

function normalizeServiceAction(value) {
  return String(value || '').trim().toUpperCase() === 'SKIP' ? 'SKIP' : 'APPLY';
}

function isSkippedRow(row) {
  return normalizeServiceAction(row?.action) === 'SKIP';
}

function clampPercent(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return 0;
  return Math.max(0, Math.min(100, number <= 1 && number > 0 ? number * 100 : number));
}

function runModeLabel(mode) {
  if (mode === 'centralize') return '센트럴 파일 생성';
  if (mode === 'worksets') return '웍셋 추가';
  if (mode === 'all') return '센트럴 생성 + 웍셋 추가';
  if (mode === 'ownership') return '기존 센트럴 권한 적용';
  if (mode === 'inspect') return 'RVT 정보 확인';
  if (mode === 'import') return 'Excel 불러오기';
  if (mode === 'export') return 'Excel 양식 내보내기';
  return '센트럴/웍셋 작업';
}

function isErrorStatus(value) {
  return /error|failed|failure|fail|실패|오류/i.test(String(value || ''));
}

function isWarningStatus(value) {
  return /warning|warn|경고/i.test(String(value || ''));
}

function isSuccessfulStatus(value) {
  return /success|succeeded|complete|created|done|ok|changed|성공|완료|생성/i.test(String(value || ''));
}

function numberFrom(object, keys, fallback = 0) {
  for (const key of keys) {
    const value = Number(object?.[key] ?? object?.[pascalCase(key)]);
    if (Number.isFinite(value)) return value;
  }
  return Number(fallback) || 0;
}

function pascalCase(value) {
  const text = String(value || '');
  return text ? text[0].toUpperCase() + text.slice(1) : text;
}

function pick(object, ...keys) {
  if (!object || typeof object !== 'object') return undefined;
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(object, key)) return object[key];
  }
  return undefined;
}

function arrayOf(value) {
  if (Array.isArray(value)) return value;
  if (value == null) return [];
  if (typeof value === 'string') return [value];
  if (typeof value[Symbol.iterator] === 'function') return Array.from(value);
  return [value];
}

function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
