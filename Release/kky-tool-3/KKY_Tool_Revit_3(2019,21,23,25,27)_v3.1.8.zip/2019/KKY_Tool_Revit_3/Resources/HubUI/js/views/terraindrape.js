import { onHost, post } from '../core/bridge.js';

export const TERRAIN_DRAPE_EVENTS = Object.freeze({ init: 'terraindrape:init', supportsInit: 'terraindrape:supports:init', apply: 'terraindrape:apply', detach: 'terraindrape:detach', context: 'terraindrape:context', supports: 'terraindrape:supports', result: 'terraindrape:result', error: 'terraindrape:error' });
let serial = 0;
let activeCleanup = null;

// Settings controls are created once. Input, host echoes and IME never replace them.
export function renderTerrainDrape(root, options = {}) {
  activeCleanup?.();
  const page = document.createElement('div');
  page.className = 'terraindrape-page feature-shell';
  page.innerHTML = `
    <header class="feature-header"><div class="feature-heading">
      <span class="feature-kicker">모델링 · 지형</span><h2 class="feature-title">지형 연동 (TEST)</h2>
      <p class="feature-sub">본체 대지에 보완 지형을 연결하고, 그 위의 도로 바닥까지 순서대로 맞춥니다.</p>
    </div></header>
    <section class="terraindrape-card terraindrape-settings" data-terrain-scroll-key="settings">
      <h3>01 · 본체 대지와 도로 높이 설정</h3>
      <p>본체 대지는 기준으로 사용하며 변경하지 않습니다. 연결된 보완 지형과 도로를 갱신합니다.</p>
      <div class="terraindrape-flow" aria-label="연동 순서"><span>본체 대지</span><b aria-hidden="true">→</b><span>보완 지형</span><b aria-hidden="true">→</b><span>도로 바닥</span></div>
      <div class="terraindrape-fields">
        <label class="terraindrape-wide">본체 대지<select data-ref="terrain" data-terrain-focus-key="terrain"><option value="">지형을 불러오는 중입니다.</option></select></label>
        <label>도로 상부 면 높이 차이 (mm)<input type="text" inputmode="decimal" value="0" data-ref="offset" data-terrain-focus-key="offset" autocomplete="off"><small>일반 바닥과 도로 역할에 적용합니다. 양수는 위, 음수는 아래입니다. 보완 접합 높이와 [보완+도로 함께] 내부에는 더하지 않습니다.</small></label>
        <label>형상 점 간격 (mm)<input type="text" inputmode="decimal" value="1000" data-ref="spacing" data-terrain-focus-key="spacing" autocomplete="off"><small>100~10,000 mm로 입력하세요. 보완 지형과 바닥은 각각 객체당 최대 2,500개 점을 처리합니다.</small></label>
      </div>
      <label class="terraindrape-check"><input type="checkbox" checked data-ref="auto" data-terrain-focus-key="auto"><span>지형 편집 완료 직후 보완 지형과 도로 자동 갱신</span></label>
      <div class="terraindrape-note">보완 지형의 접합 높이와 도로 바닥의 형상을 변경합니다. 기존 바닥 형상 편집은 새 형상으로 바뀌며, 본체 대지와 하부 터널 형상은 변경하지 않습니다.</div>
      <p class="terraindrape-validation" data-ref="validation" role="status"></p>
    </section>
    <section class="terraindrape-card terraindrape-targets">
      <div class="terraindrape-card-head"><div><h3>02 · 보완 지형과 도로 선택</h3><p>Revit에서 지형·일반 바닥 또는 인플레이스 객체를 선택한 뒤 [선택 가져오기]를 누르세요. 보완 대상은 최대 10개, 도로는 최대 50개입니다.</p></div><button type="button" class="btn btn-outline" data-ref="refresh">선택 가져오기</button></div>
      <div class="terraindrape-document" data-ref="document"></div>
      <h4 class="terraindrape-list-title">보완 지형 <span data-ref="patchCount"></span></h4>
      <p class="terraindrape-selection-note">본체로 고른 지형은 보완 대상에서 제외됩니다. 보완 지형 없이 도로 바닥만 맞출 수도 있습니다.</p>
      <div class="terraindrape-target-list" data-ref="patches" data-terrain-scroll-key="patches"></div>
      <h4 class="terraindrape-list-title">도로 바닥 <span data-ref="floorCount"></span></h4>
      <div class="terraindrape-target-list" data-ref="floors" data-terrain-scroll-key="floors"></div>
      <h4 class="terraindrape-list-title">인플레이스 역할 지정 <span data-ref="inPlaceCount"></span></h4>
      <p class="terraindrape-selection-note">보완 입체, 도로 또는 보완+도로 함께를 지정하세요. 함께 처리할 때는 기준 보완 입체를 고르세요. 원본을 보존하고 숨긴 뒤 별도 일반 모델 입체를 갱신하며, 원본 압출을 직접 편집하지 않습니다.</p>
      <div class="terraindrape-target-list" data-ref="inPlace" data-terrain-scroll-key="inPlace"></div>
    </section>
    <section class="terraindrape-card terraindrape-supports">
      <h3>03 · 하부면 맞춤 (선택 사항)</h3>
      <label class="terraindrape-check"><input type="checkbox" data-ref="supportEnabled" data-terrain-focus-key="supportEnabled"><span>하부면 맞춤 · 상부 대지와 선택한 하부 기준 사이에 입체 생성</span></label>
      <div class="terraindrape-card-head"><p>Revit에서 하부 기준 바닥 또는 배치된 패밀리(최대 50개)를 선택하고 가져오세요. 위에서 등록한 보완 지형·도로 선택은 유지됩니다.</p><button type="button" class="btn btn-outline" data-ref="supportRefresh">하부 기준 가져오기</button></div>
      <h4 class="terraindrape-list-title">하부 기준 <span data-ref="supportCount"></span></h4>
      <p class="terraindrape-selection-note">보완 지형 상부에서 수직 아래로 내려가며 선택한 기준의 윗면 중 처음 만나는 면에 맞춥니다. 직선 외곽·개구부 경계를 가진 평면 윗면을 지원합니다. 도로 대상과 같은 바닥은 사용할 수 없습니다.</p>
      <div class="terraindrape-target-list" data-ref="supports" data-terrain-scroll-key="supports"></div>
    </section>
    <section class="terraindrape-card terraindrape-run">
      <h3>연동 적용</h3><p data-ref="summary">보완 지형 또는 도로 바닥을 불러오세요.</p>
      <button type="button" class="btn btn-primary" data-ref="apply">지형 연동 적용</button>
      <button type="button" class="btn btn-outline" data-ref="detach" title="선택한 객체가 속한 보완 지형·도로 그룹 전체의 연결을 해제합니다. 현재 형상은 유지됩니다.">자동 갱신 연결 해제</button>
      <p class="terraindrape-status" data-ref="status" role="status" aria-live="polite"></p>
      <details class="terraindrape-guide"><summary>사용 방법과 적용 범위</summary><ol>
        <li>본체와 별개의 보완 지형을 작성하고, 도로는 가변 두께 층이 없는 일반 바닥(Floor)으로 작성하세요.</li>
        <li>보완 지형과 도로를 Revit에서 선택한 뒤 선택 목록을 가져오세요.</li>
        <li>본체 대지를 별도로 고르고 연동을 적용하세요.</li>
      </ol>
      <p>보완 지형은 경계 전체가 본체에 닿아야 합니다. 보완 지형 내부에서는 본체에 면이 없는 구간을 덮을 수 있습니다. 접합부의 높이를 연결하며, 경사까지 매끄럽게 이어지는 것은 보장하지 않습니다.</p>
      <p>인플레이스 내부의 각 솔리드는 평면 면과 직선 경계로 구성되고, 각 위치에서 수직으로 상부·하부 면을 하나씩 만나는 형상을 지원합니다. 도로 역할은 원본의 수직 두께를 유지합니다. 보완 입체는 하부면 맞춤을 켜면 선택한 하부 기준을 사용하고, 끄면 원본의 수직 두께를 유지합니다.</p>
      <p>인플레이스의 역할을 바꾸려면 먼저 연결을 해제하세요. 연결 해제는 화면에서 임시로 바꾼 역할과 관계없이 저장된 역할로 그룹 전체에 적용합니다. 생성 입체를 다시 선택하면 보존한 원본 인플레이스로 연결됩니다.</p>
      <p>한 인플레이스에 보완 입체와 도로가 함께 있으면 [보완+도로 함께]를 선택하세요. 솔리드가 여러 개이면 기준 보완 입체를 직접 고릅니다. 기준 입체를 본체와 연결하고, 나머지는 같은 평면 위치의 높이 변화만큼 이동해 상대 높이와 수직 두께를 유지합니다. 나머지 입체가 기준 입체 영역 밖에 있으면 적용하지 못합니다.</p>
      <p>하나로 합쳐진 솔리드는 전체 외형을 기준으로 처리하며 내부 도로층을 자동으로 분리하지 않습니다. 연결한 뒤 역할이나 기준 보완 입체를 바꾸려면 먼저 연결을 해제하세요.</p>
      <p>[보완+도로 함께] 내부 도로에는 도로 높이 차이를 별도로 더하지 않습니다. 하부면 맞춤을 켜면 기준 보완 입체의 두께는 하부 기준에 따라 달라지며, 나머지 입체의 수직 두께를 유지합니다. 원본 형상을 바꿨으면 선택 목록을 다시 가져와 기준 입체를 확인하세요.</p>
      <p>Revit 2019·2021·2023은 지형면(Toposurface), 2025·2027은 지형 솔리드(Toposolid)를 사용할 수 있습니다. 지형면에는 실제 두께가 없습니다. 도로 바닥 유형의 재료층·두께 설정은 유지하지만, 급경사 형상 편집에서는 실제 단면 두께에 편차가 생길 수 있습니다.</p>
      <p>하부면 맞춤을 켜려면 보완 지형과 하부 기준이 필요합니다. 현재 프로젝트의 바닥 또는 배치 패밀리 중 실제 솔리드의 평면 윗면을 읽을 수 있고, 외곽·개구부 경계가 모두 직선인 형상만 지원합니다. 곡면 윗면이나 호·스플라인 경계가 있는 윗면, 메시만 있는 형상은 지원하지 않습니다. 선택하지 않은 객체는 탐색하지 않으며, 아래에서 기준 면을 만나지 못하면 적용하지 못합니다.</p>
      <p>하부면 맞춤은 일반 모델 입체를 생성합니다. 원래 보완 지형은 상부 형상 조절 기준으로 보관하고 화면에서 숨깁니다. 다음 선택에서는 생성 입체를 가져오면 원래 보완 지형에 연결됩니다. 본체 대지와 하부 기준 객체는 변경하지 않습니다.</p>
      <p>연결 해제는 생성 입체와 원본의 현재 형상을 유지합니다. 지형(Topo) 보완 대상은 하부면 맞춤을 끄고 그룹 전체를 다시 적용하면 생성 입체를 제거하고 원래 지형을 표시합니다. 인플레이스 보완 대상은 하부면 맞춤을 꺼도 별도 입체로 갱신합니다. 선택 가져오기는 기존 연결에 저장된 하부 기준을 다시 불러옵니다.</p>
      <p>자동 갱신은 KKY Tool이 로드된 상태에서 지형 편집을 완료하면 반영됩니다. 포인트를 움직이는 중의 실시간 미리보기는 아닙니다.</p>
      <p>도로 바닥의 경계를 수정했으면 같은 그룹의 보완 지형과 도로를 모두 다시 선택하고 적용하세요. 보완 지형 자체의 평면 경계나 기준 형상을 바꾸려면 먼저 그룹 연결을 해제하고, 형상을 수정한 뒤 새로 연결하세요.</p>
      <p>보완 지형과 바닥은 각각 객체당 최대 2,500개 점을 처리합니다. 한도를 초과한 보완 지형은 영역을 나누거나 점을 정리하세요. 도로는 영역을 나누거나 점 간격을 늘려 다시 적용하세요.</p>
      <p>이미 연결된 그룹을 다시 적용하려면 같은 그룹의 보완 지형과 도로를 모두 선택하세요. 일부만 선택한 재적용은 거절됩니다. 연결 해제는 선택한 객체가 속한 그룹 전체에 적용하며 현재 형상을 유지합니다. 보완 지형 없는 개별 바닥 연결은 바닥별로 처리합니다.</p>
      <p>본체 편집과 뒤따르는 보완 지형·도로 자동 갱신은 별도의 실행 취소 항목입니다. 모두 되돌리려면 순서대로 두 항목을 취소하세요. 실행 취소·다시 실행 중에는 자동으로 재적용하지 않습니다.</p>
      <p>실패 사유는 결과 또는 새로 가져온 목록에서 확인하세요. 자동 갱신이 중단된 대상은 원인을 수정하고 다시 적용하세요. Revit 링크 안의 객체는 지원하지 않습니다.</p></details>
    </section>
    <section class="terraindrape-card terraindrape-results" hidden data-ref="results"><h3>처리 결과</h3><div data-ref="resultRows" class="terraindrape-result-list" data-terrain-scroll-key="results"></div></section>`;
  root.replaceChildren(page);
  const ui = Object.fromEntries(Array.from(page.querySelectorAll('[data-ref]')).map(node => [node.dataset.ref, node]));
  const state = { documentKey: '', document: null, contextRequestId: '', terrains: [], patches: [], floors: [], inPlace: [], supports: [], targetSignature: '', supportModeDirty: false, supported: false, pending: null, busy: false, invalidated: false, destroyed: false };
  const inPlaceNodes = new Map();
  const disposers = [];
  const send = options.post || post;
  const listen = (node, event, handler) => { node.addEventListener(event, handler); disposers.push(() => node.removeEventListener(event, handler)); };
  const id = action => `terraindrape-${Date.now()}-${++serial}-${action}`;
  const number = control => control.value.trim() === '' ? NaN : Number(control.value.trim());
  const validSettings = () => Number.isFinite(number(ui.offset)) && Math.abs(number(ui.offset)) <= 100000 && Number.isFinite(number(ui.spacing)) && number(ui.spacing) >= 100 && number(ui.spacing) <= 10000;
  const active = () => !state.destroyed && page.isConnected;
  const terrainPatches = () => state.patches.filter(patch => patch.uniqueId !== ui.terrain.value);
  const targetPatches = (savedRoles = false) => [...terrainPatches(), ...state.inPlace.filter(item => ['patch', 'combined'].includes(savedRoles ? item.role : item.selectedRole))];
  const targetFloors = (savedRoles = false) => [...state.floors, ...state.inPlace.filter(item => (savedRoles ? item.role : item.selectedRole) === 'road')];

  function update() {
    const valid = validSettings();
    const patches = targetPatches();
    const floors = targetFloors();
    const roleError = state.inPlace.some(item => !['patch', 'road', 'combined'].includes(item.selectedRole)) ? '각 인플레이스 객체의 역할을 지정하세요.' : state.inPlace.some(item => item.geometryError || !item.geometryToken) ? '인플레이스 형상을 읽지 못했습니다. 목록의 사유를 확인하고 선택 목록을 다시 가져오세요.' : state.inPlace.some(item => item.linked && (item.role !== item.selectedRole || (item.role === 'combined' && item.referencePartKey !== item.selectedReferencePartKey))) ? '연결된 인플레이스의 역할이나 기준 입체를 바꾸려면 먼저 연결을 해제하세요.' : state.inPlace.some(item => item.selectedRole === 'combined' && !item.parts.some(part => part.key === item.selectedReferencePartKey)) ? '보완+도로 함께 처리할 인플레이스의 기준 보완 입체를 선택하세요.' : '';
    const supportError = !ui.supportEnabled.checked ? '' : !patches.length ? '하부면 맞춤에는 보완 지형이 필요합니다. 보완 지형 또는 인플레이스 보완 입체를 선택해 가져오세요.' : !state.supports.length ? '하부 기준 바닥 또는 배치 패밀리를 선택한 뒤 하부 기준을 가져오세요.' : state.supports.length > 50 ? '하부 기준은 50개 이하로 나누어 선택하세요.' : state.supports.some(support => floors.some(floor => floor.uniqueId === support.uniqueId)) ? '도로 대상과 하부 기준에 같은 바닥이 있습니다. 하부 기준을 다시 가져오세요.' : state.supports.some(support => patches.some(patch => patch.uniqueId === support.uniqueId)) ? '보완 대상과 하부 기준에 같은 객체가 있습니다. 하부 기준을 다시 가져오세요.' : '';
    ui.validation.textContent = !valid ? '높이는 -100,000~100,000 mm, 형상 점 간격은 100~10,000 mm로 입력하세요.' : roleError || supportError;
    const withinLimit = patches.length <= 10 && floors.length <= 50;
    ui.apply.disabled = state.busy || !state.supported || !state.documentKey || (!floors.length && !patches.length) || !withinLimit || !ui.terrain.value || !valid || !!roleError || !!supportError;
    ui.detach.disabled = state.busy || !state.documentKey || targetPatches(true).length > 10 || targetFloors(true).length > 50 || ![...terrainPatches(), ...state.floors, ...state.inPlace].some(item => item.linked);
    ui.refresh.disabled = state.busy;
    ui.supportRefresh.disabled = state.busy || !state.supported || !state.documentKey || !state.contextRequestId;
    // Do not disable/rewrite active inputs on a context response: retain focus and caret.
    ui.summary.textContent = patches.length || floors.length ? `보완 대상 ${patches.length}개 → 도로 ${floors.length}개에 적용합니다.` : '보완 지형 또는 도로 바닥을 불러오세요.';
    if (ui.supportEnabled.checked && patches.length) ui.summary.textContent += ` 하부 기준 ${state.supports.length}개로 보완 입체를 생성합니다.`;
    if (!withinLimit) ui.summary.textContent = '보완 지형은 10개, 도로 바닥은 50개 이하로 나누어 선택하세요.';
    ui.patchCount.textContent = `${terrainPatches().length}개`;
    ui.floorCount.textContent = `${state.floors.length}개`;
    ui.inPlaceCount.textContent = `${state.inPlace.length}개`;
    ui.supportCount.textContent = `${state.supports.length}개${ui.supportEnabled.checked ? '' : ' · 맞춤 꺼짐'}`;
    ui.supportRefresh.textContent = state.pending?.action === 'supportsInit' ? '하부 기준을 불러오는 중…' : '하부 기준 가져오기';
    ui.apply.textContent = state.pending?.action === 'apply' ? '지형 연동 중…' : '지형 연동 적용';
    ui.detach.textContent = state.pending?.action === 'detach' ? '연결 해제 중…' : '자동 갱신 연결 해제';
  }
  function showItems(container, items, fallback, emptyMessage, supports = false) {
    const fragment = document.createDocumentFragment();
    items.forEach(floor => {
      const row = document.createElement('div'); row.className = 'terraindrape-floor';
      const name = document.createElement('strong'); name.textContent = `${floor.name || fallback} · ${floor.id}`;
      const detail = document.createElement('span'); detail.textContent = supports ? `${floor.kind === 'Floor' ? '바닥' : floor.kind === 'FamilyInstance' ? '배치 패밀리' : floor.kind || '하부 기준'} · 윗면을 하부 기준으로 사용` : floor.linked ? `${floor.terrainName || '지형 연결'} · ${floor.autoUpdate ? '자동 갱신 켜짐' : '자동 갱신 꺼짐'}` : '연결 없음';
      row.append(name, detail);
      if (floor.lastError) { const warning = document.createElement('span'); warning.className = 'terraindrape-row-warning'; warning.textContent = `자동 갱신 중단: ${floor.lastError}`; row.append(warning); }
      fragment.append(row);
    });
    if (!items.length) { const empty = document.createElement('p'); empty.textContent = emptyMessage; fragment.append(empty); }
    const scroll = container.scrollTop; container.replaceChildren(fragment); container.scrollTop = scroll;
  }
  function showFloors() {
    showItems(ui.patches, terrainPatches(), '보완 지형', '선택한 보완 지형이 없습니다. 도로 바닥만 선택하면 본체 대지에 직접 맞춥니다.');
    showItems(ui.floors, state.floors, '도로 바닥', '선택한 도로 바닥이 없습니다. 보완 지형만 연결할 수도 있습니다.');
  }
  function showSupports() {
    showItems(ui.supports, state.supports, '하부 기준', '가져온 하부 기준이 없습니다. 하부면 맞춤을 사용하려면 별도로 선택해 가져오세요.', true);
  }
  function showInPlace() {
    const scroll = ui.inPlace.scrollTop;
    const ids = new Set(state.inPlace.map(item => item.uniqueId));
    for (const [uid, entry] of inPlaceNodes) {
      if (!ids.has(uid)) { entry.row.remove(); inPlaceNodes.delete(uid); }
    }
    ui.inPlace.querySelector('.terraindrape-inplace-empty')?.remove();
    state.inPlace.forEach(item => {
      let entry = inPlaceNodes.get(item.uniqueId);
      if (!entry) {
        const row = document.createElement('div'); row.className = 'terraindrape-floor terraindrape-inplace-row';
        const name = document.createElement('strong'); const detail = document.createElement('span');
        const label = document.createElement('label'); label.className = 'terraindrape-role-label'; label.append(document.createTextNode('사용 역할'));
        const select = document.createElement('select'); select.dataset.inplaceUid = item.uniqueId; select.dataset.terrainFocusKey = `inPlaceRole:${item.uniqueId}`;
        for (const [value, text] of [['', '역할을 선택하세요.'], ['patch', '보완 입체'], ['road', '도로'], ['combined', '보완+도로 함께']]) { const option = document.createElement('option'); option.value = value; option.textContent = text; select.append(option); }
        label.append(select);
        const referenceLabel = document.createElement('label'); referenceLabel.className = 'terraindrape-role-label'; referenceLabel.append(document.createTextNode('기준 보완 입체'));
        const referenceSelect = document.createElement('select'); referenceSelect.dataset.inplacePartUid = item.uniqueId; referenceSelect.dataset.terrainFocusKey = `inPlacePart:${item.uniqueId}`; referenceLabel.append(referenceSelect);
        const warning = document.createElement('span'); warning.className = 'terraindrape-row-warning';
        row.append(name, detail, label, referenceLabel, warning); ui.inPlace.append(row);
        entry = { row, name, detail, select, referenceLabel, referenceSelect, partsSignature: '', warning }; inPlaceNodes.set(item.uniqueId, entry);
      }
      entry.name.textContent = `${item.name || '인플레이스'} · ${item.id}`;
      entry.detail.textContent = item.linked ? `${item.terrainName || '지형 연결'} · ${item.autoUpdate ? '자동 갱신 켜짐' : '자동 갱신 꺼짐'} · 저장 역할: ${item.role === 'patch' ? '보완 입체' : item.role === 'road' ? '도로' : item.role === 'combined' ? '보완+도로 함께' : '없음'}` : '원본을 보존하고 별도 입체로 연동';
      if (entry.select.value !== item.selectedRole) entry.select.value = item.selectedRole;
      entry.referenceLabel.hidden = item.selectedRole !== 'combined';
      const partsSignature = JSON.stringify(item.parts);
      // Preserve an open/focused part selector until focus leaves. Same-source echoes
      // do not replace its options, and removed keys still fail the state validation.
      if (entry.partsSignature !== partsSignature && document.activeElement !== entry.referenceSelect) {
        const fragment = document.createDocumentFragment();
        const placeholder = document.createElement('option'); placeholder.value = '-1'; placeholder.textContent = item.parts.length ? '기준 보완 입체를 선택하세요.' : '읽을 수 있는 솔리드가 없습니다.'; fragment.append(placeholder);
        item.parts.forEach(part => { const option = document.createElement('option'); option.value = String(part.key); option.textContent = part.name || `입체 ${part.key + 1}`; fragment.append(option); });
        entry.referenceSelect.replaceChildren(fragment); entry.partsSignature = partsSignature;
      }
      if (entry.partsSignature === partsSignature && entry.referenceSelect.value !== String(item.selectedReferencePartKey)) entry.referenceSelect.value = String(item.selectedReferencePartKey);
      entry.warning.textContent = [item.geometryError ? `형상 확인: ${item.geometryError}` : !item.geometryToken ? '원본 형상 정보를 확인하지 못했습니다. 선택 목록을 다시 가져오세요.' : '', item.lastError ? `자동 갱신 중단: ${item.lastError}` : ''].filter(Boolean).join(' / ');
      entry.warning.hidden = !item.geometryError && !!item.geometryToken && !item.lastError;
    });
    if (!state.inPlace.length) { const empty = document.createElement('p'); empty.className = 'terraindrape-inplace-empty'; empty.textContent = '선택한 인플레이스 객체가 없습니다. 인플레이스로 작성한 보완 입체나 도로를 선택해 가져올 수 있습니다.'; ui.inPlace.append(empty); }
    ui.inPlace.scrollTop = scroll;
  }
  function sendRequest(action, payload = {}) {
    const requestId = id(action);
    state.pending = { requestId, action, documentKey: state.documentKey, contextRequestId: state.contextRequestId, payload: { ...payload } };
    state.busy = true;
    ui.status.textContent = action === 'init' ? '현재 프로젝트와 선택한 지형·바닥을 불러오는 중입니다.' : '요청을 처리하는 중입니다.';
    update();
    try { send(TERRAIN_DRAPE_EVENTS[action], { ...payload, requestId }); }
    catch (error) { receive(TERRAIN_DRAPE_EVENTS.error, { requestId, documentKey: state.documentKey, contextRequestId: state.contextRequestId, message: error.message || '요청을 보내지 못했습니다.' }); }
    return requestId;
  }
  function requestInit() {
    if (!active() || state.busy) return false;
    return sendRequest('init');
  }
  function requestAction(action) {
    if (!active() || state.busy || (action === 'apply' ? ui.apply.disabled : ui.detach.disabled)) return false;
    const inPlaceReferenceParts = state.inPlace.filter(item => (action === 'detach' ? item.role : item.selectedRole) === 'combined').map(item => ({ uniqueId: item.uniqueId, partKey: action === 'detach' ? item.referencePartKey : item.selectedReferencePartKey }));
    return sendRequest(action, { documentKey: state.documentKey, selectedDocument: state.document, contextRequestId: state.contextRequestId, terrainUniqueId: ui.terrain.value, patchUniqueIds: targetPatches(action === 'detach').map(patch => patch.uniqueId), floorUniqueIds: targetFloors(action === 'detach').map(floor => floor.uniqueId), inPlaceReferenceParts, supportEnabled: ui.supportEnabled.checked, supportUniqueIds: ui.supportEnabled.checked ? state.supports.map(support => support.uniqueId) : [], offsetMm: number(ui.offset), spacingMm: number(ui.spacing), autoUpdate: ui.auto.checked });
  }
  function requestSupports() {
    if (!active() || state.busy || ui.supportRefresh.disabled) return false;
    return sendRequest('supportsInit', { documentKey: state.documentKey, selectedDocument: state.document, contextRequestId: state.contextRequestId });
  }
  function receive(event, payload = {}) {
    if (!active()) return false;
    if (event === 'host:doc-changed') {
      // Cancel only UI correlation. Host validates document identity before any write.
      state.pending = null; state.busy = false; state.documentKey = ''; state.contextRequestId = ''; state.document = null; state.patches = []; state.floors = []; state.inPlace = []; state.supports = []; state.targetSignature = ''; state.supportModeDirty = false; state.supported = false; state.invalidated = true;
      ui.status.textContent = '활성 문서가 변경되었습니다. 선택 목록을 다시 가져오세요.';
      ui.document.textContent = ''; ui.terrain.value = ''; ui.results.hidden = true; showFloors(); showInPlace(); showSupports(); update(); return true;
    }
    const pending = state.pending;
    if (!pending || !payload.requestId || payload.requestId !== pending.requestId) return false;
    if (pending.action !== 'init' && String(payload.documentKey || '') !== pending.documentKey) return false;
    if (pending.action === 'supportsInit' && (String(payload.contextRequestId || '') !== pending.contextRequestId || pending.contextRequestId !== state.contextRequestId)) return false;
    if (event === TERRAIN_DRAPE_EVENTS.context && pending.action !== 'init') return false;
    if (event === TERRAIN_DRAPE_EVENTS.supports && pending.action !== 'supportsInit') return false;
    if (event === TERRAIN_DRAPE_EVENTS.result && (!['apply', 'detach'].includes(pending.action) || payload.action !== pending.action)) return false;
    if (![TERRAIN_DRAPE_EVENTS.context, TERRAIN_DRAPE_EVENTS.supports, TERRAIN_DRAPE_EVENTS.result, TERRAIN_DRAPE_EVENTS.error].includes(event)) return false;
    state.pending = null; state.busy = false;
    if (event === TERRAIN_DRAPE_EVENTS.context) {
      const previousInPlace = new Map(state.documentKey === String(payload.documentKey || '') ? state.inPlace.map(item => [item.uniqueId, item]) : []);
      state.invalidated = false; state.documentKey = String(payload.documentKey || ''); state.contextRequestId = String(payload.contextRequestId || payload.requestId); state.document = payload.document || null;
      state.supported = payload.supported === true;
      state.floors = (Array.isArray(payload.floors) ? payload.floors : []).filter(floor => floor.uniqueId);
      state.patches = (Array.isArray(payload.patches) ? payload.patches : []).filter(patch => patch.uniqueId);
      state.inPlace = (Array.isArray(payload.inPlace) ? payload.inPlace : []).filter(item => item.uniqueId).map(item => {
        const previous = previousInPlace.get(item.uniqueId);
        const role = ['patch', 'road', 'combined'].includes(item.role) ? item.role : '';
        const parts = (Array.isArray(item.parts) ? item.parts : []).filter(part => Number.isInteger(part.key) && part.key >= 0);
        const tokens = parts.map(part => String(part.geometryToken || ''));
        const geometryToken = tokens.length && tokens[0] && tokens.every(token => token === tokens[0]) ? tokens[0] : '';
        const referencePartKey = Number.isInteger(item.referencePartKey) ? item.referencePartKey : -1;
        const selectedRole = previous?.roleDirty ? previous.selectedRole : role;
        const sourceChanged = previous && previous.geometryToken !== geometryToken;
        const referenceDirty = previous?.referenceDirty === true && !sourceChanged;
        let selectedReferencePartKey = referenceDirty ? previous.selectedReferencePartKey : referencePartKey;
        if (sourceChanged && !item.linked && selectedRole === 'combined' && parts.length > 1) selectedReferencePartKey = -1;
        if (selectedRole === 'combined' && parts.length === 1 && selectedReferencePartKey < 0) selectedReferencePartKey = parts[0].key;
        return { ...item, role, selectedRole, roleDirty: previous?.roleDirty === true, parts, geometryToken, referencePartKey, selectedReferencePartKey, referenceDirty };
      });
      state.supports = (Array.isArray(payload.supports) ? payload.supports : []).filter(support => support.uniqueId);
      const targetSignature = JSON.stringify([state.documentKey, state.patches.map(item => item.uniqueId).sort(), state.floors.map(item => item.uniqueId).sort(), state.inPlace.map(item => item.uniqueId).sort()]);
      if (targetSignature !== state.targetSignature || !state.supportModeDirty) {
        ui.supportEnabled.checked = payload.supportEnabled === true;
        state.supportModeDirty = false;
      }
      state.targetSignature = targetSignature;
      const terrains = (Array.isArray(payload.terrains) ? payload.terrains : []).filter(terrain => terrain.uniqueId);
      // Same-source refreshes never replace an unchanged select or its focused option.
      if (JSON.stringify(terrains) !== JSON.stringify(state.terrains) || !state.contextRequestId || ui.terrain.options[0]?.textContent === '지형을 불러오는 중입니다.') {
        const chosen = ui.terrain.value; const fragment = document.createDocumentFragment();
        const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = terrains.length ? '본체 대지를 선택하세요.' : '사용할 수 있는 지형이 없습니다.'; fragment.append(placeholder);
        terrains.forEach(terrain => { const option = document.createElement('option'); option.value = terrain.uniqueId; option.textContent = `${terrain.name} · ${terrain.kind}`; fragment.append(option); });
        ui.terrain.replaceChildren(fragment);
        const unselected = terrains.filter(terrain => !state.patches.some(patch => patch.uniqueId === terrain.uniqueId));
        ui.terrain.value = terrains.some(terrain => terrain.uniqueId === chosen) ? chosen : (unselected.length === 1 ? unselected[0].uniqueId : '');
      }
      state.terrains = terrains; ui.document.textContent = state.document?.title || state.document?.name || '현재 Revit 프로젝트';
      showFloors(); showInPlace(); showSupports();
      ui.status.textContent = payload.message || (state.floors.length || state.patches.length || state.inPlace.length ? '본체와 연동 대상의 역할을 확인한 뒤 적용하세요.' : 'Revit에서 보완 지형 또는 도로 바닥을 선택한 뒤 선택 목록을 가져오세요.');
    } else if (event === TERRAIN_DRAPE_EVENTS.supports) {
      state.supports = (Array.isArray(payload.supports) ? payload.supports : []).filter(support => support.uniqueId);
      showSupports();
      ui.status.textContent = payload.message || (state.supports.length ? `하부 기준 ${state.supports.length}개를 가져왔습니다. 보완 지형·도로 선택은 유지됩니다.` : '선택한 바닥 또는 배치 패밀리가 없습니다. Revit에서 하부 기준을 선택해 다시 가져오세요.');
    } else if (event === TERRAIN_DRAPE_EVENTS.result) {
      ui.results.hidden = false;
      const fragment = document.createDocumentFragment();
      (Array.isArray(payload.results) ? payload.results : []).forEach(result => {
        const row = document.createElement('div'); row.className = 'terraindrape-result';
        const heading = document.createElement('strong'); heading.textContent = `${result.name || '연동 대상'} · ${result.id}`;
        const message = document.createElement('span'); message.textContent = result.message || result.status || '';
        row.append(heading, message);
        if (Number.isFinite(Number(result.pointCount)) && pending.action === 'apply') { const points = document.createElement('small'); points.textContent = `형상 점 ${result.pointCount}개`; row.append(points); }
        fragment.append(row);
      });
      ui.resultRows.replaceChildren(fragment);
      ui.status.textContent = payload.message || (payload.success ? '처리가 완료되었습니다.' : '처리 결과를 확인하세요.');
      // A successful apply may have created links. Refresh the captured floors next time,
      // while retaining results and never retargeting to a newer Revit selection silently.
      const succeeded = new Set((payload.results || []).filter(result => /^(applied|updated|success|ok|detached)$/i.test(result.status || '')).map(result => String(result.id)));
      const updateLinked = item => succeeded.has(String(item.id)) ? { ...item, linked: pending.action === 'apply', autoUpdate: pending.action === 'apply' && pending.payload.autoUpdate, terrainName: pending.action === 'apply' ? state.terrains.find(terrain => terrain.uniqueId === pending.payload.terrainUniqueId)?.name || '' : '', lastError: '' } : item;
      state.floors = state.floors.map(updateLinked);
      state.patches = state.patches.map(updateLinked);
      state.inPlace = state.inPlace.map(item => {
        const updated = updateLinked(item);
        if (succeeded.has(String(item.id)) && pending.action === 'apply') {
          const reference = pending.payload.inPlaceReferenceParts.find(part => part.uniqueId === item.uniqueId);
          updated.role = reference ? 'combined' : pending.payload.patchUniqueIds.includes(item.uniqueId) ? 'patch' : 'road';
          updated.referencePartKey = reference?.partKey ?? -1;
          updated.referenceDirty = updated.selectedReferencePartKey !== updated.referencePartKey;
          updated.roleDirty = updated.selectedRole !== updated.role;
        }
        return updated;
      });
      showFloors(); showInPlace();
    } else {
      ui.status.textContent = payload.message || '처리하지 못했습니다. 선택 목록을 다시 가져오세요.';
      if (pending.action === 'init' || payload.contextInvalid) { state.documentKey = ''; state.contextRequestId = ''; state.supported = false; state.patches = []; state.floors = []; state.inPlace = []; state.supports = []; state.targetSignature = ''; state.supportModeDirty = false; showFloors(); showInPlace(); showSupports(); }
    }
    update(); return true;
  }
  ['input', 'change', 'compositionend'].forEach(event => [ui.offset, ui.spacing, ui.auto, ui.terrain, ui.supportEnabled].forEach(control => listen(control, event, update)));
  listen(ui.supportEnabled, 'change', () => { state.supportModeDirty = true; });
  listen(ui.inPlace, 'change', event => {
    const uid = event.target?.dataset.inplaceUid || event.target?.dataset.inplacePartUid;
    const item = state.inPlace.find(row => row.uniqueId === uid);
    if (!item) return;
    if (event.target.dataset.inplacePartUid) {
      const key = Number(event.target.value);
      item.selectedReferencePartKey = item.parts.some(part => part.key === key) ? key : -1; item.referenceDirty = true;
    } else {
      item.selectedRole = ['patch', 'road', 'combined'].includes(event.target.value) ? event.target.value : '';
      item.roleDirty = true;
      if (item.selectedRole === 'combined' && item.parts.length === 1) item.selectedReferencePartKey = item.parts[0].key;
    }
    showInPlace(); update();
  });
  listen(ui.inPlace, 'focusout', () => { Promise.resolve().then(() => { if (active()) showInPlace(); }); });
  listen(ui.terrain, 'change', showFloors);
  listen(ui.refresh, 'click', requestInit); listen(ui.supportRefresh, 'click', requestSupports); listen(ui.apply, 'click', () => requestAction('apply')); listen(ui.detach, 'click', () => requestAction('detach'));
  [TERRAIN_DRAPE_EVENTS.context, TERRAIN_DRAPE_EVENTS.supports, TERRAIN_DRAPE_EVENTS.result, TERRAIN_DRAPE_EVENTS.error, 'host:doc-changed'].forEach(event => disposers.push(onHost(event, payload => receive(event, payload))));
  function cleanup() { if (state.destroyed) return; state.destroyed = true; disposers.splice(0).forEach(dispose => dispose?.()); if (activeCleanup === cleanup) activeCleanup = null; }
  activeCleanup = cleanup;
  // Main's direct shell accepts a cleanup function. Extra methods support browser QA.
  Object.assign(cleanup, { receive, requestInit, requestSupports, requestApply: () => requestAction('apply'), requestDetach: () => requestAction('detach'), getState: () => ({ ...state, supportEnabled: ui.supportEnabled.checked, pending: state.pending ? { ...state.pending } : null }) });
  showInPlace(); showSupports(); update(); if (options.autoInit !== false) requestInit();
  return cleanup;
}
