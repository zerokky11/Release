import { clear, div, toast, showExcelSavedDialog } from '../core/dom.js?v=20260731parameterexport1';
import { onHost, post } from '../core/bridge.js';
import {
  addRvtTargets3,
  getCheckedRvtPaths3,
  setAllRvtTargetsChecked3,
  toggleRvtTarget3,
  WORKFLOW3_CHANGE_EVENT
} from '../core/workflowState3.js?v=20260731sharedsettings3';

const PUBLISH_CONFIRMATION = 'PUBLISH AND SAVE';

export function renderLinkSharedCoord(root) {
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);

  const state = {
    context: null,
    links: [],
    projectLocations: [],
    selectedLink: null,
    analysis: null,
    busyAction: '',
    workspaceMode: 'batch',
    batchMode: 'active',
    batchRvtPaths: getCheckedRvtPaths3(),
    batchRows: [],
    batchWorkbookPath: '',
    batchDatasetToken: '',
    batchApplyReady: false,
    batchBusy: false,
    activeHostAvailable: false,
    activeHostName: '',
    activeHostKey: ''
  };

  const page = div('feature-shell linksharedcoord-page');
  const header = div('feature-header linksharedcoord-header');
  const heading = div('feature-heading');
  heading.innerHTML = `
    <span class="feature-kicker">링크 · Shared Coordination</span>
    <h2 class="feature-title">Link 파일 Shared Coordination 검토/설정</h2>
    <p class="feature-sub">활성 문서 또는 여러 RVT의 링크를 A × 1 교차점 기준으로 검토하고, Excel 검토표를 거쳐 호스트 링크 배치를 반영합니다.</p>`;
  header.append(heading);
  page.append(header);

  const modeSwitch = div('deliverycleaner-tabs linksharedcoord-mode-switch');
  modeSwitch.setAttribute('role', 'tablist');
  modeSwitch.setAttribute('aria-label', 'Shared Coordination 작업 모드');
  modeSwitch.innerHTML = `
    <button type="button" class="deliverycleaner-tab linksharedcoord-mode-tab" role="tab" data-workspace-mode="batch" aria-selected="true">Excel 일괄 검토/설정</button>
    <button type="button" class="deliverycleaner-tab linksharedcoord-mode-tab" role="tab" data-workspace-mode="single" aria-selected="false">활성 문서 단일 링크</button>`;
  page.append(modeSwitch);

  const batchCard = div('linksharedcoord-card linksharedcoord-batch');
  batchCard.innerHTML = `
    <div class="linksharedcoord-card__head">
      <div><span class="linksharedcoord-step">BATCH WORKSPACE</span><h3>검토 대상 및 Excel 결과</h3></div>
      <span class="linksharedcoord-status" data-batch-status>준비됨</span>
    </div>
    <div class="linksharedcoord-batch-target">
      <div class="linksharedcoord-batch-target-head">
        <div>
          <strong>여러 RVT 대상 등록</strong>
          <span>활성 문서는 등록 없이 오른쪽 실행 버튼에서 바로 검토합니다.</span>
        </div>
        <div class="linksharedcoord-batch-actions">
          <button type="button" class="btn btn--secondary" data-batch-add>RVT 파일 추가</button>
          <button type="button" class="btn btn--secondary" data-batch-clear>RVT 선택 해제</button>
        </div>
      </div>
      <p class="linksharedcoord-batch-target-copy" data-batch-target-copy>활성 문서 연결을 확인하고 있습니다.</p>
      <div class="linksharedcoord-batch-files" data-batch-files></div>
    </div>
    <div class="linksharedcoord-batch-workbook">
      <span>검토 Excel</span>
      <strong data-batch-workbook>선택된 Excel 없음</strong>
      <button type="button" class="btn btn--secondary" data-batch-pick-excel>검토 Excel 선택·불러오기</button>
    </div>
  <p class="linksharedcoord-batch-note"><b>실제 작업:</b> 활성 문서/여러 RVT 검토 → Excel 내보내기 → 노란색 Action을 APPLY로 편집·저장 → 검토 Excel 선택·불러오기 → APPLY 행 적용. <b>최초 링크 Positioning</b>은 Revit API가 기존 인스턴스에서 되읽을 수 없어 ‘확인 불가’로 표시합니다. <b>현재 배치</b>는 Shared Site 관계 또는 현재 Transform 일치 기준이며 추정값은 명확히 구분합니다. <b>Link SITE</b>는 인스턴스 Shared Site와 링크 파일 Active Project Location을 따로 표시합니다. <b>링크 원점 Transform</b>은 링크 내부 원점/축이 호스트 내부좌표에 배치된 값이며 A × 1 오차가 아닙니다. <b>A × 1 목표/차이</b>는 호스트 Grid A × 1과의 직접 비교가 아니라, 링크 내부 A × 1의 현재 Shared 좌표와 선택한 링크 Shared Site(또는 직접 입력 목표)의 차이입니다. <b>Excel 양식 예시</b>는 열 구성 참고용이며 적용 데이터로 사용되지 않습니다. 검토 중 사용자 웍셋은 열지 않습니다.</p>
    <div class="linksharedcoord-batch-summary" data-batch-summary>아직 추출된 링크가 없습니다.</div>
    <div class="linksharedcoord-batch-table-wrap">
      <table class="linksharedcoord-batch-table">
        <thead><tr><th>Action</th><th>호스트</th><th>링크 인스턴스</th><th title="최초 삽입 옵션은 API로 확인할 수 없습니다. 현재 관계/Transform 판정과 SITE를 표시합니다.">현재 배치 / Link SITE</th><th>웍셋 (Type / Instance)</th><th>링크 상태</th><th title="링크 내부 원점/축 → 호스트 내부좌표 배치값. A × 1 오차가 아닙니다.">링크 원점 Transform (호스트 내부)</th><th title="링크 내부 A × 1 @ 기준 Level을 현재 배치에 적용한 호스트 Shared 좌표입니다.">A × 1 현재 좌표 (Shared)</th><th title="목표는 선택한 링크 Project Location(Shared Site) 또는 직접 입력값입니다. 차이는 목표−현재이며 호스트 Grid A × 1과의 직접 비교가 아닙니다.">A × 1 목표 / 차이</th><th>검토</th><th>적용</th><th>메시지</th></tr></thead>
        <tbody data-batch-body><tr><td colspan="12" class="linksharedcoord-empty">활성 문서 또는 RVT 파일을 분석해 주세요.</td></tr></tbody>
      </table>
    </div>`;
  const batchReviewActions = div('feature-actions linksharedcoord-batch-review-actions');
  const batchScanActiveButton = createButton('활성 문서 검토', 'btn--primary');
  const batchScanFilesButton = createButton('여러 RVT 검토', 'btn--secondary btn--multi');
  const batchTemplateButton = createButton('Excel 양식 예시', 'btn--secondary');
  const batchExportButton = createButton('Excel 내보내기', 'btn--secondary');
  batchScanActiveButton.dataset.batchScanActive = '';
  batchScanFilesButton.dataset.batchScanFiles = '';
  batchTemplateButton.dataset.batchTemplate = '';
  batchExportButton.dataset.batchExport = '';
  batchReviewActions.append(batchScanActiveButton, batchScanFilesButton, batchTemplateButton, batchExportButton);

  const batchApplyActions = div('feature-actions linksharedcoord-batch-apply-actions');
  const batchImportButton = createButton('선택한 Excel 다시 불러오기', 'btn--secondary');
  const batchApplyButton = createButton('APPLY 행 적용', 'btn--primary');
  batchImportButton.dataset.batchImport = '';
  batchApplyButton.dataset.batchApply = '';
  batchApplyActions.append(batchImportButton, batchApplyButton);

  const batchReviewCard = div('linksharedcoord-card linksharedcoord-batch-action-card');
  batchReviewCard.innerHTML = `
    <div class="linksharedcoord-card__head">
      <div><span class="linksharedcoord-step">01 · RUN</span><h3>검토표 생성</h3></div>
    </div>`;
  batchReviewCard.append(batchReviewActions);

  const batchApplyCard = div('linksharedcoord-card linksharedcoord-batch-action-card');
  batchApplyCard.innerHTML = `
    <div class="linksharedcoord-card__head">
      <div><span class="linksharedcoord-step">02 · RUN</span><h3>Excel 결과 반영</h3></div>
    </div>`;
  batchApplyCard.append(batchApplyActions);

  const batchWorkspaceElement = div('linksharedcoord-workspace linksharedcoord-batch-workspace');
  const batchMainColumn = div('linksharedcoord-main-column linksharedcoord-batch-main-column');
  const batchSideColumn = div('linksharedcoord-side-column linksharedcoord-batch-side-column');
  batchMainColumn.append(batchCard);
  batchSideColumn.append(batchReviewCard, batchApplyCard);
  batchWorkspaceElement.append(batchMainColumn, batchSideColumn);
  page.append(batchWorkspaceElement);

  const hostCard = div('linksharedcoord-card linksharedcoord-host');
  hostCard.innerHTML = `
    <div class="linksharedcoord-card__head">
      <div><span class="linksharedcoord-step">ACTIVE HOST</span><h3>현재 작업 기준</h3></div>
      <span class="linksharedcoord-status" data-host-status>연결 확인 중</span>
    </div>
    <div class="linksharedcoord-host-grid">
      <div><span>호스트 문서</span><strong data-host-name>-</strong></div>
      <div><span>Project Location</span><strong data-host-location>-</strong></div>
      <div><span>True North</span><strong data-host-bearing>-</strong></div>
      <div><span>링크 상태</span><strong data-link-count>-</strong></div>
    </div>`;

  const configCard = div('linksharedcoord-card linksharedcoord-config');
  configCard.innerHTML = `
    <div class="linksharedcoord-card__head">
      <div><span class="linksharedcoord-step">01 · REFERENCE</span><h3>링크와 기준 앵커</h3></div>
      <span class="linksharedcoord-note">활성 호스트 전용</span>
    </div>`;

  const configGrid = div('linksharedcoord-form-grid');
  const linkSelect = createSelectField(configGrid, '링크 인스턴스', '호스트에서 검토할 로드된 Revit 링크', 'link');
  const levelSelect = createSelectField(configGrid, '기준 Level', 'A × 1 교차점의 Z 기준으로 사용할 링크 Level', 'level');
  const anchorA = createTextField(configGrid, '첫 번째 Anchor Grid', '기본값 A', 'A');
  const anchor1 = createTextField(configGrid, '두 번째 Anchor Grid', '기본값 1', '1');
  configCard.append(configGrid);

  const directionCard = div('linksharedcoord-subcard');
  directionCard.innerHTML = `<div class="linksharedcoord-subcard__title"><strong>방향 기준</strong><span>앵커 한 점만으로 생기는 180° 방향 모호성을 제거합니다.</span></div>`;
  const directionGrid = div('linksharedcoord-form-grid linksharedcoord-form-grid--compact');
  const directionMode = createSelectField(directionGrid, '방향 모드', '두 번째 교차점 또는 링크 Project North', 'direction');
  addOptions(directionMode, [
    { value: 'secondIntersection', label: '두 번째 교차점' },
    { value: 'projectNorth', label: 'Project North' }
  ]);
  const directionA = createTextField(directionGrid, '방향 Grid 1', '기본값 A', 'A');
  const direction2 = createTextField(directionGrid, '방향 Grid 2', '기본값 2', '2');
  directionCard.append(directionGrid);
  configCard.append(directionCard);

  const targetCard = div('linksharedcoord-card linksharedcoord-target');
  targetCard.innerHTML = `
    <div class="linksharedcoord-card__head">
      <div><span class="linksharedcoord-step">02 · TARGET</span><h3>목표 Shared Coordination</h3></div>
    </div>`;
  const targetGrid = div('linksharedcoord-form-grid');
  const targetSource = createSelectField(targetGrid, 'Target Source', '링크에 저장된 Shared Site 또는 직접 입력', 'target-source');
  addOptions(targetSource, [
    { value: 'linkedSite', label: '링크 저장 Shared Site' },
    { value: 'manual', label: '직접 입력' }
  ]);
  const siteSelect = createSelectField(targetGrid, '기존 Project Location', '링크 파일에 저장된 Named Position / Site', 'site');
  const unitSelect = createSelectField(targetGrid, '좌표 단위', '직접 입력과 결과 표시 단위', 'unit');
  addOptions(unitSelect, [
    { value: 'mm', label: 'mm' },
    { value: 'm', label: 'm' }
  ]);
  targetCard.append(targetGrid);

  const manualPanel = div('linksharedcoord-manual');
  const manualHead = div('linksharedcoord-subcard__title');
  manualHead.innerHTML = '<strong>직접 입력 좌표</strong><span>E/N/Z는 선택 단위, Bearing은 도(°) 기준입니다.</span>';
  const manualGrid = div('linksharedcoord-coordinate-grid');
  const manualEast = createNumberField(manualGrid, 'E / Easting', '0');
  const manualNorth = createNumberField(manualGrid, 'N / Northing', '0');
  const manualElevation = createNumberField(manualGrid, 'Z / Elevation', '0');
  const manualBearing = createNumberField(manualGrid, 'Bearing (°)', '0');
  manualPanel.append(manualHead, manualGrid);
  targetCard.append(manualPanel);

  const analysisCard = div('linksharedcoord-card linksharedcoord-analysis');
  analysisCard.innerHTML = `
    <div class="linksharedcoord-card__head">
      <div><span class="linksharedcoord-step">03 · PREVIEW</span><h3>분석 결과</h3></div>
      <span class="linksharedcoord-status" data-analysis-status>분석 전</span>
    </div>
    <div class="linksharedcoord-anchor-summary" data-anchor-summary>링크와 기준을 선택한 뒤 분석을 실행해 주세요.</div>
    <div class="linksharedcoord-placement-summary" data-placement-summary>현재 배치와 Link SITE 정보가 여기에 표시됩니다.</div>
    <div class="linksharedcoord-result-table-wrap">
      <table class="linksharedcoord-result-table">
        <thead><tr><th>구분</th><th>E</th><th>N</th><th>Z</th><th title="측량 방위각 기준: 시계 방향이 양수입니다.">Bearing (CW+)</th></tr></thead>
        <tbody data-result-body><tr><td colspan="5" class="linksharedcoord-empty">분석 결과가 없습니다.</td></tr></tbody>
      </table>
    </div>
    <div class="linksharedcoord-warnings" data-warnings hidden></div>`;

  const actionsCard = div('linksharedcoord-card linksharedcoord-actions');
  actionsCard.innerHTML = `
    <div class="linksharedcoord-card__head">
      <div><span class="linksharedcoord-step">04 · EXECUTE</span><h3>분석 및 반영</h3></div>
    </div>
    <p class="linksharedcoord-action-copy" data-action-copy>분석은 문서를 변경하지 않습니다. 결과를 확인한 뒤 적용과 Publish를 각각 실행합니다.</p>`;
  const actionButtons = div('linksharedcoord-action-buttons');
  const analyzeButton = createButton('Shared Coordination 분석', 'btn--primary');
  const applyButton = createButton('호스트 링크 배치 적용', 'btn--secondary');
  const publishButton = createButton('Publish + Link 파일 저장', 'btn--danger');
  actionButtons.append(analyzeButton, applyButton, publishButton);

  const publishConfirm = document.createElement('label');
  publishConfirm.className = 'linksharedcoord-confirm';
  publishConfirm.innerHTML = `
    <input type="checkbox" data-publish-confirm>
    <span>선택한 링크 파일에 Shared Site를 Publish하고 링크 파일까지 저장한다는 것을 확인했습니다.</span>`;
  actionsCard.append(actionButtons, publishConfirm);

  const workspace = div('linksharedcoord-workspace linksharedcoord-single-workspace');
  const mainColumn = div('linksharedcoord-main-column');
  const sideColumn = div('linksharedcoord-side-column');
  mainColumn.append(hostCard, configCard, targetCard, analysisCard);
  sideColumn.append(actionsCard);
  workspace.append(mainColumn, sideColumn);
  page.append(workspace);
  target.append(page);

  const ui = {
    workspaceModes: Array.from(modeSwitch.querySelectorAll('[data-workspace-mode]')),
    hostStatus: hostCard.querySelector('[data-host-status]'),
    hostName: hostCard.querySelector('[data-host-name]'),
    hostLocation: hostCard.querySelector('[data-host-location]'),
    hostBearing: hostCard.querySelector('[data-host-bearing]'),
    linkCount: hostCard.querySelector('[data-link-count]'),
    analysisStatus: analysisCard.querySelector('[data-analysis-status]'),
    anchorSummary: analysisCard.querySelector('[data-anchor-summary]'),
    placementSummary: analysisCard.querySelector('[data-placement-summary]'),
    resultBody: analysisCard.querySelector('[data-result-body]'),
    warnings: analysisCard.querySelector('[data-warnings]'),
    actionCopy: actionsCard.querySelector('[data-action-copy]'),
    publishConfirm: actionsCard.querySelector('[data-publish-confirm]'),
    batchStatus: batchCard.querySelector('[data-batch-status]'),
    batchTargetCopy: batchCard.querySelector('[data-batch-target-copy]'),
    batchFiles: batchCard.querySelector('[data-batch-files]'),
    batchWorkbook: batchCard.querySelector('[data-batch-workbook]'),
    batchSummary: batchCard.querySelector('[data-batch-summary]'),
    batchBody: batchCard.querySelector('[data-batch-body]'),
    batchAdd: batchCard.querySelector('[data-batch-add]'),
    batchClear: batchCard.querySelector('[data-batch-clear]'),
    batchPickExcel: batchCard.querySelector('[data-batch-pick-excel]'),
    batchScanActive: batchScanActiveButton,
    batchScanFiles: batchScanFilesButton,
    batchTemplate: batchTemplateButton,
    batchExport: batchExportButton,
    batchImport: batchImportButton,
    batchApply: batchApplyButton
  };

  const invalidateInputs = [
    linkSelect, levelSelect, anchorA, anchor1, directionMode, directionA, direction2,
    targetSource, siteSelect, unitSelect, manualEast, manualNorth, manualElevation, manualBearing
  ];
  invalidateInputs.forEach((control) => control.addEventListener('change', () => {
    if (control === linkSelect) selectLink();
    if (control === directionMode) syncDirectionMode();
    if (control === targetSource) syncTargetSource();
    invalidateAnalysis();
  }));
  [anchorA, anchor1, directionA, direction2, manualEast, manualNorth, manualElevation, manualBearing]
    .forEach((control) => control.addEventListener('input', invalidateAnalysis));

  analyzeButton.addEventListener('click', analyze);
  applyButton.addEventListener('click', applyPlacement);
  publishButton.addEventListener('click', publishAndSave);
  ui.publishConfirm.addEventListener('change', syncActions);
  ui.workspaceModes.forEach((button) => button.addEventListener('click', () => {
    setWorkspaceMode(button.dataset.workspaceMode);
  }));
  ui.batchAdd.addEventListener('click', () => post('linksharedcoord:batch-pick-rvts', {}));
  ui.batchClear.addEventListener('click', () => {
    if (!state.batchRvtPaths.length) return;
    setAllRvtTargetsChecked3(false);
  });
  ui.batchScanActive.addEventListener('click', () => scanBatch('active'));
  ui.batchScanFiles.addEventListener('click', () => scanBatch('files'));
  ui.batchTemplate.addEventListener('click', exportTemplateBatch);
  ui.batchExport.addEventListener('click', exportBatch);
  ui.batchPickExcel.addEventListener('click', () => post('linksharedcoord:batch-pick-excel', {}));
  ui.batchImport.addEventListener('click', importBatch);
  ui.batchApply.addEventListener('click', applyBatch);

  onHost('linksharedcoord:context', receiveContext);
  onHost('linksharedcoord:analyzed', receiveAnalysis);
  onHost('linksharedcoord:applied', receiveApplied);
  onHost('linksharedcoord:published', receivePublished);
  onHost('linksharedcoord:error', receiveError);
  onHost('linksharedcoord:batch-rvts-picked', receiveBatchRvts);
  onHost('linksharedcoord:batch-excel-picked', receiveBatchExcel);
  onHost('linksharedcoord:batch-rows', receiveBatchRows);
  onHost('linksharedcoord:batch-template-exported', receiveBatchTemplateExported);
  onHost('linksharedcoord:batch-exported', receiveBatchExported);
  onHost('linksharedcoord:batch-applied', receiveBatchApplied);
  onHost('linksharedcoord:batch-progress', receiveBatchProgress);
  onHost('linksharedcoord:batch-error', receiveBatchError);
  onHost('host:error', receiveHostError);

  const receiveWorkflowTargets = () => {
    if (!page.isConnected) {
      window.removeEventListener(WORKFLOW3_CHANGE_EVENT, receiveWorkflowTargets);
      return;
    }
    const nextPaths = getCheckedRvtPaths3();
    if (samePathList(state.batchRvtPaths, nextPaths)) return;
    invalidateBatchDataset('공통 RVT 선택이 변경되어 기존 Excel 선택과 결과를 초기화했습니다.');
    state.batchRvtPaths = nextPaths;
    if (nextPaths.length) state.batchMode = 'files';
    renderBatchFiles();
    syncActions();
  };
  window.addEventListener(WORKFLOW3_CHANGE_EVENT, receiveWorkflowTargets);

  const cleanupObserver = new MutationObserver(() => {
    if (page.isConnected) return;
    window.removeEventListener(WORKFLOW3_CHANGE_EVENT, receiveWorkflowTargets);
    cleanupObserver.disconnect();
  });
  cleanupObserver.observe(document.body, { childList: true, subtree: true });

  syncDirectionMode();
  syncTargetSource();
  syncWorkspaceMode();
  renderBatchFiles();
  renderBatchRows();
  syncActions();
  window.requestAnimationFrame(() => syncWorkspaceMode());
  post('linksharedcoord:init', {});

  function setWorkspaceMode(mode) {
    if (state.batchBusy || state.busyAction) return;
    state.workspaceMode = mode === 'single' ? 'single' : 'batch';
    syncWorkspaceMode();
  }

  function syncWorkspaceMode() {
    const batchWorkspace = state.workspaceMode !== 'single';
    page.classList.toggle('is-single-mode', !batchWorkspace);
    batchCard.hidden = !batchWorkspace;
    batchReviewActions.hidden = !batchWorkspace;
    batchApplyActions.hidden = !batchWorkspace;
    batchWorkspaceElement.hidden = !batchWorkspace;
    workspace.hidden = batchWorkspace;
    actionsCard.hidden = batchWorkspace;
    ui.workspaceModes.forEach((button) => {
      const selected = button.dataset.workspaceMode === state.workspaceMode;
      button.setAttribute('aria-selected', selected ? 'true' : 'false');
      button.classList.toggle('is-active', selected);
      button.tabIndex = selected ? 0 : -1;
    });

    const shellAside = actionsCard.closest('.shell3-aside') || document.querySelector('.direct3-aside--linksharedcoord');
    shellAside?.querySelectorAll('.linksharedcoord-batch-aside').forEach((section) => {
      section.hidden = !batchWorkspace;
    });
  }

  function invalidateBatchDataset(message) {
    const hadDataset = state.batchRows.length > 0 || !!state.batchWorkbookPath || state.batchApplyReady;
    state.batchRows = [];
    state.batchWorkbookPath = '';
    clearBatchApplyAuthorization();
    renderBatchWorkbook();
    renderBatchRows();
    if (hadDataset && message) toast(message, 'warn', 4200);
  }

  function receiveBatchRvts(payload) {
    const paths = Array.isArray(payload?.paths) ? payload.paths : [];
    if (!paths.length) return;
    const before = state.batchRvtPaths.slice();
    const result = addRvtTargets3(paths);
    state.batchRvtPaths = getCheckedRvtPaths3();
    if (samePathList(before, state.batchRvtPaths)) {
      toast('선택한 RVT는 이미 공통 대상 목록에 등록되어 있습니다.', 'warn');
      return;
    }
    state.batchMode = 'files';
    renderBatchFiles();
    syncActions();
    toast(`${result.added || paths.length}개 RVT를 공통 대상 목록에 반영했습니다.`, 'ok');
  }

  function receiveBatchExcel(payload) {
    state.batchWorkbookPath = text(read(payload, 'path', 'Path'));
    state.batchRows = [];
    clearBatchApplyAuthorization();
    renderBatchWorkbook();
    renderBatchRows();
    syncActions();
    if (state.batchWorkbookPath) importBatch();
  }

  function receiveBatchRows(payload) {
    if (read(payload, 'ok', 'Ok') === false) {
      receiveBatchError(payload);
      return;
    }
    const source = text(read(payload, 'source', 'Source')).toLowerCase();
    state.batchRows = Array.isArray(payload?.rows) ? payload.rows : [];
    state.batchWorkbookPath = text(read(payload, 'workbookPath', 'WorkbookPath')) || state.batchWorkbookPath;
    state.batchDatasetToken = source === 'import'
      ? text(read(payload, 'datasetToken', 'DatasetToken'))
      : '';
    state.batchApplyReady = source === 'import' &&
      read(payload, 'applyReady', 'ApplyReady') === true &&
      !!state.batchDatasetToken;
    renderBatchWorkbook();
    renderBatchRows(payload?.summary || null);
    setBatchBusy(false);
    toast(source === 'import'
      ? 'Excel 저장 내용을 불러오고 현재 모델 재검토를 완료했습니다.'
      : '링크 검토 결과를 생성했습니다. 이제 Excel로 내보낼 수 있습니다.',
    batchErrorCount(state.batchRows) ? 'warn' : 'ok');
  }

  function receiveBatchExported(payload) {
    const path = text(read(payload, 'path', 'Path'));
    if (!path || read(payload, 'ok', 'Ok') === false || read(payload, 'cancelled', 'Cancelled') === true) {
      setBatchBusy(false);
      toast(text(read(payload, 'message', 'Message')) || 'Excel 저장을 취소했거나 실패했습니다.', 'warn');
      return;
    }
    state.batchWorkbookPath = path;
    clearBatchApplyAuthorization();
    renderBatchWorkbook();
    setBatchBusy(false);
    requestAnimationFrame(() => {
      if (page.isConnected) showExcelSavedDialog('링크 공유좌표 검토용 Excel을 저장했습니다.', path, (savedPath) => post('excel:open', { path: savedPath }));
    });
  }

  function receiveBatchTemplateExported(payload) {
    const path = text(read(payload, 'path', 'Path'));
    if (!path || read(payload, 'ok', 'Ok') === false || read(payload, 'cancelled', 'Cancelled') === true) {
      setBatchBusy(false);
      toast(text(read(payload, 'message', 'Message')) || '샘플 양식 저장을 취소했거나 실패했습니다.', 'warn');
      return;
    }
    setBatchBusy(false);
    requestAnimationFrame(() => {
      if (page.isConnected) showExcelSavedDialog('링크 공유좌표 Excel 양식 예시를 저장했습니다.', path, (savedPath) => post('excel:open', { path: savedPath }), { description: '이 예시는 적용 데이터로 사용되지 않습니다. 저장한 파일을 바로 여시겠습니까?' });
    });
  }

  function receiveBatchApplied(payload) {
    if (Array.isArray(payload?.rows)) state.batchRows = payload.rows;
    state.batchWorkbookPath = text(read(payload, 'workbookPath', 'WorkbookPath')) || state.batchWorkbookPath;
    state.batchDatasetToken = text(read(payload, 'datasetToken', 'DatasetToken'));
    state.batchApplyReady = read(payload, 'applyReady', 'ApplyReady') === true && !!state.batchDatasetToken;
    renderBatchRows(payload?.summary || null);
    setBatchBusy(false);
    const cancelled = read(payload, 'cancelled', 'Cancelled') === true;
    if (cancelled) {
      toast('호스트 링크 배치 적용을 취소했습니다.', 'warn');
      return;
    }
    const errors = Number(read(payload?.summary || {}, 'errorCount', 'ErrorCount') || batchErrorCount(state.batchRows));
    const changed = Number(read(payload?.summary || {}, 'changedCount', 'ChangedCount') || 0);
    const ok = read(payload, 'ok', 'Ok');
    toast(`호스트 링크 배치 적용: 변경 ${changed}건, 오류 ${errors}건`, errors || ok === false ? 'warn' : 'ok', 5000);
  }

  function receiveBatchProgress(payload) {
    const message = text(read(payload, 'message', 'Message')) || '처리 중…';
    ui.batchStatus.textContent = message;
    ui.batchStatus.dataset.tone = 'warn';
  }

  function receiveBatchError(payload) {
    clearBatchApplyAuthorization();
    setBatchBusy(false);
    const message = text(read(payload, 'message', 'Message')) || 'Excel 일괄 처리 중 오류가 발생했습니다.';
    const detail = text(read(payload, 'detail', 'Detail'));
    ui.batchStatus.textContent = '오류';
    ui.batchStatus.dataset.tone = 'warn';
    toast(detail ? `${message}\n${detail}` : message, 'err', 6500);
  }

  function receiveHostError(payload) {
    const sourceEvent = text(read(payload, 'sourceEvent', 'SourceEvent'));
    if (!state.batchBusy && !state.busyAction && !sourceEvent.startsWith('linksharedcoord:')) return;
    clearBatchApplyAuthorization();
    setBusy('');
    setBatchBusy(false);
    const message = text(read(payload, 'message', 'Message')) || 'Revit 호스트 통신 중 오류가 발생했습니다.';
    const detail = text(read(payload, 'detail', 'Detail'));
    toast(detail ? `${message}\n${detail}` : message, 'err', 6500);
  }

  function scanBatch(mode) {
    const nextMode = mode === 'files' ? 'files' : 'active';
    if (nextMode === 'files' && !state.batchRvtPaths.length) {
      toast('검토할 RVT 파일을 먼저 추가해 주세요.', 'warn');
      return;
    }
    if (nextMode === 'active' && !state.activeHostAvailable) {
      toast('열려 있는 활성 Revit 문서가 없습니다.', 'warn');
      return;
    }
    state.batchMode = nextMode;
    state.batchRows = [];
    state.batchWorkbookPath = '';
    clearBatchApplyAuthorization();
    renderBatchWorkbook();
    renderBatchRows();
    setBatchBusy(true, '링크 분석 중…');
    postBatch('linksharedcoord:batch-scan', batchPayload());
  }

  function exportTemplateBatch() {
    if (state.batchBusy) return;
    setBatchBusy(true, '템플릿 저장 중…');
    postBatch('linksharedcoord:batch-export-template', {});
  }

  function exportBatch() {
    if (!state.batchRows.length) {
      toast('먼저 링크 검토표를 생성해 주세요.', 'warn');
      return;
    }
    setBatchBusy(true, 'Excel 저장 중…');
    postBatch('linksharedcoord:batch-export', batchPayload());
  }

  function importBatch() {
    if (!state.batchWorkbookPath) {
      toast('검토한 Excel 파일을 먼저 선택해 주세요.', 'warn');
      return;
    }
    state.batchRows = [];
    clearBatchApplyAuthorization();
    renderBatchRows();
    setBatchBusy(true, 'Excel 읽는 중…');
    postBatch('linksharedcoord:batch-import', { path: state.batchWorkbookPath });
  }

  function applyBatch() {
    if (!state.batchApplyReady || !state.batchDatasetToken) {
      toast('검토 Excel을 다시 불러와 현재 모델 재검토를 완료해 주세요.', 'warn');
      return;
    }
    const applyRows = state.batchRows.filter(isPendingBatchApply);
    if (!applyRows.length) {
      toast('Excel에서 Action을 APPLY로 지정한 뒤 다시 불러와 주세요.', 'warn');
      return;
    }
    setBatchBusy(true, '호스트별 적용 중…');
    postBatch('linksharedcoord:batch-apply', {
      workbookPath: state.batchWorkbookPath,
      datasetToken: state.batchDatasetToken
    });
  }

  function postBatch(eventName, payload) {
    const sent = post(eventName, payload || {});
    if (sent !== false) return true;
    setBatchBusy(false);
    return false;
  }

  function clearBatchApplyAuthorization() {
    state.batchDatasetToken = '';
    state.batchApplyReady = false;
  }

  function isPendingBatchApply(row) {
    const action = text(read(row, 'Action', 'action')).toUpperCase();
    const reviewStatus = text(read(row, 'ReviewStatus', 'reviewStatus')).toUpperCase();
    const applyStatus = text(read(row, 'ApplyStatus', 'applyStatus')).toUpperCase();
    const rawCanApply = read(row, 'CanApply', 'canApply');
    const canApply = rawCanApply === true || text(rawCanApply).toLowerCase() === 'true';
    const reviewReady = reviewStatus === 'READY' || reviewStatus === 'DEFERRED_CLOSED_WORKSET';
    return action === 'APPLY' && reviewReady && applyStatus === 'PENDING' && canApply;
  }

  function batchPayload() {
    return {
      mode: state.batchMode,
      rvtPaths: state.batchRvtPaths.slice(),
      workbookPath: state.batchWorkbookPath
    };
  }

  function renderBatchFiles() {
    ui.batchFiles.innerHTML = '';
    renderBatchTargetCopy();
    if (!state.batchRvtPaths.length) {
      ui.batchFiles.innerHTML = '<span class="linksharedcoord-batch-placeholder">등록된 RVT가 없습니다.</span>';
      return;
    }
    state.batchRvtPaths.forEach((path) => {
      const row = div('linksharedcoord-batch-file');
      const label = document.createElement('span');
      label.textContent = path;
      label.title = path;
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.textContent = '선택 해제';
      remove.addEventListener('click', () => {
        toggleRvtTarget3(path, false);
      });
      row.append(label, remove);
      ui.batchFiles.append(row);
    });
  }

  function renderBatchTargetCopy() {
    const activeText = state.activeHostAvailable
      ? `활성 문서: ${state.activeHostName}`
      : '활성 문서: 연결 없음';
    const filesText = state.batchRvtPaths.length
      ? `여러 RVT: ${state.batchRvtPaths.length}개 등록됨`
      : '여러 RVT: 등록 없음';
    ui.batchTargetCopy.textContent = `${activeText} · ${filesText}`;
  }

  function renderBatchWorkbook() {
    ui.batchWorkbook.textContent = state.batchWorkbookPath || '선택된 Excel 없음';
    ui.batchWorkbook.title = state.batchWorkbookPath || '';
  }

  function renderBatchRows(summaryPayload = null) {
    const rows = Array.isArray(state.batchRows) ? state.batchRows : [];
    const applyCount = rows.filter((row) => text(read(row, 'Action', 'action')).toUpperCase() === 'APPLY').length;
    const applicableCount = rows.filter(isPendingBatchApply).length;
    const deferredCount = rows.filter((row) => text(read(row, 'ReviewStatus', 'reviewStatus')).toUpperCase() === 'DEFERRED_CLOSED_WORKSET').length;
    const hostCount = new Set(rows.map((row) => text(read(row, 'HostFilePath', 'hostFilePath', 'HostFileName', 'hostFileName')).toLowerCase()).filter(Boolean)).size;
    const errorCount = Number(read(summaryPayload || {}, 'errorCount', 'ErrorCount') || batchErrorCount(rows));
    ui.batchSummary.textContent = rows.length
      ? `호스트 ${hostCount || 1}개 · 링크 ${rows.length}건 · APPLY 요청 ${applyCount}건 / 적용 가능 ${applicableCount}건 · 닫힌 웍셋 재검증 ${deferredCount}건 · 오류/차단 ${errorCount}건`
      : '아직 추출된 링크가 없습니다.';
    ui.batchBody.innerHTML = '';
    if (!rows.length) {
      const empty = document.createElement('tr');
      empty.innerHTML = '<td colspan="12" class="linksharedcoord-empty">활성 문서 또는 RVT 파일을 분석해 주세요.</td>';
      ui.batchBody.append(empty);
      return;
    }
    rows.forEach((item) => {
      const row = document.createElement('tr');
      const reviewStatus = text(read(item, 'ReviewStatus', 'reviewStatus'));
      const applyStatus = text(read(item, 'ApplyStatus', 'applyStatus'));
      const message = text(read(item, 'ApplyMessage', 'applyMessage')) || text(read(item, 'ReviewMessage', 'reviewMessage'));
      const typeWorkset = text(read(item, 'TypeWorksetName', 'typeWorksetName')) || '-';
      const instanceWorkset = text(read(item, 'InstanceWorksetName', 'instanceWorksetName')) || '-';
      const instanceName = text(read(item, 'LinkInstanceName', 'linkInstanceName', 'LinkName', 'linkName'));
      const typeName = text(read(item, 'LinkTypeName', 'linkTypeName'));
      const linkLabel = instanceName || (typeName ? `${typeName} (타입 메타데이터)` : '-');
      const originalPlacement = text(read(item, 'OriginalPlacementMethod', 'originalPlacementMethod')) || '확인 불가 (Revit API 미제공)';
      const currentPlacement = text(read(item, 'CurrentPlacementMethod', 'currentPlacementMethod')) || '확인 불가';
      const placementDetails = text(read(item, 'CurrentPlacementDetails', 'currentPlacementDetails'));
      const sharedSiteStatus = text(read(item, 'InstanceSharedSiteStatus', 'instanceSharedSiteStatus')) || 'UNAVAILABLE';
      const sharedSiteName = text(read(item, 'InstanceSharedSiteName', 'instanceSharedSiteName')) ||
        (sharedSiteStatus === 'NOT_SHARED' ? '<Not Shared>' : sharedSiteStatus === 'UNAVAILABLE' ? '확인 불가' : '-');
      const linkedActiveSite = text(read(
        item,
        'LinkedDocumentActiveProjectLocationName', 'linkedDocumentActiveProjectLocationName'
      )) || '확인 불가';
      const placementSiteText = [
        `최초: ${originalPlacement}`,
        `현재: ${currentPlacement}`,
        `Instance Shared Site: ${sharedSiteName} (${sharedSiteStatus})`,
        `Link Active Site: ${linkedActiveSite}`,
        placementDetails ? `근거: ${placementDetails}` : ''
      ].filter(Boolean).join('\n');
      const unit = text(read(item, 'Unit', 'unit')) || 'mm';
      const transformAvailable = read(item, 'TransformAvailable', 'transformAvailable') === true;
      const transformText = transformAvailable
        ? `E ${formatNumber(read(item, 'InstanceTransformE', 'instanceTransformE'))}, N ${formatNumber(read(item, 'InstanceTransformN', 'instanceTransformN'))}, Z ${formatNumber(read(item, 'InstanceTransformZ', 'instanceTransformZ'))} ${unit} / ${formatNumber(read(item, 'InstanceTransformBearingDegrees', 'instanceTransformBearingDegrees'))}°`
        : '-';
      const a1AnalysisAvailable = read(item, 'A1AnalysisAvailable', 'a1AnalysisAvailable') === true;
      const a1CurrentText = a1AnalysisAvailable
        ? `E ${formatNumber(read(item, 'CurrentE', 'currentE'))}, N ${formatNumber(read(item, 'CurrentN', 'currentN'))}, Z ${formatNumber(read(item, 'CurrentZ', 'currentZ'))} ${unit} / ${formatNumber(read(item, 'CurrentBearingDegrees', 'currentBearingDegrees'))}°`
        : '-';
      const a1DeltaText = a1AnalysisAvailable
        ? `목표 E ${formatNumber(read(item, 'ResolvedTargetE', 'resolvedTargetE'))}, N ${formatNumber(read(item, 'ResolvedTargetN', 'resolvedTargetN'))}, Z ${formatNumber(read(item, 'ResolvedTargetZ', 'resolvedTargetZ'))} ${unit} / ${formatNumber(read(item, 'ResolvedTargetBearingDegrees', 'resolvedTargetBearingDegrees'))}° · ΔE ${formatNumber(read(item, 'DeltaE', 'deltaE'))}, ΔN ${formatNumber(read(item, 'DeltaN', 'deltaN'))}, ΔZ ${formatNumber(read(item, 'DeltaZ', 'deltaZ'))} ${unit} / 거리 ${formatNumber(read(item, 'MoveDistance', 'moveDistance'))} ${unit} / Δ각(CW+) ${formatNumber(read(item, 'DeltaBearingDegrees', 'deltaBearingDegrees'))}°`
        : '-';
      [
        text(read(item, 'Action', 'action')) || 'REVIEW',
        text(read(item, 'HostFileName', 'hostFileName')) || '-',
        linkLabel,
        placementSiteText,
        `${typeWorkset} / ${instanceWorkset}`,
        text(read(item, 'LinkedFileStatus', 'linkedFileStatus')) || (read(item, 'Loaded', 'loaded') === false ? 'Unloaded' : 'Loaded'),
        transformText,
        a1CurrentText,
        a1DeltaText,
        reviewStatus || '-',
        applyStatus || '-',
        message || '-'
      ].forEach((value, index) => {
        const cell = document.createElement('td');
        cell.textContent = value;
        cell.title = value;
        if (index === 3) cell.className = 'linksharedcoord-batch-placement';
        if (index === 11) cell.className = 'linksharedcoord-batch-message';
        row.append(cell);
      });
      if (/error|blocked|rollback|failed|stale|metadata|input_required|status_only/i.test(`${reviewStatus} ${applyStatus}`)) row.dataset.tone = 'warn';
      ui.batchBody.append(row);
    });
  }

  function batchErrorCount(rows) {
    return (Array.isArray(rows) ? rows : []).filter((row) => /error|blocked|rollback|failed|stale|metadata|input_required|status_only/i.test(
      `${text(read(row, 'ReviewStatus', 'reviewStatus'))} ${text(read(row, 'ApplyStatus', 'applyStatus'))}`
    )).length;
  }

  function setBatchBusy(busy, label) {
    state.batchBusy = !!busy;
    ui.batchStatus.textContent = busy ? (label || '처리 중…') : '준비됨';
    ui.batchStatus.dataset.tone = busy ? 'warn' : 'ok';
    page.classList.toggle('is-busy', !!state.busyAction || state.batchBusy);
    syncActions();
  }

  function receiveContext(payload) {
    state.context = payload || {};
    state.links = normalizeLinks(read(payload, 'links', 'linkInstances', 'Links', 'LinkInstances'));
    state.projectLocations = normalizeOptions(read(payload, 'projectLocations', 'sites', 'ProjectLocations', 'Sites'));

    const host = read(payload, 'hostDocument', 'host', 'activeDocument', 'HostDocument', 'Host', 'ActiveDocument') || {};
    const rawHostName = text(read(host, 'title', 'name', 'fileName', 'Title', 'Name', 'FileName'));
    const hostName = rawHostName || '활성 호스트 없음';
    const hostKey = text(read(host, 'path', 'filePath', 'id', 'Path', 'FilePath', 'Id')) || rawHostName;
    if (state.activeHostKey && state.activeHostKey.toLowerCase() !== hostKey.toLowerCase() && state.batchMode === 'active') {
      invalidateBatchDataset('활성 문서가 변경되어 기존 Excel 선택과 결과를 초기화했습니다.');
    }
    state.activeHostAvailable = !!rawHostName;
    state.activeHostName = rawHostName;
    state.activeHostKey = hostKey;
    renderBatchTargetCopy();
    const activeLocation = read(payload, 'activeProjectLocation', 'ActiveProjectLocation') ||
      read(host, 'activeProjectLocation', 'projectLocation', 'ActiveProjectLocation', 'ProjectLocation') || {};
    const locationName = typeof activeLocation === 'string'
      ? activeLocation
      : text(read(activeLocation, 'name', 'Name'));
    const bearing = numberOrNull(read(activeLocation, 'bearingDegrees', 'trueNorthDegrees', 'BearingDegrees', 'TrueNorthDegrees')) ??
      numberOrNull(read(host, 'bearingDegrees', 'trueNorthDegrees', 'BearingDegrees', 'TrueNorthDegrees'));

    ui.hostName.textContent = hostName;
    ui.hostLocation.textContent = locationName || '-';
    ui.hostBearing.textContent = bearing == null ? '-' : `${formatNumber(bearing)}°`;
    ui.linkCount.textContent = `${state.links.filter(isSupportedLink).length}/${state.links.length} 선택 가능`;
    ui.hostStatus.textContent = state.links.length ? '준비됨' : '링크 없음';
    ui.hostStatus.dataset.tone = state.links.length ? 'ok' : 'warn';

    renderLinkOptions();
    applyDefaults(read(payload, 'defaults', 'Defaults') || {});
    selectLink();
    setBusy('');
    syncActions();
  }

  function receiveAnalysis(payload) {
    const analysis = normalizeAnalysis(read(payload, 'analysis', 'result', 'Analysis', 'Result') || payload || {});
    state.analysis = analysis;
    setBusy('');
    renderAnalysis();
    syncActions();
    toast(analysis.message || 'Shared Coordination 분석을 완료했습니다.', analysis.warnings.length ? 'warn' : 'ok');
  }

  function receiveApplied(payload) {
    setBusy('');
    const embedded = read(payload, 'analysis', 'result', 'Analysis', 'Result');
    const directAnalysis = read(payload, 'current', 'Current') || read(payload, 'analysisToken', 'AnalysisToken')
      ? payload
      : null;
    if (embedded || directAnalysis) state.analysis = normalizeAnalysis(embedded || directAnalysis);
    if (state.analysis) {
      state.analysis.applied = true;
      renderAnalysis();
    }
    ui.actionCopy.textContent = text(read(payload, 'message', 'Message')) || '호스트 링크 배치를 적용했습니다. Publish 전 결과를 다시 확인해 주세요.';
    toast(ui.actionCopy.textContent, read(payload, 'ok', 'Ok') === false ? 'warn' : 'ok');
    syncActions();
  }

  function receivePublished(payload) {
    setBusy('');
    const ok = read(payload, 'ok', 'Ok') !== false;
    const cancelled = read(payload, 'cancelled', 'canceled', 'Cancelled', 'Canceled') === true;
    const published = read(payload, 'published', 'Published');
    const saved = read(payload, 'linkPositionsSaved', 'saved', 'linkSaved', 'LinkPositionsSaved', 'Saved', 'LinkSaved');
    const wasPublished = published === true && !cancelled;
    const message = text(read(payload, 'message', 'Message')) || (cancelled
      ? 'Publish와 링크 위치 저장이 취소되었습니다.'
      : saved === false
        ? 'Publish는 완료됐지만 링크 위치 저장 상태를 확인해야 합니다.'
        : 'Shared Site Publish와 링크 위치 저장을 완료했습니다.');
    ui.actionCopy.textContent = message;
    ui.publishConfirm.checked = false;
    const tone = cancelled
      ? 'warn'
      : wasPublished && saved === false
        ? 'warn'
        : !ok
          ? 'err'
          : saved === false
            ? 'warn'
            : 'ok';
    toast(message, tone, 4200);
    if (state.analysis) state.analysis.published = wasPublished;
    if (!cancelled && (saved === true || (wasPublished && saved === false))) {
      state.analysis = null;
      renderAnalysis();
      syncActions();
      if (saved === true) post('linksharedcoord:init', {});
      return;
    }
    syncActions();
  }

  function receiveError(payload) {
    setBusy('');
    const message = text(read(payload, 'message', 'Message')) || 'Shared Coordination 처리 중 오류가 발생했습니다.';
    const detail = text(read(payload, 'detail', 'Detail'));
    ui.actionCopy.textContent = detail ? `${message} · ${detail}` : message;
    toast(ui.actionCopy.textContent, 'err', 5000);
    syncActions();
  }

  function renderLinkOptions() {
    const previous = String(linkSelect.value || '');
    linkSelect.replaceChildren(option('', '링크 인스턴스를 선택해 주세요.'));
    state.links.forEach((item) => {
      const suffix = `${item.loaded ? '' : ' · 미로드'}${item.nested ? ' · 중첩' : ''}${item.cloud ? ' · Cloud' : ''}` +
        `${item.scenarioStatusKnown ? '' : ' · Scenario 판별 실패'}${item.scenarioBased ? ' · Forma Scenario' : ''}`;
      const entry = option(item.id, `${item.name || item.fileName || `Link ${item.id}`}${suffix}`);
      entry.disabled = !isSupportedLink(item);
      linkSelect.append(entry);
    });
    if (state.links.some((item) => String(item.id) === previous && isSupportedLink(item))) linkSelect.value = previous;
    else {
      const firstLoaded = state.links.find(isSupportedLink);
      linkSelect.value = firstLoaded ? String(firstLoaded.id) : '';
    }
  }

  function selectLink() {
    state.selectedLink = state.links.find((item) => String(item.id) === String(linkSelect.value)) || null;
    renderLevelOptions();
    renderSiteOptions();
    renderPlacementSummary(state.selectedLink);
  }

  function renderLevelOptions() {
    const previous = String(levelSelect.value || '');
    const levels = state.selectedLink?.levels || [];
    levelSelect.replaceChildren(option('', levels.length ? '기준 Level을 선택해 주세요.' : 'Level 정보 없음'));
    levels.forEach((item) => levelSelect.append(option(item.id, item.label)));
    if (levels.some((item) => String(item.id) === previous)) levelSelect.value = previous;
    else {
      const preferred = levels.find((item) => item.preferred) || levels[0];
      levelSelect.value = preferred ? String(preferred.id) : '';
    }
  }

  function renderSiteOptions() {
    const previous = String(siteSelect.value || '');
    const linkSites = state.selectedLink?.sites || [];
    const sites = linkSites.length ? linkSites : state.projectLocations;
    siteSelect.replaceChildren(option('', sites.length ? 'Project Location을 선택해 주세요.' : '저장된 Site 없음'));
    sites.forEach((item) => siteSelect.append(option(item.id, item.label)));
    if (sites.some((item) => String(item.id) === previous)) siteSelect.value = previous;
    else {
      const preferred = sites.find((item) => item.currentSharedSite) ||
        sites.find((item) => item.preferred) ||
        sites.find((item) => item.active) ||
        sites[0];
      siteSelect.value = preferred ? String(preferred.id) : '';
    }
  }

  function applyDefaults(defaults) {
    anchorA.value = text(read(defaults, 'anchorGrid1', 'AnchorGrid1')) || anchorA.value || 'A';
    anchor1.value = text(read(defaults, 'anchorGrid2', 'AnchorGrid2')) || anchor1.value || '1';
    directionA.value = text(read(defaults, 'directionGrid1', 'DirectionGrid1')) || directionA.value || 'A';
    direction2.value = text(read(defaults, 'directionGrid2', 'DirectionGrid2')) || direction2.value || '2';
    const defaultDirection = text(read(defaults, 'directionMode', 'DirectionMode'));
    if (defaultDirection && Array.from(directionMode.options).some((item) => item.value === defaultDirection)) directionMode.value = defaultDirection;
    const defaultSource = text(read(defaults, 'targetSource', 'TargetSource'));
    if (defaultSource && Array.from(targetSource.options).some((item) => item.value === defaultSource)) targetSource.value = defaultSource;
    const defaultUnit = text(read(defaults, 'unit', 'Unit')).toLowerCase();
    if (defaultUnit === 'm' || defaultUnit === 'mm') unitSelect.value = defaultUnit;
    syncDirectionMode();
    syncTargetSource();
  }

  function syncDirectionMode() {
    const manualDirection = directionMode.value === 'secondIntersection';
    directionA.disabled = !manualDirection;
    direction2.disabled = !manualDirection;
    directionA.closest('.linksharedcoord-field')?.classList.toggle('is-disabled', !manualDirection);
    direction2.closest('.linksharedcoord-field')?.classList.toggle('is-disabled', !manualDirection);
  }

  function syncTargetSource() {
    const manual = targetSource.value === 'manual';
    siteSelect.disabled = false;
    siteSelect.closest('.linksharedcoord-field')?.classList.remove('is-disabled');
    manualPanel.classList.toggle('is-disabled', !manual);
    [manualEast, manualNorth, manualElevation, manualBearing].forEach((control) => { control.disabled = !manual; });
  }

  function invalidateAnalysis() {
    if (!state.analysis) {
      renderPlacementSummary(state.selectedLink);
      syncActions();
      return;
    }
    state.analysis = null;
    ui.publishConfirm.checked = false;
    renderAnalysis();
    ui.actionCopy.textContent = '설정이 변경되었습니다. 적용 전에 다시 분석해 주세요.';
    syncActions();
  }

  function analyze() {
    const validation = validatePayload(false);
    if (validation) {
      toast(validation, 'warn');
      return;
    }
    setBusy('analyze');
    post('linksharedcoord:analyze', buildPayload(false));
  }

  function applyPlacement() {
    const validation = validatePayload(true);
    if (validation) {
      toast(validation, 'warn');
      return;
    }
    if (!window.confirm('분석된 이동·회전값을 활성 호스트의 선택 링크 인스턴스에 적용할까요?')) return;
    setBusy('apply');
    post('linksharedcoord:apply', buildPayload(true));
  }

  function publishAndSave() {
    const validation = validatePayload(true);
    if (validation) {
      toast(validation, 'warn');
      return;
    }
    if (!ui.publishConfirm.checked) {
      toast('Publish와 링크 파일 저장 확인 항목을 먼저 선택해 주세요.', 'warn');
      return;
    }
    const linkName = state.selectedLink?.name || state.selectedLink?.fileName || '선택 링크';
    const confirmed = window.confirm(
      `${linkName}에 Shared Site를 Publish하고 링크 파일을 저장합니다.\n` +
      '외부 링크 파일의 좌표 정보가 변경됩니다. 계속할까요?'
    );
    if (!confirmed) return;
    setBusy('publish');
    post('linksharedcoord:publish', {
      ...buildPayload(true),
      saveLinkedDocument: true,
      confirmationText: PUBLISH_CONFIRMATION
    });
  }

  function validatePayload(requireAnalysis) {
    if (!state.selectedLink || !isSupportedLink(state.selectedLink)) return '로드된 최상위 Revit 링크 인스턴스를 선택해 주세요. Forma Scenario 링크는 지원하지 않습니다.';
    if (!anchorA.value.trim() || !anchor1.value.trim()) return '교차점을 정의할 Grid 두 개를 입력해 주세요.';
    if (!levelSelect.value) return '기준 Level을 선택해 주세요.';
    if (directionMode.value === 'secondIntersection' && (!directionA.value.trim() || !direction2.value.trim())) {
      return '방향을 정의할 두 번째 교차점 Grid를 입력해 주세요.';
    }
    if (!siteSelect.value) return 'Publish 대상으로 사용할 기존 Project Location을 선택해 주세요.';
    if (targetSource.value === 'manual') {
      const values = [manualEast.value, manualNorth.value, manualElevation.value, manualBearing.value];
      if (values.some((value) => value.trim() === '' || !Number.isFinite(Number(value)))) return '직접 입력 E/N/Z/Bearing 값을 모두 숫자로 입력해 주세요.';
    }
    if (requireAnalysis && !state.analysis?.analysisToken) return '현재 설정으로 분석을 먼저 실행해 주세요.';
    return '';
  }

  function buildPayload(includeToken) {
    const selectedLevel = levelSelect.options[levelSelect.selectedIndex];
    const selectedSite = siteSelect.options[siteSelect.selectedIndex];
    const payload = {
      linkInstanceId: idValue(state.selectedLink?.id),
      anchorGrid1: anchorA.value.trim(),
      anchorGrid2: anchor1.value.trim(),
      levelId: idValue(levelSelect.value),
      levelName: selectedLevel?.textContent || '',
      directionMode: directionMode.value,
      directionGrid1: directionA.value.trim(),
      directionGrid2: direction2.value.trim(),
      targetSource: targetSource.value,
      targetProjectLocationId: idValue(siteSelect.value),
      targetProjectLocationName: selectedSite?.textContent || '',
      unit: unitSelect.value,
      manual: {
        east: numberOrNull(manualEast.value),
        north: numberOrNull(manualNorth.value),
        elevation: numberOrNull(manualElevation.value),
        bearingDegrees: numberOrNull(manualBearing.value)
      }
    };
    if (includeToken) payload.analysisToken = state.analysis?.analysisToken || '';
    return payload;
  }

  function setBusy(action) {
    state.busyAction = action || '';
    page.classList.toggle('is-busy', !!state.busyAction || state.batchBusy);
    analyzeButton.textContent = action === 'analyze' ? '분석 중…' : 'Shared Coordination 분석';
    applyButton.textContent = action === 'apply' ? '배치 적용 중…' : '호스트 링크 배치 적용';
    publishButton.textContent = action === 'publish' ? 'Publish 및 저장 중…' : 'Publish + Link 파일 저장';
    syncActions();
  }

  function syncActions() {
    const busy = !!state.busyAction;
    const anyBusy = busy || state.batchBusy;
    const hasLink = isSupportedLink(state.selectedLink);
    const hasAnalysis = !!state.analysis?.analysisToken;
    analyzeButton.disabled = anyBusy || !hasLink;
    applyButton.disabled = anyBusy || !hasAnalysis || state.analysis?.canApply === false;
    publishButton.disabled = anyBusy || !hasAnalysis || state.analysis?.canPublish === false || !ui.publishConfirm.checked;
    invalidateInputs.forEach((control) => { control.disabled = anyBusy || control.dataset.locked === 'true'; });
    if (!anyBusy) {
      syncDirectionMode();
      syncTargetSource();
    }
    ui.publishConfirm.disabled = anyBusy || !hasAnalysis || state.analysis?.canPublish === false;

    const hasApplyRows = state.batchRows.some(isPendingBatchApply);
    ui.batchAdd.disabled = anyBusy;
    ui.batchClear.disabled = anyBusy || !state.batchRvtPaths.length;
    ui.batchScanActive.disabled = anyBusy || !state.activeHostAvailable;
    ui.batchScanFiles.disabled = anyBusy || !state.batchRvtPaths.length;
    ui.batchTemplate.disabled = anyBusy;
    ui.batchExport.disabled = anyBusy || !state.batchRows.length;
    ui.batchPickExcel.disabled = anyBusy;
    ui.batchImport.disabled = anyBusy || !state.batchWorkbookPath;
    ui.batchApply.disabled = anyBusy || !state.batchApplyReady || !state.batchDatasetToken || !hasApplyRows;
    ui.workspaceModes.forEach((button) => { button.disabled = anyBusy; });
  }

  function renderAnalysis() {
    const analysis = state.analysis;
    ui.resultBody.innerHTML = '';
    ui.warnings.innerHTML = '';
    ui.warnings.hidden = true;
    renderPlacementSummary(analysis || state.selectedLink);

    if (!analysis) {
      ui.analysisStatus.textContent = '분석 전';
      ui.analysisStatus.dataset.tone = '';
      ui.anchorSummary.textContent = '링크와 기준을 선택한 뒤 분석을 실행해 주세요.';
      const row = document.createElement('tr');
      row.innerHTML = '<td colspan="5" class="linksharedcoord-empty">분석 결과가 없습니다.</td>';
      ui.resultBody.append(row);
      return;
    }

    ui.analysisStatus.textContent = analysis.warnings.length ? '검토 필요' : '적용 가능';
    ui.analysisStatus.dataset.tone = analysis.warnings.length ? 'warn' : 'ok';
    ui.anchorSummary.textContent = analysis.anchorSummary || `${anchorA.value.trim()} × ${anchor1.value.trim()} · ${levelSelect.options[levelSelect.selectedIndex]?.textContent || '-'}`;
    [
      ['현재', analysis.current, 'current'],
      ['목표', analysis.target, 'target'],
      ['변화량', analysis.delta, 'delta']
    ].forEach(([label, value, kind]) => {
      const row = document.createElement('tr');
      row.dataset.kind = kind;
      row.append(
        cell(label, 'linksharedcoord-result-label'),
        cell(formatCoordinate(value.east)),
        cell(formatCoordinate(value.north)),
        cell(formatCoordinate(value.elevation)),
        cell(`${formatNumber(value.bearingDegrees)}°`)
      );
      ui.resultBody.append(row);
    });

    if (analysis.warnings.length) {
      ui.warnings.hidden = false;
      const title = document.createElement('strong');
      title.textContent = '적용 전 확인';
      const list = document.createElement('ul');
      analysis.warnings.forEach((warning) => {
        const item = document.createElement('li');
        item.textContent = warning;
        list.append(item);
      });
      ui.warnings.append(title, list);
    }
  }

  function renderPlacementSummary(source) {
    const original = text(source?.originalPlacementMethod) || '확인 불가 (Revit API 미제공)';
    const current = text(source?.currentPlacementMethod) || '확인 불가';
    const details = text(source?.currentPlacementDetails);
    const siteStatus = text(source?.instanceSharedSiteStatus) || 'UNAVAILABLE';
    const siteName = text(source?.instanceSharedSiteName) ||
      (siteStatus === 'NOT_SHARED' ? '<Not Shared>' : siteStatus === 'UNAVAILABLE' ? '확인 불가' : '-');
    const activeSite = text(source?.linkedDocumentActiveProjectLocationName) || '확인 불가';
    const selectedSite = text(source?.targetProjectLocationName) ||
      text(siteSelect.options[siteSelect.selectedIndex]?.textContent) || '-';
    ui.placementSummary.textContent = [
      `최초 Positioning: ${original}`,
      `현재 배치: ${current}`,
      `Instance Shared Site: ${siteName} (${siteStatus})`,
      `Link Active Site: ${activeSite}`,
      `Target Site: ${selectedSite}`,
      details ? `판정 근거: ${details}` : ''
    ].filter(Boolean).join(' · ');
    ui.placementSummary.title = ui.placementSummary.textContent;
  }

  function formatCoordinate(value) {
    return `${formatNumber(value)} ${unitSelect.value}`;
  }
}

function createSelectField(parent, label, hint, name) {
  const field = createField(label, hint);
  const select = document.createElement('select');
  select.className = 'feature-input linksharedcoord-input';
  select.dataset.field = name || '';
  field.append(select);
  parent.append(field);
  return select;
}

function createTextField(parent, label, hint, value) {
  const field = createField(label, hint);
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'feature-input linksharedcoord-input';
  input.value = value || '';
  input.autocomplete = 'off';
  field.append(input);
  parent.append(field);
  return input;
}

function createNumberField(parent, label, value) {
  const field = createField(label, '');
  const input = document.createElement('input');
  input.type = 'number';
  input.step = 'any';
  input.className = 'feature-input linksharedcoord-input';
  input.value = value || '0';
  field.append(input);
  parent.append(field);
  return input;
}

function createField(label, hint) {
  const field = div('linksharedcoord-field');
  const labelEl = document.createElement('label');
  labelEl.textContent = label;
  field.append(labelEl);
  if (hint) {
    const hintEl = document.createElement('span');
    hintEl.textContent = hint;
    field.append(hintEl);
  }
  return field;
}

function createButton(label, modifier) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = `btn ${modifier || ''}`.trim();
  button.textContent = label;
  return button;
}

function addOptions(select, items) {
  items.forEach((item) => select.append(option(item.value, item.label)));
}

function option(value, label) {
  const item = document.createElement('option');
  item.value = value == null ? '' : String(value);
  item.textContent = label == null ? '' : String(label);
  return item;
}

function cell(value, className) {
  const item = document.createElement('td');
  item.textContent = value == null ? '-' : String(value);
  if (className) item.className = className;
  return item;
}

function normalizeLinks(raw) {
  const items = Array.isArray(raw) ? raw : [];
  return items.map((item, index) => ({
    id: read(item, 'id', 'elementId', 'linkInstanceId', 'Id', 'ElementId', 'LinkInstanceId') ?? index + 1,
    name: text(read(item, 'name', 'displayName', 'instanceName', 'Name', 'DisplayName', 'InstanceName')),
    fileName: text(read(item, 'fileName', 'linkFileName', 'FileName', 'LinkFileName')),
    loaded: read(item, 'loaded', 'isLoaded', 'Loaded', 'IsLoaded') !== false,
    pinned: read(item, 'pinned', 'isPinned', 'Pinned', 'IsPinned') === true,
    nested: read(item, 'nested', 'isNested', 'Nested', 'IsNested') === true,
    cloud: read(item, 'cloud', 'isCloud', 'Cloud', 'IsCloud') === true,
    scenarioBased: read(item, 'scenarioBased', 'isScenarioBased', 'ScenarioBased', 'IsScenarioBased') === true,
    scenarioStatusKnown: read(item, 'scenarioStatusKnown', 'ScenarioStatusKnown') === true,
    originalPlacementMethod: text(read(item, 'originalPlacementMethod', 'OriginalPlacementMethod')),
    currentPlacementMethod: text(read(item, 'currentPlacementMethod', 'CurrentPlacementMethod')),
    currentPlacementMethodCode: text(read(item, 'currentPlacementMethodCode', 'CurrentPlacementMethodCode')),
    currentPlacementDetails: text(read(item, 'currentPlacementDetails', 'CurrentPlacementDetails')),
    instanceSharedSiteName: text(read(item, 'instanceSharedSiteName', 'InstanceSharedSiteName')),
    instanceSharedSiteStatus: text(read(item, 'instanceSharedSiteStatus', 'InstanceSharedSiteStatus')),
    linkedDocumentActiveProjectLocationName: text(read(
      item,
      'activeProjectLocationName', 'linkedDocumentActiveProjectLocationName',
      'ActiveProjectLocationName', 'LinkedDocumentActiveProjectLocationName'
    )),
    levels: normalizeOptions(read(item, 'levels', 'Levels')),
    sites: normalizeOptions(read(item, 'existingSites', 'projectLocations', 'sites', 'ExistingSites', 'ProjectLocations', 'Sites')),
    grids: Array.isArray(read(item, 'grids', 'Grids')) ? read(item, 'grids', 'Grids') : []
  }));
}

function isSupportedLink(item) {
  return !!item?.loaded && !item?.nested && item?.scenarioStatusKnown === true && item?.scenarioBased !== true;
}

function normalizeOptions(raw) {
  const items = Array.isArray(raw) ? raw : [];
  return items.map((item, index) => {
    if (typeof item === 'string' || typeof item === 'number') {
      return { id: item, label: String(item), preferred: index === 0 };
    }
    return {
      id: read(item, 'id', 'elementId', 'uniqueId', 'name', 'Id', 'ElementId', 'UniqueId', 'Name') ?? index,
      label: text(read(item, 'label', 'name', 'title', 'Label', 'Name', 'Title')) || `항목 ${index + 1}`,
      preferred: read(item, 'preferred', 'isActive', 'isDefault', 'Preferred', 'IsActive', 'IsDefault') === true,
      active: read(item, 'isActive', 'IsActive') === true,
      currentSharedSite: read(item, 'isCurrentSharedSite', 'IsCurrentSharedSite') === true
    };
  });
}

function normalizeAnalysis(raw) {
  const warningsRaw = read(raw, 'warnings', 'Warnings');
  const anchor = read(raw, 'anchor', 'Anchor') || {};
  const current = normalizeCoordinate(read(raw, 'current', 'Current'));
  const target = normalizeCoordinate(read(raw, 'target', 'Target'));
  const deltaRaw = read(raw, 'delta', 'Delta');
  const delta = deltaRaw ? normalizeCoordinate(deltaRaw) : {
    east: target.east - current.east,
    north: target.north - current.north,
    elevation: target.elevation - current.elevation,
    bearingDegrees: target.bearingDegrees - current.bearingDegrees
  };
  if (deltaRaw) {
    delta.bearingDegrees = numberOrNull(read(
      deltaRaw,
      'bearingDegreesClockwise', 'BearingDegreesClockwise',
      'bearingDegrees', 'bearing', 'angleDegrees', 'BearingDegrees', 'Bearing', 'AngleDegrees'
    )) ?? delta.bearingDegrees;
  }
  const anchorSummary = text(read(raw, 'anchorSummary', 'AnchorSummary')) ||
    text(read(anchor, 'summary', 'Summary'));
  return {
    analysisToken: text(read(raw, 'analysisToken', 'token', 'AnalysisToken', 'Token')),
    current,
    target,
    delta,
    anchorSummary,
    originalPlacementMethod: text(read(raw, 'originalPlacementMethod', 'OriginalPlacementMethod')),
    currentPlacementMethod: text(read(raw, 'currentPlacementMethod', 'CurrentPlacementMethod')),
    currentPlacementMethodCode: text(read(raw, 'currentPlacementMethodCode', 'CurrentPlacementMethodCode')),
    currentPlacementDetails: text(read(raw, 'currentPlacementDetails', 'CurrentPlacementDetails')),
    instanceSharedSiteName: text(read(raw, 'instanceSharedSiteName', 'InstanceSharedSiteName')),
    instanceSharedSiteStatus: text(read(raw, 'instanceSharedSiteStatus', 'InstanceSharedSiteStatus')),
    linkedDocumentActiveProjectLocationName: text(read(
      raw,
      'linkedDocumentActiveProjectLocationName', 'LinkedDocumentActiveProjectLocationName'
    )),
    targetProjectLocationName: text(read(raw, 'targetProjectLocationName', 'TargetProjectLocationName')),
    warnings: (Array.isArray(warningsRaw) ? warningsRaw : warningsRaw ? [warningsRaw] : []).map(text).filter(Boolean),
    canApply: read(raw, 'canApply', 'CanApply') !== false,
    canPublish: read(raw, 'canPublish', 'CanPublish') !== false,
    message: text(read(raw, 'message', 'Message')),
    applied: false,
    published: false
  };
}

function normalizeCoordinate(raw) {
  const value = raw || {};
  return {
    east: numberOrNull(read(value, 'east', 'e', 'x', 'East', 'E', 'X')) ?? 0,
    north: numberOrNull(read(value, 'north', 'n', 'y', 'North', 'N', 'Y')) ?? 0,
    elevation: numberOrNull(read(value, 'elevation', 'z', 'Elevation', 'Z')) ?? 0,
    bearingDegrees: numberOrNull(read(value, 'bearingDegrees', 'bearing', 'angleDegrees', 'BearingDegrees', 'Bearing', 'AngleDegrees')) ?? 0
  };
}

function read(source, ...keys) {
  if (!source || typeof source !== 'object') return undefined;
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(source, key) && source[key] != null) return source[key];
  }
  return undefined;
}

function text(value) {
  return value == null ? '' : String(value).trim();
}

function samePathList(left, right) {
  const normalize = (items) => (Array.isArray(items) ? items : [])
    .map((item) => String(item || '').trim().toLowerCase())
    .filter(Boolean)
    .sort();
  const a = normalize(left);
  const b = normalize(right);
  return a.length === b.length && a.every((value, index) => value === b[index]);
}

function numberOrNull(value) {
  if (value == null || String(value).trim() === '') return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function idValue(value) {
  const normalized = text(value);
  if (/^-?\d+$/.test(normalized)) return Number(normalized);
  return normalized;
}

function formatNumber(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return '-';
  return number.toLocaleString('ko-KR', { maximumFractionDigits: 4 });
}
