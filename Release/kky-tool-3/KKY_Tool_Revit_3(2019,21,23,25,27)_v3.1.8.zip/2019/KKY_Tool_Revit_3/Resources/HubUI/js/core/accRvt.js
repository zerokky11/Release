// Cloud addresses identify live Revit models; they are never filesystem paths.
const LOCATION_KEY = 'kky.hub.accRvtLocations.v1';
function readLocations() {
  try { return JSON.parse(localStorage.getItem(LOCATION_KEY) || '{}') || {}; } catch { return {}; }
}
export function rememberAccRvtLocations(locations) {
  if (!locations || typeof locations !== 'object') return;
  const stored = readLocations();
  Object.entries(locations).forEach(([source, label]) => {
    if (isAccRvt(source) && typeof label === 'string' && label.length <= 4096) stored[accRvtIdentity(source)] = label;
  });
  try { localStorage.setItem(LOCATION_KEY, JSON.stringify(stored)); } catch { /* Registration still works without display metadata. */ }
}
export function isAccRvt(path) { return /^acc:/i.test(String(path || '').trim()); }
export function accRvtIdentity(path) {
  const value = String(path || '').trim();
  if (!isAccRvt(value)) return value.toLowerCase();
  return value.slice(0, value.lastIndexOf('/')).toLowerCase();
}
export function accRvtName(path) {
  try { return decodeURIComponent(String(path).split('/').pop()); }
  catch { return 'ACC 모델'; }
}
export function accRvtBelongsTo(path, ownerKey) {
  if (!isAccRvt(path)) return true;
  return !!ownerKey && String(path).split('/')[6] === ownerKey;
}
export function accRvtLabel(path) {
  if (!isAccRvt(path)) return String(path || '');
  const location = readLocations()[accRvtIdentity(path)];
  if (location) return `ACC · ${location}`;
  const parts = String(path).split('/');
  return `ACC · Revit ${parts[3] || ''} · ${accRvtName(path)}`;
}
