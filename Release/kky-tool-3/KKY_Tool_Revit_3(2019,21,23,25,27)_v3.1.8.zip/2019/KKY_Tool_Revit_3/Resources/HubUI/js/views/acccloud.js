﻿import { addRvtTargets3, removeOtherAccUsers3 } from '../core/workflowState3.js?v=20260731sharedsettings3';
import { rememberAccRvtLocations } from '../core/accRvt.js';
import { clear, div, toast, showExcelSavedDialog, showCompletionSummaryDialog } from '../core/dom.js?v=20260731parameterexport1';
import { ProgressDialog } from '../core/progress.js?v=20260701a';
import { onHost, post } from '../core/bridge.js';
import { attachRvtDropZone } from '../core/rvtDrop.js';
import { attachExcelDropZone } from '../core/excelDrop.js';
import { createFeatureGuideButton } from '../core/featureGuide.js?v=20260916linkbatch1';

const CLOUD_MODE = 'cloud-workshared';
const DEFAULT_REGION = 'US';
const APPLY = 'APPLY';
const SKIP = 'SKIP';
const TERMINAL_WARNING_STATUSES = new Set([
  'AMBIGUOUS_CREATE',
  'PARTIAL_REMOTE_CREATED',
  'MANUAL_CLEANUP_REQUIRED'
]);
const AUTODESK_HOST_PATTERN = /(^|\.)(acc|docs|bim360)\.autodesk\.com$/i;

let activeCleanup = null;

export function renderAccCloud(root) {
  activeCleanup?.();
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);

  const state = {
    rows: [],
    bulk: { prefix: '', suffix: '', find: '', replace: '', worksets: '' },
    selectedRowId: '',
    workbookPath: '',
    resultWorkbookPath: '',
    trustedResultCount: 0,
    blockedTargetKeys: new Set(),
    revitMajor: 0,
    supportedMajor: false,
    supportState: 'UNKNOWN',
    supportMessage: 'Revit 버전과 ACC 클라우드 생성 지원 상태를 확인하는 중입니다.',
    revitLoginUsername: '',
    busy: false,
    operation: '',
    disposed: false,
    cancelling: false,
    progressOwner: null,
    progressPercent: 0,
    lastResult: null,
    resultDialog: null,
    targetPickerRequest: null,
    lastContextSignature: '',
    receivedContext: false,
    cleanup: [],
    workspaceCleanup: [],
    runCleanup: [],
    ui: {}
  };

  const page = div('feature-shell acccloud-page');
  const header = div('feature-header acccloud-feature-header');
  header.innerHTML = `
    <div class="feature-heading">
      <span class="feature-kicker">ACC / Autodesk Docs · TEST</span>
      <h2 class="feature-title">ACC 클라우드 모델 생성 (TEST)</h2>
      <p class="feature-sub">여러 RVT의 저장 폴더와 모델 이름을 설정하고 ACC 작업공유 모델을 생성합니다. 생성 후 다시 열어 확인한 모델을 RVT 목록에 추가할 수 있습니다.</p>
    </div>`;
  const headerActions = div('feature-actions');
  const guideButton = createFeatureGuideButton('acccloud', { featureLabel: 'ACC 클라우드 모델 생성' });
  if (guideButton) {
    headerActions.append(guideButton);
    header.append(headerActions);
  }
  const workspace = div('acccloud-workspace');
  const runPanel = div('acccloud-run-panel');
  page.append(header, workspace, runPanel);
  target.append(page);
  state.ui.workspace = workspace;
  state.ui.runPanel = runPanel;

  registerHostEvents(state);
  render(state);
  post('acccloud:init', {});

  const cleanup = () => {
    state.disposed = true;
    finishRequest(state);
    state.resultDialog?.close();
    [...state.workspaceCleanup.splice(0), ...state.runCleanup.splice(0)].forEach((dispose) => {
      try { dispose?.(); } catch { }
    });
    state.cleanup.splice(0).forEach((dispose) => {
      try { dispose?.(); } catch { }
    });
    if (activeCleanup === cleanup) activeCleanup = null;
  };
  activeCleanup = cleanup;
  return cleanup;
}

function registerHostEvents(state) {
  const listen = (name, handler) => state.cleanup.push(onHost(name, (payload) => {
    if (!state.disposed && state.ui.workspace?.isConnected) handler(payload || {});
  }));

  listen('acccloud:context', (payload) => {
    const signature = JSON.stringify(payload);
    if (signature === state.lastContextSignature || state.targetPickerRequest) return;
    state.lastContextSignature = signature;
    state.busy = toBoolean(pick(payload, 'busy', 'Busy'));
    if (state.busy && !state.operation) state.operation = 'run';
    if (!state.busy) finishRequest(state);
    state.revitMajor = toInteger(pick(payload, 'revitMajor', 'RevitMajor'));
    state.supportedMajor = toBoolean(pick(payload, 'supportedMajor', 'SupportedMajor'));
    state.supportState = String(pick(payload, 'supportState', 'SupportState') || 'UNKNOWN').trim().toUpperCase();
    state.supportMessage = String(pick(payload, 'supportMessage', 'SupportMessage') || '').trim();
    state.revitLoginUsername = String(pick(payload, 'revitLoginUsername', 'RevitLoginUsername') || '').trim();
    state.workbookPath = String(pick(payload, 'workbookPath', 'WorkbookPath') || state.workbookPath || '').trim();
    state.resultWorkbookPath = String(pick(payload, 'resultWorkbookPath', 'ResultWorkbookPath') || state.resultWorkbookPath || '').trim();
    state.trustedResultCount = Math.max(0, toInteger(pick(payload, 'trustedResultCount', 'TrustedResultCount')));
    state.blockedTargetKeys = new Set(arrayOf(pick(payload, 'blockedTargetKeys', 'BlockedTargetKeys')).map(String).filter(Boolean));
    const incoming = arrayOf(pick(payload, 'rows', 'Rows'));
    if (!state.receivedContext) {
      state.receivedContext = true;
      if (incoming.length) replaceRows(state, incoming);
      render(state);
    } else {
      // Context refreshes report Host availability; they do not own the mounted draft.
      // Explicit import/completion events apply row changes without losing local edits.
      const support = state.ui.workspace.querySelector('.acccloud-support');
      support?.classList.toggle('is-supported', state.supportedMajor);
      support?.classList.toggle('is-blocked', !state.supportedMajor);
      if (support) {
        support.querySelector('strong').textContent = `Revit ${state.revitMajor}`;
        support.querySelector('span').textContent = state.supportMessage;
        support.querySelector('.acccloud-login strong').textContent = state.revitLoginUsername || '확인되지 않음';
      }
      const restore = captureUiState(state);
      renderRunPanel(state);
      restore();
      syncProgress(state);
    }
  });

  listen('acccloud:rvts-picked', (payload) => {
    const rows = arrayOf(pick(payload, 'rows', 'Rows'));
    const paths = arrayOf(pick(payload, 'paths', 'Paths')).map(String).filter(Boolean);
    if (rows.length) appendRows(state, rows);
    else if (paths.length) appendRows(state, paths.map((sourcePath) => newRow(sourcePath)));
    state.busy = false;
    render(state);
  });

  listen('acccloud:target-picked', (payload) => {
    const request = state.targetPickerRequest;
    if (!request || String(pick(payload, 'pickerRequestId', 'PickerRequestId')) !== request.id ||
        String(pick(payload, 'rowId', 'RowId')) !== request.rowId) return;
    state.targetPickerRequest = null;
    state.busy = false;
    request.restoreControls();
    if (toBoolean(pick(payload, 'cancelled', 'Cancelled'))) return;
    if (pick(payload, 'ok', 'Ok') !== true) {
      toast(String(pick(payload, 'message', 'Message') || 'ACC 대상 폴더를 선택하지 못했습니다.'), 'err');
      return;
    }
    const targetRows = state.rows.filter((item) => (request.rowIds || [request.rowId]).includes(item.rowId));
    if (!targetRows.length) return;
    const target = pick(payload, 'target', 'Target') || {};
    const accountGuid = normalizeGuid(pick(target, 'accountGuid', 'AccountGuid'));
    const projectGuid = normalizeGuid(pick(target, 'projectGuid', 'ProjectGuid'));
    const folderId = String(pick(target, 'folderId', 'FolderId') || '').trim();
    const region = String(pick(target, 'region', 'Region') || '').trim().toUpperCase();
    const modelName = String(pick(target, 'modelName', 'ModelName') || '').trim();
    if (!accountGuid || !projectGuid || !folderId.startsWith('urn:') || !['US', 'EMEA'].includes(region)) {
      toast('조회된 대상 정보가 불완전합니다. 폴더를 다시 선택하세요.', 'err');
      return;
    }
    if (modelName && (modelName.length <= 4 || !/\.rvt$/i.test(modelName) || /[\\/:*?"<>|\x00-\x1f]/.test(modelName))) {
      toast('조회된 모델 이름이 올바르지 않습니다. 경로를 다시 확인하세요.', 'err');
      return;
    }
    for (const row of targetRows) {
      Object.assign(row, { accountGuid, projectGuid, folderId, region,
        targetDisplayPath: String(pick(target, 'displayPath', 'DisplayPath') || '') });
      // A filename in a relative path only applies to a single selected source.
      if (modelName && targetRows.length === 1) row.modelName = modelName;
      clearRowTrustedResult(row);
    }
    render(state);
    toast(`${targetRows.length}개 파일에 ACC 저장 폴더를 적용했습니다.`, 'ok');
  });

  listen('acccloud:rows', (payload) => {
    replaceRows(state, arrayOf(pick(payload, 'rows', 'Rows')));
    state.workbookPath = String(pick(payload, 'workbookPath', 'WorkbookPath') || state.workbookPath || '').trim();
    state.busy = false;
    render(state);
    toast(`${state.rows.length}개 ACC 작업 행을 불러왔습니다.`, 'ok');
  });

  listen('acccloud:template-exported', (payload) => {
    state.busy = false;
    const ok = pick(payload, 'ok', 'Ok') !== false;
    const path = String(pick(payload, 'path', 'Path') || '').trim();
    if (ok && path && !toBoolean(pick(payload, 'cancelled', 'Cancelled'))) {
      state.workbookPath = path;
      requestAnimationFrame(() => {
        if (state.ui.workspace?.isConnected) showExcelSavedDialog('ACC 요청 전용 Excel 양식을 저장했습니다.', path, (savedPath) => post('excel:open', { path: savedPath }));
      });
    } else if (!toBoolean(pick(payload, 'cancelled', 'Cancelled'))) {
      toast(String(pick(payload, 'message', 'Message') || 'ACC Excel 양식 저장에 실패했습니다.'), 'err');
    }
    render(state);
  });

  listen('acccloud:results-exported', (payload) => {
    finishRequest(state);
    const ok = pick(payload, 'ok', 'Ok') !== false;
    const path = String(pick(payload, 'path', 'Path') || '').trim();
    if (ok && path && !toBoolean(pick(payload, 'cancelled', 'Cancelled'))) {
      state.resultWorkbookPath = path;
      const count = Math.max(0, toInteger(pick(payload, 'resultCount', 'ResultCount')));
      const omitted = Math.max(0, toInteger(pick(payload, 'omittedCount', 'OmittedCount')));
      requestAnimationFrame(() => {
        if (state.ui.workspace?.isConnected) showExcelSavedDialog(`ACC 결과 ${count}개를 저장했습니다.${omitted ? ` 현재 요청과 불일치한 ${omitted}개 행은 제외했습니다.` : ''}`, path, (savedPath) => post('excel:open', { path: savedPath }));
      });
    } else if (!toBoolean(pick(payload, 'cancelled', 'Cancelled'))) {
      toast(String(pick(payload, 'message', 'Message') || 'ACC 신뢰 결과 저장에 실패했습니다.'), 'err', 7200);
    }
    render(state);
    showResult(state);
  });

  listen('acccloud:workbook-picked', (payload) => {
    const path = String(pick(payload, 'path', 'Path') || '').trim();
    state.busy = false;
    if (!path) {
      render(state);
      return;
    }
    importWorkbook(state, path);
  });

  listen('acccloud:progress', (payload) => {
    if (!state.busy || !['run', 'preflight'].includes(state.operation)) return;
    const percent = Math.max(0, Math.min(100, toInteger(pick(payload, 'percent', 'Percent'))));
    const message = String(pick(payload, 'message', 'Message') || 'ACC 클라우드 모델을 처리하는 중입니다.');
    state.progressPercent = Math.max(state.progressPercent, percent);
    state.ui.progressMessage = message;
    syncProgress(state);
  });

  listen('acccloud:completed', (payload) => {
    const rows = arrayOf(pick(payload, 'rows', 'Rows'));
    if (rows.length) applyCompletedRows(state, rows);
    state.trustedResultCount = Math.max(state.trustedResultCount, toInteger(pick(payload, 'trustedResultCount', 'TrustedResultCount')));
    arrayOf(pick(payload, 'blockedTargetKeys', 'BlockedTargetKeys')).map(String).filter(Boolean).forEach((key) => state.blockedTargetKeys.add(key));
    state.lastResult = rows.map(normalizeRow);
    finishRequest(state);
    render(state);
    showResult(state);
  });

  listen('acccloud:preflighted', (payload) => {
    applyCompletedRows(state, arrayOf(pick(payload, 'rows', 'Rows')));
    finishRequest(state);
    render(state);
    toast(String(payload.message || '사전 검사를 완료했습니다.'), payload.ok ? 'ok' : 'warn', 7000);
  });

  listen('acccloud:created-models', (payload) => {
    const paths = arrayOf(payload.paths).filter((path) => typeof path === 'string' && path.startsWith('acc://'));
    finishRequest(state);
    if (!paths.length || !/^[a-f0-9]{64}$/.test(String(payload.ownerKey || ''))) {
      render(state);
      toast('검증된 생성 모델 정보를 받지 못했습니다. 결과를 확인한 뒤 다시 시도하세요.', 'err');
      return;
    }
    removeOtherAccUsers3(payload.ownerKey);
    rememberAccRvtLocations(payload.locations || {});
    addRvtTargets3(paths);
    render(state);
    toast(`생성 모델 ${paths.length}개를 공통 RVT 목록에 추가했습니다. 여러 RVT 기능에서 사용할 수 있습니다.`, 'ok', 7000);
  });

  const handleError = (payload) => {
    if (payload.busy === true) {
      toast(String(payload.detail || payload.message || '현재 작업이 진행 중입니다.'), 'warn');
      return;
    }
    const exporting = state.operation === 'export-results';
    state.targetPickerRequest?.restoreControls();
    state.targetPickerRequest = null;
    finishRequest(state);
    render(state);
    const message = String(pick(payload, 'message', 'Message') || 'ACC 클라우드 모델 처리 중 오류가 발생했습니다.');
    const detail = String(pick(payload, 'detail', 'Detail') || '').trim();
    toast(detail ? `${message} · ${detail}` : message, 'err', 7200);
    if (exporting) showResult(state);
  };
  listen('acccloud:error', handleError);
  listen('host:error', (payload) => {
    if (payload.sourceEvent === 'acccloud:cancel' && state.busy && state.operation === 'run') {
      state.cancelling = false;
      syncProgress(state);
      toast('중지 요청을 전달하지 못했습니다. 작업은 계속 진행 중입니다. 다시 중지를 요청할 수 있습니다.', 'err');
      return;
    }
    if (String(payload.sourceEvent || '').startsWith('acccloud:')) handleError(payload);
  });
}

function finishRequest(state) {
  state.busy = false;
  state.operation = '';
  state.cancelling = false;
  state.ui.progressMessage = '';
  if (state.progressOwner !== null) ProgressDialog.hide(state.progressOwner);
  state.progressOwner = null;
}

function syncProgress(state) {
  if (!state.busy || !['run', 'preflight'].includes(state.operation) || state.disposed) return;
  const message = state.ui.progressMessage || 'ACC 모델 생성을 준비하고 있습니다.';
  if (state.progressOwner === null) state.progressOwner = ProgressDialog.show('ACC 클라우드 모델 생성', message);
  if (!ProgressDialog.isOwner(state.progressOwner)) return;
  ProgressDialog.setActions({ onCancel: state.operation === 'run' ? () => cancelRun(state) : null, cancelLabel: '중지 요청' }, state.progressOwner);
  ProgressDialog.setActionState({ cancelDisabled: state.cancelling, statusText: state.cancelling ? '현재 모델 처리 후 남은 작업을 중단합니다.' : '' }, state.progressOwner);
  ProgressDialog.update(state.progressPercent, message, '', state.progressOwner);
}

function cancelRun(state) {
  if (!state.busy || state.operation !== 'run' || state.cancelling) return;
  state.cancelling = true;
  if (post('acccloud:cancel', {}) === false) state.cancelling = false;
  syncProgress(state);
}

function request(state, event, payload = {}) {
  if (state.busy || state.disposed) return;
  state.busy = true;
  state.operation = event;
  state.cancelling = false;
  state.progressPercent = 0;
  render(state);
  if (post(`acccloud:${event}`, payload) === false) {
    finishRequest(state);
    render(state);
    if (event === 'export-results') showResult(state);
  }
}

function showResult(state) {
  const rows = state.lastResult;
  if (!rows || state.busy || state.disposed) return;
  const verified = rows.filter((row) => row.status === 'VERIFIED' && row.verifiedFreshOpen).length;
  const warnings = rows.filter((row) => TERMINAL_WARNING_STATUSES.has(row.status) || row.manualCleanupRequired);
  const failed = rows.filter((row) => row.status === 'FAILED' && !warnings.includes(row)).length;
  const skipped = rows.filter((row) => ['SKIPPED', 'CANCELLED'].includes(row.status)).length;
  const issues = rows.filter((row) => row.status !== 'VERIFIED' && row.message);
  const notes = [];
  if (warnings.length) notes.push('원격 모델이 이미 생성되었거나 생성 여부가 불확실합니다. 바로 재실행하지 말고 ACC 저장 폴더와 결과의 모델 GUID를 확인하세요.');
  issues.slice(0, 3).forEach((row) => {
    const detail = `${row.modelName || row.sourcePath}: ${row.message}`;
    notes.push(detail.length > 200 ? `${detail.slice(0, 197)}…` : detail);
  });
  if (issues.length > 3) notes.push(`그 외 ${issues.length - 3}건의 상세 사유는 결과 Excel에서 확인할 수 있습니다.`);
  state.resultDialog = showCompletionSummaryDialog({
    title: 'ACC 클라우드 모델 생성 결과',
    message: verified === rows.length && verified > 0 ? `${verified}개 모델을 생성하고 다시 열어 검증했습니다.` :
      `검증 완료 ${verified}개 · 실패 ${failed}개 · 확인 필요 ${warnings.length}개 · 미실행 ${skipped}개`,
    summaryItems: [{ label: '전체', value: `${rows.length}개` }, { label: '검증 완료', value: `${verified}개` },
      { label: '실패', value: `${failed}개` }, { label: '확인 필요', value: `${warnings.length}개` }, { label: '미실행', value: `${skipped}개` }],
    notes, confirmLabel: '닫기', showExport: rows.length > 0,
    exportLabel: '결과 Excel 내보내기 (.xlsx)',
    onExport: () => request(state, 'export-results', { rows: serializeRequestRows(rows, { allowIncomplete: true }) }),
    onClose: () => { state.resultDialog = null; }
  });
}

function render(state) {
  const restore = captureUiState(state);
  ensureSelected(state);
  renderWorkspace(state);
  renderRunPanel(state);
  restore();
  syncProgress(state);
}

function captureUiState(state) {
  const roots = [state.ui.workspace, state.ui.runPanel];
  const scrolling = [...new Set([document.scrollingElement, ...document.querySelectorAll('*')])]
    .filter((node) => node && (node.scrollTop || node.scrollLeft))
    .map((node) => ({ node, selector: roots.some((root) => root?.contains(node)) ?
      (node.classList.contains('acccloud-row-list') ? '.acccloud-row-list' : node.classList.contains('acccloud-bulk-preview') ? '.acccloud-bulk-preview' : null) : null,
      top: node.scrollTop, left: node.scrollLeft }));
  const details = [...state.ui.workspace.querySelectorAll('[data-acc-details-key]')].map((node) => [node.dataset.accDetailsKey, node.open]);
  const active = document.activeElement;
  const field = active?.dataset.field;
  const focusRow = active?.closest('[data-row-id]')?.dataset.rowId;
  const selection = typeof active?.selectionStart === 'number' ? [active.selectionStart, active.selectionEnd] : null;
  return () => {
    for (const [key, open] of details) [...state.ui.workspace.querySelectorAll('[data-acc-details-key]')].find((node) => node.dataset.accDetailsKey === key)?.toggleAttribute('open', open);
    const next = field ? [...state.ui.workspace.querySelectorAll('[data-field]')].find((node) => node.dataset.field === field) :
      focusRow ? [...state.ui.workspace.querySelectorAll('[data-row-id]')].find((node) => node.dataset.rowId === focusRow)?.querySelector('[data-batch-check]') : null;
    if (next && !next.disabled) { next.focus({ preventScroll: true }); if (selection) { try { next.setSelectionRange(...selection); } catch {} } }
    for (const entry of scrolling) { const node = entry.node.isConnected ? entry.node : entry.selector ? document.querySelector(entry.selector) : null; if (node) { node.scrollTop = entry.top; node.scrollLeft = entry.left; } }
  };
}

function renderWorkspace(state) {
  const host = state.ui.workspace;
  if (!host) return;
  state.workspaceCleanup.splice(0).forEach((dispose) => {
    try { dispose?.(); } catch { }
  });
  clear(host);

  const version = div(`acccloud-support ${state.supportedMajor ? 'is-supported' : 'is-blocked'}`);
  version.innerHTML = `
    <div>
      <strong>${state.revitMajor ? `Revit ${state.revitMajor}` : 'Revit 확인 중'}</strong>
      <span>${escapeHtml(state.supportMessage || '')}</span>
    </div>
    <div class="acccloud-login"><span>Revit 로그인</span><strong>${escapeHtml(state.revitLoginUsername || '확인되지 않음')}</strong></div>`;

  const toolbar = div('acccloud-toolbar');
  toolbar.append(
    button('RVT 파일 추가', () => requestPickRvts(state), 'primary', state.busy),
    button('선택 행 복사', () => copySelectedRow(state), 'secondary', state.busy || !selectedRow(state)),
    button('선택 행 제거', () => removeSelectedRow(state), 'ghost', state.busy || !selectedRow(state)),
    button('요청 양식 저장', () => exportTemplate(state), 'secondary', state.busy || !state.rows.length),
    button('결과 Excel 저장', () => exportResults(state), 'secondary', state.busy || !state.rows.length || !state.trustedResultCount),
    button('ACC Excel 불러오기', () => requestWorkbook(state), 'secondary', state.busy)
  );

  const contract = div('acccloud-contract-note');
  contract.innerHTML = `
    <strong>생성 순서</strong>
    <span>RVT 등록 → 저장 폴더·이름 일괄 설정 → 사전 검사 → 생성 및 재열기 검증. 먼저 테스트 프로젝트에서 결과를 확인하세요.</span>`;

  const batch = div('acccloud-batch');
  const navigator = buildNavigator(state);
  const detail = buildDetail(state);
  batch.append(navigator, detail);
  host.append(version, toolbar, contract, buildBulkSettings(state), batch);

  state.workspaceCleanup.push(attachRvtDropZone(navigator, {
    onDropPaths: (paths) => appendRows(state, paths.map((path) => newRow(path))),
    onInvalid: (payload) => toast(String(payload?.message || '.rvt 파일만 놓을 수 있습니다.'), 'warn')
  }));
}

function buildBulkSettings(state) {
  const card = div('acccloud-bulk');
  card.innerHTML = `<div class="acccloud-card-title"><strong>선택한 파일 일괄 설정</strong><span data-bulk-count>${state.rows.filter((row) => row.batchChecked).length}개 선택</span></div>`;
  const actions = div('acccloud-toolbar');
  actions.append(
    button('전체 선택', () => { state.rows.forEach((row) => { row.batchChecked = true; }); render(state); }, 'ghost', state.busy),
    button('선택 해제', () => { state.rows.forEach((row) => { row.batchChecked = false; }); render(state); }, 'ghost', state.busy),
    button('선택 파일의 ACC 폴더 지정', () => {
      const rows = state.rows.filter((row) => row.batchChecked);
      if (!rows.length) return toast('일괄 설정할 파일을 체크하세요.', 'warn');
      requestTargetPicker(state, rows[0], rows.map((row) => row.rowId));
    }, 'primary', state.busy || !state.rows.length)
  );
  card.append(actions);
  const fields = div('acccloud-bulk-fields');
  for (const [name, label] of [['prefix', '접두어'], ['suffix', '접미어'], ['find', '바꿀 문자'], ['replace', '새 문자']]) {
    const field = textField(label, `bulk-${name}`, state.bulk[name], '');
    const input = field.querySelector('input');
    input.disabled = state.busy;
    input.addEventListener('input', () => { state.bulk[name] = input.value; updateBulkPreview(state); });
    fields.append(field);
  }
  card.append(fields);
  const preview = div('acccloud-bulk-preview');
  preview.dataset.bulkPreview = '';
  card.append(preview);
  const names = button('미리 본 이름 적용', () => {
    for (const row of state.rows.filter((item) => item.batchChecked)) {
      row.modelName = proposedName(row, state.bulk); clearRowTrustedResult(row);
    }
    render(state);
  }, 'secondary', state.busy || !state.rows.length);
  names.dataset.bulkNamesApply = '';
  card.append(names);
  const workset = textField('공통 웍셋 · 쉼표로 구분', 'bulk-worksets', state.bulk.worksets, '설비, 구조');
  const input = workset.querySelector('input');
  input.disabled = state.busy;
  input.addEventListener('input', () => { state.bulk.worksets = input.value; });
  card.append(workset, button('선택 파일에 웍셋 추가', () => {
    const values = normalizeNames(state.bulk.worksets.split(/[,;\n]/));
    for (const row of state.rows.filter((item) => item.batchChecked)) {
      row.addWorksets = normalizeNames([...row.addWorksets, ...values]); clearRowTrustedResult(row);
    }
    render(state);
  }, 'secondary', state.busy || !state.rows.length));
  preview.textContent = bulkPreviewText(state);
  return card;
}

function proposedName(row, rules) {
  let name = fileName(row.sourcePath).replace(/\.rvt$/i, '');
  if (rules.find) name = name.split(rules.find).join(rules.replace);
  return `${rules.prefix}${name}${rules.suffix}.rvt`;
}
function bulkPreviewText(state) {
  const rows = state.rows.filter((row) => row.batchChecked);
  return rows.length ? rows.map((row) => `${fileName(row.sourcePath)} → ${proposedName(row, state.bulk)} · ${row.targetDisplayPath || '저장 폴더 미지정'}`).join('\n') : '일괄 설정할 파일을 체크하세요.';
}
function updateBulkPreview(state) {
  const preview = state.ui.workspace.querySelector('[data-bulk-preview]');
  if (preview) preview.textContent = bulkPreviewText(state);
}

function buildNavigator(state) {
  const nav = div('acccloud-navigator');
  const heading = div('acccloud-panel-title');
  heading.innerHTML = `<strong>작업 행</strong><span>${state.rows.length}개</span>`;
  nav.append(heading);

  if (!state.rows.length) {
    const empty = div('acccloud-empty');
    empty.innerHTML = '<strong>RVT를 추가해 시작</strong><span>같은 파일을 여러 ACC 대상으로 만들 때는 행을 복사하세요.</span><small>여기에 .rvt 파일을 놓을 수도 있습니다.</small>';
    nav.append(empty);
    return nav;
  }

  const list = div('acccloud-row-list');
  state.rows.forEach((row, index) => {
    const item = document.createElement('div');
    item.tabIndex = 0;
    item.setAttribute('role', 'group');
    item.className = `acccloud-row${row.rowId === state.selectedRowId ? ' is-selected' : ''}`;
    item.dataset.rowId = row.rowId;
    const status = normalizeStatus(row.status);
    const warn = TERMINAL_WARNING_STATUSES.has(status) || row.manualCleanupRequired;
    item.innerHTML = `
      <input type="checkbox" data-batch-check aria-label="${index + 1}번 파일 일괄 설정 선택" ${row.batchChecked ? 'checked' : ''} ${state.busy ? 'disabled' : ''} />
      <span class="acccloud-row-copy"><strong>${escapeHtml(fileName(row.sourcePath) || 'RVT')}</strong><small>${escapeHtml(row.modelName || '모델 이름 미입력')}</small></span>
      <span class="acccloud-status ${warn ? 'is-warn' : status === 'VERIFIED' ? 'is-ok' : ''}">${escapeHtml(status || 'PENDING')}</span>`;
    item.querySelector('[data-batch-check]').addEventListener('click', (event) => event.stopPropagation());
    item.querySelector('[data-batch-check]').addEventListener('change', (event) => {
      row.batchChecked = event.target.checked;
      updateBulkPreview(state);
      state.ui.workspace.querySelector('[data-bulk-count]').textContent = `${state.rows.filter((item) => item.batchChecked).length}개 선택`;
    });
    item.addEventListener('keydown', (event) => {
      if (event.target === item && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); item.click(); }
    });
    item.addEventListener('click', () => {
      state.selectedRowId = row.rowId;
      render(state);
    });
    list.append(item);
  });
  nav.append(list);
  return nav;
}

function buildDetail(state) {
  const host = div('acccloud-detail');
  const row = selectedRow(state);
  if (!row) {
    host.innerHTML = '<div class="acccloud-empty"><strong>작업 행을 선택하세요.</strong></div>';
    return host;
  }

  const heading = div('acccloud-panel-title');
  heading.innerHTML = `<strong>파일별 생성 설정</strong><span>${escapeHtml(fileName(row.sourcePath))}</span>`;
  host.append(heading);

  const targetPicker = div('acccloud-url-card');
  const targetButton = button('ACC 프로젝트·경로 선택', () => requestTargetPicker(state, row), 'primary', state.busy);
  targetPicker.append(targetButton);
  const targetSummary = document.createElement('p');
  targetSummary.dataset.accTargetSummary = '';
  targetSummary.textContent = row.targetDisplayPath || '현재 Revit 로그인 계정에서 생성할 프로젝트와 폴더를 선택하세요.';
  targetPicker.append(targetSummary);
  host.append(targetPicker);

  const form = div('acccloud-form');
  form.append(
    selectField('실행 여부', 'action', row.action, [APPLY, SKIP]),
    readonlyField('원본 RVT', row.sourcePath),
    textField('생성할 모델 이름', 'modelName', row.modelName, 'Project_Model.rvt'),
    readonlyField('생성 위치', row.targetDisplayPath || 'ACC 폴더를 선택하세요.', 'accTargetLocation')
  );
  const advanced = document.createElement('details');
  advanced.className = 'acccloud-advanced';
  advanced.dataset.accDetailsKey = `advanced-${row.rowId}`;
  advanced.innerHTML = '<summary>고급 설정 · ACC 식별자 직접 입력</summary>';
  const technical = div('acccloud-form');
  technical.append(
    textField('계정 GUID', 'accountGuid', row.accountGuid, ''),
    textField('프로젝트 GUID', 'projectGuid', row.projectGuid, ''),
    textField('폴더 ID', 'folderId', row.folderId, ''),
    selectField('서버 지역', 'region', row.region || DEFAULT_REGION, ['US', 'EMEA'])
  );
  advanced.append(technical);
  technical.querySelectorAll('[data-field]').forEach((input) => {
    input.disabled = state.busy;
    input.addEventListener('input', () => updateField(state, row, input.dataset.field, input.value, false));
    input.addEventListener('change', () => updateField(state, row, input.dataset.field, input.value));
  });
  form.querySelectorAll('[data-field]').forEach((input) => {
    input.disabled = state.busy;
    input.addEventListener('change', () => updateField(state, row, input.dataset.field, input.value));
    input.addEventListener('input', () => updateField(state, row, input.dataset.field, input.value, false));
  });
  host.append(form);

  const urlCard = div('acccloud-url-card');
  urlCard.innerHTML = `
    <div class="acccloud-card-title"><strong>Autodesk Docs URL에서 확정 가능한 값 읽기</strong><span>프로젝트 홈 URL과 대상 folder URL을 차례로 붙여 넣으세요. URL은 로컬 화면에서만 해석하며 저장·전송·로그하지 않습니다.</span></div>
    <div class="acccloud-url-row">
      <input type="password" autocomplete="off" spellcheck="false" placeholder="https://acc.autodesk.com/docs/files/projects/..." data-acc-url />
      <button type="button" class="btn btn-secondary" data-parse-url>식별자 읽기</button>
    </div>
    <small>Autodesk 공식 host와 명시 query/fragment 또는 /projects/{GUID}만 해석합니다. 화면이 확정하지 못한 AccountGuid/FolderId는 APS Data Management browser/API에서 확인해 입력해야 합니다.</small>`;
  const urlInput = urlCard.querySelector('[data-acc-url]');
  urlCard.querySelector('[data-parse-url]').addEventListener('click', () => {
    try {
      const parsed = parseAutodeskDocsUrl(urlInput.value);
      if (parsed.accountGuid) row.accountGuid = parsed.accountGuid;
      if (parsed.projectGuid) row.projectGuid = parsed.projectGuid;
      if (parsed.folderId) row.folderId = parsed.folderId;
      if (parsed.region) row.region = parsed.region;
      clearRowTrustedResult(row);
      urlInput.value = '';
      render(state);
      const missing = ['accountGuid', 'projectGuid', 'folderId'].filter((field) => !row[field]);
      if (missing.length) toast(`확정 가능한 값만 반영했습니다. 직접 입력 필요: ${missing.join(', ')}`, 'warn', 6200);
      else toast('URL에서 확정 가능한 ACC 식별자를 반영했습니다.', 'ok');
    } catch (error) {
      urlInput.value = '';
      toast(error?.message || 'Autodesk Docs URL을 해석할 수 없습니다.', 'err', 6200);
    }
  });
  advanced.append(urlCard);

  const idGuide = div('acccloud-id-guide');
  idGuide.innerHTML = `
    <strong>이 TEST 기능의 ID 입력 규칙</strong>
    <ul>
      <li><b>AccountGuid</b>와 <b>ProjectGuid</b>는 36자 GUID만 입력합니다. Data Management 값이 <code>b.&lt;GUID&gt;</code>이면 이 화면에서는 앞의 <code>b.</code>만 제거합니다.</li>
      <li><b>FolderId</b>는 대상 Docs folder의 원문 ID/URN 전체를 입력합니다. 예: <code>urn:adsk.wipprod:fs.folder:co.…</code>. GUID로 바꾸거나 앞부분을 지우면 안 됩니다.</li>
      <li><b>Region</b>은 대상 Docs project의 <code>US</code> 또는 <code>EMEA</code>만 선택합니다. source RVT의 위치가 아니라 대상 ACC project 기준입니다.</li>
      <li>이 규칙은 아래 <b>ACC 백업 (TEST)</b>의 Hub/Project ID 규칙과 다릅니다. 두 화면의 값을 서로 바꿔 붙여 넣지 마세요.</li>
    </ul>`;
  advanced.append(idGuide);
  host.append(advanced);

  const workset = div('acccloud-workset-card');
  workset.innerHTML = `
    <div class="acccloud-card-title"><strong>생성할 사용자 웍셋</strong><span>한 줄에 하나씩 입력</span></div>
    <textarea rows="6" data-add-worksets placeholder="Architecture&#10;Coordination">${escapeHtml((row.addWorksets || []).join('\n'))}</textarea>`;
  const textarea = workset.querySelector('[data-add-worksets]');
  textarea.disabled = state.busy;
  textarea.addEventListener('input', () => {
    row.addWorksets = normalizeNames(textarea.value.split(/\r?\n/));
    clearRowTrustedResult(row);
  });
  host.append(workset);

  const unsupported = div('acccloud-ownership-card');
  unsupported.innerHTML = `
    <div class="acccloud-card-title"><strong>소유권 및 Pin 옵션</strong><span class="acccloud-badge-blocked">ACC 1차 버전 미지원</span></div>
    <label><input type="checkbox" disabled /> 3D 뷰 ViewWorkset 소유/편집 유지</label>
    <label><input type="checkbox" disabled /> 3D 뷰 템플릿 ViewWorkset 소유/편집 유지</label>
    <label><input type="checkbox" disabled /> Shared Levels and Grids 소유/편집 및 Level/Grid Pin</label>
    <p>파일 센트럴의 CreateNewLocal 기반 검증 계약을 클라우드에 그대로 적용할 수 없어 1차 버전에서는 실행값을 항상 FALSE로 보냅니다. 지원하지 않는 값을 Excel에 TRUE로 입력해도 가져오기를 차단합니다.</p>`;
  advanced.append(unsupported);

  if (row.message || row.docsUrl || row.remoteCreated || row.manualCleanupRequired) {
    host.append(buildResultCard(row));
  }
  return host;
}

function buildResultCard(row) {
  const card = div(`acccloud-result-card${row.manualCleanupRequired || TERMINAL_WARNING_STATUSES.has(normalizeStatus(row.status)) ? ' is-warning' : ''}`);
  const link = safeHttpUrl(row.docsUrl);
  card.innerHTML = `
    <div class="acccloud-card-title"><strong>실행 결과 · ${escapeHtml(normalizeStatus(row.status))}</strong><span>${row.remoteCreated ? '원격 모델 생성됨' : '원격 생성 미확정'}</span></div>
    <p>${escapeHtml(row.message || '')}</p>
    ${row.cloudModelGuid ? `<dl><dt>CloudModelGuid</dt><dd>${escapeHtml(row.cloudModelGuid)}</dd></dl>` : ''}
    <dl><dt>RequestRegion / CloudRegion</dt><dd>${escapeHtml(row.region || DEFAULT_REGION)} / ${escapeHtml(row.cloudRegion || '확인되지 않음')}</dd></dl>
    ${row.persistenceState ? `<dl><dt>PersistenceState</dt><dd>${escapeHtml(row.persistenceState)}</dd></dl>` : ''}
    ${link ? `<a href="#" data-docs-url>Autodesk Docs에서 원격 모델 확인</a>` : ''}
    ${row.manualCleanupRequired ? '<strong class="acccloud-manual-cleanup">MANUAL CLEANUP REQUIRED · 재실행 전에 ACC에서 모델 존재 여부를 확인하세요.</strong>' : ''}`;
  if (link) {
    card.querySelector('[data-docs-url]').addEventListener('click', (event) => {
      event.preventDefault();
      post('ui:open-external', { url: link });
    });
  }
  return card;
}

function renderRunPanel(state) {
  const host = state.ui.runPanel;
  if (!host) return;
  state.runCleanup.splice(0).forEach((dispose) => {
    try { dispose?.(); } catch { }
  });
  clear(host);

  const validation = validateRows(state);
  const summary = div('acccloud-run-summary');
  const applyCount = state.rows.filter((row) => normalizeAction(row.action) === APPLY).length;
  summary.innerHTML = `
    <div><span>전체 행</span><strong>${state.rows.length}</strong></div>
    <div><span>실행 대상</span><strong>${applyCount}</strong></div>
    <div><span>지원 상태</span><strong>${state.supportedMajor ? '지원' : '차단'}</strong></div>`;
  host.append(summary);

  const notice = div(`acccloud-run-notice${validation.ok ? '' : ' is-error'}`);
  notice.textContent = validation.ok
    ? '생성 전 전체 행을 검사하고, 첫 실행 실패 후 배치를 중단합니다. 원격 덮어쓰기는 하지 않습니다.'
    : validation.message;
  host.append(notice);

  const run = button(state.busy ? 'ACC 생성 처리 중…' : 'ACC Cloud Workshared 생성 (TEST)', () => runJobs(state), 'primary', state.busy || !validation.ok);
  run.classList.add('acccloud-run-button');
  host.append(button('사전 검사', () => request(state, 'preflight', { rows: serializeRequestRows(state.rows) }), 'secondary', state.busy || !validation.ok), run);
  if (state.lastResult) host.append(button('최근 결과 보기', () => showResult(state), 'secondary', state.busy));
  host.append(button('생성 모델을 RVT 목록에 추가', () => {
    request(state, 'add-created', { rows: serializeRequestRows(state.rows, { allowIncomplete: true }) });
  }, 'secondary', state.busy || !state.rows.some((row) => row.status === 'VERIFIED' && row.verifiedFreshOpen)));


  const workbook = div('acccloud-workbook-state');
  workbook.innerHTML = `
    <span>작업 설정 Excel</span>
    <strong>${escapeHtml(state.workbookPath || '선택되지 않음')}</strong>
    <span>실행 결과 Excel</span>
    <strong>${escapeHtml(state.resultWorkbookPath || '아직 저장하지 않음')}</strong>`;
  host.append(workbook);

  const statuses = div('acccloud-status-guide');
  statuses.innerHTML = `
    <strong>원격 생성 주의 상태</strong>
    <span>생성 후 검증에 실패했거나 생성 여부가 불확실하면 자동 재시도하지 않습니다. ACC 저장 폴더와 결과에 표시된 모델 GUID로 생성 여부를 확인하세요.</span>`;
  host.append(statuses);

  state.runCleanup.push(attachExcelDropZone(workbook, {
    onDropPaths: (paths) => paths.length && importWorkbook(state, paths[0]),
    onInvalid: (payload) => toast(String(payload?.message || '.xlsx 파일 하나만 놓을 수 있습니다.'), 'warn')
  }));
}

function requestPickRvts(state) {
  request(state, 'pick-rvts');
}

function requestWorkbook(state) {
  request(state, 'pick-workbook');
}

function importWorkbook(state, path) {
  if (!path || state.busy) return;
  if (state.rows.length && !window.confirm(`ACC Excel의 작업 행으로 현재 ${state.rows.length}개 행을 교체할까요?`)) return;
  request(state, 'import-workbook', { path });
}

function exportTemplate(state) {
  const rows = serializeRequestRows(state.rows, { allowIncomplete: true });
  request(state, 'export-template', { rows });
}

function exportResults(state) {
  if (state.busy || !state.rows.length) return;
  // Only mutable request identity is sent. Status, cloud identifiers, persistence and
  // cleanup fields are deliberately omitted; the Host exports its trusted cache only.
  request(state, 'export-results', { rows: serializeRequestRows(state.rows, { allowIncomplete: true }) });
}

function runJobs(state) {
  const validation = validateRows(state);
  if (!validation.ok || state.busy) {
    if (!validation.ok) toast(validation.message, 'err', 6200);
    return;
  }
  if (!window.confirm([
    `${state.rows.filter((row) => normalizeAction(row.action) === APPLY).length}개 ACC Cloud Workshared 모델을 TEST로 생성할까요?`,
    '지정한 ACC project/folder가 테스트 전용인지 다시 확인하세요.',
    '같은 폴더/이름의 원격 모델은 덮어쓰지 않습니다.',
    '네트워크 응답이 불명확하면 자동 재시도하지 않습니다.'
  ].join('\n'))) return;
  request(state, 'run', {
    rows: serializeRequestRows(state.rows)
  });
}

function validateRows(state) {
  if (!state.supportedMajor) return { ok: false, message: state.supportMessage || '이 Revit 버전에서는 ACC 클라우드 생성을 실행할 수 없습니다.' };
  if (!state.rows.length) return { ok: false, message: '먼저 Source RVT를 추가하세요.' };
  for (let index = 0; index < state.rows.length; index += 1) {
    const action = normalizeAction(state.rows[index].action);
    if (action !== APPLY && action !== SKIP) {
      return { ok: false, message: `${index + 1}행: Action은 APPLY 또는 SKIP만 허용합니다.` };
    }
  }
  const applyRows = state.rows.filter((row) => normalizeAction(row.action) === APPLY);
  if (!applyRows.length) return { ok: false, message: 'APPLY 작업 행이 없습니다.' };

  const targets = new Map();
  for (let index = 0; index < applyRows.length; index += 1) {
    const row = applyRows[index];
    const label = `${state.rows.indexOf(row) + 1}행`;
    if (!isAbsoluteRvtPath(row.sourcePath)) return { ok: false, message: `${label}: SourceRvtPath가 절대 경로의 .rvt가 아닙니다.` };
    if (!normalizeGuid(row.accountGuid)) return { ok: false, message: `${label}: AccountGuid를 확인하세요.` };
    if (!normalizeGuid(row.projectGuid)) return { ok: false, message: `${label}: ProjectGuid를 확인하세요.` };
    if (!String(row.folderId || '').trim()) return { ok: false, message: `${label}: FolderId가 비어 있습니다.` };
    if (!normalizeModelName(row.modelName)) return { ok: false, message: `${label}: ModelName이 비어 있습니다.` };
    if (!isSupportedRegion(row.region)) return { ok: false, message: `${label}: ACC 1차 버전 Region은 US 또는 EMEA만 지원합니다.` };
    if (String(row.mode || CLOUD_MODE).trim().toLowerCase() !== CLOUD_MODE) return { ok: false, message: `${label}: Mode는 cloud-workshared만 지원합니다.` };
    const targetKey = cloudTargetKey(row);
    if (state.blockedTargetKeys.has(targetKey)) {
      return { ok: false, message: `${label}: 이 cloud target은 이전 실행에서 원격 생성됨 또는 생성 불확정 상태로 잠겼습니다. RowId/원본을 바꾸지 말고 다른 target을 사용하세요.` };
    }
    if (targets.has(targetKey)) return { ok: false, message: `${label}: ${targets.get(targetKey)}행과 동일한 ACC cloud target입니다.` };
    targets.set(targetKey, state.rows.indexOf(row) + 1);
  }
  return { ok: true, message: '' };
}

function serializeRequestRows(rows, options = {}) {
  return rows.map((source) => ({
    rowId: String(source.rowId || newRowId()),
    action: normalizeAction(source.action),
    sourcePath: String(source.sourcePath || '').trim(),
    accountGuid: options.allowIncomplete ? String(source.accountGuid || '').trim() : normalizeGuid(source.accountGuid),
    projectGuid: options.allowIncomplete ? String(source.projectGuid || '').trim() : normalizeGuid(source.projectGuid),
    folderId: String(source.folderId || '').trim(),
    region: String(source.region || DEFAULT_REGION).trim().toUpperCase() || DEFAULT_REGION,
    modelName: normalizeModelName(source.modelName),
    mode: CLOUD_MODE,
    addWorksets: normalizeNames(source.addWorksets),
    retain3DViewOwnership: false,
    ownership3DViewNames: [],
    retainViewTemplateOwnership: false,
    ownershipViewTemplateNames: [],
    viewTemplateOwnershipTargetKind: 'view3d-template-workset-v2',
    pinAndRetainLevelGridOwnership: false,
    levelGridOwnershipTargetKind: 'level-grid-userworkset-v2'
  }));
}

function replaceRows(state, rawRows) {
  const seen = new Set();
  const previous = new Map(state.rows.map((row) => [row.rowId, row]));
  state.rows = arrayOf(rawRows).map((raw) => normalizeRow(raw)).map((row) => {
    if (!row.rowId || seen.has(row.rowId.toLowerCase())) row.rowId = newRowId();
    seen.add(row.rowId.toLowerCase());
    const old = previous.get(row.rowId);
    // The readable path is a display hint; execution and Excel keep the resolved IDs.
    if (old && !row.targetDisplayPath && cloudTargetKey(old) === cloudTargetKey(row)) row.targetDisplayPath = old.targetDisplayPath;
    return row;
  });
  state.selectedRowId = state.rows[0]?.rowId || '';
}

function appendRows(state, rawRows) {
  const bySource = new Set(state.rows.map((row) => normalizePathKey(row.sourcePath)));
  let added = 0;
  arrayOf(rawRows).forEach((raw) => {
    const row = normalizeRow(raw);
    const sourceKey = normalizePathKey(row.sourcePath);
    // Normal RVT registration keeps the established source-path de-duplication behavior.
    // Multiple same-source jobs are created only through copy or RowId-preserving Excel import.
    if (!sourceKey || bySource.has(sourceKey)) return;
    bySource.add(sourceKey);
    state.rows.push(row);
    state.selectedRowId = row.rowId;
    added += 1;
  });
  if (!added) toast('새로 추가할 RVT가 없습니다. 같은 원본의 다른 ACC 대상은 행 복사를 사용하세요.', 'info');
  render(state);
}

function applyCompletedRows(state, rawRows) {
  const byId = new Map(state.rows.map((row) => [row.rowId.toLowerCase(), row]));
  rawRows.forEach((raw) => {
    const completed = normalizeRow(raw);
    const prior = state.rows.find((row) => row.rowId === completed.rowId);
    if (prior) { completed.batchChecked = prior.batchChecked; completed.targetDisplayPath = prior.targetDisplayPath; }
    const current = byId.get(completed.rowId.toLowerCase());
    if (!current) return;
    if (!completed.targetDisplayPath && cloudTargetKey(current) === cloudTargetKey(completed)) completed.targetDisplayPath = current.targetDisplayPath;
    Object.assign(current, completed);
  });
}

function copySelectedRow(state) {
  const row = selectedRow(state);
  if (!row || state.busy) return;
  const copy = normalizeRow({
    ...row,
    rowId: newRowId(),
    status: 'PENDING',
    message: '',
    cloudProjectGuid: '',
    cloudModelGuid: '',
    cloudRegion: '',
    cloudModelPath: '',
    cloudModelUrn: '',
    cloudHubId: '',
    cloudProjectId: '',
    cloudFolderId: '',
    docsUrl: '',
    remoteCreated: false,
    manualCleanupRequired: false,
    persistenceState: '',
    verifiedFreshOpen: false,
    existingWorksets: [],
    createdWorksets: [],
    skippedWorksets: []
  });
  const position = state.rows.indexOf(row) + 1;
  state.rows.splice(position, 0, copy);
  state.selectedRowId = copy.rowId;
  render(state);
}

function removeSelectedRow(state) {
  const index = state.rows.findIndex((row) => row.rowId === state.selectedRowId);
  if (index < 0 || state.busy) return;
  state.rows.splice(index, 1);
  state.selectedRowId = state.rows[Math.min(index, state.rows.length - 1)]?.rowId || '';
  render(state);
}

function requestTargetPicker(state, row, rowIds = [row?.rowId]) {
  if (state.busy || !row) return;
  const controls = [...state.ui.workspace.querySelectorAll('button, input, select, textarea'),
    ...state.ui.runPanel.querySelectorAll('button')].map((node) => ({ node, disabled: node.disabled }));
  controls.forEach(({ node }) => { node.disabled = true; });
  const id = newRowId();
  state.busy = true;
  state.targetPickerRequest = { id, rowId: row.rowId, rowIds,
    restoreControls: () => controls.forEach(({ node, disabled }) => { if (node.isConnected) node.disabled = disabled; }) };
  if (post('acccloud:pick-target', { rowId: row.rowId, pickerRequestId: id }) === false) {
    state.targetPickerRequest?.restoreControls();
    state.targetPickerRequest = null;
    finishRequest(state);
  }
}

function refreshEditedRow(state, row) {
  const positions = [document.scrollingElement, ...document.querySelectorAll('*')]
    .filter((node) => node && (node.scrollTop || node.scrollLeft))
    .map((node) => ({ node, top: node.scrollTop, left: node.scrollLeft }));
  const item = [...state.ui.workspace.querySelectorAll('[data-row-id]')].find((node) => node.dataset.rowId === row.rowId);
  if (item) {
    item.querySelector('.acccloud-row-copy small').textContent = row.modelName || '모델 이름 미입력';
    const status = item.querySelector('.acccloud-status');
    status.textContent = row.status;
    status.className = 'acccloud-status';
  }
  if (state.selectedRowId === row.rowId) state.ui.workspace.querySelector('.acccloud-result-card')?.remove();
  renderRunPanel(state);
  positions.forEach(({ node, top, left }) => { node.scrollTop = top; node.scrollLeft = left; });
}

function updateField(state, row, field, value, rerender = true) {
  if (!row || !field) return;
  const next = field === 'action' ? normalizeAction(value) : field === 'region'
    ? String(value || '').trim().toUpperCase() : String(value || '').trim();
  // Text inputs emit change again on blur, between a button's pointerdown and
  // click. An unchanged value must not replace that button or clear its result.
  if (row[field] === next) return;
  const previous = row[field];
  row[field] = next;
  if (field === 'modelName' && row.targetDisplayPath) {
    // Picker display paths can include the selected filename. Retain the folder
    // hint while reflecting the filename that serializeRequestRows will send.
    row.targetDisplayPath = editedModelDisplayPath(row.targetDisplayPath, previous, next);
    const summary = state.ui.workspace.querySelector('[data-acc-target-summary]');
    if (summary) summary.textContent = row.targetDisplayPath || '생성할 모델 이름을 수정했습니다. ACC 폴더를 다시 확인하세요.';
    const location = state.ui.workspace.querySelector('[data-acc-target-location]');
    if (location) location.value = row.targetDisplayPath || 'ACC 폴더를 다시 확인하세요.';
    updateBulkPreview(state);
  }
  if (['accountGuid', 'projectGuid', 'folderId', 'region'].includes(field) && row.targetDisplayPath) {
    row.targetDisplayPath = '';
    const summary = state.ui.workspace.querySelector('[data-acc-target-summary]');
    if (summary) summary.textContent = '생성 대상을 직접 수정했습니다. 프로젝트·폴더·모델 이름을 확인하세요.';
  }
  clearRowTrustedResult(row);
  // Keep the edited form and its focus/caret intact on input, change and IME.
  refreshEditedRow(state, row);
}

function editedModelDisplayPath(displayPath, previousName, nextName) {
  const hint = String(displayPath || '').trim();
  const leaf = hint.split(/[\\/]/).pop().trim();
  let folder = hint;
  if (/\.rvt$/i.test(leaf)) {
    if (normalizeTargetKeyText(leaf) !== normalizeTargetKeyText(normalizeModelName(previousName))) return '';
    folder = hint.slice(0, hint.length - leaf.length).replace(/[\\/\s]+$/, '');
  }
  const name = normalizeModelName(nextName);
  return folder && name ? `${folder} / ${name}` : folder || name;
}

function clearRowTrustedResult(row) {
  if (!row) return;
  row.status = 'PENDING';
  row.message = '';
  row.cloudProjectGuid = '';
  row.cloudModelGuid = '';
  row.cloudRegion = '';
  row.cloudModelPath = '';
  row.cloudModelUrn = '';
  row.cloudHubId = '';
  row.cloudProjectId = '';
  row.cloudFolderId = '';
  row.docsUrl = '';
  row.remoteCreated = false;
  row.manualCleanupRequired = false;
  row.persistenceState = '';
  row.verifiedFreshOpen = false;
  row.existingWorksets = [];
  row.createdWorksets = [];
  row.skippedWorksets = [];
  row.trustedResultAvailable = false;
}

export function parseAutodeskDocsUrl(value) {
  const text = String(value || '').trim();
  if (!text) throw new Error('Autodesk Docs URL을 붙여 넣으세요.');
  let url;
  try { url = new URL(text); }
  catch { throw new Error('올바른 절대 URL이 아닙니다.'); }
  if (url.protocol !== 'https:' || !AUTODESK_HOST_PATTERN.test(url.hostname)) {
    throw new Error('공식 Autodesk ACC/Docs HTTPS URL만 허용합니다.');
  }

  const params = new URLSearchParams(url.search);
  const hash = String(url.hash || '').replace(/^#/, '');
  const hashQueryIndex = hash.indexOf('?');
  if (hashQueryIndex >= 0) {
    const hashParams = new URLSearchParams(hash.slice(hashQueryIndex + 1));
    hashParams.forEach((item, key) => { if (!params.has(key)) params.set(key, item); });
  }
  const getParam = (...names) => {
    for (const [key, item] of params.entries()) {
      if (names.some((name) => key.toLowerCase() === name.toLowerCase())) return String(item || '').trim();
    }
    return '';
  };

  const rawAccount = getParam('accountId', 'accountGuid', 'hubId');
  const rawProject = getParam('projectId', 'projectGuid');
  const rawFolder = getParam('folderId', 'folderUrn');
  const rawRegion = getParam('region');
  const projectPathMatch = url.pathname.match(/\/projects\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:\/|$)/i);

  const accountGuid = normalizeGuid(rawAccount.replace(/^b\./i, ''));
  const projectGuid = normalizeGuid((rawProject || projectPathMatch?.[1] || '').replace(/^b\./i, ''));
  const folderId = isAuthoritativeFolderId(rawFolder) ? rawFolder : '';
  const region = String(rawRegion || '').trim().toUpperCase();
  if (region && !isSupportedRegion(region)) {
    throw new Error('ACC 1차 버전은 URL의 Region도 US 또는 EMEA만 허용합니다.');
  }
  if (!accountGuid && !projectGuid && !folderId) {
    throw new Error('URL에서 확정적으로 읽을 수 있는 AccountGuid, ProjectGuid 또는 FolderId가 없습니다. 값을 직접 입력하세요.');
  }
  return { accountGuid, projectGuid, folderId, region };
}

function isAuthoritativeFolderId(value) {
  const text = String(value || '').trim();
  if (!text || /\s/.test(text)) return false;
  return /^urn:[A-Za-z0-9._~:%/+\-=]+$/i.test(text) || /^[A-Za-z0-9._~:%/+\-=]{8,512}$/.test(text);
}

function normalizeRow(raw = {}) {
  const sourcePath = String(pick(raw, 'sourcePath', 'SourcePath') || '').trim();
  const rawAction = pick(raw, 'action', 'Action');
  return {
    rowId: String(pick(raw, 'rowId', 'RowId') || newRowId()).trim(),
    action: rawAction === undefined || rawAction === null ? APPLY : normalizeAction(rawAction),
    sourcePath,
    batchChecked: pick(raw, 'batchChecked') !== false,
    accountGuid: String(pick(raw, 'accountGuid', 'AccountGuid') || '').trim(),
    projectGuid: String(pick(raw, 'projectGuid', 'ProjectGuid') || '').trim(),
    folderId: String(pick(raw, 'folderId', 'FolderId') || '').trim(),
    region: String(pick(raw, 'region', 'Region') || DEFAULT_REGION).trim().toUpperCase(),
    modelName: String(pick(raw, 'modelName', 'ModelName') || fileName(sourcePath)).trim(),
    targetDisplayPath: String(pick(raw, 'targetDisplayPath', 'TargetDisplayPath') || '').trim(),
    mode: CLOUD_MODE,
    addWorksets: normalizeNames(pick(raw, 'addWorksets', 'AddWorksets')),
    retain3DViewOwnership: false,
    ownership3DViewNames: [],
    retainViewTemplateOwnership: false,
    ownershipViewTemplateNames: [],
    pinAndRetainLevelGridOwnership: false,
    status: normalizeStatus(pick(raw, 'status', 'Status') || 'PENDING'),
    message: String(pick(raw, 'message', 'Message') || '').trim(),
    cloudProjectGuid: String(pick(raw, 'cloudProjectGuid', 'CloudProjectGuid') || '').trim(),
    cloudModelGuid: String(pick(raw, 'cloudModelGuid', 'CloudModelGuid') || '').trim(),
    cloudRegion: String(pick(raw, 'cloudRegion', 'CloudRegion') || '').trim(),
    cloudModelPath: String(pick(raw, 'cloudModelPath', 'CloudModelPath') || '').trim(),
    cloudModelUrn: String(pick(raw, 'cloudModelUrn', 'CloudModelUrn') || '').trim(),
    cloudHubId: String(pick(raw, 'cloudHubId', 'CloudHubId') || '').trim(),
    cloudProjectId: String(pick(raw, 'cloudProjectId', 'CloudProjectId') || '').trim(),
    cloudFolderId: String(pick(raw, 'cloudFolderId', 'CloudFolderId') || '').trim(),
    docsUrl: String(pick(raw, 'docsUrl', 'DocsUrl') || '').trim(),
    remoteCreated: toBoolean(pick(raw, 'remoteCreated', 'RemoteCreated')),
    manualCleanupRequired: toBoolean(pick(raw, 'manualCleanupRequired', 'ManualCleanupRequired')),
    persistenceState: String(pick(raw, 'persistenceState', 'PersistenceState') || '').trim(),
    verifiedFreshOpen: toBoolean(pick(raw, 'verifiedFreshOpen', 'VerifiedFreshOpen')),
    existingWorksets: normalizeNames(pick(raw, 'existingWorksets', 'ExistingWorksets')),
    createdWorksets: normalizeNames(pick(raw, 'createdWorksets', 'CreatedWorksets')),
    skippedWorksets: normalizeNames(pick(raw, 'skippedWorksets', 'SkippedWorksets'))
  };
}

function newRow(sourcePath) {
  return normalizeRow({ sourcePath, rowId: newRowId(), modelName: fileName(sourcePath), status: 'PENDING' });
}

function cloudTargetKey(row) {
  return [
    normalizeGuid(row.accountGuid).replace(/-/g, ''),
    normalizeGuid(row.projectGuid).replace(/-/g, ''),
    normalizeTargetKeyText(row.folderId),
    normalizeTargetKeyText(normalizeModelName(row.modelName))
  ].join('|');
}

function normalizeTargetKeyText(value) {
  return String(value || '').trim().normalize('NFC').toLowerCase();
}

function normalizeGuid(value) {
  const text = String(value || '').trim().replace(/^b\./i, '').replace(/[{}]/g, '');
  const match = text.match(/^([0-9a-f]{8})-?([0-9a-f]{4})-?([0-9a-f]{4})-?([0-9a-f]{4})-?([0-9a-f]{12})$/i);
  return match ? match.slice(1).join('-').toLowerCase() : '';
}

function isSupportedRegion(value) {
  const region = String(value || DEFAULT_REGION).trim().toUpperCase();
  return region === 'US' || region === 'EMEA';
}

function normalizeModelName(value) {
  const text = String(value || '').trim().normalize('NFC');
  if (!text) return '';
  return /\.rvt$/i.test(text) ? text : `${text}.rvt`;
}

function normalizeAction(value) {
  return String(value ?? '').trim().toUpperCase();
}

function normalizeStatus(value) {
  return String(value || 'PENDING').trim().toUpperCase();
}

function normalizeNames(value) {
  const values = Array.isArray(value) ? value : String(value || '').split(/[;\r\n]+/);
  const seen = new Set();
  return values.map((item) => String(item || '').trim()).filter((item) => item && !seen.has(item) && seen.add(item));
}

function isAbsoluteRvtPath(value) {
  const text = String(value || '').trim();
  return (/^[A-Za-z]:\\/.test(text) || /^\\\\[^\\]+\\[^\\]+/.test(text)) && /\.rvt$/i.test(text);
}

function selectedRow(state) {
  return state.rows.find((row) => row.rowId === state.selectedRowId) || null;
}

function ensureSelected(state) {
  if (!state.rows.some((row) => row.rowId === state.selectedRowId)) state.selectedRowId = state.rows[0]?.rowId || '';
}

function newRowId() {
  try { return crypto.randomUUID().replace(/-/g, ''); }
  catch { return `acc${Date.now().toString(36)}${Math.random().toString(36).slice(2, 12)}`; }
}

function fileName(path) {
  return String(path || '').split(/[\\/]/).pop() || '';
}

function normalizePathKey(path) {
  return String(path || '').trim().replace(/\//g, '\\').replace(/\\+$/, '').toLowerCase();
}

function readonlyField(label, value, reference = '') {
  const field = div('acccloud-field');
  field.innerHTML = `<label>${escapeHtml(label)}</label><input type="text" readonly value="${escapeAttribute(value)}" />`;
  if (reference) field.querySelector('input').dataset[reference] = '';
  return field;
}

function textField(label, fieldName, value, placeholder) {
  const field = div('acccloud-field');
  field.innerHTML = `<label>${escapeHtml(label)}</label><input type="text" spellcheck="false" data-field="${escapeAttribute(fieldName)}" value="${escapeAttribute(value)}" placeholder="${escapeAttribute(placeholder)}" />`;
  return field;
}

function selectField(label, fieldName, value, options) {
  const field = div('acccloud-field');
  const select = document.createElement('select');
  select.dataset.field = fieldName;
  options.forEach((option) => {
    const item = document.createElement('option');
    item.value = option;
    item.textContent = option;
    item.selected = option === value;
    select.append(item);
  });
  const labelElement = document.createElement('label');
  labelElement.textContent = label;
  field.append(labelElement, select);
  return field;
}

function button(label, handler, kind = 'secondary', disabled = false) {
  const element = document.createElement('button');
  element.type = 'button';
  element.className = `btn btn-${kind}`;
  element.textContent = label;
  element.disabled = !!disabled;
  element.addEventListener('click', handler);
  return element;
}

function safeHttpUrl(value) {
  try {
    const url = new URL(String(value || ''));
    return url.protocol === 'https:' && AUTODESK_HOST_PATTERN.test(url.hostname) ? url.href : '';
  } catch { return ''; }
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
}

function escapeAttribute(value) {
  return escapeHtml(value);
}

function pick(source, camel, pascal) {
  if (!source || typeof source !== 'object') return undefined;
  if (source[camel] !== undefined) return source[camel];
  return source[pascal];
}

function arrayOf(value) {
  return Array.isArray(value) ? value : [];
}

function toBoolean(value) {
  if (typeof value === 'boolean') return value;
  return ['true', '1', 'yes', 'y'].includes(String(value || '').trim().toLowerCase());
}

function toInteger(value) {
  const parsed = Number.parseInt(String(value || '0'), 10);
  return Number.isFinite(parsed) ? parsed : 0;
}
