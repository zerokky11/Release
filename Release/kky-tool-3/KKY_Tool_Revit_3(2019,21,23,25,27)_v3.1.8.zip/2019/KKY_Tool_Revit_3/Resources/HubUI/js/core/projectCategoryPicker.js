const read = (value, key, fallback = '') => value?.[key] ?? value?.[key[0].toLowerCase() + key.slice(1)] ?? fallback;
const typeNames = { Model: '모델', Annotation: '주석', AnalyticalModel: '해석 모델', Internal: '내부' };

// Category IDs remain independent binding choices. A native parent is a visual
// relationship, not permission to silently bind all of its descendants.
export function openProjectCategoryPicker({ categories, selectedIds, trigger, onApply, onClose }) {
  const selected = new Set(selectedIds.map(Number));
  const nodes = new Map();
  for (const item of categories) {
    const id = Number(read(item, 'Id'));
    if (!Number.isSafeInteger(id) || nodes.has(id)) continue;
    nodes.set(id, { id, name: String(read(item, 'Name')), parentId: read(item, 'ParentId', null), type: String(read(item, 'CategoryType')), selectable: read(item, 'Selectable', read(item, 'AllowsBoundParameters', true)) === true, children: [], expanded: false });
  }
  // Keep selections absent from a refreshed document catalog until the user
  // explicitly removes them. Never replace an unknown ID with a same-name item.
  for (const id of selected) if (!nodes.has(id)) nodes.set(id, { id, name: `현재 문서에서 확인할 수 없는 카테고리 (${id})`, parentId: null, type: '', selectable: true, children: [], unavailable: true });
  const roots = [];
  for (const node of nodes.values()) {
    const parent = node.parentId == null ? null : nodes.get(Number(node.parentId));
    const seen = new Set([node.id]); let cursor = parent, cycle = false;
    while (cursor) { if (seen.has(cursor.id)) { cycle = true; break; } seen.add(cursor.id); cursor = cursor.parentId == null ? null : nodes.get(Number(cursor.parentId)); }
    node.parent = !cycle && parent ? parent : null;
    (node.parent ? node.parent.children : roots).push(node);
  }
  const sort = items => { items.sort((a, b) => a.name.localeCompare(b.name, 'ko', { numeric: true }) || a.id - b.id); items.forEach(node => sort(node.children)); };
  sort(roots);
  const all = []; const visit = items => items.forEach(node => { all.push(node); visit(node.children); }); visit(roots);
  all.forEach(node => { node.removableOnly = !node.selectable && selected.has(node.id); });
  for (const node of all) if (selected.has(node.id)) { let parent = node.parent; while (parent) { parent.expanded = true; parent = parent.parent; } }
  let locked = false, closed = false, composing = false, searchText = '', activeNode = null;
  const dialog = document.createElement('dialog');
  dialog.className = 'parammigration-category-dialog parammigration-card';
  dialog.dataset.categoryDialog = '';
  dialog.setAttribute('aria-labelledby', 'parammigration-category-title');
  dialog.innerHTML = `<header><h2 id="parammigration-category-title">카테고리 선택</h2><button type="button" class="secondary" data-category-close aria-label="카테고리 선택 닫기">닫기</button></header>
    <div class="parammigration-category-tools">
      <label class="parammigration-field"><span>검색</span><input type="search" data-category-search placeholder="카테고리 이름 검색" autocomplete="off"></label>
      <label class="parammigration-field"><span>분류</span><select data-category-type aria-label="카테고리 분류"><option value="">전체 카테고리</option></select></label>
      <div class="parammigration-category-toolbar"><label class="parammigration-toggle"><input type="checkbox" data-category-selected-only>선택한 항목만</label><div class="parammigration-actions"><button type="button" class="secondary" data-category-expand>모두 펼치기</button><button type="button" class="secondary" data-category-collapse>모두 접기</button></div></div>
    </div>
    <div class="parammigration-category-list" data-category-scroll tabindex="0" role="region" aria-label="카테고리 목록">
      <ul class="parammigration-category-tree" role="tree" aria-label="프로젝트 파라미터 카테고리" aria-multiselectable="true"></ul><p class="parammigration-note" data-category-empty hidden>조건에 맞는 카테고리가 없습니다.</p>
    </div>
    <div class="parammigration-category-selection"><div class="parammigration-actions"><button type="button" class="secondary" data-category-check-all>모두 선택</button><button type="button" class="secondary" data-category-uncheck-all>모두 해제</button></div><span data-category-visible-count></span></div>
    <footer><div><strong data-category-total role="status"></strong><p class="parammigration-note">상위·하위 항목은 각각 선택합니다.</p></div><div class="parammigration-actions"><button type="button" class="secondary" data-category-cancel>취소</button><button type="button" class="primary" data-category-apply>확인</button></div></footer>`;
  const $ = selector => dialog.querySelector(selector);
  const query = $('[data-category-search]'), type = $('[data-category-type]'), selectedOnly = $('[data-category-selected-only]');
  [...new Set(all.map(node => node.type).filter(Boolean))].sort().forEach(value => { const option = document.createElement('option'); option.value = value; option.textContent = typeNames[value] || value; type.append(option); });
  const build = (items, container, depth) => items.forEach(node => {
    const li = document.createElement('li'); li.setAttribute('role', 'treeitem'); li.setAttribute('aria-level', String(depth)); li.setAttribute('aria-label', node.name); li.tabIndex = -1; li.dataset.categoryId = String(node.id);
    const row = document.createElement('div'); row.className = 'parammigration-category-row'; row.style.setProperty('--category-depth', depth - 1);
    const toggle = document.createElement('button'); toggle.type = 'button'; toggle.className = 'parammigration-category-disclosure'; toggle.tabIndex = -1; toggle.setAttribute('aria-label', `${node.name} 펼치기`); toggle.hidden = !node.children.length;
    const gutter = document.createElement('span'); gutter.className = 'parammigration-category-gutter'; gutter.append(toggle); row.append(gutter);
    const label = document.createElement('label'); label.className = 'parammigration-category-label';
    if (node.selectable || node.removableOnly) {
      const input = document.createElement('input'); input.type = 'checkbox'; input.checked = selected.has(node.id); input.value = String(node.id); input.tabIndex = -1; input.setAttribute('aria-label', node.name); node.input = input; label.append(input);
      input.addEventListener('change', () => { if (locked || (node.removableOnly && input.checked && !selected.has(node.id))) { input.checked = selected.has(node.id); return; } input.checked ? selected.add(node.id) : selected.delete(node.id); focusNode(node, false); refresh(); });
    } else { const placeholder = document.createElement('span'); placeholder.className = 'parammigration-category-checkbox-space'; label.append(placeholder); }
    const name = document.createElement('span'); name.textContent = node.name; label.append(name); row.append(label);
    if (!node.selectable) { const badge = document.createElement('small'); badge.className = 'parammigration-category-context'; badge.textContent = node.removableOnly ? '기존 선택' : '분류'; if (node.removableOnly) badge.title = '현재 추가할 수 없는 기존 선택입니다. 해제할 수 있습니다.'; row.append(badge); }
    li.append(row); container.append(li); node.li = li; node.row = row; node.toggle = toggle;
    if (node.children.length) { const children = document.createElement('ul'); children.setAttribute('role', 'group'); li.append(children); node.group = children; build(node.children, children, depth + 1); }
    toggle.addEventListener('click', () => { node.expanded = !node.expanded; focusNode(node, false); refresh(); });
    row.addEventListener('click', event => { if (!event.target.closest('button,input,label')) focusNode(node, false); });
    li.addEventListener('focus', () => { activeNode = node; all.forEach(item => { item.li.tabIndex = item === node ? 0 : -1; }); });
    li.addEventListener('keydown', event => {
      if (event.target.closest('[role="treeitem"]') !== li || locked) return;
      const visible = all.filter(item => item.visible), index = visible.indexOf(node);
      if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) { event.preventDefault(); const next = event.key === 'Home' ? visible[0] : event.key === 'End' ? visible[visible.length - 1] : visible[Math.min(visible.length - 1, Math.max(0, index + (event.key === 'ArrowDown' ? 1 : -1)))]; focusNode(next); }
      else if (event.key === 'ArrowRight' && node.children.length) { event.preventDefault(); if (!node.open) { node.expanded = true; refresh(); } else focusNode(node.children.find(item => item.visible)); }
      else if (event.key === 'ArrowLeft') { event.preventDefault(); if (node.open && node.children.length) { node.expanded = false; refresh(); } else focusNode(node.parent); }
      else if ((event.key === ' ' || event.key === 'Enter') && node.input) { event.preventDefault(); node.input.click(); }
    });
  });
  build(roots, $('.parammigration-category-tree'), 1);
  function focusNode(node, scroll = true) { if (!node) return; activeNode = node; node.li.focus({ preventScroll: !scroll }); }
  function refresh() {
    const focusedItem = document.activeElement?.closest('[role="treeitem"]');
    // A Host echo must not use an unfinished IME composition as a new filter.
    const words = searchText.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean), filtering = !!words.length || !!type.value || selectedOnly.checked;
    const mark = (node, path) => {
      const full = `${path} ${node.name}`.toLocaleLowerCase();
      node.match = words.every(word => full.includes(word)) && (!type.value || type.value === node.type) && (!selectedOnly.checked || selected.has(node.id));
      node.children.forEach(child => mark(child, full)); node.shown = node.match || node.children.some(child => child.shown);
    };
    roots.forEach(node => mark(node, ''));
    const display = (node, parentVisible) => {
      node.visible = parentVisible && node.shown; node.li.hidden = !node.shown;
      node.open = filtering ? node.children.some(child => child.shown) : node.expanded;
      if (node.group) { node.group.hidden = !node.open; node.li.setAttribute('aria-expanded', String(node.open)); node.toggle.textContent = node.open ? '▾' : '▸'; node.toggle.setAttribute('aria-label', `${node.name} ${node.open ? '접기' : '펼치기'}`); }
      if (node.input) { node.input.checked = selected.has(node.id); node.input.disabled = locked || (node.removableOnly && !node.input.checked); node.li.setAttribute('aria-checked', String(node.input.checked)); }
      node.children.forEach(child => display(child, node.visible && node.open));
    };
    roots.forEach(node => display(node, true));
    const matches = all.filter(node => node.match && node.input), visible = all.filter(node => node.visible);
    if (!activeNode?.visible) activeNode = activeNode?.parent?.visible ? activeNode.parent : all.slice(0, activeNode ? all.indexOf(activeNode) : 0).reverse().find(node => node.visible) || visible[0];
    all.forEach(node => { node.li.tabIndex = node === activeNode ? 0 : -1; });
    if (focusedItem && dialog.contains(focusedItem) && !all.find(node => node.li === focusedItem)?.visible) {
      if (activeNode) focusNode(activeNode); else $('[data-category-scroll]').focus({ preventScroll: true });
    }
    $('[data-category-empty]').hidden = !!visible.length;
    $('[data-category-total]').textContent = `${selected.size}개 선택`;
    $('[data-category-visible-count]').textContent = `${matches.length}개 항목`;
    $('[data-category-check-all]').textContent = filtering ? '검색 결과 선택' : '모두 선택';
    $('[data-category-uncheck-all]').textContent = filtering ? '검색 결과 해제' : '모두 해제';
    $('[data-category-check-all]').disabled = locked || !matches.some(node => node.selectable && !selected.has(node.id) && !node.unavailable);
    $('[data-category-uncheck-all]').disabled = locked || !matches.some(node => selected.has(node.id));
    $('[data-category-expand]').disabled = locked || filtering || !all.some(node => node.children.length);
    $('[data-category-collapse]').disabled = locked || filtering || !all.some(node => node.children.length);
  }
  const filter = () => { if (!composing) { searchText = query.value; refresh(); } };
  query.addEventListener('compositionstart', () => { composing = true; });
  query.addEventListener('compositionend', () => { composing = false; filter(); });
  query.addEventListener('input', filter); type.addEventListener('change', filter); selectedOnly.addEventListener('change', filter);
  $('[data-category-expand]').addEventListener('click', () => { all.forEach(node => { node.expanded = true; }); refresh(); });
  $('[data-category-collapse]').addEventListener('click', () => { all.forEach(node => { node.expanded = false; }); refresh(); });
  $('[data-category-check-all]').addEventListener('click', () => { if (!locked) { all.filter(node => node.match && node.selectable && !node.unavailable).forEach(node => selected.add(node.id)); refresh(); } });
  $('[data-category-uncheck-all]').addEventListener('click', () => { if (!locked) { all.filter(node => node.match && node.input).forEach(node => selected.delete(node.id)); refresh(); } });
  function close(restoreFocus = true) { if (closed) return; closed = true; dialog.close(); dialog.remove(); onClose?.(); if (restoreFocus && trigger?.isConnected && !trigger.disabled) trigger.focus({ preventScroll: true }); }
  ['close', 'cancel'].forEach(action => $(`[data-category-${action}]`).addEventListener('click', () => close()));
  dialog.addEventListener('cancel', event => { event.preventDefault(); close(); });
  $('[data-category-apply]').addEventListener('click', () => { if (!locked && onApply([...selected]) !== false) close(); });
  document.body.append(dialog); refresh(); dialog.showModal(); query.focus({ preventScroll: true });
  return { close, setLocked(value) { if (closed || locked === !!value) return; locked = !!value; query.disabled = locked; type.disabled = locked; selectedOnly.disabled = locked; $('[data-category-apply]').disabled = locked; refresh(); } };
}
