import { post, onHost } from '../core/bridge.js';
import { showExcelSavedDialog } from '../core/dom.js';
import { ProgressDialog } from '../core/progress.js?v=20260907organizerprogress1';

const STORAGE = 'kky.settings.revieworganizer.v1';
const FEATURES = [
  ['offline', '일반 결과'], ['connector', '파라미터 연속성 검토'], ['unconnected', '미연결 검토'],
  ['reducerpoint', 'Reducer Point 정합성 검토'], ['floorinfo', '레벨 영역별 파라미터 검토'],
  ['gridlevelconsistency', 'Grid / Level 기준 정합성 검토'], ['familysuitability', '패밀리 타입 적합성 검토'],
  ['tapalign', '탭/분기 축 틀어짐 검토'], ['tapdepth', 'Tap, Saddle 모델링 검토 (묻힘)'],
  ['dupclash', '중복 / 자체 간섭 검토'], ['worksetassignment', '웍셋 배정 검토'],
  ['parameterduplication', '프로젝트 파라미터 중복 검토'], ['parametermissing', '파라미터 누락 검토'],
  ['parameterstandard', '속성 모수 검토'], ['utilitymaterial', 'UTILITY 기반 재질 오류 검토'],
  ['ghostcleaner', '유령객체 제거'], ['guid', '파라미터 GUID 검토 및 정리'],
  ['familylink', '패밀리 공유파라미터 연동 검토'], ['points', '기준점/북각 추출'],
  ['linkworkset', '링크 기본 웍셋 점검/적용'], ['pms', 'PMS 검토']
];
const lowerKeys = value => Array.isArray(value) ? value.map(lowerKeys) : value && typeof value === 'object'
  ? Object.fromEntries(Object.entries(value).map(([key, item]) => [key[0].toLowerCase() + key.slice(1), lowerKeys(item)])) : value;
const basename = value => String(value || '').split(/[\\/]/).pop();
const uniqueId = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;
const labelFor = feature => FEATURES.find(([key]) => key === feature)?.[1] || feature || '일반 결과';
const modelLabel = model => model === '@rows' ? '행별 모델명으로 연결' : model || '모델 미지정';
const normalizeHint = value => String(value || '').trim().toLowerCase();
const normalizeAnswer = value => String(value ?? '').replace(/\r\n?/g, '\n').trim();
const normalizeCommonHeader=value=>String(value??'').trim().toLowerCase();
const COMMON_ELEMENT_HEADERS={'@family':'패밀리명','@type':'타입명','@category':'카테고리'};
const commonHeaderLabel=value=>COMMON_ELEMENT_HEADERS[normalizeCommonHeader(value)]||value;
const COMMON_OPERATORS=[['equals','같음'],['contains','포함'],['notEquals','같지 않음'],['notContains','포함하지 않음'],['blank','빈칸'],['notBlank','빈칸 아님']];
function normalizeReviewName(value) {
  let name = String(value || '');
  const count = /(?:^|[_\s-])\d+\s*EA(?=$|[_\s\-(\[])/i.exec(name);
  if (count) name = name.slice(0, count.index);
  return name.replace(/(?:^|[_\s-])(?:제\s*)?\d+\s*차$/i, '').replace(/^[_\s-]+|[_\s-]+$/g, '').replace(/\s+/g, ' ').toLowerCase();
}
function fileNameRule(p, modelName = p.modelHint) {
  const model = basename(modelName || '').replace(/\.rvt$/i, ''), file = basename(p.path).replace(/\.xlsx?$/i, '');
  // Protect an exact model prefix before stripping the count, round and reviewer suffix.
  if (model && model !== '@rows' && file.toLowerCase().startsWith(model.toLowerCase()) && /[_\s-]/.test(file.charAt(model.length))) return normalizeReviewName(file.slice(model.length)) || normalizeReviewName(file);
  return normalizeReviewName(file);
}
const readPresets = () => { try { return JSON.parse(localStorage.getItem(STORAGE) || '{}'); } catch { return {}; } };
const normalizedColumns = (values, columns) => [...new Set((values || []).map(Number))].filter(i => columns.some(c => c.index === i));
const autoAnswerColumns = p => normalizedColumns(p.detection?.answerColumns || (p.columns || []).filter(c => c.suggested && c.header !== '예외 적용 근거').map(c => c.index), p.columns || []);
const sourceHeaderBlocked = entry => !!entry?.choice.sourceAnswerHeader && ['ambiguous','invalid'].includes(entry.p.detection?.sourceAnswerHeaderStatus);
const sourceHeaderSummary = entry => {
  const header=entry?.choice.sourceAnswerHeader;if(!header)return '';
  const status=entry.p.detection?.sourceAnswerHeaderStatus;
  return status==='matched'?` · 지정 열: ${header}`:status==='missing'?` · ${header} 열 없음 · 자동 찾기`:status==='ambiguous'?` · ${header} 열 중복 · 직접 선택 필요`:status==='invalid'?` · ${header} 열 사용 불가`:` · 지정 열 확인 예정: ${header}`;
};
const answerColumnSummary = entry => {
  if (!entry) return '';
  const source=sourceHeaderSummary(entry);
  const columns = (entry.p.columns || []).filter(column => entry.choice.answerColumns.includes(column.index));
  if (columns.length) return source+` · 답변: ${columns.slice(0, 3).map(column => column.header || `${column.letter}열`).join(', ')}${columns.length > 3 ? ` 외 ${columns.length - 3}개` : ''}${entry.answerColumnsManual ? ' (직접 지정)' : entry.p.detection?.needsReview ? ' · 추가 확인 필요' : ''}`;
  return source || (entry.p.detection?.needsReview ? ' · 답변 열 확인 필요' : ' · 답변 없음');
};
const parseKeywords = value => {
  const seen = new Set();
  return String(value || '').split(/\r?\n/).map(word => word.trim()).filter(word => {
    const key = word.toLowerCase(); if (!word || seen.has(key)) return false; seen.add(key); return true;
  });
};

function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text != null) node.textContent = text;
  if (className) node.className = className;
  return node;
}
function button(text, handler, primary = false) {
  const node = element('button', text, `btn ${primary ? 'btn--primary' : 'btn--secondary'}`);
  node.type = 'button'; node.addEventListener('click', handler); return node;
}
function input(label, value = '') {
  const node = element('input'); node.value = value; node.setAttribute('aria-label', label); return node;
}
function checkbox(label, checked, handler) {
  const wrapper = element('label', null, 'ro-check'), node = input(label); node.type = 'checkbox'; node.checked = checked;
  node.addEventListener('change', () => handler(node.checked)); wrapper.append(node, document.createTextNode(label));
  return { wrapper, node };
}
function field(label, control) { const node = element('label', label, 'ro-field'); node.append(control); return node; }
function option(select, value, label) { const node = element('option', label); node.value = value; select.append(node); }

function installStyles() {
  if (document.getElementById('review-organizer-styles')) return;
  const link = element('link'); link.id = 'review-organizer-styles'; link.rel = 'stylesheet';
  link.href = new URL('../../css/views.revieworganizer.css?v=20260910sourceanswerheader1', import.meta.url).href;
  document.head.append(link);
}

// Lists use lazy detail panels. Editing a field never replaces its DOM or an ancestor.
export function renderReviewOrganizer(root, options = {}) {
  installStyles();
  const presets = readPresets(), previous = new Map(), current = new Map(), unsubscribers = new Set();
  let exclusionKeywords = parseKeywords((presets.exclusionKeywords || []).join('\n'));
  let keywordMatchMode = String(presets.keywordMatchMode || 'OR').toUpperCase() === 'AND' ? 'AND' : 'OR';
  const requests = new Map(), sourceUi = {}, importButtons = [], allTokens = new Set(), importRequestIds = new Set(), destinationFields = new Map();
  presets.destinationHeaders ||= {};
  let destinationMode=presets.destinationMode==='new'?'new':'existing',newDestinationHeader=presets.newDestinationHeader??'정리 답변';
  let sourceAnswerHeader=String(presets.sourceAnswerHeader||'').trim(),sourceHeaderComposing=false,sourceHeaderDirty=false;
  let lastRunResult=null,resultDialogReturnFocus=null,exportResultDialog=null;
  let commonRules=[],commonRulesDataset='',commonRulesDraft=[],commonDialogDataset='',commonDialogHeaders=[],commonDialogReturnFocus=null;
  const commonRulePanels=new Map();
  const commonHeaderCoverage=new Map();let commonHeaderSheetCount=0;
  let pending = 0, closed = false, running = false, runId = '', mappingGeneration = 0, lastMessage = '', errors = [], resuggestRequested = false, suggestQueued = false, detectionPromise = null;
  let previewSignature = '', previewRequestId = '', previewOffset = 0, previewData = null, activePane = 'sources', outputFolder = '';
  let selectedToken='',detailGeneration=0,detailRequestId='',navigationRevision=0;
  const detailPreviewCache=new Map();
  let activeProgressWork=null,runProgressWork=null;
  const progressRequests=new Map();
  const outputNames = new Map(), outputNameControls = new Map();
  const answerEdits=new Map(),answerEditors=new Map(),answerRowControls=new Map();
  let answerGroups=[],answerCatalogSignature='',answerCatalogLoaded=false,answerCatalogRequest='',answerCatalogGeneration=0,answerCatalogQueued=false,answerSelectedKey='',answerPage=0,answerCatalogPromise=null,answerFailedSignature='';
  const page = element('main', null, 'review-organizer'); page.dataset.scrollKey = 'review-organizer';
  root.replaceChildren(page);
  const intro = element('header', null, 'ro-intro');
  intro.append(element('h1', '다회차 엑셀 결과 정리'), element('p', '이전 회신을 반영하고 2차 파일 전체를 저장합니다. 미연결 파일은 원본을 유지합니다.', 'ro-hint'));page.append(intro);
  const sourcePane=element('section',null,'ro-pane ro-source-pane'),sourceIntro=element('div',null,'ro-stage-intro');sourceIntro.append(element('h2','비교할 파일을 선택하세요'),element('p','작업자의 답변이 담긴 1차 회신과 새로 추출한 2차 결과를 각각 선택하세요.','ro-hint'));sourcePane.append(sourceIntro);
  const sourceHeaderCard=element('section',null,'ro-source-answer-header'),sourceHeaderControls=element('div',null,'ro-source-header-controls');
  const sourceHeaderInput=editable(input('계승할 열 이름',sourceAnswerHeader),'organizer-source-answer-header');sourceHeaderInput.maxLength=80;sourceHeaderInput.placeholder='예: 시공 검토';
  const sourceHeaderApply=button('적용',()=>void applySourceAnswerHeader());sourceHeaderApply.setAttribute('aria-label','계승할 열 적용');
  const sourceHeaderHelp=element('p','1차 회신에서 가져올 열 제목을 입력하세요. 비워 두면 자동으로 찾고, 해당 열이 없는 파일도 기존 방식으로 찾습니다.','ro-hint');
  sourceHeaderInput.title='앞뒤 공백과 영문 대소문자는 구분하지 않습니다. 내부 공백과 기호는 제목과 같게 입력하세요.';
  const sourceHeaderState=element('p','','ro-hint ro-source-header-state');sourceHeaderState.setAttribute('role','status');
  sourceHeaderControls.append(field('계승할 열 이름 (선택)',sourceHeaderInput),sourceHeaderApply);sourceHeaderCard.append(sourceHeaderControls,sourceHeaderHelp,sourceHeaderState);sourcePane.append(sourceHeaderCard);
  sourceHeaderInput.addEventListener('input',refreshSourceHeaderControl);
  sourceHeaderInput.addEventListener('compositionstart',()=>{sourceHeaderComposing=true;refreshSourceHeaderControl();});
  sourceHeaderInput.addEventListener('compositionend',()=>{sourceHeaderComposing=false;refreshSourceHeaderControl();});
  sourceHeaderInput.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.isComposing&&!sourceHeaderComposing){event.preventDefault();void applySourceAnswerHeader();}});
  const sources = element('div', null, 'ro-sources');sources.dataset.scrollKey='organizer-source-panels';sourcePane.append(sources);
  const workspace = element('section', null, 'ro-workspace'), tabs = element('div', null, 'ro-tabs'); tabs.setAttribute('role','tablist');
  const panes = new Map(), tabButtons = new Map();
  for(const [index,[key,label]] of [['sources','파일 선택'],['preview','연결 확인'],['answers','답변 정리'],['output','저장']].entries()){
    const tab=button('',()=>{selectPane(key);update();});tab.append(element('span',String(index+1),'ro-step-number'),element('span',label));tab.setAttribute('aria-label',label);tab.setAttribute('role','tab');tab.id=`organizer-tab-${key}`;tab.setAttribute('aria-controls',`organizer-panel-${key}`);tab.dataset.pane=key;tabButtons.set(key,tab);tabs.append(tab);
  }
  tabs.addEventListener('keydown',event=>{
    const keys=[...tabButtons.keys()],index=keys.indexOf(event.target.dataset.pane);if(index<0)return;
    const next=event.key==='Home'?0:event.key==='End'?keys.length-1:event.key==='ArrowRight'?(index+1)%keys.length:event.key==='ArrowLeft'?(index+keys.length-1)%keys.length:-1;
    if(next<0)return;event.preventDefault();selectPane(keys[next]);update();tabButtons.get(keys[next]).focus({preventScroll:true});
  });
  workspace.append(tabs);page.append(workspace);
  const previewPane=element('section',null,'ro-pane ro-preview-pane'), previewSummary=element('div',null,'ro-preview-summary'), previewNotice=element('p','파일 연결을 확인한 뒤 답변 정리로 이동하세요. 필요한 파일은 답변 비교로 먼저 확인할 수 있습니다.','ro-hint ro-preview-notice');
  const reviewTop=element('div',null,'ro-review-top'),reviewCopy=element('div');reviewCopy.append(element('h2','연결된 결과를 확인하세요'),previewNotice);reviewTop.append(reviewCopy,previewSummary);previewPane.append(reviewTop);
  const reviewSplit=element('div',null,'ro-review-split'),filePanel=element('section',null,'ro-file-panel'),detailPanel=element('section',null,'ro-detail-panel');reviewSplit.append(filePanel,detailPanel);previewPane.append(reviewSplit);
  const detailHeading=element('div',null,'ro-detail-heading'),detailTitle=element('h3','파일을 선택하세요'),detailPair=element('p','','ro-detail-pair'),detailStatus=element('p','','ro-hint');detailHeading.append(detailTitle,detailPair,detailStatus);detailPanel.append(detailHeading);
  const previewScroll=element('div',null,'ro-preview-scroll');previewScroll.dataset.scrollKey='organizer-change-preview';
  const previewPages=element('div',null,'ro-preview-pages'), pageLabel=element('span',''), previousPage=button('이전 답변',()=>loadSelectedPreview(Math.max(0,previewOffset-50))),nextPage=button('다음 답변',()=>loadSelectedPreview(previewOffset+50));
  previewPages.append(previousPage,pageLabel,nextPage);previewPages.hidden=true;detailPanel.append(previewScroll,previewPages);
  const mappingCard = element('details', null, 'ro-detail-settings');mappingCard.append(element('summary','이 파일의 연결·답변 설정'));detailPanel.append(mappingCard);
  const selectionSettings=element('div',null,'ro-selection-settings');mappingCard.append(selectionSettings);
  const commonSettings=element('details',null,'ro-common-settings');commonSettings.append(element('summary','전체 파일에 적용할 설정'));previewPane.append(commonSettings);
  const mappingTools = element('div', null, 'ro-tools'), mappingCount = element('span', '', 'ro-mapping-count');
  const destinationHost = element('details', null, 'ro-destinations');
  destinationHost.append(element('summary', '이전 답변을 넣을 열 · 기능별 설정'), element('p', '기본값은 비고입니다. 이전 회신에서 가져온 작업자 답변을 새 결과의 어느 열에 기록할지 선택하세요. 없으면 해당 제목의 열을 추가합니다.', 'ro-hint'));
  const suggestButton = button('자동 연결 다시 찾기', () => suggest());
  const onlyUnresolved = checkbox('확인 필요한 항목만 보기', false, () => filterMappings());
  mappingTools.append(mappingCount,onlyUnresolved.wrapper);
  const mappingSearch = input('연결할 결과 검색'); mappingSearch.placeholder = '파일명, 모델, 검토 기능 검색'; mappingSearch.className = 'ro-search'; mappingSearch.dataset.focusKey = 'organizer-mapping-search';
  mappingSearch.addEventListener('input', filterMappings);
  const mappingList = element('div', null, 'ro-list ro-map-list'); mappingList.dataset.scrollKey = 'organizer-mappings';
  const mappingEmpty = element('p', '2차 결과를 불러오면 연결 목록이 표시됩니다.', 'ro-empty');
  mappingList.append(mappingEmpty); filePanel.append(mappingTools, mappingSearch, mappingList);commonSettings.append(suggestButton);
  const answersPane=element('section',null,'ro-pane ro-answers-pane'),answersIntro=element('div',null,'ro-stage-intro');
  answersIntro.append(element('h2','같은 답변을 한 번에 정리하세요'),element('p','자동 안내를 제외한 작업자 답변을 연결된 전체 파일에서 모았습니다. 같은 원문의 저장 문구와 수량 처리를 한 번에 지정하세요.','ro-hint'));answersPane.append(answersIntro);
  const destinationCard=element('section',null,'ro-answer-destination'),destinationControls=element('div',null,'ro-destination-controls'),destinationTop=element('div',null,'ro-destination-top');
  const commonRulesButton=button('공통 설정',openCommonRules);commonRulesButton.setAttribute('aria-label','공통 설정');commonRulesButton.dataset.action='common-rules';commonRulesButton.classList.add('ro-settings-button');
  const destinationModeControl=editable(element('select'),'organizer-destination-mode');destinationModeControl.setAttribute('aria-label','답변 저장 위치');option(destinationModeControl,'existing','기존 열 사용');option(destinationModeControl,'new','새 열 추가');destinationModeControl.value=destinationMode;
  const newHeaderControl=editable(input('새 열 제목',newDestinationHeader),'organizer-new-destination-header');newHeaderControl.maxLength=80;
  const newHeaderField=field('새 열 제목',newHeaderControl),destinationHint=element('p','','ro-hint');
  const destinationChanged=()=>{destinationMode=destinationModeControl.value;newDestinationHeader=newHeaderControl.value;presets.destinationMode=destinationMode;presets.newDestinationHeader=newDestinationHeader;try{localStorage.setItem(STORAGE,JSON.stringify(presets));}catch{}lastMessage='답변 저장 위치가 변경되었습니다. 적용 후 비교 결과를 확인하세요.';update();};
  destinationModeControl.addEventListener('change',destinationChanged);newHeaderControl.addEventListener('input',destinationChanged);newHeaderControl.addEventListener('compositionend',destinationChanged);
  destinationControls.append(field('답변 저장 위치',destinationModeControl),newHeaderField);destinationTop.append(destinationControls,commonRulesButton);destinationCard.append(destinationTop,destinationHint,destinationHost);answersPane.append(destinationCard);
  const answerTools=element('div',null,'ro-answer-tools'),answerSearch=input('작업자 답변 검색');answerSearch.placeholder='원문 또는 저장할 문구 검색';answerSearch.dataset.focusKey='organizer-answer-search';
  answerSearch.addEventListener('input',()=>{answerPage=0;renderAnswerList();});
  const answerExportButton=button('정리 양식 내보내기',()=>exchangeAnswerRules('export')),answerImportButton=button('정리한 양식 불러오기',()=>exchangeAnswerRules('import'));
  const answerExchange=element('div',null,'ro-answer-exchange');answerExchange.setAttribute('role','group');answerExchange.setAttribute('aria-label','답변 정리 엑셀 양식');answerExchange.append(answerExportButton,answerImportButton);
  answerTools.append(answerSearch,answerExchange);answersPane.append(answerTools);
  const answerSummary=element('p','연결된 파일의 답변을 불러오면 표시됩니다.','ro-hint ro-answer-summary');answersPane.append(answerSummary);
  const answerSplit=element('div',null,'ro-answer-split'),answerListPanel=element('section',null,'ro-answer-list-panel'),answerList=element('div',null,'ro-answer-list'),answerDetail=element('section',null,'ro-answer-detail');answerList.dataset.scrollKey='organizer-global-answers';answerDetail.dataset.scrollKey='organizer-answer-detail';
  answerDetail.append(element('p','목록에서 정리할 답변을 선택하세요.','ro-empty'));answerListPanel.append(answerList);
  const answerPages=element('div',null,'ro-preview-pages ro-answer-pages'),answerPageLabel=element('span'),answerPreviousPage=button('이전 원문',()=>{answerPage=Math.max(0,answerPage-1);renderAnswerList();}),answerNextPage=button('다음 원문',()=>{answerPage++;renderAnswerList();});answerPages.append(answerPreviousPage,answerPageLabel,answerNextPage);answerListPanel.append(answerPages);answerSplit.append(answerListPanel,answerDetail);answersPane.append(answerSplit);
  const outputPane=element('section',null,'ro-pane ro-output-pane'),outputTools=element('div',null,'ro-output-tools');
  const folderInput=input('저장 폴더');folderInput.placeholder='저장할 폴더 경로';folderInput.dataset.focusKey='organizer-output-folder';
  folderInput.addEventListener('input',()=>{outputFolder=folderInput.value;update();});folderInput.addEventListener('compositionend',()=>{outputFolder=folderInput.value;update();});
  const chooseOutputButton=button('저장 위치 선택',()=>chooseOutput());outputTools.append(field('저장 폴더',folderInput),chooseOutputButton);
  const outputList=element('div',null,'ro-output-list');outputList.dataset.scrollKey='organizer-output-names';
  const outputIntro=element('div',null,'ro-stage-intro'),outputSummary=element('p','','ro-hint');outputIntro.append(element('h2','저장 위치와 이름을 확인하세요'),outputSummary);outputPane.append(outputIntro,outputTools,element('p','원본에 덮어쓰지 않도록 다른 저장 위치나 이름을 지정하세요.','ro-hint'),outputList);
  for(const [key,pane] of [['sources',sourcePane],['preview',previewPane],['answers',answersPane],['output',outputPane]]){pane.setAttribute('role','tabpanel');pane.id=`organizer-panel-${key}`;pane.setAttribute('aria-labelledby',`organizer-tab-${key}`);panes.set(key,pane);workspace.append(pane);}
  const runCard = element('footer', null, 'ro-action-footer');
  const runbar = element('div', null, 'ro-runbar'), status = element('div', '', 'ro-status'); status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
  const runButton = button('연결된 파일 저장', () => run(), true), refreshPreviewButton=button('비교 새로고침',()=>loadChanges(0)),answersNextButton=button('답변 정리',()=>{selectPane('answers');update();},true),footerOutputButton=button('저장 설정',()=>applyAnswerRules(),true),applyAnswersButton=button('답변 적용 후 비교',()=>applyAnswerRules(false)),sourceNextButton=button('연결 확인',()=>{selectPane('preview');update();},true),backButton=button('이전 단계',()=>{selectPane(activePane==='output'?'answers':activePane==='answers'?'preview':'sources');update();}),cancelButton = button('정리 중단', () => {
    if (!running || !runId) return; post('organize:cancel', { requestId: runId }); cancelButton.disabled = true;
    lastMessage = '현재 파일 처리가 끝나면 중단합니다.'; update();
  });
  backButton.classList.add('ro-btn-quiet');cancelButton.classList.add('ro-btn-remove');
  runButton.dataset.action='save';cancelButton.hidden = true; const footerActions=element('div',null,'ro-footer-actions');footerActions.append(backButton,refreshPreviewButton,sourceNextButton,answersNextButton,applyAnswersButton,footerOutputButton,runButton,cancelButton);runbar.append(status,footerActions);
  const resultHost = element('div', null, 'ro-results'); outputPane.append(resultHost);runCard.append(runbar);page.append(runCard);selectPane('sources');
  const resultDialog=element('dialog',null,'ro-result-dialog'),resultDialogTitle=element('h2','엑셀 정리 결과'),resultDialogBody=element('div',null,'ro-result-dialog-body'),resultDialogActions=element('div',null,'ro-result-dialog-actions');
  resultDialogTitle.id='organizer-result-title';resultDialog.setAttribute('aria-labelledby',resultDialogTitle.id);resultDialogBody.dataset.scrollKey='organizer-save-result';
  const summaryExportButton=button('요약 엑셀 저장',()=>exportSummary(),true),resultCloseButton=button('닫기',()=>resultDialog.close()),resultOpenButton=button('저장 파일 열기',()=>openSavedResult());summaryExportButton.title='저장 당시의 정리 기준과 파일별 처리 결과를 함께 저장합니다.';resultCloseButton.classList.add('ro-btn-quiet');resultDialogActions.append(resultCloseButton,resultOpenButton,summaryExportButton);resultDialog.append(resultDialogTitle,resultDialogBody,resultDialogActions);page.append(resultDialog);
  resultDialog.addEventListener('close',()=>{if(resultDialogReturnFocus?.isConnected)resultDialogReturnFocus.focus({preventScroll:true});});
  const commonDialog=element('dialog',null,'ro-common-dialog'),commonDialogTitle=element('h2','공통 설정'),commonDialogHelp=element('p','연결된 2차 파일의 원본 값을 기준으로 조건을 확인합니다. 조건에 맞는 행에는 원문별 답변 정리보다 우선 반영합니다. 여러 규칙이 맞으면 위 규칙을 사용합니다.','ro-hint');
  commonDialogTitle.id='organizer-common-rules-title';commonDialog.setAttribute('aria-labelledby',commonDialogTitle.id);
  const commonDialogToolbar=element('div',null,'ro-common-dialog-toolbar'),commonHeaderSummary=element('p','','ro-hint'),addCommonRuleButton=button('규칙 추가',()=>addCommonRule());commonDialogToolbar.append(commonHeaderSummary,addCommonRuleButton);
  const commonRulesList=element('div',null,'ro-common-rules-list');commonRulesList.dataset.scrollKey='organizer-common-rules';
  const commonRulesEmpty=element('p','공통으로 적용할 조건과 문구를 추가하세요. 규칙이 없으면 기존 답변 정리 결과를 사용합니다.','ro-empty');
  const commonDialogStatus=element('p','','ro-warning'),commonDialogActions=element('div',null,'ro-common-dialog-actions'),cancelCommonRulesButton=button('취소',()=>commonDialog.close()),applyCommonRulesButton=button('적용 후 비교',applyCommonRules,true);
  cancelCommonRulesButton.classList.add('ro-btn-quiet');addCommonRuleButton.classList.add('ro-settings-button');
  commonDialogStatus.setAttribute('role','status');commonDialogStatus.setAttribute('aria-live','polite');commonDialogActions.append(commonDialogStatus,cancelCommonRulesButton,applyCommonRulesButton);commonDialog.append(commonDialogTitle,commonDialogHelp,commonDialogToolbar,commonRulesList,commonDialogActions);page.append(commonDialog);
  commonDialog.addEventListener('close',()=>{if(commonDialog.open)return;commonRulesDraft=[];commonRulePanels.clear();if(!closed&&commonDialogReturnFocus?.isConnected)commonDialogReturnFocus.focus({preventScroll:true});});

  function selectPane(key){if(key!=='sources'&&sourceHeaderDirty)return;navigationRevision++;activePane=key;for(const [name,pane]of panes)pane.hidden=name!==key;for(const [name,tab]of tabButtons){tab.setAttribute('aria-selected',String(name===key));tab.tabIndex=name===key?0:-1;}if(key==='answers'){answerFailedSignature='';queueAnswerCatalog();}}
  mappingCard.addEventListener('toggle',()=>{if(mappingCard.open)ensureSelectedSettings();});
  function ensureSelectedSettings(){const entry=current.get(selectedToken);if(!entry)return;if(!entry.settingsHost){entry.settingsHost=element('div');entry.settingsHost.dataset.token=entry.p.token;selectionSettings.append(entry.settingsHost);buildMapping(entry);}for(const item of current.values())if(item.settingsHost)item.settingsHost.hidden=item!==entry;}
  function selectMapping(entry,load=true){
    if(!entry)return;selectedToken=entry.p.token;detailTitle.textContent=basename(entry.p.path);detailTitle.title=entry.p.path;
    detailPair.textContent=entry.previousTokens.length?'1차 회신 · '+entry.previousTokens.map(token=>basename(previous.get(token)?.p.path)).join(', '):'연결된 1차 회신이 없습니다.';
    detailStatus.textContent=`${labelFor(entry.feature)} · ${entry.p.sheet}${entry.feature==='connector'?` · 대상 파라미터: ${entry.p.parameterHint||'확인할 수 없음'}`:''}${entry.previousTokens.length?answerColumnSummary(previous.get(entry.previousTokens[0])):''}`;
    for(const item of current.values()){item.node.classList.toggle('is-selected',item===entry);item.node.querySelector('summary')?.setAttribute('aria-pressed',String(item===entry));if(item.settingsHost)item.settingsHost.hidden=item!==entry;}
    if(mappingCard.open)ensureSelectedSettings();if(load)void loadSelectedPreview(0,false);
  }

  function listen(event, handler) { const off = onHost(event, raw => { if (!closed) handler(lowerKeys(raw)); }); if (off) unsubscribers.add(off); return off; }
  function beginProgressWork(message){
    let work=activeProgressWork;
    if(!work){work={owner:ProgressDialog.show('다회차 엑셀 결과 정리',message),depth:0,group:null};activeProgressWork=work;ProgressDialog.setActions({},work.owner);ProgressDialog.updateIndeterminate(message,'',work.owner);}
    work.depth++;return work;
  }
  function endProgressWork(work){
    if(!work)return;work.depth=Math.max(0,work.depth-1);
    if(!work.depth){if(activeProgressWork===work)activeProgressWork=null;ProgressDialog.hide(work.owner);}
  }
  function registerProgressRequest(requestId,event,options={}){
    const work=activeProgressWork;if(!work)return;
    const labels={'organize:inspect':'엑셀 파일을 선택하세요.','organize:suggest':'파일 연결을 확인하는 중입니다.','repeat:detect':'답변 열을 확인하는 중입니다.','repeat:answers':'작업자 답변을 모으는 중입니다.','organize:preview':'반영할 답변을 비교하는 중입니다.','organize:chooseOutput':'저장 위치와 이름을 선택하세요.','organize:run':'엑셀 결과를 저장하는 중입니다.','organize:answerRules':'전체 파일의 같은 답변을 모으는 중입니다.','organize:exportAnswerRules':'답변 정리 양식을 저장하는 중입니다.','organize:importAnswerRules':'답변 정리 양식을 불러오는 중입니다.','organize:exportSummary':'결과 요약 엑셀을 저장하는 중입니다.'};
    const group=options.group||{fractions:new Map()},label=labels[event]||'작업을 처리하는 중입니다.';
    group.fractions ||= new Map();const meta={work,group,event,label,weight:options.weight||1,cancelled:false};progressRequests.set(requestId,meta);
    if(work.group!==group){work.group=group;applyRequestProgress(requestId,{completed:0,total:0,message:label});}
    let cancel;
    if(event==='organize:run')cancel=()=>cancelButton.click();
    else if(event==='organize:preview')cancel=()=>post('organize:cancelPreview',{requestId});
    else if(['organize:inspect','organize:answerRules','organize:exportAnswerRules','organize:importAnswerRules','organize:exportSummary'].includes(event))cancel=()=>post('organize:cancel-imports',{requestIds:[requestId]});
    ProgressDialog.setActions({onCancel:cancel?()=>{if(meta.cancelled||!progressRequests.has(requestId))return;meta.cancelled=true;cancel();ProgressDialog.setActionState({statusText:'작업을 취소하는 중입니다.',cancelDisabled:true},work.owner);}:null,cancelLabel:event==='organize:run'?'정리 중단':'취소'},work.owner);
    ProgressDialog.setActionState({statusText:'',cancelDisabled:false},work.owner);
  }
  function applyRequestProgress(requestId,data){
    const meta=progressRequests.get(requestId);if(!meta||meta.work!==activeProgressWork||meta.work.group!==meta.group)return;
    const total=Number(data.total),completed=Math.max(0,Number(data.completed)||0),message=data.message||meta.label,detail=data.detail||'';
    if(data.elapsedSeconds!==undefined&&Number.isFinite(Number(data.elapsedSeconds))&&Number(data.elapsedSeconds)>=0)meta.elapsedSeconds=Math.floor(Number(data.elapsedSeconds));
    const elapsed=meta.elapsedSeconds===undefined?'':`현재 작업 경과 ${meta.elapsedSeconds>=3600?`${Math.floor(meta.elapsedSeconds/3600)}시간 `:''}${meta.elapsedSeconds>=60?`${Math.floor(meta.elapsedSeconds%3600/60)}분 `:''}${meta.elapsedSeconds%60}초`;
    if(!(total>0)&&!(meta.group.total>0)){ProgressDialog.updateIndeterminate(message,[detail,elapsed].filter(Boolean).join('\n'),meta.work.owner);return;}
    const fraction=total>0?Math.min(1,completed/total):0;
    if(total>0)meta.group.fractions.set(requestId,{weight:meta.weight,fraction:Math.max(meta.group.fractions.get(requestId)?.fraction||0,fraction)});
    const groupedCompleted=meta.group.total?[...meta.group.fractions.values()].reduce((sum,item)=>sum+item.weight*item.fraction,0):completed;
    const percent=meta.group.total?groupedCompleted/meta.group.total*100:fraction*100;
    const count=meta.group.total?`${Math.floor(groupedCompleted).toLocaleString()} / ${meta.group.total.toLocaleString()}개 시트`
      : ['organize:inspect','organize:preview','organize:run'].includes(meta.event)?`${Math.min(completed,total).toLocaleString()} / ${total.toLocaleString()}개 파일`:'';
    ProgressDialog.update(percent,message,[detail,count,elapsed].filter(Boolean).join('\n'),meta.work.owner);
  }
  function finishProgressRequest(requestId,success){
    const meta=progressRequests.get(requestId);if(!meta)return;progressRequests.delete(requestId);
    if(success&&meta.group.total&&meta.work===activeProgressWork&&meta.work.group===meta.group){
      meta.group.fractions.set(requestId,{weight:meta.weight,fraction:1});
      const completed=[...meta.group.fractions.values()].reduce((sum,item)=>sum+item.weight*item.fraction,0);
      ProgressDialog.update(completed/meta.group.total*100,meta.label,`${Math.floor(completed).toLocaleString()} / ${meta.group.total.toLocaleString()}개 시트`,meta.work.owner);
    }
    if(meta.work===activeProgressWork&&meta.work.group===meta.group){const remaining=[...progressRequests.entries()].find(([,item])=>item.work===meta.work&&item.group===meta.group);if(remaining)refreshRequestWaitState(remaining[0]);else ProgressDialog.setActions({},meta.work.owner);}
  }
  function refreshRequestWaitState(requestId){
    const meta=progressRequests.get(requestId);if(!meta||meta.work!==activeProgressWork||meta.work.group!==meta.group)return;
    const group=[...progressRequests.values()].filter(item=>item.work===meta.work&&item.group===meta.group),cancelled=group.some(item=>item.cancelled),delayed=group.some(item=>item.delayed);
    ProgressDialog.setActionState({statusText:cancelled?'작업을 취소하는 중입니다.':delayed?'처리 상태 확인이 지연되고 있습니다. 결과가 도착하면 자동으로 반영됩니다.':'',cancelDisabled:cancelled},meta.work.owner);
  }
  function request(event, response, payload, progressOptions={}) {
    return new Promise((resolve, reject) => {
      const requestId = payload.requestId || uniqueId();
      let timer;
      const off = listen(response, data => {
        if (data.requestId !== requestId) return;
        clearTimeout(timer); off?.(); unsubscribers.delete(off); requests.delete(requestId);
        finishProgressRequest(requestId,!data.error&&!data.cancelled);
        data.error ? reject(Error(data.error)) : resolve(data);
      });
      const renew=()=>{clearTimeout(timer);const meta=progressRequests.get(requestId);if(meta){meta.delayed=false;refreshRequestWaitState(requestId);}timer=setTimeout(()=>{const waiting=progressRequests.get(requestId);if(!requests.has(requestId)||!waiting)return;waiting.delayed=true;refreshRequestWaitState(requestId);},300000);const entry=requests.get(requestId);if(entry)entry.timer=timer;};
      requests.set(requestId, { timer, reject,renew });renew();registerProgressRequest(requestId,event,progressOptions);
      // Keep completed IDs too: the host may still own snapshots from a late response.
      if (['organize:inspect','organize:answerRules','organize:exportAnswerRules','organize:importAnswerRules','organize:exportSummary'].includes(event)) importRequestIds.add(requestId);
      post(event, { ...payload, requestId,...(event==='repeat:detect'||event==='repeat:answers'?{progressScope:'organizer'}:{}) });
    });
  }
  function savePreset(entry) {
    presets.layouts ||= {};
    presets.layouts[entry.p.layout] = { answerColumns: [...entry.choice.answerColumns], decisionColumn: entry.choice.decisionColumn, keywordColumns: [...entry.choice.keywordColumns] };
    presets.exclusionKeywords = [...exclusionKeywords];
    presets.keywordMatchMode = keywordMatchMode;
    try { localStorage.setItem(STORAGE, JSON.stringify(presets)); } catch { /* The current mapping remains usable without storage. */ }
  }
  function invalidateReplies(entry) {
    entry.replyGeneration = (entry.replyGeneration || 0) + 1;
    invalidateReplyPreview(entry.replyHost); invalidateReplyPreview(sourceUi.previous?.replyHost);
  }
  function invalidateReplyPreview(host) {
    if (!host || host.dataset.previewStale === 'true') return;
    const height = host.getBoundingClientRect().height;
    if (!height && !host.childElementCount) return;
    // Keep the occupied space while removing obsolete approval controls above another editor.
    if (height > 0) host.style.minHeight = `${height}px`;
    host.dataset.previewStale = 'true';
    host.replaceChildren(element('p', '설정이 변경되었습니다. 미리보기를 다시 실행하세요.', 'ro-hint'));
  }
  function cloneOriginalHeaders(value,columns){
    const indices=new Set((columns||[]).map(column=>column.index));
    return Object.fromEntries(Object.entries(value||{}).filter(([index,header])=>/^\d+$/.test(index)&&indices.has(Number(index))&&typeof header==='string'&&header.trim()).map(([index,header])=>[Number(index),header]));
  }
  function makeChoice(p) {
    const columns = p.columns || [];
    const decisionColumn = columns.find(c => c.header === '검토 판정')?.index ?? -1;
    const answerColumns = autoAnswerColumns(p).filter(i => i !== decisionColumn);
    return { token: p.token, model: p.modelHint || '', answerColumns, decisionColumn, exceptionRows: [],
      answerColumnsManual: false, sourceAnswerHeader:'', checkOverwrittenNarratives: p.detection?.checkOverwrittenNarratives === true,
      originalHeaders:cloneOriginalHeaders(p.detection?.originalHeaders,columns),
      exclusionKeywords: [...exclusionKeywords], keywordColumns: [...answerColumns], keywordMatchMode };
  }
  function refreshSourceHeaderControl(fromUpdate=false){
    const dirty=sourceHeaderInput.value.trim()!==sourceAnswerHeader;
    const wasDirty=sourceHeaderDirty;sourceHeaderDirty=dirty;
    sourceHeaderApply.disabled=running||!!pending||sourceHeaderComposing;
    sourceHeaderState.textContent=dirty?'변경한 열 이름을 적용하세요.':sourceAnswerHeader?`적용된 열: ${sourceAnswerHeader}`:'자동으로 답변 열을 찾습니다.';
    sourceHeaderState.classList.toggle('ro-warning',dirty);
    for(const [key,tab]of tabButtons)tab.disabled=key!=='sources'&&dirty;
    if(dirty){status.textContent='계승할 열 이름이 변경되었습니다. 적용한 뒤 다음 단계로 이동하세요.';for(const control of [sourceNextButton,answersNextButton,runButton,chooseOutputButton,refreshPreviewButton,footerOutputButton,applyAnswersButton,answerExportButton,answerImportButton])control.disabled=true;}
    else if(wasDirty&&fromUpdate!==true)update();
  }
  function applySourceHeaderToEntry(entry){
    const choice=entry.choice;
    if(sourceAnswerHeader){
      entry.sourceHeaderBaseline ||= {answerColumns:[...choice.answerColumns],answerColumnsManual:entry.answerColumnsManual,checkOverwrittenNarratives:choice.checkOverwrittenNarratives,
        originalHeaders:{...choice.originalHeaders},exceptionRows:[...choice.exceptionRows],keywordColumns:[...choice.keywordColumns],detection:entry.p.detection};
      choice.sourceAnswerHeader=sourceAnswerHeader;choice.answerColumns=[];entry.answerColumnsManual=choice.answerColumnsManual=false;
      choice.checkOverwrittenNarratives=false;choice.originalHeaders={};choice.exceptionRows=[];
      if(entry.keywordColumnsLinked)choice.keywordColumns=[];
      entry.p.detection={answerColumns:[],candidateColumns:[],needsReview:false,reason:'지정한 열을 다음 답변 확인에서 찾습니다.'};
    }else{
      choice.sourceAnswerHeader='';const saved=entry.sourceHeaderBaseline;
      if(saved){choice.answerColumns=[...saved.answerColumns];entry.answerColumnsManual=choice.answerColumnsManual=!!saved.answerColumnsManual;choice.checkOverwrittenNarratives=saved.checkOverwrittenNarratives;
        choice.originalHeaders={...saved.originalHeaders};choice.exceptionRows=[...saved.exceptionRows];if(entry.keywordColumnsLinked)choice.keywordColumns=[...saved.keywordColumns];entry.p.detection=saved.detection;delete entry.sourceHeaderBaseline;}
    }
    entry.detectionGeneration++;entry.detectionSignature='';invalidateReplies(entry);entry.syncColumns?.();entry.syncKeywordColumns?.();
    entry.refreshDetection?.();if(entry.detectionBadge)entry.detectionBadge.textContent=answerColumnSummary(entry);
  }
  async function applySourceAnswerHeader(){
    if(closed||running||pending||sourceHeaderComposing)return;
    sourceAnswerHeader=sourceHeaderInput.value.trim();presets.sourceAnswerHeader=sourceAnswerHeader;
    try{localStorage.setItem(STORAGE,JSON.stringify(presets));}catch{}
    for(const entry of previous.values())applySourceHeaderToEntry(entry);
    answerCatalogGeneration++;answerCatalogSignature='';answerFailedSignature='';previewSignature='';detailGeneration++;detailPreviewCache.clear();
    lastMessage=sourceAnswerHeader?'계승할 열을 적용했습니다. 파일별 답변 열을 확인합니다.':'자동 찾기로 변경했습니다. 이전에 직접 선택한 답변 열은 복원했습니다.';update();
    if(current.size){await detectMappings([...current.values()]);if(!closed){lastMessage=sourceAnswerHeader?'계승할 열을 확인했습니다. 열이 없는 파일은 자동 찾기 결과를 사용합니다.':'이전 답변 열 선택과 자동 찾기를 적용했습니다.';update();}}
  }
  function hasBlockedSourceHeader(){
    return [...current.values()].filter(savableMapping).some(entry=>entry.previousTokens.some(token=>sourceHeaderBlocked(previous.get(token))));
  }
  function destinationHeader(feature) { return destinationMode==='new'?newDestinationHeader:(presets.destinationHeaders[feature] ?? '비고'); }
  function refreshDestinations() {
    const features = new Set([...current.values()].filter(e => !e.p.copyOnly).map(e => e.feature));
    destinationHost.hidden = !features.size||destinationMode==='new';
    newHeaderField.hidden=destinationMode!=='new';
    destinationHint.textContent=destinationMode==='new'?'답변을 반영할 시트의 마지막에 새 열을 추가합니다. 원본 유지 시트는 변경하지 않습니다.':'기본 저장 열은 비고입니다. 아래에서 기능별로 열 제목을 선택하거나 입력할 수 있습니다.';
    for (const feature of features) {
      if (destinationFields.has(feature)) continue;
      const value = editable(input(`${labelFor(feature)} 이전 답변을 넣을 열`, presets.destinationHeaders[feature] ?? '비고'), `organizer-destination-${feature}`); value.maxLength = 80;
      const list = element('datalist'); list.id = `organizer-destination-list-${feature}`;
      const names=new Set(['비고','작업자 답변','이전 코멘트',...[...current.values()].filter(entry=>entry.feature===feature).flatMap(entry=>(entry.p.columns||[]).map(column=>column.header).filter(Boolean))]);
      for (const name of names) { const item = element('option'); item.value = name; list.append(item); }
      value.setAttribute('list', list.id);
      const changed = () => { presets.destinationHeaders[feature] = value.value; try { localStorage.setItem(STORAGE, JSON.stringify(presets)); } catch {} lastMessage = ''; update(); };
      value.addEventListener('input', changed); value.addEventListener('compositionend', changed);
      const label = field(`${labelFor(feature)} · 이전 답변을 넣을 열`, value); label.append(list); destinationHost.append(label); destinationFields.set(feature, label);
    }
    for (const [feature, field] of destinationFields) field.hidden = !features.has(feature);
  }
  function update() {
    if (closed) return;
    refreshDestinations();
    const conflicts = mappingConflicts();
    let linked = 0, preserved = 0, skipped = 0;
    for (const entry of current.values()) {
      if (entry.skip) skipped++;
      else if (savableMapping(entry)) linked++;
      else preserved++;
      const disposition = entry.skip||entry.noPrevious&&!entry.p.copyOnly ? '원본 유지' : savableMapping(entry) ? '연결됨' : entry.p.copyOnly ? '확인 필요 · 원본 유지' : entry.conflict||entry.previousTokens.length||(entry.candidateTokens||[]).length||!entry.suggestionChecked ? '연결 확인 필요 · 원본 유지' : '미연결 · 원본 유지';
      entry.badge.textContent=disposition;entry.node.dataset.state=savableMapping(entry)?'matched':'excluded';entry.node.classList.toggle('is-selected',entry.p.token===selectedToken);
      if(entry.peer)entry.peer.textContent=savableMapping(entry)?entry.previousTokens.map(token=>basename(previous.get(token)?.p.path)).join(', '):entry.reason||'연결할 1차 회신을 확인하세요.';
      entry.badge.classList.toggle('ro-warning', !savableMapping(entry));
    }
    const registration=buildRegistration(),unlinkedPrevious=new Set(registration.unlinkedPreviousTokens);
    for (const kind of ['previous', 'current']) {
      const entries = kind === 'previous' ? previous : current;
      if (sourceUi[kind]) {
        const ui=sourceUi[kind],warningCount=ui.importWarnings.size;
        const fileCount=new Set([...entries.values()].map(e=>normalizeHint(e.p.path))).size,selectedCount=ui.selectedPaths.size;
        const missing=kind==='previous'?new Set([...entries.values()].filter(entry=>unlinkedPrevious.has(entry.p.token)).map(entry=>normalizeHint(entry.p.path))).size:0;
        ui.count.textContent = `${fileCount}개 파일${selectedCount?` · ${selectedCount}개 선택`:''}${missing?` · 미연결 ${missing}개`:''}${warningCount?` · 확인 ${warningCount}개`:''}`;
        ui.count.classList.toggle('ro-warning',!!warningCount);ui.warning.hidden=!warningCount;
        ui.warning.textContent=[...ui.importWarnings.values()].join('\n');ui.count.title=ui.warning.textContent;
        ui.selectAll.textContent=fileCount&&selectedCount===fileCount?'선택 해제':'전체 선택';
        ui.selectAll.setAttribute('aria-label',`${ui.title} ${ui.selectAll.textContent}`);
        ui.selectAll.disabled=running||!!pending||!fileCount;ui.removeSelected.disabled=running||!!pending||!selectedCount;ui.clearList.disabled=running||!!pending||(!fileCount&&!warningCount);
        for(const entry of entries.values()){if(entry.selectionControl)entry.selectionControl.disabled=running||!!pending;if(entry.unlinkedLabel)entry.unlinkedLabel.hidden=!unlinkedPrevious.has(entry.p.token);}
      }
    }
    const outputFiles=new Set([...current.values()].map(entry=>normalizeHint(entry.p.path))),allFiles=outputFiles,linkedFiles=new Set([...current.values()].filter(savableMapping).map(entry=>normalizeHint(entry.p.path))),preservedFiles=allFiles.size-linkedFiles.size;
    // Remove ineligible names immediately without replacing a filename currently being edited.
    for(const [key,control]of outputNameControls)if(!outputFiles.has(key)){control.row.remove();outputNameControls.delete(key);outputNames.delete(key);}
    mappingCount.textContent = `저장 대상 ${outputFiles.size} / ${allFiles.size}개`;
    outputSummary.textContent=`2차 전체 ${allFiles.size}개 = 답변 반영 대상 ${linkedFiles.size}개 + 원본 유지 ${preservedFiles}개`;
    const usedPrevious = new Set([...current.values()].filter(savableMapping).flatMap(entry => entry.previousTokens));
    const invalidColumns = [...usedPrevious].some(token => { const choice = previous.get(token).choice; return choice.answerColumns.includes(choice.decisionColumn); });
    const invalidDestination = [...current.values()].some(entry => savableMapping(entry) && !destinationHeader(entry.feature).trim());
    const invalidSourceHeader=hasBlockedSourceHeader();
    const blocked = invalidSourceHeader?'계승할 열을 확인하세요. 중복된 제목은 파일별 답변 열을 직접 선택해야 합니다.':invalidColumns ? '답변 열과 판정 열은 서로 다르게 선택하세요.' : !current.size ? '2차 결과 파일을 선택하세요.' : '';
    const replyNeeds = [...usedPrevious].filter(token => { const entry = previous.get(token); return !entry.answerColumnsManual && entry.p.detection?.needsReview; }).length;
    status.textContent = invalidDestination ? '이전 답변을 넣을 열 제목을 입력하세요.' : invalidColumns||invalidSourceHeader ? blocked : lastMessage || errors[0] || blocked || `2차 전체 ${outputFiles.size}개 파일을 저장합니다.${replyNeeds ? ` 답변 열 확인 ${replyNeeds}개` : ''}`;
    const signature=JSON.stringify(buildMappings()),previewReady=previewSignature===signature&&!!previewData,staleCommonRules=commonRulesStale();
    const canProcess=!!current.size&&!invalidColumns&&!invalidDestination&&!invalidSourceHeader;
    const catalogReady=answerCatalogLoaded&&answerCatalogSignature===answerMappingSignature();
    const staleEditedCatalog=answerEdits.size>0&&!catalogReady;
    const readyNames=outputNames.size===outputFiles.size&&[...outputNames.values()].every(item=>!!item.fileName.trim());
    runButton.disabled = running || !!pending || !canProcess || !previewReady || staleEditedCatalog || staleCommonRules || !!previewData?.errors?.length || !readyNames;
    refreshPreviewButton.disabled=running||!!pending||!canProcess||staleCommonRules;
    refreshPreviewButton.textContent=previewData?'비교 새로고침':'전체 답변 비교';
    const detailCompare=previewScroll.querySelector('[data-action="compare-selected"]');if(detailCompare)detailCompare.disabled=running||!!pending||staleCommonRules;
    chooseOutputButton.disabled=running||!!pending||!canProcess||!previewReady||staleEditedCatalog||staleCommonRules||!!previewData?.errors?.length;
    answersNextButton.disabled=running||!!pending||!canProcess;
    footerOutputButton.disabled=applyAnswersButton.disabled=running||!!pending||!canProcess||!catalogReady||staleCommonRules;
    answerExportButton.disabled=answerImportButton.disabled=running||!!pending||!canProcess||!linked;
    commonRulesButton.disabled=running||!!pending||(!linked&&!commonRules.length);
    commonRulesButton.textContent=`공통 설정${commonRules.length?` · ${commonRules.length}개`:''}${staleCommonRules?' · 확인 필요':''}`;
    sourceNextButton.disabled=running||!!pending||!current.size;backButton.disabled=running;
    sourceNextButton.hidden=activePane!=='sources';backButton.hidden=activePane==='sources'||running;refreshPreviewButton.hidden=(activePane!=='preview'&&!(activePane==='output'&&(!previewReady||staleEditedCatalog)))||running;answersNextButton.hidden=activePane!=='preview'||running;applyAnswersButton.hidden=footerOutputButton.hidden=activePane!=='answers'||running;runButton.hidden=activePane!=='output'||running;
    runButton.textContent=`2차 전체 ${outputFiles.size}개 파일 저장`;
    folderInput.disabled=running;for(const control of outputNameControls.values())control.control.disabled=running;
    if(previewData&&!previewReady&&!previewRequestId)previewNotice.textContent='설정이 변경되었습니다. 미리보기를 새로 확인하세요.';
    previewScroll.classList.toggle('is-stale',!!previewData&&!previewReady);
    if(previewReady&&!lastMessage&&!errors.length&&!invalidColumns&&!invalidDestination)status.textContent=`2차 전체 ${outputFiles.size}개 저장 · 답변 반영 대상 ${linkedFiles.size}개 · 원본 유지 ${preservedFiles}개`;
    if(staleEditedCatalog&&!pending&&!running)status.textContent='연결 설정이 변경되었습니다. 비교 새로고침으로 답변 정리를 다시 반영하세요.';
    if(staleCommonRules&&!pending&&!running)status.textContent='파일 또는 연결이 변경되었습니다. 답변 정리의 공통 설정을 다시 확인하세요.';
    suggestButton.disabled = running || !!pending || !current.size || !activePreviousEntries().length;
    for (const node of importButtons) node.disabled = running || !!pending;
    for (const node of page.querySelectorAll('[data-organizer-edit]')) node.disabled = running || node.dataset.organizerLocked === 'true';
    refreshSourceHeaderControl(true);
    cancelButton.hidden = !running;
    mappingEmpty.hidden = !!current.size; filterMappings();
    if(activePane==='answers'&&!catalogReady)queueAnswerCatalog();
    if(commonDialog.open)syncCommonDialog();
    if (resuggestRequested && !pending && !running && !suggestQueued) {
      suggestQueued = true;
      queueMicrotask(() => { suggestQueued = false; if (closed) return; resuggestRequested = false; if (current.size && activePreviousEntries().length) void suggest(); });
    }
  }
  function commonDatasetSignature(){
    return JSON.stringify({previous:[...previous.values()].map(entry=>[entry.p.token,entry.candidate!==false]),current:[...current.values()].map(entry=>[entry.p.token,entry.model,entry.feature,entry.skip,entry.noPrevious,entry.confirmed,[...entry.previousTokens]])});
  }
  function commonRulesStale(){return commonRules.length>0&&commonRulesDataset!==commonDatasetSignature();}
  function availableCommonHeaders(){
    const entries=[...current.values()].filter(savableMapping);let intersection=null;commonHeaderCoverage.clear();commonHeaderSheetCount=entries.length;
    for(const entry of entries){
      const names=new Map(),duplicates=new Set();
      const headers=Array.isArray(entry.p.commonHeaders)?entry.p.commonHeaders:(entry.p.columns||[]).map(column=>column.header);
      const virtuals=new Set();
      for(const header of headers){const label=String(header??'').trim(),key=normalizeCommonHeader(label);if(!key||/^__KKYReview_/i.test(label))continue;if(COMMON_ELEMENT_HEADERS[key]){virtuals.add(key);continue;}if(names.has(key))duplicates.add(key);else names.set(key,label);}
      for(const key of virtuals)commonHeaderCoverage.set(key,(commonHeaderCoverage.get(key)||0)+1);
      for(const key of duplicates)names.delete(key);
      if(intersection===null)intersection=names;else for(const key of intersection.keys())if(!names.has(key))intersection.delete(key);
    }
    return [...Object.keys(COMMON_ELEMENT_HEADERS).filter(key=>commonHeaderCoverage.has(key)),...(intersection?.values()||[])];
  }
  function cloneCommonRule(rule){
    return {id:rule.id||uniqueId(),matchMode:rule.matchMode==='or'?'or':'and',conditions:(rule.conditions||[]).map(condition=>({header:String(condition.header??''),operator:condition.operator||'equals',value:String(condition.value??'')})),replacementAnswer:String(rule.replacementAnswer??''),clearAnswer:!!rule.clearAnswer,excludeFromQuantity:rule.excludeFromQuantity===true?true:rule.excludeFromQuantity===false?false:null};
  }
  function openCommonRules(){
    if(closed||running||pending)return;
    commonDialogReturnFocus=document.activeElement;commonDialogDataset=commonDatasetSignature();commonDialogHeaders=availableCommonHeaders();commonRulesDraft=commonRules.map(cloneCommonRule);commonRulePanels.clear();commonRulesList.replaceChildren(commonRulesEmpty);
    commonHeaderSummary.textContent=commonHeaderCoverage.size?`기본 필터 ${commonHeaderCoverage.size}개 · 공통 열 ${commonDialogHeaders.length-commonHeaderCoverage.size}개. 기본 필터의 정보가 없는 파일에서는 해당 조건을 적용하지 않습니다. 1·2/A·B 값은 같은 객체의 조건끼리 확인합니다.`:`공통 헤더 ${commonDialogHeaders.length}개 · 연결된 2차 파일의 공통 열만 선택할 수 있습니다.`;
    for(const rule of commonRulesDraft)appendCommonRule(rule);
    syncCommonDialog();commonDialog.showModal();(commonRulesDraft.length?cancelCommonRulesButton:addCommonRuleButton).focus({preventScroll:true});
  }
  function addCommonRule(){
    if(!commonDialogHeaders.length)return;
    const rule=cloneCommonRule({conditions:[{header:'',operator:'equals',value:''}]});commonRulesDraft.push(rule);const ui=appendCommonRule(rule);syncCommonDialog();commonRulesList.scrollTop+=ui.node.getBoundingClientRect().top-commonRulesList.getBoundingClientRect().top;ui.conditions[0]?.header.focus({preventScroll:true});
  }
  function appendCommonRule(rule){
    const node=element('section',null,'ro-common-rule');node.dataset.ruleId=rule.id;
    const heading=element('div',null,'ro-common-rule-heading'),title=element('h3'),moveUp=button('위로',()=>moveCommonRule(rule,-1)),moveDown=button('아래로',()=>moveCommonRule(rule,1)),remove=button('규칙 삭제',()=>{commonRulesDraft=commonRulesDraft.filter(item=>item!==rule);commonRulePanels.delete(rule.id);node.remove();syncCommonDialog();addCommonRuleButton.focus({preventScroll:true});});
    const reorder=element('div',null,'ro-rule-order');reorder.setAttribute('role','group');reorder.setAttribute('aria-label','규칙 순서');
    moveUp.textContent='↑';moveUp.setAttribute('aria-label','위로');moveUp.title='규칙 위로 이동';moveDown.textContent='↓';moveDown.setAttribute('aria-label','아래로');moveDown.title='규칙 아래로 이동';
    moveUp.classList.add('ro-icon-button');moveDown.classList.add('ro-icon-button');remove.classList.add('ro-btn-quiet','ro-btn-remove');reorder.append(moveUp,moveDown);heading.append(title,reorder,remove);
    const mode=element('select');mode.setAttribute('aria-label','조건 결합');option(mode,'and','모두 일치 (AND)');option(mode,'or','하나라도 일치 (OR)');mode.value=rule.matchMode;mode.addEventListener('change',()=>{rule.matchMode=mode.value;syncCommonDialog();});
    const conditionsHost=element('div',null,'ro-common-conditions'),conditions=[];
    const addCondition=button('조건 추가',()=>{const condition={header:'',operator:'equals',value:''};rule.conditions.push(condition);const row=appendCommonCondition(rule,condition,ui);syncCommonDialog();row.header.focus({preventScroll:true});});
    const replacement=element('textarea');replacement.rows=2;replacement.maxLength=32767;replacement.setAttribute('aria-label','공통 저장 문구');replacement.dataset.focusKey=`organizer-common-${rule.id}-replacement`;replacement.value=rule.replacementAnswer;replacement.placeholder='조건에 맞는 행에 저장할 문구를 입력하세요.';replacement.addEventListener('input',()=>{rule.replacementAnswer=replacement.value;syncCommonDialog();});replacement.addEventListener('compositionend',()=>{rule.replacementAnswer=replacement.value;syncCommonDialog();});
    const clear=checkbox('빈칸으로 바꾸기',rule.clearAnswer,checked=>{rule.clearAnswer=checked;replacement.disabled=checked;syncCommonDialog();});replacement.disabled=rule.clearAnswer;
    const quantity=element('select');quantity.setAttribute('aria-label','공통 오류 수량 처리');option(quantity,'','기존 기준');option(quantity,'include','포함');option(quantity,'exclude','제외');quantity.value=rule.excludeFromQuantity===true?'exclude':rule.excludeFromQuantity===false?'include':'';quantity.addEventListener('change',()=>{rule.excludeFromQuantity=quantity.value==='exclude'?true:quantity.value==='include'?false:null;syncCommonDialog();});
    const actions=element('div',null,'ro-common-rule-options');actions.append(clear.wrapper,field('오류 수량 처리',quantity));
    node.append(heading,field('조건 결합',mode),conditionsHost,addCondition,field('저장할 문구',replacement),actions);commonRulesList.append(node);
    const ui={node,title,moveUp,moveDown,mode,conditionsHost,conditions,replacement,quantity,clear:clear.node};commonRulePanels.set(rule.id,ui);
    for(const condition of rule.conditions)appendCommonCondition(rule,condition,ui);
    return ui;
  }
  function appendCommonCondition(rule,condition,ui){
    const node=element('div',null,'ro-common-condition'),header=element('select'),operator=element('select'),value=input('비교할 값',condition.value);
    header.setAttribute('aria-label','조건 열');operator.setAttribute('aria-label','비교 방식');value.maxLength=32767;
    option(header,'','필터 항목 선택');for(const name of commonDialogHeaders){const count=commonHeaderCoverage.get(name);option(header,name,commonHeaderLabel(name)+(count&&count<commonHeaderSheetCount?` (${count}/${commonHeaderSheetCount}개 시트)`:''));}
    const currentLabel=commonDialogHeaders.find(label=>normalizeCommonHeader(label)===normalizeCommonHeader(condition.header));
    if(currentLabel){condition.header=currentLabel;header.value=currentLabel;}else if(condition.header){option(header,condition.header,`${commonHeaderLabel(condition.header)} (현재 사용 불가)`);header.value=condition.header;}
    for(const [key,label]of COMMON_OPERATORS)option(operator,key,label);operator.value=condition.operator;
    const valueField=field('비교할 값',value),syncValue=()=>{const blank=['blank','notBlank'].includes(condition.operator);value.disabled=blank;valueField.classList.toggle('is-unused',blank);value.placeholder=blank?'값 입력 없음':'텍스트 입력 · 대소문자 구분 없음';};
    header.addEventListener('change',()=>{condition.header=header.value;syncCommonDialog();});operator.addEventListener('change',()=>{condition.operator=operator.value;syncValue();syncCommonDialog();});value.addEventListener('input',()=>{condition.value=value.value;syncCommonDialog();});value.addEventListener('compositionend',()=>{condition.value=value.value;syncCommonDialog();});
    const remove=button('조건 삭제',()=>{rule.conditions=rule.conditions.filter(item=>item!==condition);ui.conditions=ui.conditions.filter(item=>item.node!==node);node.remove();syncCommonDialog();ui.mode.focus({preventScroll:true});});
    remove.classList.add('ro-btn-quiet','ro-btn-remove');
    node.append(field('열',header),field('비교 방식',operator),valueField,remove);ui.conditionsHost.append(node);const row={node,header,operator,value};ui.conditions.push(row);syncValue();return row;
  }
  function moveCommonRule(rule,direction){
    const index=commonRulesDraft.indexOf(rule),next=index+direction;if(next<0||next>=commonRulesDraft.length)return;
    const scroll=commonRulesList.scrollTop,focus=document.activeElement,other=commonRulesDraft[next],node=commonRulePanels.get(rule.id).node,otherNode=commonRulePanels.get(other.id).node;
    commonRulesDraft[index]=other;commonRulesDraft[next]=rule;
    if(direction<0)commonRulesList.insertBefore(node,otherNode);else commonRulesList.insertBefore(otherNode,node);
    syncCommonDialog();const moved=commonRulePanels.get(rule.id),nextFocus=focus?.disabled?(direction<0?moved.moveDown:moved.moveUp):focus;nextFocus?.focus({preventScroll:true});commonRulesList.scrollTop=scroll;
  }
  function validateCommonDraft(){
    if(commonDialogDataset!==commonDatasetSignature())return '파일 또는 연결이 변경되었습니다. 창을 닫고 공통 설정을 다시 열어 주세요.';
    const headers=new Set(commonDialogHeaders.map(normalizeCommonHeader));
    for(const [index,rule]of commonRulesDraft.entries()){
      if(!rule.conditions.length)return `규칙 ${index+1}: 조건을 하나 이상 추가하세요.`;
      for(const condition of rule.conditions){if(!headers.has(normalizeCommonHeader(condition.header)))return `규칙 ${index+1}: 현재 파일에 공통으로 있는 열을 선택하세요.`;if(!COMMON_OPERATORS.some(([key])=>key===condition.operator))return `규칙 ${index+1}: 비교 방식을 선택하세요.`;if(!['blank','notBlank'].includes(condition.operator)&&!String(condition.value).trim())return `규칙 ${index+1}: 비교할 값을 입력하세요. 빈칸을 찾으려면 비교 방식에서 빈칸을 선택하세요.`;}
      if(!rule.clearAnswer&&!rule.replacementAnswer.trim())return `규칙 ${index+1}: 저장할 문구를 입력하거나 빈칸으로 바꾸기를 선택하세요.`;
    }
    return '';
  }
  function syncCommonDialog(){
    commonRulesEmpty.hidden=!!commonRulesDraft.length;addCommonRuleButton.disabled=!commonDialogHeaders.length;
    for(const [index,rule]of commonRulesDraft.entries()){const ui=commonRulePanels.get(rule.id);if(!ui)continue;ui.title.textContent=`규칙 ${index+1}`;ui.moveUp.disabled=index===0;ui.moveDown.disabled=index===commonRulesDraft.length-1;}
    const error=validateCommonDraft();commonDialogStatus.textContent=error||(!commonDialogHeaders.length?'사용할 기본 필터나 공통 열이 없습니다. 파일의 출력 항목을 확인하세요.':'');applyCommonRulesButton.disabled=!!error;
  }
  async function applyCommonRules(){
    if(closed||running||pending)return;syncCommonDialog();if(applyCommonRulesButton.disabled)return;
    commonRules=commonRulesDraft.map(cloneCommonRule);commonRulesDataset=commonDialogDataset;commonDialog.close();previewSignature='';lastMessage=commonRules.length?`${commonRules.length}개 공통 규칙을 적용합니다.`:'공통 규칙을 해제했습니다.';update();await loadChanges(0);
  }
  function activePreviousEntries() { return [...previous.values()].filter(entry => entry.candidate !== false); }
  function buildRegistration(){
    const candidates=new Set([...current.values()].flatMap(entry=>[...entry.previousTokens,...(entry.candidateTokens||[])]));
    const possiblePaths=new Set([...candidates].map(token=>normalizeHint(previous.get(token)?.p.path)).filter(Boolean));
    const canClassify=!current.size||[...current.values()].every(entry=>entry.suggestionChecked||entry.manual||entry.p.copyOnly);
    const unlinkedCurrentTokens=[...current.values()].filter(entry=>entry.suggestionChecked&&!entry.skip&&!entry.noPrevious&&!entry.p.copyOnly&&!entry.previousTokens.length&&!(entry.candidateTokens||[]).length).map(entry=>entry.p.token);
    return {previousTokens:[...previous.keys()],currentTokens:[...current.keys()],unlinkedPreviousTokens:canClassify?activePreviousEntries().filter(entry=>!possiblePaths.has(normalizeHint(entry.p.path))).map(entry=>entry.p.token):[],unlinkedCurrentTokens,excludedCurrentTokens:[...current.values()].filter(entry=>!savableMapping(entry)&&!unlinkedCurrentTokens.includes(entry.p.token)).map(entry=>entry.p.token)};
  }
  function savableMapping(entry){return !entry.skip&&!entry.conflict&&validMapping(entry);}
  function validMapping(entry) {
    return !entry.p.copyOnly && !entry.noPrevious && entry.confirmed && !!entry.model.trim() && !!entry.feature && entry.previousTokens.length > 0
      && entry.previousTokens.every(token => previous.has(token) && previous.get(token).candidate !== false);
  }
  function mappingConflicts() {
    const usage = new Map(), conflicts = new Set();
    for (const entry of current.values()) {
      entry.conflict = false;
      if (entry.skip || !validMapping(entry)) continue;
      for (const token of entry.previousTokens) {
        const path = normalizeHint(previous.get(token).p.path), currentPath = normalizeHint(entry.p.path);
        if (!usage.has(path)) usage.set(path, new Map());
        if (!usage.get(path).has(currentPath)) usage.get(path).set(currentPath, new Set());
        usage.get(path).get(currentPath).add(entry);
      }
    }
    for (const files of usage.values()) if (files.size > 1) for (const entries of files.values()) for (const entry of entries) { entry.conflict = true; conflicts.add(entry.p.token); }
    return conflicts;
  }
  function filterMappings() {
    const search = mappingSearch.value.trim().toLowerCase();
    for (const entry of current.values()) {
      if (entry.node.contains(document.activeElement)||entry.settingsHost?.contains(document.activeElement)) continue;
      entry.node.hidden = (!!search && !`${entry.p.path} ${entry.p.sheet} ${entry.model} ${labelFor(entry.feature)} ${entry.p.parameterHint || ''}`.toLowerCase().includes(search))
        || (onlyUnresolved.node.checked && (entry.skip || (validMapping(entry) && !entry.conflict)));
    }
  }
  function changed(entry) {
    entry.manual = true; entry.confirmed = false;
    lastMessage = ''; entry.refresh?.(); update();
  }
  function sheetHeading(p) { return `${basename(p.path)} / ${p.sheet} · ${Number(p.rowCount || 0).toLocaleString()}행`; }
  function lazyPanel(details, builder) {
    let built = false;
    details.addEventListener('toggle', () => { if (details.open && !built) { built = true; builder(); } });
  }
  function editable(node, key) { node.dataset.organizerEdit = 'true'; if (key) node.dataset.focusKey = key; return node; }

  function sourceCard(kind, title, description) {
    const section = element('section', null, 'ro-card'); section.dataset.source = kind;
    const count = element('span', '', 'ro-mapping-count'), tools = element('div', null, 'ro-tools ro-source-toolbar');
    const addActions=element('div',null,'ro-source-add-actions'),listActions=element('div',null,'ro-source-list-actions');
    addActions.setAttribute('role','group');addActions.setAttribute('aria-label',`${title} 추가`);listActions.setAttribute('role','group');listActions.setAttribute('aria-label',`${title} 목록 관리`);tools.append(addActions,listActions);
    const heading=element('div',null,'ro-source-heading');heading.append(element('h2',title),count);section.append(heading);
    for (const [mode, label] of [['files', '파일'], ['folder', '폴더']]) {
      const node = button(`${label} 추가`, () => inspect(kind, mode)); node.setAttribute('aria-label', `${title} ${label} 선택`); addActions.append(node); importButtons.push(node);
    }
    const selectAll=button('전체 선택',()=>{const ui=sourceUi[kind],entries=kind==='previous'?previous:current,paths=new Set([...entries.values()].map(entry=>normalizeHint(entry.p.path))),select=ui.selectedPaths.size!==paths.size;ui.selectedPaths=select?paths:new Set();for(const entry of entries.values())entry.selectionControl.checked=select;update();});
    const removeSelected=button('선택 삭제',()=>removeSourceFiles(kind,sourceUi[kind].selectedPaths));removeSelected.setAttribute('aria-label',`${title} 선택 삭제`);
    const clearList=button('목록 비우기',()=>removeSourceFiles(kind,new Set([...(kind==='previous'?previous:current).values()].map(entry=>normalizeHint(entry.p.path))),true));clearList.setAttribute('aria-label',`${title} 목록 비우기`);
    for(const node of [selectAll,removeSelected,clearList])node.classList.add('ro-btn-quiet');removeSelected.classList.add('ro-btn-remove');clearList.classList.add('ro-btn-remove');listActions.append(selectAll,removeSelected,clearList);
    section.append(tools);
    const details=element('div',null,'ro-source-options'),detailsBody=element('div',null,'ro-source-options-body');details.append(detailsBody);section.append(details);heading.title=description;
    const search = input(`${kind === 'previous' ? '1차 회신' : '2차 결과'} 목록 검색`); search.placeholder = '불러온 파일 검색'; search.className = 'ro-search'; search.dataset.focusKey = `organizer-${kind}-search`;
    const list = element('div', null, 'ro-list'); list.dataset.scrollKey = `organizer-${kind}-list`;
    const empty = element('p', '여러 폴더나 파일을 추가할 수 있습니다.', 'ro-empty'); list.append(empty);
    search.addEventListener('input', () => { const value = search.value.trim().toLowerCase(); for (const e of (kind === 'previous' ? previous : current).values()) e.sourceNode.hidden = !`${e.p.path} ${e.p.sheet}`.toLowerCase().includes(value); });
    const warning=element('p','','ro-warning ro-import-warning');warning.hidden=true;
    detailsBody.append(warning,search, list); sourceUi[kind] = { title,section,count,list,empty,search,details,warning,selectAll,removeSelected,clearList,selectedPaths:new Set(),importWarnings:new Map() }; sources.append(section);
    if (kind === 'previous') {
      const keywordSettings = element('details', null, 'ro-keyword-settings');keywordSettings.append(element('summary','오류 수량에서 제외할 기준 (선택)'));
      keywordSettings.append(element('p','답변을 복사할 때는 설정하지 않아도 됩니다. 합의된 예외를 수량에서 뺄 때만 사용하세요.','ro-hint'));
      const keywords = editable(element('textarea'), 'organizer-exclusion-keywords'); keywords.setAttribute('aria-label', '오류 수량에서 제외할 키워드'); keywords.value = exclusionKeywords.join('\n');
      keywords.placeholder = '예: 오류 아님\n검토 대상 외'; keywords.rows = 3;
      const keywordMode = editable(element('select'), 'organizer-keyword-match-mode'); keywordMode.setAttribute('aria-label', '키워드 조건');
      option(keywordMode, 'OR', 'OR — 하나라도 포함'); option(keywordMode, 'AND', 'AND — 모두 포함'); keywordMode.value = keywordMatchMode;
      const keywordModeHint = element('p', '', 'ro-hint');
      const keywordStatus = element('p', '', 'ro-keyword-status');
      const refreshKeywordStatus = () => {
        keywordStatus.textContent = exclusionKeywords.length ? `${exclusionKeywords.length}개 키워드 · ${keywordMatchMode === 'AND' ? '모두 포함된 행' : '하나라도 포함된 행'}을 제외 후보로 확인합니다.` : '등록된 키워드 없음';
        keywordModeHint.textContent = keywordMatchMode === 'AND' ? '같은 행의 선택한 열에서 모든 키워드를 찾습니다. 각 키워드는 서로 다른 셀에 있어도 되며, 키워드 하나는 한 셀에 온전히 포함되어야 합니다.' : '같은 행의 선택한 열에 키워드 하나라도 포함되어 있으면 제외 후보로 표시합니다.';
      };
      keywordMode.addEventListener('change', () => {
        keywordMatchMode = keywordMode.value === 'AND' ? 'AND' : 'OR'; presets.keywordMatchMode = keywordMatchMode;
        for (const entry of previous.values()) { entry.choice.keywordMatchMode = keywordMatchMode; invalidateReplies(entry); }
        try { localStorage.setItem(STORAGE, JSON.stringify(presets)); } catch { /* Keep the current settings usable. */ }
        refreshKeywordStatus(); lastMessage = '키워드 조건이 변경되었습니다. 미리보기에서 제외 후보를 다시 확인하세요.'; update();
      });
      const keywordChanged = () => {
        const next = parseKeywords(keywords.value);
        if (JSON.stringify(next) === JSON.stringify(exclusionKeywords)) return;
        exclusionKeywords = next; presets.exclusionKeywords = [...next];
        for (const entry of previous.values()) { entry.choice.exclusionKeywords = [...next]; invalidateReplies(entry); }
        try { localStorage.setItem(STORAGE, JSON.stringify(presets)); } catch { /* Keep the current settings usable. */ }
        refreshKeywordStatus(); lastMessage = '키워드가 변경되었습니다. 답변 미리보기에서 일치하는 행을 확인할 수 있습니다.'; update();
      };
      keywords.addEventListener('input', keywordChanged); keywords.addEventListener('compositionend', keywordChanged);
      const previewKeywords = button('키워드 제외 미리보기', () => showAnswers(activePreviousEntries(), sourceUi.previous.replyHost)); previewKeywords.dataset.organizerEdit = 'true';
      keywordSettings.append(field('오류 수량에서 제외할 키워드', keywords), field('키워드 조건', keywordMode), keywordModeHint, element('p', '키워드를 한 줄에 하나씩 입력하세요. 선택한 열에서 키워드를 찾고, 같은 검토 결과로 확인되면 해당 항목을 오류 수량에서 제외합니다. 답변 열과 검색할 열은 따로 선택할 수 있습니다.', 'ro-hint'),
        element('p', '입력한 문구를 그대로 검색하며 영문 대소문자는 구분하지 않습니다. 키워드를 삭제하면 해당 키워드에 따른 제외도 해제됩니다.', 'ro-hint'), keywordStatus);
      keywordSettings.append(previewKeywords);
      refreshKeywordStatus(); commonSettings.append(keywordSettings);
      const allReplies = button('전체 회신 답변 확인 · 예외 지정', () => showAnswers(activePreviousEntries(), sourceUi.previous.replyHost)); allReplies.dataset.organizerEdit = 'true';
      const replyHost = element('div'); keywordSettings.append(element('p', '제목이 없는 답변 열도 선택할 수 있습니다. ‘수정 완료’ 같은 답변은 자동으로 제외하지 않습니다.', 'ro-hint'), allReplies, replyHost); sourceUi.previous.replyHost = replyHost;
    }
  }
  sourceCard('previous', '1차 회신', '자동 안내를 제외하고 기존 열에 작성된 답변도 찾습니다. 필요한 경우 답변 열을 변경하세요.');
  sourceCard('current', '2차 결과', '모델을 수정한 뒤 추출한 새 결과를 선택하세요.');

  async function inspect(kind, mode) {
    if (running || pending) return;
    const work=beginProgressWork('엑셀 파일을 선택하세요.');
    try {
    let responseProcessed=false;const navigationAtStart=navigationRevision;
    pending++; lastMessage = '엑셀 파일을 불러오는 중…'; errors = []; update();
    try {
      const response = await request('organize:inspect', 'organize:inspected', { kind, mode });
      if (closed) return;
      const entries = kind === 'previous' ? previous : current;
      const inspectedPaths=new Set((response.sheets||[]).map(p=>normalizeHint(p.path)));
      for(const key of sourceUi[kind].importWarnings.keys())if(inspectedPaths.has(key.slice(0,key.lastIndexOf('|'))))sourceUi[kind].importWarnings.delete(key);
      const sheets=response.sheets||[];
      for (const [index,p] of sheets.entries()) {
        if(index%100===0){ProgressDialog.update(index/sheets.length*100,'검토 목록에 등록하는 중입니다.',`${index.toLocaleString()} / ${sheets.length.toLocaleString()}개 시트`,work.owner);await new Promise(resolve=>requestAnimationFrame(resolve));if(closed)return;}
        const warningKey=`${normalizeHint(p.path)}|${p.sheet||''}`;
        if ((p.error || p.copyOnly) && !(kind === 'current' && p.copyOnly)) {
          const message=`${basename(p.path)} / ${p.sheet || ''}: ${p.error || '비교할 수 없는 회신 양식입니다.'}`;
          errors.push(message);sourceUi[kind].importWarnings.set(warningKey,message);
          if (p.token) post('repeat:release', { tokens: [p.token] });
          continue;
        }
        if (!p.token) continue;
        if ([...entries.values()].some(e => e.p.path.toLowerCase() === p.path.toLowerCase() && e.p.sheet === p.sheet)) { post('repeat:release', { tokens: [p.token] }); continue; }
        allTokens.add(p.token); p.columns ||= [];
        const entry = { p, choice: makeChoice(p), keywordColumnsLinked: true, answerColumnsManual: false, detectionGeneration: 0,
          candidate: kind === 'previous' ? ([...previous.values()].find(other => normalizeHint(other.p.path) === normalizeHint(p.path))?.candidate ?? true) : true }; entries.set(p.token, entry);
        if(kind==='previous'&&sourceAnswerHeader)applySourceHeaderToEntry(entry);
        if (kind === 'previous') renderPrevious(entry); else renderCurrent(entry);
      }
      sourceUi[kind].empty.hidden = !!entries.size;
      if (response.cancelled) lastMessage = '파일 선택이 취소되었습니다.'; else lastMessage = '';
      if (errors.length) lastMessage = `${errors.length}개 파일을 불러오지 못했습니다.\n${errors.slice(0, 4).join('\n')}`;
      responseProcessed=!response.cancelled;
    } catch (error) { lastMessage = error.message; }
    finally { pending--; update(); }
    // Read failures belong to those source files; valid files still get an automatic comparison.
    if (!closed && responseProcessed && current.size) {
      if(activePane==='sources'&&navigationRevision===navigationAtStart)selectPane('preview');
      if(previous.size)await suggest();
      else{syncRegisteredOutputNames();selectMapping(current.get(selectedToken)||[...current.values()][0]);update();}
    }
    }finally{endProgressWork(work);}
  }

  function columnPicker(entry, host, currentMode = false) {
    const { p, choice } = entry, checks = new Map();
    if((p.featureHint||p.feature)==='connector')host.append(element('p',`대상 파라미터: ${p.parameterHint||'확인할 수 없음'}`,'ro-hint ro-source-parameter-hint'));
    host.append(element('p', currentMode ? '이번 결과에 이미 답변이 있으면 해당 열을 선택하세요.' : '답변이 적힌 열을 선택하세요. 열 제목이 없으면 내용 예시를 확인하세요.', 'ro-hint'));
    const detectionHint = element('p', '', 'ro-hint ro-detection');
    const refreshDetection = () => {
      const text = entry.answerColumnsManual ? '답변 열을 직접 지정했습니다.' : [p.detection?.sourceAnswerHeaderReason,p.detection?.reason].filter((value,index,values)=>value&&values.indexOf(value)===index).join(' ') || '자동으로 확인된 답변 열이 없습니다. 내용 예시를 확인하고 답변 열을 선택하세요.';
      detectionHint.textContent = text; detectionHint.classList.toggle('ro-warning', !entry.answerColumnsManual && p.detection?.needsReview === true);
      if (entry.detectionBadge) entry.detectionBadge.textContent = answerColumnSummary(entry);
    };
    entry.refreshDetection = refreshDetection; refreshDetection(); host.append(detectionHint);
    const columns = element('div', null, 'ro-columns');
    for (const c of p.columns) {
      if (String(c.header || '').startsWith('__KKYReview_') || ['검토 판정', '이전 판정', '다회차 상태', '이전 회신 위치', '예외 적용 근거'].includes(c.header)) continue;
      const label = element('label', null, 'ro-column'), check = editable(input(`${c.letter}열 ${c.header || '제목 없음'} 답변`), `organizer-${p.token}-column-${c.index}`); check.type = 'checkbox'; check.checked = choice.answerColumns.includes(c.index);
      checks.set(c.index, check);
      check.addEventListener('change', () => {
        if(!currentMode){choice.sourceAnswerHeader='';delete entry.sourceHeaderBaseline;}
        entry.answerColumnsManual = true; choice.answerColumnsManual = true; choice.checkOverwrittenNarratives = true; entry.detectionGeneration++;
        choice.answerColumns = [...checks].filter(([, n]) => n.checked).map(([index]) => index); choice.exceptionRows = [];
        refreshDetection();
        if (!currentMode && entry.keywordColumnsLinked) { choice.keywordColumns = [...choice.answerColumns]; entry.syncKeywordColumns?.(); }
        invalidateReplies(entry); savePreset(entry); lastMessage = ''; update();
      });
      label.append(check, document.createTextNode(`${c.letter}열 · ${c.header || '제목 없음'}`), element('small', (c.samples || []).join(' / ') || '작성된 내용 없음')); columns.append(label);
    }
    host.append(columns);
    let decision;
    if (!currentMode) {
      decision = editable(element('select'), `organizer-${p.token}-decision`); decision.setAttribute('aria-label', '예외 여부가 적힌 판정 열');
      option(decision, '-1', '판정 열 없음');
      for (const c of p.columns.filter(c => !String(c.header || '').startsWith('__KKYReview_'))) option(decision, String(c.index), `${c.letter}열 · ${c.header || '제목 없음'}`);
      decision.value = String(choice.decisionColumn);
      decision.addEventListener('change', () => { choice.decisionColumn = Number(decision.value); choice.exceptionRows = []; invalidateReplies(entry); savePreset(entry); lastMessage = ''; update(); });
      host.append(field('예외 여부가 적힌 판정 열', decision), element('p', '판정 열의 ‘예외 인정’ 항목만 자동 제외합니다. 판정이 없는 회신은 아래에서 예외로 인정할 답변을 선택하세요.', 'ro-hint'));
      const keywordDetails = element('details', null, 'ro-keyword-columns'); keywordDetails.append(element('summary', '키워드를 찾을 열'));
      const keywordChecks = new Map(), keywordColumns = element('div', null, 'ro-columns');
      for (const c of p.columns.filter(c => !String(c.header || '').startsWith('__KKYReview_'))) {
        const label = element('label', null, 'ro-column'), check = editable(input(`${c.letter}열 ${c.header || '제목 없음'} 키워드 검색`), `organizer-${p.token}-keyword-column-${c.index}`);
        check.type = 'checkbox'; check.checked = choice.keywordColumns.includes(c.index); keywordChecks.set(c.index, check);
        check.addEventListener('change', () => {
          choice.keywordColumns = [...keywordChecks].filter(([, n]) => n.checked).map(([index]) => index); entry.keywordColumnsLinked = false;
          invalidateReplies(entry); savePreset(entry); lastMessage = ''; update();
        });
        label.append(check, document.createTextNode(`${c.letter}열 · ${c.header || '제목 없음'}`), element('small', (c.samples || []).join(' / ') || '작성된 내용 없음')); keywordColumns.append(label);
      }
      const keywordSelectionStatus = element('p', '', 'ro-keyword-status');
      entry.syncKeywordColumns = () => {
        for (const [index, check] of keywordChecks) check.checked = choice.keywordColumns.includes(index);
        keywordSelectionStatus.textContent = choice.keywordColumns.length ? `검색할 열: ${p.columns.filter(c => choice.keywordColumns.includes(c.index)).map(c => c.letter).join(', ')}열` : '선택한 열 없음 · 이 시트에는 키워드 제외가 적용되지 않습니다.';
      };
      for (const check of keywordChecks.values()) check.addEventListener('change', entry.syncKeywordColumns);
      const applyKeywords = button('같은 양식에 키워드 검색 열 적용', () => {
        let count = 0;
        for (const other of activePreviousEntries()) {
          if (other.p.layout !== p.layout) continue;
          other.choice.keywordColumns = normalizedColumns(choice.keywordColumns, other.p.columns); other.keywordColumnsLinked = false;
          invalidateReplies(other); other.syncKeywordColumns?.(); count++;
        }
        savePreset(entry); lastMessage = `같은 양식 ${count}개에 키워드 검색 열을 적용했습니다.`; update();
      }); applyKeywords.dataset.organizerEdit = 'true';
      keywordDetails.append(element('p', '선택한 열에서만 키워드를 찾습니다. 검색할 열을 변경해도 코멘트를 가져올 답변 열은 유지됩니다.', 'ro-hint'), keywordColumns, applyKeywords);
      host.append(keywordDetails, keywordSelectionStatus); entry.syncKeywordColumns();
    }
    entry.syncColumns = () => { for (const [index, check] of checks) check.checked = choice.answerColumns.includes(index); if (decision) decision.value = String(choice.decisionColumn); };
    const apply = button('같은 양식에 답변·판정 열 적용', () => {
      let count = 0;
      for (const other of (currentMode ? [...current.values()] : activePreviousEntries())) {
        if (other.p.layout !== p.layout) continue;
        other.answerColumnsManual = true; other.choice.answerColumnsManual = true; other.choice.checkOverwrittenNarratives = true; other.detectionGeneration++;
        if(!currentMode){other.choice.sourceAnswerHeader='';delete other.sourceHeaderBaseline;}
        other.choice.answerColumns = normalizedColumns(choice.answerColumns, other.p.columns);
        other.refreshDetection?.();
        other.choice.decisionColumn = choice.decisionColumn; other.choice.exceptionRows = [];
        if (!currentMode && other.keywordColumnsLinked) { other.choice.keywordColumns = [...other.choice.answerColumns]; other.syncKeywordColumns?.(); }
        invalidateReplies(other); other.syncColumns?.(); count++;
      }
      savePreset(entry); lastMessage = `같은 양식 ${count}개에 적용했습니다.`; update();
    }); apply.dataset.organizerEdit = 'true';
    const tools = element('div', null, 'ro-tools'); tools.append(apply); host.append(tools);
    if (!currentMode) {
      const replyHost = element('div'); entry.replyHost = replyHost;
      const show = button('답변 확인 · 예외 지정', () => showAnswers([entry], replyHost)); show.dataset.organizerEdit = 'true'; tools.append(show); host.append(replyHost);
    }
  }

  function sourceSelection(kind,entry,wrapper){
    const ui=sourceUi[kind],key=normalizeHint(entry.p.path),selection=checkbox('파일 선택',ui.selectedPaths.has(key),checked=>{
      if(running||pending)return;checked?ui.selectedPaths.add(key):ui.selectedPaths.delete(key);
      for(const item of (kind==='previous'?previous:current).values())if(normalizeHint(item.p.path)===key)item.selectionControl.checked=checked;
      update();
    });
    selection.wrapper.classList.add('ro-source-select');selection.node.setAttribute('aria-label',`${basename(entry.p.path)} / ${entry.p.sheet} 목록 선택`);selection.node.dataset.focusKey=`organizer-${entry.p.token}-selection`;entry.selectionControl=selection.node;wrapper.append(selection.wrapper);
  }

  function renderPrevious(entry) {
    const details = element('details', null, 'ro-sheet'); details.dataset.token = entry.p.token;
    const wrapper = element('div', null, 'ro-source-entry ro-previous-entry');sourceSelection('previous',entry,wrapper);
    const missing=element('span','미연결 · 2차 파일 없음','ro-source-unlinked');missing.hidden=true;entry.unlinkedLabel=missing;
    const candidate = checkbox('매핑 후보로 사용', entry.candidate !== false, checked => setCandidateFile(entry.p.path, checked));
    editable(candidate.node, `organizer-${entry.p.token}-candidate`); candidate.node.setAttribute('aria-label', `${basename(entry.p.path)} / ${entry.p.sheet} 매핑 후보로 사용`); entry.candidateControl = candidate.node;
    const summary = element('summary', sheetHeading(entry.p)); entry.detectionBadge = element('span', answerColumnSummary(entry), 'ro-hint'); summary.append(entry.detectionBadge,missing);
    details.append(summary); wrapper.append(details); entry.sourceNode = wrapper;
    lazyPanel(details, () => { const body = element('div', null, 'ro-sheet-body');body.append(candidate.wrapper);columnPicker(entry, body); const remove = button('이 회신 불러오기 취소', () => removeSheet('previous', entry)); remove.dataset.organizerEdit = 'true'; body.append(remove); details.append(body); });
    sourceUi.previous.list.append(wrapper);
  }

  function setCandidateFile(path, selected) {
    if (running) return;
    const affected = new Set();
    for (const entry of previous.values()) if (normalizeHint(entry.p.path) === normalizeHint(path)) {
      entry.candidate = selected; entry.candidateControl.checked = selected; affected.add(entry.p.token); invalidateReplies(entry);
    }
    for (const entry of current.values()) {
      if (!selected && entry.previousTokens.some(token => affected.has(token))) {
        entry.previousTokens = entry.previousTokens.filter(token => !affected.has(token)); entry.confirmed = false; entry.manual = false; entry.applySuggestion?.();
      }
      entry.refreshCandidates?.();
    }
    mappingGeneration++; resuggestRequested = true;
    lastMessage = selected ? '선택한 1차 파일만 매핑 후보로 사용합니다.' : '선택을 해제한 1차 파일은 연결과 미리보기에서 제외했습니다.'; update();
  }
  function renderCurrent(entry) {
    Object.assign(entry, { model: entry.p.modelHint || '', feature: entry.p.featureHint || entry.p.feature || 'offline', previousTokens: [], confirmed: false, noPrevious: !!entry.p.copyOnly, skip: false, manual: false });
    const wrapper=element('div',null,'ro-source-entry ro-current-entry');sourceSelection('current',entry,wrapper);
    const sourceNode = element('details', null, 'ro-sheet'); sourceNode.append(element('summary', sheetHeading(entry.p)));wrapper.append(sourceNode);entry.sourceNode=wrapper;sourceUi.current.list.append(wrapper);
    lazyPanel(sourceNode, () => { const remove = button('이 결과 불러오기 취소', () => removeSheet('current', entry)); remove.dataset.organizerEdit = 'true'; sourceNode.append(remove); });
    const details = element('details', null, 'ro-sheet ro-map-row'); details.dataset.token = entry.p.token;
    const summary=element('summary'),title=element('strong',basename(entry.p.path),'ro-map-name'),badge=element('span','','ro-badge'),peer=element('span','','ro-map-peer');title.title=entry.p.path;summary.append(title,badge,peer);details.append(summary);entry.node=details;entry.badge=badge;entry.peer=peer;
    summary.addEventListener('click',event=>{event.preventDefault();selectMapping(entry);});mappingList.append(details);
  }

  function removeSheet(kind, entry) {
    removeSourceFiles(kind,new Set([normalizeHint(entry.p.path)]));
  }

  function removeSourceFiles(kind,paths,clear=false){
    if(running||pending)return;
    const ui=sourceUi[kind],entries=kind==='previous'?previous:current,removedPaths=new Set(paths),removedTokens=new Set();
    for(const entry of [...entries.values()])if(removedPaths.has(normalizeHint(entry.p.path))){
      removedTokens.add(entry.p.token);entries.delete(entry.p.token);allTokens.delete(entry.p.token);entry.sourceNode.remove();
      if(kind==='current'){entry.node.remove();entry.settingsHost?.remove();}
    }
    for(const path of removedPaths)ui.selectedPaths.delete(path);
    for(const key of ui.importWarnings.keys())if(clear||removedPaths.has(key.slice(0,key.lastIndexOf('|'))))ui.importWarnings.delete(key);
    if(kind==='previous'){
      for(const entry of current.values())if(entry.previousTokens.some(token=>removedTokens.has(token))){
        entry.previousTokens=entry.previousTokens.filter(token=>!removedTokens.has(token));entry.confirmed=false;entry.candidateTokens=(entry.candidateTokens||[]).filter(token=>!removedTokens.has(token));entry.applySuggestion?.();
      }
      sourceUi.previous.replyHost.replaceChildren();
    }
    if(removedTokens.size)post('repeat:release',{tokens:[...removedTokens]});
    mappingGeneration++;previewSignature='';ui.empty.hidden=!!entries.size;errors=[];
    if(!current.has(selectedToken))selectedToken='';
    if(!current.size){
      detailGeneration++;if(detailRequestId)post('organize:cancelPreview',{requestId:detailRequestId});detailRequestId='';previewData=null;previewSummary.replaceChildren();previewPages.hidden=true;previewScroll.replaceChildren();previewScroll.removeAttribute('aria-busy');
      detailTitle.textContent='파일을 선택하세요';detailPair.textContent='';detailStatus.textContent='';
    }
    lastMessage=clear?`${ui.title} 목록을 비웠습니다.`:`${removedPaths.size}개 파일을 목록에서 제거했습니다.`;update();
    if(current.size){syncRegisteredOutputNames();selectMapping(current.get(selectedToken)||[...current.values()][0]);}
  }

  function buildMapping(entry) {
    const body = element('div', null, 'ro-sheet-body'), tools = element('div', null, 'ro-tools');
    if (entry.p.copyOnly) {
      body.append(element('p', '비교할 수 없는 2차 파일도 원본 그대로 저장합니다.', 'ro-hint'), element('p', entry.p.error || '비교할 수 있는 검토 항목을 찾지 못했습니다.', 'ro-hint'));
      entry.settingsHost.append(body); return;
    }
    const model = editable(input('대상 모델 이름', entry.model === '@rows' ? '' : entry.model), `organizer-${entry.p.token}-model`), feature = editable(element('select'), `organizer-${entry.p.token}-feature`);
    feature.setAttribute('aria-label', '검토 기능');
    for (const [key, label] of FEATURES) option(feature, key, label);
    if (!FEATURES.some(([key]) => key === entry.feature)) option(feature, entry.feature, entry.feature);
    feature.value = entry.feature;
    model.addEventListener('input', () => { entry.model = model.value; changed(entry); });
    model.addEventListener('compositionend', () => { entry.model = model.value; changed(entry); });
    feature.addEventListener('change', () => { entry.feature = feature.value; parameterHint.hidden=entry.feature!=='connector'; changed(entry);selectMapping(entry,false); });
    const rowModel = checkbox('엑셀 각 행의 모델명으로 연결', entry.model === '@rows', checked => {
      entry.model = checked ? '@rows' : model.value; model.dataset.organizerLocked = String(checked); model.disabled = checked; changed(entry);
    }); editable(rowModel.node, `organizer-${entry.p.token}-row-model`);
    model.dataset.organizerLocked = String(entry.model === '@rows'); model.disabled = entry.model === '@rows';
    const modelField = field('대상 모델 이름', model), modelHint = element('small', '파일명을 _로 나눈 앞 4개 항목을 모델명으로 사용합니다.', 'ro-hint');
    modelHint.id = `organizer-${entry.p.token}-model-hint`; model.setAttribute('aria-describedby', modelHint.id); modelField.append(modelHint);
    tools.append(modelField, field('검토 기능', feature));
    const reason = element('p', entry.reason || '', 'ro-hint');
    const parameterHint=element('p',`대상 파라미터: ${entry.p.parameterHint||'확인할 수 없음'} · 같은 파라미터를 검토한 파일끼리 연결합니다.`,'ro-hint ro-parameter-hint');parameterHint.hidden=entry.feature!=='connector';body.append(parameterHint);
    const skip = checkbox('이 시트는 원본 그대로 저장', entry.skip, checked => { entry.skip = checked; update();selectMapping(entry); }); editable(skip.node, `organizer-${entry.p.token}-skip`);
    const noPrevious = checkbox('이 파일은 연결하지 않고 원본 유지', entry.noPrevious, checked => {
      entry.noPrevious = checked; if (checked) entry.previousTokens = []; changed(entry); refreshSelection();
    }); editable(noPrevious.node, `organizer-${entry.p.token}-new`);
    body.append(tools, rowModel.wrapper, reason, skip.wrapper, noPrevious.wrapper);
    const selected = element('div', null, 'ro-selected'); body.append(selected);
    const search = editable(input('연결할 1차 결과 검색'), `organizer-${entry.p.token}-previous-search`); search.placeholder = '다른 파일을 연결하려면 파일명으로 검색'; search.className = 'ro-search';
    const picker = element('div', null, 'ro-pair-picker'), previousSelect = editable(element('select'), `organizer-${entry.p.token}-previous`); previousSelect.setAttribute('aria-label', '연결할 1차 결과');
    function refreshOptions() {
      const old = previousSelect.value, term = search.value.trim().toLowerCase();
      const all = activePreviousEntries().filter(e => !entry.previousTokens.includes(e.p.token) && (!term || `${e.p.path} ${e.p.sheet}`.toLowerCase().includes(term)));
      if (!term) all.sort((a, b) => Number((entry.candidateTokens || []).includes(b.p.token)) - Number((entry.candidateTokens || []).includes(a.p.token))
        || Number(normalizeHint(b.p.modelHint) === normalizeHint(entry.model)) - Number(normalizeHint(a.p.modelHint) === normalizeHint(entry.model)));
      previousSelect.replaceChildren(); option(previousSelect, '', all.length > 80 ? `${all.length}개 중 80개 표시 · 파일명으로 검색하세요` : '연결할 1차 결과 선택');
      for (const item of all.slice(0, 80)) option(previousSelect, item.p.token, `${basename(item.p.path)} / ${item.p.sheet}`);
      if ([...previousSelect.options].some(o => o.value === old)) previousSelect.value = old;
    }
    search.addEventListener('input', refreshOptions);
    entry.refreshCandidates = refreshOptions;
    const add = button('연결 추가', () => {
      if (!previousSelect.value || previous.get(previousSelect.value)?.candidate === false) return;
      entry.previousTokens.push(previousSelect.value); entry.noPrevious = false;
      const hint = previous.get(previousSelect.value)?.p.modelHint;
      if (!entry.model && hint) { entry.model = hint; model.value = hint; }
      changed(entry); refreshSelection();
    }); add.dataset.organizerEdit = 'true'; picker.append(previousSelect, add);
    const confirm = button('이 연결로 확정', () => {
      if (!entry.previousTokens.length || entry.noPrevious) { lastMessage = '연결할 1차 회신을 선택하고 ‘연결 추가’를 누른 뒤 확정하세요. 미연결된 2차 파일은 원본 그대로 저장합니다.'; update(); return; }
      if (!entry.model.trim() || !entry.feature) { lastMessage = '비교할 대상 모델과 검토 기능을 지정하세요.'; update(); return; }
      entry.confirmed = true; entry.manual = true; lastMessage = ''; update();selectMapping(entry);
    }); confirm.dataset.organizerEdit = 'true';
    const applyRule = button('같은 파일명 규칙에 연결 적용', () => applyMappingRule(entry)); applyRule.dataset.organizerEdit = 'true';
    const confirmTools = element('div', null, 'ro-tools'); confirmTools.append(confirm, applyRule);
    body.append(search, picker, element('p', '1차 회신을 선택해 ‘연결 추가’를 누른 뒤, 추가된 연결을 확인하고 ‘이 연결로 확정’을 누르세요. 확정한 연결에만 이전 답변을 반영합니다.', 'ro-hint'), confirmTools,
      element('p', '다른 모델도 파일명 뒤 검토 이름이 같은 규칙이면 연결을 일괄 적용할 수 있습니다. 후보가 하나로 정해지는 결과만 연결합니다.', 'ro-hint'));
    const currentColumns = element('details'); currentColumns.append(element('summary', '이번 결과의 답변 열 지정'));
    lazyPanel(currentColumns, () => columnPicker(entry, currentColumns, true)); body.append(currentColumns);
    function refreshSelection() {
      selected.replaceChildren();
      for (const token of entry.previousTokens) {
        const previousEntry = previous.get(token), tag = element('span', null, 'ro-tag');
        tag.append(document.createTextNode(previousEntry ? `${basename(previousEntry.p.path)} / ${previousEntry.p.sheet}` : '다시 연결 필요'));
        if(previousEntry){const columns=button('답변 열 확인',()=>{selectPane('sources');const node=previousEntry.sourceNode.querySelector('details');node.open=true;update();node.scrollIntoView({block:'nearest'});node.querySelector('summary').focus({preventScroll:true});});tag.append(columns);}
        const remove = button('×', () => { entry.previousTokens = entry.previousTokens.filter(t => t !== token); changed(entry); refreshSelection(); }); remove.setAttribute('aria-label', `${basename(previousEntry?.p.path)} 연결 해제`); remove.dataset.organizerEdit = 'true'; tag.append(remove); selected.append(tag);
      }
      noPrevious.node.checked = entry.noPrevious; refreshOptions();
    }
    entry.refresh = () => { reason.textContent = entry.reason || ''; noPrevious.node.checked = entry.noPrevious; skip.node.checked = entry.skip; };
    entry.applySuggestion = () => { model.value = entry.model === '@rows' ? '' : entry.model; rowModel.node.checked = entry.model === '@rows'; model.dataset.organizerLocked = String(entry.model === '@rows'); model.disabled = entry.model === '@rows'; feature.value = entry.feature;parameterHint.hidden=entry.feature!=='connector'; entry.refresh(); refreshSelection(); };
    entry.settingsHost.append(body); refreshSelection();
  }

  function parameterSignature(preview){
    return preview&&Object.prototype.hasOwnProperty.call(preview,'parameterKey')
      ?String(preview.parameterKey||'')
      :normalizeHint(preview?.parameterHint);
  }
  function applyMappingRule(example) {
    if (running) return;
    if (!validMapping(example) || example.previousTokens.length !== 1) { lastMessage = '파일명 규칙을 적용하려면 이 시트에 1차 결과 하나를 연결하고 확정하세요.'; update(); return; }
    const previousExample = previous.get(example.previousTokens[0]);
    const connectorScope=example.feature==='connector',parameter=parameterSignature(example.p);
    if(connectorScope&&(!parameter||parameter!==parameterSignature(previousExample.p)||previousExample.p.featureHint!=='connector')){
      lastMessage='대상 파라미터가 같은 1차·2차 연결을 확인한 뒤 파일명 규칙을 적용하세요.';update();return;
    }
    // Both sides of an explicitly confirmed pair use the model selected by the user.
    const currentRule = fileNameRule(example.p, example.model), previousRule = fileNameRule(previousExample.p, example.model);
    if (!currentRule || !previousRule || !example.p.layout || !previousExample.p.layout) {
      lastMessage = '파일명에서 모델과 검토 이름을 구분할 수 없습니다. 개별 연결을 사용하세요.'; update(); return;
    }
    let count = 0, needs = 0;
    for (const target of current.values()) {
      if(connectorScope&&(target.feature!=='connector'||parameterSignature(target.p)!==parameter))continue;
      if (target === example || target.manual || target.skip || target.p.layout !== example.p.layout || fileNameRule(target.p, target.model) !== currentRule
        || (!connectorScope&&normalizeHint(target.p.parameterHint) !== normalizeHint(example.p.parameterHint)) || !target.model || target.model === '@rows') continue;
      const candidates = activePreviousEntries().filter(candidate => candidate.p.layout === previousExample.p.layout
        && (!connectorScope||(candidate.p.featureHint==='connector'&&parameterSignature(candidate.p)===parameter))
        && fileNameRule(candidate.p, target.model) === previousRule && normalizeHint(candidate.p.modelHint) === normalizeHint(target.model)
        && (connectorScope||normalizeHint(candidate.p.parameterHint) === normalizeHint(previousExample.p.parameterHint)));
      if (candidates.length !== 1) { needs++; continue; }
      target.previousTokens = [candidates[0].p.token]; target.feature = example.feature;
      target.confirmed = true; target.noPrevious = false; target.manual = true; target.reason = '사용자가 지정한 파일명 규칙으로 연결';
      target.applySuggestion?.(); count++;
    }
    lastMessage = `${count}개 시트에 연결을 적용했습니다.${needs ? ` 후보가 정해지지 않은 ${needs}개는 직접 확인하세요.` : ''}`; update();
    selectMapping(current.get(selectedToken)||example);
  }

  function detectionFileGroups(mappings=buildMappings(false,false)) {
    const files=new Map();
    for(const mapping of mappings){
      const entry=current.get(mapping.currentToken);if(!entry)continue;
      const key=normalizeHint(entry.p.path);if(!files.has(key))files.set(key,{key,mappings:[]});
      files.get(key).mappings.push(mapping);
    }
    for(const file of files.values()){
      // Automatic results are deliberately excluded: receiving a decision must
      // not make that same file stale again. Manual choices still affect its gate.
      file.signature=JSON.stringify(file.mappings.map(mapping=>({currentToken:mapping.currentToken,model:mapping.model,feature:mapping.feature,destinationMode:mapping.destinationMode,destinationHeader:mapping.destinationHeader,
        preserveOriginal:mapping.preserveOriginal,currentAnswerColumns:mapping.currentAnswerColumns,
        previous:mapping.previous.map(choice=>({token:choice.token,sourceAnswerHeader:choice.sourceAnswerHeader,answerColumnsManual:choice.answerColumnsManual,
          answerColumns:choice.answerColumnsManual?choice.answerColumns:undefined,decisionColumn:choice.decisionColumn,
          originalHeaders:choice.answerColumnsManual?choice.originalHeaders:undefined,
          checkOverwrittenNarratives:choice.answerColumnsManual?choice.checkOverwrittenNarratives:undefined}))})));
    }
    return files;
  }
  async function detectMappings(entries) {
    // Catalog and preview can both request preparation; share work while it is
    // running, then recheck the requested files against their current choices.
    while(detectionPromise)await detectionPromise;
    if(closed)return;
    const requested=new Set(entries.map(entry=>normalizeHint(entry.p.path))),files=[];
    for(const file of detectionFileGroups().values()){
      if(!requested.has(file.key))continue;
      file.captured=[];const seen=new Set();
      for(const mapping of file.mappings){
        if(mapping.preserveOriginal)continue;
        const entry=current.get(mapping.currentToken);
        for(const choice of mapping.previous){
          const source=previous.get(choice.token);
          if(!source||source.answerColumnsManual||seen.has(choice.token)||source.detectionSignature===file.signature)continue;
          seen.add(choice.token);file.captured.push({source,entry,fileKey:file.key,signature:file.signature,generation:++source.detectionGeneration,
            item:{token:choice.token,currentToken:entry.p.token,feature:entry.feature}});
        }
      }
      if(file.captured.length)files.push(file);
    }
    if(!files.length)return;
    // Never split a physical workbook, even when it contains over 100 sheets.
    // Include manual and preserved sibling sheets in the same gate request.
    const chunks=[];let chunk={mappings:[],captured:[],fileCount:0};
    for(const file of files){
      if(chunk.mappings.length&&chunk.mappings.length+file.mappings.length>100){chunks.push(chunk);chunk={mappings:[],captured:[],fileCount:0};}
      chunk.mappings.push(...file.mappings);chunk.captured.push(...file.captured);chunk.fileCount++;
    }
    if(chunk.mappings.length)chunks.push(chunk);
    const work=beginProgressWork('답변 열을 확인하는 중입니다.'),group={total:files.length,fractions:new Map()};
    pending++;update();
    const task=(async()=>{
      try{
        for(const chunk of chunks){
          const response=await request('repeat:detect','repeat:detected',{mappings:chunk.mappings,items:chunk.captured.map(target=>target.item)},{group,weight:chunk.fileCount});
          if(closed)return;
          const currentFiles=detectionFileGroups();
          for(const result of response.results||[]){
            const target=chunk.captured.find(item=>item.item.token===result.token&&item.item.currentToken===result.currentToken);if(!target)continue;
            const {source,entry,generation,signature}=target;
            if(previous.get(result.token)!==source||current.get(result.currentToken)!==entry||source.answerColumnsManual||source.detectionGeneration!==generation
              ||currentFiles.get(target.fileKey)?.signature!==signature||!savableMapping(entry)||!entry.previousTokens.includes(result.token)||entry.feature!==target.item.feature)continue;
            if(result.error)source.p.detection={answerColumns:[],candidateColumns:[],needsReview:true,status:'review',reason:result.error,checkOverwrittenNarratives:false};
            else if(result.detection)source.p.detection=result.detection;
            else continue;
            source.detectionSignature=signature;
            const columns=autoAnswerColumns(source.p).filter(index=>index!==source.choice.decisionColumn),checkOverwritten=source.p.detection.checkOverwrittenNarratives===true,originalHeaders=cloneOriginalHeaders(source.p.detection.originalHeaders,source.p.columns);
            if(JSON.stringify(columns)!==JSON.stringify(source.choice.answerColumns)||checkOverwritten!==source.choice.checkOverwrittenNarratives||JSON.stringify(originalHeaders)!==JSON.stringify(source.choice.originalHeaders)){
              source.choice.answerColumns=columns;source.choice.checkOverwrittenNarratives=checkOverwritten;source.choice.originalHeaders=originalHeaders;source.choice.exceptionRows=[];
              if(source.keywordColumnsLinked){source.choice.keywordColumns=[...columns];source.syncKeywordColumns?.();}
              invalidateReplies(source);source.syncColumns?.();
            }
            source.refreshDetection?.();
            if(!source.refreshDetection&&source.detectionBadge)source.detectionBadge.textContent=answerColumnSummary(source);
          }
        }
      }catch(error){
        if(!closed){
          for(const chunk of chunks)for(const target of chunk.captured){
            const {source,generation}=target;
            if(previous.get(source.p.token)!==source||source.answerColumnsManual||source.detectionGeneration!==generation)continue;
            source.detectionSignature='';source.p.detection={...source.p.detection,originalHeaders:{}};
            if(Object.keys(source.choice.originalHeaders||{}).length){source.choice.originalHeaders={};invalidateReplies(source);}
          }
          lastMessage=`답변 열 자동 확인을 완료하지 못했습니다. ${error.message}`;
        }
      }
      finally{pending--;if(!closed)update();endProgressWork(work);}
    })();
    detectionPromise=task;
    try{await task;}finally{if(detectionPromise===task)detectionPromise=null;}
  }

  async function suggest() {
    if (running || pending || !current.size || !activePreviousEntries().length) return;
    const work=beginProgressWork('파일 연결을 확인하는 중입니다.');
    const generation = ++mappingGeneration; pending++; lastMessage = '1차와 2차 결과를 연결하는 중…'; update();
    try {
      const response = await request('organize:suggest', 'organize:suggested', { previousTokens: activePreviousEntries().map(entry => entry.p.token), currentTokens: [...current.keys()] });
      if (closed || generation !== mappingGeneration) return;
      const suggested=response.mappings||[];
      for (const [index,mapping] of suggested.entries()) {
        if(index%100===0){ProgressDialog.update(index/suggested.length*100,'파일 연결을 목록에 반영하는 중입니다.',`${index.toLocaleString()} / ${suggested.length.toLocaleString()}개 시트`,work.owner);await new Promise(resolve=>requestAnimationFrame(resolve));if(closed||generation!==mappingGeneration)return;}
        const entry = current.get(mapping.currentToken); if (!entry || entry.manual || entry.p.copyOnly) continue;
        // A delayed host response never changes controls that the user has begun editing.
        if (entry.node.contains(document.activeElement)||entry.settingsHost?.contains(document.activeElement)) continue;
        entry.previousTokens = (mapping.previousTokens || []).filter(token => previous.has(token) && previous.get(token).candidate !== false);
        entry.candidateTokens = (mapping.candidateTokens || []).filter(token => previous.has(token) && previous.get(token).candidate !== false);
        entry.model = mapping.model || entry.model; entry.feature = mapping.feature || entry.feature;
        entry.confirmed = !!mapping.confirmed && entry.previousTokens.length > 0; entry.reason = mapping.reason || '';entry.suggestionChecked=true;
        entry.applySuggestion?.();
      }
      lastMessage = '';
      syncRegisteredOutputNames();selectMapping(current.get(selectedToken)||[...current.values()].find(savableMapping)||[...current.values()][0]);
    } catch (error) { lastMessage = error.message; }
    finally { pending--; update();endProgressWork(work); }
  }

  async function showAnswers(entries, host) {
    entries = entries.filter(entry => entry.candidate !== false);
    if (running || pending || !entries.length) return;
    const work=beginProgressWork('작업자 답변을 모으는 중입니다.'),group={total:entries.length,fractions:new Map()};
    pending++; lastMessage = '회신 답변을 모으는 중…'; update();
    const captured = entries.map(entry => ({ entry, generation: entry.replyGeneration || 0 })), groups = new Map();
    try {
      for (let offset = 0; offset < captured.length; offset += 4) {
        const chunk = captured.slice(offset, offset + 4);
        const responses = await Promise.all(chunk.map(async ({ entry, generation }) => ({ entry, generation, data: await request('repeat:answers', 'repeat:answers', { choice: entry.choice },{group}) })));
        if (closed) return;
        for (const { entry, generation, data } of responses) {
          if ((entry.replyGeneration || 0) !== generation) throw Error('답변 열이나 키워드 설정이 변경되었습니다. 답변 확인을 다시 실행하세요.');
          for (const row of data.rows || []) {
            const key = JSON.stringify([row.answer || '', row.decision || '', row.keywordMatches || []]);
            if (!groups.has(key)) groups.set(key, []); groups.get(key).push({ entry, row });
          }
        }
        lastMessage = `회신 답변 확인 ${Math.min(offset + 4, captured.length)} / ${captured.length}개 시트`; update();
      }
      if (captured.some(({ entry, generation }) => (entry.replyGeneration || 0) !== generation)) throw Error('답변 열이나 키워드 설정이 변경되었습니다. 답변 확인을 다시 실행하세요.');
      host.replaceChildren(); host.className = 'ro-replies'; host.dataset.scrollKey = `organizer-replies-${entries.length === 1 ? entries[0].p.token : 'all'}`;
      const keywordMatchCount = [...groups.values()].reduce((total, members) => total + members.filter(({ row }) => row.keywordMatches?.length).length, 0);
      if (exclusionKeywords.length) host.append(element('p', `키워드 제외 후보 ${keywordMatchCount}행 · 최종 제외 수량은 이번 결과와 동일한 항목인지 확인한 뒤 계산합니다.`, 'ro-keyword-preview-count ro-keyword-match'));
      host.append(element('p', '키워드 일치는 별도 선택 없이 제외 후보에 반영됩니다. 체크박스는 키워드와 별도로 예외를 인정할 때 사용하세요. ‘수정 완료’ 같은 문구는 제외 키워드로 직접 등록한 경우에만 키워드 조건으로 적용됩니다.', 'ro-hint'));
      for (const [index,members] of [...groups.values()].entries()) {
        if(index%100===0){ProgressDialog.update(index/groups.size*100,'작업자 답변을 화면에 표시하는 중입니다.',`${index.toLocaleString()} / ${groups.size.toLocaleString()}가지 답변`,work.owner);await new Promise(resolve=>requestAnimationFrame(resolve));if(closed)return;}
        const label = element('label', null, 'ro-reply'), check = editable(input('이 답변을 예외로 인정')); check.type = 'checkbox';
        check.checked = members.every(({ entry, row }) => entry.choice.exceptionRows.includes(row.row));
        check.indeterminate = !check.checked && members.some(({ entry, row }) => entry.choice.exceptionRows.includes(row.row));
        check.addEventListener('change', () => {
          if (captured.some(({ entry, generation }) => (entry.replyGeneration || 0) !== generation)) { check.checked = false; lastMessage = '답변 열이나 키워드 설정이 변경되었습니다. 답변 확인을 다시 실행하세요.'; update(); return; }
          for (const { entry, row } of members) { const rows = new Set(entry.choice.exceptionRows); check.checked ? rows.add(row.row) : rows.delete(row.row); entry.choice.exceptionRows = [...rows]; }
          lastMessage = check.checked ? `${members.length}건을 예외로 지정했습니다.` : `${members.length}건의 예외 지정을 해제했습니다.`; update();
        });
        const sample = members[0].row, fileCount = new Set(members.map(m => m.entry.p.path)).size;
        const text = element('span', `${members.length}건 · ${fileCount}개 파일\n${sample.answer || '(답변 없음)'}${sample.decision ? '\n판정: ' + sample.decision : ''}\n예: ${members.slice(0, 2).map(({ entry, row }) => `${basename(entry.p.path)} ${row.row}행`).join(' / ')}`);
        if (sample.keywordMatches?.length) text.append(element('span', `\n제외 후보 키워드: ${sample.keywordMatches.join(', ')}`, 'ro-keyword-match'));
        label.append(check, text); host.append(label);
      }
      if (!groups.size) host.append(element('p', '선택한 열에 답변 또는 일치하는 키워드가 없습니다. 열 선택을 확인하세요.', 'ro-hint'));
      host.style.minHeight = ''; delete host.dataset.previewStale;
      lastMessage = `${groups.size}가지 답변을 확인했습니다.`;
    } catch (error) { lastMessage = error.message; }
    finally { pending--; update();endProgressWork(work); }
  }

  function activeAnswerRules(){
    return answerGroups.filter(group=>answerEdits.has(group.key)).map(group=>({originalAnswer:group.originalAnswer,...answerEdits.get(group.key)}));
  }
  function updateAnswerSummary(){
    const edited=activeAnswerRules().length;
    answerSummary.textContent=`${answerGroups.length.toLocaleString()}가지 원문 · ${edited.toLocaleString()}개 변경${answerCatalogLoaded?' · 같은 원문이 있는 모든 연결 파일에 적용':''}`;
  }
  function answerState(group){return answerEdits.get(group.key)||{replacementAnswer:'',excludeFromQuantity:null,clearAnswer:false};}
  function answerQuantityLabel(value){return value===true?'제외':value===false?'포함':'기존 기준';}
  function updateAnswerRow(group){
    const row=answerRowControls.get(group.key);if(!row)return;const state=answerState(group);
    row.saved.textContent=state.clearAnswer?'빈칸으로 변경':normalizeAnswer(state.replacementAnswer)?state.replacementAnswer:'원문 유지';row.quantity.textContent=answerQuantityLabel(state.excludeFromQuantity);row.node.classList.toggle('is-selected',group.key===answerSelectedKey);row.button.setAttribute('aria-pressed',String(group.key===answerSelectedKey));
  }
  function changeAnswerRule(group,replacementAnswer,excludeFromQuantity,refresh=true,clearAnswer=false){
    const replacement=String(replacementAnswer??'');
    if(!normalizeAnswer(replacement)&&excludeFromQuantity==null&&!clearAnswer)answerEdits.delete(group.key);
    else answerEdits.set(group.key,{replacementAnswer:replacement,excludeFromQuantity:excludeFromQuantity===true?true:excludeFromQuantity===false?false:null,...(clearAnswer?{clearAnswer:true}:{})});
    if(refresh){updateAnswerRow(group);updateAnswerSummary();lastMessage='답변 정리가 변경되었습니다. 적용 후 비교 결과를 확인하세요.';update();}
  }
  function selectAnswer(group){
    if(!group)return;const changed=answerSelectedKey!==group.key,oldEditor=answerEditors.get(answerSelectedKey);if(changed&&oldEditor)oldEditor.scrollTop=answerDetail.scrollTop;answerSelectedKey=group.key;
    let editor=answerEditors.get(group.key);
    if(!editor){
      const panel=element('div',null,'ro-answer-editor'),heading=element('h3','선택한 원문'),original=element('div',group.originalAnswer,'ro-answer-original');
      const replacement=editable(element('textarea'),`organizer-answer-${group.key}`);replacement.setAttribute('aria-label','저장할 답변');replacement.rows=4;replacement.placeholder='비워 두면 원문을 유지합니다.';
      const quantity=editable(element('select'),`organizer-answer-quantity-${group.key}`);quantity.setAttribute('aria-label','오류 수량 처리');option(quantity,'','기존 기준');option(quantity,'include','포함');option(quantity,'exclude','제외');
      const state=answerState(group);replacement.value=state.replacementAnswer;quantity.value=state.excludeFromQuantity===true?'exclude':state.excludeFromQuantity===false?'include':'';
      const clear=checkbox('빈칸으로 바꾸기',!!state.clearAnswer,checked=>{replacement.dataset.organizerLocked=String(checked);replacement.disabled=checked;changed();});editable(clear.node,`organizer-answer-clear-${group.key}`);replacement.dataset.organizerLocked=String(!!state.clearAnswer);replacement.disabled=!!state.clearAnswer;
      const changed=()=>changeAnswerRule(group,replacement.value,quantity.value==='exclude'?true:quantity.value==='include'?false:null,true,clear.node.checked);replacement.addEventListener('input',changed);replacement.addEventListener('compositionend',changed);quantity.addEventListener('change',changed);
      const usages=element('div',null,'ro-answer-locations'),usageHeading=element('h3');
      panel.append(heading,original,field('저장할 답변',replacement),clear.wrapper,element('p','문구를 비워 두면 원문을 유지합니다. 답변을 남기지 않으려면 빈칸으로 바꾸기를 선택하세요.','ro-hint'),field('오류 수량 처리',quantity),element('p','기존 기준은 현재 예외 설정을 따릅니다. 포함을 선택하면 키워드 제외보다 우선합니다.','ro-hint'),usageHeading,usages);answerDetail.append(panel);editor={panel,replacement,quantity,clear:clear.node,original,usages,usageHeading};answerEditors.set(group.key,editor);
    }
    editor.original.textContent=group.originalAnswer;editor.usageHeading.textContent=`1차 사용 위치 · ${Number(group.fileCount||0).toLocaleString()}개 파일 / ${Number(group.rowCount||0).toLocaleString()}개 행`;
    editor.usages.replaceChildren();
    for(const location of group.locations||[]){const item=element('div'),fileName=location.fileName||basename(location.path),name=location.path?button(fileName,()=>post('excel:open',{path:location.path})):element('strong',fileName);if(location.path){name.classList.add('ro-file-link');name.setAttribute('aria-label',`원본 파일 열기: ${fileName}`);}name.title=location.path||'';item.append(name,element('span',`${location.sheet||''} · ${location.columnLetter||''}열${location.columnHeader?` (${location.columnHeader})`:''} · ${location.rowCount||0}개 행`));if(location.rowExamples?.length)item.append(element('small',`예: ${location.rowExamples.join(', ')}행`));editor.usages.append(item);}
    for(const child of answerDetail.children)child.hidden=child!==editor.panel;
    if(changed)answerDetail.scrollTop=editor.scrollTop||0;
    for(const item of answerGroups)updateAnswerRow(item);
  }
  function renderAnswerList(){
    const scroll=answerList.scrollTop,search=answerSearch.value.toLocaleLowerCase(),filtered=answerGroups.filter(group=>!search||`${group.originalAnswer}\n${answerState(group).replacementAnswer}`.toLocaleLowerCase().includes(search));
    answerPage=Math.min(answerPage,Math.max(0,Math.ceil(filtered.length/50)-1));answerRowControls.clear();
    const table=element('table'),head=element('thead'),heading=element('tr'),body=element('tbody');for(const label of ['원문 답변','저장할 문구','수량','사용'])heading.append(element('th',label));head.append(heading);table.append(head,body);
    for(const group of filtered.slice(answerPage*50,(answerPage+1)*50)){
      const row=element('tr'),original=element('td'),open=button(group.originalAnswer,()=>selectAnswer(group)),saved=element('td'),quantity=element('td'),usage=element('td',`${group.fileCount||0}개 파일\n1차 ${group.rowCount||0}개 행`);open.title=group.originalAnswer;original.append(open);row.append(original,saved,quantity,usage);body.append(row);answerRowControls.set(group.key,{node:row,button:open,saved,quantity});updateAnswerRow(group);
    }
    answerList.replaceChildren(filtered.length?table:element('p',answerCatalogLoaded?(answerGroups.length?'검색한 답변이 없습니다.':'정리할 답변이 없습니다. 답변 열을 확인하거나, 답변을 추가하지 않고 2차 결과를 저장할 수 있습니다.'):'전체 파일의 답변을 불러오는 중입니다.','ro-empty'));answerList.scrollTop=scroll;
    answerPageLabel.textContent=filtered.length?`${answerPage*50+1}–${Math.min((answerPage+1)*50,filtered.length)} / ${filtered.length.toLocaleString()}가지`:'0가지';answerPreviousPage.disabled=answerPage===0;answerNextPage.disabled=(answerPage+1)*50>=filtered.length;answerPages.hidden=filtered.length<=50;updateAnswerSummary();
    const selected=answerGroups.find(group=>group.key===answerSelectedKey)||filtered[0];if(selected)selectAnswer(selected);else for(const child of answerDetail.children)child.hidden=true;
  }
  function queueAnswerCatalog(){
    if(closed||running||pending||answerCatalogQueued||answerCatalogPromise||hasBlockedSourceHeader())return;
    if([...current.values()].some(entry=>savableMapping(entry)&&!destinationHeader(entry.feature).trim()))return;
    const signature=answerMappingSignature();if(answerCatalogSignature===signature||answerFailedSignature===signature)return;
    answerCatalogQueued=true;queueMicrotask(()=>{answerCatalogQueued=false;if(!closed&&activePane==='answers'&&!pending)void loadAnswerCatalog();});
  }
  async function loadAnswerCatalog(){
    if(closed||running)return false;
    if(answerCatalogPromise){await answerCatalogPromise;return answerCatalogSignature===answerMappingSignature();}
    await detectMappings([...current.values()]);if(closed)return false;
    if(hasBlockedSourceHeader()){lastMessage='계승할 열을 확인하세요. 파일 선택에서 답변 열을 직접 지정할 수 있습니다.';update();return false;}
    if(answerCatalogPromise){await answerCatalogPromise;return answerCatalogSignature===answerMappingSignature();}
    const base=buildMappings(false).filter(mapping=>!mapping.preserveOriginal),signature=answerMappingSignature();if(answerCatalogLoaded&&signature===answerCatalogSignature)return true;
    if(!base.length){answerGroups=[];answerCatalogLoaded=true;answerCatalogSignature=signature;renderAnswerList();update();return true;}
    const generation=++answerCatalogGeneration,work=beginProgressWork('전체 파일의 같은 답변을 모으는 중입니다.');pending++;lastMessage='연결된 파일의 답변을 모으는 중입니다.';update();
    answerCatalogPromise=(async()=>{
      try{
        const requestId=uniqueId();answerCatalogRequest=requestId;const response=await request('organize:answerRules','organize:answerRulesReady',{requestId,mappings:base});
        if(closed||generation!==answerCatalogGeneration||signature!==answerMappingSignature())return false;
        if(response.cancelled){answerFailedSignature=signature;lastMessage='답변 확인이 취소되었습니다.';return false;}
        answerGroups=(response.groups||[]).map(group=>({...group,originalAnswer:String(group.originalAnswer??'')}));answerCatalogSignature=signature;answerCatalogLoaded=true;answerFailedSignature='';
        const keys=new Set(answerGroups.map(group=>group.key));for(const [key,editor]of answerEditors)if(!keys.has(key)){editor.panel.remove();answerEditors.delete(key);}
        renderAnswerList();lastMessage='';return true;
      }catch(error){answerFailedSignature=signature;if(!closed)lastMessage=error.message;return false;}
      finally{answerCatalogRequest='';pending--;endProgressWork(work);}
    })();
    const result=await answerCatalogPromise;answerCatalogPromise=null;if(!closed)update();return result;
  }
  async function applyAnswerRules(goOutput=true){
    if(running||pending)return;const work=beginProgressWork('정리한 답변을 비교 결과에 반영하는 중입니다.');
    try{if(!await loadAnswerCatalog())return;await loadChanges(0);if(!closed&&previewSignature===JSON.stringify(buildMappings())&&!previewData?.errors?.length){if(goOutput)selectPane('output');else lastMessage='정리한 답변을 반영했습니다. 연결 확인에서 변경 내용을 확인할 수 있습니다.';update();}}
    finally{endProgressWork(work);}
  }
  async function exchangeAnswerRules(kind){
    if(running||pending)return;const work=beginProgressWork(kind==='export'?'답변 정리 양식을 저장하는 중입니다.':'답변 정리 양식을 불러오는 중입니다.');let exportedPath='';
    try{
      if(!await loadAnswerCatalog())return;
      const signature=answerCatalogSignature;pending++;update();
      try{
        const response=await request(kind==='export'?'organize:exportAnswerRules':'organize:importAnswerRules',kind==='export'?'organize:answerRulesExported':'organize:answerRulesImported',{mappings:buildMappings(true,false)});
        if(closed||response.cancelled)return;if(kind==='export')exportedPath=response.path||'';if(signature!==answerMappingSignature()){lastMessage='연결 설정이 변경되었습니다. 답변 목록을 다시 확인하세요.';return;}
        if(kind==='import'){
          const byOriginal=new Map(answerGroups.map(group=>[normalizeAnswer(group.originalAnswer),group]));let applied=0;
          for(const rule of response.rules||[]){const group=byOriginal.get(normalizeAnswer(rule.originalAnswer));if(!group)continue;changeAnswerRule(group,rule.replacementAnswer,rule.excludeFromQuantity,false,!!rule.clearAnswer);const editor=answerEditors.get(group.key);if(editor){editor.replacement.value=String(rule.replacementAnswer??'');editor.quantity.value=rule.excludeFromQuantity===true?'exclude':rule.excludeFromQuantity===false?'include':'';editor.clear.checked=!!rule.clearAnswer;editor.replacement.dataset.organizerLocked=String(!!rule.clearAnswer);editor.replacement.disabled=!!rule.clearAnswer;}applied++;if(applied%100===0){ProgressDialog.update(applied/(response.rules||[]).length*100,'불러온 답변을 목록에 반영하는 중입니다.',`${applied.toLocaleString()}개 답변`,work.owner);await new Promise(resolve=>requestAnimationFrame(resolve));if(closed)return;}}
          renderAnswerList();lastMessage=`${applied}개 답변 정리를 불러왔습니다.${response.ignoredCount?` 현재 연결에 없는 ${response.ignoredCount}개는 반영하지 않았습니다.`:''} 적용 후 비교 결과를 확인하세요.`;
        }else lastMessage='답변 정리 양식을 저장했습니다. 수정한 양식을 다시 불러올 수 있습니다.';
      }finally{pending--;if(!closed)update();}
    }catch(error){if(!closed){lastMessage=error.message;update();}}finally{endProgressWork(work);if(exportedPath&&!closed)showExportResult('답변 정리 양식을 저장했습니다.',exportedPath);}
  }
  function answerMappingSignature(){
    // A destination edit changes comparison/output only. It must not rescan every
    // source workbook on each keystroke or discard a global reply edit.
    return JSON.stringify(buildMappings(false).map(({destinationMode,destinationHeader,commonRules,...mapping})=>mapping));
  }
  function buildMappings(includeAnswerRules=true,includeCommonRules=includeAnswerRules) {
    const rulesBySource=new Map(),fallbackRules=[];
    if(includeAnswerRules&&answerCatalogSignature===answerMappingSignature()){
      for(const group of answerGroups){
        if(!answerEdits.has(group.key))continue;const rule={originalAnswer:group.originalAnswer,...answerEdits.get(group.key)};
        if(!Array.isArray(group.locations)){fallbackRules.push(rule);continue;}
        const sources=new Set(group.locations.map(location=>`${normalizeHint(location.path)}\0${String(location.sheet||'')}`));
        for(const source of sources){if(!rulesBySource.has(source))rulesBySource.set(source,[]);rulesBySource.get(source).push(rule);}
      }
    }
    return [...current.values()].map(entry => {
      const preserveOriginal = !savableMapping(entry);
      return { currentToken: entry.p.token, model: entry.model.trim(), feature: entry.feature, destinationMode, destinationHeader: destinationHeader(entry.feature).trim(), skip: false, preserveOriginal,...(!preserveOriginal&&includeCommonRules&&commonRules.length?{commonRules:commonRules.map(cloneCommonRule)}:{}),
        previous: preserveOriginal ? [] : entry.previousTokens.map(token => { const source=previous.get(token),choice=source.choice,rules=[...fallbackRules,...(rulesBySource.get(`${normalizeHint(source.p.path)}\0${String(source.p.sheet||'')}`)||[])]; return { ...choice, originalHeaders:cloneOriginalHeaders(choice.originalHeaders,source.p.columns), answerColumnsManual:!!source.answerColumnsManual, model: entry.model.trim(), answerColumns: [...choice.answerColumns], exceptionRows: [...choice.exceptionRows], exclusionKeywords: [...choice.exclusionKeywords], keywordColumns: [...choice.keywordColumns], keywordMatchMode: choice.keywordMatchMode,...(rules.length?{answerRules:rules.map(rule=>({...rule}))}:{}) }; }),
        currentAnswerColumns: preserveOriginal ? [] : [...entry.choice.answerColumns] };
    });
  }

  function syncRegisteredOutputNames(){
    syncOutputNames(previewData&&previewSignature===JSON.stringify(buildMappings())?previewData.files||[]:[]);
  }
  function syncOutputNames(files=[]) {
    const groups=new Map();for(const entry of current.values()){const key=normalizeHint(entry.p.path);if(!groups.has(key))groups.set(key,entry);}
    for(const [key,entry]of groups){
      const file=files.find(file=>normalizeHint(file.path)===key),suggested=file?.suggestedFileName||basename(entry.p.path);
      let item=outputNames.get(key);
      if(!item){item={currentToken:entry.p.token,path:entry.p.path,fileName:suggested,manual:false};outputNames.set(key,item);}
      item.currentToken=entry.p.token;
      if(!item.manual)item.fileName=suggested;
      if(!outputNameControls.has(key)){
        const row=element('label',null,'ro-output-name'),label=element('span',basename(entry.p.path)),control=input(`${basename(entry.p.path)} 저장 파일명`,item.fileName);label.title=entry.p.path;control.dataset.focusKey=`organizer-output-${entry.p.token}`;
        control.addEventListener('input',()=>{item.fileName=control.value;item.manual=true;update();});control.addEventListener('compositionend',()=>{item.fileName=control.value;item.manual=true;update();});row.append(label,control);outputList.append(row);outputNameControls.set(key,{row,control});
      }else if(!item.manual)outputNameControls.get(key).control.value=item.fileName;
    }
    for(const [key,control]of outputNameControls)if(!groups.has(key)){control.row.remove();outputNameControls.delete(key);outputNames.delete(key);}
  }

  async function chooseOutput(){
    if(closed||running||pending||!current.size)return false;const work=beginProgressWork('저장 위치와 이름을 선택하세요.'),mappings=buildMappings(),signature=JSON.stringify(mappings);pending++;lastMessage='저장 위치와 이름을 선택하세요.';update();
    try{
      const first=[...outputNames.values()][0],response=await request('organize:chooseOutput','organize:outputSelected',{mappings,folder:outputFolder||undefined,suggestedFileName:outputNames.size===1?first?.fileName:undefined});
      if(closed||response.cancelled)return false;if(signature!==JSON.stringify(buildMappings())){lastMessage='설정이 변경되었습니다. 저장 위치를 다시 선택하세요.';return false;}if(!response.folder){lastMessage='저장 위치를 선택하세요.';return false;}outputFolder=response.folder;folderInput.value=outputFolder;
      if(response.fileName){const item=[...outputNames.values()].find(item=>item.currentToken===response.currentToken)||first;if(item){item.fileName=response.fileName;item.manual=true;outputNameControls.get(normalizeHint(item.path)).control.value=item.fileName;}}
      lastMessage='저장 위치와 파일명을 확인한 뒤 적용하여 저장하세요.';selectPane('output');return true;
    }catch(error){lastMessage=error.message;return false;}finally{pending--;if(!closed)update();endProgressWork(work);}
  }

  async function loadChanges(offset=0){
    if(closed||running||!current.size)return;
    if(commonRulesStale()){previewSignature='';lastMessage='파일 또는 연결이 변경되었습니다. 답변 정리의 공통 설정을 다시 확인하세요.';update();return;}
    await detectMappings([...current.values()]);if(closed)return;
    if((answerCatalogLoaded||answerEdits.size)&&answerCatalogSignature!==answerMappingSignature()&&!await loadAnswerCatalog())return;
    const mappings=buildMappings(),signature=JSON.stringify(mappings),requestId=uniqueId();
    if(!mappings.length){previewData=null;previewSignature='';previewSummary.replaceChildren();syncOutputNames([]);selectMapping(current.get(selectedToken)||[...current.values()][0]);update();return;}
    const work=beginProgressWork('반영할 답변을 비교하는 중입니다.');
    if(previewRequestId)post('organize:cancelPreview',{requestId:previewRequestId});previewRequestId=requestId;pending++;lastMessage='이전 회신에서 반영할 답변을 확인하는 중…';update();
    try{
      const response=await request('organize:preview','organize:previewed',{requestId,mappings,limit:50,offset});
      if(closed||previewRequestId!==requestId)return;
      if(signature!==JSON.stringify(buildMappings())){lastMessage='설정이 변경되었습니다. 미리보기를 다시 확인하세요.';previewNotice.textContent=lastMessage;return;}
      if(response.cancelled){lastMessage='미리보기가 취소되었습니다.';return;}
      detailPreviewCache.clear();previewData=response;previewSignature=signature;errors=response.errors||[];
      const summary=response.summary||{};previewSummary.replaceChildren();
      for(const [label,value]of [['반영할 답변',summary.changedReplies??summary.replyRows??0],['수량 제외',summary.excluded??0],['확인 필요',summary.needsReview??0]]){const metric=element('span');metric.append(element('strong',Number(value).toLocaleString()),document.createTextNode(label));previewSummary.append(metric);}
      if(summary.commonRows)previewSummary.append(element('span',`공통 설정 ${Number(summary.commonRows).toLocaleString()}건`));
      if(summary.alreadyPresent)previewSummary.append(element('span',`이미 반영 ${Number(summary.alreadyPresent).toLocaleString()}건`));
      previewNotice.textContent=errors.length?`${errors.length}개 파일을 확인하세요. ${typeof errors[0]==='string'?errors[0]:errors[0]?.message||''}`:'2차 파일 전체를 저장합니다. 연결된 파일은 답변을 반영하고, 미연결 파일은 원본 그대로 저장합니다.';
      seedDetailPreviews(response,mappings);syncOutputNames(response.files||[]);lastMessage='';const selected=current.get(selectedToken)||[...current.values()].find(savableMapping)||[...current.values()][0];selectMapping(selected,false);await loadSelectedPreview(0,false);
    }catch(error){if(!closed&&previewRequestId===requestId){detailPreviewCache.clear();previewData=null;previewSignature='';previewSummary.replaceChildren();previewPages.hidden=true;previewScroll.replaceChildren(element('div',error.message,'ro-warning ro-preview-empty'));lastMessage=error.message;previewNotice.textContent=error.message;}}
    finally{if(previewRequestId===requestId)previewRequestId='';pending--;if(!closed)update();endProgressWork(work);}
  }

  function detailPreviewKey(mapping,offset,files=detectionFileGroups()){
    const entry=current.get(mapping.currentToken);
    return JSON.stringify([files.get(normalizeHint(entry?.p.path))?.signature,mapping,offset]);
  }
  function rememberDetailPreview(key,response){
    detailPreviewCache.delete(key);detailPreviewCache.set(key,response);
    while(detailPreviewCache.size>20)detailPreviewCache.delete(detailPreviewCache.keys().next().value);
  }
  function seedDetailPreviews(response,mappings){
    if(Number(response.offset||0)!==0)return;
    const files=detectionFileGroups();
    for(const file of response.files||[]){
      if(file.error)continue;
      for(const sheet of file.sheets||[]){
        const mapping=mappings.find(item=>item.currentToken===sheet.currentToken);if(!mapping||mapping.preserveOriginal||sheet.sampleRows==null)continue;
        const total=Number(sheet.sampleRows),rows=(response.rows||[]).filter(row=>row.currentToken===sheet.currentToken);
        if(rows.length<Math.min(50,total))continue;
        rememberDetailPreview(detailPreviewKey(mapping,0,files),{rows:rows.slice(0,50),summary:sheet,totalRows:total,offset:0,errors:[]});
      }
    }
  }
  function renderSelectedPreview(response,offset){
    const rows=response.rows||[],table=element('table'),head=element('thead'),heading=element('tr'),body=element('tbody');for(const label of ['검토 항목','반영할 답변','처리'])heading.append(element('th',label));head.append(heading);table.append(head,body);
    for(const row of rows){const tr=element('tr'),identity=element('td'),answer=element('td'),disposition=element('td',row.status||'확인 필요');identity.append(element('strong',row.id?'ID '+row.id:row.item||'검토 결과'),element('small',`${row.row||''}행 · ${row.item||''}`));answer.append(element('span',(row.resultDestination??row.answer)||'(빈칸)'),element('small',`${row.destinationHeader||'비고'}에 반영`));if(row.commonApplied)disposition.append(element('small','공통 설정 적용'));if(row.currentDestination)answer.append(element('small','기존: '+row.currentDestination));if(row.exclusionReason)disposition.append(element('small',row.exclusionReason));tr.append(identity,answer,disposition);body.append(tr);}
    const summary=response.summary||{},noMatchingIssues=summary.matched===0&&Number(summary.unmatched)>0&&summary.quantityKnown!==false&&Number(summary.excluded||0)===0;
    const emptyMessage=noMatchingIssues
      ? `계승할 이전 답변이 없습니다. 2차 오류 ${Number(summary.actionable||0).toLocaleString()}건을 제외 없이 저장합니다.`
      : '이 파일에 새로 반영할 답변이 없습니다. 2차 결과와 기존 답변은 유지하여 저장합니다.';
    previewScroll.replaceChildren(rows.length?table:element('div',emptyMessage,'ro-preview-empty'));previewScroll.scrollTop=0;
    const total=Number(response.totalRows||rows.length);pageLabel.textContent=total?`${offset+1}–${Math.min(offset+rows.length,total)} / ${total.toLocaleString()}건`:'0건';previewPages.hidden=total<=50;previousPage.disabled=offset<=0;nextPage.disabled=offset+rows.length>=total;
  }
  function showDetailComparisonAction(){
    const message=element('div',null,'ro-preview-empty');message.append(element('p','파일 연결을 확인했습니다. 답변 비교로 이 파일을 확인하거나, 답변 정리에서 전체 파일의 답변을 모으세요.'));
    const compare=button('이 파일 답변 비교',()=>loadSelectedPreview(0));compare.dataset.action='compare-selected';compare.disabled=running||!!pending;message.append(compare);previewScroll.replaceChildren(message);pageLabel.textContent='';previewPages.hidden=true;
  }
  async function loadSelectedPreview(offset=0,allowRequest=true){
    const entry=current.get(selectedToken),generation=++detailGeneration;previewOffset=offset;previewPages.hidden=true;
    if(detailRequestId)post('organize:cancelPreview',{requestId:detailRequestId});detailRequestId='';
    if(commonRulesStale()){previewScroll.replaceChildren(element('div','파일 또는 연결이 변경되었습니다. 답변 정리의 공통 설정을 다시 확인하세요.','ro-preview-empty'));return;}
    if(!entry||!savableMapping(entry)){previewScroll.replaceChildren(element('div',entry?'이 시트에는 이전 답변을 반영하지 않고 원본 내용을 그대로 저장합니다. 필요하면 아래에서 1차 회신을 연결하세요.':'파일을 선택하세요.','ro-preview-empty'));return;}
    if(previewData&&previewSignature===JSON.stringify(buildMappings())){
      const file=(previewData.files||[]).find(item=>normalizeHint(item.path)===normalizeHint(entry.p.path));
      const error=file?.error||(!file&&previewData.errors?.[0]);
      if(error){previewScroll.replaceChildren(element('div',typeof error==='string'?error:error.message||'파일을 다시 확인하세요.','ro-warning ro-preview-empty'));pageLabel.textContent='';return;}
    }
    let mapping=buildMappings().find(item=>item.currentToken===entry.p.token),key=detailPreviewKey(mapping,offset),cached=detailPreviewCache.get(key);
    if(!cached&&offset===0&&previewData&&previewSignature===JSON.stringify(buildMappings())){seedDetailPreviews(previewData,[mapping]);cached=detailPreviewCache.get(key);}
    if(cached){rememberDetailPreview(key,cached);renderSelectedPreview(cached,offset);return;}
    if(!allowRequest){showDetailComparisonAction();return;}
    await detectMappings([entry]);if(closed||generation!==detailGeneration||selectedToken!==entry.p.token||!savableMapping(entry))return;
    if((answerCatalogLoaded||answerEdits.size)&&answerCatalogSignature!==answerMappingSignature()&&!await loadAnswerCatalog())return;
    if(closed||generation!==detailGeneration||selectedToken!==entry.p.token||!savableMapping(entry))return;
    mapping=buildMappings().find(item=>item.currentToken===entry.p.token);key=detailPreviewKey(mapping,offset);cached=detailPreviewCache.get(key);
    if(cached){rememberDetailPreview(key,cached);renderSelectedPreview(cached,offset);return;}
    const work=beginProgressWork('선택한 파일의 답변을 확인하는 중입니다.');
    const signature=JSON.stringify(mapping),requestId=uniqueId();detailRequestId=requestId;previewScroll.setAttribute('aria-busy','true');
    try{
      const response=await request('organize:preview','organize:previewed',{requestId,mappings:[mapping],limit:50,offset});
      if(closed||generation!==detailGeneration||selectedToken!==entry.p.token||signature!==JSON.stringify(buildMappings().find(item=>item.currentToken===entry.p.token)))return;
      if(response.cancelled)return;if(response.errors?.length)throw Error(response.errors[0]);
      if(key!==detailPreviewKey(mapping,offset))return;
      rememberDetailPreview(key,response);renderSelectedPreview(response,offset);
    }catch(error){if(!closed&&generation===detailGeneration){previewScroll.replaceChildren(element('div',error.message,'ro-warning ro-preview-empty'));previewSignature='';lastMessage=error.message;update();}}
    finally{if(generation===detailGeneration){detailRequestId='';previewScroll.removeAttribute('aria-busy');}endProgressWork(work);}
  }

  async function run() {
    if (closed) return;
    update(); if (runButton.disabled) return;
    // Reuse the configured folder and names; prompt only when no folder is set.
    if (!outputFolder.trim() && !await chooseOutput()) return;
    if (closed) return;
    update();if(runButton.disabled||!outputFolder.trim())return;
    const mappings=buildMappings(),output={folder:outputFolder.trim(),targets:[...outputNames.values()].map(item=>({currentToken:item.currentToken,fileName:item.fileName}))};
    running = true; runId = uniqueId(); resultHost.replaceChildren(); cancelButton.disabled = false;
    runProgressWork=beginProgressWork('엑셀 결과를 저장하는 중입니다.');registerProgressRequest(runId,'organize:run');
    lastMessage = '선택한 위치에 결과를 저장하는 중…'; update();
    post('organize:run', { requestId: runId, mappings, output, registration:buildRegistration() });
  }
  function showResultDialog(){
    if(closed||!lastRunResult)return;resultDialogReturnFocus=document.activeElement;
    if(!resultDialog.open)resultDialog.showModal();resultCloseButton.focus({preventScroll:true});
  }
  function showExportResult(message,path){
    if(closed||!path)return;
    showExcelSavedDialog(message,path,openedPath=>{if(!closed)post('excel:open',{path:openedPath});},{description:'저장한 엑셀 파일을 바로 여시겠습니까?'});
    exportResultDialog=document.querySelector('.excel-dialog-backdrop');
  }
  function openSavedResult(){
    const files=lastRunResult?.files||[];if(closed||!files.length)return;
    const path=files.length===1?files[0].path:lastRunResult.outputFolder;
    if(path)post('excel:open',{path});
  }
  function appendResultSource(host,path,previousSource=false){
    const value=typeof path==='string'?path:'',name=basename(value),line=element('small',null,'ro-result-source');
    line.append(element('span',previousSource?'1차:':'2차:','ro-result-source-label'));
    // Completed results carry absolute source paths. Never turn a missing path or
    // a filename-only legacy value into a link to the current working directory.
    const absolute=/^(?:[a-z]:[\\/]|[\\/]{2}[^\\/]+[\\/][^\\/]+[\\/]|\/[^/])/i.test(value);
    if(value&&name&&absolute){
      const open=button(name,()=>{if(!closed)post('excel:open',{path:value});});open.classList.add('ro-file-link');open.title=value;
      open.setAttribute('aria-label',`${previousSource?'1차 회신':'2차 입력'} 파일 열기: ${name}`);line.append(open);
    }else{const text=element('span',name||'경로 확인 필요');text.title=value;line.append(text);}
    host.append(line);
  }
  function renderRunResult(data){
    const summary=data.summary||{},files=data.files||[],runErrors=data.errors||[],cancelled=!!data.cancelled;
    const saved=summary.savedFiles??files.length,failed=summary.failedFiles??runErrors.length;
    const registered=Number(summary.registeredCurrentFiles??lastRunResult?.registeredCurrentFiles??files.length),originalFiles=Number(summary.preservedOriginalFiles??files.filter(file=>file.preservedOriginal).length);
    const unknownFiles=Number(summary.quantityUnknownFiles??files.filter(file=>file.quantityKnown===false).length),knownFiles=files.filter(file=>file.quantityKnown!==false&&!file.preservedOriginal).length;
    resultDialogTitle.textContent=cancelled?'엑셀 정리가 중단되었습니다':failed||data.error?'엑셀 정리 결과를 확인하세요':'엑셀 정리가 완료되었습니다';
    resultDialogBody.replaceChildren();
    const metrics=element('div',null,'ro-result-metrics');
    for(const [label,value]of [['저장 완료',saved],['저장 실패',failed],['미처리',summary.notProcessedFiles??0],[unknownFiles?'집계된 오류':'최종 오류',unknownFiles&&!knownFiles?'—':summary.actionable??files.filter(file=>file.quantityKnown!==false).reduce((sum,file)=>sum+Number(file.actionable||0),0)]]){const item=element('div');item.append(element('strong',typeof value==='number'?value.toLocaleString():value),element('span',label));metrics.append(item);}
    resultDialogBody.append(metrics);
    resultDialogBody.append(element('p',`등록한 2차 ${registered}개 / 저장 완료 ${saved}개 = 답변 반영 대상 ${Math.max(0,saved-originalFiles)}개 + 원본 유지 ${originalFiles}개`,'ro-hint'));
    if(registered!==saved)resultDialogBody.append(element('p',`등록한 2차 파일 중 ${Math.max(0,registered-saved)}개가 저장되지 않았습니다. 아래 처리 상태를 확인하세요.`,'ro-warning'));
    resultOpenButton.hidden=!files.length;resultOpenButton.textContent=files.length===1?'파일 열기':'저장 폴더 열기';
    if(files.length)resultDialogBody.append(element('p',files.length===1?'저장한 엑셀 파일을 바로 여시겠습니까?':'저장 폴더를 바로 여시겠습니까?','ro-result-open-question'));
    const missingPrevious=Number(summary.unlinkedPreviousFiles||0),missingCurrent=Number(summary.unlinkedCurrentFiles||0),excluded=Number(summary.excludedFiles||0);
    if(missingPrevious||missingCurrent||excluded)resultDialogBody.append(element('p',`미연결: 1차 회신 ${missingPrevious}개 / 2차 결과 ${missingCurrent}개${excluded?` · 원본 유지 선택 ${excluded}개`:''}`,'ro-hint'));
    if(originalFiles)resultDialogBody.append(element('p',`원본 유지 ${originalFiles}개 파일은 기존 파일명과 오류 수량을 유지하며, 수량을 다시 계산하지 않습니다.`,'ro-hint'));
    if(unknownFiles>originalFiles)resultDialogBody.append(element('p',`추가로 수량 확인이 필요한 ${unknownFiles-originalFiles}개 파일은 오류 합계에 포함하지 않았습니다.`,'ro-warning'));
    if(data.outputFolder)resultDialogBody.append(element('p',`저장 위치: ${data.outputFolder}`,'ro-hint'));
    resultDialogBody.append(element('p','요약 엑셀에는 저장 당시의 답변 정리 기준, 공통 설정과 파일별 처리 결과가 포함됩니다.','ro-hint'));
    const entries=summary.entries?.length?summary.entries:files.map(file=>({status:file.preservedOriginal?'원본 유지':'저장 완료',sourcePath:file.sourcePath||'',previousPaths:file.previousPaths,outputPath:file.path,detected:file.detected,excluded:file.excluded,actionable:file.actionable,quantityKnown:file.quantityKnown,preservedOriginal:!!file.preservedOriginal,message:file.disposition}));
    if(entries.length){
      const table=element('table'),head=element('thead'),tr=element('tr'),body=element('tbody');for(const label of ['파일','처리 상태','최종 오류'])tr.append(element('th',label));head.append(tr);table.append(head,body);
      for(const entry of entries){const row=element('tr'),name=element('td'),state=element('td',entry.status||'확인 필요'),quantity=element('td',entry.preservedOriginal?'원본 유지':entry.quantityKnown===false?'확인 필요':entry.outputPath?String(entry.actionable??0):'—');
        if(entry.outputPath){const open=button(basename(entry.outputPath),()=>post('excel:open',{path:entry.outputPath}));open.title=entry.outputPath;name.append(open);}
        const previousOnly=entry.kind==='unlinked_previous'||entry.kind==='unused_previous';
        appendResultSource(name,entry.sourcePath,previousOnly);
        if(Array.isArray(entry.previousPaths))for(const path of entry.previousPaths)appendResultSource(name,path,true);
        if(entry.message)state.append(element('small',entry.message));row.append(name,state,quantity);body.append(row);
      }resultDialogBody.append(table);
    }
    const messages=new Set([data.error,...runErrors,...(summary.errors||[])].filter(Boolean).map(error=>typeof error==='string'?error:error.message||JSON.stringify(error)));
    for(const message of messages)resultDialogBody.append(element('p',message,'ro-warning'));
    resultHost.replaceChildren(element('p',`저장 완료 ${saved}개${failed?` · 실패 ${failed}개`:''}${cancelled?' · 작업 중단':''}`,'ro-hint'),button('저장 결과 다시 보기',showResultDialog));
    if(data.outputFolder)resultHost.append(button('저장 폴더 열기',()=>post('organize:open-folder',{path:data.outputFolder})));
    summaryExportButton.disabled=!lastRunResult?.runRequestId;
  }
  async function exportSummary(){
    if(closed||pending||running||!lastRunResult?.runRequestId)return;
    const result=lastRunResult,scroll=resultDialogBody.scrollTop,wasOpen=resultDialog.open;if(wasOpen)resultDialog.close();
    const work=beginProgressWork('결과 요약 엑셀을 저장하는 중입니다.');let exportedPath='';pending++;update();
    try{const response=await request('organize:exportSummary','organize:summaryExported',{runRequestId:result.runRequestId});if(closed)return;
      if(!response.cancelled){exportedPath=response.path||'';lastMessage='결과 요약 엑셀을 저장했습니다.';resultDialogBody.append(element('p',`요약 저장: ${response.path}`,'ro-hint'));}
    }catch(error){if(!closed){lastMessage=error.message;resultDialogBody.append(element('p',error.message,'ro-warning'));}}
    finally{pending--;endProgressWork(work);if(!closed){update();if(wasOpen&&lastRunResult===result){showResultDialog();resultDialogBody.scrollTop=scroll;}if(exportedPath)showExportResult('결과 요약 엑셀을 저장했습니다.',exportedPath);}}
  }
  listen('organize:progress', data => {
    requests.get(data.requestId)?.renew?.();applyRequestProgress(data.requestId,data);
    if (!running || data.requestId !== runId) return;
    lastMessage = data.message || `결과 정리 ${data.completed || 0} / ${data.total || 0}`; update();
  });
  listen('organize:done', data => {
    if (!running || data.requestId !== runId) return;
    finishProgressRequest(runId,!data.error&&!data.cancelled);endProgressWork(runProgressWork);runProgressWork=null;
    running = false;lastRunResult={...data,registeredCurrentFiles:data.summary?.registeredCurrentFiles??new Set([...current.values()].map(entry=>normalizeHint(entry.p.path))).size,runRequestId:data.summary?.runRequestId||runId};runId = ''; errors = data.errors || [];
    const files = data.files || [];
    lastMessage = data.cancelled ? `정리가 중단되었습니다.${files.length ? ` 완료된 ${files.length}개 파일은 저장되어 있습니다.` : ''}`
      : data.error ? data.error : `${files.length}개 결과 파일을 저장했습니다.${errors.length ? ` ${errors.length}개 항목은 확인이 필요합니다.` : ''}`;
    renderRunResult(data);
    selectPane('output');
    update();showResultDialog();
  });
  update();
  return function dispose() {
    if (closed) return; closed = true;
    if(exportResultDialog){if(exportResultDialog.open)exportResultDialog.close();exportResultDialog.remove();exportResultDialog=null;}
    if(resultDialog.open)resultDialog.close();resultDialog.remove();
    if(commonDialog.open)commonDialog.close();commonDialog.remove();
    if (running && runId) post('organize:cancel', { requestId: runId });
    if(previewRequestId)post('organize:cancelPreview',{requestId:previewRequestId});
    if(detailRequestId)post('organize:cancelPreview',{requestId:detailRequestId});detailGeneration++;
    if (importRequestIds.size) post('organize:cancel-imports', { requestIds: [...importRequestIds] });
    for (const off of unsubscribers) off(); unsubscribers.clear();
    for (const { timer, reject } of requests.values()) { clearTimeout(timer); reject(Error('결과 정리 화면이 닫혔습니다.')); } requests.clear();
    progressRequests.clear();if(activeProgressWork){ProgressDialog.hide(activeProgressWork.owner);activeProgressWork=null;}runProgressWork=null;
    if (allTokens.size) post('repeat:release', { tokens: [...allTokens] });
  };
}
