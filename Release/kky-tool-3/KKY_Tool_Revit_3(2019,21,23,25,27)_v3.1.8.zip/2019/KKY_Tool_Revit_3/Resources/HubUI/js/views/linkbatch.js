import { div, clear, getLastExcelExportLocale, showCompletionSummaryDialog, showExcelSavedDialog, toast } from '../core/dom.js?v=20260731parameterexport1';
import { onHost, post } from '../core/bridge.js';
import { getCurrentTheme } from '../core/theme.js';
import { ProgressDialog } from '../core/progress.js?v=20260701a';
import { attachRvtDropZone } from '../core/rvtDrop.js';
import { attachExcelDropZone } from '../core/excelDrop.js';

const STORAGE_KEY = 'kky.settings.linkbatch.v1';
const defaults = { placement: 'origin', referenceType: 'overlay', typeWorkset: '', instanceWorkset: '', sameWorkset: true, createMissingWorksets: false };
const placementLabels = { origin: '내부 원점 대 내부 원점', shared: '공유 좌표 기준', center: '중심 대 중심', basepoint: '프로젝트 기준점 대 프로젝트 기준점' };
const placementNotes = { origin: '링크와 대상 문서의 내부 원점과 축을 맞춥니다.', shared: '저장된 공유 좌표를 사용합니다. 공유 관계가 없으면 오류로 표시합니다.', center: '활성 문서: 현재 모델 뷰 · 여러 RVT: 시작/3D 뷰 (없으면 전체 모델)', basepoint: '프로젝트 기준점을 한 번 맞춥니다. 이후 기준점 이동은 따라가지 않습니다.' };
const placementLabel = value => str(value).toLowerCase()==='keep'?'현재 위치 유지':placementLabels[str(value).toLowerCase()] || String(value || '배치 미지정');
const leaf = (path) => { const value=String(path || '').split(/[\\/]/).pop() || '';try{return decodeURIComponent(value);}catch{return value;} };
const str = (value) => String(value == null ? '' : value);
const cloud = value => /^acc:/i.test(str(value));
const sourceKey = value => {if(!cloud(value))return str(value).trim().replace(/\\/g,'/').toLowerCase();try{const u=new URL(value),p=u.pathname.split('/');return `acc|${u.hostname}|${p[1]}|${p[2]}|${p[3]}`.toLowerCase();}catch{return str(value).toLowerCase();}};
const uniquePaths = (paths) => [...new Map((Array.isArray(paths) ? paths : []).map(p => str(p).trim()).filter(p => /\.rvt$/i.test(p)).map(p => [sourceKey(p), p])).values()];
const readPreferences = () => { try { return { ...defaults, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') }; } catch { return { ...defaults }; } };

// Editors are mounted once. Host context/progress/results and preference echoes update
// their own surfaces, never the form subtree, so focus, IME and scroll stay intact.
export function renderLinkBatch(root, options = {}) {
  clear(root);
  const standalone = options.standalone === true;
  const state = { mode: 'active', links: [], hosts: [], rows: [], modeDrafts: new Map(), documentDrafts: new Map(), documents: [], worksetNames: [], selectedDocumentKey: '', explicitDocumentSelection: false, contextPending: false, locations: {}, selectedFiles: { hosts: new Set(), links: new Set() }, fileSearch: { hosts: '', links: '' }, worksetMode: 'common', fileWorksets: new Map(), worksetSearch: '', rowSearch: '', importedContextToken: '', workbookPath: '', importFailed: false, context: {}, contextToken: '', busy: '', disposed: false, lastResult: null, ...readPreferences() };
  const display = path => cloud(path)?state.locations[path]||`ACC · ${leaf(path)}`:str(path);
  const page = div('linkbatch-page');
  page.dataset.linkbatchScrollKey = 'workspace';
  page.innerHTML = `
    <section class="linkbatch-card linkbatch-targets">
      <div class="linkbatch-card-head"><div><span class="linkbatch-step">01 · 대상</span><h2>작업 대상</h2></div><div class="linkbatch-actions"><span class="linkbatch-status" role="status" data-status>준비됨</span><button type="button" class="btn btn--secondary" data-refresh>새로고침</button></div></div>
      <p class="linkbatch-note">링크를 배치할 문서를 선택하세요.</p>
      <div class="rvt3-mode-grid linkbatch-target-modes" role="tablist" aria-label="작업 대상">
        <button type="button" class="rvt3-mode-card is-active" role="tab" id="linkbatch-active-mode" data-mode="active" aria-selected="true" aria-controls="linkbatch-active-target"><strong>활성 문서</strong><span>열린 문서의 링크를 확인하고 수정합니다.</span></button>
        <button type="button" class="rvt3-mode-card" role="tab" id="linkbatch-batch-mode" data-mode="batch" aria-selected="false" aria-controls="linkbatch-batch-target" tabindex="-1"><strong>여러 RVT</strong><span>선택한 파일에 일괄 추가합니다.</span></button>
      </div>
      <div class="linkbatch-target-detail" id="linkbatch-active-target" role="tabpanel" aria-labelledby="linkbatch-active-mode" data-active-panel><label class="linkbatch-field">열린 RVT 문서<select class="feature-input" data-document-select data-linkbatch-focus-key="selected-document" aria-label="열린 RVT 문서"><option value="">문서를 확인하고 있습니다.</option></select></label><strong data-document>활성 문서를 확인하고 있습니다.</strong><p class="linkbatch-note" data-document-note>문서를 선택하면 기존 링크와 웍셋을 표시합니다.</p></div>
      <div class="linkbatch-target-detail" id="linkbatch-batch-target" role="tabpanel" aria-labelledby="linkbatch-batch-mode" data-batch-panel hidden>
        <div class="linkbatch-actions"><button type="button" class="btn btn--primary" data-manage-hosts>대상 RVT 등록·관리</button><span class="linkbatch-count" data-host-count>0개</span></div>
        <p class="linkbatch-note">별도 목록 창에서 로컬·ACC 모델을 여러 개 등록하고 확인하세요.</p>
        <div class="linkbatch-list-tools" data-list-tools="hosts"><label class="linkbatch-search"><span>대상 검색</span><input type="search" class="feature-input" data-file-search="hosts" data-linkbatch-focus-key="host-search" placeholder="파일명 또는 경로 검색" autocomplete="off"></label><div class="linkbatch-list-selection"><label><input type="checkbox" data-select-visible="hosts" data-linkbatch-focus-key="host-select-visible"> 표시 항목 선택</label><span data-selection-count="hosts">0개 선택</span><button type="button" class="btn" data-remove-selected="hosts">선택 제거</button><button type="button" class="btn" data-clear-hosts>전체 비우기</button></div></div>
        <div class="linkbatch-file-list" data-host-files data-linkbatch-drop="hosts" data-linkbatch-scroll-key="hosts"></div>
        <p class="linkbatch-note">새로 등록한 파일의 작업을 추가합니다. 기존 작업의 행별 설정은 유지합니다.</p>
      </div>
    </section>
    <section class="linkbatch-card" data-simple-panel>
      <div class="linkbatch-card-head"><div><span class="linkbatch-step">02 · 파일</span><h2 data-link-list-title>현재 LINK 목록</h2></div><span class="linkbatch-count" data-link-count>0개</span></div>
      <div class="linkbatch-actions"><button type="button" class="btn btn--primary" data-manage-links>링크 RVT 등록·관리</button></div>
      <p class="linkbatch-note" data-link-list-note>기존 링크의 웍셋을 변경하거나 로컬·ACC 링크를 추가하세요. 기존 링크의 위치와 하위 링크 설정은 유지합니다.</p>
      <div class="linkbatch-list-tools" data-list-tools="links"><label class="linkbatch-search"><span>링크 검색</span><input type="search" class="feature-input" data-file-search="links" data-linkbatch-focus-key="link-search" placeholder="파일명 또는 경로 검색" autocomplete="off"></label><div class="linkbatch-list-selection"><label><input type="checkbox" data-select-visible="links" data-linkbatch-focus-key="link-select-visible"> 표시 항목 선택</label><span data-selection-count="links">0개 선택</span><button type="button" class="btn" data-remove-selected="links">선택 제거</button><button type="button" class="btn" data-clear-links>전체 비우기</button></div></div>
      <div class="linkbatch-file-list" data-link-files data-linkbatch-drop="links" data-linkbatch-scroll-key="links"></div>
      <div class="linkbatch-options">
        <label class="linkbatch-field">배치 방식 (현재 작업 전체)<select class="feature-input" data-option="placement" data-linkbatch-focus-key="placement" aria-describedby="linkbatch-placement-note"><option value="origin">자동 - 내부 원점 대 내부 원점</option><option value="shared">자동 - 공유 좌표 기준</option><option value="center">자동 - 중심 대 중심</option><option value="basepoint">자동 - 프로젝트 기준점 대 프로젝트 기준점</option></select></label>
        <label class="linkbatch-field">하위 링크 포함 방식 (현재 작업 전체)<select class="feature-input" data-option="referenceType" data-linkbatch-focus-key="referenceType" aria-describedby="linkbatch-reference-note"><option value="overlay">포함하지 않음 · 중첩 (Overlay)</option><option value="attachment">함께 포함 · 부착 (Attachment)</option></select></label>
        <label class="linkbatch-field">타입 웍셋<input class="feature-input" data-option="typeWorkset" data-linkbatch-focus-key="typeWorkset" list="linkbatch-worksets" placeholder="기본 웍셋 사용" autocomplete="off"></label>
        <label class="linkbatch-field">인스턴스 웍셋<input class="feature-input" data-option="instanceWorkset" data-linkbatch-focus-key="instanceWorkset" list="linkbatch-worksets" placeholder="기본 웍셋 사용" autocomplete="off"></label>
      </div>
      <datalist id="linkbatch-worksets"></datalist>
      <div class="linkbatch-checks">
        <label><input type="checkbox" data-option="sameWorkset" data-linkbatch-focus-key="sameWorkset"> 타입과 인스턴스에 같은 웍셋 사용</label>
        <label><input type="checkbox" data-option="createMissingWorksets" data-linkbatch-focus-key="createMissingWorksets"> 지정한 웍셋이 없으면 생성 (현재 작업 전체)</label>
      </div>
      <p class="linkbatch-note" data-workset-note>웍셋을 비우면 문서의 기본값을 사용합니다. 목록에서 선택하거나 이름을 입력하세요.</p>
      <p class="linkbatch-note" id="linkbatch-placement-note" data-placement-note>링크와 대상 문서의 내부 원점을 맞춥니다.</p>
      <p class="linkbatch-note" id="linkbatch-reference-note" data-reference-note></p>
    </section>
    <section class="linkbatch-excel-tools" data-excel-panel aria-label="Excel 일괄 등록">
      <div class="linkbatch-actions"><span class="linkbatch-excel-label">Excel 편집</span><button type="button" class="btn btn--secondary" data-export>현재 설정 Excel 내보내기</button><button type="button" class="btn btn--secondary" data-import>Excel 불러오기</button><span class="linkbatch-count" data-import-count hidden></span></div>
      <p class="linkbatch-note" data-excel-note>링크 경로를 입력한 양식을 불러오세요. 배치 방식과 웍셋은 선택 사항입니다.</p>
      <div class="linkbatch-workbook" data-workbook>불러온 Excel이 없습니다.</div>
      <div class="linkbatch-table-wrap" data-import-wrap hidden data-linkbatch-scroll-key="import"><table class="linkbatch-table linkbatch-import-table"><thead><tr><th>실행 상태</th><th>대상 RVT</th><th>링크 파일</th><th>배치 · 하위 링크</th><th>타입 · 인스턴스 웍셋</th><th>확인 사항</th></tr></thead><tbody data-import-body></tbody></table></div>
    </section>
    <section class="linkbatch-card linkbatch-run">
      <div class="linkbatch-run-copy"><h2>링크 실행</h2><p class="linkbatch-note" data-summary>링크할 RVT 파일을 선택하세요.</p></div>
      <div class="linkbatch-actions"><button type="button" class="btn btn--secondary" data-check>입력 검증</button><button type="button" class="btn btn--primary" data-run>일괄 링크</button><button type="button" class="btn btn--secondary" data-cancel hidden>중지 요청</button></div>
      <p class="linkbatch-note" data-save-note>활성 문서의 변경은 직접 저장하세요.</p>
      <p class="linkbatch-feedback" role="status" aria-live="polite" data-feedback></p>
    </section>
    <details class="linkbatch-guide"><summary>배치 방식과 웍셋 안내</summary><ul><li>내부 원점: 링크와 호스트의 내부 원점과 축을 맞춥니다.</li><li>공유 좌표: 파일에 저장된 공유 좌표를 기준으로 배치합니다. 공유 관계를 사용할 수 없으면 해당 행을 오류로 표시합니다.</li><li>중심: 대상 문서의 모델 뷰와 링크 모델의 형상 중심을 맞춥니다.</li><li>프로젝트 기준점: 두 문서의 프로젝트 기준점을 한 번 맞춥니다.</li><li>중첩: 현재 호스트를 다른 파일에 링크할 때 하위 링크를 전달하지 않습니다. 부착: 하위 링크를 함께 전달합니다.</li><li>타입 웍셋은 링크 정의에, 인스턴스 웍셋은 배치된 링크 객체에 적용합니다. 작업 공유 문서에서만 웍셋을 지정할 수 있습니다.</li><li>이미 배치한 링크는 중복 생성하지 않고 결과에 표시합니다. 여러 RVT 실행은 대상 파일의 저장 또는 동기화를 포함합니다.</li></ul></details>`;
  // Settings stay mounted while Shell3 moves the execution panel into its column.
  const workspace=div('linkbatch-workspace');workspace.dataset.linkbatchScrollKey='workspace';
  const runPanel=div('linkbatch-run-panel');runPanel.dataset.linkbatchScrollKey='run-panel';
  const targetCard=page.querySelector('.linkbatch-targets'),simpleCard=page.querySelector('[data-simple-panel]'),excelCard=page.querySelector('[data-excel-panel]'),runCard=page.querySelector('.linkbatch-run');
  targetCard.querySelector(':scope > .linkbatch-note').remove();
  targetCard.querySelector('[data-document-note]').classList.add('linkbatch-path');
  simpleCard.querySelector('.linkbatch-card-head').append(simpleCard.querySelector('.linkbatch-actions'));
  const worksetCard=div('linkbatch-card linkbatch-worksets');
  worksetCard.innerHTML='<div class="linkbatch-card-head"><div><span class="linkbatch-step">03 · 웍셋</span><h2>링크를 배치할 웍셋</h2></div></div><div class="linkbatch-options" data-workset-fields></div>';
  ['typeWorkset','instanceWorkset'].forEach(key=>worksetCard.querySelector('[data-workset-fields]').append(page.querySelector('[data-option="'+key+'"]').closest('label')));
  worksetCard.append(page.querySelector('#linkbatch-worksets'),page.querySelector('.linkbatch-checks'),page.querySelector('[data-workset-note]'),page.querySelector('.linkbatch-guide'));
  [targetCard,simpleCard,worksetCard].forEach((card,index)=>card.querySelector('.linkbatch-step').textContent=String(index+1).padStart(2,'0'));
  const importedCard=div('linkbatch-card linkbatch-import-review');
  importedCard.className='linkbatch-card linkbatch-operations';
  importedCard.innerHTML='<div class="linkbatch-card-head"><div><h2>링크 작업 목록</h2><p class="linkbatch-note">각 행의 대상·링크·배치·웍셋으로 실행합니다. Excel에서 가져온 행도 여기서 수정할 수 있습니다.</p></div><button type="button" class="btn" data-add-row>작업 행 추가</button></div><div class="linkbatch-operation-tools"><label class="linkbatch-search"><span>작업 검색</span><input class="feature-input" type="search" data-row-search placeholder="대상·링크 파일 또는 웍셋 검색" autocomplete="off"></label><span class="linkbatch-count" data-operation-count></span></div><div class="linkbatch-operation-list" data-operation-list data-linkbatch-scroll-key="operations" tabindex="0" role="group" aria-label="편집 가능한 링크 작업 목록"></div>';
  const pagination=div('linkbatch-operation-pagination');pagination.innerHTML='<span class="linkbatch-note">한 번에 최대 100개 작업을 표시합니다. Excel 저장·검증·실행은 전체 작업에 적용합니다.</span><button type="button" class="btn" data-rows-prev>이전 목록</button><button type="button" class="btn" data-rows-next>다음 목록</button>';importedCard.append(pagination);
  excelCard.querySelector('[data-import-wrap]').remove();
  excelCard.querySelector('[data-export]').textContent='현재 설정 Excel 내보내기';
  excelCard.querySelector('.linkbatch-excel-label').textContent='Excel 편집';
  // Keep configuration above the long file lists after the registration dialog closes.
  const placementFields=simpleCard.querySelector('.linkbatch-options');
  worksetCard.querySelector('h2').textContent='배치 방식과 웍셋';
  worksetCard.querySelector('.linkbatch-step').textContent='02';
  simpleCard.querySelector('.linkbatch-step').textContent='03';
  worksetCard.insertBefore(placementFields,worksetCard.querySelector('[data-workset-fields]'));
  const placementHelp=div('linkbatch-placement-help');
  placementHelp.append(page.querySelector('[data-placement-note]'),page.querySelector('[data-reference-note]'));
  worksetCard.querySelector('.linkbatch-guide').append(placementHelp);
  const worksetModes=div('linkbatch-workset-modes');
  worksetModes.setAttribute('role','radiogroup');worksetModes.setAttribute('aria-label','웍셋 지정 방식');
  worksetModes.innerHTML='<label><input type="radio" name="linkbatch-workset-mode" data-workset-mode="common" value="common" checked> 모든 링크에 공통 지정</label><label><input type="radio" name="linkbatch-workset-mode" data-workset-mode="files" value="files"> 링크 파일별 지정</label>';
  const commonWorksets=document.createElement('details');commonWorksets.className='linkbatch-workset-bulk';commonWorksets.dataset.worksetBulk='';commonWorksets.open=true;
  commonWorksets.innerHTML='<summary>여러 파일에 같은 웍셋 적용</summary><div class="linkbatch-workset-common"></div>';
  const commonBody=commonWorksets.querySelector('div'),sameCheck=worksetCard.querySelector('[data-option="sameWorkset"]').closest('label');
  commonBody.append(worksetCard.querySelector('[data-workset-fields]'),sameCheck);
  const applyWorksets=document.createElement('button');applyWorksets.type='button';applyWorksets.className='btn';applyWorksets.dataset.applyWorksets='';applyWorksets.textContent='위 웍셋을 모든 링크 파일에 적용';commonBody.append(applyWorksets);
  const fileWorksetsPane=div('linkbatch-per-file-worksets');fileWorksetsPane.dataset.fileWorksets='';
  fileWorksetsPane.innerHTML='<div class="linkbatch-workset-tools"><label class="linkbatch-search"><span>파일 검색</span><input type="search" class="feature-input" data-workset-search placeholder="파일명 또는 경로 검색" autocomplete="off"></label><span class="linkbatch-count" data-workset-count></span></div><div class="linkbatch-workset-list" data-workset-list data-linkbatch-scroll-key="file-worksets" tabindex="0" role="group" aria-label="링크 파일별 타입 및 인스턴스 웍셋"></div><p class="linkbatch-note" data-workset-mode-note></p>';
  worksetCard.insertBefore(worksetModes,worksetCard.querySelector('.linkbatch-checks'));
  worksetCard.insertBefore(commonWorksets,worksetCard.querySelector('.linkbatch-checks'));
  worksetCard.insertBefore(fileWorksetsPane,worksetCard.querySelector('.linkbatch-checks'));
  const hostCard=div('linkbatch-card linkbatch-host-list');
  hostCard.innerHTML='<div class="linkbatch-card-head"><h2>대상 RVT 파일</h2></div>';
  hostCard.append(targetCard.querySelector('[data-batch-panel]'));
  const runHead=div('linkbatch-run-head');runHead.innerHTML='<div><span class="linkbatch-kicker">실행</span><h2>링크 실행</h2></div>';
  const finalActions=runCard.querySelector('.linkbatch-actions');finalActions.className='linkbatch-final-actions';
  finalActions.querySelectorAll('button').forEach(button=>{button.className='btn linkbatch-btn';button.dataset.directKind=button.hasAttribute('data-run')?'primary':'secondary';});
  const readiness=div('linkbatch-readiness');
  readiness.innerHTML='<div data-ready="target"><span>작업 대상</span><strong></strong></div><div data-ready="links"><span>링크 파일</span><strong></strong></div><div data-ready="placement"><span>배치 방식</span><strong></strong></div><div data-ready="reference"><span>하위 링크</span><strong></strong></div><div data-ready="worksets"><span>웍셋</span><strong></strong></div>';
  const runSummary=runCard.querySelector('[data-summary]'),saveNote=runCard.querySelector('[data-save-note]'),feedback=runCard.querySelector('[data-feedback]');
  runCard.replaceChildren(runHead,runSummary,finalActions,readiness,feedback);
  const saveCard=div('linkbatch-save-note');saveCard.append(saveNote);runPanel.append(runCard,saveCard);
  const fileColumns=div('linkbatch-file-columns');fileColumns.append(hostCard,simpleCard);
  // Execution uses the editable rows. Explicit placement/reference/creation
  // changes update only that field; importing preserves per-row settings.
  for(const card of [targetCard,simpleCard,worksetCard])card.querySelector('.linkbatch-step').remove();
  worksetCard.querySelector('.linkbatch-card-head').remove();
  const quickSettings=document.createElement('details');quickSettings.className='linkbatch-quick-settings';quickSettings.dataset.quickSettings='';
  quickSettings.open=standalone;
  quickSettings.innerHTML='<summary>여러 작업에 배치·웍셋 일괄 적용</summary><p class="linkbatch-note">배치·하위 링크·웍셋 생성 옵션을 변경하면 현재 작업 전체에 바로 적용됩니다. 공통 웍셋은 새 작업의 기본값이며, 기존 작업에는 아래 적용 버튼으로 반영합니다. 파일별 웍셋을 편집하면 해당 링크의 모든 대상 행에 그 항목만 반영합니다.</p>';
  quickSettings.append(...worksetCard.children);worksetCard.append(quickSettings);
  const applyDefaults=document.createElement('button');applyDefaults.type='button';applyDefaults.className='btn';applyDefaults.dataset.applyDefaults='';applyDefaults.textContent='위 배치·하위 링크·웍셋 설정을 모든 작업에 적용';quickSettings.append(applyDefaults);
  const registrationNote=simpleCard.querySelector(':scope > .linkbatch-note');
  if(registrationNote)worksetCard.querySelector('.linkbatch-guide').append(registrationNote);
  const resultButton=document.createElement('button');resultButton.type='button';resultButton.className='btn linkbatch-btn';resultButton.dataset.directKind='secondary';resultButton.dataset.showResult='';resultButton.textContent='최근 결과 보기';resultButton.hidden=true;
  finalActions.append(resultButton);
  if(standalone){
    page.classList.add('linkbatch-page--standalone');
    for(const kind of ['hosts','links']){
      const manage=page.querySelector(`[data-manage-${kind}]`)||workspace.querySelector(`[data-manage-${kind}]`)||fileColumns.querySelector(`[data-manage-${kind}]`);
      const toolbar=manage.parentElement;
      manage.remove();
      for(const [event,label] of [[`pick-${kind}`,'로컬 RVT 추가'],[`pick-cloud-${kind}`,'ACC 모델 추가']]){
        const button=document.createElement('button');button.type='button';button.className='btn btn--primary';button.dataset[event.replace(/-([a-z])/g,(_,letter)=>letter.toUpperCase())]='';button.textContent=label;
        button.addEventListener('click',()=>request(event));toolbar.append(button);
      }
    }
    hostCard.querySelector('[data-batch-panel] > .linkbatch-note').textContent='로컬·ACC 대상 모델을 등록하고 아래에서 설정하세요.';
    workspace.append(targetCard,fileColumns,worksetCard,excelCard,importedCard);
  }else workspace.append(targetCard,fileColumns,excelCard,worksetCard,importedCard);
  page.replaceChildren(workspace,runPanel);
  root.append(page);
  const $ = (selector) => workspace.querySelector(selector)||runPanel.querySelector(selector);
  const $$ = (selector) => [...workspace.querySelectorAll(selector),...runPanel.querySelectorAll(selector)];
  const ui = Object.fromEntries(['status','document','document-note','active-panel','batch-panel','host-files','host-count','link-files','link-count','simple-panel','excel-panel','excel-note','import-count','workbook','summary','save-note','feedback','check','run','cancel','export','import'].map(key => [key,$(`[data-${key}]`)]));
  const controls = new Map([...page.querySelectorAll('[data-option]')].map(el => [el.dataset.option,el]));
  workspace.querySelectorAll('button.btn').forEach(button=>{const registration=button.hasAttribute('data-manage-hosts')||button.hasAttribute('data-manage-links')||button.hasAttribute('data-pick-hosts')||button.hasAttribute('data-pick-links')||button.hasAttribute('data-pick-cloud-hosts')||button.hasAttribute('data-pick-cloud-links');button.className=`btn linkbatch-btn shell3-btn ${registration?'shell3-btn--primary':'shell3-btn--ghost'} rvt3-compact-btn`;button.dataset.directKind=registration?'primary':'secondary';});
  workspace.querySelectorAll('.linkbatch-actions,.linkbatch-list-selection').forEach(toolbar=>toolbar.classList.add('rvt3-inline-toolbar'));
  workspace.querySelectorAll('.linkbatch-file-list').forEach(list=>list.classList.add('rvt3-table'));
  controls.forEach((el,key) => { if(el.type==='checkbox') el.checked=!!state[key]; else el.value=state[key]; });
  controls.get('instanceWorkset').readOnly=!!state.sameWorkset;
  if(state.sameWorkset){state.instanceWorkset=state.typeWorkset;controls.get('instanceWorkset').value=state.typeWorkset;}
  let nextId=0;
  const knownRowIds=new Set();
  let progressOwner=null,progressState={percent:null,message:'',meta:''},resultDialog=null;
  const subscriptions=[];
  const dropCleanups=[];
  let reportedBusy=null;
  let nativeDocumentSignature='',documentRefreshPending=false,documentRefreshTimer=null;
  const fileRows={hosts:new Map(),links:new Map()};
  const worksetRows=new Map(),worksetList=$('[data-workset-list]');
  const operationRows=new Map(),operationList=$('[data-operation-list]'),operationKeys=new WeakMap();
  const resizeWorkspace=()=>{const height=workspace.clientHeight;if(height>0){const value=`${Math.max(24,height-28)}px`;if(workspace.style.getPropertyValue('--linkbatch-inner-max')!==value)workspace.style.setProperty('--linkbatch-inner-max',value);}};
  const workspaceObserver=new ResizeObserver(resizeWorkspace);workspaceObserver.observe(workspace);resizeWorkspace();
  const listen=(event,fn)=>subscriptions.push(onHost(event,payload=>{if(!state.disposed&&page.isConnected)fn(payload||{});}));
  function scheduleDocumentRefresh(){
    if(!standalone||!documentRefreshPending||state.busy||state.disposed||documentRefreshTimer!==null)return;
    documentRefreshTimer=setTimeout(()=>{
      documentRefreshTimer=null;
      if(state.disposed||!page.isConnected||state.busy)return;
      documentRefreshPending=false;
      request('init');
    },150);
  }
  function preferences(){return Object.fromEntries(Object.keys(defaults).map(key=>[key,state[key]]));}
  function save(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(preferences()));}catch{}}
  function message(text,tone=''){ui.feedback.textContent=str(text);ui.feedback.dataset.tone=tone;if(state.busy){progressState.message=str(text);syncProgress();}}
  function syncProgress(){
    if(!state.busy){if(progressOwner!==null)ProgressDialog.hide(progressOwner);progressOwner=null;return;}
    if(progressOwner===null)progressOwner=ProgressDialog.show('링크 매니저',progressState.message||'작업을 준비하고 있습니다.');
    if(!ProgressDialog.isOwner(progressOwner))return;
    const canCancel=state.mode==='batch'&&['run','cancelling'].includes(state.busy);
    ProgressDialog.setActions({onCancel:canCancel?cancelRun:null,cancelLabel:'중지 요청'},progressOwner);
    ProgressDialog.setActionState({cancelDisabled:state.busy==='cancelling',statusText:state.busy==='cancelling'?'현재 파일 처리 후 남은 작업을 중단합니다.':''},progressOwner);
    if(progressState.percent===null)ProgressDialog.updateIndeterminate(progressState.message,progressState.meta,progressOwner);
    else ProgressDialog.update(progressState.percent,progressState.message,progressState.meta,progressOwner);
  }
  function acceptProgress(p={}){
    const total=Number(p.total),done=Number(p.done),percent=Number(p.percent);
    progressState={percent:p.percent!=null&&Number.isFinite(percent)?percent:total>0&&Number.isFinite(done)?100*done/total:null,message:str(p.message),meta:total>0&&Number.isFinite(done)?`${done} / ${total}건 처리`:''};
  }
  function cancelRun(){
    if(state.mode!=='batch'||state.busy!=='run')return;
    post('linkbatch:cancel',{});state.busy='cancelling';message('중지를 요청했습니다. 현재 파일 처리 후 결과를 확인하세요.');sync();
  }
  function invalidate(){if(state.lastResult&&!state.busy)message('설정이 변경되었습니다. 최근 결과에는 이전 작업 내용이 표시됩니다.');}
  function request(event,payload={},busy=''){
    if(state.busy)return;
    if(event==='init')payload={...payload,documentKey:state.explicitDocumentSelection?state.selectedDocumentKey:''};
    if(busy){progressState={percent:null,message:'작업을 준비하고 있습니다.',meta:''};state.busy=busy;sync();message(busy==='run'?'링크를 추가하고 있습니다.':busy==='preflight'?'입력을 검증하고 있습니다.':'처리하고 있습니다.');}
    if(post(`linkbatch:${event}`,payload)===false){state.busy='';sync();if(event==='export-result-excel')showResult();}
  }
  const isExisting=row=>str(row.operation).toUpperCase()==='UPDATE';
  function rowsForRequest(){return state.rows.map(row=>({...row,typeWorkset:str(row.typeWorkset).trim(),instanceWorkset:str(row.instanceWorkset).trim(),createMissingWorksets:state.mode==='active'?false:!!row.createMissingWorksets}));}
  function payload(){return {mode:state.mode,documentKey:state.selectedDocumentKey,contextToken:state.contextToken,rows:rowsForRequest(),options:{...preferences(),createMissingWorksets:state.mode==='active'?false:state.createMissingWorksets,worksetMode:state.worksetMode},hosts:[...state.hosts],links:[...state.links],fileWorksets:state.links.filter(path=>state.fileWorksets.has(sourceKey(path))).map(linkPath=>({linkPath,...state.fileWorksets.get(sourceKey(linkPath))}))};}
  function exportPayload(){const value=payload();if(!value.rows.length&&state.mode==='batch')value.rows=state.hosts.map((hostPath,index)=>({...newRow(hostPath,''),rowId:`draft-host-${index+1}`}));return {...value,templateKind:'rows',locale:getLastExcelExportLocale()};}
  function newRow(hostPath,linkPath,worksetDefaults=null){
    let rowId;do{rowId=`ui-${++nextId}`;}while(knownRowIds.has(rowId));knownRowIds.add(rowId);
    const worksets=worksetDefaults||(state.worksetMode==='files'?state.fileWorksets.get(sourceKey(linkPath))||commonWorksetValues():commonWorksetValues());
    return {rowId,operation:'LINK',hostPath,linkPath,hostDisplayPath:display(hostPath),linkDisplayPath:display(linkPath),placement:state.placement,referenceType:state.referenceType,...worksets,createMissingWorksets:state.mode==='active'?false:!!state.createMissingWorksets,action:cloud(hostPath)&&sourceKey(hostPath)===sourceKey(linkPath)?'SKIP':'LINK'};
  }
  function rowEdited(row){delete row.inputError;delete row.message;row.status='';state.importFailed=false;invalidate();}
  function editWorkset(row,field,value){
    const related=isExisting(row)&&field==='typeWorkset'?state.rows.filter(item=>isExisting(item)&&item.existingLinkTypeUniqueId===row.existingLinkTypeUniqueId&&sourceKey(item.hostPath)===sourceKey(row.hostPath)):[row];
    for(const item of related){item[field]=value;rowEdited(item);if(isExisting(item)){item._dirty=true;item.action='LINK';}}
  }
  function fillWorksets(input,value,existing=false){
    const signature=JSON.stringify([state.worksetNames,value,existing]);if(input.dataset.values===signature)return;
    const options=[['',existing?'현재 웍셋 유지':'문서 기본값'],...state.worksetNames.map(name=>[name,name])];
    if(value&&!state.worksetNames.includes(value))options.push([value,`사용할 수 없음: ${value}`]);
    input.replaceChildren(...options.map(([key,text])=>{const option=document.createElement('option');option.value=key;option.textContent=text;return option;}));input.value=value;input.dataset.values=signature;
  }
  function syncWorksetControls(){
    for(const key of ['typeWorkset','instanceWorkset']){
      let input=controls.get(key);const active=state.mode==='active',tag=active?'SELECT':'INPUT';
      if(input.tagName!==tag){const replacement=document.createElement(tag.toLowerCase());replacement.className=input.className;Object.assign(replacement.dataset,input.dataset);if(!active){replacement.setAttribute('list','linkbatch-worksets');replacement.autocomplete='off';replacement.placeholder='문서 기본값';}input.replaceWith(replacement);controls.set(key,replacement);input=replacement;bindOption(input,key);}
      if(active)fillWorksets(input,str(state[key]));else if(input.value!==str(state[key]))input.value=str(state[key]);
    }
  }
  function localRowError(row){
    if(row._bindingError)return str(row._bindingError);
    if(row.inputError)return str(row.inputError);
    if(str(row.status).toLowerCase()==='error')return str(row.message)||'입력 검증에서 확인이 필요한 행입니다.';
    if(str(row.action||'LINK').toUpperCase()==='SKIP')return '';
    if(!['LINK','UPDATE'].includes(str(row.operation||'LINK').toUpperCase()))return '작업 종류를 확인하세요.';
    if(isExisting(row)){
      if(state.mode!=='active')return '기존 링크 웍셋 변경은 열린 문서에서만 실행할 수 있습니다.';
      if(!row.existingLinkTypeUniqueId)return '기존 링크 식별 정보가 없습니다. 목록을 새로고침하세요.';
      if(str(row.placement).toLowerCase()!=='keep'||str(row.referenceType).toLowerCase()!=='keep')return '기존 링크는 현재 위치와 하위 링크 설정을 유지해야 합니다.';
    }
    if(state.mode==='active')for(const key of ['typeWorkset','instanceWorkset'])if(row[key]&&!state.worksetNames.includes(row[key]))return '선택 문서에 없는 웍셋입니다. 현재 웍셋에서 다시 선택하세요.';
    if(isExisting(row))return '';
    if(!/\.rvt$/i.test(str(row.linkPath).trim()))return '링크 RVT 경로를 입력하세요.';
    if(state.mode==='batch'&&!/\.rvt$/i.test(str(row.hostPath).trim()))return '대상 RVT 경로를 입력하세요.';
    if(!Object.hasOwn(placementLabels,str(row.placement).toLowerCase()))return '배치 방식을 선택하세요.';
    if(!['overlay','attachment'].includes(str(row.referenceType).toLowerCase()))return '하위 링크 포함 방식을 선택하세요.';
    if(!['LINK','SKIP'].includes(str(row.action||'LINK').toUpperCase()))return '실행 여부를 선택하세요.';
    return '';
  }
  function sync(){
    syncWorksetControls();
    syncWorksets();
    const batch=state.mode==='batch',busy=!!state.busy,rows=state.rows,enabled=rows.filter(row=>str(row.action||'LINK').toUpperCase()!=='SKIP'),errors=enabled.filter(row=>localRowError(row)),count=enabled.length;
    if(standalone&&reportedBusy!==busy){reportedBusy=busy;post('linkmanager:client-busy',{busy});}
    const stale=!!state.importedContextToken&&!batch&&state.importedContextToken!==state.contextToken;
    ui['active-panel'].hidden=batch;ui['batch-panel'].hidden=!batch;hostCard.hidden=!batch;fileColumns.classList.toggle('is-single',!batch);
    page.classList.toggle('is-active-document',!batch);
    if(!batch&&importedCard.parentNode!==simpleCard)simpleCard.append(importedCard);
    if(batch&&importedCard.parentNode!==workspace)workspace.append(importedCard);
    ui['link-files'].hidden=!batch;$('[data-list-tools="links"]').hidden=!batch;
    $('[data-link-list-title]').textContent=batch?'링크할 RVT 파일':'현재 LINK 목록';
    $('[data-link-list-note]').textContent=batch?'ACC 대상과 링크는 같은 프로젝트·Revit 버전에서 선택하세요. 자기 자신과 이미 배치된 링크는 중복 추가하지 않습니다.':'기존 링크의 웍셋을 변경하거나 로컬·ACC 링크를 추가하세요. 기존 링크의 위치와 하위 링크 설정은 유지합니다.';
    $('[data-document-select]').disabled=busy||state.contextPending;
    page.querySelectorAll('[data-mode]').forEach(button=>{const selected=button.dataset.mode===state.mode;button.setAttribute('aria-selected',String(selected));button.classList.toggle('is-active',selected);button.tabIndex=selected?0:-1;});
    $$('button').forEach(button=>{if(button!==ui.cancel)button.disabled=busy;});
    controls.forEach((control,key)=>control.disabled=busy||(!batch&&(['typeWorkset','instanceWorkset'].includes(key)&&(!state.context.isWorkshared||state.contextPending)||key==='createMissingWorksets')));$$('.linkbatch-file input,[data-row-field]').forEach(control=>control.disabled=busy);
    ['hosts','links'].forEach(syncFileTools);$('[data-row-search]').disabled=busy;
    ui.cancel.hidden=!batch||!['run','cancelling'].includes(state.busy);ui.cancel.disabled=state.busy==='cancelling';
    ui.check.disabled=busy||stale||!enabled.some(row=>isExisting(row)||str(row.linkPath).trim())||state.importFailed||(!batch&&(state.contextPending||!state.contextToken||!state.context.title));ui.run.disabled=ui.check.disabled;
    ui.run.textContent=batch?'일괄 링크':'변경 실행';
    const exportNeedsHost=batch&&!state.hosts.length&&!rows.some(row=>str(row.hostPath).trim());
    ui.export.disabled=busy||exportNeedsHost||(!rows.length&&!state.links.length&&!state.hosts.length);ui.export.title=exportNeedsHost?'여러 RVT 양식을 저장하려면 대상 RVT를 먼저 등록하세요.':'등록된 파일, 화면 기본 설정과 모든 작업 행을 Excel로 저장합니다.';
    ui.import.disabled=busy;applyDefaults.disabled=busy||!rows.length;
    applyDefaults.textContent=batch&&state.worksetMode==='files'?'위 배치·하위 링크·생성 설정을 모든 작업에 적용':'위 설정을 모든 작업에 적용 · 기존 링크는 웍셋만';
    const instanceField=controls.get('instanceWorkset').closest('label');instanceField.hidden=!!state.sameWorkset;
    controls.get('typeWorkset').closest('label').firstChild.textContent=state.sameWorkset?'타입 · 인스턴스 웍셋':'타입 웍셋';
    resultButton.hidden=!state.lastResult;
    ui.status.textContent=busy?'처리 중':count?`${count}건 등록${errors.length?` · 확인 ${errors.length}건`:''}`:'준비됨';
    ui.summary.textContent=rows.length?`${batch?new Set(rows.map(row=>sourceKey(row.hostPath)).filter(Boolean)).size+'개 대상 RVT':'활성 문서'} · 실행 ${count}건 · 제외 ${rows.length-count}건${errors.length?` · 확인 ${errors.length}건`:''}`:'등록한 파일 또는 작업 행을 추가하세요.';
    const common=(key,label)=>{const values=[...new Set(enabled.map(row=>str(row[key])))];return values.length===1?label(values[0]):values.length?'행별 설정':'작업 없음';};
    const pairs=[...new Set(enabled.map(row=>JSON.stringify([str(row.typeWorkset),str(row.instanceWorkset)])))],worksetSummary=pairs.length===1?JSON.parse(pairs[0]).map(value=>value||'문서 기본값').join(' / '):pairs.length?'행별 타입·인스턴스 설정':'작업 없음';
    const readinessValues={target:[batch?rows.some(row=>row.hostPath):!!state.context.title,batch?`${state.hosts.length}개 RVT`:state.context.title||'문서 없음'],links:[count>0,batch?`${state.links.length}개 파일 · ${count}건`:`기존 ${rows.filter(isExisting).length} · 추가 ${rows.filter(row=>!isExisting(row)).length} · 실행 ${count}건`],placement:[!errors.length,common('placement',placementLabel)],reference:[true,common('referenceType',value=>value==='keep'?'현재 설정 유지':value==='attachment'?'함께 포함 · 부착':'포함하지 않음 · 중첩')],worksets:[true,worksetSummary]};
    Object.entries(readinessValues).forEach(([key,[ready,text]])=>{const row=$(`[data-ready="${key}"]`);row.classList.toggle('is-ready',!!ready);row.querySelector('strong').textContent=text;row.querySelector('strong').title=text;});
    ui['host-count'].textContent=`${state.hosts.length}개`;ui['link-count'].textContent=batch?`${state.links.length}개`:`기존 ${rows.filter(isExisting).length} · 추가 ${rows.filter(row=>!isExisting(row)).length}`;
    ui['import-count'].hidden=!state.workbookPath;ui['import-count'].textContent=`${rows.length}행`;
    ui.workbook.textContent=state.workbookPath?`불러온 파일: ${state.workbookPath}`:'현재 화면의 작업을 내보내고, Excel에서 편집한 뒤 다시 불러올 수 있습니다.';
    ui['excel-note'].textContent=exportNeedsHost?'여러 RVT의 현재 설정을 내보내려면 대상 RVT를 먼저 등록하세요.':'배치·웍셋과 행별 차이를 그대로 저장합니다. Excel에서 일부 행만 남겨도 그 작업 목록을 유지합니다.';
    ui['save-note'].textContent=batch?'여러 RVT 실행은 대상 파일의 변경 사항을 저장하거나 동기화합니다.':'선택 문서의 변경은 직접 저장하세요.';
    $('[data-placement-note]').textContent=placementNotes[state.placement]||'배치 방식을 선택하세요.';
    $('[data-reference-note]').textContent='대상 RVT를 다른 모델에 다시 링크할 때: 중첩은 제외, 부착은 포함합니다.';
    $('[data-workset-note]').textContent=batch?'작업 목록의 각 타입·인스턴스 웍셋이 실행값입니다. 비워 두면 문서 기본값을 사용합니다.':'선택 문서의 기존 웍셋에서 선택합니다. 기존 링크의 웍셋을 바꾸면 해당 행이 실행 대상으로 바뀝니다. 타입 웍셋은 같은 타입의 모든 인스턴스에 적용됩니다.';
    controls.get('createMissingWorksets').closest('label').hidden=!batch;
    renderOperations();syncProgress();scheduleDocumentRefresh();
  }
  function commonWorksetValues(){return {typeWorkset:state.typeWorkset,instanceWorkset:state.sameWorkset?state.typeWorkset:state.instanceWorkset};}
  function syncWorksets(){
    const individual=state.mode==='batch'&&state.worksetMode==='files',liveKeys=new Set(state.links.map(sourceKey));
    // Identity-based drafts survive ACC account-token refreshes, but removed files do not leave stale settings.
    for(const key of state.fileWorksets.keys())if(!liveKeys.has(key))state.fileWorksets.delete(key);
    for(const [key,row] of worksetRows)if(!liveKeys.has(key)){row.remove();worksetRows.delete(key);}
    worksetModes.hidden=state.mode==='active';worksetModes.querySelectorAll('input').forEach(input=>{input.checked=input.value===state.worksetMode;input.disabled=!!state.busy;});
    commonWorksets.classList.toggle('is-common',!individual);commonWorksets.querySelector('summary').hidden=!individual;
    applyWorksets.hidden=!individual;fileWorksetsPane.hidden=!individual;
    $('[data-workset-search]').disabled=!!state.busy;
    if(!individual||!quickSettings.open)return;
    const search=state.worksetSearch.trim().toLocaleLowerCase(),relatedByLink=new Map();let visible=0;
    for(const item of state.rows){const key=sourceKey(item.linkPath);if(!relatedByLink.has(key))relatedByLink.set(key,[]);relatedByLink.get(key).push(item);}
    state.links.forEach((path,index)=>{
      const key=sourceKey(path),related=relatedByLink.get(key)||[],existing=state.fileWorksets.has(key);
      if(!existing)state.fileWorksets.set(key,commonWorksetValues());
      const mixed=new Set(),shown={...state.fileWorksets.get(key)};
      for(const field of ['typeWorkset','instanceWorkset']){const values=[...new Set(related.map(item=>str(item[field])))];if(values.length===1){shown[field]=values[0];if(!existing)state.fileWorksets.get(key)[field]=values[0];}else if(values.length>1)mixed.add(field);}
      let row=worksetRows.get(key);
      if(!row){
        row=div('linkbatch-workset-row');row.dataset.worksetKey=key;
        const copy=div('linkbatch-workset-file'),name=document.createElement('strong'),location=document.createElement('span');copy.append(name,location);row.append(copy);
        for(const [field,labelText] of [['typeWorkset','타입 웍셋'],['instanceWorkset','인스턴스 웍셋']]){
          const label=document.createElement('label'),caption=document.createElement('span'),input=document.createElement('input');label.className='linkbatch-field';caption.textContent=labelText;input.className='feature-input';input.dataset.fileWorkset=field;input.dataset.linkbatchFocusKey=`workset:${key}:${field}`;input.setAttribute('list','linkbatch-worksets');input.placeholder='문서 기본값';input.autocomplete='off';
          input.addEventListener('input',()=>{state.fileWorksets.get(key)[field]=input.value;for(const item of state.rows)if(sourceKey(item.linkPath)===key){item[field]=input.value;rowEdited(item);}sync();});label.append(caption,input);row.append(label);
        }
        worksetRows.set(key,row);
      }
      row.querySelector('strong').textContent=leaf(path);row.querySelector('.linkbatch-workset-file span').textContent=display(path);row.querySelector('.linkbatch-workset-file').title=display(path);
      row.querySelectorAll('[data-file-workset]').forEach(input=>{const field=input.dataset.fileWorkset,value=mixed.has(field)?'':shown[field];if(input.value!==value)input.value=value;input.placeholder=mixed.has(field)?'작업별 값 다름':'문서 기본값';input.disabled=!!state.busy;input.setAttribute('aria-label',`${leaf(path)} ${field==='typeWorkset'?'타입':'인스턴스'} 웍셋`);});
      row.hidden=!!search&&!`${leaf(path)} ${display(path)}`.toLocaleLowerCase().includes(search);if(!row.hidden)visible++;
      if(worksetList.children[index]!==row)worksetList.insertBefore(row,worksetList.children[index]||null);
    });
    let empty=worksetList.querySelector('.linkbatch-empty');
    if(!visible){if(!empty){empty=div('linkbatch-empty');worksetList.append(empty);}empty.textContent=state.links.length?'검색 조건에 맞는 파일이 없습니다.':'링크할 RVT 파일을 먼저 등록하세요.';}else if(empty)empty.remove();
    $('[data-workset-count]').textContent=`${visible} / ${state.links.length}개`;
    $('[data-workset-mode-note]').textContent='파일별 입력은 같은 링크의 모든 대상 작업에 해당 웍셋만 적용합니다. 대상마다 다른 값은 아래 작업 목록에서 수정하세요. 검색으로 숨긴 작업에도 적용합니다.';
  }
  function visibleFiles(kind){const search=state.fileSearch[kind].trim().toLocaleLowerCase();return state[kind].filter(path=>!search||`${leaf(path)} ${display(path)} ${path}`.toLocaleLowerCase().includes(search));}
  function syncFileTools(kind){
    const visible=visibleFiles(kind),selected=state.selectedFiles[kind],checked=visible.filter(path=>selected.has(path)).length;
    const all=$(`[data-select-visible="${kind}"]`),remove=$(`[data-remove-selected="${kind}"]`),search=$(`[data-file-search="${kind}"]`);
    all.checked=visible.length>0&&checked===visible.length;all.indeterminate=checked>0&&checked<visible.length;all.disabled=!!state.busy||!visible.length;
    remove.disabled=!!state.busy||!selected.size;search.disabled=!!state.busy;
    $(`[data-selection-count="${kind}"]`).textContent=`${selected.size}개 선택 · ${visible.length}개 표시`;
    $(`[data-clear-${kind}]`).disabled=!!state.busy||!state[kind].length;
  }
  function renderFiles(kind){
    const list=ui[kind==='links'?'link-files':'host-files'],paths=state[kind],scroll=list.scrollTop,selected=state.selectedFiles[kind],rows=fileRows[kind],visible=new Set(visibleFiles(kind));
    for(const path of selected)if(!paths.includes(path))selected.delete(path);
    for(const [path,row] of rows)if(!paths.includes(path)){row.remove();rows.delete(path);}
    paths.forEach((path,index)=>{
      let row=rows.get(path);
      if(!row){
        row=div('rvt3-row linkbatch-file');
        const label=document.createElement('label'),check=document.createElement('input'),copy=div('rvt3-file linkbatch-file-copy'),title=document.createElement('strong'),detail=document.createElement('span'),remove=document.createElement('button');
        label.className='linkbatch-file-label';check.type='checkbox';check.dataset.linkbatchFocusKey=`${kind}:${path}`;check.setAttribute('aria-label',`${leaf(path)} 선택`);
        check.addEventListener('change',()=>{if(check.checked)selected.add(path);else selected.delete(path);row.classList.toggle('is-selected',check.checked);row.dataset.checked=String(check.checked);syncFileTools(kind);});
        copy.append(title,detail);label.append(check,copy);remove.type='button';remove.className='linkbatch-remove';remove.textContent='×';remove.setAttribute('aria-label',`${leaf(path)} 제거`);
        remove.addEventListener('click',()=>{updateFiles(kind,state[kind].filter(p=>p!==path));invalidate();renderFiles(kind);sync();});row.append(label,remove);rows.set(path,row);
      }
      row.querySelector('strong').textContent=leaf(path);row.querySelector('.linkbatch-file-copy span').textContent=display(path);row.querySelector('.linkbatch-file-copy').title=display(path);
      row.querySelector('input').checked=selected.has(path);row.querySelector('input').disabled=!!state.busy;row.classList.toggle('is-selected',selected.has(path));row.dataset.checked=String(selected.has(path));row.hidden=!visible.has(path);
      if(list.children[index]!==row)list.insertBefore(row,list.children[index]||null);
    });
    let empty=list.querySelector('.linkbatch-empty');
    if(!visible.size){if(!empty){empty=div('linkbatch-empty');list.append(empty);}empty.textContent=paths.length?'검색 조건에 맞는 RVT가 없습니다.':kind==='links'?'링크 RVT 등록·관리에서 파일을 추가하세요.':'대상 RVT 등록·관리에서 파일을 추가하세요.';}else if(empty)empty.remove();
    list.scrollTop=scroll;syncFileTools(kind);
  }
  function updateFiles(kind,paths,generate=true){
    const selected=state.selectedFiles[kind],previous=new Map(state[kind].map(path=>[sourceKey(path),selected.has(path)])),field=kind==='hosts'?'hostPath':'linkPath';
    state[kind]=uniquePaths(paths);
    const current=new Map(state[kind].map(path=>[sourceKey(path),path]));
    if(generate)state.rows=state.rows.filter(row=>isExisting(row)||!previous.has(sourceKey(row[field]))||current.has(sourceKey(row[field])));
    for(const row of state.rows)if(!isExisting(row)&&current.has(sourceKey(row[field]))){row[field]=current.get(sourceKey(row[field]));row[kind==='hosts'?'hostDisplayPath':'linkDisplayPath']=display(row[field]);}
    if(generate){
      const added=state[kind].filter(path=>!previous.has(sourceKey(path))),pairs=new Set(state.rows.map(row=>JSON.stringify([sourceKey(row.hostPath),sourceKey(row.linkPath)])));
      const hosts=kind==='hosts'?added:state.mode==='active'?[str(state.context.path)]:state.hosts,links=kind==='links'?added:state.links;
      const values=new Map();if(state.worksetMode==='files')for(const row of state.rows){const key=sourceKey(row.linkPath);if(!values.has(key))values.set(key,{typeWorkset:new Set(),instanceWorkset:new Set()});for(const field of ['typeWorkset','instanceWorkset'])values.get(key)[field].add(str(row[field]));}
      const initial=new Map(links.map(link=>{const key=sourceKey(link),draft={...(state.worksetMode==='files'?state.fileWorksets.get(key)||commonWorksetValues():commonWorksetValues())};if(values.has(key))for(const field of ['typeWorkset','instanceWorkset'])if(values.get(key)[field].size===1)draft[field]=[...values.get(key)[field]][0];return [key,draft];}));
      for(const host of hosts)for(const link of links){const pair=JSON.stringify([sourceKey(host),sourceKey(link)]);if(!pairs.has(pair)){state.rows.push(newRow(host,link,initial.get(sourceKey(link))));pairs.add(pair);}}
    }
    // Keep the Set used by mounted row handlers; preserve explicit unchecks by model identity.
    selected.clear();
    for(const path of state[kind])if(previous.get(sourceKey(path))!==false)selected.add(path);
  }
  function addFiles(kind,paths,locations={}){Object.assign(state.locations,locations);updateFiles(kind,[...state[kind],...paths]);invalidate();renderFiles(kind);sync();}
  function manageFiles(kind){request(`manage-${kind}`,{paths:[...state[kind]],locations:{...state.locations},theme:getCurrentTheme()});}
  function replaceFiles(kind,p){if(p.cancelled||!Array.isArray(p.paths))return;Object.assign(state.locations,p.locations||{});updateFiles(kind,p.paths);state.fileSearch[kind]='';$(`[data-file-search="${kind}"]`).value='';invalidate();renderFiles(kind);sync();}
  function unionRowFiles(){
    const hosts=state.rows.filter(row=>!isExisting(row)).map(row=>str(row.hostPath)).filter(Boolean),links=state.rows.filter(row=>!isExisting(row)).map(row=>str(row.linkPath)).filter(Boolean);
    updateFiles('hosts',[...state.hosts,...hosts],false);updateFiles('links',[...state.links,...links],false);
    renderFiles('hosts');renderFiles('links');
  }
  function operationKey(row){if(!operationKeys.has(row))operationKeys.set(row,`operation-${++nextId}`);return operationKeys.get(row);}
  function renderOperations(){
    const search=state.rowSearch.trim().toLocaleLowerCase(),filtered=state.rows.filter(row=>!search||`${row.rowId} ${display(row.hostPath)} ${display(row.linkPath)} ${row.typeWorkset} ${row.instanceWorkset}`.toLocaleLowerCase().includes(search)||operationRows.get(operationKeys.get(row))?.contains(document.activeElement));
    const pages=Math.max(1,Math.ceil(filtered.length/100));state.rowPage=Math.min(state.rowPage||0,pages-1);
    const visible=filtered.slice(state.rowPage*100,state.rowPage*100+100),wanted=new Set(visible.map(operationKey));
    for(const [key,node] of operationRows)if(!wanted.has(key)){node.remove();operationRows.delete(key);}
    visible.forEach((row,index)=>{
      const key=operationKey(row);let node=operationRows.get(key);
      if(!node){
        node=document.createElement('article');node.className='linkbatch-operation-row';node.dataset.operationKey=key;
        node.innerHTML='<div class="linkbatch-operation-head"><strong data-row-title></strong><span class="linkbatch-row-status" data-row-status></span><button class="linkbatch-remove" type="button" data-remove-row aria-label="작업 행 제거">×</button></div><p class="linkbatch-note" data-row-current></p><div class="linkbatch-operation-paths"></div><div class="linkbatch-operation-options"></div><div class="linkbatch-operation-foot"><label><input type="checkbox" data-row-field="createMissingWorksets"> 지정한 웍셋이 없으면 생성</label><span class="linkbatch-note" data-row-message></span></div>';
        const fields=[['hostPath','대상 RVT','path'],['linkPath','링크 RVT','path'],['placement','배치 방식','select'],['referenceType','하위 링크','select'],['typeWorkset','타입 웍셋','text'],['instanceWorkset','인스턴스 웍셋','text'],['action','실행 여부','select']];
        for(const [field,caption,kind] of fields){
          const workset=field==='typeWorkset'||field==='instanceWorkset',select=kind==='select'||(workset&&state.mode==='active');
          const label=document.createElement('label'),title=document.createElement('span'),input=document.createElement(select?'select':'input');label.className='linkbatch-field';title.textContent=caption;input.className='feature-input';input.dataset.rowField=field;input.dataset.linkbatchFocusKey=`${key}:${field}`;
          if(select){
            const values=workset?[]:field==='placement'?(isExisting(row)?[['keep','현재 위치 유지']]:Object.entries(placementLabels)):field==='referenceType'?(isExisting(row)?[['keep','현재 설정 유지']]:[['overlay','중첩 · 하위 링크 제외'],['attachment','부착 · 하위 링크 포함']]):[['LINK','실행'],['SKIP','제외']];
            for(const [value,text] of values){const option=document.createElement('option');option.value=value;option.textContent=text;input.append(option);}
          }else{input.type='text';input.autocomplete='off';input.placeholder=kind==='path'?(field==='hostPath'?'현재 활성 문서 또는 대상 RVT 경로':'등록한 링크 또는 RVT 경로'):'문서 기본값';if(kind!=='path')input.setAttribute('list','linkbatch-worksets');}
          label.append(title,input);if(field==='action'){label.classList.add('linkbatch-operation-action');title.className='sr-only';node.querySelector('.linkbatch-operation-head').insertBefore(label,node.querySelector('[data-row-status]'));}else node.querySelector(kind==='path'?'.linkbatch-operation-paths':'.linkbatch-operation-options').append(label);
        }
        node.querySelectorAll('[data-row-field]').forEach(input=>{
          const field=input.dataset.rowField;
          input.addEventListener(input.type==='checkbox'||input.tagName==='SELECT'?'change':'input',()=>{
            if((field==='hostPath'||field==='linkPath')&&input.readOnly)return;
            const value=input.type==='checkbox'?input.checked:input.value;if(row[field]===value)return;
            if(field==='typeWorkset'||field==='instanceWorkset'){editWorkset(row,field,value);sync();return;}
            row[field]=value;if(isExisting(row))row._dirty=true;
            if(field==='hostPath'||field==='linkPath')row[field==='hostPath'?'hostDisplayPath':'linkDisplayPath']=display(value);
            rowEdited(row);sync();
          });
          if(field==='hostPath'||field==='linkPath')input.addEventListener('change',()=>{unionRowFiles();sync();});
        });
        node.querySelector('[data-remove-row]').addEventListener('click',()=>{state.rows=state.rows.filter(item=>item!==row);if(state.mode==='active'){updateFiles('links',state.rows.filter(item=>!isExisting(item)).map(item=>item.linkPath),false);renderFiles('links');}invalidate();sync();});operationRows.set(key,node);
      }
      node.dataset.rowId=str(row.rowId);node.dataset.operation=isExisting(row)?'UPDATE':'LINK';node.querySelector('[data-row-title]').textContent=`${isExisting(row)?'기존':'추가'} ${state.rowPage*100+index+1} · ${row.displayName||leaf(row.linkPath)||'링크 미지정'}`;node.querySelector('[data-row-title]').title=`행 ID: ${row.rowId}\n${display(row.linkPath)} → ${display(row.hostPath)}`;
      const current=node.querySelector('[data-row-current]');current.hidden=!isExisting(row);current.textContent=isExisting(row)?`${row.isLoaded?'로드됨':'언로드 / 인스턴스 없음'} · ${row.currentReferenceType==='attachment'?'부착':'중첩'}${row.hasInstance===false?' · 타입 웍셋만 변경 가능':row.isPinned?' · 고정됨':''} · 타입 웍셋을 바꾸면 같은 타입의 모든 인스턴스에 적용됩니다.`:'';
      node.querySelector('[data-remove-row]').hidden=isExisting(row);node.querySelector('[data-row-field="createMissingWorksets"]').closest('label').hidden=state.mode==='active';
      node.querySelectorAll('[data-row-field]').forEach(input=>{
        const field=input.dataset.rowField,isPath=field==='hostPath'||field==='linkPath',isCloudPath=isPath&&cloud(row[field]);
        const pathLabel=isPath?row[field==='hostPath'?'hostDisplayPath':'linkDisplayPath']||display(row[field]):'';
        const value=input.type==='checkbox'?!!row[field]:isCloudPath?(cloud(pathLabel)?`ACC · ${leaf(row[field])}`:pathLabel):str(row[field]);
        if(input.tagName==='SELECT'&&(field==='typeWorkset'||field==='instanceWorkset'))fillWorksets(input,value,isExisting(row));
        if(input.type==='checkbox')input.checked=value;
        else{if(input.tagName==='SELECT'&&value&&![...input.options].some(option=>option.value===value)){const option=document.createElement('option');option.value=value;option.textContent=`확인 필요: ${value}`;input.append(option);}if(input.value!==value)input.value=value;}
        input.disabled=!!state.busy||state.contextPending||isExisting(row)&&['placement','referenceType','createMissingWorksets'].includes(field)||state.mode==='active'&&['typeWorkset','instanceWorkset'].includes(field)&&(!state.context.isWorkshared||field==='instanceWorkset'&&row.hasInstance===false);
        if(isPath){input.readOnly=isCloudPath||isExisting(row)||field==='hostPath'&&state.mode==='active';input.title=isCloudPath?value:pathLabel;}
      });
      const excluded=str(row.action).toUpperCase()==='SKIP',error=localRowError(row);node.dataset.result=excluded?'skipped':error?'error':'ready';
      node.querySelector('[data-row-status]').textContent=excluded?(isExisting(row)?'변경 없음':'실행 제외'):error?'확인 필요':str(row.status).toLowerCase()==='ready'?'검증 완료':isExisting(row)?'웍셋 변경 예정':'추가 예정';node.querySelector('[data-row-message]').textContent=error;
      if(operationList.children[index]!==node)operationList.insertBefore(node,operationList.children[index]||null);
    });
    let empty=operationList.querySelector('.linkbatch-empty');if(!visible.length){if(!empty){empty=div('linkbatch-empty');operationList.append(empty);}empty.textContent=state.rows.length?'검색 조건에 맞는 작업이 없습니다.':'파일을 등록하거나 작업 행을 추가하세요.';}else empty?.remove();
    $('[data-operation-count]').textContent=`${filtered.length?state.rowPage*100+1:0}–${Math.min(filtered.length,(state.rowPage+1)*100)} / ${filtered.length}건${search?` · 전체 ${state.rows.length}건`:''}`;
    $('[data-rows-prev]').disabled=!!state.busy||state.rowPage===0;$('[data-rows-next]').disabled=!!state.busy||state.rowPage>=pages-1;
  }
  function draft(){return {rows:state.rows,hosts:state.hosts,links:state.links,fileWorksets:state.fileWorksets,workbookPath:state.workbookPath,importedContextToken:state.importedContextToken};}
  function rememberDocumentDraft(){if(state.mode==='active'&&state.context.key)state.documentDrafts.set(state.context.key,draft());}
  function rememberDraft(){state.modeDrafts.set(state.mode,draft());rememberDocumentDraft();}
  function resetOperationNodes(){for(const node of operationRows.values())node.remove();operationRows.clear();}
  function mergeExisting(fresh){
    if(state.mode!=='active')return;
    const previous=new Set(state.rows.filter(isExisting)),merged=[];
    const identity=row=>JSON.stringify([str(row.existingLinkTypeUniqueId).toLowerCase(),str(row.existingLinkInstanceUniqueId).toLowerCase(),sourceKey(row.hostPath)]);
    const indexed=new Map();for(const row of previous){const key=identity(row);if(!indexed.has(key))indexed.set(key,[]);indexed.get(key).push(row);}
    for(const value of fresh){
      const row=indexed.get(identity(value))?.shift();previous.delete(row);
      if(row){const edits=row._dirty?{rowId:row.rowId,typeWorkset:row.typeWorkset,instanceWorkset:row.instanceWorkset,action:row.action,status:row.status,message:row.message,inputError:row.inputError,_dirty:true}:{};Object.assign(row,value,edits);merged.push(row);}
      else merged.push({...value});
    }
    for(const row of previous)if(row._dirty){row._bindingError='선택 문서와 기존 링크 식별 정보가 일치하지 않습니다. 목록 또는 Excel의 대상 문서를 확인하세요.';merged.push(row);}
    state.rows=[...merged,...state.rows.filter(row=>!isExisting(row))];
  }
  function switchMode(mode){
    if(state.mode===mode)return;rememberDraft();const previousLinks=[...state.links],previousWorksets=new Map(state.fileWorksets);state.mode=mode;
    const saved=mode==='active'?state.documentDrafts.get(state.context.key)||state.modeDrafts.get(mode):state.modeDrafts.get(mode);Object.assign(state,saved||{rows:[],hosts:[],links:previousLinks,fileWorksets:previousWorksets,workbookPath:'',importedContextToken:''});
    if(!saved&&mode==='active')state.rows=state.links.map(path=>newRow(str(state.context.path),path));
    resetOperationNodes();if(mode==='active')mergeExisting(state.currentExistingLinks||[]);
    state.rowPage=0;state.rowSearch='';$('[data-row-search]').value='';state.importFailed=false;renderFiles('hosts');renderFiles('links');invalidate();sync();
  }
  function applyImported(p){
    const mode=['active','batch'].includes(p.mode)?p.mode:state.mode;if(mode!==state.mode)rememberDraft();state.mode=mode;
    state.rows=Array.isArray(p.rows)?p.rows.map(row=>({...row,rowId:row.rowId||`import-${++nextId}`,...(isExisting(row)?{_dirty:true}:{})})):[];
    for(const row of state.rows)knownRowIds.add(row.rowId);
    if(p.options&&typeof p.options==='object'){
      for(const key of Object.keys(defaults))if(Object.hasOwn(p.options,key))state[key]=p.options[key];
      if(['common','files'].includes(p.options.worksetMode))state.worksetMode=p.options.worksetMode;
      controls.forEach((input,key)=>{if(input.type==='checkbox')input.checked=!!state[key];else input.value=str(state[key]);});controls.get('instanceWorkset').readOnly=!!state.sameWorkset;
    }
    state.hosts=uniquePaths([...(Array.isArray(p.hosts)?p.hosts:[]),...state.rows.filter(row=>!isExisting(row)).map(row=>row.hostPath)]);state.links=uniquePaths([...(Array.isArray(p.links)?p.links:[]),...state.rows.filter(row=>!isExisting(row)).map(row=>row.linkPath)]);
    state.fileWorksets=new Map((Array.isArray(p.fileWorksets)?p.fileWorksets:[]).map(item=>[sourceKey(item.linkPath),{typeWorkset:str(item.typeWorkset),instanceWorkset:str(item.instanceWorkset)}]));
    for(const row of state.rows){if(row.hostDisplayPath)state.locations[row.hostPath]=row.hostDisplayPath;if(row.linkDisplayPath)state.locations[row.linkPath]=row.linkDisplayPath;}
    state.importedContextToken=state.mode==='active'?state.contextToken:'';state.workbookPath=str(p.workbookPath);state.importFailed=false;state.rowPage=0;state.rowSearch='';$('[data-row-search]').value='';
    resetOperationNodes();if(state.mode==='active')mergeExisting(state.currentExistingLinks||[]);renderFiles('hosts');renderFiles('links');invalidate();sync();
  }
  function rememberResult(result,phase){
    state.lastResult={...result,phase:result.phase||phase,rows:(Array.isArray(result.rows)?result.rows:[]).map(row=>({...row}))};
  }
  function showResult(){
    const result=state.lastResult;if(!result||state.busy||state.disposed)return;
    const rows=result.rows,preflight=result.phase==='preflight';
    const count=status=>rows.filter(row=>str(row.status).toLowerCase()===status).length;
    const issues=rows.filter(row=>['error','cancelled'].includes(str(row.status).toLowerCase()));
    const shorten=text=>str(text).length>180?str(text).slice(0,177)+'…':str(text);
    const notes=[];
    if(result.completedAt)notes.push(`작업 시각: ${result.completedAt}`);
    (Array.isArray(result.errors)?result.errors:[]).slice(0,2).forEach(error=>notes.push(shorten(typeof error==='string'?error:error.message)));
    issues.slice(0,3).forEach(row=>notes.push(shorten(`${leaf(row.hostDisplayPath||row.hostPath)||'활성 문서'} → ${leaf(row.linkDisplayPath||row.linkPath)||'링크 미지정'}: ${row.message||row.inputError||'상세 로그를 확인하세요.'}`)));
    if(issues.length>3)notes.push(`외 ${issues.length-3}건의 확인 사항이 있습니다.`);
    if(rows.length)notes.push('전체 파일별 상태와 상세 사유는 결과 Excel에서 확인할 수 있습니다.');
    resultDialog=showCompletionSummaryDialog({
      title:preflight?'링크 매니저 입력 검증 결과':'링크 매니저 실행 결과',
      message:result.message||(preflight?'입력 검증이 끝났습니다.':'링크 처리가 끝났습니다.'),
      summaryItems:[{label:'전체',value:`${rows.length}건`},{label:preflight?'실행 가능':'링크 추가',value:`${count(preflight?'ready':'linked')}건`},...(!preflight?[{label:'웍셋 변경',value:`${count('updated')}건`}]:[]),{label:'오류',value:`${count('error')}건`},{label:'건너뜀',value:`${count('skipped')}건`},{label:'중지',value:`${count('cancelled')}건`}],
      notes,confirmLabel:'닫기',showExport:rows.length>0,exportLabel:'결과 Excel 내보내기 (.xlsx)',
      onExport:()=>request('export-result-excel',{resultId:result.resultId},'result-export'),
      onClose:()=>{resultDialog=null;}
    });
  }
  function bindOption(el,key){el.addEventListener(el.type==='checkbox'||el.tagName==='SELECT'?'change':'input',()=>{
    state[key]=el.type==='checkbox'?el.checked:el.value;
    if(['placement','referenceType','createMissingWorksets'].includes(key)){
      for(const row of state.rows){
        if(isExisting(row))continue;
        if(row[key]===state[key])continue;
        row[key]=state[key];rowEdited(row);
      }
    }
    if(key==='sameWorkset')controls.get('instanceWorkset').readOnly=state.sameWorkset;
    if(state.sameWorkset&&(key==='typeWorkset'||key==='sameWorkset')){state.instanceWorkset=state.typeWorkset;controls.get('instanceWorkset').value=state.typeWorkset;}
    invalidate();save();sync();
  });}
  controls.forEach(bindOption);
  worksetModes.querySelectorAll('input').forEach(input=>input.addEventListener('change',()=>{
    if(state.busy||!input.checked)return;
    state.worksetMode=input.value;commonWorksets.open=input.value==='common';invalidate();sync();
  }));
  $('[data-workset-search]').addEventListener('input',event=>{state.worksetSearch=event.target.value;syncWorksets();});
  applyWorksets.addEventListener('click',()=>{
    if(state.busy)return;
    for(const path of state.links)state.fileWorksets.set(sourceKey(path),commonWorksetValues());
    for(const row of state.rows)for(const [field,value] of Object.entries(commonWorksetValues()))if(!(field==='instanceWorkset'&&row.hasInstance===false))editWorkset(row,field,value);
    sync();message(`링크 파일 ${state.links.length}개의 타입·인스턴스 웍셋을 적용했습니다.`,'ok');
  });
  applyDefaults.addEventListener('click',()=>{
    if(state.busy)return;
    for(const row of state.rows){const worksets=state.mode==='batch'&&state.worksetMode==='files'?{typeWorkset:row.typeWorkset,instanceWorkset:row.instanceWorkset}:commonWorksetValues();if(!isExisting(row)){Object.assign(row,{placement:state.placement,referenceType:state.referenceType,createMissingWorksets:state.mode==='active'?false:state.createMissingWorksets,...worksets});rowEdited(row);}else for(const [field,value] of Object.entries(worksets))if(!(field==='instanceWorkset'&&row.hasInstance===false))editWorkset(row,field,value);}
    sync();message(`전체 ${state.rows.length}개 작업에 설정을 적용했습니다.`,'ok');
  });
  quickSettings.addEventListener('toggle',()=>syncWorksets());
  $('[data-add-row]').addEventListener('click',()=>{if(state.busy)return;state.rows.push(newRow(state.mode==='active'?str(state.context.path):state.hosts[0]||'',state.links[0]||''));state.rowSearch='';$('[data-row-search]').value='';state.rowPage=Math.floor((state.rows.length-1)/100);invalidate();sync();});
  $('[data-row-search]').addEventListener('input',event=>{state.rowSearch=event.target.value;state.rowPage=0;renderOperations();});
  for(const [key,delta] of [['prev',-1],['next',1]])$(`[data-rows-${key}]`).addEventListener('click',()=>{if(state.busy)return;state.rowPage=(state.rowPage||0)+delta;renderOperations();operationList.scrollTop=0;operationList.focus({preventScroll:true});});
  page.querySelectorAll('[data-mode]').forEach(btn=>btn.addEventListener('click',()=>{
    if(state.busy)return;
    switchMode(btn.dataset.mode);
    if(!standalone&&btn.dataset.mode==='batch')manageFiles('hosts');
  }));
  $('.linkbatch-target-modes').addEventListener('keydown',event=>{
    if(state.busy||!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
    const buttons=[...page.querySelectorAll('[data-mode]')];
    const index=event.key==='Home'?0:event.key==='End'?1:1-buttons.findIndex(button=>button.dataset.mode===state.mode);
    event.preventDefault();buttons[index].click();buttons[index].focus({preventScroll:true});
  });
  $('[data-refresh]').addEventListener('click',()=>request('init'));
  $('[data-document-select]').addEventListener('change',event=>{
    if(state.busy||!event.target.value)return;
    rememberDocumentDraft();state.selectedDocumentKey=event.target.value;state.explicitDocumentSelection=true;state.contextPending=true;sync();request('init');
  });
  $('[data-manage-links]')?.addEventListener('click',()=>manageFiles('links'));
  $('[data-manage-hosts]')?.addEventListener('click',()=>manageFiles('hosts'));
  ['hosts','links'].forEach(kind=>{
    $(`[data-file-search="${kind}"]`).addEventListener('input',event=>{state.fileSearch[kind]=event.target.value;renderFiles(kind);});
    $(`[data-select-visible="${kind}"]`).addEventListener('change',event=>{visibleFiles(kind).forEach(path=>{if(event.target.checked)state.selectedFiles[kind].add(path);else state.selectedFiles[kind].delete(path);});renderFiles(kind);});
    $(`[data-remove-selected="${kind}"]`).addEventListener('click',()=>{updateFiles(kind,state[kind].filter(path=>!state.selectedFiles[kind].has(path)));invalidate();renderFiles(kind);sync();});
  });
  $('[data-clear-links]').addEventListener('click',()=>{updateFiles('links',[]);invalidate();renderFiles('links');sync();});
  $('[data-clear-hosts]').addEventListener('click',()=>{updateFiles('hosts',[]);invalidate();renderFiles('hosts');sync();});
  ui.export.addEventListener('click',()=>request('export-template',exportPayload(),'export'));
  ui.import.addEventListener('click',()=>request('pick-excel'));
  ui.check.addEventListener('click',()=>request('preflight',payload(),'preflight'));
  ui.run.addEventListener('click',()=>request('run',payload(),'run'));
  ui.cancel.addEventListener('click',cancelRun);
  resultButton.addEventListener('click',showResult);
  if(standalone)listen('host:doc-changed',p=>{
    // Native document paths may differ from ACC source identities. Deduplicate
    // native notifications here; the Host validates the actual document/token.
    const signature=JSON.stringify([str(p.name),str(p.path),!!p.isLinked]);
    if(signature===nativeDocumentSignature)return;
    nativeDocumentSignature=signature;documentRefreshPending=true;
    if(documentRefreshTimer!==null){clearTimeout(documentRefreshTimer);documentRefreshTimer=null;}
    // Keep an in-flight run/import snapshot intact and refresh once it finishes.
    scheduleDocumentRefresh();
  });
  listen('linkbatch:context',p=>{
    if(state.explicitDocumentSelection&&str(p.requestedDocumentKey)&&str(p.requestedDocumentKey)!==state.selectedDocumentKey)return;
    if(state.contextPending&&state.explicitDocumentSelection&&!p.requestedDocumentKey&&p.activeDocument?.key!==state.selectedDocumentKey)return;
    const previousKey=state.context.key,newKey=str(p.activeDocument?.key),changed=previousKey!==newKey;
    const previousPath=str(state.context.path);
    if(changed){
      rememberDocumentDraft();
      if(state.mode==='active'){
        const saved=state.documentDrafts.get(newKey),carry=state.explicitDocumentSelection?[]:state.rows.filter(row=>!isExisting(row));
        Object.assign(state,saved||{rows:carry,hosts:[],links:uniquePaths(carry.map(row=>row.linkPath)),fileWorksets:new Map(),workbookPath:'',importedContextToken:''});
      }
      resetOperationNodes();
    }
    if(state.contextToken&&state.contextToken!==str(p.contextToken)&&p.running!==true)invalidate();
    state.context=p.activeDocument||{};state.contextToken=str(p.contextToken);ui.document.textContent=state.context.title||'활성 문서가 없습니다.';ui.document.title=state.context.displayPath||display(state.context.path);ui['document-note'].textContent=state.context.displayPath||display(state.context.path)||'현재 열린 프로젝트 문서에 링크를 추가합니다.';
    state.contextPending=false;state.documents=Array.isArray(p.documents)?p.documents:[];
    if(newKey)state.selectedDocumentKey=newKey;else if(!p.selectionUnavailable)state.selectedDocumentKey='';
    const selector=$('[data-document-select]'),documentSignature=JSON.stringify([state.documents,state.selectedDocumentKey,!!p.selectionUnavailable]);
    if(selector.dataset.values!==documentSignature){
      const choices=state.documents.map(doc=>{const option=document.createElement('option');option.value=doc.key;option.textContent=`${doc.title}${doc.key===p.currentDocumentKey?' · 현재 Revit 탭':''}`;option.title=doc.displayPath||doc.path||doc.title;return option;});
      if(p.selectionUnavailable||!choices.length){const option=document.createElement('option');option.value='';option.textContent=p.selectionUnavailable?'선택한 문서가 닫혔습니다. 다른 문서를 선택하세요.':'열린 프로젝트 문서가 없습니다.';choices.unshift(option);}
      selector.replaceChildren(...choices);selector.value=p.selectionUnavailable?'':state.selectedDocumentKey;selector.dataset.values=documentSignature;
    }
    if(p.selectionUnavailable){ui['document-note'].textContent=p.selectionError||'선택한 문서가 닫혔습니다. 다른 열린 문서를 선택하세요.';message(ui['document-note'].textContent,'error');}
    if(state.mode==='active'&&!state.importedContextToken&&previousPath!==str(state.context.path))for(const row of state.rows)if(!isExisting(row)&&(!row.hostPath||sourceKey(row.hostPath)===sourceKey(previousPath))){row.hostPath=str(state.context.path);row.hostDisplayPath=state.context.displayPath||display(row.hostPath);}
    const names=(Array.isArray(p.worksets)?p.worksets:[]).map(w=>typeof w==='string'?w:w.name).filter(Boolean),list=$('#linkbatch-worksets'),key=JSON.stringify(names);
    state.worksetNames=names;state.currentExistingLinks=Array.isArray(p.existingLinks)?p.existingLinks:[];
    mergeExisting(state.currentExistingLinks);
    if(list.dataset.values!==key){list.replaceChildren(...names.map(name=>{const option=document.createElement('option');option.value=name;return option;}));list.dataset.values=key;}
    if(p.running===true){
      state.busy=p.cancelRequested?'cancelling':'run';state.restoredRun=true;
      if(Array.isArray(p.rows)&&JSON.stringify(state.rows)!==JSON.stringify(p.rows))applyImported({...p,mode:'batch'});
      ui.workbook.textContent='진행 중인 링크 작업';
      const progress=p.progress||{};acceptProgress(progress);
      message(progress.message||(p.cancelRequested?'중지 요청 후 현재 파일 처리를 마무리하고 있습니다.':'진행 중인 링크 작업에 다시 연결했습니다.'));

    }else if(p.running===false&&state.restoredRun){state.busy='';state.restoredRun=false;}
    if(p.lastResult)rememberResult(p.lastResult,p.lastResult.phase);
    sync();
  });
  listen('linkbatch:links-picked',p=>addFiles('links',p.paths||[],p.locations||{}));
  listen('linkbatch:hosts-picked',p=>addFiles('hosts',p.paths||[],p.locations||{}));
  listen('linkbatch:links-managed',p=>replaceFiles('links',p));
  listen('linkbatch:hosts-managed',p=>replaceFiles('hosts',p));
  listen('linkbatch:excel-picked',p=>{
    if(!p.path||state.busy)return;
    // Import is atomic: keep the mounted draft until a successful reply arrives.
    request('import',{path:p.path,mode:state.mode,documentKey:state.selectedDocumentKey,contextToken:state.contextToken},'import');
  });
  listen('linkbatch:imported',p=>{
    const userImport=state.busy==='import';state.busy='';
    if(p.cancelled){message('Excel 불러오기를 취소했습니다. 현재 설정을 유지합니다.');}
    else if(p.ok===false){message(p.message||'Excel을 불러오지 못했습니다. 현재 설정을 유지합니다.','error');}
    else{
      applyImported(p);message(p.message||`${state.rows.length}개 작업을 불러왔습니다. 행별 설정을 확인하세요.`,Number(p.summary?.failed)>0?'warning':'ok');
      if(userImport){const importedRows=state.rows;requestAnimationFrame(()=>{if(state.disposed||!page.isConnected||state.rows!==importedRows)return;operationList.scrollTop=0;importedCard.scrollIntoView({block:'start',inline:'nearest'});operationList.scrollIntoView({block:'nearest',inline:'nearest'});});}
    }
    sync();
  });
  listen('linkbatch:exported',p=>{state.busy='';const saved=p.ok===true&&!p.cancelled&&str(p.path).trim();message(p.message||(p.cancelled?'Excel 저장을 취소했습니다.':saved?'현재 설정을 Excel로 저장했습니다.':'Excel을 내보내지 못했습니다.'),saved?'ok':p.cancelled?'':'error');sync();if(saved)showExcelSavedDialog('링크 매니저 현재 설정을 Excel로 저장했습니다.',str(p.path).trim(),filePath=>post('excel:open',{path:filePath}));});
  listen('linkbatch:cancelled',()=>{state.busy='';message('작업을 취소했습니다. 현재 설정을 유지합니다.');sync();});
  for(const event of ['preflighted','completed'])listen(`linkbatch:${event}`,p=>{
    state.busy='';state.restoredRun=false;rememberResult(p,event==='preflighted'?'preflight':'completed');
    if(event==='completed'&&state.mode==='active'){
      const successful=new Set((p.rows||[]).filter(row=>['linked','updated'].includes(str(row.status).toLowerCase())).map(row=>row.rowId));
      state.rows=state.rows.filter(row=>isExisting(row)||!successful.has(row.rowId));
      for(const row of state.rows)if(successful.has(row.rowId)){row._dirty=false;row.action='SKIP';}
      state.links=uniquePaths(state.rows.filter(row=>!isExisting(row)).map(row=>row.linkPath));renderFiles('links');request('init');
    }
    message(p.message||'처리가 끝났습니다. 결과창에서 확인하세요.',p.ok?'ok':'error');sync();showResult();
  });
  listen('linkbatch:result-exported',p=>{
    state.busy='';sync();
    if(p.ok===true&&p.path){
      if(state.lastResult&&state.lastResult.resultId===p.resultId)state.lastResult.excelPath=p.path;
      showResult();showExcelSavedDialog('링크 매니저 결과 Excel을 저장했습니다.',p.path,filePath=>post('excel:open',{path:filePath}));
    }else{showResult();if(!p.cancelled)toast(p.message||'결과 Excel을 저장하지 못했습니다.','err',5200);}
  });
  listen('linkbatch:progress',p=>{if(!state.busy)return;acceptProgress(p);if(p.message)message(p.message);else syncProgress();});
  function handleError(p){const exporting=state.busy==='result-export';if(p.busy!==true)state.busy='';const text=[p.message||'처리 중 오류가 발생했습니다.',p.detail].filter(Boolean).join(' ');message(text,'error');sync();if(exporting){showResult();toast(text,'err',5200);}}
  listen('linkbatch:error',handleError);
  listen('host:error',p=>{if(str(p.sourceEvent).startsWith('linkbatch:'))handleError(p);});
  if(standalone){
    for(const kind of ['hosts','links']){
      const target=kind==='links'?simpleCard:$(`[data-linkbatch-drop="${kind}"]`);
      const markTarget=()=>post('linkmanager:drop-target',{kind});
      target.addEventListener('dragenter',markTarget,true);target.addEventListener('dragover',markTarget,true);
      dropCleanups.push(()=>{target.removeEventListener('dragenter',markTarget,true);target.removeEventListener('dragover',markTarget,true);});
      dropCleanups.push(attachRvtDropZone(target,{onDropPaths:paths=>{if(!state.busy)addFiles(kind,paths);},onInvalid:()=>{if(!state.busy)message('RVT 파일을 목록에 놓거나 파일 추가 버튼을 사용하세요.','error');}}));
    }
    dropCleanups.push(attachExcelDropZone(excelCard,{onDropPaths:paths=>{
      if(state.busy)return;
      if(paths.length!==1){message('Excel 양식은 한 번에 하나씩 불러오세요.','error');return;}
      request('import',{path:paths[0],mode:state.mode,documentKey:state.selectedDocumentKey,contextToken:state.contextToken},'import');
    },onInvalid:()=>{if(!state.busy)message('Excel 양식(.xlsx) 하나를 놓거나 불러오기 버튼을 사용하세요.','error');}}));
  }
  // Persisted preferences are deliberately local to this mounted editor. Shared
  // settings notifications do not replace this in-progress draft or its controls.
  renderFiles('links');renderFiles('hosts');sync();request('init');
  return ()=>{state.disposed=true;if(documentRefreshTimer!==null)clearTimeout(documentRefreshTimer);workspaceObserver.disconnect();dropCleanups.forEach(off=>off());if(progressOwner!==null)ProgressDialog.hide(progressOwner);if(resultDialog)resultDialog.close();subscriptions.forEach(off=>{if(typeof off==='function')off();});};
}
