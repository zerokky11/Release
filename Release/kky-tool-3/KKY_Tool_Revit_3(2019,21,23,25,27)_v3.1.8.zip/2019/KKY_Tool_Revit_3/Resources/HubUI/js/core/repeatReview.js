import { post, onHost } from './bridge.js';
import { createFeatureGuideButton } from './featureGuide.js?v=20260916linkbatch1';

const STORAGE = 'kky.repeatReview.projects.v1';
const HISTORY = 'kky.settings.repeat-review-names.v1';
const read = (key) => { try { return JSON.parse(localStorage.getItem(key) || '{}'); } catch { return {}; } };
const write = (key, value) => localStorage.setItem(key, JSON.stringify(value));
const lowerKeys = (value) => Array.isArray(value) ? value.map(lowerKeys) : value && typeof value === 'object'
  ? Object.fromEntries(Object.entries(value).map(([k,v]) => [k[0].toLowerCase() + k.slice(1), lowerKeys(v)])) : value;
const basename = path => String(path || '').split(/[\\/]/).pop();
const keywords = value => [...new Map((Array.isArray(value) ? value : String(value || '').split(/\r?\n/)).map(v=>String(v).trim()).filter(Boolean).map(v=>[v.toLowerCase(),v])).values()];
const keywordMode = value => String(value || '').trim().toUpperCase() === 'AND' ? 'AND' : 'OR';
const detectedColumns = p => (p.detection?.answerColumns || p.columns.filter(c=>c.suggested&&c.header!=='예외 적용 근거').map(c=>c.index)).filter(i=>p.columns.some(c=>c.index===i));
const detectionText = (p,manual=false) => manual ? '답변 열을 직접 지정했습니다.' : p.detection?.reason || '자동으로 확인된 답변 열이 없습니다. 작성된 내용 예시를 확인하고 답변 열을 선택하세요.';
export const repeatProjectKey = models => String(models[0] || '기본 프로젝트').replace(/[\\/][^\\/]*$/, '').toLowerCase();
export function validRepeatName(value) {
  return !!String(value || '').trim() && value.length <= 70 && !/[<>:"/\\|?*\x00-\x1f]/.test(value) && !value.endsWith('.');
}
function el(tag, text, className) {
  const node = document.createElement(tag); if (text != null) node.textContent = text; if (className) node.className = className; return node;
}
function button(text, fn) { const b=el('button', text, 'btn btn--secondary'); b.type='button'; b.addEventListener('click', fn); return b; }
function input(value, label) { const n=el('input'); n.value=value || ''; n.setAttribute('aria-label',label); return n; }
function invalidatePreview(host, message, className='repeat-hint') {
  // Keep the occupied space until a new preview arrives so controls below it do not jump during editing.
  const height=host.getBoundingClientRect().height;
  if(height>0)host.style.minHeight=`${height}px`;
  host.replaceChildren(el('p',message,className));
}
function request(event, response, payload) {
  return new Promise((resolve,reject) => {
    const requestId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const off = onHost(response, raw => { const p=lowerKeys(raw); if(p.requestId !== requestId) return; clearTimeout(timer); off?.(); p.error ? reject(Error(p.error)) : resolve(p); });
    const timer=setTimeout(()=>{off?.();reject(Error('응답이 지연되고 있습니다. 잠시 후 다시 불러오세요.'));},300000);
    post(event,{...payload,requestId});
  });
}
function styles() {
  if(document.getElementById('repeat-review-styles')) return;
  const s=el('style'); s.id='repeat-review-styles'; s.textContent=`
  .repeat-overlay{--repeat-gap:24px;position:fixed;inset:0;background:#0008;z-index:30000;display:grid;place-items:center;padding:var(--repeat-gap);box-sizing:border-box}
  .repeat-dialog{background:var(--panel,#fff);color:var(--text,#182336);width:min(1100px,100%);max-height:calc(100vh - var(--repeat-gap)*2);max-height:calc(100dvh - var(--repeat-gap)*2);min-width:0;min-height:0;box-sizing:border-box;overflow:hidden;border:1px solid #8291a455;border-radius:14px;display:grid;grid-template-rows:minmax(0,auto) minmax(80px,1fr) auto;box-shadow:0 18px 70px #0004}
  .repeat-head,.repeat-foot{padding:18px 22px}.repeat-head{min-height:0;overflow:auto;overscroll-behavior:contain}.repeat-head h2{margin:0 0 8px;font-size:20px}.repeat-head p,.repeat-hint{font-size:13px;color:var(--muted,#607087);margin:4px 0;line-height:1.6}
  .repeat-body{padding:0 22px 18px;overflow:auto;min-height:0;min-width:0;overscroll-behavior:contain;scrollbar-gutter:stable}.repeat-feature{border:1px solid #8a99ab55;border-radius:9px;padding:16px;margin:12px 0}.repeat-feature h3{font-size:16px;margin:0 0 12px}
  .repeat-fields{display:flex;gap:12px;flex-wrap:wrap;align-items:end}.repeat-fields label{display:grid;gap:6px;font-size:13px;flex:1;min-width:220px}
  .repeat-dialog input:not([type=checkbox]),.repeat-dialog select,.repeat-dialog textarea{background:var(--panel,#fff);color:inherit;border:1px solid #8897aa80;border-radius:5px;padding:7px 9px;max-width:100%;min-width:130px}.repeat-dialog input[type=checkbox]{margin-right:6px}
  .repeat-keyword-field{display:grid;gap:6px;margin:12px 0;font-size:13px}.repeat-keyword-field textarea{box-sizing:border-box;width:100%;min-height:80px;resize:vertical;font:inherit}.repeat-keyword-preview{box-sizing:border-box;max-height:270px;overflow:auto;overscroll-behavior:contain;scrollbar-gutter:stable;font-size:13px;line-height:1.6;white-space:pre-wrap}.repeat-keyword-match{display:block;font-size:12px;color:var(--muted,#607087);padding-left:24px}
  .repeat-tools{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:12px 0}.repeat-foot{border-top:1px solid #8897aa44;display:flex;gap:12px;justify-content:flex-end;align-items:center;min-width:0}.repeat-foot>button{flex-shrink:0}.repeat-status{margin-right:auto;min-width:0;max-height:64px;overflow:auto;overscroll-behavior:contain;font-size:13px;white-space:pre-wrap;overflow-wrap:anywhere}
  .repeat-sheet{padding:10px 0;border-top:1px solid #8897aa44}.repeat-sheet summary{cursor:pointer;overflow-wrap:anywhere}.repeat-sheet summary span{font-size:12px;margin-left:8px;color:#687c95}.repeat-columns{display:grid;gap:6px;margin:12px 0}.repeat-columns label{padding:7px;background:#8196ad0d;overflow-wrap:anywhere;font-size:13px}.repeat-columns small{display:block;padding-left:24px;color:var(--muted,#66788d)}
  .repeat-warning{color:#b15c05}.repeat-example{font-size:12px;margin:10px 0;overflow-wrap:anywhere}.repeat-enabled{display:inline-flex;gap:5px;align-items:center;font-size:13px;margin-right:10px}.repeat-replies{box-sizing:border-box;max-height:270px;overflow:auto;overscroll-behavior:contain;scrollbar-gutter:stable;border:1px solid #8897aa44;padding:10px}.repeat-replies label{display:block;padding:8px;white-space:pre-wrap;border-bottom:1px solid #8897aa22}
  @media(max-width:650px){.repeat-overlay{--repeat-gap:8px}.repeat-fields{display:block}.repeat-fields label{margin:8px 0}.repeat-foot{flex-wrap:wrap}.repeat-status{width:100%}}
  @media(max-height:520px){.repeat-overlay{--repeat-gap:8px}.repeat-head,.repeat-foot{padding:10px 16px}}
  `; document.head.append(s);
}
export function createRepeatToggle(getValue, setValue) {
  styles(); const label=el('label',null,'repeat-enabled'); const check=el('input');check.type='checkbox';check.checked=getValue();
  check.addEventListener('change',()=>setValue(check.checked)); label.append(check,document.createTextNode('다회차 검토'));
  label.title='이전 회신을 반영하고 결과 엑셀 파일명을 설정합니다.'; return label;
}

export async function openRepeatReviewSettings({features,models,outputMode='files',sourceMode='bqc'}) {
  styles();
  const project=repeatProjectKey(models), projects=read(STORAGE), histories=read(HISTORY);
  const loaded=await request('repeat:settings','repeat:settings',{mode:'load',project});
  const saved=loaded.settings || projects[project] || {};
  for(const [key,value]of Object.entries(saved.histories||{}))histories[key]=[...new Set([...(histories[key]||[]),...value])];
  const options={enabled:true,project,features:{}}; const ui=new Map(); const tokens=[]; let pending=0, closed=false,lastError='';
  const priorFocus=document.activeElement;
  const overlay=el('div',null,'repeat-overlay'), modal=el('section',null,'repeat-dialog');
  modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-labelledby','repeat-title');
  const head=el('header',null,'repeat-head'), title=el('h2','결과 엑셀 파일명 설정');title.id='repeat-title';
  head.append(createFeatureGuideButton('repeatreview', { inline: true, featureLabel: '다회차 검토' }));
  head.append(title,el('p','기능별로 결과 엑셀 파일에 사용할 이름을 입력하세요. 저장한 이름은 다음 검토에서 다시 선택할 수 있습니다.'),el('p','이전 회신은 폴더 또는 파일로 불러오세요. 기존 양식도 사용할 수 있습니다. 첫 검토라면 이전 회신을 선택하지 않아도 됩니다.'));
  const body=el('div',null,'repeat-body');body.dataset.scrollKey='repeat-body';
  const status=el('div',null,'repeat-status');status.setAttribute('role','status');
  const footer=el('footer',null,'repeat-foot');modal.append(head,body,footer);overlay.append(modal);document.body.append(overlay);
  let finish;
  const promise=new Promise(resolve=>{finish=resolve;});
  function close(value) { if(closed)return;closed=true;overlay.remove();document.removeEventListener('keydown',trap,true);if(!value)post('repeat:release',{tokens});priorFocus?.focus({preventScroll:true});finish(value); }
  function trap(e) {
    if(e.key==='Escape'&&!pending){e.preventDefault();e.stopPropagation();close(null);}
    if(e.key!=='Tab')return;
    const nodes=[...modal.querySelectorAll('button,input,select,textarea,summary')].filter(n=>!n.disabled&&n.getClientRects().length);
    if(!nodes.length)return; const first=nodes[0],last=nodes[nodes.length-1];
    if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
  }
  document.addEventListener('keydown',trap,true);
  function updateStatus() {
    let count=0,needs=0,skipped=0,replyNeeds=0;
    for(const f of Object.values(options.features))for(const c of f.sheets){count++;if(c.skip)skipped++;else if(!c.model)needs++;}
    for(const featureUi of ui.values())for(const entry of featureUi.entries)if(!entry.choice.skip&&!entry.answerColumnsManual&&entry.p.detection?.needsReview)replyNeeds++;
    const names=Object.values(options.features).map(f=>f.name.trim().toLowerCase());
    const duplicateNames=new Set(names).size!==names.length;
    const overlappingColumns=Object.values(options.features).some(f=>f.sheets.some(s=>!s.skip&&s.answerColumns.includes(s.decisionColumn)));
    const issue=duplicateNames?'기능별 결과 파일명은 서로 다르게 입력하세요.':overlappingColumns?'답변 열과 판정 열은 서로 다르게 선택하세요.':Object.values(options.features).some(f=>!f.destinationHeader.trim())?'이전 답변을 넣을 열 제목을 입력하세요.':'';
    status.textContent=pending?'설정을 처리하는 중…':lastError||issue||`${count}개 시트 · 연결 ${count-needs-skipped} · 확인 필요 ${needs} · 제외 ${skipped}${replyNeeds?` · 답변 열 확인 ${replyNeeds}`:''}`;
    save.disabled=!!pending||needs>0||!!issue||Object.values(options.features).some(f=>!validRepeatName(f.name));
  }
  const cancel=button('취소',()=>close(null));
  const save=button('저장하고 검토 시작',async()=>{
    pending++;lastError='';updateStatus();
    try {
      const settings={features:{}};
      for(const [key,f] of Object.entries(options.features)) {
        if(!validRepeatName(f.name))throw Error('파일명에 사용할 이름을 확인하세요.');
        const layouts={...(saved.features?.[key]?.layouts || {})};
        for(const entry of ui.get(key).entries)layouts[entry.p.layout]={answerColumns:entry.choice.answerColumns,decisionColumn:entry.choice.decisionColumn,keywordColumns:entry.choice.keywordColumns};
        settings.features[key]={name:f.name,previousName:f.previousName,destinationHeader:f.destinationHeader.trim(),exclusionKeywords:[...f.exclusionKeywords],keywordMatchMode:f.keywordMatchMode,layouts};
        histories[key]=[...new Set([f.name,...(histories[key]||[])])].slice(0,30);
      }
      settings.histories=histories;
      await request('repeat:settings','repeat:settings',{mode:'save',project,settings});
      projects[project]=settings;write(STORAGE,projects);write(HISTORY,histories);close(options);
    }catch(e){lastError=e.message;}finally{pending--;if(!closed)updateStatus();}
  });save.className='btn btn--primary';footer.append(status,cancel,save);
  for(const feature of features) {
    const stored=saved.features?.[feature.key]||{}, f={name:stored.name||feature.label.replace(/[<>:"/\\|?*]/g,' '),previousName:stored.previousName||'',destinationHeader:stored.destinationHeader||'비고',exclusionKeywords:keywords(stored.exclusionKeywords),keywordMatchMode:keywordMode(stored.keywordMatchMode),sheets:[]};options.features[feature.key]=f;
    const section=el('section',null,'repeat-feature');section.dataset.feature=feature.key;section.append(el('h3',feature.label));
    const fields=el('div',null,'repeat-fields'), nameLabel=el('label','파일명 뒤에 붙일 이름'), name=input(f.name,`${feature.label} 파일명 뒤에 붙일 이름`);
    name.maxLength=70;name.dataset.focusKey=`repeat-${feature.key}-name`;
    const list=el('datalist');list.id=`repeat-names-${feature.key}`;for(const h of histories[feature.key]||[]){const o=el('option');o.value=h;list.append(o);}name.setAttribute('list',list.id);nameLabel.append(name,list);fields.append(nameLabel);
    const destinationLabel=el('label','이전 답변을 넣을 열'),destination=input(f.destinationHeader,`${feature.label} 이전 답변을 넣을 열`),destinationList=el('datalist');
    destination.maxLength=80;destination.dataset.replyDestination=feature.key;destinationList.id=`repeat-destinations-${feature.key}`;
    for(const header of ['비고','작업자 답변','이전 코멘트']){const o=el('option');o.value=header;destinationList.append(o);}destination.setAttribute('list',destinationList.id);
    const changeDestination=()=>{f.destinationHeader=destination.value;updateStatus();};destination.addEventListener('input',changeDestination);destination.addEventListener('compositionend',changeDestination);
    destinationLabel.append(destination,destinationList,el('small','이전 회신에서 가져온 작업자 답변을 새 결과의 어느 열에 기록할지 선택하세요. 없으면 해당 제목의 열을 추가합니다.','repeat-hint'));fields.append(destinationLabel);
    const parameterSuffix=feature.key==='connector' ? `_${String(feature.parameter||'파라미터').replace(/[<>:"/\\|?*]/g,'_')}${feature.runCount ? '_검토01' : ''}` : '';
    const example=el('p',null,'repeat-example');const updateExample=()=>{example.textContent=outputMode==='combined'&&!feature.runCount
      ? `통합 저장 예: ${sourceMode}_${f.name}${parameterSuffix}_20260906_150000_12EA.xlsx · 12EA는 예외를 제외한 최종 조치 대상 수의 예시입니다.`
      : `예: ${basename(models[0]||'RVT파일명.rvt').replace(/\.rvt$/i,'')}_${f.name}${parameterSuffix}_12EA.xlsx · 예외를 제외한 최종 조치 대상 수를 붙입니다. 0건은 00EA, 1건은 01EA로 표시됩니다.`;
      if(feature.key==='points')example.textContent=outputMode==='combined'
        ? `통합 저장 예: ${sourceMode}_${f.name}_20260906_150000.xlsx · 기준점과 북각은 추출 자료이므로 오류 수량을 붙이지 않습니다. 이전 답변은 같은 항목에 이어서 기록할 수 있습니다.`
        : `예: ${basename(models[0]||'RVT파일명.rvt').replace(/\.rvt$/i,'')}_${f.name}.xlsx · 기준점과 북각은 추출 자료이므로 오류 수량을 붙이지 않습니다. 이전 답변은 같은 항목에 이어서 기록할 수 있습니다.`;
      if(feature.runCount)example.textContent+=` 등록한 연속성 검토 ${feature.runCount}개는 파라미터·등록 번호별로 각각 저장됩니다.`;
    };
    name.addEventListener('input',()=>{f.name=name.value;updateExample();updateStatus();});name.addEventListener('compositionend',()=>{f.name=name.value;updateExample();updateStatus();});updateExample();
    const oldDetails=el('details'), oldSummary=el('summary','이전 결과 이름이 다름'),oldLabel=el('label','이전 결과에서 찾을 이름'),old=input(f.previousName,'이전 결과에서 찾을 이름');
    old.addEventListener('input',()=>{f.previousName=old.value;});oldLabel.append(old);oldDetails.append(oldSummary,oldLabel);if(f.previousName)oldDetails.open=true;
    const listHost=el('div'),keywordPreview=el('div',null,'repeat-keyword-preview');
    const featureUi={entries:[],host:listHost,keywordVersion:0,keywordPreviewUsed:false};ui.set(feature.key,featureUi);
    featureUi.invalidateKeywords=()=>{featureUi.keywordVersion++;if(featureUi.keywordPreviewUsed)invalidatePreview(keywordPreview,'설정이 변경되었습니다. 키워드 제외 미리보기를 다시 확인하세요.');};
    const keywordLabel=el('label','오류 수량에서 제외할 키워드 · 줄마다 하나','repeat-keyword-field'),keywordInput=el('textarea');
    keywordInput.value=f.exclusionKeywords.join('\n');keywordInput.setAttribute('aria-label',`${feature.label} 오류 수량에서 제외할 키워드`);keywordInput.dataset.focusKey=`repeat-${feature.key}-keywords`;
    const changeKeywords=()=>{const next=keywords(keywordInput.value);if(JSON.stringify(next)===JSON.stringify(f.exclusionKeywords))return;f.exclusionKeywords=next;for(const entry of featureUi.entries){entry.choice.exclusionKeywords=[...next];entry.invalidatePreview?.();}featureUi.invalidateKeywords();};
    keywordInput.addEventListener('input',changeKeywords);keywordInput.addEventListener('compositionend',changeKeywords);keywordLabel.append(keywordInput);
    const modeLabel=el('label','키워드 조건','repeat-keyword-field'),modeSelect=el('select'),keywordHint=el('p',null,'repeat-hint');
    modeSelect.setAttribute('aria-label',`${feature.label} 키워드 조건`);modeSelect.dataset.focusKey=`repeat-${feature.key}-keyword-mode`;
    for(const [value,label] of [['OR','OR — 하나라도 포함'],['AND','AND — 모두 포함']]){const option=el('option',label);option.value=value;modeSelect.append(option);}modeSelect.value=f.keywordMatchMode;modeLabel.append(modeSelect);
    const refreshKeywordHint=()=>{keywordHint.textContent=(f.keywordMatchMode==='AND'
      ? '같은 행의 선택한 열에 모든 키워드가 있으면 제외 후보로 표시합니다. 키워드가 서로 다른 셀에 있어도 적용됩니다.'
      : '선택한 열에 키워드가 하나라도 포함되어 있으면 제외 후보로 표시합니다.')+' 각 키워드는 한 셀 안에 온전히 포함되어야 하며, 대소문자는 구분하지 않습니다. 이 기능의 회신 전체에 적용됩니다. 비워두면 키워드로 제외하지 않습니다.';};
    modeSelect.addEventListener('change',()=>{f.keywordMatchMode=keywordMode(modeSelect.value);for(const entry of featureUi.entries){entry.choice.keywordMatchMode=f.keywordMatchMode;entry.invalidatePreview?.();}featureUi.invalidateKeywords();refreshKeywordHint();});refreshKeywordHint();
    const previewKeywords=button('키워드 제외 미리보기',async()=>{
      const selected=featureUi.entries.filter(e=>!e.choice.skip),version=featureUi.keywordVersion;featureUi.keywordPreviewUsed=true;
      if(!selected.length){invalidatePreview(keywordPreview,'회신 파일을 먼저 불러오세요.');return;}
      pending++;updateStatus();invalidatePreview(keywordPreview,'선택한 열에서 키워드를 찾는 중…');
      try {
        const groups=new Map();let matches=0,sheets=0;
        for(const entry of selected){
          if(closed||version!==featureUi.keywordVersion)return;
          const response=await request('repeat:answers','repeat:answers',{choice:JSON.parse(JSON.stringify(entry.choice))});
          if(closed||version!==featureUi.keywordVersion)return;
          const rows=(response.rows||[]).filter(r=>r.keywordMatches?.length);if(rows.length)sheets++;matches+=rows.length;
          for(const row of rows){const key=JSON.stringify([row.answer||'',row.keywordMatches]);if(!groups.has(key))groups.set(key,{answer:row.answer||'(답변 없음)',matches:row.keywordMatches,count:0});groups.get(key).count++;}
        }
        keywordPreview.replaceChildren(el('strong',`키워드 제외 후보 ${matches}건 · ${sheets}개 시트`),el('p','2차 결과에서도 같은 항목·조건으로 확인된 경우에만 최종 수량에서 제외합니다.','repeat-hint'));
        if(selected.some(e=>!e.choice.keywordColumns.length))keywordPreview.append(el('p','키워드 검색 열을 선택하지 않은 회신이 있습니다. 아래 열 설정을 확인하세요.','repeat-warning'));
        for(const group of [...groups.values()].slice(0,30))keywordPreview.append(el('p',`${group.count}건 · ${group.matches.join(', ')}\n${group.answer}`));
        if(groups.size>30)keywordPreview.append(el('p',`답변 ${groups.size}종 중 30종을 표시했습니다. 나머지는 시트별 답변 확인에서 볼 수 있습니다.`,'repeat-hint'));
        keywordPreview.style.minHeight='';
      }catch(e){if(!closed&&version===featureUi.keywordVersion)keywordPreview.textContent=e.message;}finally{pending--;if(!closed)updateStatus();}
    });
    const tools=el('div',null,'repeat-tools');
    async function inspect(mode) {
      pending++;lastError='';updateStatus();
      try{
        const response=await request('repeat:inspect','repeat:inspected',{mode,models,previousName:f.previousName||f.name,feature:feature.key});
        if(closed){post('repeat:release',{tokens:(response.sheets||[]).map(s=>s.token).filter(Boolean)});return;}
        for(const p of response.sheets||[]) {
          if(p.error){const warning=el('p',`${basename(p.path)}: ${p.error}`,'repeat-warning');listHost.append(warning);continue;}
          if(featureUi.entries.some(e=>e.p.path===p.path&&e.p.sheet===p.sheet)){post('repeat:release',{tokens:[p.token]});continue;}
          tokens.push(p.token);
          const choice={token:p.token,model:p.model||'',skip:!!p.feature&&p.feature!==feature.key,answerColumns:detectedColumns(p),decisionColumn:p.columns.find(c=>c.header==='검토 판정')?.index??-1,exceptionRows:[],exclusionKeywords:[...f.exclusionKeywords],keywordMatchMode:f.keywordMatchMode};
          choice.keywordColumns=[...choice.answerColumns];
          f.sheets.push(choice);const entry={p,choice,answerColumnsManual:false,keywordColumnsCustomized:false};featureUi.entries.push(entry);renderSheet(entry,featureUi,feature);featureUi.invalidateKeywords();
        }
      }catch(e){lastError=e.message;}
      finally{pending--;if(!closed)updateStatus();}
    }
    tools.append(button('회신 폴더 선택',()=>inspect('folder')),button('회신 파일 선택',()=>inspect('files')));
    section.append(fields,example,oldDetails,keywordLabel,modeLabel,keywordHint,previewKeywords,keywordPreview,tools,listHost);body.append(section);
  }
  function renderSheet(entry,featureUi,feature) {
    const {p,choice}=entry, d=el('details',null,'repeat-sheet');d.open=!choice.model||choice.skip;
    const replyHost=el('div');let replyVersion=0,previewUsed=false;
    entry.invalidatePreview=()=>{replyVersion++;if(previewUsed){replyHost.className='repeat-replies';invalidatePreview(replyHost,'설정이 변경되었습니다. 답변과 키워드 일치를 다시 확인하세요.');}};
    const summary=el('summary',`${basename(p.path)} / ${p.sheet}`),badge=el('span');summary.append(badge);d.append(summary);
    const actions=el('div',null,'repeat-tools'),model=el('select');model.setAttribute('aria-label',`${basename(p.path)} 대상 RVT`);
    for(const [v,t] of [['','대상 RVT 선택'],['@rows','각 행의 파일명으로 연결'],...models.map(m=>[m,basename(m)])]){const o=el('option',t);o.value=v;model.append(o);}model.value=choice.model;
    const skipLabel=el('label'),skip=el('input');skip.type='checkbox';skip.checked=choice.skip;skipLabel.append(skip,document.createTextNode('이 회신 제외'));
    const refresh=()=>{model.value=choice.model;skip.checked=choice.skip;badge.textContent=choice.skip?'제외':choice.model?`연결 · ${p.rowCount}행`:'연결 필요';};
    model.addEventListener('change',()=>{choice.model=model.value;refresh();updateStatus();});skip.addEventListener('change',()=>{choice.skip=skip.checked;featureUi.invalidateKeywords();refresh();updateStatus();});
    actions.append(model,skipLabel);d.append(actions);
    if(p.feature&&p.feature!==feature.key)d.append(el('p','다른 검토 기능의 결과입니다. 해당 기능에 다시 등록하세요.','repeat-warning'));
    const detectionHint=el('p',detectionText(p),'repeat-hint repeat-detection');
    entry.refreshDetection=()=>{detectionHint.textContent=detectionText(p,entry.answerColumnsManual);detectionHint.classList.toggle('repeat-warning',!entry.answerColumnsManual&&p.detection?.needsReview===true);};entry.refreshDetection();
    d.append(detectionHint,el('p','답변 열은 엑셀 파일마다 확인합니다. 자동 선택이 맞는지 내용 예시를 확인하세요. 제목이 없는 열도 선택할 수 있습니다.','repeat-hint'));
    const columns=el('div',null,'repeat-columns repeat-answer-columns'),checks=new Map(),keywordChecks=new Map();
    for(const c of p.columns){
      if(['검토 판정','이전 판정','다회차 상태','이전 회신 위치','예외 적용 근거'].includes(c.header))continue;
      const label=el('label'),check=el('input');check.type='checkbox';check.checked=choice.answerColumns.includes(c.index);checks.set(c.index,check);
      check.addEventListener('change',()=>{entry.answerColumnsManual=true;entry.refreshDetection();choice.answerColumns=[...checks].filter(([,n])=>n.checked).map(([i])=>i);choice.exceptionRows=[];if(!entry.keywordColumnsCustomized){choice.keywordColumns=[...choice.answerColumns];for(const [i,n]of keywordChecks)n.checked=choice.keywordColumns.includes(i);}entry.invalidatePreview();featureUi.invalidateKeywords();updateStatus();});
      label.append(check,document.createTextNode(`${c.letter}열 · ${c.header||'제목 없음'}`),el('small',c.samples.join(' / ')||'작성된 내용 없음'));columns.append(label);
    }
    d.append(columns);
    const decision=el('select');decision.setAttribute('aria-label','예외 여부가 적힌 판정 열');
    for(const c of [{index:-1,letter:'',header:'판정 열 없음'},...p.columns]){const o=el('option',`${c.letter}${c.letter?'열 · ':''}${c.header||'제목 없음'}`);o.value=String(c.index);decision.append(o);}decision.value=String(choice.decisionColumn);
    decision.addEventListener('change',()=>{choice.decisionColumn=Number(decision.value);choice.exceptionRows=[];entry.invalidatePreview();featureUi.invalidateKeywords();updateStatus();});
    const decisionLabel=el('label','예외 여부가 적힌 판정 열 ');decisionLabel.append(decision);d.append(decisionLabel,el('p','판정 열의 ‘예외 인정’만 자동으로 제외합니다. 코멘트만 있는 기존 회신은 아래에서 예외를 지정할 수 있습니다.','repeat-hint'));
    const keywordDetails=el('details'),keywordSummary=el('summary','키워드를 찾을 열');keywordDetails.append(keywordSummary,el('p','기본값은 답변 열입니다. 답변 열과 별도로 선택할 수 있으며, 제목이 없는 열도 검색할 수 있습니다.','repeat-hint'));
    const keywordColumns=el('div',null,'repeat-columns repeat-keyword-columns');
    for(const c of p.columns){
      const label=el('label'),check=el('input');check.type='checkbox';check.checked=choice.keywordColumns.includes(c.index);check.setAttribute('aria-label',`키워드 검색 ${c.letter}열 · ${c.header||'제목 없음'}`);check.dataset.focusKey=`repeat-${p.token}-keyword-${c.index}`;keywordChecks.set(c.index,check);
      check.addEventListener('change',()=>{entry.keywordColumnsCustomized=true;choice.keywordColumns=[...keywordChecks].filter(([,n])=>n.checked).map(([i])=>i);entry.invalidatePreview();featureUi.invalidateKeywords();updateStatus();});
      label.append(check,document.createTextNode(`${c.letter}열 · ${c.header||'제목 없음'}`),el('small',c.samples.join(' / ')||'작성된 내용 없음'));keywordColumns.append(label);
    }
    keywordDetails.append(keywordColumns,button('같은 양식에 키워드 검색 열 적용',()=>{
      let count=0;for(const other of featureUi.entries){if(other.p.layout!==p.layout)continue;other.choice.keywordColumns=[...choice.keywordColumns];other.keywordColumnsCustomized=true;other.invalidatePreview();other.sync();count++;}featureUi.invalidateKeywords();updateStatus();status.textContent=`같은 양식 ${count}개에 키워드 검색 열을 적용했습니다.`;
    }));d.append(keywordDetails);
    entry.sync=()=>{for(const [i,c]of checks)c.checked=choice.answerColumns.includes(i);for(const [i,c]of keywordChecks)c.checked=choice.keywordColumns.includes(i);decision.value=String(choice.decisionColumn);};
    const buttons=el('div',null,'repeat-tools');buttons.append(button('같은 양식에 답변·판정 열 적용',()=>{
      let count=0;for(const other of featureUi.entries){if(other.p.layout!==p.layout)continue;other.answerColumnsManual=true;other.refreshDetection();other.choice.answerColumns=[...choice.answerColumns];other.choice.decisionColumn=choice.decisionColumn;other.choice.exceptionRows=[];if(!other.keywordColumnsCustomized)other.choice.keywordColumns=[...choice.answerColumns];other.invalidatePreview();other.sync();count++;}featureUi.invalidateKeywords();updateStatus();status.textContent=`같은 양식 ${count}개에 적용했습니다.`;
    }),button('답변 확인 · 예외 지정',async()=>{
      const version=++replyVersion;previewUsed=true;pending++;updateStatus();
      try{
        const response=await request('repeat:answers','repeat:answers',{choice:JSON.parse(JSON.stringify(choice))});if(closed||version!==replyVersion)return;
        replyHost.replaceChildren();replyHost.className='repeat-replies';
        const allRows=response.rows||[],matched=allRows.filter(r=>r.keywordMatches?.length).length;
        replyHost.append(el('strong',`확인 ${allRows.length}건 · 키워드 제외 후보 ${matched}건`),el('p','아래 항목을 체크하면 수동 예외로 지정됩니다. 키워드 후보는 별도로 체크하지 않아도 됩니다. 2차 결과에서 같은 항목·조건일 때만 최종 수량에서 제외합니다.','repeat-hint'));
        const groups=new Map();for(const r of allRows){const k=JSON.stringify([r.answer||'',r.decision||'',r.keywordMatches||[]]);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(r);}
        for(const rows of groups.values()){
          const label=el('label'),check=el('input');check.type='checkbox';check.checked=rows.every(r=>choice.exceptionRows.includes(r.row));
          check.addEventListener('change',()=>{const numbers=new Set(choice.exceptionRows);for(const r of rows)check.checked?numbers.add(r.row):numbers.delete(r.row);choice.exceptionRows=[...numbers];});
          label.append(check,document.createTextNode(`${rows.length}건 · ${rows.slice(0,5).map(r=>r.row).join(', ')}행\n${rows[0].answer||'(답변 없음)'}${rows[0].decision?'\n판정: '+rows[0].decision:''}`));
          if(rows[0].keywordMatches?.length)label.append(el('small',`키워드 일치: ${rows[0].keywordMatches.join(', ')}`,'repeat-keyword-match'));replyHost.append(label);
        }
        if(!groups.size)replyHost.append(el('p','선택한 열에 답변이나 일치하는 키워드가 없습니다. 열 선택을 확인하세요.'));
        replyHost.style.minHeight='';
      }catch(e){if(!closed&&version===replyVersion)lastError=e.message;}finally{pending--;if(!closed)updateStatus();}
    }));d.append(buttons,replyHost);featureUi.host.append(d);refresh();
  }
  updateStatus();requestAnimationFrame(()=>body.querySelector('input')?.focus({preventScroll:true}));return promise;
}

export function showRepeatSummary(raw) {
  const data=lowerKeys(raw); if(!data.rows?.length)return;styles();
  const overlay=el('div',null,'repeat-overlay'),modal=el('section',null,'repeat-dialog'),head=el('header',null,'repeat-head');
  head.append(el('h2','다회차 검토 결과'),el('p','검출 결과의 상세 행은 유지되며, 예외로 인정된 항목은 조치 대상에서 제외되었습니다. 수량은 중복 상세 행을 정리한 검토 항목 기준입니다.'));
  const body=el('div',null,'repeat-body'),table=el('table');table.style.width='100%';
  const headers=el('tr');for(const h of ['RVT','검토 기능','검출 항목','기존 예외','조치 대상','코멘트 반영','재확인'])headers.append(el('th',h));table.append(headers);
  for(const r of data.rows){const tr=el('tr'),quantityKnown=r.quantityKnown!==false&&r.feature!=='points',quantityLabel=r.feature==='points'?'집계 대상 아님':'수량 확인 필요';for(const v of [basename(r.model),data.labels?.[r.feature]||r.feature,...(quantityKnown?[r.detected,r.excluded,r.actionable]:[quantityLabel,quantityLabel,quantityLabel]),r.carried,r.recheck]){const td=el('td',String(v));td.style.padding='8px';tr.append(td);}table.append(tr);}body.append(table);
  const footer=el('footer',null,'repeat-foot');footer.append(button('요약 엑셀 열기',()=>post('excel:open',{path:data.path})),button('닫기',()=>overlay.remove()));modal.append(head,body,footer);overlay.append(modal);document.body.append(overlay);
}
