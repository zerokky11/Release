import { clear, div, toast, setBusy, showExcelSavedDialog, chooseExcelMode, getLastExcelExportLocale, showCompletionSummaryDialog } from '../core/dom.js?v=20260731parameterexport1';
import { refreshUiAfterHostDialog } from '../core/hostDialog.js';
import { attachRvtDropZone } from '../core/rvtDrop.js';
import { attachExcelDropZone } from '../core/excelDrop.js';
import { ProgressDialog } from '../core/progress.js';
import { onHost, post } from '../core/bridge.js';
import { createRvtTable, renderRvtRows, getRvtName } from './rvtTable.js?v=20260504a';

const EXCEL_PHASE_WEIGHT = {
  EXCEL_INIT: 0.05,
  EXCEL_WRITE: 0.85,
  EXCEL_SAVE: 0.08,
  AUTOFIT: 0.02,
  DONE: 1,
  ERROR: 1
};

const DEFAULT_SCHEMA = [
  'Action',
  'HostFileName',
  'HostFilePath',
  'ReferenceElementId',
  'LinkName',
  'LinkFileName',
  'TypeWorksetNames',
  'InstanceWorksetNames',
  'ApplyTypeWorksetNames',
  'ApplyInstanceWorksetNames',
  'CurrentLinkPath',
  'StoredLinkPath',
  'CurrentPathType',
  'LinkedFileStatus',
  'TargetLinkPath',
  'TargetPathType',
  'ApplyStatus',
  'ApplyMessage'
];

const VISIBLE_COLUMNS = [
  ['Result', '결과'],
  ['Target', '대상'],
  ['Action', '작업'],
  ['Resolution', '원인 · 조치']
];
const LINKPATH_SETTINGS_KEY = 'kky.settings.linkpath.v1';
let activeLinkPathPreferenceCleanup = null;

export function renderLinkPath(root) {
  activeLinkPathPreferenceCleanup?.();
  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);

  const topbarEl = document.querySelector('#topbar-root .topbar') || document.querySelector('.topbar');
  if (topbarEl) topbarEl.classList.add('hub-topbar');

  const savedPreferences = loadLinkPathPreferences();
  const state = {
    rvtPaths: [],
    rvtChecked: new Set(),
    rows: [],
    schema: DEFAULT_SCHEMA.slice(),
    workbookPath: '',
    newLinkPlacement: normalizeLinkPlacement(savedPreferences?.newLinkPlacement),
    busy: false,
    lastAction: '',
    resultSource: '',
    actionStartedAt: 0
  };

  let lastExcelPct = 0;
  let progressHideTimer = null;

  const page = div('feature-shell familylink-page linkpath-page--main');
  const header = div('feature-header');
  const heading = div('feature-heading');
  heading.innerHTML = `
    <span class="feature-kicker">Revit 링크 경로</span>
    <h2 class="feature-title">Revit 링크 경로 추출 및 변경</h2>
    <p class="feature-sub">RVT에서 링크 현황을 추출하고, 엑셀 기준으로 경로 다시 로드 또는 신규 Revit 링크 생성을 일괄 반영합니다.</p>`;
  header.append(heading);
  page.append(header);

  const body = div('familylink-body');
  const topPanels = div('familylink-top-panels');

  const rvtSection = div('paramprop-card section familylink-card linkpath-card linkpath-card--rvt');
  const rvtHeader = div('familylink-results-head');
  const rvtTitle = div('paramprop-title');
  rvtTitle.textContent = '1단계 · RVT 등록 및 링크 추출';
  const rvtMeta = div('familylink-results-meta');
  rvtMeta.textContent = '파일 0개';
  rvtHeader.append(rvtTitle, rvtMeta);
  rvtSection.append(rvtHeader);

  const rvtActions = div('familylink-rvt-actions');
  const rvtManageActions = div('feature-actions');
  const rvtRunActions = div('feature-actions linkpath-run-actions');

  const btnAdd = cardBtn('RVT 파일 추가', () => post('linkpath:pick-rvts', {}), 'btn--primary');
  const btnRemove = cardBtn('선택 제거', () => {
    if (!state.rvtChecked.size) return;
    state.rvtPaths = state.rvtPaths.filter((path) => !state.rvtChecked.has(path));
    state.rvtChecked.clear();
    renderRvtList();
    syncButtons();
  }, 'btn--secondary');
  const btnClear = cardBtn('등록 목록 비우기', () => {
    state.rvtPaths = [];
    state.rvtChecked.clear();
    renderRvtList();
    syncButtons();
  }, 'btn--secondary');
  const btnExtract = cardBtn('링크 추출', onExtract, 'btn--primary');
  const btnExport = cardBtn('엑셀 내보내기', onExport, 'btn--secondary');

  rvtManageActions.append(btnAdd, btnRemove, btnClear);
  rvtRunActions.append(btnExtract, btnExport);
  rvtActions.append(rvtManageActions, rvtRunActions);
  rvtSection.append(rvtActions);

  const rvtHint = div('rvt-drop-hint');
  rvtHint.textContent = 'RVT 파일 추가 버튼을 누르거나 탐색기에서 여러 .rvt 파일을 바로 끌어 놓을 수 있습니다.';
  rvtSection.append(rvtHint);

  const rvtTableWrap = div('familylink-rvt-table linkpath-rvt-table rvt-drop-zone');
  const { table: rvtTable, tbody: rvtTbody, master: rvtMaster } = createRvtTable();
  rvtTableWrap.append(rvtTable);
  rvtSection.append(rvtTableWrap);

  attachRvtDropZone(rvtTableWrap, {
    onDropPaths: (paths) => {
      const added = appendRvts(paths);
      if (!added) {
        toast('이미 등록된 RVT입니다.', 'warn');
        return;
      }
      renderRvtList();
      syncButtons();
      toast(`${added}개 RVT를 추가했습니다.`, 'ok');
    },
    onInvalid: () => toast('RVT 파일만 드래그해 추가할 수 있습니다.', 'warn')
  });

  const applySection = div('paramprop-card section familylink-card linkpath-card linkpath-card--apply');
  const applyHeader = div('familylink-results-head');
  const applyTitle = div('paramprop-title');
  applyTitle.textContent = '2단계 · 링크 수정 / 신규 생성 반영';
  const applyMeta = div('familylink-results-meta');
  applyMeta.textContent = '엑셀 선택 필요';
  applyHeader.append(applyTitle, applyMeta);
  applySection.append(applyHeader);

  const applyActions = div('familylink-rvt-actions');
  const applyActionLeft = div('feature-actions');
  const applyActionRight = div('feature-actions linkpath-run-actions');

  const btnPickExcel = cardBtn('엑셀 선택', () => post('linkpath:pick-excel', {}), 'btn--secondary');
  const btnApply = cardBtn('엑셀 기준 적용', onApply, 'btn--primary');
  applyActionLeft.append(btnPickExcel);
  applyActionRight.append(btnApply);
  applyActions.append(applyActionLeft, applyActionRight);
  applySection.append(applyActions);

  const newLinkSettings = div('feature-row__summary linkpath-settings-card');

  const placementLabel = document.createElement('label');
  placementLabel.textContent = '신규 링크 배치 방식';

  const placementSelect = document.createElement('select');
  placementSelect.className = 'feature-input';
  [
    ['origin', '자동 - 원점 대 원점'],
    ['centered', '자동 - 중심 대 중심'],
    ['shared', '자동 - 공유 좌표 기준'],
    ['site', '자동 - 프로젝트 기준점']
  ].forEach(([value, label]) => {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    placementSelect.append(option);
  });
  placementSelect.value = state.newLinkPlacement;
  placementSelect.addEventListener('change', () => {
    state.newLinkPlacement = placementSelect.value || 'origin';
    saveLinkPathPreferences(state);
  });
  activeLinkPathPreferenceCleanup = attachLinkPathPreferenceSync(page, state, placementSelect);

  const placementHint = div('feature-note');
  placementHint.textContent = '최신 엑셀에서는 같은 호스트 행을 복사한 뒤 Action=신규 링크와 TargetLinkPath만 입력하세요. 숨김 ID와 LinkName은 지울 필요가 없습니다. Action 열이 없는 구형 엑셀에서만 ReferenceElementId와 LinkName을 모두 비워야 신규 링크로 처리됩니다.';
  newLinkSettings.append(placementLabel, placementSelect, placementHint);
  applySection.append(newLinkSettings);

  const excelDrop = div('feature-row__summary linkpath-excel-drop');

  const excelLead = document.createElement('strong');
  excelLead.textContent = '대상 파일 경로를 적은 엑셀을 선택하면 자동으로 불러옵니다.';
  const excelPath = div('feature-note');
  excelPath.textContent = '선택된 엑셀 파일이 없습니다.';
  excelDrop.append(excelLead, excelPath);
  applySection.append(excelDrop);

  attachExcelDropZone(excelDrop, {
    onDropPaths: (paths) => {
      const path = Array.isArray(paths) && paths.length ? paths[0] : '';
      if (!path) return;
      state.workbookPath = path;
      renderWorkbookState();
      onImport();
    },
    onInvalid: () => toast('엑셀 파일만 드래그해 추가할 수 있습니다.', 'warn')
  });

  const resultSection = div('familylink-results-panel linkpath-results-panel');
  const resultHead = div('familylink-results-head');
  const resultTitle = div('familylink-results-title');
  resultTitle.textContent = '링크 현황';
  const resultMeta = div('familylink-results-meta');
  resultMeta.textContent = '결과 0개';
  resultHead.append(resultTitle, resultMeta);
  resultSection.append(resultHead);

  const summaryNote = div('feature-note');
  summaryNote.textContent = '링크 추출 후 현재 경로와 대상 경로를 여기에서 확인할 수 있습니다.';
  resultSection.append(summaryNote);

  const resultWrap = div('familylink-results-body');
  const resultTable = document.createElement('table');
  resultTable.className = 'familylink-table';
  const resultThead = document.createElement('thead');
  const resultTbody = document.createElement('tbody');
  resultTable.append(resultThead, resultTbody);
  resultWrap.append(resultTable);
  resultSection.append(resultWrap);

  topPanels.append(rvtSection, applySection);
  body.append(topPanels, resultSection);
  page.append(body);
  target.append(page);

  renderRvtList();
  renderWorkbookState();
  renderResultTable();
  syncButtons();

  onHost('linkpath:rvts-picked', (payload) => {
    const paths = Array.isArray(payload?.paths) ? payload.paths : [];
    if (!paths.length) return;
    appendRvts(paths);
    refreshUiAfterHostDialog(() => {
      renderRvtList();
      syncButtons();
    });
  });

  onHost('linkpath:excel-picked', (payload) => {
    state.workbookPath = String(payload?.path || '').trim();
    refreshUiAfterHostDialog(() => {
      renderWorkbookState();
      syncButtons();
      onImport();
    });
  });

  onHost('linkpath:rows', (payload) => {
    clearProgressHideTimer();
    const source = String(payload?.source || '').toLowerCase();
    state.resultSource = source || state.resultSource || '';
    state.rows = Array.isArray(payload?.rows) ? payload.rows : [];
    state.schema = Array.isArray(payload?.schema) && payload.schema.length ? payload.schema : DEFAULT_SCHEMA.slice();
    state.workbookPath = String(payload?.workbookPath || state.workbookPath || '').trim();
    renderWorkbookState();
    renderResultTable(payload?.summary || null);
    const summary = payload?.summary || buildSummary(state.rows);
    // Apply completion is decided only by the terminal linkpath:applied event.
    // Rows arrive first so the result table can be rendered, but they are not
    // evidence that synchronization, document cleanup, and persistence checks
    // all succeeded.
    if (source !== 'apply') finishAction(source, summary, true);
  });

  onHost('linkpath:progress', (payload) => {
    handleProgress(payload || {});
  });

  onHost('linkpath:exported', (payload) => {
    clearProgressHideTimer();
    setBusyState(false);
    ProgressDialog.hide();
    lastExcelPct = 0;
    if (payload?.path) {
      state.workbookPath = payload.path;
      renderWorkbookState();
      requestAnimationFrame(() => {
        showExcelSavedDialog('링크 현황 엑셀을 저장했습니다.', payload.path, (path) => post('excel:open', { path }));
      });
    } else {
      toast(payload?.message || '링크 경로 결과 엑셀 저장에 실패했습니다. 저장 경로 권한과 파일이 열려 있는지 확인해 주세요. 계속 실패하면 메시지를 관리자에게 전달해 주세요.', 'err');
    }
    syncButtons();
  });

  onHost('linkpath:applied', (payload) => {
    const summary = payload?.summary || buildSummary(state.rows);
    finishAction(
      'apply',
      summary,
      payload?.ok === true,
      payload?.outcome,
      payload?.message,
      payload?.detail
    );
  });

  onHost('linkpath:error', (payload) => {
    clearProgressHideTimer();
    setBusyState(false);
    ProgressDialog.hide();
    lastExcelPct = 0;
    if (String(payload?.operation || '').trim().toLowerCase() === 'import') {
      state.rows = [];
      state.schema = DEFAULT_SCHEMA.slice();
      state.resultSource = 'import';
      state.workbookPath = String(payload?.path || state.workbookPath || '').trim();
      renderWorkbookState();
      renderResultTable();
    }
    syncButtons();
    const message = payload?.message || 'Revit 링크 경로 처리 중 오류가 발생했습니다. 링크 파일 목록과 경로 변경 규칙을 확인한 뒤 다시 실행해 주세요.';
    const detail = String(payload?.detail || '').trim();
    toast(detail ? `${message}: ${detail}` : message, 'err');
  });

  function appendRvts(paths) {
    const existing = new Set(state.rvtPaths.map((path) => String(path || '').toLowerCase()));
    let added = 0;
    (Array.isArray(paths) ? paths : []).forEach((path) => {
      if (!path) return;
      const key = String(path).toLowerCase();
      if (!existing.has(key)) {
        existing.add(key);
        state.rvtPaths.push(path);
        added += 1;
      }
      state.rvtChecked.add(path);
    });
    return added;
  }

  function renderRvtList() {
    rvtMeta.textContent = `파일 ${state.rvtPaths.length}개`;
    const rows = state.rvtPaths.map((path, idx) => ({
      index: idx + 1,
      name: getRvtName(path, `RVT ${idx + 1}`),
      path,
      checked: state.rvtChecked.has(path),
      onToggle: (checked) => {
        if (checked) state.rvtChecked.add(path);
        else state.rvtChecked.delete(path);
        syncMasterCheckbox();
        syncButtons();
      }
    }));
    renderRvtRows(rvtTbody, rows, '등록된 RVT가 없습니다.');
    rvtMaster.checked = rows.length > 0 && rows.every((row) => row.checked);
    rvtMaster.indeterminate = rows.some((row) => row.checked) && !rvtMaster.checked;
  }

  rvtMaster.addEventListener('change', () => {
    if (rvtMaster.checked) state.rvtPaths.forEach((path) => state.rvtChecked.add(path));
    else state.rvtChecked.clear();
    renderRvtList();
    syncButtons();
  });

  function syncMasterCheckbox() {
    const total = state.rvtPaths.length;
    const checked = Array.from(state.rvtChecked).filter((path) => state.rvtPaths.includes(path)).length;
    rvtMaster.checked = total > 0 && checked === total;
    rvtMaster.indeterminate = checked > 0 && checked < total;
  }

  function renderWorkbookState() {
    const path = state.workbookPath || '';
    applyMeta.textContent = path ? '엑셀 선택 완료' : '엑셀 선택 필요';
    excelPath.textContent = path || '선택된 엑셀 파일이 없습니다.';
    excelPath.setAttribute('aria-label', path || '선택된 엑셀 파일이 없습니다.');
  }

  function renderResultTable(summaryPayload = null) {
    const rows = Array.isArray(state.rows) ? state.rows : [];
    const source = String(state.resultSource || '').toLowerCase();
    const visibleRows = rows.filter((row) => shouldShowLinkPathResultRow(row, source));
    const hiddenCount = Math.max(0, rows.length - visibleRows.length);
    const summaryData = summaryPayload || buildSummary(rows);
    resultMeta.textContent = hiddenCount > 0
      ? `표시 ${visibleRows.length}개 / 전체 ${rows.length}개`
      : `결과 ${rows.length}개`;
    if (source === 'extract') {
      const localSummary = buildSummary(rows);
      const extractionErrors = Number(summaryData.extractionErrorRowCount ?? localSummary.extractionErrorRowCount ?? 0);
      const extractionWarnings = Number(summaryData.extractionWarningRowCount ?? localSummary.extractionWarningRowCount ?? 0);
      summaryNote.textContent =
        `호스트 ${summaryData.hostCount || 0}개 · 링크 ${summaryData.rowCount || rows.length}건 · 오류 ${extractionErrors}건 · 주의 ${extractionWarnings}건`;
    } else {
      const confirmed = Number(summaryData.confirmedActionCount ?? summaryData.changedCount ?? 0);
      const failed = Number(summaryData.failedActionCount ?? summaryData.errorCount ?? 0);
      const requested = Number(summaryData.requestedActionCount ?? summaryData.targetCount ?? 0)
        + (summaryData.requestedActionCount == null ? Number(summaryData.deleteCandidateCount || 0) : 0);
      summaryNote.textContent =
        `실행 대상 ${requested}건 · 적용 확인 ${confirmed}건 · 실패 ${failed}건${hiddenCount > 0 ? ` · 유지/단순 건너뜀 ${hiddenCount}건 숨김` : ''}`;
    }

    resultThead.innerHTML = '';
    const headRow = document.createElement('tr');
    VISIBLE_COLUMNS.forEach(([, label]) => {
      const th = document.createElement('th');
      th.textContent = label;
      headRow.append(th);
    });
    resultThead.append(headRow);

    resultTbody.innerHTML = '';
    if (!visibleRows.length) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = VISIBLE_COLUMNS.length;
      td.className = 'empty-cell';
      td.textContent = rows.length
        ? '표시할 실행·오류·주의 결과가 없습니다. 유지 행은 숨겼습니다.'
        : '추출된 링크가 없습니다.';
      tr.append(td);
      resultTbody.append(tr);
      return;
    }

    visibleRows.forEach((row) => {
      const view = buildLinkPathResultView(row, source);
      const tr = document.createElement('tr');
      tr.className = `linkpath-result-row linkpath-result-row--${view.resultState}`;
      tr.append(
        createLinkPathResultStateCell(view),
        createLinkPathTargetCell(row),
        createLinkPathActionCell(view),
        createLinkPathResolutionCell(row, view)
      );
      resultTbody.append(tr);
    });
  }

  function shouldShowLinkPathResultRow(row, source) {
    if (String(source || '').toLowerCase() === 'extract') return true;
    const view = buildLinkPathResultView(row, source);
    if (isActionableLinkPathAction(view.action)) return true;
    const status = String(row?.ApplyStatus || '').trim().toLowerCase();
    return status === 'error'
      || status === 'warning'
      || status === 'changed'
      || view.resultState === 'failure'
      || view.resultState === 'warning';
  }

  function createLinkPathResultStateCell(view) {
    const td = document.createElement('td');
    td.className = 'linkpath-result-cell linkpath-result-cell--state';
    const badge = document.createElement('span');
    badge.className = `linkpath-result-badge linkpath-result-badge--${view.resultState}`;
    badge.textContent = view.resultLabel || '확인';
    td.append(badge);
    if (view.applyConfirmation) {
      const confirmation = document.createElement('span');
      confirmation.className = 'linkpath-result-confirmation';
      confirmation.textContent = view.applyConfirmation;
      td.append(confirmation);
    }
    return td;
  }

  function createLinkPathTargetCell(row) {
    const td = document.createElement('td');
    td.className = 'linkpath-result-cell linkpath-result-cell--target';
    const targetName = resolveLinkPathTargetName(row);
    const hostName = String(row?.HostFileName || fileNameFromPath(row?.HostFilePath) || '호스트 미지정').trim();
    const primary = document.createElement('strong');
    primary.className = 'linkpath-result-target-name';
    primary.textContent = targetName;
    const secondary = document.createElement('span');
    secondary.className = 'linkpath-result-target-host';
    secondary.textContent = hostName;
    td.append(primary, secondary);
    const targetPath = String(row?.TargetLinkPath || row?.CurrentLinkPath || row?.StoredLinkPath || '').trim();
    td.title = [hostName, targetName, targetPath].filter(Boolean).join('\n');
    return td;
  }

  function createLinkPathActionCell(view) {
    const td = document.createElement('td');
    td.className = 'linkpath-result-cell linkpath-result-cell--action';
    const label = document.createElement('span');
    label.className = `linkpath-action-badge linkpath-action-badge--${view.action}`;
    label.textContent = view.actionLabel || '확인';
    td.append(label);
    return td;
  }

  function createLinkPathResolutionCell(row, view) {
    const td = document.createElement('td');
    td.className = 'linkpath-result-cell linkpath-result-cell--resolution';

    const reason = document.createElement('strong');
    reason.className = 'linkpath-result-reason';
    reason.textContent = view.failureReason || defaultLinkPathResultReason(view);
    td.append(reason);

    if (view.suggestedAction) {
      const action = document.createElement('span');
      action.className = 'linkpath-result-suggestion';
      action.textContent = view.suggestedAction;
      td.append(action);
    }

    const technicalItems = buildLinkPathTechnicalItems(row, view);
    if (technicalItems.length) {
      const details = document.createElement('details');
      details.className = 'linkpath-technical-details';
      const summary = document.createElement('summary');
      summary.textContent = '기술 상세';
      const body = document.createElement('div');
      body.className = 'linkpath-technical-details__body';
      technicalItems.forEach(([label, value]) => {
        const item = document.createElement('div');
        item.className = 'linkpath-technical-item';
        const key = document.createElement('span');
        key.className = 'linkpath-technical-item__label';
        key.textContent = label;
        const text = document.createElement('span');
        text.className = 'linkpath-technical-item__value';
        text.textContent = value;
        item.append(key, text);
        body.append(item);
      });
      details.append(summary, body);
      td.append(details);
    }

    return td;
  }

  function buildLinkPathTechnicalItems(row, view) {
    const items = [];
    const add = (label, value) => {
      const text = String(value == null ? '' : value).trim();
      if (text) items.push([label, text]);
    };
    add('코드', view.failureCode);
    add('원문', view.technicalDetail || row?.ApplyMessage);
    add('링크 상태', row?.LinkedFileStatus);
    add('현재 경로', row?.CurrentLinkPath);
    add('저장 경로', row?.StoredLinkPath);
    add('대상 경로', row?.TargetLinkPath);
    add('경로 방식', row?.TargetPathType || row?.CurrentPathType);
    add('타입 웍셋', row?.ApplyTypeWorksetNames || row?.TypeWorksetNames);
    add('인스턴스 웍셋', row?.ApplyInstanceWorksetNames || row?.InstanceWorksetNames);
    return items;
  }

  function buildLinkPathResultView(row, source) {
    const sourceText = String(source || '').trim().toLowerCase();
    const action = normalizeLinkPathAction(row?.Action || row?.RequestedAction, row, sourceText);
    const technicalDetail = String(row?.TechnicalDetail || row?.ApplyMessage || '').trim();
    let resultState = String(row?.ResultState || '').trim().toLowerCase();
    if (!['success', 'failure', 'warning', 'skipped', 'info', 'ready', 'pending'].includes(resultState)) {
      resultState = deriveLinkPathResultState(row, sourceText);
    }

    let resultLabel = String(row?.ResultLabel || '').trim() || linkPathResultLabel(resultState, sourceText);
    let failureCode = String(row?.FailureCode || '').trim();
    let failureReason = String(row?.FailureReason || '').trim();
    let suggestedAction = String(row?.SuggestedAction || '').trim();

    const fallback = classifyLinkPathFailureFallback(row, resultState, technicalDetail, sourceText);
    if (fallback.resultState === 'warning' && resultState === 'success') {
      resultState = 'warning';
      resultLabel = '주의';
    }
    failureCode ||= fallback.failureCode;
    failureReason ||= fallback.failureReason;
    suggestedAction ||= fallback.suggestedAction;

    let applyConfirmation = String(row?.ApplyConfirmation || '').trim();
    if (resultState === 'warning' && messageHas(technicalDetail, '프로젝트 기준점으로 다시 배치', '프로젝트 기준점으로 배치')) {
      applyConfirmation = '대체 배치 확인';
    }

    return {
      source: sourceText,
      action,
      actionLabel: String(row?.ActionLabel || '').trim() || linkPathActionLabel(action),
      resultState,
      resultLabel,
      failureCode,
      failureReason,
      suggestedAction,
      applyConfirmation,
      technicalDetail
    };
  }

  function deriveLinkPathResultState(row, source) {
    const status = String(row?.ApplyStatus || '').trim().toLowerCase();
    const linkStatus = String(row?.LinkedFileStatus || '').trim().toLowerCase().replace(/\s+/g, '');
    if (source === 'extract') {
      if (status === 'error' || ['notfound', 'invalid', 'error'].includes(linkStatus)) return 'failure';
      if (status === 'warning' || ['unloaded', 'locallyunloaded', 'inclosedworkset', 'canbeupgraded', 'imported', 'unknown'].includes(linkStatus)) return 'warning';
      if (status === 'info') return 'info';
      return 'success';
    }
    if (source === 'import') {
      if (status === 'error' || ['notfound', 'invalid', 'error'].includes(linkStatus)) return 'failure';
      if (status === 'warning' || ['unloaded', 'locallyunloaded', 'inclosedworkset', 'canbeupgraded', 'imported', 'unknown'].includes(linkStatus)) return 'warning';
      return isActionableLinkPathAction(normalizeLinkPathAction(row?.Action || row?.RequestedAction, row, source)) ? 'ready' : 'skipped';
    }
    if (status === 'changed') return 'success';
    if (status === 'error') return 'failure';
    if (status === 'warning') return 'warning';
    if (status === 'skip' || status === 'info') return 'skipped';
    return 'pending';
  }

  function normalizeLinkPathAction(value, row, source) {
    if (String(source || '').toLowerCase() === 'extract') return 'extract';
    const compact = String(value || '').trim().toLowerCase().replace(/[\s_-]+/g, '');
    if (['keep', 'skip', 'nochange', '유지', '변경없음', '건너뜀'].includes(compact)) return 'keep';
    if (['reload', 'reloadfrom', '리로드', '리로드프롬', '재로드', '경로변경'].includes(compact)) return 'reloadfrom';
    if (['new', 'newlink', 'create', '신규', '신규링크', '새링크'].includes(compact)) return 'newlink';
    if (['delete', 'remove', '삭제', '링크삭제'].includes(compact)) return 'delete';
    if (compact === 'extract') return 'extract';
    if (String(source || '').toLowerCase() === 'import') return 'keep';

    const target = String(row?.TargetLinkPath || '').trim();
    const referenceId = String(row?.ReferenceElementId || '').trim();
    const linkName = String(row?.LinkName || '').trim();
    if (target) return !referenceId && !linkName ? 'newlink' : 'reloadfrom';
    if (referenceId && !linkName.startsWith('외부 참조 #')) return 'delete';
    return 'keep';
  }

  function isActionableLinkPathAction(action) {
    return ['reloadfrom', 'newlink', 'delete'].includes(String(action || '').toLowerCase());
  }

  function linkPathActionLabel(action) {
    switch (String(action || '').toLowerCase()) {
      case 'extract': return '현황 추출';
      case 'reloadfrom': return 'Reload From';
      case 'newlink': return '신규 링크';
      case 'delete': return '링크 삭제';
      case 'keep': return '유지';
      default: return '확인';
    }
  }

  function linkPathResultLabel(resultState, source) {
    switch (String(resultState || '').toLowerCase()) {
      case 'success': return source === 'extract' ? '정상' : '성공';
      case 'failure': return source === 'extract' ? '오류' : '실패';
      case 'warning': return '주의';
      case 'skipped': return source === 'import' ? '유지' : '건너뜀';
      case 'info': return '정보';
      case 'ready': return '적용 대기';
      default: return '확인 필요';
    }
  }

  function classifyLinkPathFailureFallback(row, resultState, technicalDetail, source = '') {
    const none = { failureCode: '', failureReason: '', suggestedAction: '', resultState };
    const detail = String(technicalDetail || '');
    const linkedStatus = String(row?.LinkedFileStatus || '').trim().toLowerCase().replace(/\s+/g, '');
    const sourceText = String(source || '').trim().toLowerCase();
    const make = (failureCode, failureReason, suggestedAction, nextState = resultState) => ({
      failureCode,
      failureReason,
      suggestedAction,
      resultState: nextState
    });

    if (messageHas(detail, '프로젝트 기준점으로 다시 배치', '프로젝트 기준점으로 배치')) {
      return messageHas(detail, '(Shared)')
        ? make(
            'SHARED_COORDINATES_FALLBACK',
            '요청한 공유좌표 배치 대신 프로젝트 기준점으로 배치됨',
            '호스트와 링크의 공유좌표를 확인하고 필요하면 공유좌표 설정 후 다시 배치하세요.',
            'warning'
          )
        : make(
            'PLACEMENT_FALLBACK',
            '요청한 배치 방식 대신 프로젝트 기준점으로 다시 배치됨',
            '링크 배치 결과를 검토하고 필요하면 신규 링크 배치 방식을 조정해 다시 실행하세요.',
            'warning'
          );
    }
    if (['extract', 'import'].includes(sourceText) && linkedStatus === 'inclosedworkset') {
      return make(
        'IN_CLOSED_WORKSET',
        '링크가 닫힌 호스트 웍셋 안에 있어 로드되지 않음',
        '해당 링크가 배치된 호스트 웍셋을 열어 링크 상태를 확인하세요.'
      );
    }
    if (
      sourceText === 'extract'
      && ['info', 'skipped'].includes(resultState)
      && messageHas(detail, 'Revit 링크가 없습니다', 'Revit 링크 없음')
    ) {
      return make('NO_REVIT_LINKS', '호스트에 추출할 Revit 링크가 없음', '조치할 내용이 없습니다.');
    }
    if (resultState === 'success' || resultState === 'ready') return none;
    if (messageHas(detail, 'cleanup', '문서 정리', '백그라운드', '잔류 문서', '문서를 닫지 못', '자동 종료하지 않았')) {
      return make('CLEANUP_FAILED', '문서 정리 또는 백그라운드 문서 종료 실패', '열린 문서와 저장되지 않은 변경을 확인해 모두 닫은 뒤 다시 실행하세요.');
    }
    if (messageHas(detail, '저장 결과 재확인', '저장 결과 확인', '저장 결과를 다시', '저장 파일', 'persisted', 'transmitted 상태')) {
      return make('PERSISTENCE_VERIFY_FAILED', '저장된 링크 결과를 다시 확인하지 못함', '호스트를 직접 열어 저장된 링크 경로를 확인하고 해당 호스트만 다시 실행하세요.');
    }
    if (messageHas(detail, '센트럴 잠금', '중앙 모델이 잠', '중앙 파일이 잠', 'central lock', 'central locked', 'central model is locked', 'central file is locked', 'central is locked')) {
      return make('CENTRAL_LOCKED', '센트럴 모델이 잠겨 작업을 진행할 수 없음', '다른 사용자의 센트럴 작업이 끝난 뒤 연결 상태를 확인하고 다시 실행하세요.');
    }
    if (messageHas(detail, 'checkout', '체크아웃', '대여하지 못', '소유자=', '권한', 'access denied', 'read-only', 'readonly')) {
      return make('PERMISSION_OR_CHECKOUT', '권한·소유권 또는 링크 요소 checkout 실패', '표시된 소유자가 요소를 반환하고 센트럴 쓰기 권한을 확보한 뒤 다시 실행하세요.');
    }
    if (messageHas(detail, '동기화 실패', '동기화에 실패', '저장 실패', '저장·동기화', '저장 상태로 확정')) {
      return make('SAVE_SYNC_FAILED', '저장 또는 센트럴 동기화 실패', '센트럴 연결, 쓰기 권한, 소유권을 확인한 뒤 해당 호스트를 다시 실행하세요.');
    }
    if (messageHas(detail, 'Action=유지 행에 변경 입력값')) {
      return make('ACTION_REQUIRED_FOR_CHANGES', '변경값이 입력됐지만 Action이 유지로 되어 있음', '경로 또는 웍셋을 바꾸려면 Action=Reload From을 선택하세요.');
    }
    if ((['extract', 'import'].includes(sourceText) && linkedStatus === 'inclosedworkset') || messageHas(detail, '웍셋', 'workset')) {
      return make('WORKSET', '지정 웍셋을 찾지 못했거나 적용할 수 없음', '엑셀의 타입·인스턴스 웍셋 이름과 실제 호스트 웍셋을 맞춘 뒤 다시 실행하세요.');
    }
    if (messageHas(detail, '공유 좌표', '공유좌표', '공유포인트', 'shared coordinate', 'shared coordinates', 'shared point', 'shared site')) {
      return make('SHARED_COORDINATES', '공유좌표 기준으로 링크를 배치할 수 없음', '공유좌표를 먼저 설정하거나 신규 링크 배치를 원점/프로젝트 기준점으로 바꾸세요.');
    }
    if (messageHas(detail, '이미 열려', '열려 있는 문서', '열린 문서에서 사용 중', '다른 열린 문서', 'already open', 'is open', 'in use')) {
      return make('FILE_ALREADY_OPEN', '대상 링크 파일이 다른 문서에서 열려 있거나 사용 중', '해당 대상 문서와 잔류 백그라운드 문서를 닫은 뒤 다시 실행하세요.');
    }
    if (messageHas(detail, 'Action은 유지', 'Action 열', '입력값=')) {
      return make('INVALID_ACTION', 'Excel Action 값이 올바르지 않음', 'Action 열에서 유지, Reload From, 신규 링크, 삭제 중 하나를 선택하세요.');
    }
    if (messageHas(detail, '기존 링크 식별자가 없어', '추출된 기존 링크 행에서만', '링크 식별자가 없어')) {
      return make('LINK_IDENTITY_MISSING', '기존 링크를 식별할 ReferenceElementId가 없음', '다시 추출한 기존 링크 행에서 Reload From 또는 삭제를 지정하세요.');
    }
    if (messageHas(detail, '엑셀의 원본 링크 경로와 현재 RVT의 링크 경로가 달라', '최신 상태로 다시 추출')) {
      return make('STALE_EXTRACTION', '링크 추출 후 호스트의 링크 경로가 변경됨', '해당 호스트의 링크를 최신 상태로 다시 추출한 뒤 Action과 대상 경로를 다시 입력하세요.');
    }
    if (messageHas(detail, '기존 링크를 현재 호스트에서 찾지 못', '삭제할 링크를 찾지 못', '링크 식별자를 해석하지 못')) {
      return make('LINK_REFERENCE_NOT_FOUND', 'Excel 행의 링크 식별자가 현재 호스트와 맞지 않음', '해당 호스트를 다시 추출하고 새로 생성된 행에서 작업을 지정하세요.');
    }
    if ((['extract', 'import'].includes(sourceText) && linkedStatus === 'canbeupgraded') || messageHas(detail, '버전', 'version', 'upgrade', 'upgraded')) {
      return make('VERSION_MISMATCH', '대상 RVT 버전이 호스트와 호환되지 않음', '현재 Revit에서 열 수 있는 버전의 대상 RVT를 지정하세요.');
    }
    if (messageHas(detail, '호스트 RVT 경로', 'HostFilePath', '호스트 RVT 파일을 찾을 수')) {
      return make('HOST_PATH_MISSING', '적용할 호스트 RVT 경로를 찾지 못함', 'RVT 등록 목록과 Excel HostFilePath가 같은 호스트를 가리키는지 확인하세요.');
    }
    if ((['extract', 'import'].includes(sourceText) && (linkedStatus === 'notfound' || linkedStatus === 'invalid')) || messageHas(detail, '파일을 찾을 수', '경로를 찾지 못', '경로가 비어', '경로 형식', 'targetpathtype', '상대 대상 경로', '확인 경로:', 'path not found', 'file not found')) {
      return make('PATH_NOT_FOUND_OR_INVALID', '대상 파일 또는 링크 경로를 찾지 못함', 'TargetLinkPath와 Relative/Absolute/Server 방식, 파일 접근 가능 여부를 확인하세요.');
    }
    if (['extract', 'import'].includes(sourceText) && ['unloaded', 'locallyunloaded', 'unknown'].includes(linkedStatus)) {
      return make('LINK_FILE_STATUS', '링크 파일의 로드 상태를 확인할 수 없거나 언로드 상태임', 'Revit 링크 관리에서 파일 존재 여부와 로드 상태를 확인하세요.');
    }
    if ((['extract', 'import'].includes(sourceText) && linkedStatus === 'imported') || messageHas(detail, '중첩 링크', '클라우드', '자동 변경 대상에서 제외', '지원하지')) {
      return make('UNSUPPORTED_LINK', '자동 처리하지 않는 링크 유형 또는 상태', 'Revit에서 수동으로 확인하거나 지원되는 파일 링크로 변경하세요.');
    }
    if (resultState === 'skipped' || resultState === 'info') {
      return make('SKIPPED', '자동 실행 대상에서 제외됨', '기술 상세와 Action, 링크 식별자, 대상 경로를 확인하세요.');
    }
    if (resultState === 'failure' || resultState === 'warning') {
      return make('ROW_APPLY_FAILED', 'Revit 링크 작업 중 오류가 발생함', '기술 상세의 원문과 대상 경로, 링크 방식, 웍셋 상태를 확인한 뒤 다시 실행하세요.');
    }
    return none;
  }

  function messageHas(text, ...needles) {
    const source = String(text || '').toLowerCase();
    return needles.some((needle) => source.includes(String(needle || '').toLowerCase()));
  }

  function defaultLinkPathResultReason(view) {
    if (view.resultState === 'success') {
      return view.source === 'extract' ? '특이사항 없음' : '요청한 링크 작업의 적용 결과를 확인했습니다.';
    }
    if (view.resultState === 'ready') return '엑셀에 지정한 작업을 적용할 준비가 되었습니다.';
    if (view.resultState === 'pending') return '결과 상태를 확인해야 합니다.';
    if (view.resultState === 'skipped' || view.resultState === 'info') return '자동 실행 대상에서 제외되었습니다.';
    if (view.resultState === 'warning') return '확인이 필요한 결과입니다.';
    return '작업을 완료하지 못했습니다.';
  }

  function resolveLinkPathTargetName(row) {
    return String(
      row?.LinkName
      || row?.LinkFileName
      || fileNameFromPath(row?.TargetLinkPath)
      || fileNameFromPath(row?.CurrentLinkPath)
      || '링크 미지정'
    ).trim();
  }

  function fileNameFromPath(value) {
    const normalized = String(value || '').trim().replace(/\\/g, '/').replace(/\/+$/, '');
    if (!normalized) return '';
    return normalized.split('/').pop() || normalized;
  }

  function buildSummary(rows) {
    const safeRows = Array.isArray(rows) ? rows : [];
    const hostSet = new Set();
    let requestedActionCount = 0;
    let reloadFromCount = 0;
    let newLinkCount = 0;
    let deleteRequestedCount = 0;
    let confirmedActionCount = 0;
    let failedActionCount = 0;
    let targetCount = 0;
    let deleteCandidateCount = 0;
    let deletedCount = 0;
    let changedCount = 0;
    let errorCount = 0;
    let extractionWarningCount = 0;
    let skipCount = 0;
    let linkStatusErrorCount = 0;
    let linkStatusWarningCount = 0;
    let extractionErrorRowCount = 0;
    let extractionWarningRowCount = 0;

    safeRows.forEach((row) => {
      const host = String(row?.HostFilePath || row?.HostFileName || '').trim();
      if (host) hostSet.add(host.toLowerCase());
      const action = normalizeLinkPathAction(row?.Action || row?.RequestedAction, row, state.resultSource);
      const actionable = isActionableLinkPathAction(action);
      if (actionable) requestedActionCount += 1;
      if (action === 'reloadfrom') {
        reloadFromCount += 1;
        targetCount += 1;
      } else if (action === 'newlink') {
        newLinkCount += 1;
        targetCount += 1;
      } else if (action === 'delete') {
        deleteRequestedCount += 1;
        deleteCandidateCount += 1;
      }
      const status = String(row?.ApplyStatus || '').trim().toLowerCase();
      if (status === 'changed') {
        changedCount += 1;
        if (actionable) confirmedActionCount += 1;
        if (action === 'delete') deletedCount += 1;
      } else if (status === 'error') {
        errorCount += 1;
        if (actionable) failedActionCount += 1;
      }
      else if (status === 'warning') extractionWarningCount += 1;
      else if (status === 'skip' || status === 'info') skipCount += 1;

      const linkStatus = String(row?.LinkedFileStatus || '').trim().toLowerCase().replace(/\s+/g, '');
      const isLinkStatusError = linkStatus === 'notfound' || linkStatus === 'invalid' || linkStatus === 'error';
      const isLinkStatusWarning = linkStatus === 'unloaded' || linkStatus === 'locallyunloaded' || linkStatus === 'inclosedworkset' || linkStatus === 'canbeupgraded' || linkStatus === 'imported' || linkStatus === 'unknown';
      if (isLinkStatusError) linkStatusErrorCount += 1;
      else if (isLinkStatusWarning) linkStatusWarningCount += 1;
      if (status === 'error' || isLinkStatusError) extractionErrorRowCount += 1;
      else if (status === 'warning' || isLinkStatusWarning) extractionWarningRowCount += 1;
    });

    const fullySuccessfulHostSet = new Set();
    const partialHostSet = new Set();
    const failedHostSet = new Set();
    hostSet.forEach((host) => {
      const hostRows = safeRows.filter((row) => {
        const rowHost = String(row?.HostFilePath || row?.HostFileName || '').trim().toLowerCase();
        return rowHost === host;
      });
      const hasChanged = hostRows.some((row) => String(row?.ApplyStatus || '').trim().toLowerCase() === 'changed');
      const hasError = hostRows.some((row) => String(row?.ApplyStatus || '').trim().toLowerCase() === 'error');
      if (hasChanged && hasError) partialHostSet.add(host);
      else if (hasChanged) fullySuccessfulHostSet.add(host);
      else if (hasError) failedHostSet.add(host);
    });

    return {
      hostCount: hostSet.size,
      successfulHostCount: fullySuccessfulHostSet.size,
      fullySuccessfulHostCount: fullySuccessfulHostSet.size,
      partialHostCount: partialHostSet.size,
      failedHostCount: failedHostSet.size,
      rowCount: safeRows.length,
      requestedActionCount,
      reloadFromCount,
      newLinkCount,
      deleteRequestedCount,
      confirmedActionCount,
      failedActionCount,
      targetCount,
      deleteCandidateCount,
      deletedCount,
      changedCount,
      errorCount,
      extractionWarningCount,
      skipCount,
      extractionErrorRowCount,
      extractionWarningRowCount,
      linkStatusErrorCount,
      linkStatusWarningCount
    };
  }

  function onExtract() {
    if (!state.rvtPaths.length) {
      toast('RVT를 먼저 추가해 주세요.', 'warn');
      return;
    }
    state.lastAction = 'extract';
    state.actionStartedAt = Date.now();
    setBusyState(true);
    lastExcelPct = 0;
    ProgressDialog.show('링크 추출', '링크 정보를 읽는 중입니다.');
    ProgressDialog.update(5, '링크 추출', '등록된 RVT에서 Revit 링크를 확인하고 있습니다.');
    post('linkpath:extract', { rvtPaths: state.rvtPaths });
  }

  function onExport() {
    if (!state.rows.length) {
      toast('먼저 링크를 추출해 주세요.', 'warn');
      return;
    }
    state.lastAction = 'export';
    state.actionStartedAt = Date.now();
    chooseExcelMode((mode) => {
      lastExcelPct = 0;
      setBusyState(true);
      post('linkpath:export', { excelMode: mode || 'fast', locale: getLastExcelExportLocale() });
    });
  }

  function onImport() {
    if (!state.workbookPath) {
      toast('엑셀 파일을 먼저 선택해 주세요.', 'warn');
      return;
    }
    state.lastAction = 'import';
    state.actionStartedAt = Date.now();
    setBusyState(true);
    ProgressDialog.show('엑셀 불러오기', 'Action과 대상 링크 정보를 읽는 중입니다.');
    ProgressDialog.update(20, '엑셀 불러오기', state.workbookPath);
    post('linkpath:import', { path: state.workbookPath });
  }

  function onApply() {
    const summary = buildSummary(state.rows);
    const requestedCount = Number(summary.requestedActionCount || 0);
    if (requestedCount <= 0) {
      toast('실행할 Action이 없습니다. Excel Action 열에서 Reload From·신규 링크·삭제를 선택해 주세요.', 'warn');
      return;
    }

    const confirmLines = [
      `실행 Action ${requestedCount}건: Reload From ${Number(summary.reloadFromCount || 0)}건 · 신규 링크 ${Number(summary.newLinkCount || 0)}건 · 삭제 ${Number(summary.deleteRequestedCount || 0)}건`,
      '같은 호스트의 링크 행은 호스트별로 처리하며, 저장할 변경이 있으면 호스트당 최종 1회 저장·동기화합니다.',
      '계속 적용할까요?'
    ];
    const confirmed = window.confirm(confirmLines.join('\n'));
    if (!confirmed) return;

    state.lastAction = 'apply';
    state.actionStartedAt = Date.now();
    setBusyState(true);
    lastExcelPct = 0;
    ProgressDialog.show('엑셀 기준 적용', '호스트별로 링크 경로 변경/신규 생성/삭제를 적용하는 중입니다.');
    ProgressDialog.update(5, '엑셀 기준 적용', '각 호스트의 링크 행을 모두 처리하고, 저장할 변경이 있으면 호스트당 최종 1회 저장·동기화합니다.');
    post('linkpath:apply', { newLinkPlacement: state.newLinkPlacement, rvtPaths: state.rvtPaths });
  }

  function finishAction(
    source,
    summary,
    completionOk = true,
    completionOutcome = '',
    completionMessage = '',
    completionDetail = ''
  ) {
    const action = source || state.lastAction || '';
    const outcome = normalizeApplyCompletionOutcome(completionOutcome, completionOk);
    const isPartial = action === 'apply' && outcome === 'partial';
    const changedCount = Number(summary?.changedCount || 0);
    const errorCount = Number(summary?.errorCount || 0);
    const requestedActionCount = Number(summary?.requestedActionCount || 0);
    const confirmedActionCount = Number(summary?.confirmedActionCount ?? changedCount);
    const failedActionCount = Math.max(Number(summary?.failedActionCount || 0), errorCount);
    const isNoOp = action === 'apply'
      && outcome === 'success'
      && requestedActionCount === 0
      && changedCount === 0
      && errorCount === 0;
    const isAllRequestedSkipped = action === 'apply'
      && outcome === 'success'
      && requestedActionCount > 0
      && confirmedActionCount === 0
      && failedActionCount === 0;
    const elapsed = Date.now() - Number(state.actionStartedAt || 0);
    const minVisibleMs = action === 'extract' || action === 'apply' ? 500 : 250;
    const waitMs = Math.max(0, minVisibleMs - elapsed);

    scheduleProgressHide(waitMs, () => {
      setBusyState(false);
      if (action === 'import') {
        toast('엑셀을 불러왔습니다.', 'ok');
        return;
      }
      if (action === 'apply') {
        if (isPartial) {
          toast(
            changedCount > 0
              ? '일부 링크는 저장되었지만 실패한 행도 있습니다. 변경·오류 건수를 확인해 주세요.'
              : '작업 단위는 끝까지 확인했지만 적용에 성공한 링크가 없습니다. 오류 행을 확인해 주세요.',
            'warn'
          );
        } else if (isAllRequestedSkipped) {
          toast('실행 Action은 있었지만 모두 적용 대상에서 제외되었습니다. 행별 원인을 확인해 주세요.', 'warn');
        } else if (isNoOp) {
          toast('적용할 링크 변경 대상이 없습니다.', 'warn');
        } else {
          toast(
            completionOk
              ? '엑셀 기준 링크 경로 적용이 끝났습니다.'
              : '링크 경로 적용이 중단되었습니다. 오류 행과 메시지를 확인해 주세요.',
            completionOk ? 'ok' : 'err'
          );
        }
      }
      if (action === 'extract' || action === 'apply') {
        requestAnimationFrame(() => showLinkPathCompletionDialog(
          action,
          summary,
          completionOk,
          outcome,
          completionMessage,
          completionDetail
        ));
      }
    });
  }

  function normalizeApplyCompletionOutcome(value, completionOk) {
    const normalized = String(value || '').trim().toLowerCase();
    if (normalized === 'success' || normalized === 'partial' || normalized === 'aborted') return normalized;
    return completionOk === true ? 'success' : 'aborted';
  }

  function showLinkPathCompletionDialog(
    action,
    summary,
    completionOk = true,
    completionOutcome = '',
    completionMessage = '',
    completionDetail = ''
  ) {
    const safeSummary = summary || buildSummary(state.rows);
    const isExtract = action === 'extract';
    const outcome = normalizeApplyCompletionOutcome(completionOutcome, completionOk);
    const isPartial = !isExtract && outcome === 'partial';
    const applySucceeded = !isExtract && outcome === 'success';
    const hasPersistedChanges = Number(safeSummary.changedCount || 0) > 0;
    const requestedActionCount = Number(safeSummary.requestedActionCount || 0);
    const confirmedActionCount = Number(safeSummary.confirmedActionCount ?? safeSummary.changedCount ?? 0);
    const failedActionCount = Math.max(
      Number(safeSummary.failedActionCount || 0),
      Number(safeSummary.errorCount || 0)
    );
    const isNoOp = applySucceeded
      && requestedActionCount === 0
      && !hasPersistedChanges
      && Number(safeSummary.errorCount || 0) === 0;
    const isAllRequestedSkipped = applySucceeded
      && requestedActionCount > 0
      && confirmedActionCount === 0
      && failedActionCount === 0;
    const title = isExtract
      ? '링크 추출 완료'
      : (isPartial
          ? (hasPersistedChanges ? '링크 반영 부분 성공' : '링크 반영 실패')
          : (isAllRequestedSkipped
              ? '요청 작업 건너뜀'
              : (isNoOp ? '적용할 변경 없음' : (applySucceeded ? '링크 반영 완료' : '링크 반영 중단'))));
    const message = isExtract
      ? '추출한 링크 현황은 아래 결과 표와 엑셀에서 확인할 수 있습니다.'
      : (isPartial
          ? (hasPersistedChanges
              ? '성공분은 저장·동기화했고, 실패 행을 남긴 채 다음 호스트까지 계속 처리했습니다.'
              : '전체 호스트를 확인했지만 저장·동기화까지 확인된 링크가 없습니다.')
          : (isAllRequestedSkipped
              ? '실행 Action은 있었지만 모든 행이 적용 대상에서 제외되어 호스트를 저장하지 않았습니다. 결과 표의 행별 원인을 확인하세요.'
              : (isNoOp
                  ? '실행할 Action이 없어 호스트를 변경하지 않았습니다.'
                  : (applySucceeded
                      ? '호스트별 링크 작업과 최종 저장·동기화 확인을 마쳤습니다.'
                      : '치명 오류 또는 문서 정리 실패로 배치를 중단했습니다.'))));
    const notes = [];

    if (isExtract) {
      notes.push('오류·주의 행은 원인과 조치를 먼저 확인하고, 필요할 때만 기술 상세를 펼쳐 보세요.');
    } else {
      notes.push(`실행 ${requestedActionCount}건 · 적용 확인 ${confirmedActionCount}건 · 실패 ${failedActionCount}건. 결과 표에는 실행 대상과 오류·주의 행만 표시합니다.`);
      const terminalText = [completionMessage, completionDetail].map((value) => String(value || '').trim()).filter(Boolean).join(': ');
      if (terminalText) notes.push(`중단 원인: ${terminalText}`);
    }

    const summaryItems = isExtract
      ? [
          { label: '호스트 파일', value: `${safeSummary.hostCount || 0}개` },
          { label: '링크 수', value: `${safeSummary.rowCount || 0}건` },
          { label: '오류', value: `${safeSummary.extractionErrorRowCount ?? buildSummary(state.rows).extractionErrorRowCount ?? 0}건` },
          { label: '주의', value: `${safeSummary.extractionWarningRowCount ?? buildSummary(state.rows).extractionWarningRowCount ?? 0}건` }
        ]
      : [
          { label: '호스트 완전 성공', value: `${safeSummary.fullySuccessfulHostCount ?? safeSummary.successfulHostCount ?? 0}개` },
          { label: '호스트 부분 성공', value: `${safeSummary.partialHostCount || 0}개` },
          { label: '호스트 전체 실패', value: `${safeSummary.failedHostCount || 0}개` },
          { label: '적용 확인', value: `${confirmedActionCount}건` }
        ];

    showCompletionSummaryDialog({
      title,
      message,
      summaryItems,
      notes,
      confirmLabel: '닫기',
      showExport: isExtract,
      exportLabel: '엑셀 내보내기',
      exportDisabled: !state.rows.length,
      onExport: isExtract ? () => onExport() : null
    });
  }

  function handleProgress(payload) {
    if (!payload) return;
    if (payload.phase || payload.current != null || payload.total != null) {
      handleExcelProgress(payload);
      return;
    }

    clearProgressHideTimer();
    const pct = Math.max(0, Math.min(100, Number(payload.percent) || 0));
    const subtitle = payload.stage || payload.message || '링크 작업을 진행하는 중입니다.';
    const detail = payload.detail || payload.message || '';
    ProgressDialog.show('링크 작업', subtitle);
    ProgressDialog.update(pct, subtitle, detail);
    if (pct >= 100) scheduleProgressHide(300);
  }

  function handleExcelProgress(payload) {
    const phase = normalizeExcelPhase(payload?.phase);
    const total = Number(payload?.total) || 0;
    const current = Number(payload?.current) || 0;
    const percent = computeExcelPercent(phase, current, total, payload?.phaseProgress, payload?.percent);
    const subtitle = buildExcelSubtitle(phase, current, total);
    const detail = formatExcelDetail(phase, payload?.message);
    const exporting = phase !== 'DONE' && phase !== 'ERROR';

    if (!state.busy && exporting) setBusyState(true);
    clearProgressHideTimer();

    ProgressDialog.show('링크 경로 결과 엑셀 내보내기', subtitle || '링크 경로 결과 엑셀 내보내기를 진행하는 중입니다.');
    ProgressDialog.update(percent, subtitle, detail);

    if (!exporting) {
      scheduleProgressHide(260, () => {
        lastExcelPct = 0;
        setBusyState(false);
      });
    }
  }

  function normalizeExcelPhase(phase) {
    return String(phase || '').trim().toUpperCase() || 'EXCEL_WRITE';
  }

  function computeExcelPercent(phase, current, total, phaseProgress, percentOverride) {
    const norm = normalizeExcelPhase(phase);
    if (norm === 'DONE') {
      lastExcelPct = 100;
      return 100;
    }
    if (Number.isFinite(Number(percentOverride))) {
      const pct = Math.max(lastExcelPct, Math.min(100, Number(percentOverride) * 100));
      lastExcelPct = pct;
      return pct;
    }
    if (norm === 'ERROR') return lastExcelPct;

    const completed = ['EXCEL_INIT', 'EXCEL_WRITE', 'EXCEL_SAVE', 'AUTOFIT'].reduce((acc, key) => {
      if (key === norm) return acc;
      return acc + (EXCEL_PHASE_WEIGHT[key] || 0);
    }, 0);
    const weight = EXCEL_PHASE_WEIGHT[norm] || 0;
    const staged = Number.isFinite(Number(phaseProgress))
      ? Math.max(0, Math.min(1, Number(phaseProgress)))
      : (total > 0 ? Math.max(0, Math.min(1, current / total)) : 0);
    const pct = Math.min(100, Math.max(lastExcelPct, (completed + weight * staged) * 100));
    lastExcelPct = pct;
    return pct;
  }

  function buildExcelSubtitle(phase, current, total) {
    switch (normalizeExcelPhase(phase)) {
      case 'EXCEL_INIT':
        return '링크 경로 결과 엑셀을 준비하는 중입니다.';
      case 'EXCEL_WRITE':
        return `링크 경로 결과 엑셀 데이터를 작성하는 중입니다. (${current}/${Math.max(total, current || 1)})`;
      case 'EXCEL_SAVE':
        return '링크 경로 결과 엑셀을 저장하는 중입니다.';
      case 'AUTOFIT':
        return '열 너비를 조정하는 중입니다.';
      case 'DONE':
        return '링크 경로 결과 엑셀 저장이 완료되었습니다.';
      case 'ERROR':
        return '엑셀 저장 과정에서 오류가 발생했습니다. 저장 경로 권한과 파일이 열려 있는지 확인해 주세요.';
      default:
        return '링크 경로 결과 엑셀 작업을 진행하는 중입니다.';
    }
  }

  function formatExcelDetail(phase, message) {
    const text = String(message || '').trim();
    if (text) return text;
    if (normalizeExcelPhase(phase) === 'DONE') return '링크 현황 엑셀 저장이 완료되었습니다.';
    if (normalizeExcelPhase(phase) === 'ERROR') return '링크 경로 결과 엑셀 저장 과정에서 오류가 발생했습니다. 저장 경로 권한과 파일이 열려 있는지 확인해 주세요.';
    return '';
  }

  function scheduleProgressHide(delay, onDone) {
    clearProgressHideTimer();
    progressHideTimer = window.setTimeout(() => {
      progressHideTimer = null;
      ProgressDialog.hide();
      if (typeof onDone === 'function') onDone();
    }, delay);
  }

  function clearProgressHideTimer() {
    if (!progressHideTimer) return;
    window.clearTimeout(progressHideTimer);
    progressHideTimer = null;
  }

  function setBusyState(nextBusy) {
    state.busy = !!nextBusy;
    setBusy(state.busy);
    syncButtons();
  }

  function syncButtons() {
    const hasRows = state.rows.length > 0;
    const summary = buildSummary(state.rows);
    const hasApplyCandidates = Number(summary.targetCount || 0) + Number(summary.deleteCandidateCount || 0) > 0;
    btnExtract.disabled = state.busy || state.rvtPaths.length === 0;
    btnExport.disabled = state.busy || !hasRows;
    btnApply.disabled = state.busy || !hasApplyCandidates;
    btnPickExcel.disabled = state.busy;
    placementSelect.disabled = state.busy;
    btnAdd.disabled = state.busy;
    btnRemove.disabled = state.busy || state.rvtChecked.size === 0;
    btnClear.disabled = state.busy || state.rvtPaths.length === 0;
  }
}

function normalizeLinkPlacement(value) {
  return ['origin', 'centered', 'shared', 'site'].includes(value) ? value : 'origin';
}

function loadLinkPathPreferences() {
  try {
    const value = JSON.parse(localStorage.getItem(LINKPATH_SETTINGS_KEY) || 'null');
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

function saveLinkPathPreferences(state) {
  const serialized = JSON.stringify({ newLinkPlacement: normalizeLinkPlacement(state.newLinkPlacement) });
  if (serialized === state.lastSavedPreferences) return;
  try {
    localStorage.setItem(LINKPATH_SETTINGS_KEY, serialized);
    state.lastSavedPreferences = serialized;
  } catch {}
}

function attachLinkPathPreferenceSync(page, state, placementSelect) {
  let applyTimer = 0;
  let routeTimer = 0;
  const tryApply = () => {
    clearTimeout(applyTimer);
    clearTimeout(routeTimer);
    if (!page.isConnected) return;
    if (state.busy || document.activeElement === placementSelect) {
      applyTimer = window.setTimeout(tryApply, 400);
      return;
    }
    const value = loadLinkPathPreferences();
    if (!value) return;
    state.newLinkPlacement = normalizeLinkPlacement(value.newLinkPlacement);
    placementSelect.value = state.newLinkPlacement;
    state.lastSavedPreferences = JSON.stringify({ newLinkPlacement: state.newLinkPlacement });
  };
  const onSharedChange = (event) => {
    const detail = event?.detail;
    const keys = Array.isArray(detail?.keys) ? [...detail.keys] : [];
    if (detail?.key) keys.push(detail.key);
    if (detail?.values && typeof detail.values === 'object') keys.push(...Object.keys(detail.values));
    if (!detail || !keys.length || keys.includes(LINKPATH_SETTINGS_KEY)) tryApply();
  };
  const cleanup = () => {
    clearTimeout(applyTimer);
    window.removeEventListener('kky:shared-settings-changed', onSharedChange);
    window.removeEventListener('hashchange', onRouteChange);
    if (activeLinkPathPreferenceCleanup === cleanup) activeLinkPathPreferenceCleanup = null;
  };
  const onRouteChange = () => {
    clearTimeout(routeTimer);
    routeTimer = window.setTimeout(() => {
      if (!page.isConnected) cleanup();
    }, 0);
  };
  window.addEventListener('kky:shared-settings-changed', onSharedChange);
  window.addEventListener('hashchange', onRouteChange);
  return cleanup;
}

function cardBtn(label, onClick, variant = 'btn--primary') {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = `btn ${variant}`;
  btn.textContent = label;
  btn.addEventListener('click', onClick);
  return btn;
}
