import { post } from './bridge.js';

export const KKY_WEBSITE_BASE_URL = 'https://update.zerokky.com';
const MANUAL_FEATURE_BASE_PATH = '/Manual/features';
const DEFAULT_MANUAL_PATH = '/Manual/features.html';
const DEFAULT_LABEL = '가이드';

export const FEATURE_MANUAL_SLUGS = Object.freeze({
  connector: 'connector',
  unconnected: 'unconnected',
  floorinfo: 'floorinfo',
  familysuitability: 'familysuitability',
  tapalign: 'tapalign',
  tapdepth: 'tapdepth',
  tapdepthutility: 'tapdepthutility',
  dupclash: 'dupclash',
  worksetassignment: 'worksetassignment',
  parameterduplication: 'parameterduplication',
  parametermissing: 'parametermissing',
  parameterstandard: 'parameterstandard',
  utilitymaterial: 'utilitymaterial',
  guid: 'guid',
  familylink: 'familylink',
  points: 'points',
  linkworkset: 'linkworkset',
  deliverycleaner: 'deliverycleaner',
  conditionextract: 'conditionextract',
  dup: 'dup',
  paramprop: 'paramprop',
  segmentpms: 'segmentpms',
  linkpath: 'linkpath',
  parammodifier: 'parammodifier',
  sharedparambatch: 'sharedparambatch',
  reducerpoint: 'reducerpoint',
  gridlevelconsistency: 'gridlevelconsistency',
  ghostcleaner: 'ghostcleaner',
  linksharedcoord: 'linksharedcoord',
  centralworkset: 'centralworkset',
  acccloud: 'acccloud',
  accbackup: 'accbackup',
  lateralnozzle: 'lateralnozzle',
  revieworganizer: 'revieworganizer',
  repeatreview: 'repeatreview'
});

export const FEATURE_MANUAL_PATHS = Object.freeze({
  linkbatch: '/Manual/features.html',
  scheduleio: '/Manual/schedule-io.html',
  nwccompare: '/Manual/nwc-compare.html',
  nwcexport: '/Manual/nwc-export.html',
  usermanagement: '/Manual/kky-tool.html'
});

function resolveFeatureSlug(featureId) {
  const key = String(featureId || '').trim().toLowerCase();
  return FEATURE_MANUAL_SLUGS[key] || '';
}

function resolveFeatureManualPath(featureId) {
  const key = String(featureId || '').trim().toLowerCase();
  if (FEATURE_MANUAL_PATHS[key]) return FEATURE_MANUAL_PATHS[key];
  const slug = resolveFeatureSlug(key);
  return slug ? `${MANUAL_FEATURE_BASE_PATH}/${slug}.html` : '';
}

export function getWebsiteUrl(path = '/') {
  const normalizedPath = String(path || '/').trim() || '/';
  return new URL(normalizedPath, `${KKY_WEBSITE_BASE_URL}/`).href;
}

export function getFeatureManualUrl(featureId) {
  return getWebsiteUrl(resolveFeatureManualPath(featureId) || DEFAULT_MANUAL_PATH);
}

export function createFeatureGuideButton(featureId, options = {}) {
  const slug = resolveFeatureSlug(featureId);
  const manualPath = resolveFeatureManualPath(featureId);
  if (!manualPath && options.requireSlug !== false) return null;

  const label = options.text || DEFAULT_LABEL;
  const featureLabel = options.featureLabel || options.title || '기능';
  const button = document.createElement('button');
  button.type = 'button';
  button.className = `feature-guide-button${options.inline ? ' feature-guide-button--inline' : ''}`;
  button.dataset.featureGuideButton = '1';
  button.dataset.featureGuide = String(featureId || '');
  button.title = `${featureLabel} 상세 가이드 열기`;
  button.setAttribute('aria-label', button.title);

  const icon = document.createElement('span');
  icon.className = 'feature-guide-button__icon';
  icon.setAttribute('aria-hidden', 'true');
  icon.innerHTML = '<svg viewBox="0 0 24 24" focusable="false"><path d="M9 21h6M10 17h4M8.5 14.5C6.9 13.4 6 11.7 6 9.7 6 6.4 8.7 4 12 4s6 2.4 6 5.7c0 2-.9 3.7-2.5 4.8-.7.5-1 1.1-1 1.8h-5c0-.7-.3-1.3-1-1.8Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const text = document.createElement('span');
  text.textContent = label;
  button.append(icon, text);

  button.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    post('ui:open-external', {
      url: getFeatureManualUrl(featureId),
      source: 'feature-guide',
      feature: String(featureId || ''),
      slug,
      manualPath: manualPath || DEFAULT_MANUAL_PATH
    });
  });
  return button;
}

export function attachFeatureGuideButton(surface, featureId, options = {}) {
  if (!surface || surface.querySelector(':scope > [data-feature-guide-button]')) return null;
  const button = createFeatureGuideButton(featureId, options);
  if (!button) return null;
  surface.classList.add('feature-guide-surface');
  surface.append(button);
  return button;
}
