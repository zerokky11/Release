import { onHost } from './bridge.js';

function normalizeDocument(raw) {
  if (!raw || raw.isLinked === true || raw.IsLinked === true) return null;
  const name = String(raw.name || raw.Name || raw.title || raw.Title || '').trim();
  const path = String(raw.path || raw.Path || raw.filePath || '').trim();
  if (!name && !path) return null;
  return { ...raw, name, title: String(raw.title || raw.Title || name), path };
}

function sameDocument(left, right) {
  if (!left || !right) return left === right;
  if (left.path || right.path) return String(left.path).toLowerCase() === String(right.path).toLowerCase();
  return String(left.name).toLowerCase() === String(right.name).toLowerCase();
}

// Current context can change during a run; the submitted document remains a separate snapshot.
export function bindActiveDocumentContext(state, onChange) {
  return onHost('host:doc-changed', payload => {
    state.documentContextObserved = true;
    const next = normalizeDocument(payload);
    if (sameDocument(state.activeDocument, next)) {
      if (next) state.activeDocument = { ...state.activeDocument, ...next };
      return;
    }
    state.activeDocument = next;
    onChange?.();
  });
}

export function acceptActiveDocumentSnapshot(state, raw) {
  const next = normalizeDocument(raw);
  if (state.documentContextObserved && !sameDocument(state.activeDocument, next)) return;
  state.activeDocument = next ? { ...state.activeDocument, ...next } : null;
}

export function getActiveDocumentSnapshot(state, fallback) {
  if (state.busy && state.runDocument) return { ...state.runDocument };
  const current = state.documentContextObserved ? state.activeDocument : (state.activeDocument || normalizeDocument(fallback));
  return current ? { ...current } : null;
}

export function beginActiveDocumentRun(state, fallback) {
  state.runDocument = getActiveDocumentSnapshot(state, fallback);
}

export function finishActiveDocumentRun(state) {
  const submitted = state.runDocument;
  state.runDocument = null;
  return submitted;
}
