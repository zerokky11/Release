// Non-modal update discovery notice. Lives outside the legacy, hidden topbar.
const DISPLAY_MS = 8000;
const seen = new Set();
let latest = {};
let detailsHandler = null;
let pendingTimer = 0;
let pendingKey = '';
let current = null;

function version(value) { return String(value || '').trim().replace(/^v/i, ''); }
function releaseKey(state) {
  return state.hasUpdate && version(state.latestVersion)
    ? `${version(state.currentVersionDisplay || state.currentVersion)}|${version(state.latestVersion)}`
    : '';
}
function clearPending() {
  window.clearTimeout(pendingTimer);
  pendingTimer = 0;
  pendingKey = '';
}
function restoreUpdateFocus() {
  const buttons = [...document.querySelectorAll('[data-shell3-update]'), document.getElementById('updateChip')];
  buttons.find(button => button && !button.disabled && button.getClientRects().length)?.focus({ preventScroll: true });
}

export function dismissUpdateNotice({ immediate = false, acknowledge = false } = {}) {
  clearPending();
  if (acknowledge && releaseKey(latest)) seen.add(releaseKey(latest));
  if (!current) return;
  const notice = current;
  current = null;
  window.clearTimeout(notice.timer);
  if (notice.element.contains(document.activeElement)) {
    restoreUpdateFocus();
  }
  notice.element.classList.add('is-leaving');
  notice.element.style.pointerEvents = 'none';
  // A disappearing card must not leave its buttons in the keyboard sequence.
  notice.element.querySelectorAll('button').forEach(button => { button.disabled = true; });
  if (immediate) notice.element.remove();
  else window.setTimeout(() => notice.element.remove(), 180);
}

export function syncUpdateNotice(state, { onDetails, suppress = false, delay = 350 } = {}) {
  latest = { ...state };
  if (onDetails) detailsHandler = onDetails;
  const key = releaseKey(latest);
  if (suppress || !key || latest.busy || latest.kind === 'err') {
    // Suppression can be temporary (for example, an older release dialog is
    // still open). Only an actually displayed notice/dialog acknowledges a key.
    dismissUpdateNotice({ immediate: true });
    return;
  }
  if (current?.key === key) return;
  if (current) dismissUpdateNotice({ immediate: true });
  if (seen.has(key)) { clearPending(); return; }
  if (pendingKey === key && pendingTimer) return;
  clearPending();
  pendingKey = key;
  pendingTimer = window.setTimeout(() => {
    pendingTimer = 0;
    if (document.hidden || releaseKey(latest) !== key || latest.busy) return;
    pendingKey = '';
    showNotice(key);
  }, delay);
}

function pauseNotice() {
  if (!current || !current.timer) return;
  window.clearTimeout(current.timer);
  current.timer = 0;
  current.remaining = Math.max(0, current.remaining - (performance.now() - current.started));
  current.element.classList.add('is-paused');
}

function resumeNotice() {
  if (!current || current.timer || document.hidden || current.hovered || current.element.contains(document.activeElement)) return;
  const notice = current;
  notice.started = performance.now();
  notice.element.classList.remove('is-paused');
  notice.timer = window.setTimeout(() => {
    if (current === notice) dismissUpdateNotice();
  }, notice.remaining);
}

function showNotice(key) {
  if (seen.has(key) || !document.body) return;
  document.querySelectorAll('.update-available-notice.is-leaving').forEach(element => element.remove());
  const element = document.createElement('section');
  element.className = 'update-available-notice';
  element.setAttribute('role', 'region');
  element.setAttribute('aria-label', '새 업데이트 알림');
  element.innerHTML = `
    <div class="update-available-notice__icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 7a7 7 0 0 1 11.5-1L20 9M4 15l2.4 3A7 7 0 0 0 17.9 17"/></svg></div>
    <div class="update-available-notice__content">
      <div role="status" aria-live="polite" aria-atomic="true"><strong class="update-available-notice__title">새 업데이트가 있습니다</strong><p data-notice-version></p></div>
      <p class="update-available-notice__hint">상단 업데이트 버튼에서 다시 확인하세요.</p>
      <button type="button" class="update-available-notice__details" data-notice-details>업데이트 확인 <span aria-hidden="true">→</span></button>
    </div>
    <button type="button" class="update-available-notice__close" data-notice-close aria-label="업데이트 알림 닫기">×</button>
    <div class="update-available-notice__timer" aria-hidden="true"></div>`;
  const currentVersion = version(latest.currentVersionDisplay || latest.currentVersion);
  element.querySelector('[data-notice-version]').textContent = `KKY Tool ${currentVersion} → ${version(latest.latestVersion)}`;
  element.style.setProperty('--notice-duration', `${DISPLAY_MS}ms`);
  const notice = { key, element, timer: 0, started: 0, remaining: DISPLAY_MS, hovered: false };
  current = notice;
  seen.add(key);
  element.querySelector('[data-notice-details]').addEventListener('click', () => {
    dismissUpdateNotice({ immediate: true });
    detailsHandler?.();
  });
  function closeByUser() {
    dismissUpdateNotice({ immediate: true });
  }
  element.querySelector('[data-notice-close]').addEventListener('click', closeByUser);
  element.addEventListener('keydown', event => {
    if (event.key === 'Escape') { event.stopPropagation(); closeByUser(); }
  });
  element.addEventListener('mouseenter', () => { notice.hovered = true; pauseNotice(); });
  element.addEventListener('mouseleave', () => { notice.hovered = false; resumeNotice(); });
  element.addEventListener('focusin', pauseNotice);
  element.addEventListener('focusout', () => window.setTimeout(resumeNotice, 0));
  document.body.append(element);
  resumeNotice();
}

document.addEventListener('visibilitychange', () => {
  if (document.hidden) pauseNotice();
  else if (current) resumeNotice();
  else if (pendingKey) syncUpdateNotice(latest);
});
