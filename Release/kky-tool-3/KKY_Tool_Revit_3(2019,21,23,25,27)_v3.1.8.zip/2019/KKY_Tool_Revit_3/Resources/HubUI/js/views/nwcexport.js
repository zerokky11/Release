import { clear, div, toast, chooseExcelMode, getLastExcelExportLocale, showCompletionSummaryDialog, closeCompletionSummaryDialog, showExcelSavedDialog } from '../core/dom.js?v=20260731parameterexport1';
import { onHost, post } from '../core/bridge.js';
import { ProgressDialog } from '../core/progress.js?v=20260701a';
import { attachRvtDropZone } from '../core/rvtDrop.js?v=20260707rvtdrop1';
import { refreshUiAfterHostDialog } from '../core/hostDialog.js?v=20260701a';

let activeNwcExportCleanup = null;

const NWC_EXPORT_SETTINGS_KEY = 'kky.nwcexport.settings.v2';
const NWC_EXPORT_WORKFLOW_SETTINGS_KEY = 'kky.settings.nwcexport.workflow.v1';
const NWC_EXPORT_SETTINGS_FILE_SCHEMA_VERSION = 1;
const NWC_EXPORT_DEFAULT_SETTINGS = Object.freeze({
  fileNamePattern: '{RVT}_{View}',
  coordinates: 'shared',
  parameters: 'none',
  facetingFactor: 1,
  manageLinkLoadStates: true,
  exportLinks: true,
  convertElementProperties: false,
  exportElementIds: false,
  findMissingMaterials: false,
  divideFileIntoLevels: false,
  exportRoomAsAttribute: false,
  exportRoomGeometry: false,
  exportParts: false,
  exportUrls: false,
  overwriteExisting: false,
  createEmptyGeometryMarker: false
});
const NWC_EXPORT_BOOLEAN_SETTINGS = Object.freeze([
  'convertElementProperties',
  'exportElementIds',
  'findMissingMaterials',
  'divideFileIntoLevels',
  'exportRoomAsAttribute',
  'exportRoomGeometry',
  'exportParts',
  'exportUrls',
  'overwriteExisting',
  'createEmptyGeometryMarker'
]);

export function renderNwcExport(root) {
  activeNwcExportCleanup?.();

  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);
  const workflowSettings = loadNwcExportWorkflowSettings();

  const state = {
    revitVersion: '',
    exporterAvailable: false,
    activeDocument: { name: '', path: '', canUse: false },
    sourceKind: workflowSettings.sourceKind,
    viewSelectionMode: workflowSettings.viewSelectionMode,
    viewNamesText: workflowSettings.viewNamesText,
    nameModeExportLinks: workflowSettings.nameModeExportLinks,
    currentStep: 1,
    targetPaths: [],
    catalogs: [],
    selectedViews: new Set(),
    selectedLinks: new Set(),
    excludedLinkDocuments: new Set(),
    viewQuery: '',
    linkQuery: '',
    activeViewCatalogKey: '',
    activeLinkCatalogKey: '',
    outputFolder: '',
    outputFolderPickerPending: false,
    settings: loadNwcExportSettings(),
    settingsFile: {
      pendingAction: '',
      status: 'idle',
      message: '변경한 추출 설정은 자동으로 기억되며 다른 Revit 창과 공유됩니다.',
      path: ''
    },
    busy: false,
    modalOpen: false,
    modalSnapshot: null,
    quickViewModalOpen: false,
    quickViewQuery: '',
    quickViewDraft: null,
    quickViewEscapeHandler: null,
    quickViewReturnFocus: null,
    dropCleanup: null,
    lastResult: null,
    ui: {
      sharedSettingsPendingKeys: new Set(),
      sharedSettingsRefreshTimer: 0,
      settingsPointerInteractionActive: false,
      settingsCompositionActive: false
    }
  };

  const page = div('feature-shell nwcexport-page');
  const workspace = div('nwcexport-workspace');
  const runPanel = div('nwcexport-run-panel');
  const modal = buildTargetModal(state);
  const quickViewModal = buildQuickViewModal(state);
  page.append(workspace, runPanel);
  target.append(page);
  document.body.append(modal, quickViewModal);

  state.ui.workspace = workspace;
  state.ui.runPanel = runPanel;
  state.ui.modal = modal;
  state.ui.quickViewModal = quickViewModal;
  state.ui.page = page;

  const isSettingsEditableControl = () => {
    const active = document.activeElement;
    return !!(
      active
      && page.contains(active)
      && active.matches?.('input, select, textarea, [contenteditable="true"]')
    );
  };
  const isSettingsInteractionActive = () => (
    state.ui.settingsPointerInteractionActive
    || state.ui.settingsCompositionActive
    || isSettingsEditableControl()
  );
  const applyPendingSharedSettings = () => {
    state.ui.sharedSettingsRefreshTimer = 0;
    if (!state.ui.sharedSettingsPendingKeys.size) return;
    if (state.busy || state.modalOpen || isSettingsInteractionActive()) {
      schedulePendingSharedSettings();
      return;
    }

    const keys = state.ui.sharedSettingsPendingKeys;
    state.ui.sharedSettingsPendingKeys = new Set();
    let changed = false;
    if (keys.has(NWC_EXPORT_SETTINGS_KEY)) {
      state.settings = loadNwcExportSettings();
      changed = true;
    }
    if (keys.has(NWC_EXPORT_WORKFLOW_SETTINGS_KEY)) {
      const incoming = loadNwcExportWorkflowSettings();
      state.sourceKind = incoming.sourceKind;
      state.viewSelectionMode = incoming.viewSelectionMode;
      state.viewNamesText = incoming.viewNamesText;
      state.nameModeExportLinks = incoming.nameModeExportLinks;
      changed = true;
    }
    if (changed) renderAll(state);
  };
  const schedulePendingSharedSettings = () => {
    if (!state.ui.sharedSettingsPendingKeys.size) return;
    window.clearTimeout(state.ui.sharedSettingsRefreshTimer);
    if (state.busy || state.modalOpen) {
      // A shared update may arrive while an Export or target dialog is open. Keep the
      // revision pending and retry after the protected workflow becomes idle instead of
      // dropping the only change event from the cross-process settings store.
      state.ui.sharedSettingsRefreshTimer = window.setTimeout(schedulePendingSharedSettings, 300);
      return;
    }
    if (isSettingsInteractionActive()) return;
    state.ui.sharedSettingsRefreshTimer = window.setTimeout(applyPendingSharedSettings, 0);
  };
  const beginSettingsPointerInteraction = () => {
    state.ui.settingsPointerInteractionActive = true;
  };
  const endSettingsPointerInteraction = () => {
    state.ui.settingsPointerInteractionActive = false;
    window.setTimeout(schedulePendingSharedSettings, 0);
  };
  const beginSettingsComposition = () => {
    state.ui.settingsCompositionActive = true;
  };
  const endSettingsComposition = () => {
    state.ui.settingsCompositionActive = false;
    window.setTimeout(schedulePendingSharedSettings, 0);
  };
  const resumeAfterSettingsFocusChange = () => {
    window.setTimeout(schedulePendingSharedSettings, 0);
  };

  const cleanup = () => {
    state.dropCleanup?.();
    state.dropCleanup = null;
    window.clearTimeout(state.ui.sharedSettingsRefreshTimer);
    state.ui.sharedSettingsRefreshTimer = 0;
    removeQuickViewEscapeHandler(state);
    closeCompletionSummaryDialog();
    modal.remove();
    quickViewModal.remove();
    window.removeEventListener('hashchange', cleanupOnRouteChange);
    window.removeEventListener('kky:shared-settings-changed', onSharedSettingsChanged);
    page.removeEventListener('pointerdown', beginSettingsPointerInteraction, true);
    page.removeEventListener('focusout', resumeAfterSettingsFocusChange, true);
    page.removeEventListener('compositionstart', beginSettingsComposition, true);
    page.removeEventListener('compositionend', endSettingsComposition, true);
    window.removeEventListener('pointerup', endSettingsPointerInteraction, true);
    window.removeEventListener('pointercancel', endSettingsPointerInteraction, true);
    if (activeNwcExportCleanup === cleanup) activeNwcExportCleanup = null;
  };
  const onSharedSettingsChanged = (event) => {
    const keys = Array.isArray(event?.detail?.keys) ? event.detail.keys : [];
    keys
      .filter((key) => key === NWC_EXPORT_SETTINGS_KEY || key === NWC_EXPORT_WORKFLOW_SETTINGS_KEY)
      .forEach((key) => state.ui.sharedSettingsPendingKeys.add(key));
    // Storage synchronization can arrive while a user is composing text or a native select is
    // still open. Defer both the state import and render until that interaction has completed.
    schedulePendingSharedSettings();
  };
  const cleanupOnRouteChange = () => {
    const route = String(location.hash || '').replace(/^#/, '').split('?')[0].toLowerCase();
    if (route !== 'nwcexport') cleanup();
  };
  activeNwcExportCleanup = cleanup;
  window.addEventListener('hashchange', cleanupOnRouteChange);
  window.addEventListener('kky:shared-settings-changed', onSharedSettingsChanged);
  page.addEventListener('pointerdown', beginSettingsPointerInteraction, true);
  page.addEventListener('focusout', resumeAfterSettingsFocusChange, true);
  page.addEventListener('compositionstart', beginSettingsComposition, true);
  page.addEventListener('compositionend', endSettingsComposition, true);
  window.addEventListener('pointerup', endSettingsPointerInteraction, true);
  window.addEventListener('pointercancel', endSettingsPointerInteraction, true);

  registerHostEvents(state);
  renderAll(state);
  post('nwcexport:init', {});
}

function registerHostEvents(state) {
  onHost('nwcexport:init', (payload) => {
    const active = pick(payload, 'activeDocument', 'ActiveDocument') || {};
    state.revitVersion = String(pick(payload, 'revitVersion', 'RevitVersion') || '');
    state.exporterAvailable = !!pick(payload, 'exporterAvailable', 'ExporterAvailable');
    state.activeDocument = {
      name: String(pick(active, 'name', 'Name') || ''),
      path: String(pick(active, 'path', 'Path') || ''),
      canUse: !!pick(active, 'canUse', 'CanUse')
    };
    renderAll(state);
    if (state.activeDocument.canUse && state.sourceKind === 'active') {
      state.busy = true;
      renderAll(state);
      post('nwcexport:scan-active', {});
    }
  });

  onHost('nwcexport:targets-picked', (payload) => {
    if (!state.modalOpen) openTargetModal(state);
    appendTargetPaths(state, arrayOf(pick(payload, 'paths', 'Paths')));
    refreshUiAfterHostDialog(() => renderAll(state));
  });

  onHost('nwcexport:catalog-loaded', (payload) => {
    state.busy = false;
    ProgressDialog.hide();
    const targetKind = String(pick(payload, 'targetKind', 'TargetKind') || 'active').toLowerCase();
    const catalogs = reconcileCatalogs(
      targetKind,
      arrayOf(pick(payload, 'catalogs', 'Catalogs')).map(normalizeCatalog),
      state.targetPaths
    );
    state.sourceKind = targetKind === 'batch' ? 'batch' : 'active';
    state.viewSelectionMode = 'catalog';
    persistNwcExportWorkflowSettings(state);
    state.catalogs = catalogs;
    state.selectedViews.clear();
    state.selectedLinks.clear();
    state.excludedLinkDocuments.clear();
    state.viewQuery = '';
    state.linkQuery = '';
    state.activeViewCatalogKey = catalogs.length ? catalogKey(catalogs[0]) : '';
    state.activeLinkCatalogKey = catalogs.length ? catalogKey(catalogs[0]) : '';
    catalogs.forEach((catalog) => catalog.links.forEach((link) => {
      if (link.isLoaded) state.selectedLinks.add(linkKey(catalog, link));
    }));
    state.currentStep = 1;
    state.lastResult = null;
    refreshUiAfterHostDialog(() => renderAll(state));
    const viewCount = catalogs.reduce((sum, item) => sum + item.views.length, 0);
    toast(`${catalogs.length}개 문서에서 3D View ${viewCount}개를 불러왔습니다.`, viewCount ? 'ok' : 'info');
  });

  onHost('nwcexport:output-folder-picked', (payload) => {
    const ok = pick(payload, 'ok', 'Ok') !== false;
    const cancelled = isHostOperationCanceled(payload);
    const path = String(pick(payload, 'path', 'Path') || '');
    const message = String(pick(payload, 'message', 'Message') || '');
    state.outputFolderPickerPending = false;
    if (ok && path) {
      state.outputFolder = path;
      toast('NWC 저장 폴더를 선택했습니다.', 'ok');
    } else if (!cancelled) {
      toast(message || 'NWC 저장 폴더를 선택하지 못했습니다.', 'err', 5200);
    }
    refreshUiAfterHostDialog(() => renderAll(state));
  });

  onHost('nwcexport:settings-file-saved', (payload) => {
    const ok = pick(payload, 'ok', 'Ok') !== false;
    const cancelled = isHostOperationCanceled(payload);
    const path = String(pick(payload, 'path', 'Path') || '');
    const message = String(pick(payload, 'message', 'Message') || '');
    state.settingsFile.pendingAction = '';
    if (cancelled) {
      setNwcExportSettingsFileStatus(
        state,
        'idle',
        '설정 파일 저장을 취소했습니다. 현재 설정의 자동 기억은 계속 유지됩니다.'
      );
    } else if (!ok || !path) {
      setNwcExportSettingsFileStatus(state, 'error', message || 'NWC 추출 설정 파일을 저장하지 못했습니다.');
      toast(state.settingsFile.message, 'err', 5200);
    } else {
      setNwcExportSettingsFileStatus(state, 'saved', message || 'NWC 추출 설정 파일을 저장했습니다.', path);
      toast('NWC 추출 설정 파일을 저장했습니다.', 'ok');
    }
    refreshUiAfterHostDialog(() => renderAll(state));
  });

  onHost('nwcexport:settings-file-loaded', (payload) => {
    const ok = pick(payload, 'ok', 'Ok') !== false;
    const cancelled = isHostOperationCanceled(payload);
    const path = String(pick(payload, 'path', 'Path') || '');
    const message = String(pick(payload, 'message', 'Message') || '');
    const importedSettings = pick(payload, 'settings', 'Settings');
    state.settingsFile.pendingAction = '';
    if (cancelled) {
      setNwcExportSettingsFileStatus(
        state,
        'idle',
        '설정 파일 불러오기를 취소했습니다. 현재 설정은 바뀌지 않았습니다.'
      );
    } else if (!ok || !importedSettings || typeof importedSettings !== 'object' || Array.isArray(importedSettings)) {
      setNwcExportSettingsFileStatus(state, 'error', message || '올바른 NWC 추출 설정 파일을 불러오지 못했습니다.');
      toast(state.settingsFile.message, 'err', 5200);
    } else {
      // A settings file is deliberately scoped to export options only. Keep the current
      // RVTs, Views, Links, output folder, workflow position, result and progress untouched.
      applyNwcExportSettingsFile(state, importedSettings);
      setNwcExportSettingsFileStatus(state, 'loaded', message || 'NWC 추출 설정 파일을 불러와 적용했습니다.', path);
      toast('NWC 추출 설정을 불러와 적용했습니다.', 'ok');
    }
    refreshUiAfterHostDialog(() => renderAll(state));
  });

  onHost('nwcexport:progress', (payload) => {
    state.busy = true;
    ProgressDialog.setActions({});
    ProgressDialog.show('NWC Export', String(pick(payload, 'message', 'Message') || '추출을 진행하는 중입니다.'));
    ProgressDialog.update(Number(pick(payload, 'percent', 'Percent')) || 0, String(pick(payload, 'message', 'Message') || ''), '');
  });

  onHost('nwcexport:done', (payload) => {
    state.busy = false;
    ProgressDialog.hide();
    const raw = pick(payload, 'result', 'Result') || {};
    state.lastResult = {
      ok: pick(raw, 'ok', 'Ok') !== false,
      message: String(pick(raw, 'message', 'Message') || 'NWC Export를 완료했습니다.'),
      outputFolder: String(pick(raw, 'outputFolder', 'OutputFolder') || state.outputFolder),
      documentCount: Number(pick(raw, 'documentCount', 'DocumentCount')) || 0,
      exportedCount: Number(pick(raw, 'exportedCount', 'ExportedCount')) || 0,
      skippedCount: Number(pick(raw, 'skippedCount', 'SkippedCount')) || 0,
      failedCount: Number(pick(raw, 'failedCount', 'FailedCount')) || 0,
      warningCount: Number(pick(raw, 'warningCount', 'WarningCount')) || 0,
      linkReloadedCount: Number(pick(raw, 'linkReloadedCount', 'LinkReloadedCount')) || 0,
      linkUnloadedCount: Number(pick(raw, 'linkUnloadedCount', 'LinkUnloadedCount')) || 0,
      linkFailedCount: Number(pick(raw, 'linkFailedCount', 'LinkFailedCount')) || 0,
      rows: arrayOf(pick(raw, 'rows', 'Rows')).map((row) => ({
        fileName: String(pick(row, 'fileName', 'FileName') || ''),
        viewName: String(pick(row, 'viewName', 'ViewName') || ''),
        status: String(pick(row, 'status', 'Status') || ''),
        outputPath: String(pick(row, 'outputPath', 'OutputPath') || ''),
        message: String(pick(row, 'message', 'Message') || '')
      }))
    };
    renderAll(state);
    showNwcResultDialog(state);
    toast(state.lastResult.message, state.lastResult.ok ? 'ok' : 'err', 4600);
  });

  onHost('nwcexport:error', (payload) => {
    state.busy = false;
    ProgressDialog.hide();
    state.lastResult = {
      ok: false,
      message: String(pick(payload, 'message', 'Message') || 'NWC Export 중 오류가 발생했습니다.'),
      rows: []
    };
    renderAll(state);
    showNwcResultDialog(state);
    toast(state.lastResult.message, 'err', 5200);
  });

  onHost('nwcexport:excel-exported', (payload) => {
    state.busy = false;
    ProgressDialog.hide();
    const ok = pick(payload, 'ok', 'Ok') !== false;
    const cancelled = !!pick(payload, 'cancelled', 'Cancelled');
    const path = String(pick(payload, 'path', 'Path') || '');
    if (!ok || !path) {
      renderAll(state);
      showNwcResultDialog(state);
      if (!cancelled) toast(String(pick(payload, 'message', 'Message') || 'NWC 결과 Excel 저장에 실패했습니다.'), 'err', 5200);
      return;
    }
    if (state.lastResult) state.lastResult.excelPath = path;
    renderAll(state);
    showNwcResultDialog(state);
    showExcelSavedDialog('NWC 결과 Excel을 저장했습니다.', path, (filePath) => post('excel:open', { path: filePath }));
  });

  onHost('nwcexport:cancelled', () => {
    state.busy = false;
    ProgressDialog.hide();
    renderAll(state);
  });
}

function renderAll(state) {
  renderWorkspace(state);
  renderRunPanel(state);
  renderTargetModal(state);
  renderQuickViewModal(state);
}

function renderWorkspace(state) {
  const host = state.ui.workspace;
  clear(host);

  const linkTotal = state.catalogs
    .filter((catalog) => isCatalogLinksIncluded(state, catalog))
    .reduce((sum, catalog) => sum + catalog.links.length, 0);
  const selectedLinkTotal = countSelectedLinks(state);

  const documentCount = targetDocumentCount(state);
  const viewCount = selectedViewCount(state);
  const fastNameMode = isFastNameMode(state);
  const linkSummary = fastNameMode
    ? (state.nameModeExportLinks ? '모든 문서' : '포함 안 함')
    : `${selectedLinkTotal}/${linkTotal}`;
  const summary = div('nwcexport-summary');
  summary.innerHTML = `
    <div><span class="nwcexport-kicker">NWC Export</span><h2>3D View 일괄 추출</h2></div>
    <div class="nwcexport-summary__stats">
      <span>문서 <strong>${documentCount}</strong></span>
      <span>${fastNameMode ? '입력 View 이름' : '선택 View'} <strong data-nwcexport-selected-view-count>${viewCount}</strong></span>
      <span>${fastNameMode ? 'Revit 링크' : 'Reload 링크'} <strong>${escapeHtml(linkSummary)}</strong></span>
      <span>Revit <strong>${escapeHtml(state.revitVersion || '-')}</strong></span>
    </div>`;
  host.append(summary);

  host.append(buildStepNavigation(state));
  if (state.currentStep === 1) host.append(buildTargetAndLinksStep(state));
  if (state.currentStep === 2) host.append(buildViewSelectionStep(state));
  if (state.currentStep === 3) host.append(buildSettingsCard(state));
  if (state.lastResult) host.append(buildResultTable(state));
}

function buildStepNavigation(state) {
  const nav = div('nwcexport-step-nav');
  const steps = [
    [1, '대상 및 링크'],
    [2, '3D View'],
    [3, '저장 및 Export']
  ];
  steps.forEach(([step, label]) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.step = String(step);
    button.className = `${step === state.currentStep ? 'is-current' : ''} ${step < state.currentStep ? 'is-complete' : ''}`.trim();
    if (step === state.currentStep) button.setAttribute('aria-current', 'step');
    button.innerHTML = `<span>${step}</span><strong>${escapeHtml(label)}</strong>`;
    button.disabled = state.busy || (step > 1 && !hasReadyTarget(state)) || (step > 2 && !hasViewSelection(state));
    button.addEventListener('click', () => goToStep(state, step));
    nav.append(button);
  });
  return nav;
}

function buildTargetAndLinksStep(state) {
  const card = createStepCard('1', '추출 대상과 Revit 링크', '활성 문서 또는 등록 RVT를 선택하고 문서별 링크 로드 계획을 정합니다.');
  const choices = div('nwcexport-source-choices');
  const active = sourceChoice(
    '활성 문서',
    state.activeDocument.name || '열린 프로젝트 문서 없음',
    state.sourceKind === 'active',
    () => scanActive(state)
  );
  active.disabled = state.busy || !state.activeDocument.canUse;
  const batch = sourceChoice(
    '여러 RVT',
    state.targetPaths.length ? `${state.targetPaths.length}개 RVT 등록됨` : 'RVT를 등록해 일괄 추출',
    state.sourceKind === 'batch',
    () => openTargetModal(state)
  );
  batch.disabled = state.busy;
  choices.append(active, batch);
  card.append(choices);

  const source = div('nwcexport-source');
  const sourceLabel = state.sourceKind === 'batch' ? '등록 RVT' : '활성 문서';
  const sourceName = state.sourceKind === 'batch'
    ? `${state.targetPaths.length}개 RVT`
    : (state.activeDocument.name || '활성 문서 없음');
  const sourceStatus = state.busy
    ? '링크와 View 조회 중'
    : (isFastNameMode(state)
      ? '사전 조회 없이 추출 시 View 검색'
      : `${state.catalogs.length}개 문서 준비됨`);
  source.innerHTML = `<span>${sourceLabel}</span><strong title="${escapeHtml(sourceName)}">${escapeHtml(sourceName)}</strong><em>${sourceStatus}</em>`;
  card.append(source);
  appendLinkPlanContent(state, card);
  return card;
}

function buildViewSelectionStep(state) {
  const fastNameMode = isFastNameMode(state);
  const card = createStepCard(
    '2',
    fastNameMode ? '추출할 3D View 이름' : '추출할 3D View',
    fastNameMode
      ? '각 RVT를 미리 열지 않고, 추출 시작 후 입력한 이름과 정확히 일치하는 3D View를 찾아 추출합니다.'
      : '1단계에서 조회한 문서별 3D View 중 NWC로 만들 View를 선택합니다.'
  );
  if (fastNameMode) {
    appendFastNameSelectionContent(state, card);
    return card;
  }
  const toolbar = div('nwcexport-view-toolbar');
  const summary = document.createElement('span');
  summary.className = 'nwcexport-view-toolbar__summary';
  const totalViews = state.catalogs.reduce((sum, catalog) => sum + catalog.views.length, 0);
  summary.innerHTML = `선택 View <strong>${state.selectedViews.size}</strong> / ${totalViews}`;
  const actions = div('nwcexport-view-toolbar__actions');
  const quickView = actionButton('간편 뷰 설정', () => openQuickViewModal(state), 'primary');
  quickView.dataset.openQuickView = 'true';
  quickView.disabled = state.busy || totalViews === 0;
  const selectAll = actionButton('모든 문서 전체 선택', () => {
    state.catalogs.forEach((catalog) => catalog.views.forEach((view) => state.selectedViews.add(viewKey(catalog, view))));
    renderAll(state);
  }, 'secondary');
  selectAll.disabled = state.busy || totalViews === 0;
  const clearSelection = actionButton('모든 문서 선택 해제', () => {
    state.selectedViews.clear();
    renderAll(state);
  }, 'ghost');
  clearSelection.disabled = !state.selectedViews.size;
  actions.append(quickView, selectAll, clearSelection);
  toolbar.append(summary, actions);
  card.append(toolbar);

  const browser = div('nwcexport-view-browser');
  if (state.busy && !state.catalogs.length) {
    browser.append(emptyState('3D View 목록을 불러오는 중입니다.'));
    card.append(browser);
    return card;
  }
  if (!state.catalogs.length) {
    browser.append(emptyState('활성 문서를 열거나 대상 RVT를 등록해 주세요.'));
    card.append(browser);
    return card;
  }

  const activeCatalog = getActiveViewCatalog(state);
  const activeCatalogKey = catalogKey(activeCatalog);
  const nav = div('nwcexport-view-doc-nav');
  const navHead = div('nwcexport-view-doc-nav__head');
  navHead.innerHTML = `<strong>RVT 문서</strong><span>${state.catalogs.length}개</span>`;
  const navList = div('nwcexport-view-doc-list');
  const navStatus = new Map();
  state.catalogs.forEach((catalog) => {
    const key = catalogKey(catalog);
    const isActive = key === activeCatalogKey;
    const documentName = catalog.fileName || catalog.title || '이름 없는 RVT';
    const documentPath = catalog.path || documentName;
    const option = document.createElement('button');
    option.type = 'button';
    option.className = `nwcexport-view-doc-option ${isActive ? 'is-active' : ''}`;
    option.disabled = state.busy;
    option.title = documentPath;
    option.setAttribute('aria-pressed', String(isActive));
    const statusCopy = catalog.scanOk === false ? '조회 실패' : `${catalog.views.length}개 View`;
    option.innerHTML = `
      <span class="nwcexport-view-doc-option__copy">
        <strong title="${escapeHtml(documentPath)}">${escapeHtml(documentName)}</strong>
        <small>${escapeHtml(statusCopy)}</small>
      </span>
      <span class="nwcexport-doc-option__meta">
        <span class="nwcexport-doc-option__active" aria-hidden="true">현재</span>
        <em></em>
      </span>`;
    option.addEventListener('click', (event) => {
      const restoreKeyboardFocus = event.detail === 0;
      state.activeViewCatalogKey = key;
      state.viewQuery = '';
      renderAll(state);
      if (restoreKeyboardFocus) {
        state.ui.page?.querySelector('.nwcexport-view-doc-option.is-active')?.focus({ preventScroll: true });
      }
    });
    navStatus.set(key, option.querySelector('em'));
    navList.append(option);
  });
  nav.append(navHead, navList);

  const detail = div('nwcexport-view-detail');
  const detailHead = div('nwcexport-view-detail__head');
  const detailTitle = div('nwcexport-view-detail__title');
  detailTitle.innerHTML = `<strong title="${escapeHtml(activeCatalog.path || activeCatalog.fileName || activeCatalog.title)}">${escapeHtml(activeCatalog.fileName || activeCatalog.title || '이름 없는 RVT')}</strong><span>${activeCatalog.views.length}개 View</span>`;
  const detailCount = document.createElement('em');
  detailCount.className = 'nwcexport-view-detail__count';
  detailHead.append(detailTitle, detailCount);

  const detailToolbar = div('nwcexport-view-detail__toolbar');
  const search = document.createElement('input');
  search.type = 'search';
  search.value = state.viewQuery;
  search.placeholder = '선택 문서 3D View 이름 검색';
  search.setAttribute('aria-label', '선택 문서 3D View 검색');
  search.disabled = state.busy || !activeCatalog.views.length;
  const detailActions = div('nwcexport-view-detail__actions');
  const selectVisible = actionButton('표시 View 전체 선택', () => {
    getCatalogVisibleViews(state, activeCatalog).forEach((view) => state.selectedViews.add(viewKey(activeCatalog, view)));
    renderRows();
    updateCounts();
  }, 'secondary');
  const clearDocument = actionButton('이 문서 선택 해제', () => {
    activeCatalog.views.forEach((view) => state.selectedViews.delete(viewKey(activeCatalog, view)));
    renderRows();
    updateCounts();
  }, 'ghost');
  detailActions.append(selectVisible, clearDocument);
  detailToolbar.append(search, detailActions);

  const listHost = div('nwcexport-view-detail__list');
  const rows = div('nwcexport-view-list');
  listHost.append(rows);
  detail.append(detailHead, detailToolbar, listHost);
  browser.append(nav, detail);
  card.append(browser);

  const renderRows = () => {
    clear(rows);
    const visibleViews = getCatalogVisibleViews(state, activeCatalog);
    if (!activeCatalog.views.length) {
      const message = activeCatalog.scanOk === false
        ? (activeCatalog.message || '이 RVT의 3D View를 조회하지 못했습니다.')
        : (activeCatalog.message || '이 문서에는 비템플릿 3D View가 없습니다.');
      rows.append(emptyState(message));
      return;
    }
    if (!visibleViews.length) {
      rows.append(emptyState('검색 결과가 없습니다.'));
      return;
    }
    visibleViews.forEach((view) => {
      const key = viewKey(activeCatalog, view);
      const row = document.createElement('label');
      row.className = `nwcexport-view-row ${state.selectedViews.has(key) ? 'is-selected' : ''}`;
      row.innerHTML = `<input type="checkbox" ${state.selectedViews.has(key) ? 'checked' : ''}><span><strong title="${escapeHtml(view.name)}">${escapeHtml(view.name)}</strong>${view.isPerspective ? '<em>Perspective</em>' : ''}</span>`;
      row.querySelector('input').addEventListener('change', (event) => {
        if (event.target.checked) state.selectedViews.add(key);
        else state.selectedViews.delete(key);
        row.classList.toggle('is-selected', event.target.checked);
        updateCounts();
      });
      rows.append(row);
    });
  };

  const updateCounts = () => {
    const selectedInDocument = countCatalogViews(state, activeCatalog);
    const visibleViews = getCatalogVisibleViews(state, activeCatalog);
    summary.innerHTML = `선택 View <strong>${state.selectedViews.size}</strong> / ${totalViews}`;
    detailCount.textContent = `${selectedInDocument}/${activeCatalog.views.length} 선택`;
    state.catalogs.forEach((catalog) => {
      const status = navStatus.get(catalogKey(catalog));
      if (status) status.textContent = `${countCatalogViews(state, catalog)}/${catalog.views.length}`;
    });
    selectVisible.disabled = state.busy || !visibleViews.length || visibleViews.every((view) => state.selectedViews.has(viewKey(activeCatalog, view)));
    clearDocument.disabled = state.busy || selectedInDocument === 0;
    clearSelection.disabled = state.selectedViews.size === 0;
    state.ui.page?.querySelectorAll('[data-nwcexport-selected-view-count]').forEach((node) => {
      node.textContent = String(state.selectedViews.size);
    });
    const stepThree = state.ui.workspace?.querySelector('.nwcexport-step-nav button[data-step="3"]');
    if (stepThree) stepThree.disabled = state.busy || !state.catalogs.length || !state.selectedViews.size;
    renderRunPanel(state);
  };

  search.addEventListener('input', (event) => {
    state.viewQuery = event.target.value;
    renderRows();
    updateCounts();
  });
  renderRows();
  updateCounts();
  return card;
}

function appendFastNameSelectionContent(state, card) {
  const names = parseViewNames(state.viewNamesText);
  const editor = div('nwcexport-name-mode-editor');
  const head = div('nwcexport-name-mode-editor__head');
  head.innerHTML = `
    <div>
      <strong>3D View 이름</strong>
      <span>줄바꿈 또는 쉼표로 여러 이름을 입력할 수 있습니다. 대소문자는 구분하지 않고 전체 이름이 정확히 일치해야 합니다.</span>
    </div>
    <em data-view-name-count>${names.length}개 이름</em>`;

  const textarea = document.createElement('textarea');
  textarea.rows = 6;
  textarea.value = state.viewNamesText;
  textarea.placeholder = '예:\nNWC_EXPORT\nCoordination, A';
  textarea.setAttribute('aria-label', '추출할 3D View 이름');
  textarea.dataset.viewNamesInput = 'true';

  const chips = div('nwcexport-name-mode-chips');
  const message = document.createElement('p');
  message.className = 'nwcexport-name-mode-editor__message';
  message.setAttribute('aria-live', 'polite');

  const updatePreview = () => {
    const parsed = parseViewNames(state.viewNamesText);
    const count = head.querySelector('[data-view-name-count]');
    if (count) count.textContent = `${parsed.length}개 이름`;
    clear(chips);
    parsed.forEach((name) => {
      const chip = document.createElement('span');
      chip.title = name;
      chip.textContent = name;
      chips.append(chip);
    });
    message.textContent = parsed.length
      ? `${state.targetPaths.length}개 RVT에서 위 이름의 3D View를 추출 시작 후 찾습니다.`
      : '추출할 3D View 이름을 하나 이상 입력해 주세요.';
    message.classList.toggle('is-warning', parsed.length === 0);
    state.ui.page?.querySelectorAll('[data-nwcexport-selected-view-count]').forEach((node) => {
      node.textContent = String(parsed.length);
    });
    const stepThree = state.ui.workspace?.querySelector('.nwcexport-step-nav button[data-step="3"]');
    if (stepThree) stepThree.disabled = state.busy || parsed.length === 0;
    renderRunPanel(state);
  };

  textarea.addEventListener('input', () => {
    state.viewNamesText = textarea.value;
    persistNwcExportWorkflowSettings(state);
    updatePreview();
  });
  editor.append(head, textarea, chips, message);
  card.append(editor);

  const note = div('nwcexport-note');
  note.textContent = '입력한 이름이 없는 문서와 템플릿 또는 3D가 아닌 View는 결과에서 건너뜀 사유로 표시됩니다.';
  card.append(note);
  updatePreview();
}

function appendLinkPlanContent(state, card) {
  if (isFastNameMode(state)) {
    appendFastNameLinkPlan(state, card);
    return;
  }
  const heading = div('nwcexport-section-heading');
  heading.innerHTML = '<div><strong>문서별 Revit 링크</strong><span>왼쪽에서 문서를 고른 뒤 오른쪽에서 Reload할 링크를 검색하고 선택합니다.</span></div>';
  card.append(heading);
  const toolbar = div('nwcexport-link-toolbar');
  const summary = document.createElement('span');
  summary.className = 'nwcexport-link-toolbar__summary';
  const includedCatalogs = state.catalogs.filter((catalog) => isCatalogLinksIncluded(state, catalog));
  const total = includedCatalogs.reduce((sum, catalog) => sum + catalog.links.length, 0);
  summary.innerHTML = `Reload 대상 <strong>${countSelectedLinks(state)}</strong> / ${total}`;
  const actions = div('nwcexport-link-toolbar__actions');
  const selectAll = actionButton('모든 문서 Reload', () => {
    includedCatalogs.forEach((catalog) => catalog.links.forEach((link) => state.selectedLinks.add(linkKey(catalog, link))));
    renderAll(state);
  }, 'secondary');
  const resetLoaded = actionButton('모든 문서 현재 상태', () => {
    state.selectedLinks.clear();
    includedCatalogs.forEach((catalog) => catalog.links.forEach((link) => {
      if (link.isLoaded) state.selectedLinks.add(linkKey(catalog, link));
    }));
    renderAll(state);
  }, 'secondary');
  const clearLinks = actionButton('모든 문서 Unload', () => {
    state.selectedLinks.clear();
    renderAll(state);
  }, 'ghost');
  [selectAll, resetLoaded, clearLinks].forEach((button) => {
    button.disabled = state.busy || total === 0;
  });
  actions.append(selectAll, resetLoaded, clearLinks);
  toolbar.append(summary, actions);
  card.append(toolbar);

  const browser = div('nwcexport-link-browser');
  if (!state.catalogs.length) {
    browser.append(emptyState('위에서 활성 문서를 선택하거나 대상 RVT를 등록해 주세요.'));
    card.append(browser);
  } else {
    const activeCatalog = getActiveLinkCatalog(state);
    const activeCatalogKey = catalogKey(activeCatalog);
    const nav = div('nwcexport-link-doc-nav');
    const navHead = div('nwcexport-link-doc-nav__head');
    navHead.innerHTML = `<strong>RVT 문서</strong><span>${state.catalogs.length}개</span>`;
    const navList = div('nwcexport-link-doc-list');
    const navStatus = new Map();

    state.catalogs.forEach((catalog) => {
      const key = catalogKey(catalog);
      const isActive = key === activeCatalogKey;
      const documentName = catalog.fileName || catalog.title || '이름 없는 RVT';
      const documentPath = catalog.path || documentName;
      const option = document.createElement('button');
      option.type = 'button';
      option.className = `nwcexport-link-doc-option ${isActive ? 'is-active' : ''}`;
      option.disabled = state.busy;
      option.title = documentPath;
      option.setAttribute('aria-pressed', String(isActive));
      option.innerHTML = `
        <span class="nwcexport-link-doc-option__copy">
          <strong title="${escapeHtml(documentPath)}">${escapeHtml(documentName)}</strong>
          <small>${catalog.links.length}개 링크</small>
        </span>
        <span class="nwcexport-doc-option__meta">
          <span class="nwcexport-doc-option__active" aria-hidden="true">현재</span>
          <em></em>
        </span>`;
      option.addEventListener('click', (event) => {
        const restoreKeyboardFocus = event.detail === 0;
        state.activeLinkCatalogKey = key;
        state.linkQuery = '';
        renderAll(state);
        if (restoreKeyboardFocus) {
          state.ui.page?.querySelector('.nwcexport-link-doc-option.is-active')?.focus({ preventScroll: true });
        }
      });
      navStatus.set(key, option.querySelector('em'));
      navList.append(option);
    });
    nav.append(navHead, navList);

    const detail = div('nwcexport-link-detail');
    const detailHead = div('nwcexport-link-detail__head');
    const detailTitle = div('nwcexport-link-detail__title');
    detailTitle.innerHTML = `<strong title="${escapeHtml(activeCatalog.path || activeCatalog.fileName || activeCatalog.title)}">${escapeHtml(activeCatalog.fileName || activeCatalog.title)}</strong><span>${activeCatalog.links.length}개 링크</span>`;
    const includeLinks = isCatalogLinksIncluded(state, activeCatalog);
    const include = toggleLine('링크 모델 포함', 'Export Links', includeLinks, (checked) => {
      if (checked) state.excludedLinkDocuments.delete(activeCatalogKey);
      else state.excludedLinkDocuments.add(activeCatalogKey);
      renderAll(state);
    });
    include.classList.add('nwcexport-link-document__toggle');
    const detailCount = document.createElement('em');
    detailCount.className = 'nwcexport-link-detail__count';
    detailHead.append(detailTitle, include, detailCount);

    const detailToolbar = div('nwcexport-link-detail__toolbar');
    const search = document.createElement('input');
    search.type = 'search';
    search.value = state.linkQuery;
    search.placeholder = '선택 문서 링크 이름 또는 경로 검색';
    search.setAttribute('aria-label', '선택 문서 링크 검색');
    search.disabled = state.busy || !includeLinks || !activeCatalog.links.length;
    const detailActions = div('nwcexport-link-detail__actions');
    const selectDocumentLinks = actionButton('전체 Reload', () => {
      activeCatalog.links.forEach((link) => state.selectedLinks.add(linkKey(activeCatalog, link)));
      renderRows();
      updateCounts();
    }, 'secondary');
    const resetDocumentLinks = actionButton('현재 상태', () => {
      activeCatalog.links.forEach((link) => {
        const key = linkKey(activeCatalog, link);
        if (link.isLoaded) state.selectedLinks.add(key);
        else state.selectedLinks.delete(key);
      });
      renderRows();
      updateCounts();
    }, 'secondary');
    const clearDocumentLinks = actionButton('전체 Unload', () => {
      activeCatalog.links.forEach((link) => state.selectedLinks.delete(linkKey(activeCatalog, link)));
      renderRows();
      updateCounts();
    }, 'ghost');
    [selectDocumentLinks, resetDocumentLinks, clearDocumentLinks].forEach((button) => {
      button.disabled = state.busy || !includeLinks || !activeCatalog.links.length;
    });
    detailActions.append(selectDocumentLinks, resetDocumentLinks, clearDocumentLinks);
    detailToolbar.append(search, detailActions);

    const rows = div(`nwcexport-link-list nwcexport-link-detail__list ${includeLinks ? '' : 'is-disabled'}`);

    function updateCounts() {
      summary.innerHTML = `Reload 대상 <strong>${countSelectedLinks(state)}</strong> / ${total}`;
      state.catalogs.forEach((catalog) => {
        const key = catalogKey(catalog);
        const selectedCount = countCatalogLinks(state, catalog);
        const node = navStatus.get(key);
        if (node) node.textContent = isCatalogLinksIncluded(state, catalog) ? `${selectedCount} / ${catalog.links.length}` : '링크 제외';
      });
      const selectedCount = countCatalogLinks(state, activeCatalog);
      detailCount.textContent = includeLinks ? `${selectedCount}개 Reload` : '링크 제외';
    }

    function renderRows() {
      clear(rows);
      const query = normalizeText(state.linkQuery);
      const links = activeCatalog.links.filter((link) => {
        if (!query) return true;
        return normalizeText(`${link.name || ''} ${link.path || ''}`).includes(query);
      });
      if (!activeCatalog.links.length) {
        rows.append(emptyState('이 문서에는 Revit 링크가 없습니다.'));
        return;
      }
      if (!links.length) {
        rows.append(emptyState('검색 결과가 없습니다.'));
        return;
      }
      links.forEach((link) => {
        const key = linkKey(activeCatalog, link);
        const checked = state.selectedLinks.has(key);
        const row = document.createElement('label');
        row.className = `nwcexport-link-row ${checked ? 'is-selected' : ''}`;
        row.innerHTML = `
          <input type="checkbox" ${checked ? 'checked' : ''} ${state.busy || !includeLinks ? 'disabled' : ''}>
          <span class="nwcexport-link-row__copy">
            <strong>${escapeHtml(link.name || fileName(link.path) || `Link ${link.id}`)}</strong>
            <small title="${escapeHtml(link.path)}">${escapeHtml(link.path || '저장 경로 정보 없음')}</small>
          </span>
          <em class="${link.isLoaded ? 'is-loaded' : ''}">${link.isLoaded ? '현재 Loaded' : '현재 Unloaded'}</em>`;
        row.querySelector('input').addEventListener('change', (event) => {
          if (event.target.checked) state.selectedLinks.add(key);
          else state.selectedLinks.delete(key);
          row.classList.toggle('is-selected', event.target.checked);
          updateCounts();
        });
        rows.append(row);
      });
    }

    search.addEventListener('input', () => {
      state.linkQuery = search.value;
      renderRows();
    });
    renderRows();
    updateCounts();
    detail.append(detailHead, detailToolbar, rows);
    browser.append(nav, detail);
    card.append(browser);
  }

  const note = div('nwcexport-note');
  note.textContent = '배치 조회 문서는 링크와 3D View 정보만 수집한 뒤 닫습니다. 실제 추출 시 선택 링크만 Reload하고, 이미 열려 있던 문서는 완료 후 원래 링크 상태로 복원합니다.';
  card.append(note);
}

function appendFastNameLinkPlan(state, card) {
  const heading = div('nwcexport-section-heading');
  heading.innerHTML = '<div><strong>Revit 링크 일괄 처리</strong><span>빠른 방식은 문서를 미리 열지 않으므로 링크를 개별 선택하지 않습니다.</span></div>';
  card.append(heading);

  const panel = div('nwcexport-name-mode-link-plan');
  const includeAll = toggleLine(
    '모든 Revit 링크 포함',
    'Reload and Export All Revit Links',
    state.nameModeExportLinks,
    (checked) => {
      state.nameModeExportLinks = checked;
      persistNwcExportWorkflowSettings(state);
      renderAll(state);
    }
  );
  const description = document.createElement('p');
  description.textContent = state.nameModeExportLinks
    ? '추출 시작 후 각 RVT의 모든 Revit 링크를 Reload하여 NWC에 포함합니다.'
    : '각 RVT의 Revit 링크를 Reload하지 않고 NWC에서도 제외합니다.';
  panel.append(includeAll, description);
  card.append(panel);

  const note = div('nwcexport-note');
  note.textContent = '링크를 문서별 또는 개별로 고르려면 대상 RVT 등록에서 ‘목록에서 직접 선택’을 사용해 주세요.';
  card.append(note);
}

function buildSettingsCard(state) {
  const card = createStepCard('3', '저장 및 Export 옵션', '저장 위치, 파일 이름 구성과 Navisworks Export 옵션을 지정합니다.');
  const pathRow = div('nwcexport-path-row');
  pathRow.innerHTML = `<label>NWC 저장 폴더</label><div><input type="text" readonly value="${escapeHtml(state.outputFolder)}" placeholder="저장 폴더를 선택해 주세요"></div>`;
  const browse = actionButton(
    state.outputFolderPickerPending ? '폴더 선택 중...' : '찾아보기',
    () => requestPickNwcExportOutputFolder(state),
    'secondary'
  );
  browse.disabled = state.busy || state.outputFolderPickerPending || !!state.settingsFile.pendingAction;
  browse.setAttribute('aria-busy', state.outputFolderPickerPending ? 'true' : 'false');
  pathRow.querySelector('div').append(browse);
  card.append(pathRow);

  const fields = div('nwcexport-field-grid nwcexport-field-grid--filename');
  fields.append(selectField('파일 이름 구성', state.settings.fileNamePattern, [
    ['{RVT}_{View}', '파일 이름 + 뷰 이름'],
    ['{View}', '뷰 이름'],
    ['{RVT}', '파일 이름']
  ], (value) => updateNwcExportSetting(state, 'fileNamePattern', value, true)));
  card.append(fields);

  const fileNameExample = div('nwcexport-file-example');
  fileNameExample.innerHTML = `<span>파일 이름 예시</span><strong>${escapeHtml(buildFileNameExample(state))}</strong><em>같은 실행 안의 이름 중복에는 번호가 붙고, 기존 파일은 아래 덮어쓰기 설정을 따릅니다.</em>`;
  card.append(fileNameExample);

  const optionsEditor = div('nwcexport-option-section nwcexport-native-options');
  optionsEditor.innerHTML = '<div class="nwcexport-option-section__head"><strong>Navisworks Export 옵션</strong><span>Navisworks Options Editor - Revit의 표시 순서와 이름을 따릅니다.</span></div>';
  const optionRows = div('nwcexport-native-options__rows');
  optionRows.append(
    optionToggleRow('건설 부품 변환', 'Convert construction parts', state.settings.exportParts, (checked) => updateNwcExportSetting(state, 'exportParts', checked)),
    optionToggleRow('Element ID 변환', 'Convert element Ids', state.settings.exportElementIds, (checked) => updateNwcExportSetting(state, 'exportElementIds', checked)),
    optionSelectRow('요소 파라미터 변환', 'Convert element parameters', state.settings.parameters, [
      ['none', 'None'],
      ['elements', 'Elements'],
      ['all', 'All']
    ], (value) => updateNwcExportSetting(state, 'parameters', value)),
    optionToggleRow('요소 속성 변환', 'Convert element properties', state.settings.convertElementProperties, (checked) => updateNwcExportSetting(state, 'convertElementProperties', checked)),
    optionReadOnlyRow('조명 변환', 'Convert lights', 'Exporter 기본값'),
    optionReadOnlyRow('링크 CAD 형식 변환', 'Convert linked CAD formats', 'Exporter 기본값'),
    optionReadOnlyRow('링크 파일 변환', 'Convert linked files', '1단계 문서별 설정'),
    optionToggleRow('Room을 속성으로 변환', 'Convert room as attribute', state.settings.exportRoomAsAttribute, (checked) => updateNwcExportSetting(state, 'exportRoomAsAttribute', checked)),
    optionToggleRow('URL 변환', 'Convert URLs', state.settings.exportUrls, (checked) => updateNwcExportSetting(state, 'exportUrls', checked)),
    optionSelectRow('좌표', 'Coordinates', state.settings.coordinates, [
      ['shared', 'Shared'],
      ['internal', 'Internal']
    ], (value) => updateNwcExportSetting(state, 'coordinates', value)),
    optionToggleRow('레벨별 파일 분할', 'Divide File into Levels', state.settings.divideFileIntoLevels, (checked) => updateNwcExportSetting(state, 'divideFileIntoLevels', checked)),
    optionReadOnlyRow('추출 범위', 'Export', 'View'),
    optionToggleRow('Room 형상 추출', 'Export room geometry', state.settings.exportRoomGeometry, (checked) => updateNwcExportSetting(state, 'exportRoomGeometry', checked)),
    optionNumberRow('표면 분할 계수', 'Faceting Factor', state.settings.facetingFactor, (value) => updateNwcExportSetting(state, 'facetingFactor', value, true), 0, 100, 0.1),
    optionToggleRow('누락 재질 찾기', 'Try and find missing materials', state.settings.findMissingMaterials, (checked) => updateNwcExportSetting(state, 'findMissingMaterials', checked))
  );
  optionsEditor.append(optionRows);
  card.append(optionsEditor);

  const outputOptions = div('nwcexport-option-section nwcexport-output-options');
  outputOptions.innerHTML = '<div class="nwcexport-option-section__head"><strong>KKY 출력 처리</strong><span>NWC 파일 충돌과 객체 없는 View의 표시 방식을 지정합니다.</span></div>';
  const overwriteExistingRow = optionToggleRow(
    '기존 NWC 덮어쓰기',
    'Overwrite Existing NWC',
    state.settings.overwriteExisting,
    (checked) => updateNwcExportSetting(state, 'overwriteExisting', checked)
  );
  const emptyGeometryMarkerRow = optionToggleRow(
    '객체 없는 View 표시 TXT 생성',
    'Create No-Geometry Marker TXT (_객체없음.txt)',
    state.settings.createEmptyGeometryMarker,
    (checked) => updateNwcExportSetting(state, 'createEmptyGeometryMarker', checked)
  );
  outputOptions.append(
    overwriteExistingRow,
    emptyGeometryMarkerRow
  );
  card.append(outputOptions);

  const settingsFileSection = div('nwcexport-option-section nwcexport-settings-file');
  settingsFileSection.innerHTML = '<div class="nwcexport-option-section__head"><strong>추출 설정 파일</strong><span>현재 NWC 추출 옵션을 파일로 보관하거나 다른 작업에서 다시 불러옵니다.</span></div>';
  const settingsFileActions = div('nwcexport-settings-file__actions');
  const saveSettingsFile = actionButton(
    state.settingsFile.pendingAction === 'save' ? '저장 중...' : '설정 파일 저장',
    () => requestSaveNwcExportSettingsFile(state),
    'secondary'
  );
  saveSettingsFile.classList.add('nwcexport-settings-file-btn--save');
  const loadSettingsFile = actionButton(
    state.settingsFile.pendingAction === 'load' ? '불러오는 중...' : '설정 파일 불러오기',
    () => requestLoadNwcExportSettingsFile(state),
    'secondary'
  );
  loadSettingsFile.classList.add('nwcexport-settings-file-btn--load');
  const settingsFilePending = !!state.settingsFile.pendingAction;
  saveSettingsFile.disabled = state.busy || state.outputFolderPickerPending || settingsFilePending;
  loadSettingsFile.disabled = state.busy || state.outputFolderPickerPending || settingsFilePending;
  settingsFileActions.append(saveSettingsFile, loadSettingsFile);

  const settingsFileStatus = div('nwcexport-settings-file-status');
  settingsFileStatus.dataset.status = state.settingsFile.status || 'idle';
  settingsFileStatus.setAttribute('role', 'status');
  settingsFileStatus.setAttribute('aria-live', 'polite');
  const statusTitle = settingsFileStatusTitle(state.settingsFile.status);
  const statusPath = state.settingsFile.path ? fileName(state.settingsFile.path) : '';
  settingsFileStatus.innerHTML = `
    <span aria-hidden="true"></span>
    <div><strong>${escapeHtml(statusTitle)}</strong><small>${escapeHtml(state.settingsFile.message || '')}</small>${statusPath ? `<em title="${escapeHtml(state.settingsFile.path)}">${escapeHtml(statusPath)}</em>` : ''}</div>`;
  settingsFileSection.append(settingsFileActions, settingsFileStatus);
  card.append(settingsFileSection);

  const note = div('nwcexport-note');
  note.dataset.factorMode = state.revitVersion === '2019' && Number(state.settings.facetingFactor) === 1 ? 'api' : 'configured';
  note.textContent = state.revitVersion === '2019'
    ? (Number(state.settings.facetingFactor) === 1
      ? 'Revit 2019 / Faceting Factor 1: 리본과 옵션 창을 열지 않고 Revit API로 바로 추출합니다.'
      : 'Revit 2019 / Faceting Factor 1 이외: Navisworks 설정 창에 값을 자동 반영한 뒤 추출합니다.')
    : 'Faceting Factor는 현재 Revit API가 지원하는 버전에서 적용됩니다.';
  card.append(note);
  return card;
}

function renderRunPanel(state) {
  const host = state.ui.runPanel;
  clear(host);

  const fastNameMode = isFastNameMode(state);
  const documentCount = targetDocumentCount(state);
  const viewCount = selectedViewCount(state);
  const runCard = asideCard('Workflow', `${state.currentStep} / 3 ${stepTitle(state.currentStep)}`);
  const readiness = div('nwcexport-readiness');
  readiness.append(
    readinessRow('대상', hasReadyTarget(state), state.sourceKind === 'batch' ? `${documentCount}개 RVT` : '활성 문서'),
    readinessRow(fastNameMode ? 'View 이름' : '3D View', hasViewSelection(state), `${viewCount}개`),
    readinessRow(
      'Revit 링크',
      true,
      fastNameMode
        ? (state.nameModeExportLinks ? '모든 링크 포함' : '링크 제외')
        : `${countSelectedLinks(state)}개 Reload`
    ),
    readinessRow('저장 폴더', !!state.outputFolder, state.outputFolder ? '선택됨' : ''),
    readinessRow('Navisworks Exporter', state.exporterAvailable, state.exporterAvailable ? '사용 가능' : '')
  );
  runCard.append(readiness);

  if (state.currentStep === 1) {
    const next = actionButton(fastNameMode ? '다음: View 이름 확인' : '다음: 3D View 선택', () => goToStep(state, 2), 'primary');
    next.disabled = state.busy || !hasReadyTarget(state);
    runCard.append(next);
  } else if (state.currentStep === 2) {
    const nav = div('nwcexport-run-navigation');
    const back = actionButton('이전 설정', () => goToStep(state, 1), 'secondary');
    const next = actionButton('다음: 저장 및 Export', () => goToStep(state, 3), 'primary');
    next.disabled = state.busy || !hasViewSelection(state);
    nav.append(back, next);
    runCard.append(nav);
  } else {
    const back = actionButton('이전 설정', () => goToStep(state, 2), 'secondary');
    const run = actionButton(state.sourceKind === 'batch' ? '여러 RVT NWC 추출' : '활성 문서 NWC 추출', () => runExport(state, state.sourceKind), 'primary');
    run.disabled = !canRun(state, state.sourceKind);
    runCard.append(back, run);
  }
  host.append(runCard);
}

function showNwcResultDialog(state) {
  const result = state.lastResult;
  if (!result) return;
  const outputFolder = result.outputFolder || state.outputFolder;
  const notes = [];
  if (outputFolder) notes.push(`결과 폴더: ${outputFolder}`);
  arrayOf(result.rows).slice(0, 8).forEach((row) => {
    const name = [row.fileName, row.viewName].filter(Boolean).join(' / ');
    const detail = resultDetailText(row);
    notes.push(`${name || 'NWC'}: ${detail}`);
  });
  if (arrayOf(result.rows).length > 8) notes.push(`외 ${arrayOf(result.rows).length - 8}개 결과는 화면의 최근 결과에서 확인할 수 있습니다.`);
  if (result.excelPath) notes.push(`결과 Excel: ${result.excelPath}`);

  const actions = [];
  if (outputFolder) actions.push({ label: '결과 폴더 열기', onClick: () => post('nwcexport:open-output-folder', { path: outputFolder }) });
  if (result.excelPath) actions.push({ label: '결과 Excel 열기', onClick: () => post('excel:open', { path: result.excelPath }) });

  showCompletionSummaryDialog({
    dialogClassName: 'completion-summary-dialog--wide',
    title: 'NWC Export 결과',
    message: result.message || 'NWC Export를 완료했습니다.',
    summaryItems: [
      { label: '대상 문서', value: `${Number(result.documentCount) || 0}개` },
      { label: '정상', value: `${Number(result.exportedCount) || 0}개` },
      { label: '건너뜀', value: `${Number(result.skippedCount) || 0}개` },
      { label: '자동 처리 경고', value: `${Number(result.warningCount) || 0}개` },
      { label: '오류', value: `${Number(result.failedCount) || 0}개` },
      { label: '링크 Reload', value: `${Number(result.linkReloadedCount) || 0}개` },
      { label: '링크 Unload', value: `${Number(result.linkUnloadedCount) || 0}개` },
      { label: '링크 오류', value: `${Number(result.linkFailedCount) || 0}개` }
    ],
    notes,
    actions,
    confirmLabel: '닫기',
    showExport: arrayOf(result.rows).length > 0,
    exportLabel: result.excelPath ? '결과 엑셀 다시 내보내기' : '결과 엑셀 내보내기',
    exportDisabled: state.busy,
    onExport: () => exportNwcResultExcel(state)
  });
}

async function exportNwcResultExcel(state) {
  if (!state.lastResult || state.busy) return;
  const choice = await chooseExcelMode();
  if (!choice) {
    showNwcResultDialog(state);
    return;
  }
  const mode = typeof choice === 'object' ? choice.mode : choice;
  state.busy = true;
  renderAll(state);
  ProgressDialog.setActions({});
  ProgressDialog.show('NWC 결과 Excel 내보내기', '저장 위치를 선택하고 결과 Excel을 생성하는 중입니다.');
  post('nwcexport:export-result-excel', {
    excelMode: mode || 'fast',
    locale: getLastExcelExportLocale()
  });
}

function buildResultTable(state) {
  const result = state.lastResult;
  const card = createCard('최근 결과', result.message || '');
  const rows = div('nwcexport-result-table');
  const head = div('nwcexport-result-row nwcexport-result-row--head');
  head.innerHTML = '<span>RVT</span><span>대상 (View · Link)</span><span>상태</span><span>결과</span>';
  rows.append(head);
  const items = arrayOf(result.rows);
  if (!items.length) rows.append(emptyState('상세 결과가 없습니다.'));
  items.forEach((item) => {
    const row = div('nwcexport-result-row');
    const detail = resultDetailText(item);
    row.innerHTML = `<span>${escapeHtml(item.fileName)}</span><span>${escapeHtml(item.viewName)}</span><span data-status="${escapeHtml(item.status)}">${escapeHtml(statusLabel(item.status))}</span><span title="${escapeHtml(detail)}">${escapeHtml(detail)}</span>`;
    rows.append(row);
  });
  card.append(rows);
  return card;
}

function normalizeNwcExportSettings(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const settings = { ...NWC_EXPORT_DEFAULT_SETTINGS };
  if (['{RVT}_{View}', '{View}', '{RVT}'].includes(source.fileNamePattern)) settings.fileNamePattern = source.fileNamePattern;
  if (['shared', 'internal'].includes(source.coordinates)) settings.coordinates = source.coordinates;
  if (['none', 'elements', 'all'].includes(source.parameters)) settings.parameters = source.parameters;
  const factor = Number(source.facetingFactor);
  if (Number.isFinite(factor)) settings.facetingFactor = Math.max(0, Math.min(100, factor));
  NWC_EXPORT_BOOLEAN_SETTINGS.forEach((key) => {
    if (typeof source[key] === 'boolean') settings[key] = source[key];
  });
  // Link inclusion is controlled only by the visible per-document plan.
  // Ignore hidden 2.x legacy values that may still exist in localStorage.
  settings.manageLinkLoadStates = true;
  settings.exportLinks = true;
  return settings;
}

function loadNwcExportSettings() {
  try {
    const stored = window.localStorage?.getItem(NWC_EXPORT_SETTINGS_KEY);
    return normalizeNwcExportSettings(stored ? JSON.parse(stored) : null);
  } catch {
    return { ...NWC_EXPORT_DEFAULT_SETTINGS };
  }
}

function persistNwcExportSettings(settings) {
  try {
    window.localStorage?.setItem(NWC_EXPORT_SETTINGS_KEY, JSON.stringify(normalizeNwcExportSettings(settings)));
  } catch {
  }
}

function normalizeNwcExportWorkflowSettings(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const sourceKind = source.sourceKind === 'batch' ? 'batch' : 'active';
  const viewSelectionMode = source.viewSelectionMode === 'names' ? 'names' : 'catalog';
  return {
    sourceKind: viewSelectionMode === 'names' ? 'batch' : sourceKind,
    viewSelectionMode,
    viewNamesText: String(source.viewNamesText || '').slice(0, 12000),
    nameModeExportLinks: source.nameModeExportLinks !== false
  };
}

function loadNwcExportWorkflowSettings() {
  try {
    const stored = window.localStorage?.getItem(NWC_EXPORT_WORKFLOW_SETTINGS_KEY);
    return normalizeNwcExportWorkflowSettings(stored ? JSON.parse(stored) : null);
  } catch {
    return normalizeNwcExportWorkflowSettings(null);
  }
}

function persistNwcExportWorkflowSettings(state) {
  try {
    window.localStorage?.setItem(
      NWC_EXPORT_WORKFLOW_SETTINGS_KEY,
      JSON.stringify(normalizeNwcExportWorkflowSettings({
        sourceKind: state.sourceKind,
        viewSelectionMode: state.viewSelectionMode,
        viewNamesText: state.viewNamesText,
        nameModeExportLinks: state.nameModeExportLinks
      }))
    );
  } catch {
  }
}

function updateNwcExportSetting(state, key, value, rerender = false) {
  state.settings[key] = value;
  state.settings = normalizeNwcExportSettings(state.settings);
  persistNwcExportSettings(state.settings);
  if (rerender) renderAll(state);
}

function requestPickNwcExportOutputFolder(state) {
  if (state.busy || state.outputFolderPickerPending || state.settingsFile.pendingAction) return;
  state.outputFolderPickerPending = true;
  renderAll(state);
  if (!post('nwcexport:pick-output-folder', { currentPath: state.outputFolder })) {
    state.outputFolderPickerPending = false;
    renderAll(state);
    toast('Revit으로 NWC 저장 폴더 선택 요청을 보내지 못했습니다.', 'err', 5200);
  }
}

function requestSaveNwcExportSettingsFile(state) {
  if (state.busy || state.outputFolderPickerPending || state.settingsFile.pendingAction) return;
  state.settings = normalizeNwcExportSettings(state.settings);
  persistNwcExportSettings(state.settings);
  state.settingsFile.pendingAction = 'save';
  setNwcExportSettingsFileStatus(state, 'pending', '현재 NWC 추출 설정을 파일로 저장할 위치를 선택해 주세요.');
  renderAll(state);
  if (!post('nwcexport:save-settings-file', buildNwcExportSettingsFilePayload(state))) {
    state.settingsFile.pendingAction = '';
    setNwcExportSettingsFileStatus(state, 'error', 'Revit으로 설정 파일 저장 요청을 보내지 못했습니다.');
    renderAll(state);
  }
}

function requestLoadNwcExportSettingsFile(state) {
  if (state.busy || state.outputFolderPickerPending || state.settingsFile.pendingAction) return;
  state.settingsFile.pendingAction = 'load';
  setNwcExportSettingsFileStatus(state, 'pending', '불러올 NWC 추출 설정 파일을 선택해 주세요.');
  renderAll(state);
  if (!post('nwcexport:load-settings-file', {})) {
    state.settingsFile.pendingAction = '';
    setNwcExportSettingsFileStatus(state, 'error', 'Revit으로 설정 파일 불러오기 요청을 보내지 못했습니다.');
    renderAll(state);
  }
}

function buildNwcExportSettingsFilePayload(state) {
  const settings = normalizeNwcExportSettings(state.settings);
  return {
    schemaVersion: NWC_EXPORT_SETTINGS_FILE_SCHEMA_VERSION,
    settings: {
      fileNamePattern: settings.fileNamePattern,
      coordinates: settings.coordinates,
      parameters: settings.parameters,
      facetingFactor: settings.facetingFactor,
      convertElementProperties: settings.convertElementProperties,
      exportElementIds: settings.exportElementIds,
      findMissingMaterials: settings.findMissingMaterials,
      divideFileIntoLevels: settings.divideFileIntoLevels,
      exportRoomAsAttribute: settings.exportRoomAsAttribute,
      exportRoomGeometry: settings.exportRoomGeometry,
      exportParts: settings.exportParts,
      exportUrls: settings.exportUrls,
      overwriteExisting: settings.overwriteExisting,
      createEmptyGeometryMarker: settings.createEmptyGeometryMarker
    }
  };
}

function applyNwcExportSettingsFile(state, importedSettings) {
  state.settings = normalizeNwcExportSettings(importedSettings);
  persistNwcExportSettings(state.settings);
  renderAll(state);
}

function setNwcExportSettingsFileStatus(state, status, message, path = '') {
  state.settingsFile.status = String(status || 'idle');
  state.settingsFile.message = String(message || '');
  state.settingsFile.path = String(path || '');
}

function settingsFileStatusTitle(status) {
  if (status === 'pending') return '파일 선택 대기 중';
  if (status === 'saved') return '설정 파일 저장 완료';
  if (status === 'loaded') return '설정 파일 적용 완료';
  if (status === 'error') return '설정 파일 처리 실패';
  return '이전 설정 자동 기억';
}

function isHostOperationCanceled(payload) {
  return !!(
    pick(payload, 'canceled', 'Canceled')
    || pick(payload, 'cancelled', 'Cancelled')
  );
}

function openTargetModal(state) {
  if (!state.modalOpen) {
    state.modalSnapshot = {
      targetPaths: [...state.targetPaths],
      sourceKind: state.sourceKind,
      viewSelectionMode: state.viewSelectionMode,
      viewNamesText: state.viewNamesText,
      nameModeExportLinks: state.nameModeExportLinks,
      currentStep: state.currentStep,
      catalogs: state.catalogs,
      selectedViews: new Set(state.selectedViews),
      selectedLinks: new Set(state.selectedLinks),
      excludedLinkDocuments: new Set(state.excludedLinkDocuments),
      viewQuery: state.viewQuery,
      linkQuery: state.linkQuery,
      activeViewCatalogKey: state.activeViewCatalogKey,
      activeLinkCatalogKey: state.activeLinkCatalogKey,
      lastResult: state.lastResult
    };
  }
  state.modalOpen = true;
  renderTargetModal(state);
}

function cancelTargetModal(state) {
  const snapshot = state.modalSnapshot;
  if (snapshot) {
    state.targetPaths = [...snapshot.targetPaths];
    state.sourceKind = snapshot.sourceKind;
    state.viewSelectionMode = snapshot.viewSelectionMode;
    state.viewNamesText = snapshot.viewNamesText;
    state.nameModeExportLinks = snapshot.nameModeExportLinks;
    state.currentStep = snapshot.currentStep;
    state.catalogs = snapshot.catalogs;
    state.selectedViews = new Set(snapshot.selectedViews);
    state.selectedLinks = new Set(snapshot.selectedLinks);
    state.excludedLinkDocuments = new Set(snapshot.excludedLinkDocuments);
    state.viewQuery = snapshot.viewQuery;
    state.linkQuery = snapshot.linkQuery;
    state.activeViewCatalogKey = snapshot.activeViewCatalogKey;
    state.activeLinkCatalogKey = snapshot.activeLinkCatalogKey;
    state.lastResult = snapshot.lastResult;
  }
  state.modalSnapshot = null;
  state.modalOpen = false;
  persistNwcExportWorkflowSettings(state);
  renderAll(state);
}

function confirmTargetModal(state) {
  const snapshot = state.modalSnapshot;
  const fastNameMode = state.viewSelectionMode === 'names';
  const viewNames = parseViewNames(state.viewNamesText);
  if (state.targetPaths.length && fastNameMode && !viewNames.length) {
    toast('빠른 방식으로 추출할 3D View 이름을 하나 이상 입력해 주세요.', 'info');
    renderTargetModal(state);
    return;
  }
  const pathsChanged = !samePathLists(snapshot?.targetPaths || [], state.targetPaths);
  const needsBatchScan = !fastNameMode
    && state.targetPaths.length > 0
    && (pathsChanged || state.sourceKind !== 'batch' || !state.catalogs.length);

  state.modalSnapshot = null;
  state.modalOpen = false;

  if (fastNameMode && state.targetPaths.length) {
    state.sourceKind = 'batch';
    state.catalogs = [];
    state.selectedViews.clear();
    state.selectedLinks.clear();
    state.excludedLinkDocuments.clear();
    state.viewQuery = '';
    state.linkQuery = '';
    state.activeViewCatalogKey = '';
    state.activeLinkCatalogKey = '';
    state.currentStep = 1;
    state.lastResult = null;
    persistNwcExportWorkflowSettings(state);
    renderAll(state);
    toast(`${state.targetPaths.length}개 RVT를 사전 조회 없이 등록했습니다.`, 'ok');
    return;
  }

  if (needsBatchScan) {
    scanBatch(state);
    return;
  }

  if (!state.targetPaths.length && state.sourceKind === 'batch') {
    state.sourceKind = 'active';
    state.catalogs = [];
    state.selectedViews.clear();
    state.selectedLinks.clear();
    state.excludedLinkDocuments.clear();
    state.viewQuery = '';
    state.linkQuery = '';
    state.activeViewCatalogKey = '';
    state.activeLinkCatalogKey = '';
    state.currentStep = 1;
    state.lastResult = null;
    persistNwcExportWorkflowSettings(state);
  }
  renderAll(state);
}

function buildTargetModal(state) {
  const overlay = div('nwcexport-modal is-hidden');
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.innerHTML = `
    <section class="nwcexport-modal-dialog">
      <header><div><h2>대상 RVT 등록</h2><p>RVT를 등록하고 3D View 선택 방식을 정합니다.</p></div><button type="button" data-close aria-label="닫기">x</button></header>
      <div class="nwcexport-modal-body"></div>
      <footer class="nwcexport-modal-footer"></footer>
    </section>`;
  overlay.querySelector('.nwcexport-modal-footer').append(
    actionButton('취소', () => cancelTargetModal(state), 'secondary'),
    actionButton('확인', () => confirmTargetModal(state), 'primary')
  );
  overlay.querySelector('.nwcexport-modal-footer .nwcexport-btn--primary').dataset.targetConfirm = 'true';
  overlay.addEventListener('click', (event) => {
    if (event.target === overlay || event.target.closest('[data-close]')) {
      cancelTargetModal(state);
    }
  });
  return overlay;
}

function renderTargetModal(state) {
  const overlay = state.ui.modal;
  overlay.classList.toggle('is-hidden', !state.modalOpen);
  if (!state.modalOpen) {
    state.dropCleanup?.();
    state.dropCleanup = null;
    return;
  }

  const body = overlay.querySelector('.nwcexport-modal-body');
  clear(body);
  const actions = div('nwcexport-modal-actions');
  const add = actionButton('RVT 추가', () => post('nwcexport:pick-target-rvts', {}), 'primary');
  const clearButton = actionButton('목록 비우기', () => {
    state.targetPaths = [];
    renderAll(state);
  }, 'secondary');
  clearButton.disabled = !state.targetPaths.length || state.busy;
  actions.append(add, clearButton);

  const mode = div('nwcexport-target-mode');
  const modeHead = div('nwcexport-target-mode__head');
  modeHead.innerHTML = '<strong>3D View 선택 방식</strong><span>작업 성격에 맞는 방식을 선택해 주세요.</span>';
  const modeChoices = div('nwcexport-source-choices nwcexport-target-mode__choices');
  const catalogMode = sourceChoice(
    '목록에서 직접 선택',
    '등록 확인 후 RVT를 열어 View와 링크 목록을 조회',
    state.viewSelectionMode !== 'names',
    () => {
      state.viewSelectionMode = 'catalog';
      persistNwcExportWorkflowSettings(state);
      renderAll(state);
    }
  );
  catalogMode.dataset.viewSelectionMode = 'catalog';
  const namesMode = sourceChoice(
    '뷰 이름으로 일괄 추출 (빠른 방식)',
    '지금은 열지 않고 추출 시작 후 이름으로 검색',
    state.viewSelectionMode === 'names',
    () => {
      state.viewSelectionMode = 'names';
      state.sourceKind = 'batch';
      persistNwcExportWorkflowSettings(state);
      renderAll(state);
      window.requestAnimationFrame(() => {
        state.ui.modal?.querySelector('[data-view-names-input]')?.focus();
      });
    }
  );
  namesMode.dataset.viewSelectionMode = 'names';
  modeChoices.append(catalogMode, namesMode);
  mode.append(modeHead, modeChoices);

  const drop = div('nwcexport-rvt-drop');
  const dropDescription = state.viewSelectionMode === 'names'
    ? '파일을 추가해도 지금은 열지 않습니다. 추출을 시작할 때 View를 찾습니다.'
    : '파일을 추가한 뒤 확인을 누르면 3D View와 링크 목록을 갱신합니다.';
  drop.innerHTML = `<strong>${state.targetPaths.length ? `${state.targetPaths.length}개 RVT 등록됨` : 'RVT 파일을 여기에 놓으세요'}</strong><span>${dropDescription}</span>`;
  state.dropCleanup?.();
  state.dropCleanup = attachRvtDropZone(drop, {
    onDropPaths: (paths) => {
      appendTargetPaths(state, paths);
      renderAll(state);
    },
    onInvalid: (payload) => toast(payload?.message || 'RVT 파일만 추가할 수 있습니다.', 'err')
  });

  const nameEditor = state.viewSelectionMode === 'names'
    ? buildTargetNameEditor(state)
    : null;
  const list = div('nwcexport-target-list');
  if (!state.targetPaths.length) list.append(emptyState('등록된 RVT가 없습니다.'));
  state.targetPaths.forEach((path, index) => {
    const row = div('nwcexport-target-row');
    row.innerHTML = `<span><strong>${escapeHtml(fileName(path))}</strong><em>${escapeHtml(path)}</em></span>`;
    const remove = actionButton('제거', () => {
      state.targetPaths.splice(index, 1);
      renderAll(state);
    }, 'ghost');
    remove.disabled = state.busy;
    row.append(remove);
    list.append(row);
  });
  body.append(actions, mode, drop);
  if (nameEditor) body.append(nameEditor);
  body.append(list);
  const confirm = overlay.querySelector('[data-target-confirm]');
  if (confirm) {
    confirm.disabled = state.busy
      || (state.targetPaths.length > 0
        && state.viewSelectionMode === 'names'
        && parseViewNames(state.viewNamesText).length === 0);
  }
}

function buildTargetNameEditor(state) {
  const host = div('nwcexport-name-mode-editor nwcexport-name-mode-editor--modal');
  const names = parseViewNames(state.viewNamesText);
  const head = div('nwcexport-name-mode-editor__head');
  head.innerHTML = `
    <div>
      <strong>추출할 3D View 이름</strong>
      <span>줄바꿈 또는 쉼표로 여러 개를 입력할 수 있습니다.</span>
    </div>
    <em data-view-name-count>${names.length}개 이름</em>`;
  const textarea = document.createElement('textarea');
  textarea.rows = 4;
  textarea.value = state.viewNamesText;
  textarea.placeholder = '예: NWC_EXPORT, Coordination';
  textarea.setAttribute('aria-label', '빠른 방식 3D View 이름');
  textarea.dataset.viewNamesInput = 'true';
  const message = document.createElement('p');
  message.className = 'nwcexport-name-mode-editor__message';
  message.setAttribute('aria-live', 'polite');

  const update = () => {
    const parsed = parseViewNames(state.viewNamesText);
    const count = head.querySelector('[data-view-name-count]');
    if (count) count.textContent = `${parsed.length}개 이름`;
    message.textContent = parsed.length
      ? `${parsed.length}개 이름을 각 RVT에서 정확히 일치로 찾습니다.`
      : '3D View 이름을 하나 이상 입력해야 확인할 수 있습니다.';
    message.classList.toggle('is-warning', parsed.length === 0);
    const confirm = state.ui.modal?.querySelector('[data-target-confirm]');
    if (confirm) confirm.disabled = state.busy || (state.targetPaths.length > 0 && parsed.length === 0);
  };
  textarea.addEventListener('input', () => {
    state.viewNamesText = textarea.value;
    persistNwcExportWorkflowSettings(state);
    update();
  });
  host.append(head, textarea, message);
  update();
  return host;
}

function openQuickViewModal(state) {
  if (state.busy || !state.catalogs.length) return;
  state.quickViewDraft = new Set(state.selectedViews);
  state.quickViewQuery = '';
  state.quickViewModalOpen = true;
  state.quickViewReturnFocus = document.activeElement;
  removeQuickViewEscapeHandler(state);
  state.quickViewEscapeHandler = (event) => {
    if (event.key !== 'Escape' || !state.quickViewModalOpen) return;
    event.preventDefault();
    event.stopPropagation();
    cancelQuickViewModal(state);
  };
  document.addEventListener('keydown', state.quickViewEscapeHandler, true);
  renderQuickViewModal(state);
  window.requestAnimationFrame(() => {
    state.ui.quickViewModal?.querySelector('[data-quick-view-search]')?.focus();
  });
}

function cancelQuickViewModal(state) {
  const returnFocus = state.quickViewReturnFocus;
  state.quickViewModalOpen = false;
  state.quickViewQuery = '';
  state.quickViewDraft = null;
  state.quickViewReturnFocus = null;
  removeQuickViewEscapeHandler(state);
  renderQuickViewModal(state);
  window.requestAnimationFrame(() => {
    if (returnFocus?.isConnected) returnFocus.focus();
    else state.ui.page?.querySelector('[data-open-quick-view]')?.focus();
  });
}

function applyQuickViewModal(state, moveToNextStep) {
  const draft = state.quickViewDraft instanceof Set
    ? state.quickViewDraft
    : new Set(state.selectedViews);
  state.selectedViews = new Set(draft);
  pruneSelectedViews(state);
  const selectedCount = state.selectedViews.size;
  state.quickViewModalOpen = false;
  state.quickViewQuery = '';
  state.quickViewDraft = null;
  state.quickViewReturnFocus = null;
  removeQuickViewEscapeHandler(state);
  if (moveToNextStep && selectedCount > 0) state.currentStep = 3;
  renderAll(state);
  toast(
    selectedCount
      ? `${selectedCount}개 3D View 선택을 적용했습니다.`
      : '3D View 선택을 모두 해제했습니다.',
    selectedCount ? 'ok' : 'info'
  );
  if (!moveToNextStep) {
    window.requestAnimationFrame(() => {
      state.ui.page?.querySelector('[data-open-quick-view]')?.focus();
    });
  }
}

function removeQuickViewEscapeHandler(state) {
  if (!state.quickViewEscapeHandler) return;
  document.removeEventListener('keydown', state.quickViewEscapeHandler, true);
  state.quickViewEscapeHandler = null;
}

function buildQuickViewModal(state) {
  const overlay = div('nwcexport-modal nwcexport-quick-view-modal is-hidden');
  overlay.innerHTML = `
    <section class="nwcexport-modal-dialog nwcexport-quick-view-dialog"
             role="dialog"
             aria-modal="true"
             aria-labelledby="nwcexport-quick-view-title">
      <header>
        <div>
          <h2 id="nwcexport-quick-view-title">간편 3D View 설정</h2>
          <p>모든 대상 RVT에서 View 이름을 한 번에 검색하고 추출할 View를 선택합니다.</p>
        </div>
        <button type="button" data-close aria-label="닫기">×</button>
      </header>
      <div class="nwcexport-modal-body nwcexport-quick-view-body"></div>
      <footer class="nwcexport-modal-footer nwcexport-quick-view-footer">
        <span aria-live="polite">임시 선택 <strong data-quick-view-selected-count>0</strong>개</span>
        <div data-quick-view-footer-actions></div>
      </footer>
    </section>`;
  const footerActions = overlay.querySelector('[data-quick-view-footer-actions]');
  const cancel = actionButton('취소', () => cancelQuickViewModal(state), 'ghost');
  const apply = actionButton('선택 적용', () => applyQuickViewModal(state, false), 'secondary');
  const applyAndNext = actionButton('적용 후 다음 설정', () => applyQuickViewModal(state, true), 'primary');
  applyAndNext.dataset.quickViewApplyNext = 'true';
  footerActions.append(cancel, apply, applyAndNext);
  overlay.addEventListener('click', (event) => {
    if (event.target === overlay || event.target.closest('[data-close]')) {
      cancelQuickViewModal(state);
    }
  });
  return overlay;
}

function renderQuickViewModal(state) {
  const overlay = state.ui.quickViewModal;
  if (!overlay) return;
  overlay.classList.toggle('is-hidden', !state.quickViewModalOpen);
  if (!state.quickViewModalOpen) return;
  if (!(state.quickViewDraft instanceof Set)) {
    state.quickViewDraft = new Set(state.selectedViews);
  }

  const body = overlay.querySelector('.nwcexport-quick-view-body');
  clear(body);
  const totalViews = state.catalogs.reduce((sum, catalog) => sum + catalog.views.length, 0);
  const scannedDocuments = state.catalogs.filter((catalog) => catalog.scanOk !== false).length;

  const overview = div('nwcexport-quick-view-overview');
  overview.innerHTML = `
    <span>대상 문서 <strong>${state.catalogs.length}</strong>개</span>
    <span>조회 완료 <strong>${scannedDocuments}</strong>개</span>
    <span>전체 View <strong>${totalViews}</strong>개</span>
    <span>임시 선택 <strong data-quick-view-selected-count>${state.quickViewDraft.size}</strong>개</span>`;

  const searchPanel = div('nwcexport-quick-view-search');
  const searchLabel = document.createElement('label');
  searchLabel.innerHTML = '<span>모든 문서에서 View 이름 검색</span>';
  const search = document.createElement('input');
  search.type = 'search';
  search.value = state.quickViewQuery;
  search.placeholder = '예: A, Coordination, NWC';
  search.setAttribute('aria-label', '모든 문서에서 3D View 이름 검색');
  search.dataset.quickViewSearch = 'true';
  searchLabel.append(search);
  const clearSearch = actionButton('검색 지우기', () => {
    state.quickViewQuery = '';
    search.value = '';
    renderResults();
    search.focus();
  }, 'ghost');
  searchPanel.append(searchLabel, clearSearch);

  const resultHead = div('nwcexport-quick-view-result-head');
  const resultSummary = document.createElement('p');
  resultSummary.setAttribute('aria-live', 'polite');
  const resultActions = div('nwcexport-quick-view-result-actions');
  resultHead.append(resultSummary, resultActions);
  const results = div('nwcexport-quick-view-results');
  body.append(overview, searchPanel, resultHead, results);

  const renderResults = () => {
    clear(resultActions);
    clear(results);
    clearSearch.disabled = !normalizeText(state.quickViewQuery);
    const query = normalizeText(state.quickViewQuery);

    if (!query) {
      resultSummary.textContent = '검색어를 입력하거나 여러 문서에 공통으로 존재하는 View를 선택해 주세요.';
      const clearDraft = actionButton('현재 선택 모두 해제', () => {
        state.quickViewDraft.clear();
        renderResults();
      }, 'ghost');
      clearDraft.disabled = state.quickViewDraft.size === 0;
      resultActions.append(clearDraft);

      const commonGroups = getQuickViewCommonGroups(state);
      if (!commonGroups.length) {
        results.append(emptyState('View 이름을 입력하면 모든 대상 문서의 검색 결과가 여기에 표시됩니다.'));
      } else {
        const common = div('nwcexport-quick-view-common');
        const commonHead = div('nwcexport-quick-view-common__head');
        commonHead.innerHTML = '<strong>공통 View 빠른 검색</strong><span>많은 문서에 존재하는 순</span>';
        const chips = div('nwcexport-quick-view-chips');
        commonGroups.forEach((group) => {
          const chip = document.createElement('button');
          chip.type = 'button';
          chip.title = `${group.name} · ${group.documentCount}/${state.catalogs.length}개 문서`;
          chip.innerHTML = `<strong>${escapeHtml(group.name)}</strong><span>${group.documentCount}/${state.catalogs.length}</span>`;
          chip.addEventListener('click', () => {
            state.quickViewQuery = group.name;
            search.value = group.name;
            renderResults();
            search.focus();
            search.select();
          });
          chips.append(chip);
        });
        common.append(commonHead, chips);
        results.append(common);
      }
      appendQuickViewScanFailures(state, results);
      updateQuickViewModalSelectionState(state);
      return;
    }

    const groups = getQuickViewSearchGroups(state, query);
    const matchedEntries = groups.flatMap((group) => group.entries);
    const exactEntries = groups.filter((group) => group.isExact).flatMap((group) => group.entries);
    const matchedDocuments = new Set(matchedEntries.map((entry) => entry.documentKey)).size;
    const exactDocuments = new Set(exactEntries.map((entry) => entry.documentKey)).size;
    const partialCount = matchedEntries.length - exactEntries.length;
    resultSummary.textContent = exactEntries.length
      ? `정확히 일치 ${exactEntries.length}개 · ${exactDocuments}/${state.catalogs.length}개 문서 · 유사 이름 ${partialCount}개`
      : `검색 결과 ${matchedEntries.length}개 · ${matchedDocuments}/${state.catalogs.length}개 문서`;

    if (exactEntries.length) {
      const selectExact = actionButton('정확히 일치 전체 선택', () => {
        setQuickViewDraftEntries(state, exactEntries, true);
        renderResults();
      }, 'primary');
      selectExact.disabled = exactEntries.every((entry) => state.quickViewDraft.has(entry.key));
      resultActions.append(selectExact);
    }
    if (matchedEntries.length) {
      const selectMatches = actionButton(exactEntries.length ? '유사 이름 포함 전체 선택' : '검색 결과 전체 선택', () => {
        setQuickViewDraftEntries(state, matchedEntries, true);
        renderResults();
      }, 'secondary');
      selectMatches.disabled = matchedEntries.every((entry) => state.quickViewDraft.has(entry.key));
      const clearMatches = actionButton('검색 결과 선택 해제', () => {
        setQuickViewDraftEntries(state, matchedEntries, false);
        renderResults();
      }, 'ghost');
      clearMatches.disabled = matchedEntries.every((entry) => !state.quickViewDraft.has(entry.key));
      resultActions.append(selectMatches, clearMatches);
    }

    if (!groups.length) {
      results.append(emptyState(`"${state.quickViewQuery.trim()}"에 해당하는 3D View가 없습니다.`));
    } else if (exactEntries.length) {
      const exactGroups = groups.filter((group) => group.isExact);
      const similarGroups = groups.filter((group) => !group.isExact);
      exactGroups.forEach((group) => {
        results.append(buildQuickViewResultGroup(state, group, renderResults));
      });
      if (similarGroups.length) {
        const similar = document.createElement('details');
        similar.className = 'nwcexport-quick-view-similar';
        const similarSummary = document.createElement('summary');
        similarSummary.textContent = `유사한 이름 ${partialCount}개 View · ${similarGroups.length}개 이름 보기`;
        const similarGroupsHost = div('nwcexport-quick-view-similar__groups');
        similarGroups.forEach((group) => {
          similarGroupsHost.append(buildQuickViewResultGroup(state, group, renderResults));
        });
        similar.append(similarSummary, similarGroupsHost);
        results.append(similar);
      }
    } else {
      groups.forEach((group) => {
        results.append(buildQuickViewResultGroup(state, group, renderResults));
      });
    }
    appendQuickViewMissingDocuments(state, results, state.quickViewQuery.trim(), exactEntries);
    appendQuickViewScanFailures(state, results);
    updateQuickViewModalSelectionState(state);
  };

  search.addEventListener('input', (event) => {
    state.quickViewQuery = event.target.value;
    renderResults();
  });
  renderResults();
}

function buildQuickViewResultGroup(state, group, rerender) {
  const host = div(`nwcexport-quick-view-group ${group.isExact ? 'is-exact' : ''}`);
  const head = div('nwcexport-quick-view-group__head');
  const copy = div('nwcexport-quick-view-group__copy');
  copy.innerHTML = `
    <span>${group.isExact ? '정확히 일치' : '유사 이름'}</span>
    <strong title="${escapeHtml(group.name)}">${escapeHtml(group.name)}</strong>
    <em>${group.documentCount}/${group.totalDocuments}개 문서</em>`;
  const actions = div('nwcexport-quick-view-group__actions');
  const selectGroup = actionButton('이 이름 전체 선택', () => {
    setQuickViewDraftEntries(state, group.entries, true);
    rerender();
  }, group.isExact ? 'primary' : 'secondary');
  selectGroup.dataset.quickViewGroupSelect = 'true';
  const clearGroup = actionButton('선택 해제', () => {
    setQuickViewDraftEntries(state, group.entries, false);
    rerender();
  }, 'ghost');
  clearGroup.dataset.quickViewGroupClear = 'true';
  const groupCount = document.createElement('small');
  groupCount.dataset.quickViewGroupCount = 'true';
  actions.append(groupCount, selectGroup, clearGroup);
  head.append(copy, actions);

  const rows = div('nwcexport-quick-view-group__rows');
  group.entries.forEach((entry) => {
    const row = document.createElement('label');
    row.className = `nwcexport-quick-view-row ${state.quickViewDraft.has(entry.key) ? 'is-selected' : ''}`;
    row.dataset.quickViewKey = entry.key;
    row.title = entry.documentPath;
    row.innerHTML = `
      <input type="checkbox" ${state.quickViewDraft.has(entry.key) ? 'checked' : ''}>
      <span>
        <strong>${escapeHtml(entry.documentName)}</strong>
        <small><span>${escapeHtml(entry.view.name)}</span>${entry.parentFolder ? `<em>${escapeHtml(entry.parentFolder)}</em>` : ''}</small>
      </span>`;
    row.querySelector('input').addEventListener('change', (event) => {
      if (event.target.checked) state.quickViewDraft.add(entry.key);
      else state.quickViewDraft.delete(entry.key);
      updateQuickViewModalSelectionState(state);
    });
    rows.append(row);
  });
  host.append(head, rows);
  return host;
}

function setQuickViewDraftEntries(state, entries, selected) {
  entries.forEach((entry) => {
    if (selected) state.quickViewDraft.add(entry.key);
    else state.quickViewDraft.delete(entry.key);
  });
}

function updateQuickViewModalSelectionState(state) {
  const overlay = state.ui.quickViewModal;
  if (!overlay || !(state.quickViewDraft instanceof Set)) return;
  overlay.querySelectorAll('[data-quick-view-selected-count]').forEach((node) => {
    node.textContent = String(state.quickViewDraft.size);
  });
  overlay.querySelectorAll('[data-quick-view-key]').forEach((row) => {
    const selected = state.quickViewDraft.has(row.dataset.quickViewKey);
    row.classList.toggle('is-selected', selected);
    const checkbox = row.querySelector('input[type="checkbox"]');
    if (checkbox) checkbox.checked = selected;
  });
  overlay.querySelectorAll('.nwcexport-quick-view-group').forEach((group) => {
    const rows = [...group.querySelectorAll('[data-quick-view-key]')];
    const selectedCount = rows.filter((row) => state.quickViewDraft.has(row.dataset.quickViewKey)).length;
    const count = group.querySelector('[data-quick-view-group-count]');
    if (count) count.textContent = `${selectedCount}/${rows.length} 선택`;
    const select = group.querySelector('[data-quick-view-group-select]');
    const clear = group.querySelector('[data-quick-view-group-clear]');
    if (select) select.disabled = rows.length === 0 || selectedCount === rows.length;
    if (clear) clear.disabled = selectedCount === 0;
  });
  const applyNext = overlay.querySelector('[data-quick-view-apply-next]');
  if (applyNext) applyNext.disabled = state.quickViewDraft.size === 0;
}

function appendQuickViewMissingDocuments(state, host, query, exactEntries) {
  const exactDocumentKeys = new Set(exactEntries.map((entry) => entry.documentKey));
  const missing = state.catalogs.filter((catalog) => catalog.scanOk !== false
    && !exactDocumentKeys.has(catalogKey(catalog)));
  if (!missing.length) return;
  const details = document.createElement('details');
  details.className = 'nwcexport-quick-view-details';
  const summary = document.createElement('summary');
  summary.textContent = `정확히 "${query}" View가 없는 문서 ${missing.length}개`;
  const list = div('nwcexport-quick-view-details__list');
  missing.forEach((catalog) => {
    const item = document.createElement('span');
    item.title = catalog.path || catalog.fileName || catalog.title || '';
    item.textContent = catalog.fileName || catalog.title || '이름 없는 RVT';
    list.append(item);
  });
  details.append(summary, list);
  host.append(details);
}

function appendQuickViewScanFailures(state, host) {
  const failed = state.catalogs.filter((catalog) => catalog.scanOk === false);
  if (!failed.length) return;
  const details = document.createElement('details');
  details.className = 'nwcexport-quick-view-details is-warning';
  const summary = document.createElement('summary');
  summary.textContent = `View 조회 실패 문서 ${failed.length}개`;
  const list = div('nwcexport-quick-view-details__list');
  failed.forEach((catalog) => {
    const item = document.createElement('span');
    item.title = [catalog.path, catalog.message].filter(Boolean).join(' · ');
    item.textContent = catalog.fileName || catalog.title || '이름 없는 RVT';
    list.append(item);
  });
  details.append(summary, list);
  host.append(details);
}

function scanActive(state) {
  if (state.busy || !state.activeDocument.canUse) return;
  state.sourceKind = 'active';
  state.viewSelectionMode = 'catalog';
  state.catalogs = [];
  state.selectedViews.clear();
  state.selectedLinks.clear();
  state.excludedLinkDocuments.clear();
  state.viewQuery = '';
  state.linkQuery = '';
  state.activeViewCatalogKey = '';
  state.activeLinkCatalogKey = '';
  state.currentStep = 1;
  state.busy = true;
  state.lastResult = null;
  persistNwcExportWorkflowSettings(state);
  renderAll(state);
  ProgressDialog.setActions({});
  ProgressDialog.show('3D View 조회', '활성 문서의 3D View를 읽는 중입니다.');
  post('nwcexport:scan-active', {});
}

function scanBatch(state) {
  if (state.busy || !state.targetPaths.length) return;
  state.sourceKind = 'batch';
  state.viewSelectionMode = 'catalog';
  state.catalogs = [];
  state.selectedViews.clear();
  state.selectedLinks.clear();
  state.excludedLinkDocuments.clear();
  state.viewQuery = '';
  state.linkQuery = '';
  state.activeViewCatalogKey = '';
  state.activeLinkCatalogKey = '';
  state.currentStep = 1;
  state.busy = true;
  state.lastResult = null;
  persistNwcExportWorkflowSettings(state);
  renderAll(state);
  ProgressDialog.setActions({});
  ProgressDialog.show('3D View 조회', `${state.targetPaths.length}개 RVT의 3D View를 읽는 중입니다.`);
  post('nwcexport:scan-batch', { paths: state.targetPaths });
}

function runExport(state, targetKind) {
  if (!canRun(state, targetKind)) return;
  persistNwcExportSettings(state.settings);
  persistNwcExportWorkflowSettings(state);
  state.busy = true;
  state.lastResult = null;
  renderAll(state);
  ProgressDialog.setActions({});
  ProgressDialog.show('NWC Export', '선택한 3D View를 추출할 준비를 하는 중입니다.');
  post(`nwcexport:run-${targetKind}`, buildRunPayload(state));
}

function buildRunPayload(state) {
  const fastNameMode = isFastNameMode(state);
  const viewNames = fastNameMode ? parseViewNames(state.viewNamesText) : [];
  const selections = [];
  state.catalogs.forEach((catalog) => catalog.views.forEach((view) => {
    if (!state.selectedViews.has(viewKey(catalog, view))) return;
    selections.push({
      sourceKey: catalog.sourceKey,
      sourcePath: catalog.path,
      viewId: String(view.id),
      viewName: view.name
    });
  }));
  const linkSelections = state.catalogs.map((catalog) => ({
    sourceKey: catalog.sourceKey,
    sourcePath: catalog.path,
    exportLinks: isCatalogLinksIncluded(state, catalog),
    linkTypeIds: catalog.links
      .filter((link) => state.selectedLinks.has(linkKey(catalog, link)))
      .map((link) => String(link.id))
  }));
  return {
    targetPaths: state.targetPaths,
    viewSelectionMode: fastNameMode ? 'names' : 'catalog',
    viewNames,
    nameModeExportLinks: fastNameMode ? state.nameModeExportLinks : true,
    selections,
    linkSelections,
    outputFolder: state.outputFolder,
    settings: {
      ...state.settings,
      createEmptyGeometryMarker: state.settings.createEmptyGeometryMarker
    }
  };
}

function canRun(state, targetKind) {
  if (state.busy || state.outputFolderPickerPending || state.settingsFile?.pendingAction || !state.exporterAvailable || !state.outputFolder || !hasViewSelection(state)) return false;
  if (targetKind === 'active') return state.sourceKind === 'active' && state.activeDocument.canUse && state.catalogs.length > 0;
  if (isFastNameMode(state)) return state.targetPaths.length > 0;
  return state.sourceKind === 'batch' && state.targetPaths.length > 0 && state.catalogs.length > 0;
}

function parseViewNames(value) {
  const names = [];
  const seen = new Set();
  String(value || '').split(/[\r\n,]+/).forEach((raw) => {
    const name = raw.trim();
    const key = name.toLocaleLowerCase();
    if (!name || seen.has(key)) return;
    seen.add(key);
    names.push(name);
  });
  return names;
}

function isFastNameMode(state) {
  return state.sourceKind === 'batch' && state.viewSelectionMode === 'names';
}

function targetDocumentCount(state) {
  return isFastNameMode(state) ? state.targetPaths.length : state.catalogs.length;
}

function selectedViewCount(state) {
  return isFastNameMode(state) ? parseViewNames(state.viewNamesText).length : state.selectedViews.size;
}

function hasReadyTarget(state) {
  if (isFastNameMode(state)) return state.targetPaths.length > 0;
  return state.catalogs.length > 0;
}

function hasViewSelection(state) {
  return selectedViewCount(state) > 0;
}

function appendTargetPaths(state, paths) {
  const seen = new Set(state.targetPaths.map((path) => path.toLowerCase()));
  arrayOf(paths).map(String).filter((path) => /\.rvt$/i.test(path)).forEach((path) => {
    const key = path.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    state.targetPaths.push(path);
  });
}

function samePathLists(left, right) {
  return left.length === right.length && left.every((path, index) => samePath(path, right[index]));
}

function normalizeCatalog(raw) {
  const scanOk = pick(raw, 'scanOk', 'ScanOk');
  return {
    sourceKey: String(pick(raw, 'sourceKey', 'SourceKey') || ''),
    path: String(pick(raw, 'path', 'Path') || ''),
    fileName: String(pick(raw, 'fileName', 'FileName') || ''),
    title: String(pick(raw, 'title', 'Title') || ''),
    scanOk: scanOk !== false,
    message: String(pick(raw, 'message', 'Message') || ''),
    linkCount: Number(pick(raw, 'linkCount', 'LinkCount')) || 0,
    links: arrayOf(pick(raw, 'links', 'Links')).map((link) => ({
      id: String(pick(link, 'id', 'Id') || ''),
      name: String(pick(link, 'name', 'Name') || ''),
      path: String(pick(link, 'path', 'Path') || ''),
      isLoaded: !!pick(link, 'isLoaded', 'IsLoaded')
    })).filter((link) => link.id),
    views: arrayOf(pick(raw, 'views', 'Views')).map((view) => ({
      id: String(pick(view, 'id', 'Id') || ''),
      name: String(pick(view, 'name', 'Name') || ''),
      isPerspective: !!pick(view, 'isPerspective', 'IsPerspective')
    })).filter((view) => view.id && view.name)
  };
}

function reconcileCatalogs(targetKind, catalogs, targetPaths) {
  if (targetKind !== 'batch') return catalogs;

  const remaining = [...catalogs];
  const ordered = arrayOf(targetPaths).map(String).filter(Boolean).map((pathText) => {
    const matchIndex = remaining.findIndex((catalog) => samePath(catalog.path, pathText)
      || samePath(catalog.sourceKey, pathText));
    if (matchIndex >= 0) return remaining.splice(matchIndex, 1)[0];
    return {
      sourceKey: pathText,
      path: pathText,
      fileName: fileName(pathText),
      title: fileName(pathText),
      scanOk: false,
      message: '이 RVT의 링크 및 3D View 조회 응답을 받지 못했습니다.',
      linkCount: 0,
      links: [],
      views: []
    };
  });
  return [...ordered, ...remaining];
}

function getQuickViewEntries(state) {
  const entries = [];
  state.catalogs.forEach((catalog) => {
    const documentName = catalog.fileName || catalog.title || '이름 없는 RVT';
    const documentPath = catalog.path || documentName;
    catalog.views.forEach((view) => {
      entries.push({
        catalog,
        view,
        key: viewKey(catalog, view),
        documentKey: catalogKey(catalog),
        documentName,
        documentPath,
        parentFolder: parentFolderName(documentPath)
      });
    });
  });
  return entries;
}

function getQuickViewNameGroups(state) {
  const byName = new Map();
  getQuickViewEntries(state).forEach((entry) => {
    const normalizedName = normalizeText(entry.view.name);
    if (!normalizedName) return;
    if (!byName.has(normalizedName)) {
      byName.set(normalizedName, {
        name: entry.view.name,
        normalizedName,
        entries: []
      });
    }
    byName.get(normalizedName).entries.push(entry);
  });
  return [...byName.values()].map((group) => {
    group.entries.sort((left, right) => compareNaturalText(left.documentName, right.documentName));
    group.documentCount = new Set(group.entries.map((entry) => entry.documentKey)).size;
    group.totalDocuments = state.catalogs.length;
    return group;
  });
}

function getQuickViewSearchGroups(state, query) {
  const normalizedQuery = normalizeText(query);
  return getQuickViewNameGroups(state)
    .filter((group) => group.normalizedName.includes(normalizedQuery))
    .map((group) => ({
      ...group,
      isExact: group.normalizedName === normalizedQuery
    }))
    .sort((left, right) => {
      if (left.isExact !== right.isExact) return left.isExact ? -1 : 1;
      return compareNaturalText(left.name, right.name);
    });
}

function getQuickViewCommonGroups(state) {
  const minimumDocuments = state.catalogs.length > 1 ? 2 : 1;
  return getQuickViewNameGroups(state)
    .filter((group) => group.documentCount >= minimumDocuments)
    .sort((left, right) => {
      if (left.documentCount !== right.documentCount) return right.documentCount - left.documentCount;
      return compareNaturalText(left.name, right.name);
    })
    .slice(0, 24);
}

function compareNaturalText(left, right) {
  return String(left || '').localeCompare(String(right || ''), 'ko', {
    numeric: true,
    sensitivity: 'base'
  });
}

function parentFolderName(path) {
  const parts = String(path || '').split(/[\\/]/).filter(Boolean);
  return parts.length > 1 ? parts[parts.length - 2] : '';
}

function getCatalogVisibleViews(state, catalog) {
  const query = normalizeText(state.viewQuery);
  return catalog.views.filter((view) => !query || normalizeText(view.name).includes(query));
}

function countCatalogViews(state, catalog) {
  return catalog.views.reduce((count, view) => count + (state.selectedViews.has(viewKey(catalog, view)) ? 1 : 0), 0);
}

function getActiveViewCatalog(state) {
  const active = state.catalogs.find((catalog) => catalogKey(catalog) === state.activeViewCatalogKey);
  if (active) return active;
  const fallback = state.catalogs[0] || null;
  state.activeViewCatalogKey = fallback ? catalogKey(fallback) : '';
  return fallback;
}

function pruneSelectedViews(state) {
  const valid = new Set();
  state.catalogs.forEach((catalog) => catalog.views.forEach((view) => valid.add(viewKey(catalog, view))));
  [...state.selectedViews].forEach((key) => {
    if (!valid.has(key)) state.selectedViews.delete(key);
  });
}

function pruneSelectedLinks(state) {
  const valid = new Set();
  state.catalogs.forEach((catalog) => catalog.links.forEach((link) => valid.add(linkKey(catalog, link))));
  [...state.selectedLinks].forEach((key) => {
    if (!valid.has(key)) state.selectedLinks.delete(key);
  });
}

function countSelectedLinks(state) {
  let count = 0;
  state.catalogs.filter((catalog) => isCatalogLinksIncluded(state, catalog)).forEach((catalog) => catalog.links.forEach((link) => {
    if (state.selectedLinks.has(linkKey(catalog, link))) count += 1;
  }));
  return count;
}

function countCatalogLinks(state, catalog) {
  return catalog.links.reduce((count, link) => count + (state.selectedLinks.has(linkKey(catalog, link)) ? 1 : 0), 0);
}

function getActiveLinkCatalog(state) {
  const active = state.catalogs.find((catalog) => catalogKey(catalog) === state.activeLinkCatalogKey);
  if (active) return active;
  const fallback = state.catalogs[0] || null;
  state.activeLinkCatalogKey = fallback ? catalogKey(fallback) : '';
  return fallback;
}

function catalogKey(catalog) {
  return String(catalog?.sourceKey || catalog?.path || 'active').trim().toLowerCase();
}

function isCatalogLinksIncluded(state, catalog) {
  return !state.excludedLinkDocuments.has(catalogKey(catalog));
}

function viewKey(catalog, view) {
  return `${catalog.sourceKey || catalog.path || 'active'}::${view.id}`;
}

function linkKey(catalog, link) {
  return `${catalog.sourceKey || catalog.path || 'active'}::link::${link.id}`;
}

function samePath(left, right) {
  return String(left || '').trim().toLowerCase() === String(right || '').trim().toLowerCase();
}

function goToStep(state, step) {
  const next = Math.max(1, Math.min(3, Number(step) || 1));
  if (next > 1 && !hasReadyTarget(state)) {
    toast('먼저 활성 문서 또는 대상 RVT를 불러와 주세요.', 'info');
    return;
  }
  if (next > 2 && !hasViewSelection(state)) {
    toast(
      isFastNameMode(state)
        ? '추출할 3D View 이름을 하나 이상 입력해 주세요.'
        : '추출할 3D View를 하나 이상 선택해 주세요.',
      'info'
    );
    return;
  }
  state.currentStep = next;
  renderAll(state);
  if (state.ui.page) state.ui.page.scrollTop = 0;
}

function stepTitle(step) {
  if (step === 1) return '대상 및 링크';
  if (step === 2) return '3D View';
  return '저장 및 Export';
}

function sourceChoice(title, description, selected, onClick) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = `nwcexport-source-choice ${selected ? 'is-selected' : ''}`;
  button.setAttribute('aria-pressed', String(selected));
  button.innerHTML = `<span>${selected ? '선택됨' : '선택'}</span><strong>${escapeHtml(title)}</strong><small>${escapeHtml(description)}</small>`;
  button.addEventListener('click', onClick);
  return button;
}

function buildFileNameExample(state) {
  let selectedCatalog = null;
  let selectedView = null;
  state.catalogs.some((catalog) => catalog.views.some((view) => {
    if (!state.selectedViews.has(viewKey(catalog, view))) return false;
    selectedCatalog = catalog;
    selectedView = view;
    return true;
  }));
  selectedCatalog ||= state.catalogs[0] || null;
  selectedView ||= selectedCatalog?.views?.[0] || null;
  const firstTarget = state.targetPaths[0] || '';
  const rvt = fileName(selectedCatalog?.fileName || selectedCatalog?.title || firstTarget || 'Project').replace(/\.rvt$/i, '') || 'Project';
  const view = selectedView?.name || parseViewNames(state.viewNamesText)[0] || '3D View';
  return String(state.settings.fileNamePattern || '{RVT}_{View}')
    .replace(/\{RVT\}/gi, rvt)
    .replace(/\{View\}/gi, view)
    .replace(/\{Index\}/gi, '001')
    .replace(/[<>:"/\\|?*]/g, '_') + '.nwc';
}

function createCard(title, subtitle) {
  const card = div('nwcexport-card');
  const head = div('nwcexport-card__head');
  head.innerHTML = `<div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(subtitle || '')}</p></div>`;
  card.append(head);
  return card;
}

function createStepCard(step, title, subtitle) {
  const card = div('nwcexport-card nwcexport-step-card');
  const head = div('nwcexport-card__head nwcexport-step-card__head');
  head.innerHTML = `
    <span class="nwcexport-step-index">${escapeHtml(step)}</span>
    <div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(subtitle || '')}</p></div>`;
  card.append(head);
  return card;
}

function asideCard(kicker, title) {
  const card = div('nwcexport-aside-card');
  card.innerHTML = `<span class="nwcexport-kicker">${escapeHtml(kicker)}</span><h3>${escapeHtml(title)}</h3>`;
  return card;
}

function actionButton(label, onClick, kind = 'secondary') {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = `btn nwcexport-btn nwcexport-btn--${kind}`;
  button.dataset.directKind = kind === 'primary' ? 'primary' : (kind === 'ghost' ? 'muted' : 'secondary');
  button.textContent = label;
  if (typeof onClick === 'function') button.addEventListener('click', onClick);
  return button;
}

function optionRow(label, englishLabel) {
  const row = div('nwcexport-native-option');
  row.dataset.option = englishLabel;
  const copy = div('nwcexport-native-option__copy');
  copy.innerHTML = `<strong>${escapeHtml(label)}</strong><small>(${escapeHtml(englishLabel)})</small>`;
  row.append(copy);
  return row;
}

function optionToggleRow(label, englishLabel, checked, onChange) {
  const row = optionRow(label, englishLabel);
  const control = document.createElement('label');
  control.className = 'nwcexport-native-option__check';
  control.innerHTML = `<input type="checkbox" ${checked ? 'checked' : ''}><span>${checked ? '사용' : '해제'}</span>`;
  control.querySelector('input').addEventListener('change', (event) => {
    const next = !!event.target.checked;
    control.querySelector('span').textContent = next ? '사용' : '해제';
    onChange?.(next);
  });
  row.append(control);
  return row;
}

function optionSelectRow(label, englishLabel, value, options, onChange) {
  const row = optionRow(label, englishLabel);
  const select = document.createElement('select');
  select.className = 'nwcexport-native-option__select';
  select.setAttribute('aria-label', englishLabel);
  options.forEach(([optionValue, optionLabel]) => {
    const option = document.createElement('option');
    option.value = optionValue;
    option.textContent = optionLabel;
    option.selected = optionValue === value;
    select.append(option);
  });
  select.addEventListener('change', (event) => onChange?.(event.target.value));
  row.append(select);
  return row;
}

function optionNumberRow(label, englishLabel, value, onChange, min, max, step) {
  const row = optionRow(label, englishLabel);
  const input = document.createElement('input');
  input.className = 'nwcexport-native-option__number';
  input.type = 'number';
  input.min = String(min);
  input.max = String(max);
  input.step = String(step);
  input.value = String(Number.isFinite(Number(value)) ? Number(value) : 1);
  input.setAttribute('aria-label', englishLabel);
  input.addEventListener('change', (event) => {
    const next = Math.max(min, Math.min(max, Number(event.target.value) || 1));
    event.target.value = String(next);
    onChange?.(next);
  });
  row.append(input);
  return row;
}

function optionReadOnlyRow(label, englishLabel, value) {
  const row = optionRow(label, englishLabel);
  const status = document.createElement('span');
  status.className = 'nwcexport-native-option__readonly';
  status.textContent = value;
  row.append(status);
  return row;
}

function toggleLine(label, englishLabel, checked, onChange) {
  const line = document.createElement('label');
  line.className = 'nwcexport-toggle';
  line.innerHTML = `<input type="checkbox" ${checked ? 'checked' : ''}><span class="nwcexport-toggle__copy"><strong>${escapeHtml(label)}</strong><small>(${escapeHtml(englishLabel)})</small></span>`;
  line.querySelector('input').addEventListener('change', (event) => onChange?.(!!event.target.checked));
  return line;
}

function textField(label, value, onChange, placeholder = '') {
  const field = div('nwcexport-field');
  field.innerHTML = `<label>${escapeHtml(label)}</label><input type="text" value="${escapeHtml(value)}" placeholder="${escapeHtml(placeholder)}">`;
  field.querySelector('input').addEventListener('input', (event) => onChange?.(event.target.value));
  return field;
}

function numberField(label, value, onChange, min, max, step) {
  const field = div('nwcexport-field');
  const numericValue = Number(value);
  const safeValue = Number.isFinite(numericValue) ? numericValue : 1;
  field.innerHTML = `<label>${escapeHtml(label)}</label><input type="number" min="${min}" max="${max}" step="${step}" value="${safeValue}">`;
  field.querySelector('input').addEventListener('change', (event) => {
    const next = Math.max(min, Math.min(max, Number(event.target.value) || 1));
    event.target.value = String(next);
    onChange?.(next);
  });
  return field;
}

function selectField(label, value, options, onChange) {
  const field = div('nwcexport-field');
  const select = document.createElement('select');
  options.forEach(([optionValue, optionLabel]) => {
    const option = document.createElement('option');
    option.value = optionValue;
    option.textContent = optionLabel;
    option.selected = optionValue === value;
    select.append(option);
  });
  select.addEventListener('change', (event) => onChange?.(event.target.value));
  const labelNode = document.createElement('label');
  labelNode.textContent = label;
  field.append(labelNode, select);
  return field;
}

function readinessRow(label, ready, detail = '') {
  const row = div(`nwcexport-ready ${ready ? 'is-ready' : ''}`);
  row.innerHTML = `<span>${escapeHtml(label)}</span><strong>${ready ? escapeHtml(detail || '준비됨') : '필요'}</strong>`;
  return row;
}

function emptyState(message) {
  const node = div('nwcexport-empty');
  node.textContent = message;
  return node;
}

function stat(label, value) {
  const node = document.createElement('span');
  node.innerHTML = `${escapeHtml(label)} <strong>${Number(value) || 0}</strong>`;
  return node;
}

function statusLabel(value) {
  const status = String(value || '').toLowerCase();
  if (status === 'exported') return '정상';
  if (status === 'skipped') return '건너뜀';
  if (status === 'warning') return '경고';
  if (status === 'link-failed') return '링크 오류';
  if (status === 'failed') return '오류';
  return value || '-';
}

function resultDetailText(row) {
  const status = String(row?.status || '').toLowerCase();
  const message = String(row?.message || '').trim();
  const outputPath = String(row?.outputPath || '').trim();
  if (['skipped', 'warning', 'link-failed', 'failed'].includes(status) && message) {
    return outputPath ? `${message} (${outputPath})` : message;
  }
  if (status === 'exported' && message.includes('객체 없음 표시 TXT 정리 실패')) {
    return outputPath ? `${message} (${outputPath})` : message;
  }
  return outputPath || message || statusLabel(status);
}

function fileName(path) {
  return String(path || '').split(/[\\/]/).pop() || '';
}

function normalizeText(value) {
  return String(value || '').trim().toLowerCase();
}

function pick(object, ...keys) {
  if (!object) return undefined;
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(object, key)) return object[key];
  }
  return undefined;
}

function arrayOf(value) {
  return Array.isArray(value) ? value : [];
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
