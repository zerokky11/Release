import {
  clear,
  div,
  toast,
  chooseExcelMode,
  getLastExcelExportLocale,
  showExcelSavedDialog
} from '../core/dom.js?v=20260731parameterexport1';
import { onHost, post } from '../core/bridge.js';

const SETTINGS_KEY = 'kky.nwccompare.settings.v1';
const PRESETS_KEY = 'kky.nwccompare.presets.v1';
const DEFAULT_DIMENSIONS = Object.freeze([
  { id: 'custom-building', label: '동', type: 'custom', rules: '' },
  { id: 'custom-discipline', label: '공종', type: 'custom', rules: '' },
  { id: 'file', label: '파일', type: 'file', rules: '' }
]);

let activeCleanup = null;

export function renderNwcCompare(root) {
  activeCleanup?.();

  const target = root || document.getElementById('view-root') || document.getElementById('app');
  clear(target);

  const settings = loadSettings();
  const state = {
    settings,
    presets: loadPresets(),
    result: null,
    rows: [],
    busy: false,
    progress: null,
    statusFilter: 'all',
    groupFilters: {},
    manualGroupsByContext: cloneManualGroupContexts(settings.manualGroupsByContext),
    manualGroupContextKey: '',
    manualGroups: {},
    ui: {}
  };
  loadManualGroupContext(state);

  const page = div('feature-shell nwccompare-page');
  const workspace = div('nwccompare-workspace');
  const runPanel = div('nwccompare-run-panel');
  page.append(workspace, runPanel);
  target.append(page);
  state.ui = { page, workspace, runPanel };

  let sharedSettingsTimer = 0;
  const applySharedSettings = () => {
    window.clearTimeout(sharedSettingsTimer);
    if (!page.isConnected) return;
    const active = document.activeElement;
    const editing = !!active && page.contains(active) && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName || '');
    if (state.busy || editing) {
      sharedSettingsTimer = window.setTimeout(applySharedSettings, 400);
      return;
    }
    state.settings = loadSettings();
    state.presets = loadPresets();
    state.manualGroupsByContext = cloneManualGroupContexts(state.settings.manualGroupsByContext);
    loadManualGroupContext(state);
    const dimensionIds = new Set(state.settings.dimensions.map((item) => item.id));
    state.groupFilters = Object.fromEntries(
      Object.entries(state.groupFilters || {}).filter(([key]) => dimensionIds.has(key))
    );
    renderAll(state, true);
  };
  const onSharedSettingsChanged = (event) => {
    const keys = Array.isArray(event?.detail?.keys) ? event.detail.keys : [];
    if (!keys.includes(SETTINGS_KEY) && !keys.includes(PRESETS_KEY)) return;
    applySharedSettings();
  };
  const cleanup = () => {
    window.clearTimeout(sharedSettingsTimer);
    window.removeEventListener('hashchange', cleanupOnRouteChange);
    window.removeEventListener('kky:shared-settings-changed', onSharedSettingsChanged);
    if (activeCleanup === cleanup) activeCleanup = null;
  };
  const cleanupOnRouteChange = () => {
    const route = String(location.hash || '').replace(/^#/, '').split('?')[0].toLowerCase();
    if (route !== 'nwccompare') cleanup();
  };
  activeCleanup = cleanup;
  window.addEventListener('hashchange', cleanupOnRouteChange);
  window.addEventListener('kky:shared-settings-changed', onSharedSettingsChanged);

  registerHostEvents(state);
  renderAll(state);
}

function registerHostEvents(state) {
  onHost('nwccompare:baseline-folder-picked', (payload) => {
    switchComparisonContext(state, 'baselineFolder', String(pick(payload, 'path', 'Path') || ''));
    renderAll(state, true);
  });

  onHost('nwccompare:current-folder-picked', (payload) => {
    switchComparisonContext(state, 'currentFolder', String(pick(payload, 'path', 'Path') || ''));
    renderAll(state, true);
  });

  onHost('nwccompare:done', (payload) => {
    state.busy = false;
    state.progress = null;
    const result = pick(payload, 'result', 'Result') || {};
    if (pick(payload, 'ok', 'Ok') === false || pick(result, 'ok', 'Ok') === false) {
      toast(String(pick(payload, 'message', 'Message') || pick(result, 'message', 'Message') || 'NWC/TXT 비교에 실패했습니다.'), 'error');
      renderAll(state, true);
      return;
    }
    state.result = normalizeResult(result);
    state.rows = state.result.rows;
    pruneManualGroups(state);
    toast(state.result.message || `NWC/TXT 모델 ${state.rows.length}개를 비교했습니다.`, 'ok');
    renderAll(state, true);
  });

  onHost('nwccompare:error', (payload) => {
    state.busy = false;
    state.progress = null;
    toast(String(pick(payload, 'message', 'Message') || 'NWC/TXT 비교 처리 중 오류가 발생했습니다.'), 'error');
    renderAll(state, true);
  });

  onHost('nwccompare:progress', (payload) => {
    if (!state.busy) return;
    state.progress = {
      phase: String(pick(payload, 'phase', 'Phase') || ''),
      completed: Math.max(0, Number(pick(payload, 'completed', 'Completed')) || 0),
      total: Math.max(0, Number(pick(payload, 'total', 'Total')) || 0),
      percent: Math.max(0, Math.min(100, Number(pick(payload, 'percent', 'Percent')) || 0)),
      message: String(pick(payload, 'message', 'Message') || 'NWC/TXT를 비교하는 중입니다.')
    };
    renderRunPanel(state);
  });

  onHost('nwccompare:cancelled', (payload) => {
    state.busy = false;
    state.progress = null;
    toast(String(pick(payload, 'message', 'Message') || 'NWC/TXT 비교를 중지했습니다.'), 'warn');
    renderAll(state, true);
  });

  onHost('nwccompare:excel-exported', (payload) => {
    if (pick(payload, 'cancelled', 'Cancelled')) return;
    if (pick(payload, 'ok', 'Ok') === false) {
      toast(String(pick(payload, 'message', 'Message') || 'Excel 저장에 실패했습니다.'), 'error');
      return;
    }
    const path = String(pick(payload, 'path', 'Path') || '');
    showExcelSavedDialog(
      'NWC 비교 결과 Excel을 저장했습니다.',
      path,
      (filePath) => post('excel:open', { path: filePath })
    );
  });

  onHost('nwccompare:classification-template-exported', (payload) => {
    if (pick(payload, 'cancelled', 'Cancelled')) return;
    if (pick(payload, 'ok', 'Ok') === false) {
      toast(String(pick(payload, 'message', 'Message') || '분류표 Excel 저장에 실패했습니다.'), 'error');
      return;
    }
    const path = String(pick(payload, 'path', 'Path') || '');
    showExcelSavedDialog(
      '파일명 기준 분류표 Excel을 저장했습니다.',
      path,
      (filePath) => post('excel:open', { path: filePath })
    );
  });

  onHost('nwccompare:classification-imported', (payload) => {
    if (pick(payload, 'cancelled', 'Cancelled')) return;
    if (pick(payload, 'ok', 'Ok') === false) {
      toast(String(pick(payload, 'message', 'Message') || '분류표 Excel을 불러오지 못했습니다.'), 'error');
      return;
    }
    arrayOf(pick(payload, 'records', 'Records')).forEach((record) => {
      const fileKey = normalizeLogicalKey(pick(record, 'fileName', 'FileName'));
      if (!fileKey) return;
      const nextValues = { ...(state.manualGroups[fileKey] || {}) };
      arrayOf(pick(record, 'values', 'Values')).forEach((item) => {
        const id = String(pick(item, 'id', 'Id') || '').trim();
        if (!id || id === 'file') return;
        const value = String(pick(item, 'value', 'Value') || '').trim();
        if (value) nextValues[id] = value;
        else delete nextValues[id];
      });
      if (Object.keys(nextValues).length) state.manualGroups[fileKey] = nextValues;
      else delete state.manualGroups[fileKey];
    });
    persistSettings(state);
    renderAll(state, true);
    toast(String(pick(payload, 'message', 'Message') || '분류값을 파일명으로 연결했습니다.'), 'ok');
  });
}

function renderAll(state, preserveScroll = false) {
  const scroll = preserveScroll ? captureScroll(state.ui.workspace) : null;
  renderWorkspace(state);
  setWorkspaceBusy(state, state.busy);
  renderRunPanel(state);
  if (scroll) restoreScroll(scroll);
}

function renderWorkspace(state) {
  const root = state.ui.workspace;
  clear(root);

  const intro = div('nwccompare-intro');
  intro.innerHTML = `
    <div>
      <span class="nwccompare-eyebrow">NWC COMPARE</span>
      <h2>NWC 용량 비교 검토</h2>
      <p>같은 파일명 본체를 가진 NWC와 객체 없음 TXT를 한 모델로 비교하고 누락, 신규, 객체 없음, 용량 변화를 찾습니다.</p>
    </div>
    <span class="nwccompare-intro__count">${state.rows.length ? `${state.rows.length}개 결과` : '비교 전'}</span>`;

  const source = buildSourceSection(state);
  const dimensions = buildDimensionSection(state);
  const results = buildResultSection(state);
  root.append(intro, source, dimensions, results);
}

function buildSourceSection(state) {
  const section = div('nwccompare-section');
  section.innerHTML = `
    <div class="nwccompare-section__head">
      <div><span class="nwccompare-step">1</span><div><h3>비교 폴더와 판정 기준</h3><p>기본은 확장자를 제외한 파일명으로, 하위 폴더 포함 시에는 상대경로까지 같은 NWC와 TXT를 하나의 모델로 비교합니다.</p></div></div>
    </div>
    <div class="nwccompare-folder-grid">
      <label class="nwccompare-field"><span>기준 NWC/TXT 폴더</span><div><input data-field="baselineFolder" value="${escapeAttr(state.settings.baselineFolder)}" placeholder="이전 주기 결과 폴더"><button type="button" data-action="pick-baseline">찾아보기</button></div></label>
      <label class="nwccompare-field"><span>현재 NWC/TXT 폴더</span><div><input data-field="currentFolder" value="${escapeAttr(state.settings.currentFolder)}" placeholder="이번 주기 결과 폴더"><button type="button" data-action="pick-current">찾아보기</button></div></label>
    </div>
    <div class="nwccompare-option-grid">
      <label class="nwccompare-field nwccompare-field--number"><span>검토 필요 기준 (%)</span><input type="number" min="0" step="0.1" data-field="thresholdPercent" value="${escapeAttr(state.settings.thresholdPercent)}"></label>
      <label class="nwccompare-check"><input type="checkbox" data-field="includeSubfolders" ${state.settings.includeSubfolders ? 'checked' : ''}><span><strong>하위 폴더 포함</strong><small>모든 NWC/TXT를 찾고 상대 폴더 경로까지 파일 식별에 사용합니다.</small></span></label>
      <label class="nwccompare-check"><input type="checkbox" data-field="verifyEqualSizeHash" ${state.settings.verifyEqualSizeHash ? 'checked' : ''}><span><strong>같은 용량도 SHA-256 확인</strong><small>용량이 같아도 내용이 바뀐 파일을 검토 대상으로 찾습니다.</small></span></label>
    </div>`;

  bindSettingsFields(section, state);
  section.querySelector('[data-action="pick-baseline"]')?.addEventListener('click', () => post('nwccompare:pick-baseline-folder', { currentPath: state.settings.baselineFolder }));
  section.querySelector('[data-action="pick-current"]')?.addEventListener('click', () => post('nwccompare:pick-current-folder', { currentPath: state.settings.currentFolder }));
  return section;
}

function buildDimensionSection(state) {
  const section = div('nwccompare-section');
  const presetOptions = state.presets.map((preset, index) => `<option value="${index}" ${preset.name === state.settings.activePresetName ? 'selected' : ''}>${escapeHtml(preset.name)}</option>`).join('');
  section.innerHTML = `
    <div class="nwccompare-section__head">
      <div><span class="nwccompare-step">2</span><div><h3>사용자 정의 분류</h3><p>필요한 분류 축을 직접 추가하고 이름, 파일명 규칙, 표시 순서를 정합니다.</p></div></div>
      <button type="button" class="nwccompare-button" data-action="add-dimension">분류 축 추가</button>
    </div>
    <div class="nwccompare-rule-note"><strong>규칙 형식</strong><span><b>동/공종은 예시</b>이며 축을 자유롭게 추가, 삭제, 변경할 수 있습니다. <code>분류값=키워드1|키워드2</code>를 세미콜론 또는 줄바꿈으로 구분합니다. 일치 규칙이 없으면 빈칸으로 두고 직접 입력하거나 Excel로 채울 수 있습니다.</span></div>
    <div class="nwccompare-dimension-list" data-dimension-list></div>
    <div class="nwccompare-preset-bar">
      <label><span>분류 구성 프리셋</span><select data-preset-select><option value="">선택</option>${presetOptions}</select></label>
      <input data-preset-name placeholder="새 프리셋 이름">
      <button type="button" class="nwccompare-button" data-action="load-preset">불러오기</button>
      <button type="button" class="nwccompare-button" data-action="save-preset">저장</button>
      <button type="button" class="nwccompare-button nwccompare-button--danger" data-action="delete-preset">삭제</button>
    </div>
    <div class="nwccompare-classification-excel">
      <div><strong>파일별 분류값 Excel</strong><span>현재 모델명을 행으로 내보낸 뒤 빈 분류값을 채워 다시 가져옵니다. .nwc/.txt 확장자는 무시하며, 하위 폴더 포함 시 상대경로까지 일치해야 합니다.</span></div>
      <div>
        <button type="button" class="nwccompare-button" data-action="export-classification" ${state.rows.length ? '' : 'disabled'}>분류표 Excel 내보내기</button>
        <button type="button" class="nwccompare-button" data-action="import-classification" ${state.rows.length ? '' : 'disabled'}>분류표 Excel 가져오기</button>
      </div>
    </div>`;

  const list = section.querySelector('[data-dimension-list]');
  state.settings.dimensions.forEach((dimension, index) => list.append(buildDimensionRow(state, dimension, index)));

  section.querySelector('[data-action="add-dimension"]')?.addEventListener('click', () => {
    state.settings.dimensions.push({
      id: createDimensionId(),
      label: `분류 ${state.settings.dimensions.filter((item) => item.type === 'custom').length + 1}`,
      type: 'custom',
      rules: ''
    });
    persistSettings(state);
    renderAll(state, true);
  });
  section.querySelector('[data-action="load-preset"]')?.addEventListener('click', () => loadSelectedPreset(section, state));
  section.querySelector('[data-action="save-preset"]')?.addEventListener('click', () => savePreset(section, state));
  section.querySelector('[data-action="delete-preset"]')?.addEventListener('click', () => deleteSelectedPreset(section, state));
  section.querySelector('[data-action="export-classification"]')?.addEventListener('click', () => exportClassificationTemplate(state));
  section.querySelector('[data-action="import-classification"]')?.addEventListener('click', () => importClassification(state));
  return section;
}

function buildDimensionRow(state, dimension, index) {
  const isFile = dimension.type === 'file' || dimension.id === 'file';
  const row = div(`nwccompare-dimension-row${isFile ? ' is-file' : ''}`);
  row.dataset.dimensionId = dimension.id;
  row.innerHTML = `
    <span class="nwccompare-dimension-order">${index + 1}</span>
    <label><span>헤더 이름</span><input data-role="label" value="${escapeAttr(dimension.label)}" aria-label="분류 헤더 이름"></label>
    <label class="nwccompare-dimension-rules"><span>${isFile ? '값 생성 방식' : '파일명 판정 규칙'}</span><input data-role="rules" value="${escapeAttr(isFile ? 'NWC 파일명 자동' : dimension.rules)}" ${isFile ? 'disabled' : ''} placeholder="예: A동=A동|BLDG-A; B동=B동|BLDG-B"></label>
    <div class="nwccompare-dimension-actions">
      <button type="button" title="위로 이동" aria-label="위로 이동" data-action="up" ${index === 0 ? 'disabled' : ''}>↑</button>
      <button type="button" title="아래로 이동" aria-label="아래로 이동" data-action="down" ${index === state.settings.dimensions.length - 1 ? 'disabled' : ''}>↓</button>
      <button type="button" title="분류 축 삭제" aria-label="분류 축 삭제" data-action="remove" ${isFile ? 'disabled' : ''}>×</button>
    </div>`;

  row.querySelector('[data-role="label"]')?.addEventListener('input', (event) => {
    dimension.label = String(event.target.value || '');
    persistSettings(state);
  });
  row.querySelector('[data-role="rules"]')?.addEventListener('input', (event) => {
    dimension.rules = String(event.target.value || '');
    persistSettings(state);
  });
  row.querySelector('[data-action="up"]')?.addEventListener('click', () => moveDimension(state, index, index - 1));
  row.querySelector('[data-action="down"]')?.addEventListener('click', () => moveDimension(state, index, index + 1));
  row.querySelector('[data-action="remove"]')?.addEventListener('click', () => {
    if (isFile) return;
    state.settings.dimensions.splice(index, 1);
    deleteDimensionOverrides(state, dimension.id);
    persistSettings(state);
    renderAll(state, true);
  });
  return row;
}

function buildResultSection(state) {
  const section = div('nwccompare-section nwccompare-results');
  section.innerHTML = `
    <div class="nwccompare-section__head">
      <div><span class="nwccompare-step">3</span><div><h3>비교 결과</h3><p>현재 분류 순서대로 필터, 그룹 집계, 상세 결과가 구성됩니다.</p></div></div>
    </div>`;

  if (!state.rows.length) {
    const empty = div('nwccompare-empty');
    empty.innerHTML = '<strong>아직 비교 결과가 없습니다.</strong><span>두 폴더와 판정 기준을 확인한 뒤 오른쪽의 비교 실행을 누르세요.</span>';
    section.append(empty);
    return section;
  }

  const summary = buildSummary(state);
  const filters = buildFilters(state);
  const filtered = getFilteredRows(state);
  const grouped = buildGroupSummary(state, filtered);
  const table = buildDetailTable(state, filtered);
  section.append(summary, filters, grouped, table);
  return section;
}

function buildSummary(state) {
  const root = div('nwccompare-summary');
  const counts = getStatusCounts(state.rows);
  const items = [
    ['all', '전체', state.rows.length],
    ['same', '정상', counts.same],
    ['within', '허용 범위', counts.within],
    ['review', '검토 필요', counts.review],
    ['empty', '객체 없음', counts.empty],
    ['new', '신규', counts.new],
    ['missing', '누락', counts.missing],
    ['duplicate', '중복', counts.duplicate]
  ];
  items.forEach(([status, label, count]) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `nwccompare-summary__item status-${status}${state.statusFilter === status ? ' is-active' : ''}`;
    button.innerHTML = `<span>${label}</span><strong>${count}</strong>`;
    button.addEventListener('click', () => {
      state.statusFilter = status;
      renderAll(state, true);
    });
    root.append(button);
  });
  return root;
}

function buildFilters(state) {
  const root = div('nwccompare-filters');
  const heading = document.createElement('strong');
  heading.textContent = '순서별 필터';
  root.append(heading);

  const status = document.createElement('label');
  status.innerHTML = `<span>상태</span><select data-status-filter>
    <option value="all">전체</option><option value="same">정상</option><option value="within">허용 범위</option><option value="review">검토 필요</option><option value="empty">객체 없음</option><option value="new">신규</option><option value="missing">누락</option><option value="duplicate">중복</option>
  </select>`;
  const statusSelect = status.querySelector('select');
  statusSelect.value = state.statusFilter;
  statusSelect.addEventListener('change', () => {
    state.statusFilter = statusSelect.value;
    renderAll(state, true);
  });
  root.append(status);

  state.settings.dimensions.forEach((dimension) => {
    const label = document.createElement('label');
    const title = normalizeDimensionLabel(dimension);
    if (dimension.type === 'file' || dimension.id === 'file') {
      label.innerHTML = `<span>${escapeHtml(title)}</span><input type="search" data-filter-dimension="${escapeAttr(dimension.id)}" value="${escapeAttr(state.groupFilters[dimension.id] || '')}" placeholder="파일명 검색">`;
      label.querySelector('input').addEventListener('input', (event) => {
        const selectionStart = event.target.selectionStart;
        const selectionEnd = event.target.selectionEnd;
        state.groupFilters[dimension.id] = String(event.target.value || '');
        renderResultParts(state, dimension.id, selectionStart, selectionEnd);
      });
    } else {
      const values = getDimensionValues(state, dimension);
      label.innerHTML = `<span>${escapeHtml(title)}</span><select><option value="">전체</option>${values.map((value) => `<option value="${escapeAttr(value)}">${escapeHtml(value)}</option>`).join('')}</select>`;
      const select = label.querySelector('select');
      select.value = state.groupFilters[dimension.id] || '';
      select.addEventListener('change', () => {
        state.groupFilters[dimension.id] = select.value;
        renderAll(state, true);
      });
    }
    root.append(label);
  });

  const reset = document.createElement('button');
  reset.type = 'button';
  reset.className = 'nwccompare-button';
  reset.textContent = '필터 초기화';
  reset.addEventListener('click', () => {
    state.statusFilter = 'all';
    state.groupFilters = {};
    renderAll(state, true);
  });
  root.append(reset);
  return root;
}

function buildGroupSummary(state, rows) {
  const root = div('nwccompare-group-summary');
  const heading = div('nwccompare-subhead');
  heading.innerHTML = `<strong>그룹 집계</strong><span>${rows.length}개 모델</span>`;
  root.append(heading);

  const groups = new Map();
  rows.forEach((row) => {
    const values = state.settings.dimensions.map((dimension) => getGroupValue(state, row, dimension));
    const key = JSON.stringify(values);
    if (!groups.has(key)) groups.set(key, { values, total: 0, review: 0, empty: 0, newCount: 0, missing: 0 });
    const group = groups.get(key);
    group.total += 1;
    if (row.status === 'review' || row.status === 'duplicate') group.review += 1;
    if (row.status === 'empty') group.empty += 1;
    if (row.status === 'new') group.newCount += 1;
    if (row.status === 'missing') group.missing += 1;
  });

  if (!groups.size) {
    root.append(makeEmpty('현재 필터에 해당하는 그룹이 없습니다.'));
    return root;
  }

  const scroller = div('nwccompare-table-scroll');
  const table = document.createElement('table');
  table.innerHTML = `<thead><tr>${state.settings.dimensions.map((dimension) => `<th>${escapeHtml(normalizeDimensionLabel(dimension))}</th>`).join('')}<th>개수</th><th>검토</th><th>객체 없음</th><th>신규</th><th>누락</th></tr></thead>`;
  const body = document.createElement('tbody');
  Array.from(groups.values()).sort(compareGroupValues).forEach((group) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `${group.values.map((value) => `<td>${escapeHtml(displayGroupValue(value))}</td>`).join('')}<td>${group.total}</td><td>${group.review}</td><td>${group.empty}</td><td>${group.newCount}</td><td>${group.missing}</td>`;
    body.append(tr);
  });
  table.append(body);
  scroller.append(table);
  root.append(scroller);
  return root;
}

function buildDetailTable(state, rows) {
  const root = div('nwccompare-detail');
  const heading = div('nwccompare-subhead');
  heading.innerHTML = `<strong>모델별 상세</strong><span>${rows.length}개 표시</span>`;
  root.append(heading);

  if (!rows.length) {
    root.append(makeEmpty('현재 필터에 해당하는 모델이 없습니다.'));
    return root;
  }

  const scroller = div('nwccompare-table-scroll nwccompare-table-scroll--detail');
  const table = document.createElement('table');
  table.innerHTML = `<thead><tr>${state.settings.dimensions.map((dimension) => `<th>${escapeHtml(normalizeDimensionLabel(dimension))}</th>`).join('')}<th>기준 출력</th><th>현재 출력</th><th>기준 MB</th><th>현재 MB</th><th>증감 MB</th><th>증감률</th><th>상태</th><th>메시지</th></tr></thead>`;
  const body = document.createElement('tbody');

  rows.forEach((row) => {
    const tr = document.createElement('tr');
    state.settings.dimensions.forEach((dimension) => {
      const td = document.createElement('td');
      const value = getGroupValue(state, row, dimension);
      if (dimension.type === 'file' || dimension.id === 'file') {
        td.textContent = value;
      } else {
        const input = document.createElement('input');
        input.className = 'nwccompare-inline-group';
        input.value = value;
        input.title = `${getLogicalFileName(row)}의 ${normalizeDimensionLabel(dimension)} 수동 분류값`;
        input.addEventListener('change', () => {
          setManualGroupValue(state, row, dimension.id, input.value);
          renderAll(state, true);
        });
        td.append(input);
      }
      tr.append(td);
    });
    tr.insertAdjacentHTML('beforeend', `
      <td>${escapeHtml(outputLabel(row.baselineKind))}</td>
      <td>${escapeHtml(outputLabel(row.currentKind))}</td>
      <td>${formatMegabytes(row.baselineSizeBytes)}</td>
      <td>${formatMegabytes(row.currentSizeBytes)}</td>
      <td>${formatMegabytes(row.deltaBytes, true)}</td>
      <td>${formatPercent(row.deltaPercent)}</td>
      <td><span class="nwccompare-status status-${escapeAttr(row.status)}">${escapeHtml(statusLabel(row.status))}</span></td>
      <td class="nwccompare-message">${escapeHtml(row.message)}</td>`);
    body.append(tr);
  });
  table.append(body);
  scroller.append(table);
  root.append(scroller);
  return root;
}

function renderResultParts(state, focusDimensionId = '', selectionStart = null, selectionEnd = null) {
  renderAll(state, true);
  if (!focusDimensionId) return;
  const input = Array.from(state.ui.workspace.querySelectorAll('[data-filter-dimension]'))
    .find((candidate) => candidate.dataset.filterDimension === focusDimensionId);
  if (!input) return;
  input.focus({ preventScroll: true });
  if (Number.isInteger(selectionStart) && Number.isInteger(selectionEnd)) {
    input.setSelectionRange(selectionStart, selectionEnd);
  }
}

function renderRunPanel(state) {
  const root = state.ui.runPanel;
  const hasResult = state.rows.length > 0;
  const foldersReady = !!state.settings.baselineFolder && !!state.settings.currentFolder;
  const progress = state.progress || {};
  const isCancelling = progress.phase === 'cancelling';
  const progressTotal = Math.max(0, Number(progress.total) || 0);
  const progressCompleted = Math.max(0, Number(progress.completed) || 0);
  const progressPercent = progressTotal > 0
    ? Math.max(0, Math.min(100, Number(progress.percent) || 0))
    : 0;
  root.innerHTML = `
    <span class="nwccompare-eyebrow">RUN</span>
    <h2>비교 실행</h2>
    <div class="nwccompare-run-status">
      <div><span>기준 폴더</span><strong class="${state.settings.baselineFolder ? 'is-ready' : ''}">${state.settings.baselineFolder ? '선택됨' : '필요'}</strong></div>
      <div><span>현재 폴더</span><strong class="${state.settings.currentFolder ? 'is-ready' : ''}">${state.settings.currentFolder ? '선택됨' : '필요'}</strong></div>
      <div><span>분류 축</span><strong class="is-ready">${state.settings.dimensions.length}개</strong></div>
      <div><span>검토 기준</span><strong class="is-ready">±${formatNumber(state.settings.thresholdPercent)}%</strong></div>
    </div>
    ${state.busy ? `
      <div class="nwccompare-progress" role="status" aria-live="polite">
        <div class="nwccompare-progress__head">
          <strong>${escapeHtml(progress.message || 'NWC/TXT를 비교하는 중입니다.')}</strong>
          <span>${progressTotal > 0 ? `${progressCompleted}/${progressTotal}` : '준비 중'}</span>
        </div>
        <div class="nwccompare-progress__track"><span style="width:${progressPercent}%"></span></div>
      </div>` : ''}
    <button type="button" class="${state.busy ? 'nwccompare-cancel' : 'nwccompare-primary'}" data-action="compare" ${(!state.busy && !foldersReady) || isCancelling ? 'disabled' : ''}>${state.busy ? (isCancelling ? '중지 중...' : '비교 중지') : 'NWC/TXT 비교 실행'}</button>
    <button type="button" class="nwccompare-secondary" data-action="excel" ${!hasResult || state.busy ? 'disabled' : ''}>결과 Excel 내보내기</button>
    <div class="nwccompare-run-links">
      <button type="button" data-action="open-baseline" ${!state.settings.baselineFolder || state.busy ? 'disabled' : ''}>기준 폴더 열기</button>
      <button type="button" data-action="open-current" ${!state.settings.currentFolder || state.busy ? 'disabled' : ''}>현재 폴더 열기</button>
    </div>
    ${hasResult ? `<div class="nwccompare-run-result"><strong>${state.rows.length}개 모델</strong><span>확인 필요 ${getReviewLikeCount(state.rows)}개</span></div>` : ''}`;

  root.querySelector('[data-action="compare"]')?.addEventListener('click', () => {
    if (state.busy) cancelCompare(state);
    else runCompare(state);
  });
  root.querySelector('[data-action="excel"]')?.addEventListener('click', () => exportExcel(state));
  root.querySelector('[data-action="open-baseline"]')?.addEventListener('click', () => post('nwccompare:open-folder', { path: state.settings.baselineFolder }));
  root.querySelector('[data-action="open-current"]')?.addEventListener('click', () => post('nwccompare:open-folder', { path: state.settings.currentFolder }));
}

function bindSettingsFields(root, state) {
  root.querySelectorAll('[data-field]').forEach((control) => {
    const key = control.dataset.field;
    const isFolderField = key === 'baselineFolder' || key === 'currentFolder';
    const changesComparisonIdentity = isFolderField || key === 'includeSubfolders';
    const eventName = control.type === 'checkbox' || isFolderField ? 'change' : 'input';
    control.addEventListener(eventName, () => {
      if (changesComparisonIdentity) {
        switchComparisonContext(state, key, control.type === 'checkbox' ? control.checked : control.value);
        renderAll(state, true);
        return;
      }
      if (control.type === 'checkbox') state.settings[key] = control.checked;
      else if (control.type === 'number') state.settings[key] = Math.max(0, Number(control.value) || 0);
      else state.settings[key] = control.value;
      persistSettings(state);
      renderRunPanel(state);
    });
  });
}

function runCompare(state) {
  if (!state.settings.baselineFolder || !state.settings.currentFolder) {
    toast('기준 폴더와 현재 폴더를 모두 선택해 주세요.', 'warn');
    return;
  }
  state.busy = true;
  state.progress = {
    phase: 'starting',
    completed: 0,
    total: 0,
    percent: 0,
    message: '비교 작업을 준비하는 중입니다.'
  };
  persistSettings(state);
  renderAll(state, true);
  post('nwccompare:compare', {
    baselineFolder: state.settings.baselineFolder,
    currentFolder: state.settings.currentFolder,
    thresholdPercent: state.settings.thresholdPercent,
    includeSubfolders: state.settings.includeSubfolders,
    verifyEqualSizeHash: state.settings.verifyEqualSizeHash
  });
}

function cancelCompare(state) {
  if (!state.busy || state.progress?.phase === 'cancelling') return;
  state.progress = {
    ...(state.progress || {}),
    phase: 'cancelling',
    message: '진행 중인 비교를 안전하게 중지하는 중입니다.'
  };
  renderRunPanel(state);
  post('nwccompare:cancel', {});
}

function setWorkspaceBusy(state, busy) {
  const workspace = state.ui.workspace;
  if (!workspace) return;
  workspace.classList.toggle('is-busy', !!busy);
  workspace.querySelectorAll('button, input, select, textarea').forEach((control) => {
    control.disabled = !!busy;
  });
}

async function exportExcel(state) {
  if (!state.rows.length) return;
  const choice = await chooseExcelMode();
  if (!choice) return;
  const excelMode = typeof choice === 'object' ? choice.mode : choice;
  const dimensions = state.settings.dimensions.map((dimension) => ({
    id: dimension.id,
    label: normalizeDimensionLabel(dimension)
  }));
  const groups = state.rows.map((row) => ({
    fileName: getLogicalFileName(row),
    values: state.settings.dimensions.map((dimension) => ({
      id: dimension.id,
      value: getGroupValue(state, row, dimension)
    }))
  }));
  post('nwccompare:export-result-excel', {
    excelMode: excelMode || 'fast',
    locale: getLastExcelExportLocale(),
    dimensions,
    groups
  });
}

function exportClassificationTemplate(state) {
  if (!state.rows.length) {
    toast('먼저 NWC/TXT 폴더 비교를 실행해 모델 목록을 만들어 주세요.', 'warn');
    return;
  }
  if (!validateCustomDimensionLabels(state)) return;
  const dimensions = getCustomDimensions(state);
  post('nwccompare:export-classification-template', {
    dimensions,
    groups: state.rows.map((row) => ({
      fileName: getLogicalFileName(row),
      values: dimensions.map((dimension) => ({
        id: dimension.id,
        value: getGroupValue(state, row, dimension)
      }))
    }))
  });
}

function importClassification(state) {
  if (!state.rows.length) {
    toast('먼저 NWC/TXT 폴더 비교를 실행해 모델 목록을 만들어 주세요.', 'warn');
    return;
  }
  if (!validateCustomDimensionLabels(state)) return;
  const dimensions = getCustomDimensions(state);
  post('nwccompare:import-classification', { dimensions });
}

function getCustomDimensions(state) {
  return state.settings.dimensions
    .filter((dimension) => dimension.type !== 'file' && dimension.id !== 'file')
    .map((dimension) => ({ id: dimension.id, label: normalizeDimensionLabel(dimension) }));
}

function validateCustomDimensionLabels(state) {
  const dimensions = state.settings.dimensions
    .filter((dimension) => dimension.type !== 'file' && dimension.id !== 'file');
  if (!dimensions.length) {
    toast('Excel로 관리할 사용자 분류 축을 하나 이상 추가해 주세요.', 'warn');
    return false;
  }

  const labels = dimensions.map((dimension) => String(dimension.label || '').trim());
  if (labels.some((label) => !label)) {
    toast('모든 사용자 분류 축의 헤더 이름을 입력해 주세요.', 'warn');
    return false;
  }

  const seen = new Set();
  const duplicates = new Set();
  labels.forEach((label) => {
    const key = label.toLocaleLowerCase('ko-KR');
    if (seen.has(key)) duplicates.add(label);
    seen.add(key);
  });
  if (duplicates.size) {
    toast(`중복된 분류 헤더 이름을 바꿔 주세요: ${Array.from(duplicates).join(', ')}`, 'warn');
    return false;
  }
  return true;
}

function moveDimension(state, from, to) {
  if (to < 0 || to >= state.settings.dimensions.length || from === to) return;
  const [dimension] = state.settings.dimensions.splice(from, 1);
  state.settings.dimensions.splice(to, 0, dimension);
  persistSettings(state);
  renderAll(state, true);
}

function loadSelectedPreset(section, state) {
  const select = section.querySelector('[data-preset-select]');
  const index = Number(select?.value);
  if (!Number.isInteger(index) || !state.presets[index]) {
    toast('불러올 분류 프리셋을 선택해 주세요.', 'warn');
    return;
  }
  const preset = state.presets[index];
  state.settings.dimensions = normalizeDimensions(preset.dimensions);
  state.settings.activePresetName = preset.name;
  state.groupFilters = {};
  persistSettings(state);
  renderAll(state, true);
  toast(`'${state.presets[index].name}' 분류 프리셋을 불러왔습니다.`, 'ok');
}

function savePreset(section, state) {
  const input = section.querySelector('[data-preset-name]');
  const name = String(input?.value || '').trim();
  if (!name) {
    toast('저장할 분류 프리셋 이름을 입력해 주세요.', 'warn');
    input?.focus();
    return;
  }
  if (!validateCustomDimensionLabels(state)) return;
  const next = {
    name,
    dimensions: cloneDimensions(state.settings.dimensions)
  };
  const existing = state.presets.findIndex((preset) => preset.name.toLowerCase() === name.toLowerCase());
  if (existing >= 0) state.presets.splice(existing, 1, next);
  else state.presets.push(next);
  state.settings.activePresetName = name;
  persistPresets(state.presets);
  persistSettings(state);
  renderAll(state, true);
  toast(`'${name}' 분류 프리셋을 저장했습니다.`, 'ok');
}

function deleteSelectedPreset(section, state) {
  const select = section.querySelector('[data-preset-select]');
  const index = Number(select?.value);
  if (!Number.isInteger(index) || !state.presets[index]) {
    toast('삭제할 분류 프리셋을 선택해 주세요.', 'warn');
    return;
  }
  const [removed] = state.presets.splice(index, 1);
  if (state.settings.activePresetName === removed.name) state.settings.activePresetName = '';
  persistPresets(state.presets);
  persistSettings(state);
  renderAll(state, true);
  toast(`'${removed.name}' 분류 프리셋을 삭제했습니다.`, 'ok');
}

function getFilteredRows(state) {
  const status = state.statusFilter;
  return state.rows.filter((row) => {
    if (status !== 'all' && row.status !== status) return false;
    return state.settings.dimensions.every((dimension) => {
      const filter = String(state.groupFilters[dimension.id] || '').trim();
      if (!filter) return true;
      const value = getGroupValue(state, row, dimension);
      if (dimension.type === 'file' || dimension.id === 'file') {
        return value.toLowerCase().includes(filter.toLowerCase());
      }
      return value === filter;
    });
  });
}

function getDimensionValues(state, dimension) {
  return Array.from(new Set(state.rows.map((row) => getGroupValue(state, row, dimension)).filter(Boolean)))
    .sort((a, b) => a.localeCompare(b, 'ko'));
}

function getGroupValue(state, row, dimension) {
  const logicalName = getLogicalFileName(row);
  if (dimension.type === 'file' || dimension.id === 'file') return logicalName;
  const manual = state.manualGroups?.[normalizeLogicalKey(logicalName)]?.[dimension.id];
  if (String(manual || '').trim()) return String(manual).trim();
  return resolveRuleValue(logicalName, dimension.rules);
}

function resolveRuleValue(fileName, ruleText) {
  const source = stripComparisonExtension(fileName).toLowerCase();
  const rules = String(ruleText || '').split(/;|\r?\n/).map((item) => item.trim()).filter(Boolean);
  const candidates = [];
  rules.forEach((rule, ruleIndex) => {
    const separator = rule.indexOf('=');
    if (separator < 1) return;
    const value = rule.slice(0, separator).trim();
    const tokens = rule.slice(separator + 1).split(/[|,]/).map((item) => item.trim()).filter(Boolean);
    if (!value) return;
    tokens.forEach((token, tokenIndex) => {
      const normalizedToken = token.toLowerCase();
      if (!normalizedToken || !hasRuleTokenBoundaryMatch(source, normalizedToken)) return;
      candidates.push({ value, length: normalizedToken.length, ruleIndex, tokenIndex });
    });
  });
  candidates.sort((a, b) => b.length - a.length || a.ruleIndex - b.ruleIndex || a.tokenIndex - b.tokenIndex);
  return candidates[0]?.value || '';
}

function hasRuleTokenBoundaryMatch(source, token) {
  let start = 0;
  while (start <= source.length - token.length) {
    const index = source.indexOf(token, start);
    if (index < 0) return false;
    const before = index > 0 ? source[index - 1] : '';
    const afterIndex = index + token.length;
    const after = afterIndex < source.length ? source[afterIndex] : '';
    if ((!before || !isRuleWordCharacter(before)) && (!after || !isRuleWordCharacter(after))) return true;
    start = index + Math.max(1, token.length);
  }
  return false;
}

function isRuleWordCharacter(character) {
  return /[0-9A-Za-z가-힣]/.test(character);
}

function setManualGroupValue(state, rowOrFileName, dimensionId, value) {
  const fileName = typeof rowOrFileName === 'object' ? getLogicalFileName(rowOrFileName) : rowOrFileName;
  const fileKey = normalizeLogicalKey(fileName);
  if (!fileKey) return;
  const next = String(value || '').trim();
  if (!state.manualGroups[fileKey]) state.manualGroups[fileKey] = {};
  if (next) state.manualGroups[fileKey][dimensionId] = next;
  else delete state.manualGroups[fileKey][dimensionId];
  if (!Object.keys(state.manualGroups[fileKey]).length) delete state.manualGroups[fileKey];
  persistSettings(state);
}

function deleteDimensionOverrides(state, dimensionId) {
  Object.keys(state.manualGroups).forEach((fileName) => {
    const values = state.manualGroups[fileName];
    if (!values || typeof values !== 'object') return;
    delete values[dimensionId];
    if (!Object.keys(values).length) delete state.manualGroups[fileName];
  });
}

function pruneManualGroups(state) {
  const validDimensions = new Set(state.settings.dimensions
    .filter((dimension) => dimension.type !== 'file' && dimension.id !== 'file')
    .map((dimension) => dimension.id));
  const validFiles = new Set(state.rows.map((row) => normalizeLogicalKey(getLogicalFileName(row))).filter(Boolean));
  const migrated = {};
  Object.entries(state.manualGroups || {}).forEach(([fileName, values]) => {
    const fileKey = normalizeLogicalKey(fileName);
    if (!fileKey || (validFiles.size && !validFiles.has(fileKey)) || !values || typeof values !== 'object') return;
    const next = migrated[fileKey] || {};
    Object.entries(values).forEach(([dimensionId, rawValue]) => {
      const value = String(rawValue || '').trim();
      if (validDimensions.has(dimensionId) && value) next[dimensionId] = value;
    });
    if (Object.keys(next).length) migrated[fileKey] = next;
  });
  state.manualGroups = migrated;
  persistSettings(state);
}

function switchComparisonContext(state, settingKey, value) {
  saveCurrentManualGroups(state);
  state.settings[settingKey] = settingKey === 'includeSubfolders'
    ? !!value
    : String(value || '').trim();
  loadManualGroupContext(state);
  state.result = null;
  state.rows = [];
  state.statusFilter = 'all';
  state.groupFilters = {};
  persistSettings(state);
}

function loadManualGroupContext(state) {
  const contextKey = getComparisonContextKey(state.settings);
  const legacyKey = getComparisonFolderPairKey(state.settings);
  if (contextKey && !state.manualGroupsByContext[contextKey]
      && !state.settings.includeSubfolders && state.manualGroupsByContext[legacyKey]) {
    state.manualGroupsByContext[contextKey] = cloneManualGroups(state.manualGroupsByContext[legacyKey]);
    delete state.manualGroupsByContext[legacyKey];
  }
  state.manualGroupContextKey = contextKey;
  state.manualGroups = cloneManualGroups(contextKey ? state.manualGroupsByContext[contextKey] : null);
}

function saveCurrentManualGroups(state) {
  const contextKey = String(state.manualGroupContextKey || '');
  if (!contextKey) return;
  delete state.manualGroupsByContext[contextKey];
  if (Object.keys(state.manualGroups || {}).length) {
    state.manualGroupsByContext[contextKey] = cloneManualGroups(state.manualGroups);
  }
  const keys = Object.keys(state.manualGroupsByContext);
  keys.slice(0, Math.max(0, keys.length - 20)).forEach((key) => delete state.manualGroupsByContext[key]);
}

function getComparisonContextKey(settings) {
  const folderPair = getComparisonFolderPairKey(settings);
  if (!folderPair) return '';
  const scanMode = settings?.includeSubfolders ? 'recursive' : 'top';
  return `${folderPair}\n${scanMode}`;
}

function getComparisonFolderPairKey(settings) {
  const baseline = normalizeFolderContext(settings?.baselineFolder);
  const current = normalizeFolderContext(settings?.currentFolder);
  return baseline && current ? `${baseline}\n${current}` : '';
}

function normalizeFolderContext(value) {
  return String(value || '')
    .trim()
    .replace(/\\/g, '/')
    .replace(/\/+$/, '')
    .toLocaleLowerCase('en-US');
}

function cloneManualGroupContexts(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const result = {};
  Object.entries(raw).forEach(([contextKey, values]) => {
    const groups = cloneManualGroups(values);
    if (contextKey && Object.keys(groups).length) result[contextKey] = groups;
  });
  return result;
}

function cloneManualGroups(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const result = {};
  Object.entries(raw).forEach(([fileName, values]) => {
    if (!values || typeof values !== 'object' || Array.isArray(values)) return;
    const fileKey = normalizeLogicalKey(fileName);
    if (!fileKey) return;
    const next = {};
    Object.entries(values).forEach(([dimensionId, rawValue]) => {
      const value = String(rawValue || '').trim();
      if (dimensionId && value) next[dimensionId] = value;
    });
    if (Object.keys(next).length) result[fileKey] = next;
  });
  return result;
}

function normalizeResult(raw) {
  const rows = arrayOf(pick(raw, 'rows', 'Rows')).map((row) => {
    const fileName = String(pick(row, 'fileName', 'FileName') || '');
    const logicalName = String(pick(row, 'logicalName', 'LogicalName') || stripComparisonExtension(fileName));
    return {
    fileName,
    logicalName,
    baselineFileName: String(pick(row, 'baselineFileName', 'BaselineFileName') || ''),
    currentFileName: String(pick(row, 'currentFileName', 'CurrentFileName') || ''),
    baselineKind: String(pick(row, 'baselineKind', 'BaselineKind') || '').toLowerCase(),
    currentKind: String(pick(row, 'currentKind', 'CurrentKind') || '').toLowerCase(),
    baselinePath: String(pick(row, 'baselinePath', 'BaselinePath') || ''),
    currentPath: String(pick(row, 'currentPath', 'CurrentPath') || ''),
    baselineSizeBytes: nullableNumber(pick(row, 'baselineSizeBytes', 'BaselineSizeBytes')),
    currentSizeBytes: nullableNumber(pick(row, 'currentSizeBytes', 'CurrentSizeBytes')),
    deltaBytes: Number(pick(row, 'deltaBytes', 'DeltaBytes')) || 0,
    deltaPercent: nullableNumber(pick(row, 'deltaPercent', 'DeltaPercent')),
    status: String(pick(row, 'status', 'Status') || '').toLowerCase(),
    message: String(pick(row, 'message', 'Message') || '')
  };
  });
  return {
    ok: pick(raw, 'ok', 'Ok') !== false,
    message: String(pick(raw, 'message', 'Message') || ''),
    baselineFolder: String(pick(raw, 'baselineFolder', 'BaselineFolder') || ''),
    currentFolder: String(pick(raw, 'currentFolder', 'CurrentFolder') || ''),
    thresholdPercent: Number(pick(raw, 'thresholdPercent', 'ThresholdPercent')) || 0,
    rows
  };
}

function loadSettings() {
  const fallback = {
    baselineFolder: '',
    currentFolder: '',
    thresholdPercent: 5,
    includeSubfolders: false,
    verifyEqualSizeHash: true,
    activePresetName: '',
    dimensions: cloneDimensions(DEFAULT_DIMENSIONS),
    manualGroupsByContext: {}
  };
  try {
    const saved = JSON.parse(localStorage.getItem(SETTINGS_KEY) || 'null');
    if (!saved || typeof saved !== 'object') return fallback;
    const result = {
      ...fallback,
      ...saved,
      thresholdPercent: Math.max(0, Number(saved.thresholdPercent) || 0),
      dimensions: normalizeDimensions(saved.dimensions),
      manualGroupsByContext: cloneManualGroupContexts(saved.manualGroupsByContext)
    };
    delete result.manualGroups;
    return result;
  } catch {
    return fallback;
  }
}

function normalizeDimensions(raw) {
  const source = Array.isArray(raw) ? raw : [];
  const seen = new Set();
  const result = [];
  source.forEach((item) => {
    if (!item || typeof item !== 'object') return;
    const isFile = item.type === 'file' || item.id === 'file';
    let id = isFile ? 'file' : String(item.id || createDimensionId());
    if (seen.has(id)) id = createDimensionId();
    seen.add(id);
    result.push({
      id,
      label: String(item.label || (isFile ? '파일' : '분류')).trim() || (isFile ? '파일' : '분류'),
      type: isFile ? 'file' : 'custom',
      rules: isFile ? '' : String(item.rules || '')
    });
  });
  if (!result.some((item) => item.type === 'file')) result.push({ id: 'file', label: '파일', type: 'file', rules: '' });
  return result.length ? result : cloneDimensions(DEFAULT_DIMENSIONS);
}

function persistSettings(state) {
  state.settings.dimensions = normalizeDimensions(state.settings.dimensions);
  saveCurrentManualGroups(state);
  state.settings.manualGroupsByContext = state.manualGroupsByContext;
  delete state.settings.manualGroups;
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(state.settings));
  } catch {
    // Local storage can be unavailable in locked-down WebView environments.
  }
}

function loadPresets() {
  try {
    const saved = JSON.parse(localStorage.getItem(PRESETS_KEY) || '[]');
    if (!Array.isArray(saved)) return [];
    return saved.map((preset) => ({
      name: String(preset?.name || '').trim(),
      dimensions: normalizeDimensions(preset?.dimensions)
    })).filter((preset) => preset.name);
  } catch {
    return [];
  }
}

function persistPresets(presets) {
  try {
    localStorage.setItem(PRESETS_KEY, JSON.stringify(presets));
  } catch {
    // Keep the current session usable even if persistence is blocked.
  }
}

function cloneDimensions(dimensions) {
  return Array.from(dimensions || []).map((item) => ({ ...item }));
}

function normalizeDimensionLabel(dimension) {
  return String(dimension?.label || (dimension?.type === 'file' ? '파일' : '분류')).trim() || '분류';
}

function createDimensionId() {
  return `custom-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

function getStatusCounts(rows) {
  return rows.reduce((counts, row) => {
    counts[row.status] = (counts[row.status] || 0) + 1;
    return counts;
  }, { same: 0, within: 0, review: 0, empty: 0, new: 0, missing: 0, duplicate: 0 });
}

function getReviewLikeCount(rows) {
  return rows.filter((row) => ['review', 'empty', 'new', 'missing', 'duplicate'].includes(row.status)).length;
}

function statusLabel(status) {
  return ({
    same: '정상',
    within: '허용 범위',
    review: '검토 필요',
    empty: '객체 없음',
    new: '신규',
    missing: '누락',
    duplicate: '중복'
  })[status] || status || '-';
}

function compareGroupValues(a, b) {
  return a.values.join('\u0001').localeCompare(b.values.join('\u0001'), 'ko');
}

function formatMegabytes(bytes, signed = false) {
  if (bytes === null || bytes === undefined || Number.isNaN(Number(bytes))) return '-';
  const value = Number(bytes) / 1048576;
  const text = value.toLocaleString('ko-KR', { minimumFractionDigits: 0, maximumFractionDigits: 3 });
  return signed && value > 0 ? `+${text}` : text;
}

function formatPercent(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return '-';
  const number = Number(value);
  const text = number.toLocaleString('ko-KR', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  return `${number > 0 ? '+' : ''}${text}%`;
}

function formatNumber(value) {
  return Number(value || 0).toLocaleString('ko-KR', { maximumFractionDigits: 2 });
}

function getLogicalFileName(row) {
  return stripComparisonExtension(
    row?.logicalName || row?.currentFileName || row?.baselineFileName || row?.fileName || ''
  );
}

function stripComparisonExtension(value) {
  let logicalName = String(value || '').trim().replace(/\\/g, '/');
  while (logicalName.startsWith('./')) logicalName = logicalName.slice(2);
  logicalName = logicalName.replace(/^\/+|\/+$/g, '');
  const isEmptyGeometryMarker = /_객체없음\.txt$/i.test(logicalName);
  logicalName = logicalName.replace(/\.(?:nwc|txt)$/i, '');
  return isEmptyGeometryMarker ? logicalName.replace(/_객체없음$/i, '') : logicalName;
}

function normalizeLogicalKey(value) {
  return stripComparisonExtension(value).trim().toLocaleLowerCase('en-US');
}

function displayGroupValue(value) {
  return String(value || '').trim() || '-';
}

function outputLabel(kind) {
  return ({
    nwc: 'NWC',
    txt: 'TXT (객체 없음)'
  })[String(kind || '').toLowerCase()] || '-';
}

function nullableNumber(value) {
  if (value === null || value === undefined || value === '') return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function makeEmpty(message) {
  const empty = div('nwccompare-empty nwccompare-empty--compact');
  empty.textContent = message;
  return empty;
}

function captureScroll(workspace) {
  const shellMain = workspace.closest('.direct3-main, .shell3-main');
  return {
    workspace,
    workspaceTop: workspace.scrollTop,
    shellMain,
    shellTop: shellMain?.scrollTop || 0,
    windowY: window.scrollY
  };
}

function restoreScroll(scroll) {
  requestAnimationFrame(() => {
    scroll.workspace.scrollTop = scroll.workspaceTop;
    if (scroll.shellMain) scroll.shellMain.scrollTop = scroll.shellTop;
    window.scrollTo(window.scrollX, scroll.windowY);
  });
}

function pick(object, ...names) {
  if (!object || typeof object !== 'object') return undefined;
  for (const name of names) {
    if (Object.prototype.hasOwnProperty.call(object, name)) return object[name];
  }
  return undefined;
}

function arrayOf(value) {
  return Array.isArray(value) ? value : [];
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, '&#96;');
}
