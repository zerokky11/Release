﻿// Resources/HubUI/js/core/progress.js
// 공용 중앙 진행 다이얼로그 (SegmentPMS / ParamPropagate 등에서 재사용)

const MIN_UPDATE_MS = 140;
const OWNER_KEY = Symbol.for('kky.sharedProgressDialog.owner');

let root = null;
let titleEl = null;
let detailEl = null;
let metaEl = null;
let pctEl = null;
let barFillEl = null;
let barEl = null;
let actionsEl = null;
let cancelBtn = null;
let skipBtn = null;
let statusEl = null;
let lastUpdate = 0;
let pendingTimer = null;
let pendingData = null;
let lastApplied = null;
let isVisible = false;
let ownerVersion = 0;
let actionHandlers = { onCancel: null, onSkip: null };

function ensure() {
    if (root && root.isConnected) return;
    root = document.createElement('div');
    lastApplied = null;
    root.className = 'segmentpms-progress is-hidden';

    const card = document.createElement('div');
    card.className = 'segmentpms-progress-card';

    titleEl = document.createElement('div'); titleEl.className = 'segmentpms-progress-title';
    detailEl = document.createElement('div'); detailEl.className = 'segmentpms-progress-detail';
    metaEl = document.createElement('div'); metaEl.className = 'segmentpms-progress-meta';

    const bar = document.createElement('div'); bar.className = 'segmentpms-progress-bar';
    barEl = bar; bar.setAttribute('role', 'progressbar'); bar.setAttribute('aria-valuemin', '0'); bar.setAttribute('aria-valuemax', '100');
    barFillEl = document.createElement('div'); barFillEl.className = 'segmentpms-progress-fill';
    bar.append(barFillEl);

    pctEl = document.createElement('div'); pctEl.className = 'segmentpms-progress-pct';

    actionsEl = document.createElement('div');
    actionsEl.className = 'segmentpms-progress-actions';
    statusEl = document.createElement('div');
    statusEl.className = 'segmentpms-progress-status';
    cancelBtn = document.createElement('button');
    cancelBtn.type = 'button';
    cancelBtn.className = 'btn btn--danger';
    cancelBtn.textContent = '취소';
    cancelBtn.style.display = 'none';
    skipBtn = document.createElement('button');
    skipBtn.type = 'button';
    skipBtn.className = 'btn btn--secondary';
    skipBtn.textContent = '다음 파일로';
    skipBtn.style.display = 'none';
    cancelBtn.addEventListener('click', () => {
        if (actionHandlers.onCancel) actionHandlers.onCancel();
    });
    skipBtn.addEventListener('click', () => {
        if (actionHandlers.onSkip) actionHandlers.onSkip();
    });
    actionsEl.append(statusEl, skipBtn, cancelBtn);

    card.append(titleEl, detailEl, metaEl, bar, pctEl, actionsEl);
    root.append(card);
    document.body.append(root);
}

function applyUpdate({ percent, subtitle, detail, indeterminate = false, owner }) {
    if (!isVisible || owner !== ownerVersion || owner !== globalThis[OWNER_KEY]) return;
    ensure();
    const pct = Math.max(0, Math.min(100, Number(percent) || 0));
    const applied = { pct, subtitle, detail, indeterminate, owner };
    if (lastApplied && Object.keys(applied).every(key => applied[key] === lastApplied[key])) return;
    lastApplied = applied;
    root.classList.toggle('is-indeterminate', indeterminate);
    if (barFillEl) barFillEl.style.width = indeterminate ? '35%' : `${pct}%`;
    if (barEl) {
        if (indeterminate) barEl.removeAttribute('aria-valuenow'); else barEl.setAttribute('aria-valuenow', String(pct));
        barEl.setAttribute('aria-label', subtitle || titleEl?.textContent || '작업 진행률');
    }
    if (pctEl) {
        const label = Number.isInteger(pct) ? `${pct.toFixed(0)}%` : `${pct.toFixed(1)}%`;
        pctEl.textContent = indeterminate ? '진행 중' : label;
    }
    if (detailEl && subtitle != null) detailEl.textContent = subtitle;
    if (metaEl && detail != null) metaEl.textContent = detail;
}

function throttledUpdate(data) {
    const now = performance.now ? performance.now() : Date.now();
    const elapsed = now - lastUpdate;
    if ((!data.indeterminate && Number(data.percent) >= 100) || elapsed >= MIN_UPDATE_MS) {
        lastUpdate = now;
        applyUpdate(data);
        pendingData = null;
        if (pendingTimer) { clearTimeout(pendingTimer); pendingTimer = null; }
        return;
    }
    pendingData = data;
    if (!pendingTimer) {
        pendingTimer = setTimeout(() => {
            pendingTimer = null;
            if (pendingData) throttledUpdate(pendingData);
        }, MIN_UPDATE_MS - elapsed);
    }
}

export const ProgressDialog = {
    show(title, subtitle) {
        ensure();
        ownerVersion = (Number(globalThis[OWNER_KEY]) || 0) + 1; globalThis[OWNER_KEY] = ownerVersion;
        // A cache-qualified import still shares the one visible application progress surface.
        for (const other of document.querySelectorAll('.segmentpms-progress')) if (other !== root) { other.classList.add('is-hidden'); other.style.display = 'none'; }
        pendingData = null; if (pendingTimer) { clearTimeout(pendingTimer); pendingTimer = null; } lastUpdate = -Infinity; lastApplied = null;
        root.classList.remove('is-indeterminate');
        if (root) root.style.display = 'flex';
        root.classList.remove('is-hidden');
        isVisible = true;
        document.body.classList.add('is-busy');
        if (barFillEl) barFillEl.style.width = '0%';
        if (pctEl) pctEl.textContent = '';
        if (barEl) barEl.removeAttribute('aria-valuenow');
        if (titleEl) titleEl.textContent = title || '작업을 진행하는 중입니다';
        if (detailEl) detailEl.textContent = subtitle || '';
        if (metaEl) metaEl.textContent = '';
        if (statusEl) statusEl.textContent = '';
        return ownerVersion;
    },
    isOwner(owner) { return isVisible && owner === ownerVersion && owner === globalThis[OWNER_KEY]; },
    update(percent, subtitle, detail, owner) {
        if (!isVisible || ownerVersion !== globalThis[OWNER_KEY]) return;
        if (owner != null && !this.isOwner(owner)) return;
        throttledUpdate({ percent, subtitle: subtitle ?? '', detail: detail ?? '', owner: ownerVersion });
    },
    updateIndeterminate(subtitle, detail, owner) {
        if (!isVisible || ownerVersion !== globalThis[OWNER_KEY]) return;
        if (owner != null && !this.isOwner(owner)) return;
        throttledUpdate({ indeterminate: true, subtitle: subtitle ?? '', detail: detail ?? '', owner: ownerVersion });
    },
    hide(owner) {
        if (owner != null && !this.isOwner(owner)) return;
        if (globalThis[OWNER_KEY] !== ownerVersion) return;
        if (root) {
            root.classList.add('is-hidden');
            root.style.display = 'none';
            root.classList.remove('is-indeterminate');
        }
        if (isVisible) {
            isVisible = false;
            document.body.classList.remove('is-busy');
        }
        pendingData = null;
        lastApplied = null;
        if (pendingTimer) { clearTimeout(pendingTimer); pendingTimer = null; }
        lastUpdate = 0;
        if (barFillEl) barFillEl.style.width = '0%';
        if (pctEl) pctEl.textContent = '';
        if (detailEl) detailEl.textContent = '';
        if (metaEl) metaEl.textContent = '';
        if (statusEl) statusEl.textContent = '';
        if (cancelBtn) cancelBtn.disabled = false;
        if (skipBtn) skipBtn.disabled = false;
        if (cancelBtn) cancelBtn.style.display = 'none';
        if (skipBtn) skipBtn.style.display = 'none';
        actionHandlers = { onCancel: null, onSkip: null };
    }
};

ProgressDialog.setActions = function setActions({ onCancel, onSkip, cancelLabel, skipLabel } = {}, owner) {
    if (owner != null && !ProgressDialog.isOwner(owner)) return;
    ensure();
    actionHandlers = { onCancel: onCancel || null, onSkip: onSkip || null };
    if (cancelBtn) {
        cancelBtn.textContent = cancelLabel || '취소';
        cancelBtn.style.display = actionHandlers.onCancel ? 'inline-flex' : 'none';
    }
    if (skipBtn) {
        skipBtn.textContent = skipLabel || '다음 파일로';
        skipBtn.style.display = actionHandlers.onSkip ? 'inline-flex' : 'none';
    }
};

ProgressDialog.setActionState = function setActionState({ statusText, cancelDisabled, skipDisabled } = {}, owner) {
    if (owner != null && !ProgressDialog.isOwner(owner)) return;
    if (statusEl && typeof statusText === 'string') statusEl.textContent = statusText;
    if (cancelBtn && typeof cancelDisabled === 'boolean') cancelBtn.disabled = cancelDisabled;
    if (skipBtn && typeof skipDisabled === 'boolean') skipBtn.disabled = skipDisabled;
};

export default ProgressDialog;
